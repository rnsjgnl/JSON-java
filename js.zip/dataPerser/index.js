/**
 * @file CLI
 */

const config = require('config');
const fs = require('fs');
const commandLineArgs = require('command-line-args');
//
const {loggerDebug, loggerApp} = require('./lib/util/logger.js'); // eslint-disable-line no-unused-vars
const sfdcToJSON = require('./lib');
const {isExistFile, checkFilename} = require('./lib/util/funcs.js'); // eslint-disable-line no-unused-vars
const redisOutput = require('./lib/util/redis.js');

//
const optionDefinitions = [
  {
    name: 'output',
    alias: 'o',
    type: String,
  },
  {
    name: 'template',
    alias: 't',
    type: String,
    defaultValue: './template.js'
  },
  {
    name: 'redis-host',
    alias: 'r',
    type: String,
  },
  {
    name: 'redis-port',
    alias: 'p',
    type: Number,
    defaultValue: 6379
  },
  {
    name: 'redis-prefix',
    alias: 'x',
    type: String,
    defaultValue: 'sfdc:'
  },
];
// コマンドライン引数処理
const options = commandLineArgs(optionDefinitions);

// template file
const templatesFileName = checkFilename(__dirname, options.template, true);

// output file
let outputFileName = null;
if(options.output){
  outputFileName = checkFilename(__dirname, options.output);
}

// redis
config.redis = config.redis || {};
config.redis.host = config.redis.host || options['redis-host'];
config.redis.port = config.redis.port || options['redis-port'];
config.redis.prefix = config.redis.prefix || options['redis-prefix'];

//
(async () => {
  //
  let json = null;

  //
  try{
    loggerApp.info(`template file : '${templatesFileName}'`);
    json = await sfdcToJSON(templatesFileName);
  }catch(e){
    loggerApp.fatal(`パースエラー : ${templatesFileName}, ${e.message}`);
  }

  //
  if(outputFileName){
    loggerApp.info(`Output file : '${outputFileName}'`);
    try{
      fs.writeFileSync(outputFileName, JSON.stringify(json, null, 2));
    }catch(e){
      loggerApp.fatal(`ファイル出力エラー : ${outputFileName}, ${e.message}`);
    }
  }

  //
  if(options['redis-host']){
    loggerApp.info(`Redis output : '${JSON.stringify(config.redis)}'`);
    try{
      await redisOutput(config.redis, json);
    }catch(e){
      loggerApp.fatal(`Redis出力エラー : ${JSON.stringify(config.redis)}, ${e.message}`);
    }
  }

  //
  process.exit(0);
  //
})();
