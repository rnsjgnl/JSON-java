//
const data01 = {key: '0001', data: 'DATA0001'};
const data02 = {key: '0002', data: 'DATA0002'};
const data03 = {key: '0003', data: 'DATA0003'};
const data04 = {key: '0004', data: 'DATA0004'};

//
const data11 = {keykey: '1001', data: 'DATA1001', data0x: '0001'};
const data12 = {keykey: '1002', data: 'DATA1002', data0x: '0001'};
const data13 = {keykey: '1003', data: 'DATA1003', data0x: '0002'};
const data14 = {keykey: '1004', data: 'DATA1004', data0x: '0003'};

//
const data21 = {key3: '2001', data: 'DATA2001', data1x: '1001'};
const data22 = {key3: '2002', data: 'DATA2002', data1x: '1001'};
const data23 = {key3: '2003', data: 'DATA2003', data1x: '1002'};
const data24 = {key3: '2004', data: 'DATA2004', data1x: '1003'};

//
test('test SfdcParser Object from JSON', async () => {

  //
  const SfdcParser = require('../lib/classes/SfdcParser.js');
  const sfdcParser = new SfdcParser();

  //
  const templatesConfig = {
    sfdc: {
      Table0:{
        index: 'key',
        data: [data01, data02, data03, data04]
      },
      Table1:{
        index: 'keykey',
        subIndex: ['data0x'],
        data:[data11, data12, data13, data14],
      },
      Table2:{
        index: 'key3',
        subIndex: 'data1x',
        data:[data21, data22, data23, data24],
      },
    },
    output: {
      sources: 'sfdc.Table0',
      templates: {
        key: 'this.key',
        data: 'this.data',
        data_func: function(sfdc, ctx){ // eslint-disable-line no-unused-vars
          return `${this.key}-${this.data}`;
        },
        //
        'child': {
          sources: 'sfdc.Table1.find("data0x", this.key)',
          templates: {
            key: 'this.keykey',
            data: function(sfdc, ctx){ // eslint-disable-line no-unused-vars
              return `${this.keykey}-${this.data}-${this.data0x}`;
            },
            //
            'child_child': {
              sources: 'sfdc.Table2.find("data1x", this.keykey)',
              templates: {
                dataX: 'this.data',
              }
            }
            //
          }
        }
        //
      }
    }
  };
  //    output = await sfdcParser.parse(templatesFileName);
  const result = await sfdcParser._parse(templatesConfig);
  const keys = Object.keys(result);
  //
  expect(keys).toHaveLength(4);
  expect(keys.indexOf('0001')).toBeGreaterThanOrEqual(0);
  expect(keys.indexOf('0002')).toBeGreaterThanOrEqual(0);
  expect(keys.indexOf('0003')).toBeGreaterThanOrEqual(0);
  expect(keys.indexOf('0004')).toBeGreaterThanOrEqual(0);
  //
  expect(result['0001']).toEqual({key: '0001', data: 'DATA0001', data_func: '0001-DATA0001',
    child:{
      '1001':{key:'1001', data: '1001-DATA1001-0001',
        child_child: {
          '2001': {dataX: 'DATA2001'},
          '2002': {dataX: 'DATA2002'}
        }
      },
      '1002':{key:'1002', data: '1002-DATA1002-0001',
        child_child: {
          '2003': {dataX: 'DATA2003'},
        }
      }
    }
  });
  expect(result['0002']).toEqual({key: '0002', data: 'DATA0002', data_func: '0002-DATA0002',
    child:{
      '1003':{key:'1003', data: '1003-DATA1003-0002',
        child_child: {
          '2004': {dataX: 'DATA2004'},
        }
      }
    }
  });
  expect(result['0003']).toEqual({key: '0003', data: 'DATA0003', data_func: '0003-DATA0003',
    child:{
      '1004':{key:'1004', data: '1004-DATA1004-0003',
        child_child: {
        }
      }
    }
  });
  expect(result['0004']).toEqual({key: '0004', data: 'DATA0004', data_func: '0004-DATA0004',
    child:{
    }
  });
  //
});

