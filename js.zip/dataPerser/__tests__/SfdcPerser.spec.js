const SfdcData = require('../lib/classes/SfdcData.js');
const SfdcObject = require('../lib/classes/SfdcObject.js');
const SfdcTable = require('../lib/classes/SfdcTable.js');


//
const data01 = {key: '0001', data: 'DATA0001'};
const data02 = {key: '0002', data: 'DATA0002'};
const data03 = {key: '0003', data: 'DATA0003'};
const data04 = {key: '0004', data: 'DATA0004'};
//
const sfdcObject01 = new SfdcObject(data01);
const sfdcObject02 = new SfdcObject(data02);
const sfdcObject03 = new SfdcObject(data03);
const sfdcObject04 = new SfdcObject(data04);
//
const sfdcTable0x = new SfdcTable('Table0', 'key');
//
sfdcTable0x.insert(sfdcObject01);
sfdcTable0x.insert(sfdcObject02);
sfdcTable0x.insert(sfdcObject03);
sfdcTable0x.insert(sfdcObject04);


//
const data11 = {keykey: '1001', data: 'DATA1001', data0x: '0001'};
const data12 = {keykey: '1002', data: 'DATA1002', data0x: '0001'};
const data13 = {keykey: '1003', data: 'DATA1003', data0x: '0002'};
const data14 = {keykey: '1004', data: 'DATA1004', data0x: '0003'};
//
const sfdcObject11 = new SfdcObject(data11);
const sfdcObject12 = new SfdcObject(data12);
const sfdcObject13 = new SfdcObject(data13);
const sfdcObject14 = new SfdcObject(data14);
//
const sfdcTable1x = new SfdcTable('Table1', 'keykey', ['data0x']);
//
sfdcTable1x.insert(sfdcObject11);
sfdcTable1x.insert(sfdcObject12);
sfdcTable1x.insert(sfdcObject13);
sfdcTable1x.insert(sfdcObject14);


//
const data21 = {key3: '2001', data: 'DATA2001', data1x: '1001'};
const data22 = {key3: '2002', data: 'DATA2002', data1x: '1001'};
const data23 = {key3: '2003', data: 'DATA2003', data1x: '1002'};
const data24 = {key3: '2004', data: 'DATA2004', data1x: '1003'};
//
const sfdcObject21 = new SfdcObject(data21);
const sfdcObject22 = new SfdcObject(data22);
const sfdcObject23 = new SfdcObject(data23);
const sfdcObject24 = new SfdcObject(data24);
//
const sfdcTable2x = new SfdcTable('Table2', 'key3', ['data1x']);
//
sfdcTable2x.insert(sfdcObject21);
sfdcTable2x.insert(sfdcObject22);
sfdcTable2x.insert(sfdcObject23);
sfdcTable2x.insert(sfdcObject24);


//
const sfdcData = new SfdcData();
//
sfdcData.insert(sfdcTable0x);
sfdcData.insert(sfdcTable1x);
sfdcData.insert(sfdcTable2x);

////////////////////////////////////////////////////////////////////////////////
// error系
////////////////////////////////////////////////////////////////////////////////

//
test('test SfdcParser Object (source no target item)', () => {

  //
  const SfdcParser = require('../lib/classes/SfdcParser.js');
  const sfdcParser = new SfdcParser();
  sfdcParser.sfdcData = sfdcData;

  //
  const templatesConfig = {
    output: {
      source: 'sfdc.Table0.find("X", 5)',
      templates: {
        key: 'this.key',
        data: 'this.data',
        data_func: function(sfdc, ctx){ // eslint-disable-line no-unused-vars
          return `${this.key}-${this.data}`;
        },
      }
    }
  };
  //
  const result = sfdcParser._toJson('output', templatesConfig.output);
  expect(result).toEqual({});
  //
});

test('test SfdcParser Object (no source root)', () => {

  //
  const SfdcParser = require('../lib/classes/SfdcParser.js');
  const sfdcParser = new SfdcParser();
  sfdcParser.sfdcData = sfdcData;

  //
  const templatesConfig = {
    output: {
      //source: 'sfdc.Table0',
      templates: {
        data: 'this.data',
      }
    }
  };
  //
  const result = sfdcParser._toJson('output', templatesConfig.output);
  expect(result).toEqual('!fatal! "source" または "sources" が存在しません。"output" : {"templates":{"data":"this.data"}}');
  //
});

test('test SfdcParser Object (no templates root)', () => {

  //
  const SfdcParser = require('../lib/classes/SfdcParser.js');
  const sfdcParser = new SfdcParser();
  sfdcParser.sfdcData = sfdcData;

  //
  const templatesConfig = {
    output: {
      source: 'sfdc.Table0',
      //templates: {
      //  data: 'this.data',
      //}
    }
  };
  //
  const result = sfdcParser._toJson('output', templatesConfig.output);
  expect(result).toEqual('!fatal! "templates" または "template" が存在しません。"output" : {"source":"sfdc.Table0"}');
  //
});

test('test SfdcParser Object (invalid templates format root)', () => {

  //
  const SfdcParser = require('../lib/classes/SfdcParser.js');
  const sfdcParser = new SfdcParser();
  sfdcParser.sfdcData = sfdcData;

  //
  const templatesConfig = {
    output: {
      source: 'sfdc.Table0',
      templates: 'hogehoge'
    }
  };
  //
  const result = sfdcParser._toJson('output', templatesConfig.output);
  expect(result).toEqual('!fatal! "templates" の書式が違います。"output" : {"source":"sfdc.Table0","templates":"hogehoge"}');
  //
});

test('test SfdcParser Object (no source)', () => {

  //
  const SfdcParser = require('../lib/classes/SfdcParser.js');
  const sfdcParser = new SfdcParser();
  sfdcParser.sfdcData = sfdcData;

  //
  const templatesConfig = {
    output: {
      source: 'sfdc.Table0',
      templates: {
        data: 'this.data',
        'child': {
          //sources: 'sfdc.Table1.find("data0x", this.key)',
          templates: {
            data: 'this.data',
          }
        }
      }
    }
  };
  //
  const result = sfdcParser._toJson('output', templatesConfig.output);
  expect(result.child).toEqual('!fatal! "source" または "sources" が存在しません。"child" : {"templates":{"data":"this.data"}}');
  //
});

test('test SfdcParser Object (no templates)', () => {

  //
  const SfdcParser = require('../lib/classes/SfdcParser.js');
  const sfdcParser = new SfdcParser();
  sfdcParser.sfdcData = sfdcData;

  //
  const templatesConfig = {
    output: {
      source: 'sfdc.Table0',
      templates: {
        data: 'this.data',
        'child': {
          sources: 'sfdc.Table1.find("data0x", this.key)',
          //templates: {
          //  data: 'this.data',
          //}
        }
      }
    }
  };
  //
  const result = sfdcParser._toJson('output', templatesConfig.output);
  expect(result.child).toEqual('!fatal! "templates" または "template" が存在しません。"child" : {"sources":"sfdc.Table1.find(\\"data0x\\", this.key)"}');
  //
});

test('test SfdcParser Object (invalid templates format)', () => {

  //
  const SfdcParser = require('../lib/classes/SfdcParser.js');
  const sfdcParser = new SfdcParser();
  sfdcParser.sfdcData = sfdcData;

  //
  const templatesConfig = {
    output: {
      source: 'sfdc.Table0',
      templates: {
        data: 'this.data',
        'child': {
          sources: 'sfdc.Table1.find("data0x", this.key)',
          templates: 'hogehoge'
        }
      }
    }
  };
  //
  const result = sfdcParser._toJson('output', templatesConfig.output);
  expect(result.child).toEqual('!fatal! "templates" の書式が違います。"child" : {"sources":"sfdc.Table1.find(\\"data0x\\", this.key)","templates":"hogehoge"}');
  //
});

////////////////////////////////////////////////////////////////////////////////
// コマンド error系
////////////////////////////////////////////////////////////////////////////////

test('test SfdcParser Object (invalid command)', () => {

  //
  const SfdcParser = require('../lib/classes/SfdcParser.js');
  const sfdcParser = new SfdcParser();
  sfdcParser.sfdcData = sfdcData;

  //
  const templatesConfig = {
    output: {
      sources: 'sfdc.Table0',
      templates: {
        key: 'x.key',
        data: 'this.datax',
        syntax_error: '* + a',
      }
    }
  };
  //
  const result = sfdcParser._toJson('output', templatesConfig.output);
  expect(result['0001'].key).toEqual('!fatal! "key" : "x.key" コマンドエラー。x is not defined');
  expect(result['0001'].data).toEqual(undefined);
  expect(result['0001'].syntax_error).toEqual('!fatal! "syntax_error" : "* + a" シンタックスエラー。Unexpected token *');
  //
});







////////////////////////////////////////////////////////////////////////////////
// 正常系
////////////////////////////////////////////////////////////////////////////////

//
test('test SfdcParser Object', () => {

  //
  const SfdcParser = require('../lib/classes/SfdcParser.js');
  const sfdcParser = new SfdcParser();
  sfdcParser.sfdcData = sfdcData;

  //
  const templatesConfig = {
    output: {
      sources: 'sfdc.Table0',
      templates: {
        key: 'this.key',
        data: 'this.data',
        data_func: function(sfdc, ctx){ // eslint-disable-line no-unused-vars
          return `${this.key}-${this.data}`;
        },
      }
    }
  };
  //
  const result = sfdcParser._toJson('output', templatesConfig.output);
  const keys = Object.keys(result);

  //
  expect(keys).toHaveLength(4);
  expect(keys.indexOf('0001')).toBeGreaterThanOrEqual(0);
  expect(keys.indexOf('0002')).toBeGreaterThanOrEqual(0);
  expect(keys.indexOf('0003')).toBeGreaterThanOrEqual(0);
  expect(keys.indexOf('0004')).toBeGreaterThanOrEqual(0);
  //
  expect(result['0001']).toEqual({key: '0001', data: 'DATA0001', data_func: '0001-DATA0001'});
  expect(result['0002']).toEqual({key: '0002', data: 'DATA0002', data_func: '0002-DATA0002'});
  expect(result['0003']).toEqual({key: '0003', data: 'DATA0003', data_func: '0003-DATA0003'});
  expect(result['0004']).toEqual({key: '0004', data: 'DATA0004', data_func: '0004-DATA0004'});
  //

});

//
test('test SfdcParser Object (source)', () => {

  //
  const SfdcParser = require('../lib/classes/SfdcParser.js');
  const sfdcParser = new SfdcParser();
  sfdcParser.sfdcData = sfdcData;

  //
  const templatesConfig = {
    output: {
      source: 'sfdc.Table0',
      templates: {
        key: 'this.key',
        data: 'this.data',
        data_func: function(sfdc, ctx){ // eslint-disable-line no-unused-vars
          return `${this.key}-${this.data}`;
        },
      }
    }
  };
  //    output = await sfdcParser.parse(templatesFileName);
  const result = sfdcParser._toJson('output', templatesConfig.output);
  expect(result).toEqual({key: '0001', data: 'DATA0001', data_func: '0001-DATA0001'});
  //
});

//
test('test SfdcParser Object (filter)', () => {

  //
  const SfdcParser = require('../lib/classes/SfdcParser.js');
  const sfdcParser = new SfdcParser();
  sfdcParser.sfdcData = sfdcData;

  //
  const templatesConfig = {
    output: {
      sources: 'sfdc.Table0',
      filter: function(sfdc, ctx){ // eslint-disable-line no-unused-vars
        if(this.key === '0002')return false;
        return true;
      },
      templates: {
        key: 'this.key',
        data: 'this.data',
        data_func: function(sfdc, ctx){ // eslint-disable-line no-unused-vars
          return `${this.key}-${this.data}`;
        },
      }
    }
  };
  //    output = await sfdcParser.parse(templatesFileName);
  const result = sfdcParser._toJson('output', templatesConfig.output);
  const keys = Object.keys(result);

  //
  expect(keys).toHaveLength(3);
  expect(keys.indexOf('0001')).toBeGreaterThanOrEqual(0);
  expect(keys.indexOf('0003')).toBeGreaterThanOrEqual(0);
  expect(keys.indexOf('0004')).toBeGreaterThanOrEqual(0);
  //
  expect(result['0001']).toEqual({key: '0001', data: 'DATA0001', data_func: '0001-DATA0001'});
  expect(result['0003']).toEqual({key: '0003', data: 'DATA0003', data_func: '0003-DATA0003'});
  expect(result['0004']).toEqual({key: '0004', data: 'DATA0004', data_func: '0004-DATA0004'});
  //

});

//
test('test SfdcParser Object (render_child)', () => {

  //
  const SfdcParser = require('../lib/classes/SfdcParser.js');
  const sfdcParser = new SfdcParser();
  sfdcParser.sfdcData = sfdcData;

  //
  const templatesConfig = {
    output: {
      sources: 'sfdc.Table0',
      templates: {
        key: 'this.key',
        data: 'this.data',
        data_func: function(sfdc, ctx){ // eslint-disable-line no-unused-vars
          return `${this.key}-${this.data}`;
        },
        'child': {
          sources: 'sfdc.Table1.find("data0x", this.key)',
          templates: {
            key: 'this.keykey',
            data: function(sfdc, ctx){ // eslint-disable-line no-unused-vars
              return `${this.keykey}-${this.data}-${this.data0x}`;
            },
          }
        }
      }
    }
  };
  //    output = await sfdcParser.parse(templatesFileName);
  const result = sfdcParser._toJson('output', templatesConfig.output);
  const keys = Object.keys(result);

  //
  expect(keys).toHaveLength(4);
  expect(keys.indexOf('0001')).toBeGreaterThanOrEqual(0);
  expect(keys.indexOf('0002')).toBeGreaterThanOrEqual(0);
  expect(keys.indexOf('0003')).toBeGreaterThanOrEqual(0);
  expect(keys.indexOf('0004')).toBeGreaterThanOrEqual(0);
  //
  expect(result['0001']).toEqual({key: '0001', data: 'DATA0001', data_func: '0001-DATA0001',
    child:{
      '1001':{key:'1001', data: '1001-DATA1001-0001'},
      '1002':{key:'1002', data: '1002-DATA1002-0001'}
    }
  });
  expect(result['0002']).toEqual({key: '0002', data: 'DATA0002', data_func: '0002-DATA0002', child:{'1003':{key:'1003', data: '1003-DATA1003-0002'}}});
  expect(result['0003']).toEqual({key: '0003', data: 'DATA0003', data_func: '0003-DATA0003', child:{'1004':{key:'1004', data: '1004-DATA1004-0003'}}});
  expect(result['0004']).toEqual({key: '0004', data: 'DATA0004', data_func: '0004-DATA0004', child:{}});
  //

});

//
test('test SfdcParser Object (render_child_child)', () => {

  //
  const SfdcParser = require('../lib/classes/SfdcParser.js');
  const sfdcParser = new SfdcParser();
  sfdcParser.sfdcData = sfdcData;

  //
  const templatesConfig = {
    output: {
      sources: 'sfdc.Table0',
      templates: {
        key: 'this.key',
        data: 'this.data',
        data_func: function(sfdc, ctx){ // eslint-disable-line no-unused-vars
          return `${this.key}-${this.data}`;
        },
        //
        'child': {
          sources: 'sfdc.Table1.find("data0x", this.key)',
          templates: {
            key: 'this.keykey',
            data: function(sfdc, ctx){ // eslint-disable-line no-unused-vars
              return `${this.keykey}-${this.data}-${this.data0x}`;
            },
            //
            'child_child': {
              sources: 'sfdc.Table2.find("data1x", this.keykey)',
              templates: {
                dataX: 'this.data',
              }
            }
            //
          }
        }
        //
      }
    }
  };
  //    output = await sfdcParser.parse(templatesFileName);
  const result = sfdcParser._toJson('output', templatesConfig.output);
  const keys = Object.keys(result);
  //
  expect(keys).toHaveLength(4);
  expect(keys.indexOf('0001')).toBeGreaterThanOrEqual(0);
  expect(keys.indexOf('0002')).toBeGreaterThanOrEqual(0);
  expect(keys.indexOf('0003')).toBeGreaterThanOrEqual(0);
  expect(keys.indexOf('0004')).toBeGreaterThanOrEqual(0);
  //
  expect(result['0001']).toEqual({key: '0001', data: 'DATA0001', data_func: '0001-DATA0001',
    child:{
      '1001':{key:'1001', data: '1001-DATA1001-0001',
        child_child: {
          '2001': {dataX: 'DATA2001'},
          '2002': {dataX: 'DATA2002'}
        }
      },
      '1002':{key:'1002', data: '1002-DATA1002-0001',
        child_child: {
          '2003': {dataX: 'DATA2003'},
        }
      }
    }
  });
  expect(result['0002']).toEqual({key: '0002', data: 'DATA0002', data_func: '0002-DATA0002',
    child:{
      '1003':{key:'1003', data: '1003-DATA1003-0002',
        child_child: {
          '2004': {dataX: 'DATA2004'},
        }
      }
    }
  });
  expect(result['0003']).toEqual({key: '0003', data: 'DATA0003', data_func: '0003-DATA0003',
    child:{
      '1004':{key:'1004', data: '1004-DATA1004-0003',
        child_child: {
        }
      }
    }
  });
  expect(result['0004']).toEqual({key: '0004', data: 'DATA0004', data_func: '0004-DATA0004',
    child:{
    }
  });
  //
});
