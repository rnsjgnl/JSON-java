const SfdcObject = require('../lib/classes/SfdcObject.js');

//
test('test SfdcData Object', () => {

  const sfdcObject = new SfdcObject();
  //
  sfdcObject.import(/*'key', */{key: '0001', data: 'DATA0001'});
  //
  //expect(sfdcObject.$index).toBe('key');
  expect(sfdcObject.key).toBe('0001');
  expect(sfdcObject.data).toBe('DATA0001');

});

//
test('test SfdcData Object (init by constructor)', () => {

  const sfdcObject = new SfdcObject(/*'key', */{key: '0001', data: 'DATA0001'});
  //
  //expect(sfdcObject.$index).toBe('key');
  expect(sfdcObject.key).toBe('0001');
  expect(sfdcObject.data).toBe('DATA0001');

});
