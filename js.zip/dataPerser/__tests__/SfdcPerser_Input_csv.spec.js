const fs = require('fs');
const path = require('path');
const mkdirp = require('mkdirp');

//
const csv01 =
`"key","data"
"0001","DATA0001"
"0002","DATA0002"
"0003","DATA0003"
"0004","DATA0004"
`;
const csv02 =
`"keykey","data","data0x"
"1001","DATA1001","0001"
"1002","DATA1002","0001"
"1003","DATA1003","0002"
"1004","DATA1004","0003"
`;
const csv03 =
`"key3","data","data1x"
"2001","DATA2001","1001"
"2002","DATA2002","1001"
"2003","DATA2003","1002"
"2004","DATA2004","1003"
`;

//
test('test SfdcParser Object from CSV', async () => {

  //
  const SfdcParser = require('../lib/classes/SfdcParser.js');
  const sfdcParser = new SfdcParser();

  //
  mkdirp.sync(path.normalize(path.join(__dirname, 'work')));
  //
  const fname01 = path.normalize(path.join(__dirname, 'work', 'csv01.csv'));
  const fname02 = path.normalize(path.join(__dirname, 'work', 'csv02.csv'));
  const fname03 = path.normalize(path.join(__dirname, 'work', 'csv03.csv'));
  fs.writeFileSync(fname01, csv01);
  fs.writeFileSync(fname02, csv02);
  fs.writeFileSync(fname03, csv03);

  //
  const templatesConfig = {
    sfdc: {
      Table0:{
        index: 'key',
        filename: fname01
      },
      Table1:{
        index: 'keykey',
        subIndex: ['data0x'],
        filename: fname02
      },
      Table2:{
        index: 'key3',
        subIndex: 'data1x',
        filename: fname03
      },
    },
    output: {
      sources: 'sfdc.Table0',
      templates: {
        key: 'this.key',
        data: 'this.data',
        data_func: function(sfdc, ctx){ // eslint-disable-line no-unused-vars
          return `${this.key}-${this.data}`;
        },
        //
        'child': {
          sources: 'sfdc.Table1.find("data0x", this.key)',
          templates: {
            key: 'this.keykey',
            data: function(sfdc, ctx){ // eslint-disable-line no-unused-vars
              return `${this.keykey}-${this.data}-${this.data0x}`;
            },
            //
            'child_child': {
              sources: 'sfdc.Table2.find("data1x", this.keykey)',
              templates: {
                dataX: 'this.data',
              }
            }
            //
          }
        }
        //
      }
    }
  };
  //
  const result = await sfdcParser._parse(templatesConfig);
  const keys = Object.keys(result);
  //
  expect(keys).toHaveLength(4);
  expect(keys.indexOf('0001')).toBeGreaterThanOrEqual(0);
  expect(keys.indexOf('0002')).toBeGreaterThanOrEqual(0);
  expect(keys.indexOf('0003')).toBeGreaterThanOrEqual(0);
  expect(keys.indexOf('0004')).toBeGreaterThanOrEqual(0);
  //
  expect(result['0001']).toEqual({key: '0001', data: 'DATA0001', data_func: '0001-DATA0001',
    child:{
      '1001':{key:'1001', data: '1001-DATA1001-0001',
        child_child: {
          '2001': {dataX: 'DATA2001'},
          '2002': {dataX: 'DATA2002'}
        }
      },
      '1002':{key:'1002', data: '1002-DATA1002-0001',
        child_child: {
          '2003': {dataX: 'DATA2003'},
        }
      }
    }
  });
  expect(result['0002']).toEqual({key: '0002', data: 'DATA0002', data_func: '0002-DATA0002',
    child:{
      '1003':{key:'1003', data: '1003-DATA1003-0002',
        child_child: {
          '2004': {dataX: 'DATA2004'},
        }
      }
    }
  });
  expect(result['0003']).toEqual({key: '0003', data: 'DATA0003', data_func: '0003-DATA0003',
    child:{
      '1004':{key:'1004', data: '1004-DATA1004-0003',
        child_child: {
        }
      }
    }
  });
  expect(result['0004']).toEqual({key: '0004', data: 'DATA0004', data_func: '0004-DATA0004',
    child:{
    }
  });
  //
});
