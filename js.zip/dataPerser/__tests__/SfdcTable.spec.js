const SfdcObject = require('../lib/classes/SfdcObject.js');
const SfdcTable = require('../lib/classes/SfdcTable.js');

//
const data01 = {key: '0001', data: 'DATA0001', subkey01: 'A', subkey02: 'X'};
const data02 = {key: '0002', data: 'DATA0002', subkey01: 'A', subkey02: 'Y'};
const data03 = {key: '0003', data: 'DATA0003', subkey01: 'B', subkey02: 'X'};

//
test('test SfdcTable Object', () => {
  //
  const sfdcObject01 = new SfdcObject(data01);
  const sfdcObject02 = new SfdcObject(data02);
  const sfdcObject03 = new SfdcObject(data03);

  //
  const sfdcTable = new SfdcTable('TestTable', 'key', 'subkey01');
  //
  sfdcTable.insert(sfdcObject01);
  sfdcTable.insert(sfdcObject02);
  sfdcTable.insert(sfdcObject03);

  //
  expect(sfdcTable.tableName()).toBe('TestTable');

  //
  const findResult01_A = sfdcTable.find('subkey01', 'A');
  const findResult01_B = sfdcTable.find('subkey01', 'B');
  const findResult01_C = sfdcTable.find('subkey01', 'C');
  //
  expect(findResult01_A['0001']).toEqual(data01);
  expect(findResult01_A['0002']).toEqual(data02);
  expect(findResult01_A['0003']).toBe(undefined);
  //
  expect(findResult01_B['0001']).toBe(undefined);
  expect(findResult01_B['0002']).toBe(undefined);
  expect(findResult01_B['0003']).toEqual(data03);
  //
  expect(findResult01_C['0001']).toBe(undefined);
  expect(findResult01_C['0002']).toBe(undefined);
  expect(findResult01_C['0003']).toBe(undefined);

});


//
test('test SfdcTable Object (multi key)', () => {
  //
  const sfdcObject01 = new SfdcObject(data01);
  const sfdcObject02 = new SfdcObject(data02);
  const sfdcObject03 = new SfdcObject(data03);

  //
  const sfdcTable = new SfdcTable('TestTable', 'key', ['subkey01', 'subkey02']);
  //
  sfdcTable.insert(sfdcObject01);
  sfdcTable.insert(sfdcObject02);
  sfdcTable.insert(sfdcObject03);

  //
  expect(sfdcTable.tableName()).toBe('TestTable');

  //
  const findResult01_A = sfdcTable.find('subkey01', 'A');
  const findResult01_B = sfdcTable.find('subkey01', 'B');
  const findResult01_C = sfdcTable.find('subkey01', 'C');
  //
  expect(findResult01_A['0001']).toEqual(data01);
  expect(findResult01_A['0002']).toEqual(data02);
  expect(findResult01_A['0003']).toBe(undefined);
  //
  expect(findResult01_B['0001']).toBe(undefined);
  expect(findResult01_B['0002']).toBe(undefined);
  expect(findResult01_B['0003']).toEqual(data03);
  //
  expect(findResult01_C['0001']).toBe(undefined);
  expect(findResult01_C['0002']).toBe(undefined);
  expect(findResult01_C['0003']).toBe(undefined);

  //
  const findResult02_X = sfdcTable.find('subkey02', 'X');
  const findResult02_Y = sfdcTable.find('subkey02', 'Y');
  const findResult02_Z = sfdcTable.find('subkey02', 'Z');
  //
  expect(findResult02_X['0001']).toEqual(data01);
  expect(findResult02_X['0002']).toBe(undefined);
  expect(findResult02_X['0003']).toEqual(data03);
  //
  expect(findResult02_Y['0001']).toBe(undefined);
  expect(findResult02_Y['0002']).toEqual(data02);
  expect(findResult02_Y['0003']).toBe(undefined);
  //
  expect(findResult02_Z['0001']).toBe(undefined);
  expect(findResult02_Z['0002']).toBe(undefined);
  expect(findResult02_Z['0003']).toBe(undefined);

});
