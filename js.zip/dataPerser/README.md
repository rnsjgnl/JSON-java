# SFDC 2 JSON

## インストール

```bash
git clone "http://t_itou@vmsv1713/SFDC/dataPerser.git"
cd dataPerser
git checkout release
git pull
npm install
```

## Run Tests

```bash
npm run test
```

## サンプルの実行

```bash
node index.js -o ./sample/output.json -t ./sample/template.js -r 192.168.154.161
```

|command|||
|:--|:--|:--|
|--template -t|テンプレートファイル名|(default) `./template.js`|
|--output -o (option)|出力ファイル名|`./sample/output.json`|
|--redis-host -r (option)|Redis出力先IP|`192.168.154.161`|
|--redis-port -p (option)|Redis出力先ポート|(default) `6379`|
|--redis-prefix -x (option)|Redis出力Prefix|(default) `sfdc`|




## 設定ファイル

```bash
./config/default.json5
```

## テンプレートの書き方

```bash
./sample/template.js
```

を参照してください。

```js
// ./sample/template.js
module.exports = {

  // SFDC 読み込みCSV指定
  sfdc: {

    Table0:{                // 参照テーブル名
      index: 'key',         // キー
      filename: 'csv01.csv' // 参照CSV
    },

    Table1:{                // 参照テーブル名
      index: 'keykey',      // キー
      subIndex: ['data0x'], // lookupキー
      filename: 'csv02.csv' // 参照CSV
    },

    Sex: {                  // 固定データ参照テーブル名
      index: 'kind',        // キー
      subIndex: ['kind'],   // lookupキー
      data: [               // 値(CSV以外の固定値定義可能)
        {kind : 0, value: '男'},
        {kind : 1, value: '女'},
        {kind : 2, value: 'その他'},
      ]
    }

  },

  // 出力指定
  output: {

    // ソース指定（上記 sfdcオブジェクト名)
    sources: 'sfdc.Table0',

    /**
     * フィルタ関数(option)
     * @param {JSON} sfdc sfdcオブジェクト
     * @param {JSON} ctx コンテキスト(logger ロガー, data 参照レコード(=== this), config 設定ファイル情報)
     */
    filter: function(sfdc, ctx){
      if(this.key === '0003'){
        ctx.logger.info('データスキップ', this.key);
        return false; // falseを戻すと、出力されない
      }
      return true;
    },

    // 出力テンプレート
    templates: {

      // 単純出力 (thisは現在参照しているレコード)
      key: 'this.key',

      // 単純演算出力(JavaScript構文が利用できます)
      data: 'this.key + "@" + this.data',

      // 単純出力(日付)
      datetime: 'this.datetime',

      // 日付フォーマット出力(JST)
      formatted_local_datetime: 'moment(this.datetime).format("YYYY-MM-DD HH:mm:ss")',

      // 関数出力(JavaScript構文が利用できます)
      keiyaku: function(sfdc, ctx){ // eslint-disable-line no-unused-vars
        // 要素が無いので undefined でreturn ⇒要素出力しない
        if(!this.keiyaku)return undefined;
        // 行末「;」を削除
        const temp = this.keiyaku.replace(/.?;$/, '');
        // 「;」で分離
        return temp.split(';');
        //
      },

      // 他テーブル参照する場合（構造はトップレベルと同等）
      child: {

        // ソース指定（上記 sfdcオブジェクト名に対して lookupキー、検索キーの指定)
        sources: 'sfdc.Table1.find("data0x", this.key)',

        // 出力テンプレート
        templates: {

          // 単純出力
          key: 'this.keykey',

          // 関数出力
          data: function(sfdc, ctx){ // eslint-disable-line no-unused-vars
            return `${this.keykey}-${this.data}-${this.data0x}`;
          },

          // 参照出力
          profile: {

            // ソース指定 ※ !caution!  「sources」 ではなく 「source」
            source: 'sfdc.Sex.find("kind", this.sex)',

            // 出力テンプレート
            templates:{
              value: 'this.value'
            }
          },

          // 参照出力(直接出力)
          sex: {

            // ソース指定 ※ !caution!  「sources」 ではなく 「source」
            source: 'sfdc.Sex.find("kind", this.sex)',

            // 出力テンプレート(直接出力用)
            template : 'this.value'
          }
        },

      }

    }
  }
};
```

---
EOF
