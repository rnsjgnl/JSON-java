module.exports = {
  verbose: true,
  collectCoverage: true,
  testPathIgnorePatterns:[
    "/node_modules/",
    "__tests__/work/"
  ]
};
