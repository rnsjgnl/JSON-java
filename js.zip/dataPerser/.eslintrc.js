module.exports = {
  root: true,
  env: {
    node: true,
    es6: true,
    "jest/globals": true
  },
  plugins: [
    "jest"
  ],
  extends: [
    'eslint:recommended',
    //'plugin:vue/essential',
    //'plugin:vue/recommended',
    //'plugin:prettier/recommended'
  ],
  rules: {
    //
    // semi
    'semi': ['error', 'always'],
    'semi-spacing': ['error', {'after': true, 'before': false}],
    'semi-style': ['error', 'last'],
    'no-extra-semi': 'error',
    'no-unexpected-multiline': 'error',
    'no-unreachable': 'error',
    //
    'quotes': [2, 'single'],
    //
    'no-console': process.env.NODE_ENV === 'production' ? 'error' : 'off',
    'no-debugger': process.env.NODE_ENV === 'production' ? 'error' : 'off',
    //
    "jest/no-disabled-tests": "warn",
    "jest/no-focused-tests": "error",
    "jest/no-identical-title": "error",
    "jest/prefer-to-have-length": "warn",
    "jest/valid-expect": "error",
    //
  },
  parserOptions: {
    ecmaVersion: 2018,
  }
}
