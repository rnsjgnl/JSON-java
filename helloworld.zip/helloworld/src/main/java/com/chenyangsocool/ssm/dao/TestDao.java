package com.chenyangsocool.ssm.dao;

import com.chenyangsocool.ssm.model.Test;

public interface TestDao {
    Test getModelById(String id);
}
