CREATE OR REPLACE PACKAGE NH010106B001_101
/* **********************************************************
 *  Copyright(c) 2011 beyond, INTEC Inc. All rights reserved.
 * **********************************************************/
AUTHID CURRENT_USER
IS
	/*** �J�[�\���^ ***************************************************************/
	-- �G���[���i�[�p�J�[�\���^
	TYPE ERR_INF_CSR		IS REF CURSOR;

	/*
	************************************************************************
	*  DCF�{�ݑf��DB�f�[�^�̍쐬
	*  CREATE_DCF_SHISETSU
	************************************************************************
	*/
	FUNCTION CREATE_DCF_SHISETSU(
	iLayoutKind	IN	INTEGER,										-- ���C�A�E�g�敪
	iShimeKind	IN	INTEGER,										-- ���ߓ��敪
	iTensoYMD	IN	VARCHAR2,										-- �]���N���� 
	iIP_ADDR	IN TL_STORED_SHORI.IP%TYPE,							-- ���s�[��IP�A�h���X (FW�Őݒ�)
	iWINDOWS_LOGIN_USER	IN TL_STORED_SHORI.WINDOWS_LOGIN_USER%TYPE, -- ���s�[��OS���[�U�[ (FW�Őݒ�)
	oROW_COUNT	OUT NUMBER,         -- �o�^����
	oOUT_ERR_INF_CSR 	OUT ERR_INF_CSR,    -- �G���[���J�[�\��
	iOPE_CD IN Varchar2,                      -- �I�y���[�^�R�[�h
	iPGM_ID IN Varchar2,                      -- �v���O����ID
	iDATE DATE                              -- �V�X�e������
	) RETURN NUMBER;

END;
/
CREATE OR REPLACE PACKAGE BODY NH010106B001_101
/* **********************************************************
 *  Copyright(c) 2011 beyond, INTEC Inc. All rights reserved.
 * **********************************************************/
IS
	/*
	************************************************************************
	* Function ID  : CREATE_DCF_SHISETSU
	* Program Name : DCF�{�ݑf��DB�f�[�^�̍쐬
	* Parameter    :  <I> iLayoutKind		�F���C�A�E�g�敪
	*				         <I> iShimeKind		�F���ߓ��敪
	*				         <I> iTensoYMD		�F�]���N����
	*				         <I> iOPE_CD		�F�I�y���[�^�R�[�h
	*				         <I> iPGM_ID		�F�v���O����ID
	*				         <I> iDATE		�F�V�X�e������
	*		             <I> iIP_ADDR		�F���s�[��IP�A�h���X
	*		             <I> iWINDOWS_LOGIN_USER  �F���s�[��IP�A�h���X
	*                <O> oROW_COUNT		    �F�X�V����
	*                <O> oOUT_ERR_INF_CSR	�F�G���[���J�[�\��
	* Return       �F�������ʁi0:����I���A1:�ُ�I���j
	************************************************************************
	*/
  FUNCTION CREATE_DCF_SHISETSU(
  iLayoutKind  IN  INTEGER,                    -- ���C�A�E�g�敪
  iShimeKind  IN  INTEGER,                    -- ���ߓ��敪
  iTensoYMD  IN  VARCHAR2,                    -- �]���N����
  iIP_ADDR  IN TL_STORED_SHORI.IP%TYPE,              -- ���s�[��IP�A�h���X (FW�Őݒ�)
  iWINDOWS_LOGIN_USER  IN TL_STORED_SHORI.WINDOWS_LOGIN_USER%TYPE, -- ���s�[��OS���[�U�[ (FW�Őݒ�)
  oROW_COUNT  OUT NUMBER,         -- �o�^����
  oOUT_ERR_INF_CSR   OUT ERR_INF_CSR,    -- �G���[���J�[�\��
  iOPE_CD IN Varchar2,                      -- �I�y���[�^�R�[�h
  iPGM_ID IN Varchar2,                      -- �v���O����ID
  iDATE DATE                            -- �V�X�e������
  )RETURN NUMBER IS

  PRAGMA AUTONOMOUS_TRANSACTION;

  /************************************************************************/
  /*                              �G���[����                              */
  /************************************************************************/
  W_INDEX_N           NUMBER(10) := 0;
  W_ERR_INF_TBL         TYPE_ERR_INFO_TBL := TYPE_ERR_INFO_TBL();
  W_ERR_INF_RCD         TYPE_ERR_INFO_RCD := TYPE_ERR_INFO_RCD(NULL,NULL,NULL,NULL);
  vSchemaNm     TM_JOSU.HANYO_KOMOKU%TYPE := NULL; -- �X�L�[�}����
  PGM_ID        VARCHAR2(50) := 'NH010106B001_101.CREATE_DCF_SHISETSU';
  EXECUTE_SQL   VARCHAR2(32767) := NULL;

  BEGIN
    -- �J�n���O�o��
    ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'PL/SQL Start',PGM_ID || '�̏������J�n���܂��B',iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);
    -- �[�i�p�X�L�[�}�̎擾���s���B
    vSchemaNm := ULT_COMMON.GET_SCHEMA_NAME(ULT_COMMON.SYS_ENV_JOSU_DAI_CD, ULT_COMMON.NOHIN_SHEMA_JOSU_SHO_CD);

      IF iLayoutKind = ULT_COMMON.LAYOUT_SBT_CD_SHIN THEN
          -- �V���C�A�E�g

          IF iShimeKind = ULT_COMMON.SHIME_SBT_CD_HISHIME THEN
            --�V_�S��_DCF�{�݃e�[�u���̃f�[�^���N���A����B
            EXECUTE_SQL := 'TRUNCATE TABLE ' || vSchemaNm || '.' || 'TD_NA_DCF_SHI';
            EXECUTE IMMEDIATE EXECUTE_SQL;
            ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

           --�V_�S��_DCF�{�݃e�[�u���̃f�[�^��o�^����
           INSERT INTO TD_NA_DCF_SHI(
                  LAYOUT_KBN,
                  SHIREC_ID,
                  SHI_CD,
                  SHI_CD_YOBI,
                  MOD_KBN,
                  MENTE_YMD,
                  YOBI_1,
                  MIKAKUNIN_FLG,
                  DEL_YOTEI_RIYU,
                  AITSK_CD_SHIREC_ID,
                  AITSK_CD_SHI_CD,
                  AITSK_CD_SHI_CD_YOBI,
                  SEISHIKI_SHI_NM_KANJI,
                  SEISHIKI_SHI_NM_KANA,
                  RYKSK_SHI_NM_KANJI,
                  RYKSK_SHI_NM_KANA,
                  JUSHOFUMEI,
                  JUSHO_CD_KEN_CD,
                  JUSHO_CD_SHIKU_CD,
                  JUSHO_CD_OAZA_CD,
                  JUSHO_CD_AZA_CD,
                  ZIP,
                  JUSHO_KANJI,
                  JUSHO_KANA,
                  JUSHO_HYOJI_NO,
                  JUSHO_COUNT_KANJI_KEN,
                  JUSHO_COUNT_KANJI_SHIKU,
                  JUSHO_COUNT_KANJI_OAZA,
                  JUSHO_COUNT_KANJI_AZA,
                  JUSHO_COUNT_KANA_KEN,
                  JUSHO_COUNT_KANA_SHIKU,
                  JUSHO_COUNT_KANA_OAZA,
                  JUSHO_COUNT_KANA_AZA,
                  TEL_NASHI_FLG,
                  TEL,
                  KEIEITAI,
                  SHI_KBN,
                  DAIHYO_KJNREC_ID,
                  DAIHYO_KJN_CD,
                  DAIHYO_KJN_CD_YOBI,
                  DAIHYO_KANJI,
                  DAIHYO_KANA,
                  KAIGYO_YOTEI_KAIGYO_YOTEI_FLG,
                  KAIGYO_YOTEI_KAIGYO_YOTEI_YM,
                  KYUIN_KYUIN_FLG,
                  KYUIN_KYUIN_S_YM,
                  SNRYKMK_1,
                  SNRYKMK_2,
                  SNRYKMK_3,
                  SNRYKMK_4,
                  SNRYKMK_5,
                  SNRYKMK_6,
                  SNRYKMK_7,
                  SNRYKMK_8,
                  SNRYKMK_9,
                  SNRYKMK_10,
                  SNRYKMK_11,
                  SNRYKMK_12,
                  SNRYKMK_13,
                  SNRYKMK_14,
                  SNRYKMK_15,
                  SNRYKMK_16,
                  SNRYKMK_17,
                  SNRYKMK_18,
                  SNRYKMK_19,
                  SNRYKMK_20,
                  SNRYKMK_21,
                  SNRYKMK_22,
                  SNRYKMK_23,
                  SNRYKMK_24,
                  SNRYKMK_25,
                  SNRYKMK_26,
                  SNRYKMK_27,
                  SNRYKMK_28,
                  SNRYKMK_29,
                  SNRYKMK_30,
                  SNRYKMK_31,
                  SNRYKMK_32,
                  SNRYKMK_33,
                  SNRYKMK_34,
                  SNRYKMK_35,
                  SNRYKMK_36,
                  SNRYKMK_37,
                  SNRYKMK_38,
                  SNRYKMK_39,
                  SNRYKMK_40,
                  SNRYKMK_41,
                  SNRYKMK_42,
                  SNRYKMK_43,
                  SNRYKMK_44,
                  SNRYKMK_45,
                  SNRYKMK_46,
                  SNRYKMK_47,
                  SNRYKMK_48,
                  SNRYKMK_49,
                  SNRYKMK_50,
                  SNRYKMK_51,
                  SNRYKMK_52,
                  SNRYKMK_53,
                  SNRYKMK_54,
                  SNRYKMK_55,
                  SNRYKMK_56,
                  SNRYKMK_57,
                  SNRYKMK_58,
                  SNRYKMK_59,
                  SNRYKMK_60,
                  BYOIN_SBT,
                  SAISHINSA_KBN,
                  KANREN_DAIGAKU_OYA_SHIREC_ID,
                  KANREN_DAIGAKU_OYA_SHI_CD,
                  KANREN_DAIGAKU_OYA_SHI_CD_YOBI,
                  BYOTO_HEISA_FLG,
                  BED_SU_TEIIN,
                  KYOKA_BED_MENTE_HIZUKE,
                  KYOKA_BED_SU_GOKEI,
                  KYOKA_BED_SU_SEISHIN,
                  KYOKA_BED_SU_KEKKAKU,
                  KYOKA_BED_SU_KANSEN,
                  KYOKA_BED_SU_SONOTA,
                  KYOKA_BED_SU_IPPAN_BED,
                  KYOKA_BED_SU_RYOYO_BED,
                  KENSAKOMOKU_BISEIBUTSU,
                  KENSAKOMOKU_KESSEI,
                  KENSAKOMOKU_KETSUEKI,
                  KENSAKOMOKU_BYORI,
                  KENSAKOMOKU_KISEICHU,
                  KENSAKOMOKU_SEIKA,
                  KENSAKOMOKU_RI,
                  TOKUI_CD_REC_ID,
                  TOKUI_CD_SHI_CD,
                  TOKUI_CD_YOBI,
                  YOBI_2,
                  YOBI_3,
                  YOBI_4,
                  TENSO_YMD,
                  TRK_OPE_CD,
                  TRK_DATE,
                  TRK_PGM_ID,
                  UPD_OPE_CD,
                  UPD_DATE,
                  UPD_PGM_ID)
        SELECT
            '101',
                TTS.REC_ID,
                TTS.SHI_CD,
                NULL,
                NULL,
                TTS.UPD_EIGY_YMD,
                NULL,
                TTS.MIKAKUNIN_FLG,
                TTS.DEL_YOTEI_RIYU_CD,
                TTS.CHOFUKU_AITSK_REC_ID,
                TTS.CHOFUKU_AITSK_SHI_CD,
                NULL,
                TTS.SEISHIKI_SHI_NM,
                TTS.SEISHIKI_SHI_NM_KANA,
                TTS.SHI_RN,
                TTS.SHI_RN_KANA,
                TTS.JUSHOFUMEI_CD,
                TTS.KEN_CD,
                TTS.SHIKU_CD,
                TTS.OAZA_CD,
                TTS.AZA_CD,
                NVL2(TTS.ZIP,SUBSTR(TTS.ZIP,1,3)||'-'||SUBSTR(TTS.ZIP,4),NULL) AS ZIP,
                TTS.JUSHO_KANJI_RENKETSU,
                TTS.JUSHO_KANA_RENKETSU,
                TTS.JUSHO_HYOJI_NO,
                TTS.KEN_NM_KANJI_MOJI_SU,
                TTS.SHIKU_NM_KANJI_MOJI_SU,
                TTS.OAZA_NM_KANJI_MOJI_SU,
                TTS.AZA_NM_KANJI_MOJI_SU,
                TTS.KEN_NM_KANA_MOJI_SU,
                TTS.SHIKU_NM_KANA_MOJI_SU,
                TTS.OAZA_NM_KANA_MOJI_SU,
                TTS.AZA_NM_KANA_MOJI_SU,
                TTS.TEL_NASHI_FLG,
                TTS.TEL,
                TTS.KEIEITAI_CD,
                TTS.SHI_KBN_CD,
                TTS.DAIHYO_REC_ID,
                TTS.DAIHYO_KJN_CD,
                NULL,
                TTK.KJN_NM,
                TTK.KJN_NM_KANA,
                TTS.KAIGYO_YOTEI_FLG,
                TTS.KAIGYO_YOTEI_YM,
                TTS.KYUIN_FLG,
                TTS.KYUIN_S_YM,
                TTS.SNRYKMK_CD_01,
                TTS.SNRYKMK_CD_02,
                TTS.SNRYKMK_CD_03,
                TTS.SNRYKMK_CD_04,
                TTS.SNRYKMK_CD_05,
                TTS.SNRYKMK_CD_06,
                TTS.SNRYKMK_CD_07,
                TTS.SNRYKMK_CD_08,
                TTS.SNRYKMK_CD_09,
                TTS.SNRYKMK_CD_10,
                TTS.SNRYKMK_CD_11,
                TTS.SNRYKMK_CD_12,
                TTS.SNRYKMK_CD_13,
                TTS.SNRYKMK_CD_14,
                TTS.SNRYKMK_CD_15,
                TTS.SNRYKMK_CD_16,
                TTS.SNRYKMK_CD_17,
                TTS.SNRYKMK_CD_18,
                TTS.SNRYKMK_CD_19,
                TTS.SNRYKMK_CD_20,
                TTS.SNRYKMK_CD_21,
                TTS.SNRYKMK_CD_22,
                TTS.SNRYKMK_CD_23,
                TTS.SNRYKMK_CD_24,
                TTS.SNRYKMK_CD_25,
                TTS.SNRYKMK_CD_26,
                TTS.SNRYKMK_CD_27,
                TTS.SNRYKMK_CD_28,
                TTS.SNRYKMK_CD_29,
                TTS.SNRYKMK_CD_30,
                TTS.SNRYKMK_CD_31,
                TTS.SNRYKMK_CD_32,
                TTS.SNRYKMK_CD_33,
                TTS.SNRYKMK_CD_34,
                TTS.SNRYKMK_CD_35,
                TTS.SNRYKMK_CD_36,
                TTS.SNRYKMK_CD_37,
                TTS.SNRYKMK_CD_38,
                TTS.SNRYKMK_CD_39,
                TTS.SNRYKMK_CD_40,
                TTS.SNRYKMK_CD_41,
                TTS.SNRYKMK_CD_42,
                TTS.SNRYKMK_CD_43,
                TTS.SNRYKMK_CD_44,
                TTS.SNRYKMK_CD_45,
                TTS.SNRYKMK_CD_46,
                TTS.SNRYKMK_CD_47,
                TTS.SNRYKMK_CD_48,
                TTS.SNRYKMK_CD_49,
                TTS.SNRYKMK_CD_50,
                TTS.SNRYKMK_CD_51,
                TTS.SNRYKMK_CD_52,
                TTS.SNRYKMK_CD_53,
                TTS.SNRYKMK_CD_54,
                TTS.SNRYKMK_CD_55,
                TTS.SNRYKMK_CD_56,
                TTS.SNRYKMK_CD_57,
                TTS.SNRYKMK_CD_58,
                TTS.SNRYKMK_CD_59,
                TTS.SNRYKMK_CD_60,
                TTS.BYOIN_SBT_CD,
                TTS.SAISHINSA_KBN_CD,
                TTS.KANREN_DAIGAKU_OYA_REC_ID,
                TTS.KANREN_DAIGAKU_OYA_SHI_CD,
                NULL,
                TTS.BYOTO_HEISA_KBN,
                TTS.SHI_BED_SU,
                TTS.BED_SU_KKNN_EIGY_YMD,
                TTS.KYOKA_BED_SU_GOKEI,
                TTS.KYOKA_BED_SU_SEISHIN,
                TTS.KYOKA_BED_SU_KEKKAKU,
                TTS.KYOKA_BED_SU_KANSEN,
                TTS.KYOKA_BED_SU_SONOTA,
                TTS.KYOKA_BED_SU_IPPAN,
                TTS.KYOKA_BED_SU_RYOYO,
                TTS.KENSAKOMOKU_BISEIBUTSU_FLG,
                TTS.KENSAKOMOKU_KESSEI_FLG,
                TTS.KENSAKOMOKU_KETSUEKI_FLG,
                TTS.KENSAKOMOKU_BYORI_FLG,
                TTS.KENSAKOMOKU_KISEICHU_FLG,
                TTS.KENSAKOMOKU_SEIKA_FLG,
                TTS.KENSAKOMOKU_RI_FLG,
                TTS.IMUSHITSU_REC_ID,
                TTS.IMUSHITSU_SHI_CD,
                NULL,
                NULL,
                NULL,
                NULL,
                iTensoYMD,
                iOPE_CD,
                iDATE,
                iPGM_ID,
                iOPE_CD,
                iDATE,
                iPGM_ID
          FROM TT_TIKY_SHI TTS
      LEFT OUTER JOIN TT_TIKY_KJN TTK
        ON  TTS.DAIHYO_REC_ID = TTK.REC_ID
        AND TTS.DAIHYO_KJN_CD = TTK.KJN_CD
        AND TTK.DEL_FLG IS NULL
      WHERE TTS.REC_ID = '00'
      AND TTS.DEL_FLG IS NULL ;

         -- LOG�̓o�^
       EXECUTE_SQL := ' INSERT INTO TD_NA_DCF_SHI(                                               ' ||
            '             LAYOUT_KBN,                                                  ' ||
            '             SHIREC_ID,                                                   ' ||
            '             SHI_CD,                                                      ' ||
            '             SHI_CD_YOBI,                                                 ' ||
            '             MOD_KBN,                                                     ' ||
            '             MENTE_YMD,                                                   ' ||
            '             YOBI_1,                                                      ' ||
            '             MIKAKUNIN_FLG,                                               ' ||
            '             DEL_YOTEI_RIYU,                                              ' ||
            '             AITSK_CD_SHIREC_ID,                                          ' ||
            '             AITSK_CD_SHI_CD,                                             ' ||
            '             AITSK_CD_SHI_CD_YOBI,                                        ' ||
            '             SEISHIKI_SHI_NM_KANJI,                                       ' ||
            '             SEISHIKI_SHI_NM_KANA,                                        ' ||
            '             RYKSK_SHI_NM_KANJI,                                          ' ||
            '             RYKSK_SHI_NM_KANA,                                           ' ||
            '             JUSHOFUMEI,                                                  ' ||
            '             JUSHO_CD_KEN_CD,                                             ' ||
            '             JUSHO_CD_SHIKU_CD,                                           ' ||
            '             JUSHO_CD_OAZA_CD,                                            ' ||
            '             JUSHO_CD_AZA_CD,                                             ' ||
            '             ZIP,                                                         ' ||
            '             JUSHO_KANJI,                                                 ' ||
            '             JUSHO_KANA,                                                  ' ||
            '             JUSHO_HYOJI_NO,                                              ' ||
            '             JUSHO_COUNT_KANJI_KEN,                                       ' ||
            '             JUSHO_COUNT_KANJI_SHIKU,                                     ' ||
            '             JUSHO_COUNT_KANJI_OAZA,                                      ' ||
            '             JUSHO_COUNT_KANJI_AZA,                                       ' ||
            '             JUSHO_COUNT_KANA_KEN,                                        ' ||
            '             JUSHO_COUNT_KANA_SHIKU,                                      ' ||
            '             JUSHO_COUNT_KANA_OAZA,                                       ' ||
            '             JUSHO_COUNT_KANA_AZA,                                        ' ||
            '             TEL_NASHI_FLG,                                               ' ||
            '             TEL,                                                         ' ||
            '             KEIEITAI,                                                    ' ||
            '             SHI_KBN,                                                     ' ||
            '             DAIHYO_KJNREC_ID,                                            ' ||
            '             DAIHYO_KJN_CD,                                               ' ||
            '             DAIHYO_KJN_CD_YOBI,                                          ' ||
            '             DAIHYO_KANJI,                                                ' ||
            '             DAIHYO_KANA,                                                 ' ||
            '             KAIGYO_YOTEI_KAIGYO_YOTEI_FLG,                               ' ||
            '             KAIGYO_YOTEI_KAIGYO_YOTEI_YM,                                ' ||
            '             KYUIN_KYUIN_FLG,                                             ' ||
            '             KYUIN_KYUIN_S_YM,                                            ' ||
            '             SNRYKMK_1,                                                   ' ||
            '             SNRYKMK_2,                                                   ' ||
            '             SNRYKMK_3,                                                   ' ||
            '             SNRYKMK_4,                                                   ' ||
            '             SNRYKMK_5,                                                   ' ||
            '             SNRYKMK_6,                                                   ' ||
            '             SNRYKMK_7,                                                   ' ||
            '             SNRYKMK_8,                                                   ' ||
            '             SNRYKMK_9,                                                   ' ||
            '             SNRYKMK_10,                                                  ' ||
            '             SNRYKMK_11,                                                  ' ||
            '             SNRYKMK_12,                                                  ' ||
            '             SNRYKMK_13,                                                  ' ||
            '             SNRYKMK_14,                                                  ' ||
            '             SNRYKMK_15,                                                  ' ||
            '             SNRYKMK_16,                                                  ' ||
            '             SNRYKMK_17,                                                  ' ||
            '             SNRYKMK_18,                                                  ' ||
            '             SNRYKMK_19,                                                  ' ||
            '             SNRYKMK_20,                                                  ' ||
            '             SNRYKMK_21,                                                  ' ||
            '             SNRYKMK_22,                                                  ' ||
            '             SNRYKMK_23,                                                  ' ||
            '             SNRYKMK_24,                                                  ' ||
            '             SNRYKMK_25,                                                  ' ||
            '             SNRYKMK_26,                                                  ' ||
            '             SNRYKMK_27,                                                  ' ||
            '             SNRYKMK_28,                                                  ' ||
            '             SNRYKMK_29,                                                  ' ||
            '             SNRYKMK_30,                                                  ' ||
            '             SNRYKMK_31,                                                  ' ||
            '             SNRYKMK_32,                                                  ' ||
            '             SNRYKMK_33,                                                  ' ||
            '             SNRYKMK_34,                                                  ' ||
            '             SNRYKMK_35,                                                  ' ||
            '             SNRYKMK_36,                                                  ' ||
            '             SNRYKMK_37,                                                  ' ||
            '             SNRYKMK_38,                                                  ' ||
            '             SNRYKMK_39,                                                  ' ||
            '             SNRYKMK_40,                                                  ' ||
            '             SNRYKMK_41,                                                  ' ||
            '             SNRYKMK_42,                                                  ' ||
            '             SNRYKMK_43,                                                  ' ||
            '             SNRYKMK_44,                                                  ' ||
            '             SNRYKMK_45,                                                  ' ||
            '             SNRYKMK_46,                                                  ' ||
            '             SNRYKMK_47,                                                  ' ||
            '             SNRYKMK_48,                                                  ' ||
            '             SNRYKMK_49,                                                  ' ||
            '             SNRYKMK_50,                                                  ' ||
            '             SNRYKMK_51,                                                  ' ||
            '             SNRYKMK_52,                                                  ' ||
            '             SNRYKMK_53,                                                  ' ||
            '             SNRYKMK_54,                                                  ' ||
            '             SNRYKMK_55,                                                  ' ||
            '             SNRYKMK_56,                                                  ' ||
            '             SNRYKMK_57,                                                  ' ||
            '             SNRYKMK_58,                                                  ' ||
            '             SNRYKMK_59,                                                  ' ||
            '             SNRYKMK_60,                                                  ' ||
            '             BYOIN_SBT,                                                   ' ||
            '             SAISHINSA_KBN,                                               ' ||
            '             KANREN_DAIGAKU_OYA_SHIREC_ID,                                ' ||
            '             KANREN_DAIGAKU_OYA_SHI_CD,                                   ' ||
            '             KANREN_DAIGAKU_OYA_SHI_CD_YOBI,                              ' ||
            '             BYOTO_HEISA_FLG,                                             ' ||
            '             BED_SU_TEIIN,                                                ' ||
            '             KYOKA_BED_MENTE_HIZUKE,                                      ' ||
            '             KYOKA_BED_SU_GOKEI,                                          ' ||
            '             KYOKA_BED_SU_SEISHIN,                                        ' ||
            '             KYOKA_BED_SU_KEKKAKU,                                        ' ||
            '             KYOKA_BED_SU_KANSEN,                                         ' ||
            '             KYOKA_BED_SU_SONOTA,                                         ' ||
            '             KYOKA_BED_SU_IPPAN_BED,                                      ' ||
            '             KYOKA_BED_SU_RYOYO_BED,                                      ' ||
            '             KENSAKOMOKU_BISEIBUTSU,                                      ' ||
            '             KENSAKOMOKU_KESSEI,                                          ' ||
            '             KENSAKOMOKU_KETSUEKI,                                        ' ||
            '             KENSAKOMOKU_BYORI,                                           ' ||
            '             KENSAKOMOKU_KISEICHU,                                        ' ||
            '             KENSAKOMOKU_SEIKA,                                           ' ||
            '             KENSAKOMOKU_RI,                                              ' ||
            '             TOKUI_CD_REC_ID,                                             ' ||
            '             TOKUI_CD_SHI_CD,                                             ' ||
            '             TOKUI_CD_YOBI,                                               ' ||
            '             YOBI_2,                                                      ' ||
            '             YOBI_3,                                                      ' ||
            '             YOBI_4,                                                      ' ||
            '             TENSO_YMD,                                                   ' ||
            '             TRK_OPE_CD,                                                  ' ||
            '             TRK_DATE,                                                    ' ||
            '             TRK_PGM_ID,                                                  ' ||
            '             UPD_OPE_CD,                                                  ' ||
            '             UPD_DATE,                                                    ' ||
            '             UPD_PGM_ID) ||                                              ' ||
            '         SELECT                                                           ' ||
            '         101,                                                             ' ||
            '         TTS.REC_ID,                                                      ' ||
            '         TTS.SHI_CD,                                                      ' ||
            '         NULL,                                                            ' ||
            '         NULL,                                                            ' ||
            '         TTS.UPD_EIGY_YMD,                                                ' ||
            '         NULL,                                                            ' ||
            '         TTS.MIKAKUNIN_FLG,                                               ' ||
            '         TTS.DEL_YOTEI_RIYU_CD,                                           ' ||
            '         TTS.CHOFUKU_AITSK_REC_ID,                                        ' ||
            '         TTS.CHOFUKU_AITSK_SHI_CD,                                        ' ||
            '         NULL,                                                            ' ||
            '         TTS.SEISHIKI_SHI_NM,                                             ' ||
            '         TTS.SEISHIKI_SHI_NM_KANA,                                        ' ||
            '         TTS.SHI_RN,                                                      ' ||
            '         TTS.SHI_RN_KANA,                                                 ' ||
            '         TTS.JUSHOFUMEI_CD,                                               ' ||
            '         TTS.KEN_CD,                                                      ' ||
            '         TTS.SHIKU_CD,                                                    ' ||
            '         TTS.OAZA_CD,                                                     ' ||
            '         TTS.AZA_CD,                                                      ' ||
            '         NVL2(TTS.ZIP,SUBSTR(TTS.ZIP,1,3)||-||SUBSTR(TTS.ZIP,4),NULL),    ' ||
            '         TTS.JUSHO_KANJI_RENKETSU,                                        ' ||
            '         TTS.JUSHO_KANA_RENKETSU,                                         ' ||
            '         TTS.JUSHO_HYOJI_NO,                                              ' ||
            '         TTS.KEN_NM_KANJI_MOJI_SU,                                        ' ||
            '         TTS.SHIKU_NM_KANJI_MOJI_SU,                                      ' ||
            '         TTS.OAZA_NM_KANJI_MOJI_SU,                                       ' ||
            '         TTS.AZA_NM_KANJI_MOJI_SU,                                        ' ||
            '         TTS.KEN_NM_KANA_MOJI_SU,                                         ' ||
            '         TTS.SHIKU_NM_KANA_MOJI_SU,                                       ' ||
            '         TTS.OAZA_NM_KANA_MOJI_SU,                                        ' ||
            '         TTS.AZA_NM_KANA_MOJI_SU,                                         ' ||
            '         TTS.TEL_NASHI_FLG,                                               ' ||
            '         TTS.TEL,                                                         ' ||
            '         TTS.KEIEITAI_CD,                                                 ' ||
            '         TTS.SHI_KBN_CD,                                                  ' ||
            '         TTS.DAIHYO_REC_ID,                                               ' ||
            '         TTS.DAIHYO_KJN_CD,                                               ' ||
            '         NULL,                                                            ' ||
            '         TTK.KJN_NM,                                                      ' ||
            '         TTK.KJN_NM_KANA,                                                 ' ||
            '         TTS.KAIGYO_YOTEI_FLG,                                            ' ||
            '         TTS.KAIGYO_YOTEI_YM,                                             ' ||
            '         TTS.KYUIN_FLG,                                                   ' ||
            '         TTS.KYUIN_S_YM,                                                  ' ||
            '         TTS.SNRYKMK_CD_01,                                               ' ||
            '         TTS.SNRYKMK_CD_02,                                               ' ||
            '         TTS.SNRYKMK_CD_03,                                               ' ||
            '         TTS.SNRYKMK_CD_04,                                               ' ||
            '         TTS.SNRYKMK_CD_05,                                               ' ||
            '         TTS.SNRYKMK_CD_06,                                               ' ||
            '         TTS.SNRYKMK_CD_07,                                               ' ||
            '         TTS.SNRYKMK_CD_08,                                               ' ||
            '         TTS.SNRYKMK_CD_09,                                               ' ||
            '         TTS.SNRYKMK_CD_10,                                               ' ||
            '         TTS.SNRYKMK_CD_11,                                               ' ||
            '         TTS.SNRYKMK_CD_12,                                               ' ||
            '         TTS.SNRYKMK_CD_13,                                               ' ||
            '         TTS.SNRYKMK_CD_14,                                               ' ||
            '         TTS.SNRYKMK_CD_15,                                               ' ||
            '         TTS.SNRYKMK_CD_16,                                               ' ||
            '         TTS.SNRYKMK_CD_17,                                               ' ||
            '         TTS.SNRYKMK_CD_18,                                               ' ||
            '         TTS.SNRYKMK_CD_19,                                               ' ||
            '         TTS.SNRYKMK_CD_20,                                               ' ||
            '         TTS.SNRYKMK_CD_21,                                               ' ||
            '         TTS.SNRYKMK_CD_22,                                               ' ||
            '         TTS.SNRYKMK_CD_23,                                               ' ||
            '         TTS.SNRYKMK_CD_24,                                               ' ||
            '         TTS.SNRYKMK_CD_25,                                               ' ||
            '         TTS.SNRYKMK_CD_26,                                               ' ||
            '         TTS.SNRYKMK_CD_27,                                               ' ||
            '         TTS.SNRYKMK_CD_28,                                               ' ||
            '         TTS.SNRYKMK_CD_29,                                               ' ||
            '         TTS.SNRYKMK_CD_30,                                               ' ||
            '         TTS.SNRYKMK_CD_31,                                               ' ||
            '         TTS.SNRYKMK_CD_32,                                               ' ||
            '         TTS.SNRYKMK_CD_33,                                               ' ||
            '         TTS.SNRYKMK_CD_34,                                               ' ||
            '         TTS.SNRYKMK_CD_35,                                               ' ||
            '         TTS.SNRYKMK_CD_36,                                               ' ||
            '         TTS.SNRYKMK_CD_37,                                               ' ||
            '         TTS.SNRYKMK_CD_38,                                               ' ||
            '         TTS.SNRYKMK_CD_39,                                               ' ||
            '         TTS.SNRYKMK_CD_40,                                               ' ||
            '         TTS.SNRYKMK_CD_41,                                               ' ||
            '         TTS.SNRYKMK_CD_42,                                               ' ||
            '         TTS.SNRYKMK_CD_43,                                               ' ||
            '         TTS.SNRYKMK_CD_44,                                               ' ||
            '         TTS.SNRYKMK_CD_45,                                               ' ||
            '         TTS.SNRYKMK_CD_46,                                               ' ||
            '         TTS.SNRYKMK_CD_47,                                               ' ||
            '         TTS.SNRYKMK_CD_48,                                               ' ||
            '         TTS.SNRYKMK_CD_49,                                               ' ||
            '         TTS.SNRYKMK_CD_50,                                               ' ||
            '         TTS.SNRYKMK_CD_51,                                               ' ||
            '         TTS.SNRYKMK_CD_52,                                               ' ||
            '         TTS.SNRYKMK_CD_53,                                               ' ||
            '         TTS.SNRYKMK_CD_54,                                               ' ||
            '         TTS.SNRYKMK_CD_55,                                               ' ||
            '         TTS.SNRYKMK_CD_56,                                               ' ||
            '         TTS.SNRYKMK_CD_57,                                               ' ||
            '         TTS.SNRYKMK_CD_58,                                               ' ||
            '         TTS.SNRYKMK_CD_59,                                               ' ||
            '         TTS.SNRYKMK_CD_60,                                               ' ||
            '         TTS.BYOIN_SBT_CD,                                                ' ||
            '         TTS.SAISHINSA_KBN_CD,                                            ' ||
            '         TTS.KANREN_DAIGAKU_OYA_REC_ID,                                   ' ||
            '         TTS.KANREN_DAIGAKU_OYA_SHI_CD,                                   ' ||
            '         NULL,                                                            ' ||
            '         TTS.BYOTO_HEISA_KBN,                                             ' ||
            '         TTS.SHI_BED_SU,                                                  ' ||
            '         TTS.BED_SU_KKNN_EIGY_YMD,                                        ' ||
            '         TTS.KYOKA_BED_SU_GOKEI,                                          ' ||
            '         TTS.KYOKA_BED_SU_SEISHIN,                                        ' ||
            '         TTS.KYOKA_BED_SU_KEKKAKU,                                        ' ||
            '         TTS.KYOKA_BED_SU_KANSEN,                                         ' ||
            '         TTS.KYOKA_BED_SU_SONOTA,                                         ' ||
            '         TTS.KYOKA_BED_SU_IPPAN,                                          ' ||
            '         TTS.KYOKA_BED_SU_RYOYO,                                          ' ||
            '         TTS.KENSAKOMOKU_BISEIBUTSU_FLG,                                  ' ||
            '         TTS.KENSAKOMOKU_KESSEI_FLG,                                      ' ||
            '         TTS.KENSAKOMOKU_KETSUEKI_FLG,                                    ' ||
            '         TTS.KENSAKOMOKU_BYORI_FLG,                                       ' ||
            '         TTS.KENSAKOMOKU_KISEICHU_FLG,                                    ' ||
            '         TTS.KENSAKOMOKU_SEIKA_FLG,                                       ' ||
            '         TTS.KENSAKOMOKU_RI_FLG,                                          ' ||
            '         TTS.IMUSHITSU_REC_ID,                                            ' ||
            '         TTS.IMUSHITSU_SHI_CD,                                            ' ||
            '         NULL,                                                            ' ||
            '         NULL,                                                            ' ||
            '         NULL,                                                            ' ||
            '         NULL,                                                            ' ||
                     iTensoYMD || ',' ||
                     iOPE_CD || ',' ||
                     iDATE || ',' ||
                     iPGM_ID || ',' ||
                     iOPE_CD || ',' ||
                   iDATE || ',' ||
                     iPGM_ID                                                             ||
            '     FROM TT_TIKY_SHI TTS                                                 ' ||
            '   LEFT OUTER JOIN TT_TIKY_KJN TTK                                        ' ||
            '     ON  TTS.DAIHYO_REC_ID = TTK.REC_ID                                 ' ||
            '     AND TTS.DAIHYO_KJN_CD = TTK.KJN_CD                                 ' ||
            '     AND TTK.DEL_FLG IS NULL                                            ' ||
            '   WHERE TTS.REC_ID = ' || '''00'''                                           ||
            '   AND TTS.DEL_FLG IS NULL                                                ' ;
            ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);
          END IF;

      ELSIF iLayoutKind = ULT_COMMON.LAYOUT_SBT_CD_ZANTEI THEN
          -- �b�背�C�A�E�g
          IF iShimeKind = ULT_COMMON.SHIME_SBT_CD_HISHIME THEN

            --�b��_�S��_DCF�{�݃e�[�u���̃f�[�^���N���A����B
            EXECUTE_SQL := 'TRUNCATE TABLE ' || vSchemaNm || '.' || 'TD_PA_DCF_SHI';
            EXECUTE IMMEDIATE EXECUTE_SQL;
            ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);
            --�b��_�S��_���{�㖱���e�[�u���̃f�[�^���N���A����B
            EXECUTE_SQL := 'TRUNCATE TABLE ' || vSchemaNm || '.' || 'TD_PA_TOKUITBL';
            EXECUTE IMMEDIATE EXECUTE_SQL;
            ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

             --�b��_�S��_DCF�{�݂�o�^����
              INSERT INTO TD_PA_DCF_SHI(
                        SHIREC_ID,
                        SHI_CD,
                        SEISHIKI_SHI_NM_KANA,
                        RYKSK_SHI_NM_KANA,
                        SEISHIKI_SHI_NM_KANJI,
                        RYKSK_SHI_NM_KANJI,
                        KANREN_DAIGAKU_OYA_SHIREC_ID,
                        KANREN_DAIGAKU_OYA_SHI_CD,
                        JUSHO_KANA,
                        JUSHO_KANJI,
                        JUSHO_CD_KEN_CD,
                        JUSHO_CD_SHIKU_CD,
                        JUSHO_CD_OAZA_CD,
                        JUSHO_CD_AZA_CD,
                        ZIP,
                        JUSHO_HYOJI_NO,
                        JUSHO_COUNT_KANA_KEN,
                        JUSHO_COUNT_KANA_SHIKU,
                        JUSHO_COUNT_KANA_OAZA,
                        JUSHO_COUNT_KANJI_KEN,
                        JUSHO_COUNT_KANJI_SHIKU,
                        JUSHO_COUNT_KANJI_OAZA,
                        JUSHO_COUNT_KANA_AZA,
                        JUSHO_COUNT_KANJI_AZA,
                        SHI_TEL,
                        BED_SU_TEIIN,
                        KEIEITAI,
                        SHI_KBN,
                        KENSAKOMOKU_BISEIBUTSU,
                        KENSAKOMOKU_KESSEI,
                        KENSAKOMOKU_KETSUEKI,
                        KENSAKOMOKU_BYORI,
                        KENSAKOMOKU_KISEICHU,
                        KENSAKOMOKU_SEIKA,
                        KENSAKOMOKU_RI,
                        STATUS_JUSHOFUMEI,
                        STATUS_KYUIN_FLG,
                        STATUS_DEL_YOTEI_RIYU,
                        STATUS_KAIGYO_YOTEI_FLG,
                        STATUS_BYOTO_HEISA_FLG,
                        STATUS_TEL_NASHI_FLG,
                        STATUS_MIKAKUNIN_FLG,
                        STATUS_SAISHINSA_KBN,
                        KYOKA_BED_MENTE_HIZUKE_Y,
                        KYOKA_BED_MENTE_HIZUKE_M,
                        KYOKA_BED_MENTE_HIZUKE_D,
                        KYOKA_BED_SU_SONOTA,
                        KYOKA_BED_SU_SEISHIN,
                        KYOKA_BED_SU_KEKKAKU,
                        KYOKA_BED_SU_KANSEN,
                        KYOKA_BED_SU_GOKEI,
                        BYOIN_SBT,
                        SHI_DAIHYO_KJNREC_ID,
                        SHI_DAIHYO_KJN_CD,
                        SHI_DAIHYO_KANA,
                        SHI_DAIHYO_KANJI,
                        AITSK_CD_SHIREC_ID,
                        AITSK_CD_SHI_CD,
                        KYUIN_S_KAIGYO_YOTEI_Y,
                        KYUIN_S_KAIGYO_YOTEI_M,
                        SHIN_BED_KBN_IPPAN_BED,
                        SHIN_BED_KBN_RYOYO_BED,
                        SNRYKMK_1,
                        SNRYKMK_2,
                        SNRYKMK_3,
                        SNRYKMK_4,
                        SNRYKMK_5,
                        SNRYKMK_6,
                        SNRYKMK_7,
                        SNRYKMK_8,
                        SNRYKMK_9,
                        SNRYKMK_10,
                        SNRYKMK_11,
                        SNRYKMK_12,
                        SNRYKMK_13,
                        SNRYKMK_14,
                        SNRYKMK_15,
                        SNRYKMK_16,
                        SNRYKMK_17,
                        SNRYKMK_18,
                        SNRYKMK_19,
                        SNRYKMK_20,
                        SNRYKMK_21,
                        SNRYKMK_22,
                        SNRYKMK_23,
                        SNRYKMK_24,
                        SNRYKMK_25,
                        SNRYKMK_26,
                        SNRYKMK_27,
                        SNRYKMK_28,
                        SNRYKMK_29,
                        SNRYKMK_30,
                        SNRYKMK_31,
                        SNRYKMK_32,
                        SNRYKMK_33,
                        SNRYKMK_34,
                        SNRYKMK_35,
                        SNRYKMK_36,
                        SNRYKMK_37,
                        SNRYKMK_38,
                        SNRYKMK_39,
                        SNRYKMK_40,
                        SNRYKMK_41,
                        SNRYKMK_42,
                        SNRYKMK_43,
                        SNRYKMK_44,
                        SNRYKMK_45,
                        SNRYKMK_46,
                        SNRYKMK_47,
                        SNRYKMK_48,
                        SNRYKMK_49,
                        SNRYKMK_50,
                        SNRYKMK_51,
                        SNRYKMK_52,
                        SNRYKMK_53,
                        SNRYKMK_54,
                        SNRYKMK_55,
                        SNRYKMK_56,
                        SNRYKMK_57,
                        SNRYKMK_58,
                        SNRYKMK_59,
                        SNRYKMK_60,
                        SHIN_SEISHIKI_SHI_NM_KANJI,
                        SHIN_SEISHIKI_SHI_NM_KANA,
                        TENSO_Y,
                        TENSO_M,
                        TENSO_D,
                        MOD_SHORI_HIZUKE_Y,
                        MOD_SHORI_HIZUKE_M,
                        MOD_SHORI_HIZUKE_D,
                        TRK_OPE_CD,
                        TRK_DATE,
                        TRK_PGM_ID,
                        UPD_OPE_CD,
                        UPD_DATE,
                        UPD_PGM_ID
                      )
              SELECT
                '00',
                TTS.SHI_CD,
                TTS.SEISHIKI_SHI_NM_KANA40,
                TTS.SHI_RN_KANA,
                TTS.SEISHIKI_SHI_NM30,
                TTS.SHI_RN,
                TTS.KANREN_DAIGAKU_OYA_REC_ID,
                TTS.KANREN_DAIGAKU_OYA_SHI_CD,
                TTS.JUSHO_KANA_RENKETSU,
                TTS.JUSHO_KANJI_RENKETSU,
                TTS.KEN_CD,
                TTS.SHIKU_CD,
                TTS.OAZA_CD,
                TTS.AZA_CD,
                NVL2(TTS.ZIP,SUBSTR(TTS.ZIP,1,3)||'-'||SUBSTR(TTS.ZIP,4),NULL) AS ZIP,
                TTS.JUSHO_HYOJI_NO,
                TO_CHAR(TTS.KEN_NM_KANA_MOJI_SU,'FM09') AS KEN_NM_KANA_MOJI_SU,
                TO_CHAR(TTS.SHIKU_NM_KANA_MOJI_SU,'FM09') AS SHIKU_NM_KANA_MOJI_SU,
                TO_CHAR(TTS.OAZA_NM_KANA_MOJI_SU,'FM09') AS OAZA_NM_KANA_MOJI_SU,
                TO_CHAR(TTS.KEN_NM_KANJI_MOJI_SU,'FM09') AS KEN_NM_KANJI_MOJI_SU,
                TO_CHAR(TTS.SHIKU_NM_KANJI_MOJI_SU,'FM09') AS SHIKU_NM_KANJI_MOJI_SU,
                TO_CHAR(TTS.OAZA_NM_KANJI_MOJI_SU,'FM09') AS OAZA_NM_KANJI_MOJI_SU,
                TO_CHAR(TTS.AZA_NM_KANA_MOJI_SU,'FM09') AS AZA_NM_KANA_MOJI_SU,
                TO_CHAR(TTS.AZA_NM_KANJI_MOJI_SU,'FM09') AS AZA_NM_KANJI_MOJI_SU,
                TTS.TEL,
                TO_CHAR(TTS.SHI_BED_SU,'FM0009') AS SHI_BED_SU,
                TTS.KEIEITAI_CD,
                TTS.SHI_KBN_CD,
                TTS.KENSAKOMOKU_BISEIBUTSU_FLG,
                TTS.KENSAKOMOKU_KESSEI_FLG,
                TTS.KENSAKOMOKU_KETSUEKI_FLG,
                TTS.KENSAKOMOKU_BYORI_FLG,
                TTS.KENSAKOMOKU_KISEICHU_FLG,
                TTS.KENSAKOMOKU_SEIKA_FLG,
                TTS.KENSAKOMOKU_RI_FLG,
                TTS.JUSHOFUMEI_CD,
                TTS.KYUIN_FLG,
                TTS.DEL_YOTEI_RIYU_CD,
                TTS.KAIGYO_YOTEI_FLG,
                TTS.BYOTO_HEISA_KBN,
                TTS.TEL_NASHI_FLG,
                TTS.MIKAKUNIN_FLG,
                TTS.SAISHINSA_KBN_CD,
                SUBSTR(TTS.BED_SU_KKNN_EIGY_YMD,1,4) AS KYOKA_BED_MENTE_HIZUKE_Y,
                SUBSTR(TTS.BED_SU_KKNN_EIGY_YMD,5,2) AS KYOKA_BED_MENTE_HIZUKE_M,
                SUBSTR(TTS.BED_SU_KKNN_EIGY_YMD,7,2) AS KYOKA_BED_MENTE_HIZUKE_D,
                TO_CHAR(TTS.KYOKA_BED_SU_SONOTA,'FM0009') AS KYOKA_BED_SU_SONOTA,
                TO_CHAR(TTS.KYOKA_BED_SU_SEISHIN,'FM0009') AS KYOKA_BED_SU_SEISHIN,
                TO_CHAR(TTS.KYOKA_BED_SU_KEKKAKU,'FM0009') AS KYOKA_BED_SU_KEKKAKU,
                TO_CHAR(TTS.KYOKA_BED_SU_KANSEN,'FM0009') AS KYOKA_BED_SU_KANSEN,
                TO_CHAR(TTS.KYOKA_BED_SU_GOKEI,'FM0009') AS KYOKA_BED_SU_GOKEI,
                TTS.BYOIN_SBT_CD,
                TTS.DAIHYO_REC_ID,
                TTS.DAIHYO_KJN_CD,
                TTK.KJN_NM_KANA,
                TTK.KJN_NM,
                TTS.CHOFUKU_AITSK_REC_ID,
                TTS.CHOFUKU_AITSK_SHI_CD,
                CASE
                  WHEN TTS.KAIGYO_YOTEI_FLG='1' THEN SUBSTR(TTS.KAIGYO_YOTEI_YM,1,4)
                  WHEN TTS.KYUIN_FLG ='1' THEN SUBSTR(TTS.KYUIN_S_YM,1,4)
                  ELSE NULL
                END AS KYUIN_S_KAIGYO_YOTEI_Y,
                CASE
                  WHEN TTS.KAIGYO_YOTEI_FLG='1' THEN SUBSTR(TTS.KAIGYO_YOTEI_YM,5,2)
                  WHEN TTS.KYUIN_FLG ='1' THEN SUBSTR(TTS.KYUIN_S_YM,5,2)
                  ELSE NULL
                END AS KYUIN_S_KAIGYO_YOTEI_M,
                TO_CHAR(TTS.KYOKA_BED_SU_IPPAN,'FM0009') AS KYOKA_BED_SU_IPPAN,
                TO_CHAR(TTS.KYOKA_BED_SU_RYOYO,'FM0009') AS KYOKA_BED_SU_RYOYO,
                TTS.SNRYKMK_CD_01,
                TTS.SNRYKMK_CD_02,
                TTS.SNRYKMK_CD_03,
                TTS.SNRYKMK_CD_04,
                TTS.SNRYKMK_CD_05,
                TTS.SNRYKMK_CD_06,
                TTS.SNRYKMK_CD_07,
                TTS.SNRYKMK_CD_08,
                TTS.SNRYKMK_CD_09,
                TTS.SNRYKMK_CD_10,
                TTS.SNRYKMK_CD_11,
                TTS.SNRYKMK_CD_12,
                TTS.SNRYKMK_CD_13,
                TTS.SNRYKMK_CD_14,
                TTS.SNRYKMK_CD_15,
                TTS.SNRYKMK_CD_16,
                TTS.SNRYKMK_CD_17,
                TTS.SNRYKMK_CD_18,
                TTS.SNRYKMK_CD_19,
                TTS.SNRYKMK_CD_20,
                TTS.SNRYKMK_CD_21,
                TTS.SNRYKMK_CD_22,
                TTS.SNRYKMK_CD_23,
                TTS.SNRYKMK_CD_24,
                TTS.SNRYKMK_CD_25,
                TTS.SNRYKMK_CD_26,
                TTS.SNRYKMK_CD_27,
                TTS.SNRYKMK_CD_28,
                TTS.SNRYKMK_CD_29,
                TTS.SNRYKMK_CD_30,
                TTS.SNRYKMK_CD_31,
                TTS.SNRYKMK_CD_32,
                TTS.SNRYKMK_CD_33,
                TTS.SNRYKMK_CD_34,
                TTS.SNRYKMK_CD_35,
                TTS.SNRYKMK_CD_36,
                TTS.SNRYKMK_CD_37,
                TTS.SNRYKMK_CD_38,
                TTS.SNRYKMK_CD_39,
                TTS.SNRYKMK_CD_40,
                TTS.SNRYKMK_CD_41,
                TTS.SNRYKMK_CD_42,
                TTS.SNRYKMK_CD_43,
                TTS.SNRYKMK_CD_44,
                TTS.SNRYKMK_CD_45,
                TTS.SNRYKMK_CD_46,
                TTS.SNRYKMK_CD_47,
                TTS.SNRYKMK_CD_48,
                TTS.SNRYKMK_CD_49,
                TTS.SNRYKMK_CD_50,
                TTS.SNRYKMK_CD_51,
                TTS.SNRYKMK_CD_52,
                TTS.SNRYKMK_CD_53,
                TTS.SNRYKMK_CD_54,
                TTS.SNRYKMK_CD_55,
                TTS.SNRYKMK_CD_56,
                TTS.SNRYKMK_CD_57,
                TTS.SNRYKMK_CD_58,
                TTS.SNRYKMK_CD_59,
                TTS.SNRYKMK_CD_60,
                TTS.SEISHIKI_SHI_NM,
                TTS.SEISHIKI_SHI_NM_KANA,
                SUBSTR(iTensoYMD,1,4) AS TENSO_Y,
                SUBSTR(iTensoYMD,5,2) AS TENSO_M,
                SUBSTR(iTensoYMD,7,2) AS TENSO_D,
                SUBSTR(TTS.UPD_EIGY_YMD,1,4) AS MOD_SHORI_HIZUKE_Y,
                SUBSTR(TTS.UPD_EIGY_YMD,5,2) AS MOD_SHORI_HIZUKE_M,
                SUBSTR(TTS.UPD_EIGY_YMD,7,2) AS MOD_SHORI_HIZUKE_D,
                iOPE_CD,
                iDATE,
                iPGM_ID,
                iOPE_CD,
                iDATE,
                iPGM_ID
            FROM TT_TIKY_SHI TTS
        LEFT OUTER JOIN TT_TIKY_KJN TTK
          ON  TTS.DAIHYO_REC_ID = TTK.REC_ID
          AND TTS.DAIHYO_KJN_CD = TTK.KJN_CD
          AND TTK.DEL_FLG IS NULL
        WHERE TTS.REC_ID = '00'
        AND TTS.DEL_FLG IS NULL ;

      		-- ���O��o�^����
            EXECUTE_SQL := ' INSERT INTO TD_PA_DCF_SHI(                                                         ' ||
              '                 SHIREC_ID,                                                         ' ||
              '                 SHI_CD,                                                            ' ||
              '                 SEISHIKI_SHI_NM_KANA,                                              ' ||
              '                 RYKSK_SHI_NM_KANA,                                                 ' ||
              '                 SEISHIKI_SHI_NM_KANJI,                                             ' ||
              '                 RYKSK_SHI_NM_KANJI,                                                ' ||
              '                 KANREN_DAIGAKU_OYA_SHIREC_ID,                                      ' ||
              '                 KANREN_DAIGAKU_OYA_SHI_CD,                                         ' ||
              '                 JUSHO_KANA,                                                        ' ||
              '                 JUSHO_KANJI,                                                       ' ||
              '                 JUSHO_CD_KEN_CD,                                                   ' ||
              '                 JUSHO_CD_SHIKU_CD,                                                 ' ||
              '                 JUSHO_CD_OAZA_CD,                                                  ' ||
              '                 JUSHO_CD_AZA_CD,                                                   ' ||
              '                 ZIP,                                                               ' ||
              '                 JUSHO_HYOJI_NO,                                                    ' ||
              '                 JUSHO_COUNT_KANA_KEN,                                              ' ||
              '                 JUSHO_COUNT_KANA_SHIKU,                                            ' ||
              '                 JUSHO_COUNT_KANA_OAZA,                                             ' ||
              '                 JUSHO_COUNT_KANJI_KEN,                                             ' ||
              '                 JUSHO_COUNT_KANJI_SHIKU,                                           ' ||
              '                 JUSHO_COUNT_KANJI_OAZA,                                            ' ||
              '                 JUSHO_COUNT_KANA_AZA,                                              ' ||
              '                 JUSHO_COUNT_KANJI_AZA,                                             ' ||
              '                 SHI_TEL,                                                           ' ||
              '                 BED_SU_TEIIN,                                                      ' ||
              '                 KEIEITAI,                                                          ' ||
              '                 SHI_KBN,                                                           ' ||
              '                 KENSAKOMOKU_BISEIBUTSU,                                            ' ||
              '                 KENSAKOMOKU_KESSEI,                                                ' ||
              '                 KENSAKOMOKU_KETSUEKI,                                              ' ||
              '                 KENSAKOMOKU_BYORI,                                                 ' ||
              '                 KENSAKOMOKU_KISEICHU,                                              ' ||
              '                 KENSAKOMOKU_SEIKA,                                                 ' ||
              '                 KENSAKOMOKU_RI,                                                    ' ||
              '                 STATUS_JUSHOFUMEI,                                                 ' ||
              '                 STATUS_KYUIN_FLG,                                                  ' ||
              '                 STATUS_DEL_YOTEI_RIYU,                                             ' ||
              '                 STATUS_KAIGYO_YOTEI_FLG,                                           ' ||
              '                 STATUS_BYOTO_HEISA_FLG,                                            ' ||
              '                 STATUS_TEL_NASHI_FLG,                                              ' ||
              '                 STATUS_MIKAKUNIN_FLG,                                              ' ||
              '                 STATUS_SAISHINSA_KBN,                                              ' ||
              '                 KYOKA_BED_MENTE_HIZUKE_Y,                                          ' ||
              '                 KYOKA_BED_MENTE_HIZUKE_M,                                          ' ||
              '                 KYOKA_BED_MENTE_HIZUKE_D,                                          ' ||
              '                 KYOKA_BED_SU_SONOTA,                                               ' ||
              '                 KYOKA_BED_SU_SEISHIN,                                              ' ||
              '                 KYOKA_BED_SU_KEKKAKU,                                              ' ||
              '                 KYOKA_BED_SU_KANSEN,                                               ' ||
              '                 KYOKA_BED_SU_GOKEI,                                                ' ||
              '                 BYOIN_SBT,                                                         ' ||
              '                 SHI_DAIHYO_KJNREC_ID,                                              ' ||
              '                 SHI_DAIHYO_KJN_CD,                                                 ' ||
              '                 SHI_DAIHYO_KANA,                                                   ' ||
              '                 SHI_DAIHYO_KANJI,                                                  ' ||
              '                 AITSK_CD_SHIREC_ID,                                                ' ||
              '                 AITSK_CD_SHI_CD,                                                   ' ||
              '                 KYUIN_S_KAIGYO_YOTEI_Y,                                            ' ||
              '                 KYUIN_S_KAIGYO_YOTEI_M,                                            ' ||
              '                 SHIN_BED_KBN_IPPAN_BED,                                            ' ||
              '                 SHIN_BED_KBN_RYOYO_BED,                                            ' ||
              '                 SNRYKMK_1,                                                         ' ||
              '                 SNRYKMK_2,                                                         ' ||
              '                 SNRYKMK_3,                                                         ' ||
              '                 SNRYKMK_4,                                                         ' ||
              '                 SNRYKMK_5,                                                         ' ||
              '                 SNRYKMK_6,                                                         ' ||
              '                 SNRYKMK_7,                                                         ' ||
              '                 SNRYKMK_8,                                                         ' ||
              '                 SNRYKMK_9,                                                         ' ||
              '                 SNRYKMK_10,                                                        ' ||
              '                 SNRYKMK_11,                                                        ' ||
              '                 SNRYKMK_12,                                                        ' ||
              '                 SNRYKMK_13,                                                        ' ||
              '                 SNRYKMK_14,                                                        ' ||
              '                 SNRYKMK_15,                                                        ' ||
              '                 SNRYKMK_16,                                                        ' ||
              '                 SNRYKMK_17,                                                        ' ||
              '                 SNRYKMK_18,                                                        ' ||
              '                 SNRYKMK_19,                                                        ' ||
              '                 SNRYKMK_20,                                                        ' ||
              '                 SNRYKMK_21,                                                        ' ||
              '                 SNRYKMK_22,                                                        ' ||
              '                 SNRYKMK_23,                                                        ' ||
              '                 SNRYKMK_24,                                                        ' ||
              '                 SNRYKMK_25,                                                        ' ||
              '                 SNRYKMK_26,                                                        ' ||
              '                 SNRYKMK_27,                                                        ' ||
              '                 SNRYKMK_28,                                                        ' ||
              '                 SNRYKMK_29,                                                        ' ||
              '                 SNRYKMK_30,                                                        ' ||
              '                 SNRYKMK_31,                                                        ' ||
              '                 SNRYKMK_32,                                                        ' ||
              '                 SNRYKMK_33,                                                        ' ||
              '                 SNRYKMK_34,                                                        ' ||
              '                 SNRYKMK_35,                                                        ' ||
              '                 SNRYKMK_36,                                                        ' ||
              '                 SNRYKMK_37,                                                        ' ||
              '                 SNRYKMK_38,                                                        ' ||
              '                 SNRYKMK_39,                                                        ' ||
              '                 SNRYKMK_40,                                                        ' ||
              '                 SNRYKMK_41,                                                        ' ||
              '                 SNRYKMK_42,                                                        ' ||
              '                 SNRYKMK_43,                                                        ' ||
              '                 SNRYKMK_44,                                                        ' ||
              '                 SNRYKMK_45,                                                        ' ||
              '                 SNRYKMK_46,                                                        ' ||
              '                 SNRYKMK_47,                                                        ' ||
              '                 SNRYKMK_48,                                                        ' ||
              '                 SNRYKMK_49,                                                        ' ||
              '                 SNRYKMK_50,                                                        ' ||
              '                 SNRYKMK_51,                                                        ' ||
              '                 SNRYKMK_52,                                                        ' ||
              '                 SNRYKMK_53,                                                        ' ||
              '                 SNRYKMK_54,                                                        ' ||
              '                 SNRYKMK_55,                                                        ' ||
              '                 SNRYKMK_56,                                                        ' ||
              '                 SNRYKMK_57,                                                        ' ||
              '                 SNRYKMK_58,                                                        ' ||
              '                 SNRYKMK_59,                                                        ' ||
              '                 SNRYKMK_60,                                                        ' ||
              '                 SHIN_SEISHIKI_SHI_NM_KANJI,                                        ' ||
              '                 SHIN_SEISHIKI_SHI_NM_KANA,                                         ' ||
              '                 TENSO_Y,                                                           ' ||
              '                 TENSO_M,                                                           ' ||
              '                 TENSO_D,                                                           ' ||
              '                 MOD_SHORI_HIZUKE_Y,                                                ' ||
              '                 MOD_SHORI_HIZUKE_M,                                                ' ||
              '                 MOD_SHORI_HIZUKE_D,                                                ' ||
              '                 TRK_OPE_CD,                                                        ' ||
              '                 TRK_DATE,                                                          ' ||
              '                 TRK_PGM_ID,                                                        ' ||
              '                 UPD_OPE_CD,                                                        ' ||
              '                 UPD_DATE,                                                          ' ||
              '                 UPD_PGM_ID                                                         ' ||
              '               )                                                                    ' ||
              '         SELECT                                                                     ' ||
              '             ''00'',                                                                  ' ||
              '             TTS.SHI_CD,                                                            ' ||
              '             TTS.SEISHIKI_SHI_NM_KANA40,                                            ' ||
              '             TTS.SHI_RN_KANA,                                                       ' ||
              '             TTS.SEISHIKI_SHI_NM30,                                                 ' ||
              '             TTS.SHI_RN,                                                            ' ||
              '             TTS.KANREN_DAIGAKU_OYA_REC_ID,                                         ' ||
              '             TTS.KANREN_DAIGAKU_OYA_SHI_CD,                                         ' ||
              '             TTS.JUSHO_KANA_RENKETSU,                                               ' ||
              '             TTS.JUSHO_KANJI_RENKETSU,                                              ' ||
              '             TTS.KEN_CD,                                                            ' ||
              '             TTS.SHIKU_CD,                                                          ' ||
              '             TTS.OAZA_CD,                                                           ' ||
              '             TTS.AZA_CD,                                                            ' ||
              '             NVL2(TTS.ZIP,SUBSTR(TTS.ZIP,1,3)||''-''||SUBSTR(TTS.ZIP,4),NULL) AS ZIP, ' ||
              '             TTS.JUSHO_HYOJI_NO,                                                    ' ||
              '             TO_CHAR(TTS.KEN_NM_KANA_MOJI_SU,''FM09'') AS KEN_NM_KANA_MOJI_SU,        ' ||
              '             TO_CHAR(TTS.SHIKU_NM_KANA_MOJI_SU,''FM09'') AS SHIKU_NM_KANA_MOJI_SU,    ' ||
              '             TO_CHAR(TTS.OAZA_NM_KANA_MOJI_SU,''FM09'') AS OAZA_NM_KANA_MOJI_SU,      ' ||
              '             TO_CHAR(TTS.KEN_NM_KANJI_MOJI_SU,''FM09'') AS KEN_NM_KANJI_MOJI_SU,      ' ||
              '             TO_CHAR(TTS.SHIKU_NM_KANJI_MOJI_SU,''FM09'') AS SHIKU_NM_KANJI_MOJI_SU,  ' ||
              '             TO_CHAR(TTS.OAZA_NM_KANJI_MOJI_SU,''FM09'') AS OAZA_NM_KANJI_MOJI_SU,    ' ||
              '             TO_CHAR(TTS.AZA_NM_KANA_MOJI_SU,''FM09'') AS AZA_NM_KANA_MOJI_SU,        ' ||
              '             TO_CHAR(TTS.AZA_NM_KANJI_MOJI_SU,''FM09'') AS AZA_NM_KANJI_MOJI_SU,      ' ||
              '             TTS.TEL,                                                               ' ||
              '             TO_CHAR(TTS.SHI_BED_SU,''FM0009'') AS SHI_BED_SU,                        ' ||
              '             TTS.KEIEITAI_CD,                                                       ' ||
              '             TTS.SHI_KBN_CD,                                                        ' ||
              '             TTS.KENSAKOMOKU_BISEIBUTSU_FLG,                                        ' ||
              '             TTS.KENSAKOMOKU_KESSEI_FLG,                                            ' ||
              '             TTS.KENSAKOMOKU_KETSUEKI_FLG,                                          ' ||
              '             TTS.KENSAKOMOKU_BYORI_FLG,                                             ' ||
              '             TTS.KENSAKOMOKU_KISEICHU_FLG,                                          ' ||
              '             TTS.KENSAKOMOKU_SEIKA_FLG,                                             ' ||
              '             TTS.KENSAKOMOKU_RI_FLG,                                                ' ||
              '             TTS.JUSHOFUMEI_CD,                                                     ' ||
              '             TTS.KYUIN_FLG,                                                         ' ||
              '             TTS.DEL_YOTEI_RIYU_CD,                                                 ' ||
              '             TTS.KAIGYO_YOTEI_FLG,                                                  ' ||
              '             TTS.BYOTO_HEISA_KBN,                                                   ' ||
              '             TTS.TEL_NASHI_FLG,                                                     ' ||
              '             TTS.MIKAKUNIN_FLG,                                                     ' ||
              '             TTS.SAISHINSA_KBN_CD,                                                  ' ||
              '             SUBSTR(TTS.BED_SU_KKNN_EIGY_YMD,1,4) AS KYOKA_BED_MENTE_HIZUKE_Y,      ' ||
              '             SUBSTR(TTS.BED_SU_KKNN_EIGY_YMD,5,2) AS KYOKA_BED_MENTE_HIZUKE_M,      ' ||
              '             SUBSTR(TTS.BED_SU_KKNN_EIGY_YMD,7,2) AS KYOKA_BED_MENTE_HIZUKE_D,      ' ||
              '             TO_CHAR(TTS.KYOKA_BED_SU_SONOTA,''FM0009'') AS KYOKA_BED_SU_SONOTA,      ' ||
              '             TO_CHAR(TTS.KYOKA_BED_SU_SEISHIN,''FM0009'') AS KYOKA_BED_SU_SEISHIN,    ' ||
              '             TO_CHAR(TTS.KYOKA_BED_SU_KEKKAKU,''FM0009'') AS KYOKA_BED_SU_KEKKAKU,    ' ||
              '             TO_CHAR(TTS.KYOKA_BED_SU_KANSEN,''FM0009'') AS KYOKA_BED_SU_KANSEN,      ' ||
              '             TO_CHAR(TTS.KYOKA_BED_SU_GOKEI,''FM0009'') AS KYOKA_BED_SU_GOKEI,        ' ||
              '             TTS.BYOIN_SBT_CD,                                                      ' ||
              '             TTS.DAIHYO_REC_ID,                                                     ' ||
              '             TTS.DAIHYO_KJN_CD,                                                     ' ||
              '             TTK.KJN_NM_KANA,                                                       ' ||
              '             TTK.KJN_NM,                                                            ' ||
              '             TTS.CHOFUKU_AITSK_REC_ID,                                              ' ||
              '             TTS.CHOFUKU_AITSK_SHI_CD,                                              ' ||
              '             CASE                                                                   ' ||
              '             WHEN TTS.KAIGYO_YOTEI_FLG=''1'' THEN SUBSTR(TTS.KAIGYO_YOTEI_YM,1,4)     ' ||
              '             WHEN TTS.KYUIN_FLG =''1'' THEN SUBSTR(TTS.KYUIN_S_YM,1,4)                ' ||
              '             ELSE NULL                                                              ' ||
              '             END AS KYUIN_S_KAIGYO_YOTEI_Y,                                         ' ||
              '             CASE                                                                   ' ||
              '             WHEN TTS.KAIGYO_YOTEI_FLG=''1'' THEN SUBSTR(TTS.KAIGYO_YOTEI_YM,5,2)     ' ||
              '             WHEN TTS.KYUIN_FLG =''1'' THEN SUBSTR(TTS.KYUIN_S_YM,5,2)                ' ||
              '             ELSE NULL                                                              ' ||
              '             END AS KYUIN_S_KAIGYO_YOTEI_M,                                         ' ||
              '             TO_CHAR(TTS.KYOKA_BED_SU_IPPAN,''FM0009'') AS KYOKA_BED_SU_IPPAN,        ' ||
              '             TO_CHAR(TTS.KYOKA_BED_SU_RYOYO,''FM0009'') AS KYOKA_BED_SU_RYOYO,        ' ||
              '             TTS.SNRYKMK_CD_01,                                                     ' ||
              '             TTS.SNRYKMK_CD_02,                                                     ' ||
              '             TTS.SNRYKMK_CD_03,                                                     ' ||
              '             TTS.SNRYKMK_CD_04,                                                     ' ||
              '             TTS.SNRYKMK_CD_05,                                                     ' ||
              '             TTS.SNRYKMK_CD_06,                                                     ' ||
              '             TTS.SNRYKMK_CD_07,                                                     ' ||
              '             TTS.SNRYKMK_CD_08,                                                     ' ||
              '             TTS.SNRYKMK_CD_09,                                                     ' ||
              '             TTS.SNRYKMK_CD_10,                                                     ' ||
              '             TTS.SNRYKMK_CD_11,                                                     ' ||
              '             TTS.SNRYKMK_CD_12,                                                     ' ||
              '             TTS.SNRYKMK_CD_13,                                                     ' ||
              '             TTS.SNRYKMK_CD_14,                                                     ' ||
              '             TTS.SNRYKMK_CD_15,                                                     ' ||
              '             TTS.SNRYKMK_CD_16,                                                     ' ||
              '             TTS.SNRYKMK_CD_17,                                                     ' ||
              '             TTS.SNRYKMK_CD_18,                                                     ' ||
              '             TTS.SNRYKMK_CD_19,                                                     ' ||
              '             TTS.SNRYKMK_CD_20,                                                     ' ||
              '             TTS.SNRYKMK_CD_21,                                                     ' ||
              '             TTS.SNRYKMK_CD_22,                                                     ' ||
              '             TTS.SNRYKMK_CD_23,                                                     ' ||
              '             TTS.SNRYKMK_CD_24,                                                     ' ||
              '             TTS.SNRYKMK_CD_25,                                                     ' ||
              '             TTS.SNRYKMK_CD_26,                                                     ' ||
              '             TTS.SNRYKMK_CD_27,                                                     ' ||
              '             TTS.SNRYKMK_CD_28,                                                     ' ||
              '             TTS.SNRYKMK_CD_29,                                                     ' ||
              '             TTS.SNRYKMK_CD_30,                                                     ' ||
              '             TTS.SNRYKMK_CD_31,                                                     ' ||
              '             TTS.SNRYKMK_CD_32,                                                     ' ||
              '             TTS.SNRYKMK_CD_33,                                                     ' ||
              '             TTS.SNRYKMK_CD_34,                                                     ' ||
              '             TTS.SNRYKMK_CD_35,                                                     ' ||
              '             TTS.SNRYKMK_CD_36,                                                     ' ||
              '             TTS.SNRYKMK_CD_37,                                                     ' ||
              '             TTS.SNRYKMK_CD_38,                                                     ' ||
              '             TTS.SNRYKMK_CD_39,                                                     ' ||
              '             TTS.SNRYKMK_CD_40,                                                     ' ||
              '             TTS.SNRYKMK_CD_41,                                                     ' ||
              '             TTS.SNRYKMK_CD_42,                                                     ' ||
              '             TTS.SNRYKMK_CD_43,                                                     ' ||
              '             TTS.SNRYKMK_CD_44,                                                     ' ||
              '             TTS.SNRYKMK_CD_45,                                                     ' ||
              '             TTS.SNRYKMK_CD_46,                                                     ' ||
              '             TTS.SNRYKMK_CD_47,                                                     ' ||
              '             TTS.SNRYKMK_CD_48,                                                     ' ||
              '             TTS.SNRYKMK_CD_49,                                                     ' ||
              '             TTS.SNRYKMK_CD_50,                                                     ' ||
              '             TTS.SNRYKMK_CD_51,                                                     ' ||
              '             TTS.SNRYKMK_CD_52,                                                     ' ||
              '             TTS.SNRYKMK_CD_53,                                                     ' ||
              '             TTS.SNRYKMK_CD_54,                                                     ' ||
              '             TTS.SNRYKMK_CD_55,                                                     ' ||
              '             TTS.SNRYKMK_CD_56,                                                     ' ||
              '             TTS.SNRYKMK_CD_57,                                                     ' ||
              '             TTS.SNRYKMK_CD_58,                                                     ' ||
              '             TTS.SNRYKMK_CD_59,                                                     ' ||
              '             TTS.SNRYKMK_CD_60,                                                     ' ||
              '             TTS.SEISHIKI_SHI_NM,                                                   ' ||
              '             TTS.SEISHIKI_SHI_NM_KANA,                                              ' ||
              '             SUBSTR(iTensoYMD,1,4) AS TENSO_Y,                                      ' ||
              '             SUBSTR(iTensoYMD,5,2) AS TENSO_M,                                      ' ||
              '             SUBSTR(iTensoYMD,7,2) AS TENSO_D,                                      ' ||
              '             SUBSTR(TTS.UPD_EIGY_YMD,1,4) AS MOD_SHORI_HIZUKE_Y,                    ' ||
              '             SUBSTR(TTS.UPD_EIGY_YMD,5,2) AS MOD_SHORI_HIZUKE_M,                    ' ||
              '             SUBSTR(TTS.UPD_EIGY_YMD,7,2) AS MOD_SHORI_HIZUKE_D,                    ' ||
                          iOPE_CD   || ','                                                         ||
                            iDATE    || ','                                                         ||
                            iPGM_ID  || ','                                                         ||
                            iOPE_CD  || ','                                                         ||
                            iDATE    || ','                                                         ||
                            iPGM_ID                                                                  ||
              '         FROM TT_TIKY_SHI TTS                                                       ' ||
              '     LEFT OUTER JOIN TT_TIKY_KJN TTK                                                ' ||
              '       ON  TTS.DAIHYO_REC_ID = TTK.REC_ID                                           ' ||
              '       AND TTS.DAIHYO_KJN_CD = TTK.KJN_CD                                           ' ||
              '       AND TTK.DEL_FLG IS NULL                                                      ' ||
              '     WHERE TTS.REC_ID = ''00''                                                      ' ||
              '     AND TTS.DEL_FLG IS NULL                                                        ' ;

            ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);


            --�b��_�S��_���{�㖱����o�^����
            INSERT INTO TD_PA_TOKUITBL(
                      REC_ID,
                      TAG_NO,
                      KO_SHIREC_ID,
                      KO_SHI_CD,
                      OYA_SHIREC_ID,
                      OYA_SHI_CD,
                      TENSO_Y,
                      TENSO_M,
                      TENSO_D,
                      MENTE_Y,
                      MENTE_M,
                      MENTE_D,
                      TRK_OPE_CD,
                      TRK_DATE,
                      TRK_PGM_ID,
                      UPD_OPE_CD,
                      UPD_DATE,
                      UPD_PGM_ID
                    )
                SELECT
                    '00',
                    '92',
                    TTS.REC_ID,
                    TTS.SHI_CD,
                    TTS.IMUSHITSU_REC_ID,
                    TTS.IMUSHITSU_SHI_CD,
                    SUBSTR(iTensoYMD,1,4) AS TENSO_Y,
                    SUBSTR(iTensoYMD,5,2) AS TENSO_M,
                    SUBSTR(iTensoYMD,7,2) AS TENSO_D,
                    SUBSTR(TTS.UPD_EIGY_YMD,1,4),
                    SUBSTR(TTS.UPD_EIGY_YMD,5,2),
                    SUBSTR(TTS.UPD_EIGY_YMD,7,2),
                    iOPE_CD,
                    iDATE,
                    iPGM_ID,
                    iOPE_CD,
                    iDATE,
                    iPGM_ID
              FROM TT_TIKY_SHI TTS
              WHERE TTS.REC_ID = '00'
              AND TTS.DEL_FLG IS NULL
              AND TTS.IMUSHITSU_REC_ID IS NOT NULL
              AND TTS.IMUSHITSU_SHI_CD IS NOT NULL;

      -- ���O��o�^����
            EXECUTE_SQL := '  INSERT INTO TD_PA_TOKUITBL(                     ' ||
              '                  REC_ID,                        ' ||
              '                  TAG_NO,                        ' ||
              '                  KO_SHIREC_ID,                  ' ||
              '                  KO_SHI_CD,                     ' ||
              '                  OYA_SHIREC_ID,                 ' ||
              '                  OYA_SHI_CD,                    ' ||
              '                  TENSO_Y,                       ' ||
              '                  TENSO_M,                       ' ||
              '                  TENSO_D,                       ' ||
              '                  MENTE_Y,                       ' ||
              '                  MENTE_M,                       ' ||
              '                  MENTE_D,                       ' ||
              '                  TRK_OPE_CD,                    ' ||
              '                  TRK_DATE,                      ' ||
              '                  TRK_PGM_ID,                    ' ||
              '                  UPD_OPE_CD,                    ' ||
              '                  UPD_DATE,                      ' ||
              '                  UPD_PGM_ID                     ' ||
              '              )                                  ' ||
              '      SELECT                                     ' ||
              '              ''00'',                              ' ||
              '              ''92'',                              ' ||
              '            TTS.REC_ID,                          ' ||
              '              TTS.SHI_CD,                        ' ||
              '              TTS.IMUSHITSU_REC_ID,              ' ||
              '              TTS.IMUSHITSU_SHI_CD,              ' ||
              '              SUBSTR(iTensoYMD ,1,4) AS TENSO_Y,  ' ||
              '              SUBSTR(iTensoYMD ,5,2) AS TENSO_M,  ' ||
              '              SUBSTR(iTensoYMD ,7,2) AS TENSO_D,  ' ||
              '              SUBSTR(TTS.UPD_EIGY_YMD,1,4),      ' ||
              '              SUBSTR(TTS.UPD_EIGY_YMD,5,2),      ' ||
              '              SUBSTR(TTS.UPD_EIGY_YMD,7,2),      ' ||
                            iOPE_CD            ||           ',' ||
                           iDATE              ||           ',' ||
                            iPGM_ID            ||           ',' ||
                            iOPE_CD            ||           ',' ||
                            iDATE              ||           ',' ||
                            iPGM_ID                              ||
              '      FROM TT_TIKY_SHI TTS                       ' ||
              '      WHERE TTS.REC_ID = ' || '''00'''              ||
              '      AND TTS.DEL_FLG IS NULL                    ' ||
              '      AND TTS.IMUSHITSU_REC_ID IS NOT NULL       ' ||
              '      AND TTS.IMUSHITSU_SHI_CD IS NOT NULL       ' ;

            ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

          END IF;
      ELSIF iShimeKind = ULT_COMMON.SHIME_SBT_CD_NAKASHIME OR iShimeKind = ULT_COMMON.SHIME_SBT_CD_MATSUSHIME THEN
          -- �Q����O���C�A�E�g

            --�b��_�S��_2����O_DCF�{�݃e�[�u���̃f�[�^���N���A����B
            EXECUTE_SQL := 'TRUNCATE TABLE ' || vSchemaNm || '.' || 'TD_PA_GEN_DCF_SHI';
            EXECUTE IMMEDIATE EXECUTE_SQL;
            ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

              --�b��_�S��_2����O_DCF�{�݂�o�^����
              INSERT INTO TD_PA_GEN_DCF_SHI(
                      SHIREC_ID,
                      SHI_CD,
                      SHI_CD_YOBI,
                      SEISHIKI_SHI_NM_KANA,
                      RYKSK_SHI_NM_KANA,
                      JUSHO_CD_KEN_CD,
                      JUSHO_CD_SHIKU_CD,
                      JUSHO_CD_OAZA_CD,
                      JUSHO_CD_AZA_CD,
                      ZIP,
                      JUSHO_HYOJI_NO,
                      YOBI_1,
                      JUSHO_KANA,
                      JUSHO_COUNT_KANA_KEN,
                      JUSHO_COUNT_KANA_SHIKU,
                      JUSHO_COUNT_KANA_OAZA,
                      JUSHO_COUNT_KANJI_KEN,
                      JUSHO_COUNT_KANJI_SHIKU,
                      JUSHO_COUNT_KANJI_OAZA,
                      SHI_TEL,
                      BED_SU_TEIIN,
                      KEIEITAI,
                      SHI_KBN,
                      YOBI_2,
                      BYOIN_SBT,
                      KANREN_DAIGAKU_OYA_SHIREC_ID,
                      KANREN_DAIGAKU_OYA_SHI_CD,
                      KANREN_DAIGAKU_OYA_SHI_CD_YOBI,
                      STATUS_JUSHOFUMEI,
                      STATUS_KYUIN_FLG,
                      STATUS_DEL_YOTEI_RIYU,
                      STATUS_KAIGYO_YOTEI_FLG,
                      STATUS_BYOTO_HEISA_FLG,
                      STATUS_YOBI,
                      STATUS_SAISHINSA_KBN,
                      KYUIN_S_KAIGYO_YOTEI_Y,
                      KYUIN_S_KAIGYO_YOTEI_M,
                      KYOKA_BED_MENTE_HIZUKE_Y,
                      KYOKA_BED_MENTE_HIZUKE_M,
                      KYOKA_BED_MENTE_HIZUKE_D,
                      KYOKA_BED_SU_SONOTA,
                      KYOKA_BED_SU_SEISHIN,
                      KYOKA_BED_SU_KEKKAKU,
                      KYOKA_BED_SU_KANSEN,
                      KYOKA_BED_SU_GOKEI,
                      KENSAKOMOKU_BISEIBUTSU,
                      KENSAKOMOKU_KESSEI,
                      KENSAKOMOKU_KETSUEKI,
                      KENSAKOMOKU_BYORI,
                      KENSAKOMOKU_KISEICHU,
                      KENSAKOMOKU_SEIKA,
                      KENSAKOMOKU_RI,
                      KENSAKOMOKU_YOBI,
                      SNRYKMK_1,
                      SNRYKMK_2,
                      SNRYKMK_3,
                      SNRYKMK_4,
                      SNRYKMK_5,
                      SNRYKMK_6,
                      SNRYKMK_7,
                      SNRYKMK_8,
                      SNRYKMK_9,
                      SNRYKMK_10,
                      SNRYKMK_11,
                      SNRYKMK_12,
                      SNRYKMK_13,
                      SNRYKMK_14,
                      SNRYKMK_15,
                      SNRYKMK_16,
                      SNRYKMK_17,
                      SNRYKMK_18,
                      SNRYKMK_19,
                      SNRYKMK_20,
                      SNRYKMK_21,
                      SNRYKMK_22,
                      SNRYKMK_23,
                      SNRYKMK_24,
                      SNRYKMK_25,
                      SNRYKMK_26,
                      SNRYKMK_27,
                      SNRYKMK_28,
                      SNRYKMK_29,
                      SNRYKMK_30,
                      SNRYKMK_31,
                      SNRYKMK_32,
                      SNRYKMK_33,
                      SNRYKMK_34,
                      SNRYKMK_35,
                      SNRYKMK_36,
                      SNRYKMK_37,
                      SNRYKMK_38,
                      SNRYKMK_39,
                      SNRYKMK_40,
                      SEISHIKI_SHI_NM_KANJI,
                      RYKSK_SHI_NM_KANJI,
                      JUSHO_KANJI,
                      SHI_DAIHYO_KJNREC_ID,
                      SHI_DAIHYO_KJN_CD,
                      SHI_DAIHYO_KJN_CD_YOBI,
                      SHI_DAIHYO_KANA,
                      SHI_DAIHYO_KANJI,
                      SHI_YOBI_AREA,
                      SHIN_BED_KBN_IPPAN_BED,
                      SHIN_BED_KBN_RYOYO_BED,
                      AITSK_CD_SHIREC_ID,
                      AITSK_CD_SHI_CD,
                      AITSK_CD_SHI_CD_YOBI,
                      TRK_OPE_CD,
                      TRK_DATE,
                      TRK_PGM_ID,
                      UPD_OPE_CD,
                      UPD_DATE,
                      UPD_PGM_ID
                    )
              SELECT
                '00',
                TTS.SHI_CD,
                NULL,
                TTS.SEISHIKI_SHI_NM_KANA40,
                TTS.SHI_RN_KANA,
                TTS.KEN_CD,
                TTS.SHIKU_CD,
                TTS.OAZA_CD,
                TTS.AZA_CD,
                NVL2(TTS.ZIP,SUBSTR(TTS.ZIP,1,3)||'-'||SUBSTR(TTS.ZIP,4),NULL) AS ZIP,
                TTS.JUSHO_HYOJI_NO,
                NULL,
                TTS.JUSHO_KANA_RENKETSU,
                TO_CHAR(TTS.KEN_NM_KANA_MOJI_SU,'FM09') AS KEN_NM_KANA_MOJI_SU,
                TO_CHAR(TTS.SHIKU_NM_KANA_MOJI_SU,'FM09') AS SHIKU_NM_KANA_MOJI_SU,
                TO_CHAR(TTS.OAZA_NM_KANA_MOJI_SU,'FM09') AS OAZA_NM_KANA_MOJI_SU,
                TO_CHAR(TTS.KEN_NM_KANJI_MOJI_SU,'FM09') AS KEN_NM_KANJI_MOJI_SU,
                TO_CHAR(TTS.SHIKU_NM_KANJI_MOJI_SU,'FM09') AS SHIKU_NM_KANJI_MOJI_SU,
                TO_CHAR(TTS.OAZA_NM_KANJI_MOJI_SU,'FM09') AS OAZA_NM_KANJI_MOJI_SU,
                TTS.TEL,
                TO_CHAR(TTS.SHI_BED_SU,'FM0009') AS SHI_BED_SU,
                TTS.KEIEITAI_CD,
                TTS.SHI_KBN_CD,
                NULL,
                TTS.BYOIN_SBT_CD,
                TTS.KANREN_DAIGAKU_OYA_REC_ID,
                TTS.KANREN_DAIGAKU_OYA_SHI_CD,
                NULL,
                TTS.JUSHOFUMEI_CD,
                TTS.KYUIN_FLG,
                TTS.DEL_YOTEI_RIYU_CD,
                TTS.KAIGYO_YOTEI_FLG,
                TTS.BYOTO_HEISA_KBN,
                
                --TTS.TEL_NASHI_FLG||TTS.MIKAKUNIN_FLG,
                CASE
                  WHEN TTS.TEL_NASHI_FLG='1' AND TTS.MIKAKUNIN_FLG IS NULL THEN '1'
                  WHEN TTS.TEL_NASHI_FLG='1' AND TTS.MIKAKUNIN_FLG='1' THEN '11'
                  WHEN TTS.TEL_NASHI_FLG IS NULL AND TTS.MIKAKUNIN_FLG='1' THEN ' 1'
                  WHEN TTS.TEL_NASHI_FLG IS NULL AND TTS.MIKAKUNIN_FLG IS NULL THEN TTS.TEL_NASHI_FLG
                END AS STATUS_YOBI,

                TTS.SAISHINSA_KBN_CD,
                CASE
                  WHEN TTS.KAIGYO_YOTEI_FLG='1' THEN SUBSTR(TTS.KAIGYO_YOTEI_YM,1,4)
                  WHEN TTS.KYUIN_FLG ='1' THEN SUBSTR(TTS.KYUIN_S_YM,1,4)
                  ELSE NULL
                END AS KYUIN_S_KAIGYO_YOTEI_Y,
                CASE
                  WHEN TTS.KAIGYO_YOTEI_FLG='1' THEN SUBSTR(TTS.KAIGYO_YOTEI_YM,5,2)
                  WHEN TTS.KYUIN_FLG ='1' THEN SUBSTR(TTS.KYUIN_S_YM,5,2)
                  ELSE NULL
                END AS KYUIN_S_KAIGYO_YOTEI_M,
                SUBSTR(TTS.BED_SU_KKNN_EIGY_YMD,1,4) AS KYOKA_BED_MENTE_HIZUKE_Y,
                SUBSTR(TTS.BED_SU_KKNN_EIGY_YMD,5,2) AS KYOKA_BED_MENTE_HIZUKE_M,
                SUBSTR(TTS.BED_SU_KKNN_EIGY_YMD,7,2) AS KYOKA_BED_MENTE_HIZUKE_D,
                TO_CHAR(TTS.KYOKA_BED_SU_SONOTA,'FM0009') AS KYOKA_BED_SU_SONOTA,
                TO_CHAR(TTS.KYOKA_BED_SU_SEISHIN,'FM0009') AS KYOKA_BED_SU_SEISHIN,
                TO_CHAR(TTS.KYOKA_BED_SU_KEKKAKU,'FM0009') AS KYOKA_BED_SU_KEKKAKU,
                TO_CHAR(TTS.KYOKA_BED_SU_KANSEN,'FM0009') AS KYOKA_BED_SU_KANSEN,
                TO_CHAR(TTS.KYOKA_BED_SU_GOKEI,'FM0009') AS KYOKA_BED_SU_GOKEI,
                TTS.KENSAKOMOKU_BISEIBUTSU_FLG,
                TTS.KENSAKOMOKU_KESSEI_FLG,
                TTS.KENSAKOMOKU_KETSUEKI_FLG,
                TTS.KENSAKOMOKU_BYORI_FLG,
                TTS.KENSAKOMOKU_KISEICHU_FLG,
                TTS.KENSAKOMOKU_SEIKA_FLG,
                TTS.KENSAKOMOKU_RI_FLG,
                NULL,
                TTS.SNRYKMK_CD_01,
                TTS.SNRYKMK_CD_02,
                TTS.SNRYKMK_CD_03,
                TTS.SNRYKMK_CD_04,
                TTS.SNRYKMK_CD_05,
                TTS.SNRYKMK_CD_06,
                TTS.SNRYKMK_CD_07,
                TTS.SNRYKMK_CD_08,
                TTS.SNRYKMK_CD_09,
                TTS.SNRYKMK_CD_10,
                TTS.SNRYKMK_CD_11,
                TTS.SNRYKMK_CD_12,
                TTS.SNRYKMK_CD_13,
                TTS.SNRYKMK_CD_14,
                TTS.SNRYKMK_CD_15,
                TTS.SNRYKMK_CD_16,
                TTS.SNRYKMK_CD_17,
                TTS.SNRYKMK_CD_18,
                TTS.SNRYKMK_CD_19,
                TTS.SNRYKMK_CD_20,
                TTS.SNRYKMK_CD_21,
                TTS.SNRYKMK_CD_22,
                TTS.SNRYKMK_CD_23,
                TTS.SNRYKMK_CD_24,
                TTS.SNRYKMK_CD_25,
                TTS.SNRYKMK_CD_26,
                TTS.SNRYKMK_CD_27,
                TTS.SNRYKMK_CD_28,
                TTS.SNRYKMK_CD_29,
                TTS.SNRYKMK_CD_30,
                TTS.SNRYKMK_CD_31,
                TTS.SNRYKMK_CD_32,
                TTS.SNRYKMK_CD_33,
                TTS.SNRYKMK_CD_34,
                TTS.SNRYKMK_CD_35,
                TTS.SNRYKMK_CD_36,
                TTS.SNRYKMK_CD_37,
                TTS.SNRYKMK_CD_38,
                TTS.SNRYKMK_CD_39,
                TTS.SNRYKMK_CD_40,
                TTS.SEISHIKI_SHI_NM30,
                TTS.SHI_RN,
                TTS.JUSHO_KANJI_RENKETSU,
                TTS.DAIHYO_REC_ID,
                TTS.DAIHYO_KJN_CD,
                NULL,
                TTK.KJN_NM_KANA,
                TTK.KJN_NM,
                NULL,
                TO_CHAR(TTS.KYOKA_BED_SU_IPPAN,'FM0009') AS KYOKA_BED_SU_IPPAN,
                TO_CHAR(TTS.KYOKA_BED_SU_RYOYO,'FM0009') AS KYOKA_BED_SU_RYOYO,
                TTS.CHOFUKU_AITSK_REC_ID,
                TTS.CHOFUKU_AITSK_SHI_CD,
                NULL,
                iOPE_CD,
                iDATE,
                iPGM_ID,
                iOPE_CD,
                iDATE,
                iPGM_ID
            FROM TT_TIKY_SHI TTS
        LEFT OUTER JOIN TT_TIKY_KJN TTK
          ON  TTS.DAIHYO_REC_ID = TTK.REC_ID
          AND TTS.DAIHYO_KJN_CD = TTK.KJN_CD
          AND TTK.DEL_FLG IS NULL
        WHERE TTS.REC_ID = '00'
        AND TTS.DEL_FLG IS NULL;

        -- ���O��o�^����
              EXECUTE_SQL := '  INSERT INTO TD_PA_GEN_DCF_SHI(                                                    ' ||
                '                    SHIREC_ID,                                                     ' ||
                '                    SHI_CD,                                                        ' ||
                '                    SHI_CD_YOBI,                                                   ' ||
                '                    SEISHIKI_SHI_NM_KANA,                                          ' ||
                '                    RYKSK_SHI_NM_KANA,                                             ' ||
                '                    JUSHO_CD_KEN_CD,                                               ' ||
                '                    JUSHO_CD_SHIKU_CD,                                             ' ||
                '                    JUSHO_CD_OAZA_CD,                                              ' ||
                '                    JUSHO_CD_AZA_CD,                                               ' ||
                '                    ZIP,                                                           ' ||
                '                    JUSHO_HYOJI_NO,                                                ' ||
                '                    YOBI_1,                                                        ' ||
                '                    JUSHO_KANA,                                                    ' ||
                '                    JUSHO_COUNT_KANA_KEN,                                          ' ||
                '                    JUSHO_COUNT_KANA_SHIKU,                                        ' ||
                '                    JUSHO_COUNT_KANA_OAZA,                                         ' ||
                '                    JUSHO_COUNT_KANJI_KEN,                                         ' ||
                '                    JUSHO_COUNT_KANJI_SHIKU,                                       ' ||
                '                    JUSHO_COUNT_KANJI_OAZA,                                        ' ||
                '                    SHI_TEL,                                                       ' ||
                '                    BED_SU_TEIIN,                                                  ' ||
                '                    KEIEITAI,                                                      ' ||
                '                    SHI_KBN,                                                       ' ||
                '                    YOBI_2,                                                        ' ||
                '                    BYOIN_SBT,                                                     ' ||
                '                    KANREN_DAIGAKU_OYA_SHIREC_ID,                                  ' ||
                '                    KANREN_DAIGAKU_OYA_SHI_CD,                                     ' ||
                '                    KANREN_DAIGAKU_OYA_SHI_CD_YOBI,                                ' ||
                '                    STATUS_JUSHOFUMEI,                                             ' ||
                '                    STATUS_KYUIN_FLG,                                              ' ||
                '                    STATUS_DEL_YOTEI_RIYU,                                         ' ||
                '                    STATUS_KAIGYO_YOTEI_FLG,                                       ' ||
                '                    STATUS_BYOTO_HEISA_FLG,                                        ' ||
                '                    STATUS_YOBI,                                                   ' ||
                '                    STATUS_SAISHINSA_KBN,                                          ' ||
                '                    KYUIN_S_KAIGYO_YOTEI_Y,                                        ' ||
                '                    KYUIN_S_KAIGYO_YOTEI_M,                                        ' ||
                '                    KYOKA_BED_MENTE_HIZUKE_Y,                                      ' ||
                '                    KYOKA_BED_MENTE_HIZUKE_M,                                      ' ||
                '                    KYOKA_BED_MENTE_HIZUKE_D,                                      ' ||
                '                    KYOKA_BED_SU_SONOTA,                                           ' ||
                '                    KYOKA_BED_SU_SEISHIN,                                          ' ||
                '                    KYOKA_BED_SU_KEKKAKU,                                          ' ||
                '                    KYOKA_BED_SU_KANSEN,                                           ' ||
                '                    KYOKA_BED_SU_GOKEI,                                            ' ||
                '                    KENSAKOMOKU_BISEIBUTSU,                                        ' ||
                '                    KENSAKOMOKU_KESSEI,                                            ' ||
                '                    KENSAKOMOKU_KETSUEKI,                                          ' ||
                '                    KENSAKOMOKU_BYORI,                                             ' ||
                '                    KENSAKOMOKU_KISEICHU,                                          ' ||
                '                    KENSAKOMOKU_SEIKA,                                             ' ||
                '                    KENSAKOMOKU_RI,                                                ' ||
                '                    KENSAKOMOKU_YOBI,                                              ' ||
                '                    SNRYKMK_1,                                                     ' ||
                '                    SNRYKMK_2,                                                     ' ||
                '                    SNRYKMK_3,                                                     ' ||
                '                    SNRYKMK_4,                                                     ' ||
                '                    SNRYKMK_5,                                                     ' ||
                '                    SNRYKMK_6,                                                     ' ||
                '                    SNRYKMK_7,                                                     ' ||
                '                    SNRYKMK_8,                                                     ' ||
                '                    SNRYKMK_9,                                                     ' ||
                '                    SNRYKMK_10,                                                    ' ||
                '                    SNRYKMK_11,                                                    ' ||
                '                    SNRYKMK_12,                                                    ' ||
                '                    SNRYKMK_13,                                                    ' ||
                '                    SNRYKMK_14,                                                    ' ||
                '                    SNRYKMK_15,                                                    ' ||
                '                    SNRYKMK_16,                                                    ' ||
                '                    SNRYKMK_17,                                                    ' ||
                '                    SNRYKMK_18,                                                    ' ||
                '                    SNRYKMK_19,                                                    ' ||
                '                    SNRYKMK_20,                                                    ' ||
                '                    SNRYKMK_21,                                                    ' ||
                '                    SNRYKMK_22,                                                    ' ||
                '                    SNRYKMK_23,                                                    ' ||
                '                    SNRYKMK_24,                                                    ' ||
                '                    SNRYKMK_25,                                                    ' ||
                '                    SNRYKMK_26,                                                    ' ||
                '                    SNRYKMK_27,                                                    ' ||
                '                    SNRYKMK_28,                                                    ' ||
                '                    SNRYKMK_29,                                                    ' ||
                '                    SNRYKMK_30,                                                    ' ||
                '                    SNRYKMK_31,                                                    ' ||
                '                    SNRYKMK_32,                                                    ' ||
                '                    SNRYKMK_33,                                                    ' ||
                '                    SNRYKMK_34,                                                    ' ||
                '                    SNRYKMK_35,                                                    ' ||
                '                    SNRYKMK_36,                                                    ' ||
                '                    SNRYKMK_37,                                                    ' ||
                '                    SNRYKMK_38,                                                    ' ||
                '                    SNRYKMK_39,                                                    ' ||
                '                    SNRYKMK_40,                                                    ' ||
                '                    SEISHIKI_SHI_NM_KANJI,                                         ' ||
                '                    RYKSK_SHI_NM_KANJI,                                            ' ||
                '                    JUSHO_KANJI,                                                   ' ||
                '                    SHI_DAIHYO_KJNREC_ID,                                          ' ||
                '                    SHI_DAIHYO_KJN_CD,                                             ' ||
                '                    SHI_DAIHYO_KJN_CD_YOBI,                                        ' ||
                '                    SHI_DAIHYO_KANA,                                               ' ||
                '                    SHI_DAIHYO_KANJI,                                              ' ||
                '                    SHI_YOBI_AREA,                                                 ' ||
                '                    SHIN_BED_KBN_IPPAN_BED,                                        ' ||
                '                    SHIN_BED_KBN_RYOYO_BED,                                        ' ||
                '                    AITSK_CD_SHIREC_ID,                                            ' ||
                '                    AITSK_CD_SHI_CD,                                               ' ||
                '                    AITSK_CD_SHI_CD_YOBI,                                          ' ||
                '                    TRK_OPE_CD,                                                    ' ||
                '                    TRK_DATE,                                                      ' ||
                '                    TRK_PGM_ID,                                                    ' ||
                '                    UPD_OPE_CD,                                                    ' ||
                '                    UPD_DATE,                                                      ' ||
                '                    UPD_PGM_ID                                                   ' ||
                '                  )                                                                ' ||
                '          SELECT                                                                    ' ||
                '              ''00'',                                                                 ' ||
                '              TTS.SHI_CD,                                                           ' ||
                '              NULL,                                                                 ' ||
                '              TTS.SEISHIKI_SHI_NM_KANA40,                                           ' ||
                '              TTS.SHI_RN_KANA,                                                      ' ||
                '              TTS.KEN_CD,                                                           ' ||
                '              TTS.SHIKU_CD,                                                         ' ||
                '              TTS.OAZA_CD,                                                          ' ||
                '              TTS.AZA_CD,                                                           ' ||
                '              NVL2(TTS.ZIP,SUBSTR(TTS.ZIP,1,3)||''-''||SUBSTR(TTS.ZIP,4),NULL) AS ZIP,' ||
                '              TTS.JUSHO_HYOJI_NO,                                                   ' ||
                '              NULL,                                                                 ' ||
                '              TTS.JUSHO_KANA_RENKETSU,                                              ' ||
                '              TO_CHAR(TTS.KEN_NM_KANA_MOJI_SU,''FM09'') AS KEN_NM_KANA_MOJI_SU,       ' ||
                '              TO_CHAR(TTS.SHIKU_NM_KANA_MOJI_SU,''FM09'') AS SHIKU_NM_KANA_MOJI_SU,   ' ||
                '              TO_CHAR(TTS.OAZA_NM_KANA_MOJI_SU,''FM09'') AS OAZA_NM_KANA_MOJI_SU,     ' ||
                '              TO_CHAR(TTS.KEN_NM_KANJI_MOJI_SU,''FM09'') AS KEN_NM_KANJI_MOJI_SU,     ' ||
                '              TO_CHAR(TTS.SHIKU_NM_KANJI_MOJI_SU,''FM09'') AS SHIKU_NM_KANJI_MOJI_SU, ' ||
                '              TO_CHAR(TTS.OAZA_NM_KANJI_MOJI_SU,''FM09'') AS OAZA_NM_KANJI_MOJI_SU,   ' ||
                '              TTS.TEL,                                                              ' ||
                '              TO_CHAR(TTS.SHI_BED_SU,''FM0009'') AS SHI_BED_SU,                       ' ||
                '              TTS.KEIEITAI_CD,                                                      ' ||
                '              TTS.SHI_KBN_CD,                                                       ' ||
                '              NULL,                                                                 ' ||
                '              TTS.BYOIN_SBT_CD,                                                     ' ||
                '              TTS.KANREN_DAIGAKU_OYA_REC_ID,                                        ' ||
                '              TTS.KANREN_DAIGAKU_OYA_SHI_CD,                                        ' ||
                '              NULL,                                                                 ' ||
                '              TTS.JUSHOFUMEI_CD,                                                    ' ||
                '              TTS.KYUIN_FLG,                                                        ' ||
                '              TTS.DEL_YOTEI_RIYU_CD,                                                ' ||
                '              TTS.KAIGYO_YOTEI_FLG,                                                 ' ||
                '              TTS.BYOTO_HEISA_KBN,                                                  ' ||
                '              TTS.TEL_NASHI_FLG||TTS.MIKAKUNIN_FLG,                                 ' ||
                '              TTS.SAISHINSA_KBN_CD,                                                 ' ||
                '              CASE                                                                  ' ||
                '              WHEN TTS.KAIGYO_YOTEI_FLG=''1'' THEN SUBSTR(TTS.KAIGYO_YOTEI_YM,1,4)    ' ||
                '              WHEN TTS.KYUIN_FLG =''1'' THEN SUBSTR(TTS.KYUIN_S_YM,1,4)               ' ||
                '              ELSE NULL                                                             ' ||
                '              END AS KYUIN_S_KAIGYO_YOTEI_Y,                                        ' ||
                '              CASE                                                                  ' ||
                '              WHEN TTS.KAIGYO_YOTEI_FLG=''1'' THEN SUBSTR(TTS.KAIGYO_YOTEI_YM,5,2)    ' ||
                '              WHEN TTS.KYUIN_FLG =''1'' THEN SUBSTR(TTS.KYUIN_S_YM,5,2)               ' ||
                '              ELSE NULL                                                             ' ||
                '              END AS KYUIN_S_KAIGYO_YOTEI_M,                                        ' ||
                '              SUBSTR(TTS.BED_SU_KKNN_EIGY_YMD,1,4) AS KYOKA_BED_MENTE_HIZUKE_Y,     ' ||
                '              SUBSTR(TTS.BED_SU_KKNN_EIGY_YMD,5,2) AS KYOKA_BED_MENTE_HIZUKE_M,     ' ||
                '              SUBSTR(TTS.BED_SU_KKNN_EIGY_YMD,7,2) AS KYOKA_BED_MENTE_HIZUKE_D,     ' ||
                '              TO_CHAR(TTS.KYOKA_BED_SU_SONOTA,''FM0009'') AS KYOKA_BED_SU_SONOTA,     ' ||
                '              TO_CHAR(TTS.KYOKA_BED_SU_SEISHIN,''FM0009'') AS KYOKA_BED_SU_SEISHIN,   ' ||
                '              TO_CHAR(TTS.KYOKA_BED_SU_KEKKAKU,''FM0009'') AS KYOKA_BED_SU_KEKKAKU,   ' ||
                '              TO_CHAR(TTS.KYOKA_BED_SU_KANSEN,''FM0009'') AS KYOKA_BED_SU_KANSEN,     ' ||
                '              TO_CHAR(TTS.KYOKA_BED_SU_GOKEI,''FM0009'') AS KYOKA_BED_SU_GOKEI,       ' ||
                '              TTS.KENSAKOMOKU_BISEIBUTSU_FLG,                                       ' ||
                '              TTS.KENSAKOMOKU_KESSEI_FLG,                                           ' ||
                '              TTS.KENSAKOMOKU_KETSUEKI_FLG,                                         ' ||
                '              TTS.KENSAKOMOKU_BYORI_FLG,                                            ' ||
                '              TTS.KENSAKOMOKU_KISEICHU_FLG,                                         ' ||
                '              TTS.KENSAKOMOKU_SEIKA_FLG,                                            ' ||
                '              TTS.KENSAKOMOKU_RI_FLG,                                               ' ||
                '              NULL,                                                                 ' ||
                '              TTS.SNRYKMK_CD_01,                                                    ' ||
                '              TTS.SNRYKMK_CD_02,                                                    ' ||
                '              TTS.SNRYKMK_CD_03,                                                    ' ||
                '              TTS.SNRYKMK_CD_04,                                                    ' ||
                '              TTS.SNRYKMK_CD_05,                                                    ' ||
                '              TTS.SNRYKMK_CD_06,                                                    ' ||
                '              TTS.SNRYKMK_CD_07,                                                    ' ||
                '              TTS.SNRYKMK_CD_08,                                                    ' ||
                '              TTS.SNRYKMK_CD_09,                                                    ' ||
                '              TTS.SNRYKMK_CD_10,                                                    ' ||
                '              TTS.SNRYKMK_CD_11,                                                    ' ||
                '              TTS.SNRYKMK_CD_12,                                                    ' ||
                '              TTS.SNRYKMK_CD_13,                                                    ' ||
                '              TTS.SNRYKMK_CD_14,                                                    ' ||
                '              TTS.SNRYKMK_CD_15,                                                    ' ||
                '              TTS.SNRYKMK_CD_16,                                                    ' ||
                '              TTS.SNRYKMK_CD_17,                                                    ' ||
                '              TTS.SNRYKMK_CD_18,                                                    ' ||
                '              TTS.SNRYKMK_CD_19,                                                    ' ||
                '              TTS.SNRYKMK_CD_20,                                                    ' ||
                '              TTS.SNRYKMK_CD_21,                                                    ' ||
                '              TTS.SNRYKMK_CD_22,                                                    ' ||
                '              TTS.SNRYKMK_CD_23,                                                    ' ||
                '              TTS.SNRYKMK_CD_24,                                                    ' ||
                '              TTS.SNRYKMK_CD_25,                                                    ' ||
                '              TTS.SNRYKMK_CD_26,                                                    ' ||
                '              TTS.SNRYKMK_CD_27,                                                    ' ||
                '              TTS.SNRYKMK_CD_28,                                                    ' ||
                '              TTS.SNRYKMK_CD_29,                                                    ' ||
                '              TTS.SNRYKMK_CD_30,                                                    ' ||
                '              TTS.SNRYKMK_CD_31,                                                    ' ||
                '              TTS.SNRYKMK_CD_32,                                                    ' ||
                '              TTS.SNRYKMK_CD_33,                                                    ' ||
                '              TTS.SNRYKMK_CD_34,                                                    ' ||
                '              TTS.SNRYKMK_CD_35,                                                    ' ||
                '              TTS.SNRYKMK_CD_36,                                                    ' ||
                '              TTS.SNRYKMK_CD_37,                                                    ' ||
                '              TTS.SNRYKMK_CD_38,                                                    ' ||
                '              TTS.SNRYKMK_CD_39,                                                    ' ||
                '              TTS.SNRYKMK_CD_40,                                                    ' ||
                '              TTS.SEISHIKI_SHI_NM30,                                                ' ||
                '              TTS.SHI_RN,                                                           ' ||
                '              TTS.JUSHO_KANJI_RENKETSU,                                             ' ||
                '              TTS.DAIHYO_REC_ID,                                                    ' ||
                '              TTS.DAIHYO_KJN_CD,                                                    ' ||
                '              NULL,                                                                 ' ||
                '              TTK.KJN_NM_KANA,                                                      ' ||
                '              TTK.KJN_NM,                                                           ' ||
                '              NULL,                                                                 ' ||
                '              TO_CHAR(TTS.KYOKA_BED_SU_IPPAN,''FM0009'') AS KYOKA_BED_SU_IPPAN,       ' ||
                '              TO_CHAR(TTS.KYOKA_BED_SU_RYOYO,''FM0009'') AS KYOKA_BED_SU_RYOYO,       ' ||
                '              TTS.CHOFUKU_AITSK_REC_ID,                                             ' ||
                '              TTS.CHOFUKU_AITSK_SHI_CD,                                             ' ||
                '              NULL,                                                                 ' ||
                              iOPE_CD                                                   ||     ',' ||
                              iDATE                                                     ||     ',' ||
                              iPGM_ID                                                   ||     ',' ||
                              iOPE_CD                                                   ||     ',' ||
                              iDATE                                                     ||     ',' ||
                              iPGM_ID                                                   ||
                '          FROM TT_TIKY_SHI TTS                                                      ' ||
                '      LEFT OUTER JOIN TT_TIKY_KJN TTK                                                ' ||
                '        ON  TTS.DAIHYO_REC_ID = TTK.REC_ID                                           ' ||
                '        AND TTS.DAIHYO_KJN_CD = TTK.KJN_CD                                           ' ||
                '        AND TTK.DEL_FLG IS NULL                                                      ' ||
                '      WHERE TTS.REC_ID = ' || '''00''' ||
                '      AND TTS.DEL_FLG IS NULL                                                        ' ;
        ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);        
      END IF;

      commit;

      -- �I�����O�o��
       ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'PL/SQL End',PGM_ID || '�̏������I�����܂����B',iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

      oROW_COUNT:=-1;

      return 0;
    -- ��O����
  EXCEPTION
    -- ���̑��G���[
    WHEN OTHERS THEN
      W_ERR_INF_RCD.ERR_CD     := TO_CHAR(SQLCODE);
      W_ERR_INF_RCD.ERR_MSG     := SUBSTR(SQLERRM, 0, 500);
      W_ERR_INF_RCD.ERR_KEY_INF   := SUBSTR('iLayoutKind:' || iLayoutKind || ', iShimeKind:' || iShimeKind , 0,500);
      W_INDEX_N           := W_ERR_INF_TBL.COUNT + 1;
      W_ERR_INF_TBL.EXTEND;
      W_ERR_INF_TBL(W_INDEX_N)   := W_ERR_INF_RCD;

      OPEN oOUT_ERR_INF_CSR FOR
        SELECT * FROM TABLE(W_ERR_INF_TBL);
      ROLLBACK;

      --�G���[���O�̓o�^
      ULT_INSERT_LOG_TABLE('ERROR',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'ERROR_INFO',W_ERR_INF_RCD.ERR_MSG,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

      RAISE;
  END;

END;
/
