CREATE OR REPLACE PACKAGE NH010106B001_135
/* **********************************************************
 *  Copyright(c) 2011 beyond, INTEC Inc. All rights reserved.
 * **********************************************************/
AUTHID CURRENT_USER
IS
	/*** �J�[�\���^ ***************************************************************/
	-- �G���[���i�[�p�J�[�\���^
	TYPE ERR_INF_CSR		IS REF CURSOR;

	/*
	************************************************************************
	*  �s���{����Ë@�\���t�@�C���iCSV�F�Z���؍ݎ�p�j�f��DB�f�[�^�̍쐬
	*  CREATE_KEN_IKJ_TTS
	************************************************************************
	*/
	FUNCTION CREATE_KEN_IKJ_TTS(
	iLayoutKind	IN	INTEGER,										-- ���C�A�E�g�敪
	iShimeKind	IN	INTEGER,										-- ���ߓ��敪
     iTensoYMD	IN	VARCHAR2,										-- �]���N���� 
	iIP_ADDR	IN TL_STORED_SHORI.IP%TYPE,							-- ���s�[��IP�A�h���X (FW�Őݒ�)
	iWINDOWS_LOGIN_USER	IN TL_STORED_SHORI.WINDOWS_LOGIN_USER%TYPE, -- ���s�[��OS���[�U�[ (FW�Őݒ�)
	oROW_COUNT	OUT NUMBER,         -- �o�^����
	oOUT_ERR_INF_CSR 	OUT ERR_INF_CSR,    -- �G���[���J�[�\��
     iOPE_CD IN Varchar2,                      -- �I�y���[�^�R�[�h
     iPGM_ID IN Varchar2,                      -- �v���O����ID
     iDATE DATE                              -- �V�X�e������
	) RETURN NUMBER;
    
END;
/
CREATE OR REPLACE PACKAGE BODY NH010106B001_135
/* **********************************************************
 *  Copyright(c) 2011 beyond, INTEC Inc. All rights reserved.
 * **********************************************************/
IS
	/*
	 ************************************************************************
	 * Function ID  : CREATE_KEN_IKJ_TTS
	 * Program Name : �s���{����Ë@�\���t�@�C���iCSV�F(�Z���؍ݎ�p�j�f��DB�f�[�^�̍쐬
	 * Parameter    :  <I> iLayoutKind	    	�F���C�A�E�g�敪
	 *		   		   <I> iShimeKind	    	�F���ߓ��敪
	 *				   <I> iTensoYMD	    	�F�]���N����
	 *				   <I> iOPE_CD		        �F�I�y���[�^�R�[�h
	 *				   <I> iPGM_ID		        �F�v���O����ID
	 *				   <I> iDATE		        �F�V�X�e������ 
	 *		           <I> iIP_ADDR		        �F���s�[��IP�A�h���X
	 *		           <I> iWINDOWS_LOGIN_USER  �F���s�[��IP�A�h���X
	 *                 <O> oROW_COUNT		    �F�X�V����
	 *                <O> oOUT_ERR_INF_CSR	�F�G���[���J�[�\��
	 * Return       �F�������ʁi0:����I���A1:�ُ�I���j
	 ************************************************************************
	 */
	FUNCTION CREATE_KEN_IKJ_TTS(
	iLayoutKind	IN	INTEGER,										-- ���C�A�E�g�敪
	iShimeKind	IN	INTEGER,										-- ���ߓ��敪
	iTensoYMD	IN	VARCHAR2,										-- �]���N����
	iIP_ADDR	IN TL_STORED_SHORI.IP%TYPE,							-- ���s�[��IP�A�h���X (FW�Őݒ�)
	iWINDOWS_LOGIN_USER	IN TL_STORED_SHORI.WINDOWS_LOGIN_USER%TYPE, -- ���s�[��OS���[�U�[ (FW�Őݒ�)
	oROW_COUNT	OUT NUMBER,                                         -- �o�^����
	oOUT_ERR_INF_CSR 	OUT ERR_INF_CSR,                            -- �G���[���J�[�\��
	iOPE_CD IN Varchar2,                                            -- �I�y���[�^�R�[�h
	iPGM_ID IN Varchar2,                                            -- �v���O����ID
	iDATE DATE                                                      -- �V�X�e������  
	)RETURN NUMBER IS

  PRAGMA AUTONOMOUS_TRANSACTION;
	/************************************************************************/
	/*                              �G���[����                              */
	/************************************************************************/
	W_INDEX_N 				NUMBER(10) := 0;
	W_ERR_INF_TBL 				TYPE_ERR_INFO_TBL := TYPE_ERR_INFO_TBL();
	W_ERR_INF_RCD 				TYPE_ERR_INFO_RCD := TYPE_ERR_INFO_RCD(NULL,NULL,NULL,NULL);
	vSQL VARCHAR2(200);
        vSchemaNm     TM_JOSU.HANYO_KOMOKU%TYPE := NULL; -- �X�L�[�}����
	PGM_ID        VARCHAR2(50) := 'NH010106B001_135.CREATE_KEN_IKJ_TTS';
	EXECUTE_SQL   VARCHAR2(32767) := NULL;  

	BEGIN
	 -- �J�n���O�o��
        ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'PL/SQL Start',PGM_ID || '�̏������J�n���܂��B',iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);
        -- �[�i�p�X�L�[�}�̎擾���s���B
	vSchemaNm := ULT_COMMON.GET_SCHEMA_NAME(ULT_COMMON.SYS_ENV_JOSU_DAI_CD, ULT_COMMON.NOHIN_SHEMA_JOSU_SHO_CD);
	oROW_COUNT:= -1;
          -- �V���C�A�E�g
	  IF iLayoutKind = 1 THEN

             --�V_�S��_��Ë@�\���_CSV_���O���̃f�[�^���N���A����B
             EXECUTE_SQL := 'TRUNCATE TABLE ' || vSchemaNm || '.' || 'TD_NA_IKJ_CSV_TTS';
             EXECUTE IMMEDIATE EXECUTE_SQL;
             ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);
             
             INSERT INTO TD_NA_IKJ_CSV_TTS(
                          LAYOUT_KBN,												
	                  DCF_CD_REC_ID,												
                          DCF_CD_SHI_CD,												
                          DCF_CD_YOBI,												
		          MOD_KBN,											
		          TNK_TIZI_SJT_CD,											
                          YOBI_1,
                          MENTE_YMD,
                          YOBI_2,
                          TSUIKA_DEL_KBN,
                          TENSO_YMD,
		          TRK_OPE_CD,
		          TRK_DATE,
		          TRK_PGM_ID,
		          UPD_OPE_CD,
		          UPD_DATE,
		          UPD_PGM_ID)
               SELECT
                    '135',
                    '00',
                    TTS.SHI_CD,
                    NULL,
                    NULL,
                    TTS.TNK_TIZI_SJT_CD,
                    NULL,
                    CASE WHEN iShimeKind = 1 THEN TTS.UPD_EIGY_YMD ELSE NULL END,
                    NULL,
                    NULL,
                    CASE WHEN iShimeKind = 1 THEN iTensoYMD ELSE NULL END,
                    iOPE_CD,
                    iDATE,
                    iPGM_ID,
                    iOPE_CD,
                    iDATE,
                    iPGM_ID
             FROM TT_TIKY_SHI SHI									
	     INNER JOIN TT_TIKY_IKJ_KIHON IK ON (										
             IK.REC_ID = SHI.REC_ID									
	     AND IK.SHI_CD = SHI.SHI_CD)
	     INNER JOIN TT_TIKY_IKJ_TNK_TIZI_SJT TTS ON (										
	     TTS.REC_ID = SHI.REC_ID									
	     AND TTS.SHI_CD = SHI.SHI_CD)
             WHERE SHI.REC_ID = '00'							
	        AND SHI.DEL_FLG IS NULL
		AND (IK.JOHO_YMD IS NOT NULL														
		OR IK.ANNAIYO_URL IS NOT NULL														
		OR IK.INNAI_SHOHO_FLG IS NOT NULL														
		OR IK.INGAI_SHOHO_FLG IS NOT NULL														
		OR IK.CHIKENJISSHI_FLG IS NOT NULL														
		OR IK.CHIKENJISSHI_S_YMD IS NOT NULL														
		OR IK.CHIKENJISSHI_E_YMD IS NOT NULL														
		OR IK.CHIKENJISSHI_KIYK_KENSU IS NOT NULL														
		OR IK.CHIKRENKEI_MADOGUCHI_FLG IS NOT NULL														
		OR IK.CHIKRENKEIPATH_FLG_IKJ IS NOT NULL														
		OR IK.NYUINSNRY_INNAI_RNKITISI_FLG IS NOT NULL														
		OR IK.ORDERINGSYSTEM_FLG IS NOT NULL														
		OR IK.ORDERINGSYSTEM_KENSA_FLG IS NOT NULL														
		OR IK.ORDERINGSYSTEM_SHOHO_FLG IS NOT NULL														
		OR IK.ORDERINGSYSTEM_YOYAKU_FLG IS NOT NULL														
		OR IK.ICD_CD_RIYO_FLG IS NOT NULL														
		OR IK.DENSHI_KARTE_FLG IS NOT NULL														
		OR IK.KARTEKANRI_SENNIN_FLG IS NOT NULL														
		OR IK.KARTEKANRI_SENNIN_SU IS NOT NULL														
		OR IK.COMMENTS IS NOT NULL														
		OR IK.KANJYASU_IPPAN_BED IS NOT NULL														
		OR IK.KANJYASU_RYOYO_BED IS NOT NULL														
		OR IK.KANJYASU_RYOYO_BED_IRY_HKN IS NOT NULL														
		OR IK.KANJYASU_RYOYO_BED_KIG_HKN IS NOT NULL														
		OR IK.KANJYASU_SEISHIN_BED IS NOT NULL														
		OR IK.KANJYASU_KEKKAKU_BED IS NOT NULL														
		OR IK.KANJYASU_KANSEN IS NOT NULL														
		OR IK.KANJYASU_ZENTAI_BED IS NOT NULL														
		OR IK.KANJYASU_BED_SBT_S_YMD IS NOT NULL														
		OR IK.KANJYASU_BED_SBT_E_YMD IS NOT NULL														
		OR IK.KANJYASU_GAIRAI IS NOT NULL														
		OR IK.KANJYASU_GAIRAI_S_YMD IS NOT NULL														
		OR IK.KANJYASU_GAIRAI_E_YMD IS NOT NULL														
		OR IK.KANJYASU_ZAITAKU IS NOT NULL														
		OR IK.KANJYASU_ZAITAKU_S_YMD IS NOT NULL														
		OR IK.KANJYASU_ZAITAKU_E_YMD IS NOT NULL														
		OR IK.KANJYANSU_IPPAN_BED IS NOT NULL														
		OR IK.KANJYANSU_RYOYO_BED IS NOT NULL														
		OR IK.KANJYANSU_RYOYO_BED_IRY_HKN IS NOT NULL														
		OR IK.KANJYANSU_RYOYO_BED_KIG_HKN IS NOT NULL														
		OR IK.KANJYANSU_SEISHIN_BED IS NOT NULL														
		OR IK.KANJYANSU_KEKKAKU_BED IS NOT NULL														
		OR IK.KANJYANSU_KANSEN IS NOT NULL														
		OR IK.KANJYANSU_ZENTAI_BED IS NOT NULL														
		OR IK.KANJYANSU_BED_SBT_S_YMD IS NOT NULL														
		OR IK.KANJYANSU_BED_SBT_E_YMD IS NOT NULL														
		OR IK.KANJYANSU_GAIRAI IS NOT NULL														
		OR IK.KANJYANSU_GAIRAI_S_YMD IS NOT NULL														
		OR IK.KANJYANSU_GAIRAI_E_YMD IS NOT NULL														
		OR IK.KANJYANSU_ZAITAKU IS NOT NULL														
		OR IK.KANJYANSU_ZAITAKU_S_YMD IS NOT NULL														
		OR IK.KANJYANSU_ZAITAKU_E_YMD IS NOT NULL														
		OR IK.AVGNISSU_IPPAN_BED IS NOT NULL														
		OR IK.AVGNISSU_RYOYO_BED IS NOT NULL														
		OR IK.AVGNISSU_RYOYO_BED_IRY_HKN IS NOT NULL														
		OR IK.AVGNISSU_RYOYO_BED_KIG_HKN IS NOT NULL														
		OR IK.AVGNISSU_SEISHIN_BED IS NOT NULL														
		OR IK.AVGNISSU_KEKKAKU_BED IS NOT NULL														
		OR IK.AVGNISSU_KANSEN IS NOT NULL														
		OR IK.AVGNISSU_ZENTAI_BED IS NOT NULL)														
	        AND IK.DEL_FLG IS NULL								
	        AND TTS.HAISHI_FLG  IS NULL;								

	       EXECUTE_SQL :=  'INSERT INTO TD_NA_IKJ_CSV_TTS('||
                          'LAYOUT_KBN,				'||								
	                  'DCF_CD_REC_ID,			'||									
                          'DCF_CD_SHI_CD,			'||									
                          'DCF_CD_YOBI,				'||								
		          'MOD_KBN,				'||							
		          'TNK_TIZI_SJT_CD,			'||								
                          'YOBI_1,'||
                          'MENTE_YMD,'||
                          'YOBI_2,'||
                          'TSUIKA_DEL_KBN,'||
                          'TENSO_YMD,'||
		          'TRK_OPE_CD,'||
		          'TRK_DATE,'||
		          'TRK_PGM_ID,'||
		          'UPD_OPE_CD,'||
		          'UPD_DATE,'||
		          'UPD_PGM_ID)'||
          '    SELECT                                                          '||
                    '''135'''  || ','                                        ||
                    '''00'''   || ','                                        ||
                    'TTS.SHI_CD,'||
                    'NULL,'||
                    'NULL,'||
                    'TTS.TNK_TIZI_SJT_CD,'||
                    'NULL,'||
                    'CASE WHEN iShimeKind = 1 THEN TTS.UPD_EIGY_YMD ELSE NULL END,'||
                    'NULL,'||
                    'NULL,'||
                    'CASE WHEN iShimeKind = 1 THEN iTensoYMD ELSE NULL END,'||
                    'iOPE_CD,'||
                    'iDATE,'||
                    'iPGM_ID,'||
                    'iOPE_CD,'||
                    'iDATE,'||
                    'iPGM_ID'||
             'FROM TT_TIKY_SHI SHI'||									
	     'INNER JOIN TT_TIKY_IKJ_KIHON IK ON (		'||								
             'IK.REC_ID = SHI.REC_ID				'||					
	     'AND IK.SHI_CD = SHI.SHI_CD)'||
	     'INNER JOIN TT_TIKY_IKJ_TNK_TIZI_SJT TTS ON (	'||									
	     'TTS.REC_ID = SHI.REC_ID				'||					
	     'AND TTS.SHI_CD = SHI.SHI_CD)'||
             'WHERE SHI.REC_ID = ''00''	'||						
	        'AND SHI.DEL_FLG IS NULL'||
		'AND (IK.JOHO_YMD IS NOT NULL			'||											
		'OR IK.ANNAIYO_URL IS NOT NULL			'||											
		'OR IK.INNAI_SHOHO_FLG IS NOT NULL		'||												
		'OR IK.INGAI_SHOHO_FLG IS NOT NULL		'||												
		'OR IK.CHIKENJISSHI_FLG IS NOT NULL		'||												
		'OR IK.CHIKENJISSHI_S_YMD IS NOT NULL		'||												
		'OR IK.CHIKENJISSHI_E_YMD IS NOT NULL		'||												
		'OR IK.CHIKENJISSHI_KIYK_KENSU IS NOT NULL	'||													
		'OR IK.CHIKRENKEI_MADOGUCHI_FLG IS NOT NULL	'||													
		'OR IK.CHIKRENKEIPATH_FLG_IKJ IS NOT NULL	'||													
		'OR IK.NYUINSNRY_INNAI_RNKITISI_FLG IS NOT NULL	'||													
		'OR IK.ORDERINGSYSTEM_FLG IS NOT NULL		'||												
		'OR IK.ORDERINGSYSTEM_KENSA_FLG IS NOT NULL	'||													
		'OR IK.ORDERINGSYSTEM_SHOHO_FLG IS NOT NULL	'||													
		'OR IK.ORDERINGSYSTEM_YOYAKU_FLG IS NOT NULL	'||													
		'OR IK.ICD_CD_RIYO_FLG IS NOT NULL		'||												
		'OR IK.DENSHI_KARTE_FLG IS NOT NULL		'||												
		'OR IK.KARTEKANRI_SENNIN_FLG IS NOT NULL	'||													
		'OR IK.KARTEKANRI_SENNIN_SU IS NOT NULL		'||												
		'OR IK.COMMENTS IS NOT NULL			'||											
		'OR IK.KANJYASU_IPPAN_BED IS NOT NULL		'||												
		'OR IK.KANJYASU_RYOYO_BED IS NOT NULL		'||												
		'OR IK.KANJYASU_RYOYO_BED_IRY_HKN IS NOT NULL	'||													
		'OR IK.KANJYASU_RYOYO_BED_KIG_HKN IS NOT NULL	'||													
		'OR IK.KANJYASU_SEISHIN_BED IS NOT NULL		'||												
		'OR IK.KANJYASU_KEKKAKU_BED IS NOT NULL		'||												
		'OR IK.KANJYASU_KANSEN IS NOT NULL		'||												
		'OR IK.KANJYASU_ZENTAI_BED IS NOT NULL		'||												
		'OR IK.KANJYASU_BED_SBT_S_YMD IS NOT NULL	'||													
		'OR IK.KANJYASU_BED_SBT_E_YMD IS NOT NULL	'||													
		'OR IK.KANJYASU_GAIRAI IS NOT NULL		'||												
		'OR IK.KANJYASU_GAIRAI_S_YMD IS NOT NULL	'||													
		'OR IK.KANJYASU_GAIRAI_E_YMD IS NOT NULL	'||													
		'OR IK.KANJYASU_ZAITAKU IS NOT NULL		'||												
		'OR IK.KANJYASU_ZAITAKU_S_YMD IS NOT NULL	'||													
		'OR IK.KANJYASU_ZAITAKU_E_YMD IS NOT NULL	'||													
		'OR IK.KANJYANSU_IPPAN_BED IS NOT NULL		'||												
		'OR IK.KANJYANSU_RYOYO_BED IS NOT NULL		'||												
		'OR IK.KANJYANSU_RYOYO_BED_IRY_HKN IS NOT NULL	'||													
		'OR IK.KANJYANSU_RYOYO_BED_KIG_HKN IS NOT NULL	'||													
		'OR IK.KANJYANSU_SEISHIN_BED IS NOT NULL	'||													
		'OR IK.KANJYANSU_KEKKAKU_BED IS NOT NULL	'||													
		'OR IK.KANJYANSU_KANSEN IS NOT NULL		'||												
		'OR IK.KANJYANSU_ZENTAI_BED IS NOT NULL		'||												
		'OR IK.KANJYANSU_BED_SBT_S_YMD IS NOT NULL	'||													
		'OR IK.KANJYANSU_BED_SBT_E_YMD IS NOT NULL	'||													
		'OR IK.KANJYANSU_GAIRAI IS NOT NULL		'||												
		'OR IK.KANJYANSU_GAIRAI_S_YMD IS NOT NULL	'||													
		'OR IK.KANJYANSU_GAIRAI_E_YMD IS NOT NULL	'||													
		'OR IK.KANJYANSU_ZAITAKU IS NOT NULL		'||												
		'OR IK.KANJYANSU_ZAITAKU_S_YMD IS NOT NULL	'||													
		'OR IK.KANJYANSU_ZAITAKU_E_YMD IS NOT NULL	'||													
		'OR IK.AVGNISSU_IPPAN_BED IS NOT NULL		'||												
		'OR IK.AVGNISSU_RYOYO_BED IS NOT NULL		'||												
		'OR IK.AVGNISSU_RYOYO_BED_IRY_HKN IS NOT NULL	'||													
		'OR IK.AVGNISSU_RYOYO_BED_KIG_HKN IS NOT NULL	'||													
		'OR IK.AVGNISSU_SEISHIN_BED IS NOT NULL		'||												
		'OR IK.AVGNISSU_KEKKAKU_BED IS NOT NULL		'||												
		'OR IK.AVGNISSU_KANSEN IS NOT NULL		'||												
		'OR IK.AVGNISSU_ZENTAI_BED IS NOT NULL)		'||												
	        'AND IK.DEL_FLG IS NULL				'||				
	        'AND TTS.HAISHI_FLG  IS NULL';		
	       ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

        -- �b�背�C�A�E�g
        ELSIF iLayoutKind = 2 THEN
               IF iShimeKind = 4 OR iShimeKind = 5 THEN
		--�b��S����Ë@�\(�Z���؍ݎ�p)�e�[�u���̃f�[�^���N���A����B
                EXECUTE_SQL := 'TRUNCATE TABLE ' || vSchemaNm || '.' || 'TD_PA_IKJ_TTS';
                EXECUTE IMMEDIATE EXECUTE_SQL;
                ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);
                
                INSERT INTO TD_PA_IKJ_TTS(
		         DCF_CD_REC_ID,											
		         DCF_CD_SHI_CD,											
		         TNK_TIZI_SJT_CD,
                         TRK_OPE_CD,
		         TRK_DATE,
		         TRK_PGM_ID,
		         UPD_OPE_CD,
		         UPD_DATE,
		         UPD_PGM_ID)
                SELECT
                      '00',
                       TTS.SHI_CD,
                       TTS.TNK_TIZI_SJT_CD,
                       iOPE_CD,
                       iDATE,
                       iPGM_ID,
                       iOPE_CD,
                       iDATE,
                       iPGM_ID
                FROM TT_TIKY_SHI SHI									
	        INNER JOIN TT_TIKY_IKJ_KIHON IK ON (										
	        IK.REC_ID = SHI.REC_ID									
	        AND IK.SHI_CD = SHI.SHI_CD )
	        INNER JOIN TT_TIKY_IKJ_TNK_TIZI_SJT TTS ON (										
	        TTS.REC_ID = SHI.REC_ID									
	        AND TTS.SHI_CD = SHI.SHI_CD )
                WHERE SHI.REC_ID = '00'							
	        AND SHI.DEL_FLG IS NULL
	        AND IK.DEL_FLG IS NULL	
                AND TTS.HAISHI_FLG IS NULL;	           
	        --�b��S����Ë@�\(�Z���؍ݎ�p)
	        EXECUTE_SQL :=  'INSERT INTO TD_PA_IKJ_TTS(' ||
		         'DCF_CD_REC_ID,		' ||									
		         'DCF_CD_SHI_CD,		' ||									
		         'TNK_TIZI_SJT_CD,' ||
                         'TRK_OPE_CD,' ||
		         'TRK_DATE,' ||
		         'TRK_PGM_ID,' ||
		         'UPD_OPE_CD,' ||
		         'UPD_DATE,' ||
		         'UPD_PGM_ID)' ||
                 '     SELECT                                           ' ||
                       '''00'''  || ',' ||
                       'TTS.SHI_CD,' ||
                       'TTS.TNK_TIZI_SJT_CD,' ||
                       'iOPE_CD,' ||
                       'iDATE,' ||
                       'iPGM_ID,' ||
                       'iOPE_CD,' ||
                       'iDATE,' ||
                       'iPGM_ID' ||
                'FROM TT_TIKY_SHI SHI	' ||								
	        'INNER JOIN TT_TIKY_IKJ_KIHON IK ON (		' ||								
	        'IK.REC_ID = SHI.REC_ID				' ||					
	        'AND IK.SHI_CD = SHI.SHI_CD )' ||
	        'INNER JOIN TT_TIKY_IKJ_TNK_TIZI_SJT TTS ON (	' ||									
	        'TTS.REC_ID = SHI.REC_ID			' ||						
	        'AND TTS.SHI_CD = SHI.SHI_CD )' ||
                'WHERE SHI.REC_ID = ''00''	' ||						
	        'AND SHI.DEL_FLG IS NULL' ||
	        'AND IK.DEL_FLG IS NULL	' ||
                'AND TTS.HAISHI_FLG IS NULL';
		ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

        END IF; 
      END IF;
      COMMIT;
      -- �I�����O�o��
      ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'PL/SQL End',PGM_ID || '�̏������I�����܂����B',iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);
      return 0;
    -- ��O����
	EXCEPTION
		-- ���̑��G���[
		WHEN OTHERS THEN
			W_ERR_INF_RCD.ERR_CD 		:= TO_CHAR(SQLCODE);
			W_ERR_INF_RCD.ERR_MSG 		:= SUBSTR(SQLERRM, 0, 500);
			W_ERR_INF_RCD.ERR_KEY_INF 	:= SUBSTR('iLayoutKind:' || iLayoutKind || ', iShimeKind:' || iShimeKind , 0,500);
			W_INDEX_N 			:= W_ERR_INF_TBL.COUNT + 1;
			W_ERR_INF_TBL.EXTEND;
			W_ERR_INF_TBL(W_INDEX_N) 	:= W_ERR_INF_RCD;

			OPEN oOUT_ERR_INF_CSR FOR
				SELECT * FROM TABLE(W_ERR_INF_TBL);

	   ROLLBACK;
       
	   --�G���[���O�̓o�^
           ULT_INSERT_LOG_TABLE('ERROR',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'ERROR_INFO',W_ERR_INF_RCD.ERR_MSG,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

        RETURN 1;
        END;
    END;
/

