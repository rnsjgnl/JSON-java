CREATE OR REPLACE PACKAGE NH010106B001_000
/* **********************************************************
 *  Copyright(c) 2011 beyond, INTEC Inc. All rights reserved.
 * **********************************************************/
AUTHID CURRENT_USER
IS
	/*** �J�[�\���^ ***************************************************************/
	-- �G���[���i�[�p�J�[�\���^
	TYPE ERR_INF_CSR		IS REF CURSOR;

	/*
	************************************************************************
	*  �e��e�[�u��(�R�[�h�\)�f��DB�f�[�^�̍쐬
	*  CREATE_KAKUSHU_TBL
	************************************************************************
	*/
	FUNCTION CREATE_KAKUSHU_TBL(
	iLayoutKind	IN	INTEGER,					 -- ���C�A�E�g�敪
	iShimeKind	IN	INTEGER,					 -- ���ߓ��敪
	iTensoYMD	IN	VARCHAR2,					 -- �]���N����
	iOPE_CD 	IN	VARCHAR2,                               	 -- �I�y���[�^�R�[�h
	iPGM_ID 	IN	VARCHAR2,                               	 -- �v���O����ID
	iDATE DATE,                                                     	 -- �V�X�e������
	iIP_ADDR	IN 	TL_STORED_SHORI.IP%TYPE,			 -- ���s�[��IP�A�h���X (FW�Őݒ�)
	iWINDOWS_LOGIN_USER	IN 	TL_STORED_SHORI.WINDOWS_LOGIN_USER%TYPE, -- ���s�[��OS���[�U�[ (FW�Őݒ�)
	oROW_COUNT	OUT 	NUMBER,                                          -- �o�^����
	oOUT_ERR_INF_CSR 	OUT 	ERR_INF_CSR                              -- �G���[���J�[�\��
	) RETURN NUMBER;

END;
/

CREATE OR REPLACE PACKAGE BODY NH010106B001_000
/* **********************************************************
 *  Copyright(c) 2011 beyond, INTEC Inc. All rights reserved.
 * **********************************************************/
IS
	/*
	 ************************************************************************
	 * Function ID  : CREATE_KAKUSHU_TBL
	 * Program Name : �e��e�[�u��(�R�[�h�\)�f��DB�f�[�^�̍쐬
	 * Parameter    :  <I> iLayoutKind	    	�F���C�A�E�g�敪
	 *		   <I> iShimeKind	    	�F���ߓ��敪
	 *		   <I> iTensoYMD	    	�F�]���N����
	 *		   <I> iOPE_CD		        �F�I�y���[�^�R�[�h
	 *		   <I> iPGM_ID		        �F�v���O����ID
	 *		   <I> iDATE		        �F�V�X�e������ 
	 *		   <I> iIP_ADDR		        �F���s�[��IP�A�h���X
	 *		   <I> iWINDOWS_LOGIN_USER  	�F���s�[��IP�A�h���X
	 *                 <O> oROW_COUNT		�F�X�V����
	 *                 <O> oOUT_ERR_INF_CSR		�F�G���[���J�[�\��
	 * Return       �F�������ʁi0:����I���A1:�ُ�I���j
	 ************************************************************************
	 */
	FUNCTION CREATE_KAKUSHU_TBL(
	iLayoutKind	IN	INTEGER,					 -- ���C�A�E�g�敪
	iShimeKind	IN	INTEGER,					 -- ���ߓ��敪
	iTensoYMD	IN	VARCHAR2,					 -- �]���N����
	iOPE_CD 	IN	VARCHAR2,                               	 -- �I�y���[�^�R�[�h
	iPGM_ID 	IN	VARCHAR2,                               	 -- �v���O����ID
	iDATE DATE,                                                     	 -- �V�X�e������
	iIP_ADDR	IN 	TL_STORED_SHORI.IP%TYPE,			 -- ���s�[��IP�A�h���X (FW�Őݒ�)
	iWINDOWS_LOGIN_USER	IN 	TL_STORED_SHORI.WINDOWS_LOGIN_USER%TYPE, -- ���s�[��OS���[�U�[ (FW�Őݒ�)
	oROW_COUNT	OUT 	NUMBER,                                          -- �o�^����
	oOUT_ERR_INF_CSR 	OUT 	ERR_INF_CSR                              -- �G���[���J�[�\��
	)RETURN NUMBER IS
	
  PRAGMA AUTONOMOUS_TRANSACTION;
	/************************************************************************/
	/*                              �G���[����                              */
	/************************************************************************/
	W_INDEX_N 				NUMBER(10) := 0;
	W_ERR_INF_TBL 				TYPE_ERR_INFO_TBL := TYPE_ERR_INFO_TBL();
	W_ERR_INF_RCD 				TYPE_ERR_INFO_RCD := TYPE_ERR_INFO_RCD(NULL,NULL,NULL,NULL);
	
	V_SCHEMA_NM   TM_JOSU.HANYO_KOMOKU%TYPE := NULL; -- �X�L�[�}����
	PGM_ID        VARCHAR2(50) := 'NH010106B001_000.CREATE_KAKUSHU_TBL';
	EXECUTE_SQL   VARCHAR2(32767) := NULL;

	BEGIN

		-- �J�n���O�o��
    		ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'PL/SQL Start',PGM_ID || '�̏������J�n���܂��B',iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

		-- �X�V�����̏�����
		oROW_COUNT := -1;

		-- �[�i�p�X�L�[�}�̎擾���s���B
		V_SCHEMA_NM := ULT_COMMON.GET_SCHEMA_NAME(ULT_COMMON.SYS_ENV_JOSU_DAI_CD, ULT_COMMON.NOHIN_SHEMA_JOSU_SHO_CD);

	-- ���ߋ敪:"1"(������)
	IF iShimeKind = 1 THEN
		-- �b�背�C�A�E�g
		IF iLayoutKind = 2 THEN

		/************************************************************************/
		/*                             �@�f�ÉȖ�                               */
		/************************************************************************/
			-- �b��_�S��_�e��e�[�u��_�f�ÉȖڃe�[�u���̃f�[�^���N���A����
			EXECUTE_SQL := 'TRUNCATE TABLE ' || V_SCHEMA_NM || '.' || 'TD_PA_KAKUSHUTBL_A';
			EXECUTE IMMEDIATE EXECUTE_SQL;
			ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

			INSERT INTO TD_PA_KAKUSHUTBL_A(
				REC_ID,
				FILE_KBN,
				SNRYKMK_CD,
				KANA_MEISYO,
				KANJI_MEISYO_SNRYKMK_RYKSK,
				KANJI_MEISYO_SNRYKMK_FILLER,
				KANJI_MEISYO_SNRYKMK_SEISHIKI,
				TENSO_Y,
				TENSO_M,
				TENSO_D,
				MENTE_Y,
				MENTE_M,
				MENTE_D,
				MOD_KBN,
				TRK_OPE_CD,
				TRK_DATE,
				TRK_PGM_ID,
				UPD_OPE_CD,
				UPD_DATE,
				UPD_PGM_ID)
				SELECT
				'11',
				'A',
				'0' || SNRYKMK_CD,
				SNRYKMK_NM_KANA,
				SNRYKMK_RN,
				NULL,
				SNRYKMK_NM,
				SUBSTR(iTensoYMD,1,4),
				SUBSTR(iTensoYMD,5,2),
				SUBSTR(iTensoYMD,7,2),
				SUBSTR(UPD_EIGY_YMD,1,4),
				SUBSTR(UPD_EIGY_YMD,5,2),
				SUBSTR(UPD_EIGY_YMD,7,2),
				NULL,
				iOPE_CD,
				iDATE,
				iPGM_ID,
				iOPE_CD,
				iDATE,
				iPGM_ID
				FROM TM_TIKY_SNRYKMK;
				-- 2012/11/12 �d�l�ύX�̑Ή�
				-- WHERE HAISHI_FLG IS NULL;
				-- 2012/11/12 �d�l�ύX�̑Ή�
				-- �b��_�S��_�e��e�[�u��_�f�ÉȖڃe�[�u���̓o�^
				EXECUTE_SQL :=  'INSERT INTO TD_PA_KAKUSHUTBL_A('  ||
						'REC_ID,			'  ||
						'FILE_KBN,			'  ||
						'SNRYKMK_CD,			'  ||
						'KANA_MEISYO,			'  ||
						'KANJI_MEISYO_SNRYKMK_RYKSK,	'  ||
						'KANJI_MEISYO_SNRYKMK_FILLER,	'  ||
						'KANJI_MEISYO_SNRYKMK_SEISHIKI,	'  ||
						'TENSO_Y,			'  ||
						'TENSO_M,			'  ||
						'TENSO_D,			'  ||
						'MENTE_Y,			'  ||
						'MENTE_M,			'  ||
						'MENTE_D,			'  ||
						'MOD_KBN,			'  ||
						'TRK_OPE_CD,			'  ||
						'TRK_DATE,			'  ||
						'TRK_PGM_ID,			'  ||
						'UPD_OPE_CD,			'  ||
						'UPD_DATE,			'  ||
						'UPD_PGM_ID)			'  ||
							'SELECT 				'  ||
							 '''11'''				|| ','	||
							 '''A'''				|| ','	||
							 '''0''' || 'SNRYKMK_CD, 		'  ||
							 'SNRYKMK_NM_KANA, 			'  ||
							 'SNRYKMK_RN, 				'  ||
							 'NULL,		 			'  ||
							 'SNRYKMK_NM,		 		'  ||
							 'SUBSTR(iTensoYMD,1,4), 		'  ||
							 'SUBSTR(iTensoYMD,5,2), 		'  ||
							 'SUBSTR(iTensoYMD,7,2), 		'  ||
							 'SUBSTR(UPD_EIGY_YMD,1,4), 		'  ||
							 'SUBSTR(UPD_EIGY_YMD,5,2), 		'  ||
							 'SUBSTR(UPD_EIGY_YMD,7,2), 		'  ||
							 'NULL, 				'  ||
							 iOPE_CD 				|| ','	||
							 iDATE 					|| ','	||
							 iPGM_ID 				|| ','	||
							 iOPE_CD 				|| ','	||
							 iDATE 					|| ','	||
							 iPGM_ID				||
							'FROM TM_TIKY_SNRYKMK			'  ;
							-- 2012/11/12 �d�l�ύX�̑Ή�
							-- || 'WHERE HAISHI_FLG IS NULL		';
							-- 2012/11/12 �d�l�ύX�̑Ή�

				ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

		/************************************************************************/
		/*                             �A�a�@���                               */
		/************************************************************************/
			-- �b��_�S��_�e��e�[�u��_�a�@��ʃe�[�u���̃f�[�^���N���A����
			EXECUTE_SQL := 'TRUNCATE TABLE ' || V_SCHEMA_NM || '.' || 'TD_PA_KAKUSHUTBL_C';
			EXECUTE IMMEDIATE EXECUTE_SQL;
			ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

			INSERT INTO TD_PA_KAKUSHUTBL_C(
				REC_ID,
				FILE_KBN,
				BYOIN_SBT_CD,
				FILLER,
				KANJI_MEISYO,
				TENSO_Y,
				TENSO_M,
				TENSO_D,
				MENTE_Y,
				MENTE_M,
				MENTE_D,
				MOD_KBN,
				TRK_OPE_CD,
				TRK_DATE,
				TRK_PGM_ID,
				UPD_OPE_CD,
				UPD_DATE,
				UPD_PGM_ID)
				SELECT
				'11',
				'C',
				'000' || BYOIN_SBT_CD,
				NULL,
				BYOIN_SBT_NM,
				SUBSTR(iTensoYMD,1,4),
				SUBSTR(iTensoYMD,5,2),
				SUBSTR(iTensoYMD,7,2),
				SUBSTR(UPD_EIGY_YMD,1,4),
				SUBSTR(UPD_EIGY_YMD,5,2),
				SUBSTR(UPD_EIGY_YMD,7,2),
				NULL,
				iOPE_CD,
				iDATE,
				iPGM_ID,
				iOPE_CD,
				iDATE,
				iPGM_ID
				FROM TM_TIKY_BYOIN_SBT;
				-- 2012/11/12 �d�l�ύX�̑Ή�
				-- WHERE HAISHI_FLG IS NULL;
				-- 2012/11/12 �d�l�ύX�̑Ή�
				
				-- �b��_�S��_�e��e�[�u��_�a�@��ʃe�[�u���̓o�^
				EXECUTE_SQL :=  'INSERT INTO TD_PA_KAKUSHUTBL_C('  ||
						'REC_ID,			'  ||
						'FILE_KBN,			'  ||
						'BYOIN_SBT_CD,			'  ||
						'FILLER,			'  ||
						'KANJI_MEISYO,			'  ||
						'TENSO_Y,			'  ||
						'TENSO_M,			'  ||
						'TENSO_D,			'  ||
						'MENTE_Y,			'  ||
						'MENTE_M,			'  ||
						'MENTE_D,			'  ||
						'MOD_KBN,			'  ||
						'TRK_OPE_CD,			'  ||
						'TRK_DATE,			'  ||
						'TRK_PGM_ID,			'  ||
						'UPD_OPE_CD,			'  ||
						'UPD_DATE,			'  ||
						'UPD_PGM_ID)			'  ||
							'SELECT 				'  ||
							 '''11'''				|| ','	||
							 '''C'''				|| ','	||
							 '''000''' || 'BYOIN_SBT_CD, 		'  ||
							 'BYOIN_SBT_NM, 			'  ||
							 'SUBSTR(iTensoYMD,1,4), 		'  ||
							 'SUBSTR(iTensoYMD,5,2), 		'  ||
							 'SUBSTR(iTensoYMD,7,2), 		'  ||
							 'SUBSTR(UPD_EIGY_YMD,1,4), 		'  ||
							 'SUBSTR(UPD_EIGY_YMD,5,2), 		'  ||
							 'SUBSTR(UPD_EIGY_YMD,7,2), 		'  ||
							 'NULL, 				'  ||
							 iOPE_CD 				|| ','	||
							 iDATE 					|| ','	||
							 iPGM_ID 				|| ','	||
							 iOPE_CD 				|| ','	||
							 iDATE 					|| ','	||
							 iPGM_ID				||
							'FROM TM_TIKY_BYOIN_SBT			'  ;
							-- 2012/11/12 �d�l�ύX�̑Ή�
							-- || 'WHERE HAISHI_FLG IS NULL		';
							-- 2012/11/12 �d�l�ύX�̑Ή�

				ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);
		  
		/************************************************************************/
		/*                             �B�o�g�Z�w��                             */
		/************************************************************************/
			-- �b��_�S��_�e��e�[�u��_�o�g�Z_�w���e�[�u���̃f�[�^���N���A����
			EXECUTE_SQL := 'TRUNCATE TABLE ' || V_SCHEMA_NM || '.' || 'TD_PA_KAKUSHUTBL_E';
			EXECUTE IMMEDIATE EXECUTE_SQL;
			ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

			INSERT INTO TD_PA_KAKUSHUTBL_E(
				REC_ID,
				FILE_KBN,
				SHUSSHINKO_CD,
				FILLER,
				SORITSU_GENGO,
				SORITSU_Y,
				KANJI_MEISYO,
				TENSO_Y,
				TENSO_M,
				TENSO_D,
				MENTE_Y,
				MENTE_M,
				MENTE_D,
				MOD_KBN,
				TRK_OPE_CD,
				TRK_DATE,
				TRK_PGM_ID,
				UPD_OPE_CD,
				UPD_DATE,
				UPD_PGM_ID)
				SELECT
				'11',
				'E',
				A.SHUSSHINKO_CD || A.GAKUBU_SHIKIBETSU_KBN,
				NULL,
				A.SORITSUNEN_GENGO_CD,
				A.SORITSUNEN_WY,
				B.SHUSSHINKO_RN,
				SUBSTR(iTensoYMD,1,4),
				SUBSTR(iTensoYMD,5,2),
				SUBSTR(iTensoYMD,7,2),
				SUBSTR(A.UPD_EIGY_YMD,1,4),
				SUBSTR(A.UPD_EIGY_YMD,5,2),
				SUBSTR(A.UPD_EIGY_YMD,7,2),
				NULL,
				iOPE_CD,
				iDATE,
				iPGM_ID,
				iOPE_CD,
				iDATE,
				iPGM_ID
				FROM�@TM_TIKY_SHUSSHINKO_GAKUBU A
				LEFT OUTER JOIN TM_TIKY_SHUSSHINKO_NM B
				ON A.SHUSSHINKO_CD = B.SHUSSHINKO_CD;
				-- 2012/11/12 �d�l�ύX�̑Ή�
				-- WHERE A.HAISHI_FLG IS NULL;
				-- 2012/11/12 �d�l�ύX�̑Ή�

				-- �b��_�S��_�e��e�[�u��_�o�g�Z_�w���e�[�u���̓o�^
				EXECUTE_SQL :=  'INSERT INTO TD_PA_KAKUSHUTBL_E(	'  ||
						'REC_ID,			'  ||
						'FILE_KBN,			'  ||
						'SHUSSHINKO_CD,			'  ||
						'FILLER,			'  ||
						'SORITSU_GENGO,			'  ||
						'SORITSU_Y,			'  ||
						'KANJI_MEISYO,			'  ||
						'TENSO_Y,			'  ||
						'TENSO_M,			'  ||
						'TENSO_D,			'  ||
						'MENTE_Y,			'  ||
						'MENTE_M,			'  ||
						'MENTE_D,			'  ||
						'MOD_KBN,			'  ||
						'TRK_OPE_CD,			'  ||
						'TRK_DATE,			'  ||
						'TRK_PGM_ID,			'  ||
						'UPD_OPE_CD,			'  ||
						'UPD_DATE,			'  ||
						'UPD_PGM_ID)			'  ||
							'SELECT 					'  ||
							 '''11'''					|| ','	||
							 '''E'''					|| ','	||
							 'A.SHUSSHINKO_CD' || 'A.GAKUBU_SHIKIBETSU_KBN,	'  ||
							 'NULL, 					'  ||
							 'A.SORITSUNEN_GENGO_CD, 			'  ||
							 'A.SORITSUNEN_WY, 				'  ||
							 'B.SHUSSHINKO_RN, 				'  ||
							 'SUBSTR(iTensoYMD,1,4), 			'  ||
							 'SUBSTR(iTensoYMD,5,2), 			'  ||
							 'SUBSTR(iTensoYMD,7,2), 			'  ||
							 'SUBSTR(UPD_EIGY_YMD,1,4), 			'  ||
							 'SUBSTR(UPD_EIGY_YMD,5,2), 			'  ||
							 'SUBSTR(UPD_EIGY_YMD,7,2), 			'  ||
							 'NULL, 					'  ||
							 iOPE_CD 					|| ','	||
							 iDATE 						|| ','	||
							 iPGM_ID 					|| ','	||
							 iOPE_CD 					|| ','	||
							 iDATE 						|| ','	||
							 iPGM_ID					||
							'FROM�@TM_TIKY_SHUSSHINKO_GAKUBU A		'  ||
							'LEFT OUTER JOIN TM_TIKY_SHUSSHINKO_NM B	'  ||
							'ON A.SHUSSHINKO_CD = B.SHUSSHINKO_CD		'  ;
							-- 2012/11/12 �d�l�ύX�̑Ή�
							-- || 'WHERE A.HAISHI_FLG IS NULL			';
							-- 2012/11/12 �d�l�ύX�̑Ή�

				ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);
		  
		/************************************************************************/
		/*                             �C��E                                   */
		/************************************************************************/
			-- �b��_�S��_�e��e�[�u��_��E�e�[�u���̃f�[�^���N���A����
			EXECUTE_SQL := 'TRUNCATE TABLE ' || V_SCHEMA_NM || '.' || 'TD_PA_KAKUSHUTBL_H';
			EXECUTE IMMEDIATE EXECUTE_SQL;
			ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

			INSERT INTO TD_PA_KAKUSHUTBL_H(
				REC_ID,
				FILE_KBN,
				YAKUSHOKU_CD,
				FILLER,
				KANJI_MEISYO,
				TENSO_Y,
				TENSO_M,
				TENSO_D,
				MENTE_Y,
				MENTE_M,
				MENTE_D,
				MOD_KBN,
				TRK_OPE_CD,
				TRK_DATE,
				TRK_PGM_ID,
				UPD_OPE_CD,
				UPD_DATE,
				UPD_PGM_ID)
				SELECT
				'11',
				'H',
				'0' || YAKUSHOKU_CD,
				NULL,
				YAKUSHOKU_RN,
				SUBSTR(iTensoYMD,1,4),
				SUBSTR(iTensoYMD,5,2),
				SUBSTR(iTensoYMD,7,2),
				SUBSTR(UPD_EIGY_YMD,1,4),
				SUBSTR(UPD_EIGY_YMD,5,2),
				SUBSTR(UPD_EIGY_YMD,7,2),
				NULL,
				iOPE_CD,
				iDATE,
				iPGM_ID,
				iOPE_CD,
				iDATE,
				iPGM_ID
				FROM TM_TIKY_YAKUSHOKU;
				-- 2012/11/12 �d�l�ύX�̑Ή�
				-- WHERE HAISHI_FLG IS NULL;
				-- 2012/11/12 �d�l�ύX�̑Ή�
				
				-- �b��_�S��_�e��e�[�u��_��E�e�[�u���̓o�^
				EXECUTE_SQL :=  'INSERT INTO TD_PA_KAKUSHUTBL_H('  ||
						'REC_ID,			'  ||
						'FILE_KBN,			'  ||
						'YAKUSHOKU_CD,			'  ||
						'FILLER,			'  ||
						'KANJI_MEISYO,			'  ||
						'TENSO_Y,			'  ||
						'TENSO_M,			'  ||
						'TENSO_D,			'  ||
						'MENTE_Y,			'  ||
						'MENTE_M,			'  ||
						'MENTE_D,			'  ||
						'MOD_KBN,			'  ||
						'TRK_OPE_CD,			'  ||
						'TRK_DATE,			'  ||
						'TRK_PGM_ID,			'  ||
						'UPD_OPE_CD,			'  ||
						'UPD_DATE,			'  ||
						'UPD_PGM_ID)			'  ||
							'SELECT 				'  ||
							 '''11'''				|| ','	||
							 '''H'''				|| ','	||
							 '''0''' || 'YAKUSHOKU_CD, 		'  ||
							 'NULL, 				'  ||
							 'YAKUSHOKU_RN, 			'  ||
							 'SUBSTR(iTensoYMD,1,4), 		'  ||
							 'SUBSTR(iTensoYMD,5,2), 		'  ||
							 'SUBSTR(iTensoYMD,7,2), 		'  ||
							 'SUBSTR(UPD_EIGY_YMD,1,4), 		'  ||
							 'SUBSTR(UPD_EIGY_YMD,5,2), 		'  ||
							 'SUBSTR(UPD_EIGY_YMD,7,2), 		'  ||
							 'NULL, 				'  ||
							 iOPE_CD 				|| ','	||
							 iDATE 					|| ','	||
							 iPGM_ID 				|| ','	||
							 iOPE_CD 				|| ','	||
							 iDATE 					|| ','	||
							 iPGM_ID				||
							'FROM TM_TIKY_YAKUSHOKU			'  ;
							-- 2012/11/12 �d�l�ύX�̑Ή�
							-- || 'WHERE HAISHI_FLG IS NULL		';
							-- 2012/11/12 �d�l�ύX�̑Ή�

				ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

		/************************************************************************/
		/*                             �D�����w��                               */
		/************************************************************************/
			-- �b��_�S��_�e��e�[�u��_�����w��e�[�u���̃f�[�^���N���A����
			EXECUTE_SQL := 'TRUNCATE TABLE ' || V_SCHEMA_NM || '.' || 'TD_PA_KAKUSHUTBL_O';
			EXECUTE IMMEDIATE EXECUTE_SQL;
			ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

			INSERT INTO TD_PA_KAKUSHUTBL_O(
				REC_ID,
				FILE_KBN,
				GAKKAI_CD,
				FILLER,
				KANJI_MEISYO,
				TENSO_Y,
				TENSO_M,
				TENSO_D,
				MENTE_Y,
				MENTE_M,
				MENTE_D,
				MOD_KBN,
				TRK_OPE_CD,
				TRK_DATE,
				TRK_PGM_ID,
				UPD_OPE_CD,
				UPD_DATE,
				UPD_PGM_ID)
				SELECT
				'11',
				'O',
				'0' || GAKKAI_CD,
				NULL,
				GAKKAI_RN,
				SUBSTR(iTensoYMD,1,4),
				SUBSTR(iTensoYMD,5,2),
				SUBSTR(iTensoYMD,7,2),
				SUBSTR(UPD_EIGY_YMD,1,4),
				SUBSTR(UPD_EIGY_YMD,5,2),
				SUBSTR(UPD_EIGY_YMD,7,2),
				NULL,
				iOPE_CD,
				iDATE,
				iPGM_ID,
				iOPE_CD,
				iDATE,
				iPGM_ID
				FROM TM_TIKY_GAKKAI;
				-- 2012/11/12 �d�l�ύX�̑Ή�
				-- WHERE HAISHI_FLG IS NULL;
				-- 2012/11/12 �d�l�ύX�̑Ή�
				
				-- �b��_�S��_�e��e�[�u��_�����w��e�[�u���̓o�^
				EXECUTE_SQL :=  'INSERT INTO TD_PA_KAKUSHUTBL_O('  ||
						'REC_ID,			'  ||
						'FILE_KBN,			'  ||
						'GAKKAI_CD,			'  ||
						'FILLER,			'  ||
						'KANJI_MEISYO,			'  ||
						'TENSO_Y,			'  ||
						'TENSO_M,			'  ||
						'TENSO_D,			'  ||
						'MENTE_Y,			'  ||
						'MENTE_M,			'  ||
						'MENTE_D,			'  ||
						'MOD_KBN,			'  ||
						'TRK_OPE_CD,			'  ||
						'TRK_DATE,			'  ||
						'TRK_PGM_ID,			'  ||
						'UPD_OPE_CD,			'  ||
						'UPD_DATE,			'  ||
						'UPD_PGM_ID)			'  ||
							'SELECT 				'  ||
							 '''11'''				|| ','	||
							 '''O'''				|| ','	||
							 '''0''' || 'GAKKAI_CD, 		'  ||
							 'NULL, 				'  ||
							 'GAKKAI_RN, 				'  ||
							 'SUBSTR(iTensoYMD,1,4), 		'  ||
							 'SUBSTR(iTensoYMD,5,2), 		'  ||
							 'SUBSTR(iTensoYMD,7,2), 		'  ||
							 'SUBSTR(UPD_EIGY_YMD,1,4), 		'  ||
							 'SUBSTR(UPD_EIGY_YMD,5,2), 		'  ||
							 'SUBSTR(UPD_EIGY_YMD,7,2), 		'  ||
							 'NULL, 				'  ||
							 iOPE_CD 				|| ','	||
							 iDATE 					|| ','	||
							 iPGM_ID 				|| ','	||
							 iOPE_CD 				|| ','	||
							 iDATE 					|| ','	||
							 iPGM_ID				||
							'FROM TM_TIKY_GAKKAI			'  ;
							-- 2012/11/12 �d�l�ύX�̑Ή�
							-- || 'WHERE HAISHI_FLG IS NULL		';
							-- 2012/11/12 �d�l�ύX�̑Ή�

				ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

		/************************************************************************/
		/*                             �E�o�g�Z                                 */
		/************************************************************************/
			-- �b��_�S��_�e��e�[�u��_�o�g�Z�e�[�u���̃f�[�^���N���A����
			EXECUTE_SQL := 'TRUNCATE TABLE ' || V_SCHEMA_NM || '.' || 'TD_PA_KAKUSHUTBL_X';
			EXECUTE IMMEDIATE EXECUTE_SQL;
			ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

			INSERT INTO TD_PA_KAKUSHUTBL_X(
				REC_ID,
				FILE_KBN,
				SHUSSHINKO_CD,
				FILLER,
				KANJI_MEISYO,
				TENSO_Y,
				TENSO_M,
				TENSO_D,
				MENTE_Y,
				MENTE_M,
				MENTE_D,
				MOD_KBN,
				TRK_OPE_CD,
				TRK_DATE,
				TRK_PGM_ID,
				UPD_OPE_CD,
				UPD_DATE,
				UPD_PGM_ID)
				SELECT
				'11',
				'X',
				'0' || SHUSSHINKO_CD,
				NULL,
				SHUSSHINKO_RN,
				SUBSTR(iTensoYMD,1,4),
				SUBSTR(iTensoYMD,5,2),
				SUBSTR(iTensoYMD,7,2),
				SUBSTR(UPD_EIGY_YMD,1,4),
				SUBSTR(UPD_EIGY_YMD,5,2),
				SUBSTR(UPD_EIGY_YMD,7,2),
				NULL,
				iOPE_CD,
				iDATE,
				iPGM_ID,
				iOPE_CD,
				iDATE,
				iPGM_ID
				FROM TM_TIKY_SHUSSHINKO_NM;
				-- 2012/11/12 �d�l�ύX�̑Ή�
				-- WHERE HAISHI_FLG IS NULL;
				-- 2012/11/12 �d�l�ύX�̑Ή�
				
				-- �b��_�S��_�e��e�[�u��_�o�g�Z�e�[�u���̓o�^
				EXECUTE_SQL :=  'INSERT INTO TD_PA_KAKUSHUTBL_X('  ||
						'REC_ID,			'  ||
						'FILE_KBN,			'  ||
						'SHUSSHINKO_CD,			'  ||
						'FILLER,			'  ||
						'KANJI_MEISYO,			'  ||
						'TENSO_Y,			'  ||
						'TENSO_M,			'  ||
						'TENSO_D,			'  ||
						'MENTE_Y,			'  ||
						'MENTE_M,			'  ||
						'MENTE_D,			'  ||
						'MOD_KBN,			'  ||
						'TRK_OPE_CD,			'  ||
						'TRK_DATE,			'  ||
						'TRK_PGM_ID,			'  ||
						'UPD_OPE_CD,			'  ||
						'UPD_DATE,			'  ||
						'UPD_PGM_ID)			'  ||
							'SELECT 				'  ||
							 '''11'''				|| ','	||
							 '''X'''				|| ','	||
							 '''0''' || 'SHUSSHINKO_CD, 		'  ||
							 'NULL, 				'  ||
							 'SHUSSHINKO_RN, 			'  ||
							 'SUBSTR(iTensoYMD,1,4), 		'  ||
							 'SUBSTR(iTensoYMD,5,2), 		'  ||
							 'SUBSTR(iTensoYMD,7,2), 		'  ||
							 'SUBSTR(UPD_EIGY_YMD,1,4), 		'  ||
							 'SUBSTR(UPD_EIGY_YMD,5,2), 		'  ||
							 'SUBSTR(UPD_EIGY_YMD,7,2), 		'  ||
							 'NULL, 				'  ||
							 iOPE_CD 				|| ','	||
							 iDATE 					|| ','	||
							 iPGM_ID 				|| ','	||
							 iOPE_CD 				|| ','	||
							 iDATE 					|| ','	||
							 iPGM_ID				||
							'FROM TM_TIKY_SHUSSHINKO_NM		'  ;
							-- 2012/11/12 �d�l�ύX�̑Ή�
							-- || 'WHERE HAISHI_FLG IS NULL		';
							-- 2012/11/12 �d�l�ύX�̑Ή�

				ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

		/************************************************************************/
		/*                             �F�s���{����                             */
		/************************************************************************/
			-- �b��_�S��_�e��e�[�u��_�s���{�����e�[�u���̃f�[�^���N���A����
			EXECUTE_SQL := 'TRUNCATE TABLE ' || V_SCHEMA_NM || '.' || 'TD_PA_KAKUSHUTBL_K';
			EXECUTE IMMEDIATE EXECUTE_SQL;
			ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

			INSERT INTO TD_PA_KAKUSHUTBL_K(
				REC_ID,
				FILE_KBN,
				KEN_CD,
				FILLER,
				JIS_KEN_CD,
				KANJI_MEISYO,
				TENSO_Y,
				TENSO_M,
				TENSO_D,
				MENTE_Y,
				MENTE_M,
				MENTE_D,
				MOD_KBN,
				TRK_OPE_CD,
				TRK_DATE,
				TRK_PGM_ID,
				UPD_OPE_CD,
				UPD_DATE,
				UPD_PGM_ID)
				SELECT
				'11',
				'K',
				'00' || RIDAI_CD,
				NULL,
				KEN_CD,
				KEN_NM,
				SUBSTR(iTensoYMD,1,4),
				SUBSTR(iTensoYMD,5,2),
				SUBSTR(iTensoYMD,7,2),
				SUBSTR(UPD_EIGY_YMD,1,4),
				SUBSTR(UPD_EIGY_YMD,5,2),
				SUBSTR(UPD_EIGY_YMD,7,2),
				NULL,
				iOPE_CD,
				iDATE,
				iPGM_ID,
				iOPE_CD,
				iDATE,
				iPGM_ID
				FROM TM_TIKY_KEN_NM;
				-- 2012/11/12 �d�l�ύX�̑Ή�
				-- WHERE HAISHI_FLG IS NULL;
				-- 2012/11/12 �d�l�ύX�̑Ή�
				
				-- �b��_�S��_�e��e�[�u��_�s���{�����e�[�u���̓o�^
				EXECUTE_SQL :=  'INSERT INTO TD_PA_KAKUSHUTBL_K('  ||
						'REC_ID,			'  ||
						'FILE_KBN,			'  ||
						'KEN_CD,			'  ||
						'FILLER,			'  ||
						'JIS_KEN_CD,			'  ||
						'KANJI_MEISYO,			'  ||
						'TENSO_Y,			'  ||
						'TENSO_M,			'  ||
						'TENSO_D,			'  ||
						'MENTE_Y,			'  ||
						'MENTE_M,			'  ||
						'MENTE_D,			'  ||
						'MOD_KBN,			'  ||
						'TRK_OPE_CD,			'  ||
						'TRK_DATE,			'  ||
						'TRK_PGM_ID,			'  ||
						'UPD_OPE_CD,			'  ||
						'UPD_DATE,			'  ||
						'UPD_PGM_ID)			'  ||
							'SELECT 				'  ||
							 '''11'''				|| ','	||
							 '''K'''				|| ','	||
							 '''00''' || 'RIDAI_CD, 		'  ||
							 'NULL, 				'  ||
							 'KEN_CD, 				'  ||
							 'KEN_NM, 				'  ||
							 'SUBSTR(iTensoYMD,1,4), 		'  ||
							 'SUBSTR(iTensoYMD,5,2), 		'  ||
							 'SUBSTR(iTensoYMD,7,2), 		'  ||
							 'SUBSTR(UPD_EIGY_YMD,1,4), 		'  ||
							 'SUBSTR(UPD_EIGY_YMD,5,2), 		'  ||
							 'SUBSTR(UPD_EIGY_YMD,7,2), 		'  ||
							 'NULL, 				'  ||
							 iOPE_CD 				|| ','	||
							 iDATE 					|| ','	||
							 iPGM_ID 				|| ','	||
							 iOPE_CD 				|| ','	||
							 iDATE 					|| ','	||
							 iPGM_ID				||
							'FROM TM_TIKY_KEN_NM			'  ;
							-- 2012/11/12 �d�l�ύX�̑Ή�
							-- || 'WHERE HAISHI_FLG IS NULL		';
							-- 2012/11/12 �d�l�ύX�̑Ή�

				ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

		/************************************************************************/
		/*                             �G�o�c��                                 */
		/************************************************************************/
			-- �b��_�S��_�e��e�[�u��_�o�c�̃e�[�u���̃f�[�^���N���A����
			EXECUTE_SQL := 'TRUNCATE TABLE ' || V_SCHEMA_NM || '.' || 'TD_PA_KAKUSHUTBL_L';
			EXECUTE IMMEDIATE EXECUTE_SQL;
			ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

			INSERT INTO TD_PA_KAKUSHUTBL_L(
				REC_ID,
				FILE_KBN,
				KEIEITAI_CD,
				FILLER,
				KANJI_MEISYO,
				TENSO_Y,
				TENSO_M,
				TENSO_D,
				MENTE_Y,
				MENTE_M,
				MENTE_D,
				MOD_KBN,
				TRK_OPE_CD,
				TRK_DATE,
				TRK_PGM_ID,
				UPD_OPE_CD,
				UPD_DATE,
				UPD_PGM_ID)
				SELECT
				'11',
				'L',
				KEIEITAI_CD || ' ',
				NULL,
				KEIEITAI_RN,
				SUBSTR(iTensoYMD,1,4),
				SUBSTR(iTensoYMD,5,2),
				SUBSTR(iTensoYMD,7,2),
				SUBSTR(UPD_EIGY_YMD,1,4),
				SUBSTR(UPD_EIGY_YMD,5,2),
				SUBSTR(UPD_EIGY_YMD,7,2),
				NULL,
				iOPE_CD,
				iDATE,
				iPGM_ID,
				iOPE_CD,
				iDATE,
				iPGM_ID
				FROM TM_TIKY_KEIEITAI;
				-- �b��_�S��_�e��e�[�u��_�o�c�̃e�[�u���̓o�^
				EXECUTE_SQL :=  'INSERT INTO TD_PA_KAKUSHUTBL_L('  ||
						'REC_ID,			'  ||
						'FILE_KBN,			'  ||
						'KEIEITAI_CD,			'  ||
						'FILLER,			'  ||
						'KANJI_MEISYO,			'  ||
						'TENSO_Y,			'  ||
						'TENSO_M,			'  ||
						'TENSO_D,			'  ||
						'MENTE_Y,			'  ||
						'MENTE_M,			'  ||
						'MENTE_D,			'  ||
						'MOD_KBN,			'  ||
						'TRK_OPE_CD,			'  ||
						'TRK_DATE,			'  ||
						'TRK_PGM_ID,			'  ||
						'UPD_OPE_CD,			'  ||
						'UPD_DATE,			'  ||
						'UPD_PGM_ID)			'  ||
							'SELECT 				'  ||
							 '''11'''				|| ','	||
							 '''L'''				|| ','	||
							 'KEIEITAI_CD' || ''' '''		|| ','	||
							 'NULL, 				'  ||
							 'KEIEITAI_RN, 				'  ||
							 'SUBSTR(iTensoYMD,1,4), 		'  ||
							 'SUBSTR(iTensoYMD,5,2), 		'  ||
							 'SUBSTR(iTensoYMD,7,2), 		'  ||
							 'SUBSTR(UPD_EIGY_YMD,1,4), 		'  ||
							 'SUBSTR(UPD_EIGY_YMD,5,2), 		'  ||
							 'SUBSTR(UPD_EIGY_YMD,7,2), 		'  ||
							 'NULL, 				'  ||
							 iOPE_CD 				|| ','	||
							 iDATE 					|| ','	||
							 iPGM_ID 				|| ','	||
							 iOPE_CD 				|| ','	||
							 iDATE 					|| ','	||
							 iPGM_ID				||
							'FROM TM_TIKY_KEIEITAI			';

				ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

		/************************************************************************/
		/*                             �H��������                               */
		/************************************************************************/
			-- �b��_�S��_�e��e�[�u��_�������ȃe�[�u���̃f�[�^���N���A����
			EXECUTE_SQL := 'TRUNCATE TABLE ' || V_SCHEMA_NM || '.' || 'TD_PA_KAKUSHUTBL_M';
			EXECUTE IMMEDIATE EXECUTE_SQL;
			ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

			INSERT INTO TD_PA_KAKUSHUTBL_M(
				REC_ID,
				FILE_KBN,
				CD,
				KANA_MEISYO,
				BNRIHOJO_CD,
				KANJI_MEISYO,
				TENSO_Y,
				TENSO_M,
				TENSO_D,
				MENTE_Y,
				MENTE_M,
				MENTE_D,
				MOD_KBN,
				TRK_OPE_CD,
				TRK_DATE,
				TRK_PGM_ID,
				UPD_OPE_CD,
				UPD_DATE,
				UPD_PGM_ID)
				SELECT
				'11',
				'M',
				SZKBUKA_CD,
				SZKBUKA_NM_KANA,
				BNRIHOJO_SHI_BNRI_CD || BNRIHOJO_SNRY_BNY_BNRI_CD || BNRIHOJO_SORTKEY,
				SZKBUKA_NM,
				SUBSTR(iTensoYMD,1,4),
				SUBSTR(iTensoYMD,5,2),
				SUBSTR(iTensoYMD,7,2),
				SUBSTR(UPD_EIGY_YMD,1,4),
				SUBSTR(UPD_EIGY_YMD,5,2),
				SUBSTR(UPD_EIGY_YMD,7,2),
				NULL,
				iOPE_CD,
				iDATE,
				iPGM_ID,
				iOPE_CD,
				iDATE,
				iPGM_ID
				FROM TM_TIKY_SZKBUKA;
				-- 2012/11/12 �d�l�ύX�̑Ή�
				-- WHERE HAISHI_FLG IS NULL;
				-- 2012/11/12 �d�l�ύX�̑Ή�
				
				-- �b��_�S��_�e��e�[�u��_�������ȃe�[�u���̓o�^
				EXECUTE_SQL :=  'INSERT INTO TD_PA_KAKUSHUTBL_M('  ||
						'REC_ID,			'  ||
						'FILE_KBN,			'  ||
						'CD,				'  ||
						'KANA_MEISYO,			'  ||
						'BNRIHOJO_CD,			'  ||
						'KANJI_MEISYO,			'  ||
						'TENSO_Y,			'  ||
						'TENSO_M,			'  ||
						'TENSO_D,			'  ||
						'MENTE_Y,			'  ||
						'MENTE_M,			'  ||
						'MENTE_D,			'  ||
						'MOD_KBN,			'  ||
						'TRK_OPE_CD,			'  ||
						'TRK_DATE,			'  ||
						'TRK_PGM_ID,			'  ||
						'UPD_OPE_CD,			'  ||
						'UPD_DATE,			'  ||
						'UPD_PGM_ID)			'  ||
							'SELECT 				'  ||
							 '''11'''				|| ','	||
							 '''M'''				|| ','	||
							 'SZKBUKA_CD, 				'  ||
							 'SZKBUKA_NM_KANA, 			'  ||
							 'BNRIHOJO_SHI_BNRI_CD' || 'BNRIHOJO_SNRY_BNY_BNRI_CD' || 'BNRIHOJO_SORTKEY, 	'  ||
							 'SZKBUKA_NM, 				'  ||
							 'SUBSTR(iTensoYMD,1,4), 		'  ||
							 'SUBSTR(iTensoYMD,5,2), 		'  ||
							 'SUBSTR(iTensoYMD,7,2), 		'  ||
							 'SUBSTR(UPD_EIGY_YMD,1,4), 		'  ||
							 'SUBSTR(UPD_EIGY_YMD,5,2), 		'  ||
							 'SUBSTR(UPD_EIGY_YMD,7,2), 		'  ||
							 'NULL, 				'  ||
							 iOPE_CD 				|| ','	||
							 iDATE 					|| ','	||
							 iPGM_ID 				|| ','	||
							 iOPE_CD 				|| ','	||
							 iDATE 					|| ','	||
							 iPGM_ID				||
							'FROM TM_TIKY_SZKBUKA			'  ;
							-- 2012/11/12 �d�l�ύX�̑Ή�
							-- || 'WHERE HAISHI_FLG IS NULL		';
							-- 2012/11/12 �d�l�ύX�̑Ή�

				ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);
		  
		/************************************************************************/
		/*                             �I���㎑�i����                         */
		/************************************************************************/
			-- �b��_�S��_�e��e�[�u��_���㎑�i���̃e�[�u���̃f�[�^���N���A����
			EXECUTE_SQL := 'TRUNCATE TABLE ' || V_SCHEMA_NM || '.' || 'TD_PA_KAKUSHUTBL_P';
			EXECUTE IMMEDIATE EXECUTE_SQL;
			ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

			INSERT INTO TD_PA_KAKUSHUTBL_P(
				REC_ID,
				FILE_KBN,
				CD,
				FILLER,
				KANJI_MEISYO,
				TENSO_Y,
				TENSO_M,
				TENSO_D,
				MENTE_Y,
				MENTE_M,
				MENTE_D,
				MOD_KBN,
				TRK_OPE_CD,
				TRK_DATE,
				TRK_PGM_ID,
				UPD_OPE_CD,
				UPD_DATE,
				UPD_PGM_ID)
				SELECT
				'11',
				'P',
				SENMONI_CD,
				NULL,
				SENMONI_SHIKAKU_NM,
				SUBSTR(iTensoYMD,1,4),
				SUBSTR(iTensoYMD,5,2),
				SUBSTR(iTensoYMD,7,2),
				SUBSTR(UPD_EIGY_YMD,1,4),
				SUBSTR(UPD_EIGY_YMD,5,2),
				SUBSTR(UPD_EIGY_YMD,7,2),
				NULL,
				iOPE_CD,
				iDATE,
				iPGM_ID,
				iOPE_CD,
				iDATE,
				iPGM_ID
				FROM TM_TIKY_SENMONI;
				-- 2012/11/12 �d�l�ύX�̑Ή�
				-- WHERE HAISHI_FLG IS NULL;
				-- 2012/11/12 �d�l�ύX�̑Ή�
				
				-- �b��_�S��_�e��e�[�u��_���㎑�i���̃e�[�u���̓o�^
				EXECUTE_SQL :=  'INSERT INTO TD_PA_KAKUSHUTBL_P('  ||
						'REC_ID,			'  ||
						'FILE_KBN,			'  ||
						'CD,				'  ||
						'FILLER,			'  ||
						'KANJI_MEISYO,			'  ||
						'TENSO_Y,			'  ||
						'TENSO_M,			'  ||
						'TENSO_D,			'  ||
						'MENTE_Y,			'  ||
						'MENTE_M,			'  ||
						'MENTE_D,			'  ||
						'MOD_KBN,			'  ||
						'TRK_OPE_CD,			'  ||
						'TRK_DATE,			'  ||
						'TRK_PGM_ID,			'  ||
						'UPD_OPE_CD,			'  ||
						'UPD_DATE,			'  ||
						'UPD_PGM_ID)			'  ||
							'SELECT 				'  ||
							 '''11'''				|| ','	||
							 '''P'''				|| ','	||
							 'SENMONI_CD, 				'  ||
							 'NULL, 				'  ||
							 'SENMONI_SHIKAKU_NM, 			'  ||
							 'SUBSTR(iTensoYMD,1,4), 		'  ||
							 'SUBSTR(iTensoYMD,5,2), 		'  ||
							 'SUBSTR(iTensoYMD,7,2), 		'  ||
							 'SUBSTR(UPD_EIGY_YMD,1,4), 		'  ||
							 'SUBSTR(UPD_EIGY_YMD,5,2), 		'  ||
							 'SUBSTR(UPD_EIGY_YMD,7,2), 		'  ||
							 'NULL, 				'  ||
							 iOPE_CD 				|| ','	||
							 iDATE 					|| ','	||
							 iPGM_ID 				|| ','	||
							 iOPE_CD 				|| ','	||
							 iDATE 					|| ','	||
							 iPGM_ID				||
							'FROM TM_TIKY_SENMONI			'  ;
							-- 2012/11/12 �d�l�ύX�̑Ή�
							-- || 'WHERE HAISHI_FLG IS NULL		';
							-- 2012/11/12 �d�l�ύX�̑Ή�

				ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

		END IF; 
	END IF;
	COMMIT;

    	-- �I�����O�o��
   	ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'PL/SQL End',PGM_ID || '�̏������I�����܂����B',iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

	return 0;
	-- ��O����
	EXCEPTION
		-- ���̑��G���[
		WHEN OTHERS THEN
			W_ERR_INF_RCD.ERR_CD 		:= TO_CHAR(SQLCODE);
			W_ERR_INF_RCD.ERR_MSG 		:= SUBSTR(SQLERRM, 0, 500);
			W_ERR_INF_RCD.ERR_KEY_INF 	:= SUBSTR('iLayoutKind:' || iLayoutKind || ', iShimeKind:' || iShimeKind , 0,500);
			W_INDEX_N 			:= W_ERR_INF_TBL.COUNT + 1;
			W_ERR_INF_TBL.EXTEND;
			W_ERR_INF_TBL(W_INDEX_N) 	:= W_ERR_INF_RCD;

			OPEN oOUT_ERR_INF_CSR FOR
				SELECT * FROM TABLE(W_ERR_INF_TBL);

			ROLLBACK;
			-- �G���[���O�̓o�^
          		ULT_INSERT_LOG_TABLE('ERROR',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'ERROR_INFO',W_ERR_INF_RCD.ERR_MSG,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);  
			return 1;
  
        END;
    END;
/
