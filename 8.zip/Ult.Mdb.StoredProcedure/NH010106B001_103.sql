CREATE OR REPLACE PACKAGE NH010106B001_103
/* **********************************************************
 *  Copyright(c) 2011 beyond, INTEC Inc. All rights reserved.
 * **********************************************************/
AUTHID CURRENT_USER
IS
	/*** �J�[�\���^ ***************************************************************/
	-- �G���[���i�[�p�J�[�\���^
	TYPE ERR_INF_CSR		IS REF CURSOR;

	/*
	************************************************************************
	*  DNF���Ȏ{�ݑf��DB�f�[�^�̍쐬
	*  CREATE_DNF_SHIKASHISETSU
	************************************************************************
	*/
	FUNCTION CREATE_DNF_SHIKASHISETSU(
		iLayoutKind		IN	INTEGER,				-- ���C�A�E�g�敪
		iShimeKind		IN	INTEGER,				-- ���ߓ��敪
		iTensoYMD		IN	VARCHAR2,				-- �]���N����
		iOPE_CD 		IN	Varchar2,                               -- �I�y���[�^�R�[�h
		iPGM_ID 		IN	Varchar2,                               -- �v���O����ID
		iDATE 			DATE,                                           -- �V�X�e������  
		iIP_ADDR		IN	TL_STORED_SHORI.IP%TYPE,		-- ���s�[��IP�A�h���X (FW�Őݒ�)
		iWINDOWS_LOGIN_USER	IN	TL_STORED_SHORI.WINDOWS_LOGIN_USER%TYPE,-- ���s�[��OS���[�U�[ (FW�Őݒ�)
		oROW_COUNT		OUT	NUMBER,                                	-- �o�^����
		oOUT_ERR_INF_CSR 	OUT	ERR_INF_CSR                            	-- �G���[���J�[�\��
	) RETURN NUMBER;

END;
/

CREATE OR REPLACE PACKAGE BODY NH010106B001_103
/* **********************************************************
 *  Copyright(c) 2011 beyond, INTEC Inc. All rights reserved.
 * **********************************************************/
IS
	/*
	 ************************************************************************
	 * Function ID  : CREATE_DNF_SHIKASHISETSU
	 * Program Name : DNF���Ȏ{�ݑf��DB�f�[�^�̍쐬
	 * Parameter    :  <I> iLayoutKind	    	�F���C�A�E�g�敪
	 *		   <I> iShimeKind	    	�F���ߓ��敪
	 *		   <I> iTensoYMD	    	�F�]���N����
	 *		   <I> iOPE_CD		        �F�I�y���[�^�R�[�h
	 *		   <I> iPGM_ID		        �F�v���O����ID
	 *		   <I> iDATE		        �F�V�X�e������ 
	 *		   <I> iIP_ADDR		        �F���s�[��IP�A�h���X
	 *		   <I> iWINDOWS_LOGIN_USER  	�F���s�[��IP�A�h���X
	 *                 <O> oROW_COUNT		�F�X�V����
	 *                 <O> oOUT_ERR_INF_CSR	�F�G���[���J�[�\��
	 * Return       �F�������ʁi0:����I���A1:�ُ�I���j
	 ************************************************************************
	 */
	FUNCTION CREATE_DNF_SHIKASHISETSU(
		iLayoutKind		IN	INTEGER,				-- ���C�A�E�g�敪
		iShimeKind		IN	INTEGER,				-- ���ߓ��敪
		iTensoYMD		IN	VARCHAR2,				-- �]���N����
		iOPE_CD 		IN	VARCHAR2,                               -- �I�y���[�^�R�[�h
		iPGM_ID 		IN	VARCHAR2,                               -- �v���O����ID
		iDATE 			DATE,                                           -- �V�X�e������  
		iIP_ADDR		IN	TL_STORED_SHORI.IP%TYPE,		-- ���s�[��IP�A�h���X (FW�Őݒ�)
		iWINDOWS_LOGIN_USER	IN	TL_STORED_SHORI.WINDOWS_LOGIN_USER%TYPE,-- ���s�[��OS���[�U�[ (FW�Őݒ�)
		oROW_COUNT		OUT	NUMBER,                                	-- �o�^����
		oOUT_ERR_INF_CSR 	OUT	ERR_INF_CSR                            	-- �G���[���J�[�\�� 
	)RETURN NUMBER IS

  PRAGMA AUTONOMOUS_TRANSACTION;
	/************************************************************************/
	/*                              �G���[����                              */
	/************************************************************************/
	W_INDEX_N 				NUMBER(10) := 0;
	W_ERR_INF_TBL 				TYPE_ERR_INFO_TBL := TYPE_ERR_INFO_TBL();
	W_ERR_INF_RCD 				TYPE_ERR_INFO_RCD := TYPE_ERR_INFO_RCD(NULL,NULL,NULL,NULL);
	
	V_SCHEMA_NM   TM_JOSU.HANYO_KOMOKU%TYPE := NULL; -- �X�L�[�}����
	PGM_ID        VARCHAR2(50) := 'NH010106B001_103.CREATE_DNF_SHIKASHISETSU';
	EXECUTE_SQL   VARCHAR2(32767) := NULL;

	BEGIN

		-- �J�n���O�o��
    		ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'PL/SQL Start',PGM_ID || '�̏������J�n���܂��B',iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

		-- �X�V�����̏�����
		oROW_COUNT := -1;

		-- �[�i�p�X�L�[�}�̎擾���s���B
		V_SCHEMA_NM := ULT_COMMON.GET_SCHEMA_NAME(ULT_COMMON.SYS_ENV_JOSU_DAI_CD, ULT_COMMON.NOHIN_SHEMA_JOSU_SHO_CD);

		-- ���ߋ敪:"1"(������)
		IF iShimeKind = 1 THEN
			-- �V���C�A�E�g
			IF iLayoutKind = 1 THEN

				-- �V_�S��_DNF���Ȏ{�݃e�[�u���̃f�[�^���N���A����
				EXECUTE_SQL := 'TRUNCATE TABLE ' || V_SCHEMA_NM || '.' || 'TD_NA_DNF_SHI';
				EXECUTE IMMEDIATE EXECUTE_SQL;
				ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

			INSERT INTO TD_NA_DNF_SHI(
				LAYOUT_KBN,
				SHIREC_ID,
				SHI_CD,
				SHI_CD_YOBI,
				MOD_KBN,
				MENTE_YMD,
				YOBI_1,
				MIKAKUNIN_FLG,
				DEL_YOTEI_RIYU,
				AITSK_CD_SHIREC_ID,
				AITSK_CD_SHI_CD,
				AITSK_CD_SHI_CD_YOBI,
				SEISHIKI_SHI_NM_KANJI,
				SEISHIKI_SHI_NM_KANA,
				RYKSK_SHI_NM_KANJI,
				RYKSK_SHI_NM_KANA,
				JUSHOFUMEI,
				JUSHO_CD_KEN_CD,
				JUSHO_CD_SHIKU_CD,
				JUSHO_CD_OAZA_CD,
				JUSHO_CD_AZA_CD,
				ZIP,
				JUSHO_KANJI,
				JUSHO_KANA,
				JUSHO_HYOJI_NO,
				JUSHO_COUNT_KANJI_KEN,
				JUSHO_COUNT_KANJI_SHIKU,
				JUSHO_COUNT_KANJI_OAZA,
				JUSHO_COUNT_KANJI_AZA,
				JUSHO_COUNT_KANA_KEN,
				JUSHO_COUNT_KANA_SHIKU,
				JUSHO_COUNT_KANA_OAZA,
				JUSHO_COUNT_KANA_AZA,
				TEL_NASHI_FLG,
				TEL,
				KEIEITAI,
				SHI_KBN,
				DAIHYO_KJNREC_ID,
				DAIHYO_KJN_CD,
				DAIHYO_KJN_CD_YOBI,
				DAIHYO_KANJI,
				DAIHYO_KANA,
				KAIGYO_YOTEI_KAIGYO_YOTEI_FLG,
				KAIGYO_YOTEI_KAIGYO_YOTEI_YM,
				KYUIN_KYUIN_FLG,
				KYUIN_KYUIN_S_YM,
				SNRYKMK_1,
				SNRYKMK_2,
				SNRYKMK_3,
				SNRYKMK_4,
				SNRYKMK_5,
				SNRYKMK_6,
				SNRYKMK_7,
				SNRYKMK_8,
				SNRYKMK_9,
				SNRYKMK_10,
				SNRYKMK_11,
				SNRYKMK_12,
				SNRYKMK_13,
				SNRYKMK_14,
				SNRYKMK_15,
				SNRYKMK_16,
				SNRYKMK_17,
				SNRYKMK_18,
				SNRYKMK_19,
				SNRYKMK_20,
				SNRYKMK_21,
				SNRYKMK_22,
				SNRYKMK_23,
				SNRYKMK_24,
				SNRYKMK_25,
				SNRYKMK_26,
				SNRYKMK_27,
				SNRYKMK_28,
				SNRYKMK_29,
				SNRYKMK_30,
				SNRYKMK_31,
				SNRYKMK_32,
				SNRYKMK_33,
				SNRYKMK_34,
				SNRYKMK_35,
				SNRYKMK_36,
				SNRYKMK_37,
				SNRYKMK_38,
				SNRYKMK_39,
				SNRYKMK_40,
				SNRYKMK_41,
				SNRYKMK_42,
				SNRYKMK_43,
				SNRYKMK_44,
				SNRYKMK_45,
				SNRYKMK_46,
				SNRYKMK_47,
				SNRYKMK_48,
				SNRYKMK_49,
				SNRYKMK_50,
				SNRYKMK_51,
				SNRYKMK_52,
				SNRYKMK_53,
				SNRYKMK_54,
				SNRYKMK_55,
				SNRYKMK_56,
				SNRYKMK_57,
				SNRYKMK_58,
				SNRYKMK_59,
				SNRYKMK_60,
				YOBI_2,
				YOBI_3,
				YOBI_4,
				YOBI_5,
				TENSO_YMD,
				TRK_OPE_CD,
				TRK_DATE,
				TRK_PGM_ID,
				UPD_OPE_CD,
				UPD_DATE,
				UPD_PGM_ID)
				SELECT
				'103',
				A.REC_ID,
				A.SHI_CD,
				NULL,
				NULL,
				A.UPD_EIGY_YMD,
				NULL,
				A.MIKAKUNIN_FLG,
				A.DEL_YOTEI_RIYU_CD,
				A.CHOFUKU_AITSK_REC_ID,
				A.CHOFUKU_AITSK_SHI_CD,
				NULL,
				A.SEISHIKI_SHI_NM,
				A.SEISHIKI_SHI_NM_KANA,
				A.SHI_RN,
				A.SHI_RN_KANA,
				A.JUSHOFUMEI_CD,
				A.KEN_CD,
				A.SHIKU_CD,
				A.OAZA_CD,
				A.AZA_CD,
				CASE WHEN A.ZIP IS NULL THEN '' ELSE SUBSTR(A.ZIP,1,3)||'-'||SUBSTR(A.ZIP,4) END,
				A.JUSHO_KANJI_RENKETSU,
				A.JUSHO_KANA_RENKETSU,
				A.JUSHO_HYOJI_NO,
				A.KEN_NM_KANJI_MOJI_SU,
				A.SHIKU_NM_KANJI_MOJI_SU,
				A.OAZA_NM_KANJI_MOJI_SU,
				A.AZA_NM_KANJI_MOJI_SU,
				A.KEN_NM_KANA_MOJI_SU,
				A.SHIKU_NM_KANA_MOJI_SU,
				A.OAZA_NM_KANA_MOJI_SU,
				A.AZA_NM_KANA_MOJI_SU,
				A.TEL_NASHI_FLG,
				A.TEL,
				A.KEIEITAI_CD,
				A.SHI_KBN_CD,
				A.DAIHYO_REC_ID,
				A.DAIHYO_KJN_CD,
				NULL,
				B.KJN_NM,
				B.KJN_NM_KANA,
				A.KAIGYO_YOTEI_FLG,
				A.KAIGYO_YOTEI_YM,
				A.KYUIN_FLG,
				A.KYUIN_S_YM,
				A.SNRYKMK_CD_01,
				A.SNRYKMK_CD_02,
				A.SNRYKMK_CD_03,
				A.SNRYKMK_CD_04,
				A.SNRYKMK_CD_05,
				A.SNRYKMK_CD_06,
				A.SNRYKMK_CD_07,
				A.SNRYKMK_CD_08,
				A.SNRYKMK_CD_09,
				A.SNRYKMK_CD_10,
				A.SNRYKMK_CD_11,
				A.SNRYKMK_CD_12,
				A.SNRYKMK_CD_13,
				A.SNRYKMK_CD_14,
				A.SNRYKMK_CD_15,
				A.SNRYKMK_CD_16,
				A.SNRYKMK_CD_17,
				A.SNRYKMK_CD_18,
				A.SNRYKMK_CD_19,
				A.SNRYKMK_CD_20,
				A.SNRYKMK_CD_21,
				A.SNRYKMK_CD_22,
				A.SNRYKMK_CD_23,
				A.SNRYKMK_CD_24,
				A.SNRYKMK_CD_25,
				A.SNRYKMK_CD_26,
				A.SNRYKMK_CD_27,
				A.SNRYKMK_CD_28,
				A.SNRYKMK_CD_29,
				A.SNRYKMK_CD_30,
				A.SNRYKMK_CD_31,
				A.SNRYKMK_CD_32,
				A.SNRYKMK_CD_33,
				A.SNRYKMK_CD_34,
				A.SNRYKMK_CD_35,
				A.SNRYKMK_CD_36,
				A.SNRYKMK_CD_37,
				A.SNRYKMK_CD_38,
				A.SNRYKMK_CD_39,
				A.SNRYKMK_CD_40,
				A.SNRYKMK_CD_41,
				A.SNRYKMK_CD_42,
				A.SNRYKMK_CD_43,
				A.SNRYKMK_CD_44,
				A.SNRYKMK_CD_45,
				A.SNRYKMK_CD_46,
				A.SNRYKMK_CD_47,
				A.SNRYKMK_CD_48,
				A.SNRYKMK_CD_49,
				A.SNRYKMK_CD_50,
				A.SNRYKMK_CD_51,
				A.SNRYKMK_CD_52,
				A.SNRYKMK_CD_53,
				A.SNRYKMK_CD_54,
				A.SNRYKMK_CD_55,
				A.SNRYKMK_CD_56,
				A.SNRYKMK_CD_57,
				A.SNRYKMK_CD_58,
				A.SNRYKMK_CD_59,
				A.SNRYKMK_CD_60,
				NULL,
				NULL,
				NULL,
				NULL,
				iTensoYMD,
				iOPE_CD,
				iDATE,
				iPGM_ID,
				iOPE_CD,
				iDATE,
				iPGM_ID
				FROM TT_TIKY_SHI A
				LEFT OUTER JOIN TT_TIKY_KJN B
				ON A.DAIHYO_REC_ID = B.REC_ID
				AND A.DAIHYO_KJN_CD = B.KJN_CD
				WHERE A.REC_ID = '04'
				AND A.DEL_FLG IS NULL;
				-- �V_�S��_DNF���Ȏ{�݃e�[�u���̓o�^
				EXECUTE_SQL :=  'INSERT INTO TD_NA_DNF_SHI(		'  ||
						'LAYOUT_KBN,				'  ||
						'SHIREC_ID,				'  ||
						'SHI_CD,				'  ||
						'SHI_CD_YOBI,				'  ||
						'MOD_KBN,				'  ||
						'MENTE_YMD,				'  ||
						'YOBI_1,				'  ||
						'MIKAKUNIN_FLG,				'  ||
						'DEL_YOTEI_RIYU,			'  ||
						'AITSK_CD_SHIREC_ID,			'  ||
						'AITSK_CD_SHI_CD,			'  ||
						'AITSK_CD_SHI_CD_YOBI,			'  ||
						'SEISHIKI_SHI_NM_KANJI,			'  ||
						'SEISHIKI_SHI_NM_KANA,			'  ||
						'RYKSK_SHI_NM_KANJI,			'  ||
						'RYKSK_SHI_NM_KANA,			'  ||
						'JUSHOFUMEI,				'  ||
						'JUSHO_CD_KEN_CD,			'  ||
						'JUSHO_CD_SHIKU_CD,			'  ||
						'JUSHO_CD_OAZA_CD,			'  ||
						'JUSHO_CD_AZA_CD,			'  ||
						'ZIP,					'  ||
						'JUSHO_KANJI,				'  ||
						'JUSHO_KANA,				'  ||
						'JUSHO_HYOJI_NO,			'  ||
						'JUSHO_COUNT_KANJI_KEN,			'  ||
						'JUSHO_COUNT_KANJI_SHIKU,		'  ||
						'JUSHO_COUNT_KANJI_OAZA,		'  ||
						'JUSHO_COUNT_KANJI_AZA,			'  ||
						'JUSHO_COUNT_KANA_KEN,			'  ||
						'JUSHO_COUNT_KANA_SHIKU,		'  ||
						'JUSHO_COUNT_KANA_OAZA,			'  ||
						'JUSHO_COUNT_KANA_AZA,			'  ||
						'TEL_NASHI_FLG,				'  ||
						'TEL,					'  ||
						'KEIEITAI,				'  ||
						'SHI_KBN,				'  ||
						'DAIHYO_KJNREC_ID,			'  ||
						'DAIHYO_KJN_CD,				'  ||
						'DAIHYO_KJN_CD_YOBI,			'  ||
						'DAIHYO_KANJI,				'  ||
						'DAIHYO_KANA,				'  ||
						'KAIGYO_YOTEI_KAIGYO_YOTEI_FLG,		'  ||
						'KAIGYO_YOTEI_KAIGYO_YOTEI_YM,		'  ||
						'KYUIN_KYUIN_FLG,			'  ||
						'KYUIN_KYUIN_S_YM,			'  ||
						'SNRYKMK_1,				'  ||
						'SNRYKMK_2,				'  ||
						'SNRYKMK_3,				'  ||
						'SNRYKMK_4,				'  ||
						'SNRYKMK_5,				'  ||
						'SNRYKMK_6,				'  ||
						'SNRYKMK_7,				'  ||
						'SNRYKMK_8,				'  ||
						'SNRYKMK_9,				'  ||
						'SNRYKMK_10,				'  ||
						'SNRYKMK_11,				'  ||
						'SNRYKMK_12,				'  ||
						'SNRYKMK_13,				'  ||
						'SNRYKMK_14,				'  ||
						'SNRYKMK_15,				'  ||
						'SNRYKMK_16,				'  ||
						'SNRYKMK_17,				'  ||
						'SNRYKMK_18,				'  ||
						'SNRYKMK_19,				'  ||
						'SNRYKMK_20,				'  ||
						'SNRYKMK_21,				'  ||
						'SNRYKMK_22,				'  ||
						'SNRYKMK_23,				'  ||
						'SNRYKMK_24,				'  ||
						'SNRYKMK_25,				'  ||
						'SNRYKMK_26,				'  ||
						'SNRYKMK_27,				'  ||
						'SNRYKMK_28,				'  ||
						'SNRYKMK_29,				'  ||
						'SNRYKMK_30,				'  ||
						'SNRYKMK_31,				'  ||
						'SNRYKMK_32,				'  ||
						'SNRYKMK_33,				'  ||
						'SNRYKMK_34,				'  ||
						'SNRYKMK_35,				'  ||
						'SNRYKMK_36,				'  ||
						'SNRYKMK_37,				'  ||
						'SNRYKMK_38,				'  ||
						'SNRYKMK_39,				'  ||
						'SNRYKMK_40,				'  ||
						'SNRYKMK_41,				'  ||
						'SNRYKMK_42,				'  ||
						'SNRYKMK_43,				'  ||
						'SNRYKMK_44,				'  ||
						'SNRYKMK_45,				'  ||
						'SNRYKMK_46,				'  ||
						'SNRYKMK_47,				'  ||
						'SNRYKMK_48,				'  ||
						'SNRYKMK_49,				'  ||
						'SNRYKMK_50,				'  ||
						'SNRYKMK_51,				'  ||
						'SNRYKMK_52,				'  ||
						'SNRYKMK_53,				'  ||
						'SNRYKMK_54,				'  ||
						'SNRYKMK_55,				'  ||
						'SNRYKMK_56,				'  ||
						'SNRYKMK_57,				'  ||
						'SNRYKMK_58,				'  ||
						'SNRYKMK_59,				'  ||
						'SNRYKMK_60,				'  ||
						'YOBI_2,				'  ||
						'YOBI_3,				'  ||
						'YOBI_4,				'  ||
						'YOBI_5,				'  ||
						'TENSO_YMD,				'  ||
						'TRK_OPE_CD,				'  ||
						'TRK_DATE,				'  ||
						'TRK_PGM_ID,				'  ||
						'UPD_OPE_CD,				'  ||
						'UPD_DATE,				'  ||
						'UPD_PGM_ID)				'  ||
							'SELECT 					'  ||
							'''103'''					|| ','	||
							'A.REC_ID,					'  ||
							'A.SHI_CD,					'  ||
							'NULL,						'  ||
							'NULL,						'  ||
							'A.UPD_EIGY_YMD,				'  ||
							'NULL,						'  ||
							'A.MIKAKUNIN_FLG,				'  ||
							'A.DEL_YOTEI_RIYU_CD,				'  ||
							'A.CHOFUKU_AITSK_REC_ID,			'  ||
							'A.CHOFUKU_AITSK_SHI_CD,			'  ||
							'NULL,						'  ||
							'A.SEISHIKI_SHI_NM,				'  ||
							'A.SEISHIKI_SHI_NM_KANA,			'  ||
							'A.SHI_RN,					'  ||
							'A.SHI_RN_KANA,					'  ||
							'A.JUSHOFUMEI_CD,				'  ||
							'A.KEN_CD,					'  ||
							'A.SHIKU_CD,					'  ||
							'A.OAZA_CD,					'  ||
							'A.AZA_CD,					'  ||
							'CASE WHEN A.ZIP IS NULL THEN '''' ELSE SUBSTR(A.ZIP,1,3)||''-''||SUBSTR(A.ZIP,4) END,'  ||
							'A.JUSHO_KANJI_RENKETSU,			'  ||
							'A.JUSHO_KANA_RENKETSU,				'  ||
							'A.JUSHO_HYOJI_NO,				'  ||
							'A.KEN_NM_KANJI_MOJI_SU,			'  ||
							'A.SHIKU_NM_KANJI_MOJI_SU,			'  ||
							'A.OAZA_NM_KANJI_MOJI_SU,			'  ||
							'A.AZA_NM_KANJI_MOJI_SU,			'  ||
							'A.KEN_NM_KANA_MOJI_SU,				'  ||
							'A.SHIKU_NM_KANA_MOJI_SU,			'  ||
							'A.OAZA_NM_KANA_MOJI_SU,			'  ||
							'A.AZA_NM_KANA_MOJI_SU,				'  ||
							'A.TEL_NASHI_FLG,				'  ||
							'A.TEL,						'  ||
							'A.KEIEITAI_CD,					'  ||
							'A.SHI_KBN_CD,					'  ||
							'A.DAIHYO_REC_ID,				'  ||
							'A.DAIHYO_KJN_CD,				'  ||
							'NULL,						'  ||
							'B.KJN_NM,					'  ||
							'B.KJN_NM_KANA,					'  ||
							'A.KAIGYO_YOTEI_FLG,				'  ||
							'A.KAIGYO_YOTEI_YM,				'  ||
							'A.KYUIN_FLG,					'  ||
							'A.KYUIN_S_YM,					'  ||
							'A.SNRYKMK_CD_01,				'  ||
							'A.SNRYKMK_CD_02,				'  ||
							'A.SNRYKMK_CD_03,				'  ||
							'A.SNRYKMK_CD_04,				'  ||
							'A.SNRYKMK_CD_05,				'  ||
							'A.SNRYKMK_CD_06,				'  ||
							'A.SNRYKMK_CD_07,				'  ||
							'A.SNRYKMK_CD_08,				'  ||
							'A.SNRYKMK_CD_09,				'  ||
							'A.SNRYKMK_CD_10,				'  ||
							'A.SNRYKMK_CD_11,				'  ||
							'A.SNRYKMK_CD_12,				'  ||
							'A.SNRYKMK_CD_13,				'  ||
							'A.SNRYKMK_CD_14,				'  ||
							'A.SNRYKMK_CD_15,				'  ||
							'A.SNRYKMK_CD_16,				'  ||
							'A.SNRYKMK_CD_17,				'  ||
							'A.SNRYKMK_CD_18,				'  ||
							'A.SNRYKMK_CD_19,				'  ||
							'A.SNRYKMK_CD_20,				'  ||
							'A.SNRYKMK_CD_21,				'  ||
							'A.SNRYKMK_CD_22,				'  ||
							'A.SNRYKMK_CD_23,				'  ||
							'A.SNRYKMK_CD_24,				'  ||
							'A.SNRYKMK_CD_25,				'  ||
							'A.SNRYKMK_CD_26,				'  ||
							'A.SNRYKMK_CD_27,				'  ||
							'A.SNRYKMK_CD_28,				'  ||
							'A.SNRYKMK_CD_29,				'  ||
							'A.SNRYKMK_CD_30,				'  ||
							'A.SNRYKMK_CD_31,				'  ||
							'A.SNRYKMK_CD_32,				'  ||
							'A.SNRYKMK_CD_33,				'  ||
							'A.SNRYKMK_CD_34,				'  ||
							'A.SNRYKMK_CD_35,				'  ||
							'A.SNRYKMK_CD_36,				'  ||
							'A.SNRYKMK_CD_37,				'  ||
							'A.SNRYKMK_CD_38,				'  ||
							'A.SNRYKMK_CD_39,				'  ||
							'A.SNRYKMK_CD_40,				'  ||
							'A.SNRYKMK_CD_41,				'  ||
							'A.SNRYKMK_CD_42,				'  ||
							'A.SNRYKMK_CD_43,				'  ||
							'A.SNRYKMK_CD_44,				'  ||
							'A.SNRYKMK_CD_45,				'  ||
							'A.SNRYKMK_CD_46,				'  ||
							'A.SNRYKMK_CD_47,				'  ||
							'A.SNRYKMK_CD_48,				'  ||
							'A.SNRYKMK_CD_49,				'  ||
							'A.SNRYKMK_CD_50,				'  ||
							'A.SNRYKMK_CD_51,				'  ||
							'A.SNRYKMK_CD_52,				'  ||
							'A.SNRYKMK_CD_53,				'  ||
							'A.SNRYKMK_CD_54,				'  ||
							'A.SNRYKMK_CD_55,				'  ||
							'A.SNRYKMK_CD_56,				'  ||
							'A.SNRYKMK_CD_57,				'  ||
							'A.SNRYKMK_CD_58,				'  ||
							'A.SNRYKMK_CD_59,				'  ||
							'A.SNRYKMK_CD_60,				'  ||
							'NULL,						'  ||
							'NULL,						'  ||
							'NULL,						'  ||
							'NULL,						'  ||
							 iTensoYMD 				|| ','	||
							 iOPE_CD 				|| ','	||
							 iDATE 					|| ','	||
							 iPGM_ID 				|| ','	||
							 iOPE_CD 				|| ','	||
							 iDATE 					|| ','	||
							 iPGM_ID				||
							'FROM TT_TIKY_SHI A			'  ||
							'LEFT OUTER JOIN TT_TIKY_KJN B		'  ||
							'ON A.DAIHYO_REC_ID = B.REC_ID		'  ||
							'AND A.DAIHYO_KJN_CD = B.KJN_CD		'  ||
							'WHERE A.REC_ID = ''04''		'  ||
							'AND A.DEL_FLG IS NULL			';

				ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

	        -- �b�背�C�A�E�g
	        ELSIF iLayoutKind = 2 THEN

			--�b��_�S��_DNF���Ȏ{�݃e�[�u���̃f�[�^���N���A����B
			EXECUTE_SQL := 'TRUNCATE TABLE ' || V_SCHEMA_NM || '.' || 'TD_PA_DNF_SHI';
			EXECUTE IMMEDIATE EXECUTE_SQL;
			ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

			INSERT INTO TD_PA_DNF_SHI(
				SHIREC_ID,
				SHI_CD,
				SHI_CD_YOBI,
				SEISHIKI_SHI_NM_KANA,
				RYKSK_SHI_NM_KANA,
				JUSHO_CD_KEN_CD,
				JUSHO_CD_SHIKU_CD,
				JUSHO_CD_OAZA_CD,
				JUSHO_CD_AZA_CD,
				ZIP,
				JUSHO_HYOJI_NO,
				YOBI_1,
				JUSHO_KANA,
				JUSHO_COUNT_KANA_KEN,
				JUSHO_COUNT_KANA_SHIKU,
				JUSHO_COUNT_KANA_OAZA,
				JUSHO_COUNT_KANA_AZA,
				JUSHO_COUNT_KANJI_KEN,
				JUSHO_COUNT_KANJI_SHIKU,
				JUSHO_COUNT_KANJI_OAZA,
				JUSHO_COUNT_KANJI_AZA,
				SHI_TEL,
				YOBI_2,
				KEIEITAI,
				SHI_KBN,
				YOBI_3,
				YOBI_4,
				YOBI_5,
				YOBI_6,
				YOBI_7,
				STATUS_JUSHOFUMEI,
				STATUS_KYUIN_FLG,
				STATUS_DEL_YOTEI_RIYU,
				STATUS_KAIGYO_YOTEI_FLG,
				STATUS_YOBI,
				STATUS_TEL_NASHI_FLG,
				STATUS_MIKAKUNIN_FLG,
				STATUS_YOBI_1,
				STATUS_YOBI_2,
				KYUIN_S_KAIGYO_YOTEI_Y,
				KYUIN_S_KAIGYO_YOTEI_M,
				YOBI_8,
				YOBI_9,
				YOBI_10,
				YOBI_11,
				YOBI_12,
				YOBI_13,
				YOBI_14,
				YOBI_15,
				YOBI_16,
				TAIO_DCF_SHI_SHI_CD_REC_ID,
				TAIO_DCF_SHI_SHI_CD,
				TAIO_DCF_SHI_SHI_CD_YOBI,
				SNRYKMK_1,
				SNRYKMK_2,
				SNRYKMK_3,
				SNRYKMK_4,
				SNRYKMK_5,
				SNRYKMK_6,
				SNRYKMK_7,
				SNRYKMK_8,
				SNRYKMK_9,
				SNRYKMK_10,
				SNRYKMK_11,
				SNRYKMK_12,
				SNRYKMK_13,
				SNRYKMK_14,
				SNRYKMK_15,
				SNRYKMK_16,
				SNRYKMK_17,
				SNRYKMK_18,
				SNRYKMK_19,
				SNRYKMK_20,
				SNRYKMK_21,
				SNRYKMK_22,
				SNRYKMK_23,
				SNRYKMK_24,
				SNRYKMK_25,
				SNRYKMK_26,
				SNRYKMK_27,
				SNRYKMK_28,
				SNRYKMK_29,
				SNRYKMK_30,
				SNRYKMK_31,
				SNRYKMK_32,
				SNRYKMK_33,
				SNRYKMK_34,
				SNRYKMK_35,
				SNRYKMK_36,
				SNRYKMK_37,
				SNRYKMK_38,
				SNRYKMK_39,
				SNRYKMK_40,
				SNRYKMK_41,
				SNRYKMK_42,
				SNRYKMK_43,
				SNRYKMK_44,
				SNRYKMK_45,
				SNRYKMK_46,
				SNRYKMK_47,
				SNRYKMK_48,
				SNRYKMK_49,
				SNRYKMK_50,
				SNRYKMK_51,
				SNRYKMK_52,
				SNRYKMK_53,
				SNRYKMK_54,
				SNRYKMK_55,
				SNRYKMK_56,
				SNRYKMK_57,
				SNRYKMK_58,
				SNRYKMK_59,
				SNRYKMK_60,
				SEISHIKI_SHI_NM_KANJI,
				RYKSK_SHI_NM_KANJI,
				JUSHO_KANJI,
				SHI_DAIHYO_KJNREC_ID,
				SHI_DAIHYO_KJN_CD,
				SHI_DAIHYO_KJN_CD_YOBI,
				SHI_DAIHYO_KANA,
				SHI_DAIHYO_KANJI,
				SHI_YOBI_AREA,
				AITSK_CD_SHIREC_ID,
				AITSK_CD_SHI_CD,
				AITSK_CD_SHI_CD_YOBI,
				MOD_SHORI_HIZUKE_Y,
				MOD_SHORI_HIZUKE_M,
				MOD_SHORI_HIZUKE_D,
				TENSO_Y,
				TENSO_M,
				TENSO_D,
				SHIN_SEISHIKI_SHI_NM_KANJI,
				SHIN_SEISHIKI_SHI_NM_KANA,
				MOD_KBN,
				TRK_OPE_CD,
				TRK_DATE,
				TRK_PGM_ID,
				UPD_OPE_CD,
				UPD_DATE,
				UPD_PGM_ID)
				SELECT
				A.REC_ID,
				A.SHI_CD,
				NULL,
				A.SEISHIKI_SHI_NM_KANA40,
				A.SHI_RN_KANA,
				A.KEN_CD,
				A.SHIKU_CD,
				A.OAZA_CD,
				A.AZA_CD,
				CASE WHEN A.ZIP IS NULL THEN '' ELSE SUBSTR(A.ZIP,1,3)||'-'||SUBSTR(A.ZIP,4) END,
				A.JUSHO_HYOJI_NO,
				NULL,
				A.JUSHO_KANA_RENKETSU,
				TO_CHAR(A.KEN_NM_KANA_MOJI_SU,'FM09'),
				TO_CHAR(A.SHIKU_NM_KANA_MOJI_SU,'FM09'),
				TO_CHAR(A.OAZA_NM_KANA_MOJI_SU,'FM09'),
				TO_CHAR(A.AZA_NM_KANA_MOJI_SU,'FM09'),
				TO_CHAR(A.KEN_NM_KANJI_MOJI_SU,'FM09'),
				TO_CHAR(A.SHIKU_NM_KANJI_MOJI_SU,'FM09'),
				TO_CHAR(A.OAZA_NM_KANJI_MOJI_SU,'FM09'),
				TO_CHAR(A.AZA_NM_KANJI_MOJI_SU,'FM09'),
				A.TEL,
				NULL,
				A.KEIEITAI_CD,
				A.SHI_KBN_CD,
				NULL,
				NULL,
				NULL,
				NULL,
				NULL,
				A.JUSHOFUMEI_CD,
				A.KYUIN_FLG,
				A.DEL_YOTEI_RIYU_CD,
				A.KAIGYO_YOTEI_FLG,
				NULL,
				A.TEL_NASHI_FLG,
				A.MIKAKUNIN_FLG,
				NULL,
				NULL,
				CASE WHEN A.KYUIN_FLG = '1' THEN SUBSTR(A.KYUIN_S_YM,1,4) WHEN A.KAIGYO_YOTEI_FLG = '1' THEN SUBSTR(A.KAIGYO_YOTEI_YM,1,4) END,
				CASE WHEN A.KYUIN_FLG = '1' THEN SUBSTR(A.KYUIN_S_YM,5,2) WHEN A.KAIGYO_YOTEI_FLG = '1' THEN SUBSTR(A.KAIGYO_YOTEI_YM,5,2) END,
				NULL,
				NULL,
				NULL,
				NULL,
				NULL,
				NULL,
				NULL,
				NULL,
				NULL,
				A.DCFCHOFUKU_REC_ID,
				A.DCFCHOFUKU_SHI_CD,
				NULL,
				A.SNRYKMK_CD_01,
				A.SNRYKMK_CD_02,
				A.SNRYKMK_CD_03,
				A.SNRYKMK_CD_04,
				A.SNRYKMK_CD_05,
				A.SNRYKMK_CD_06,
				A.SNRYKMK_CD_07,
				A.SNRYKMK_CD_08,
				A.SNRYKMK_CD_09,
				A.SNRYKMK_CD_10,
				A.SNRYKMK_CD_11,
				A.SNRYKMK_CD_12,
				A.SNRYKMK_CD_13,
				A.SNRYKMK_CD_14,
				A.SNRYKMK_CD_15,
				A.SNRYKMK_CD_16,
				A.SNRYKMK_CD_17,
				A.SNRYKMK_CD_18,
				A.SNRYKMK_CD_19,
				A.SNRYKMK_CD_20,
				A.SNRYKMK_CD_21,
				A.SNRYKMK_CD_22,
				A.SNRYKMK_CD_23,
				A.SNRYKMK_CD_24,
				A.SNRYKMK_CD_25,
				A.SNRYKMK_CD_26,
				A.SNRYKMK_CD_27,
				A.SNRYKMK_CD_28,
				A.SNRYKMK_CD_29,
				A.SNRYKMK_CD_30,
				A.SNRYKMK_CD_31,
				A.SNRYKMK_CD_32,
				A.SNRYKMK_CD_33,
				A.SNRYKMK_CD_34,
				A.SNRYKMK_CD_35,
				A.SNRYKMK_CD_36,
				A.SNRYKMK_CD_37,
				A.SNRYKMK_CD_38,
				A.SNRYKMK_CD_39,
				A.SNRYKMK_CD_40,
				A.SNRYKMK_CD_41,
				A.SNRYKMK_CD_42,
				A.SNRYKMK_CD_43,
				A.SNRYKMK_CD_44,
				A.SNRYKMK_CD_45,
				A.SNRYKMK_CD_46,
				A.SNRYKMK_CD_47,
				A.SNRYKMK_CD_48,
				A.SNRYKMK_CD_49,
				A.SNRYKMK_CD_50,
				A.SNRYKMK_CD_51,
				A.SNRYKMK_CD_52,
				A.SNRYKMK_CD_53,
				A.SNRYKMK_CD_54,
				A.SNRYKMK_CD_55,
				A.SNRYKMK_CD_56,
				A.SNRYKMK_CD_57,
				A.SNRYKMK_CD_58,
				A.SNRYKMK_CD_59,
				A.SNRYKMK_CD_60,
				A.SEISHIKI_SHI_NM30,
				A.SHI_RN,
				A.JUSHO_KANJI_RENKETSU,
				A.DAIHYO_REC_ID,
				A.DAIHYO_KJN_CD,
				NULL,
				B.KJN_NM_KANA,
				B.KJN_NM,
				NULL,
				A.CHOFUKU_AITSK_REC_ID,
				A.CHOFUKU_AITSK_SHI_CD,
				NULL,
				SUBSTR(A.UPD_EIGY_YMD,1,4),
				SUBSTR(A.UPD_EIGY_YMD,5,2),
				SUBSTR(A.UPD_EIGY_YMD,7,2),
				SUBSTR(iTensoYMD,1,4),
				SUBSTR(iTensoYMD,5,2),
				SUBSTR(iTensoYMD,7,2),
				A.SEISHIKI_SHI_NM,
				A.SEISHIKI_SHI_NM_KANA,
				NULL,
				iOPE_CD,
				iDATE,
				iPGM_ID,
				iOPE_CD,
				iDATE,
				iPGM_ID
				FROM TT_TIKY_SHI A
				LEFT OUTER JOIN TT_TIKY_KJN B
				ON A.DAIHYO_REC_ID = B.REC_ID
				AND A.DAIHYO_KJN_CD = B.KJN_CD
				WHERE A.REC_ID = '04'
				AND A.DEL_FLG IS NULL;
				-- �b��_�S��_DNF���Ȏ{�݃e�[�u���̓o�^
				EXECUTE_SQL :=  'INSERT TD_PA_DNF_SHI(			'  ||
						'SHIREC_ID,				'  ||
						'SHI_CD,				'  ||
						'SHI_CD_YOBI,				'  ||
						'SEISHIKI_SHI_NM_KANA,			'  ||
						'RYKSK_SHI_NM_KANA,			'  ||
						'JUSHO_CD_KEN_CD,			'  ||
						'JUSHO_CD_SHIKU_CD,			'  ||
						'JUSHO_CD_OAZA_CD,			'  ||
						'JUSHO_CD_AZA_CD,			'  ||
						'ZIP,					'  ||
						'JUSHO_HYOJI_NO,			'  ||
						'YOBI_1,				'  ||
						'JUSHO_KANA,				'  ||
						'JUSHO_COUNT_KANA_KEN,			'  ||
						'JUSHO_COUNT_KANA_SHIKU,		'  ||
						'JUSHO_COUNT_KANA_OAZA,			'  ||
						'JUSHO_COUNT_KANA_AZA,			'  ||
						'JUSHO_COUNT_KANJI_KEN,			'  ||
						'JUSHO_COUNT_KANJI_SHIKU,		'  ||
						'JUSHO_COUNT_KANJI_OAZA,		'  ||
						'JUSHO_COUNT_KANJI_AZA,			'  ||
						'SHI_TEL,				'  ||
						'YOBI_2,				'  ||
						'KEIEITAI,				'  ||
						'SHI_KBN,				'  ||
						'YOBI_3,				'  ||
						'YOBI_4,				'  ||
						'YOBI_5,				'  ||
						'YOBI_6,				'  ||
						'YOBI_7,				'  ||
						'STATUS_JUSHOFUMEI,			'  ||
						'STATUS_KYUIN_FLG,			'  ||
						'STATUS_DEL_YOTEI_RIYU,			'  ||
						'STATUS_KAIGYO_YOTEI_FLG,		'  ||
						'STATUS_YOBI,				'  ||
						'STATUS_TEL_NASHI_FLG,			'  ||
						'STATUS_MIKAKUNIN_FLG,			'  ||
						'STATUS_YOBI_1,				'  ||
						'STATUS_YOBI_2,				'  ||
						'KYUIN_S_KAIGYO_YOTEI_Y,		'  ||
						'KYUIN_S_KAIGYO_YOTEI_M,		'  ||
						'YOBI_8,				'  ||
						'YOBI_9,				'  ||
						'YOBI_10,				'  ||
						'YOBI_11,				'  ||
						'YOBI_12,				'  ||
						'YOBI_13,				'  ||
						'YOBI_14,				'  ||
						'YOBI_15,				'  ||
						'YOBI_16,				'  ||
						'TAIO_DCF_SHI_SHI_CD_REC_ID,		'  ||
						'TAIO_DCF_SHI_SHI_CD,			'  ||
						'TAIO_DCF_SHI_SHI_CD_YOBI,		'  ||
						'SNRYKMK_1,				'  ||
						'SNRYKMK_2,				'  ||
						'SNRYKMK_3,				'  ||
						'SNRYKMK_4,				'  ||
						'SNRYKMK_5,				'  ||
						'SNRYKMK_6,				'  ||
						'SNRYKMK_7,				'  ||
						'SNRYKMK_8,				'  ||
						'SNRYKMK_9,				'  ||
						'SNRYKMK_10,				'  ||
						'SNRYKMK_11,				'  ||
						'SNRYKMK_12,				'  ||
						'SNRYKMK_13,				'  ||
						'SNRYKMK_14,				'  ||
						'SNRYKMK_15,				'  ||
						'SNRYKMK_16,				'  ||
						'SNRYKMK_17,				'  ||
						'SNRYKMK_18,				'  ||
						'SNRYKMK_19,				'  ||
						'SNRYKMK_20,				'  ||
						'SNRYKMK_21,				'  ||
						'SNRYKMK_22,				'  ||
						'SNRYKMK_23,				'  ||
						'SNRYKMK_24,				'  ||
						'SNRYKMK_25,				'  ||
						'SNRYKMK_26,				'  ||
						'SNRYKMK_27,				'  ||
						'SNRYKMK_28,				'  ||
						'SNRYKMK_29,				'  ||
						'SNRYKMK_30,				'  ||
						'SNRYKMK_31,				'  ||
						'SNRYKMK_32,				'  ||
						'SNRYKMK_33,				'  ||
						'SNRYKMK_34,				'  ||
						'SNRYKMK_35,				'  ||
						'SNRYKMK_36,				'  ||
						'SNRYKMK_37,				'  ||
						'SNRYKMK_38,				'  ||
						'SNRYKMK_39,				'  ||
						'SNRYKMK_40,				'  ||
						'SNRYKMK_41,				'  ||
						'SNRYKMK_42,				'  ||
						'SNRYKMK_43,				'  ||
						'SNRYKMK_44,				'  ||
						'SNRYKMK_45,				'  ||
						'SNRYKMK_46,				'  ||
						'SNRYKMK_47,				'  ||
						'SNRYKMK_48,				'  ||
						'SNRYKMK_49,				'  ||
						'SNRYKMK_50,				'  ||
						'SNRYKMK_51,				'  ||
						'SNRYKMK_52,				'  ||
						'SNRYKMK_53,				'  ||
						'SNRYKMK_54,				'  ||
						'SNRYKMK_55,				'  ||
						'SNRYKMK_56,				'  ||
						'SNRYKMK_57,				'  ||
						'SNRYKMK_58,				'  ||
						'SNRYKMK_59,				'  ||
						'SNRYKMK_60,				'  ||
						'SEISHIKI_SHI_NM_KANJI,			'  ||
						'RYKSK_SHI_NM_KANJI,			'  ||
						'JUSHO_KANJI,				'  ||
						'SHI_DAIHYO_KJNREC_ID,			'  ||
						'SHI_DAIHYO_KJN_CD,			'  ||
						'SHI_DAIHYO_KJN_CD_YOBI,		'  ||
						'SHI_DAIHYO_KANA,			'  ||
						'SHI_DAIHYO_KANJI,			'  ||
						'SHI_YOBI_AREA,				'  ||
						'AITSK_CD_SHIREC_ID,			'  ||
						'AITSK_CD_SHI_CD,			'  ||
						'AITSK_CD_SHI_CD_YOBI,			'  ||
						'MOD_SHORI_HIZUKE_Y,			'  ||
						'MOD_SHORI_HIZUKE_M,			'  ||
						'MOD_SHORI_HIZUKE_D,			'  ||
						'TENSO_Y,				'  ||
						'TENSO_M,				'  ||
						'TENSO_D,				'  ||
						'SHIN_SEISHIKI_SHI_NM_KANJI,		'  ||
						'SHIN_SEISHIKI_SHI_NM_KANA,		'  ||
						'MOD_KBN,				'  ||
						'TRK_OPE_CD,				'  ||
						'TRK_DATE,				'  ||
						'TRK_PGM_ID,				'  ||
						'UPD_OPE_CD,				'  ||
						'UPD_DATE,				'  ||
						'UPD_PGM_ID)				'  ||
							'SELECT 					'  ||
							'A.REC_ID,					'  ||
							'A.SHI_CD,					'  ||
							'NULL,						'  ||
							'A.SEISHIKI_SHI_NM_KANA40,			'  ||
							'A.SHI_RN_KANA,					'  ||
							'A.KEN_CD,					'  ||
							'A.SHIKU_CD,					'  ||
							'A.OAZA_CD,					'  ||
							'A.AZA_CD,					'  ||
							'CASE WHEN A.ZIP IS NULL THEN '''' ELSE SUBSTR(A.ZIP,1,3)||''-''||SUBSTR(A.ZIP,4) END,	'  ||
							'A.JUSHO_HYOJI_NO,				'  ||
							'NULL,						'  ||
							'A.JUSHO_KANA_RENKETSU,				'  ||
							'TO_CHAR(A.KEN_NM_KANA_MOJI_SU,''FM09''),	'  ||
							'TO_CHAR(A.SHIKU_NM_KANA_MOJI_SU,''FM09''),	'  ||
							'TO_CHAR(A.OAZA_NM_KANA_MOJI_SU,''FM09''),	'  ||
							'TO_CHAR(A.AZA_NM_KANA_MOJI_SU,''FM09''),	'  ||
							'TO_CHAR(A.KEN_NM_KANJI_MOJI_SU,''FM09''),	'  ||
							'TO_CHAR(A.SHIKU_NM_KANJI_MOJI_SU,''FM09''),	'  ||
							'TO_CHAR(A.OAZA_NM_KANJI_MOJI_SU,''FM09''),	'  ||
							'TO_CHAR(A.AZA_NM_KANJI_MOJI_SU,''FM09''),	'  ||
							'A.TEL,						'  ||
							'NULL,						'  ||
							'A.KEIEITAI_CD,					'  ||
							'A.SHI_KBN_CD,					'  ||
							'NULL,						'  ||
							'NULL,						'  ||
							'NULL,						'  ||
							'NULL,						'  ||
							'NULL,						'  ||
							'A.JUSHOFUMEI_CD,				'  ||
							'A.KYUIN_FLG,					'  ||
							'A.DEL_YOTEI_RIYU_CD,				'  ||
							'A.KAIGYO_YOTEI_FLG,				'  ||
							'NULL,						'  ||
							'A.TEL_NASHI_FLG,				'  ||
							'A.MIKAKUNIN_FLG,				'  ||
							'NULL,						'  ||
							'NULL,						'  ||
							'CASE WHEN A.KYUIN_FLG = ''1'' THEN SUBSTR(A.KYUIN_S_YM,1,4) WHEN A.KAIGYO_YOTEI_FLG = ''1'' THEN SUBSTR(A.KAIGYO_YOTEI_YM,1,4) END,	'  ||
							'CASE WHEN A.KYUIN_FLG = ''1'' THEN SUBSTR(A.KYUIN_S_YM,5,2) WHEN A.KAIGYO_YOTEI_FLG = ''1'' THEN SUBSTR(A.KAIGYO_YOTEI_YM,5,2) END,	'  ||
							'NULL,						'  ||
							'NULL,						'  ||
							'NULL,						'  ||
							'NULL,						'  ||
							'NULL,						'  ||
							'NULL,						'  ||
							'NULL,						'  ||
							'NULL,						'  ||
							'NULL,						'  ||
							'A.DCFCHOFUKU_REC_ID,				'  ||
							'A.DCFCHOFUKU_SHI_CD,				'  ||
							'NULL,						'  ||
							'A.SNRYKMK_CD_01,				'  ||
							'A.SNRYKMK_CD_02,				'  ||
							'A.SNRYKMK_CD_03,				'  ||
							'A.SNRYKMK_CD_04,				'  ||
							'A.SNRYKMK_CD_05,				'  ||
							'A.SNRYKMK_CD_06,				'  ||
							'A.SNRYKMK_CD_07,				'  ||
							'A.SNRYKMK_CD_08,				'  ||
							'A.SNRYKMK_CD_09,				'  ||
							'A.SNRYKMK_CD_10,				'  ||
							'A.SNRYKMK_CD_11,				'  ||
							'A.SNRYKMK_CD_12,				'  ||
							'A.SNRYKMK_CD_13,				'  ||
							'A.SNRYKMK_CD_14,				'  ||
							'A.SNRYKMK_CD_15,				'  ||
							'A.SNRYKMK_CD_16,				'  ||
							'A.SNRYKMK_CD_17,				'  ||
							'A.SNRYKMK_CD_18,				'  ||
							'A.SNRYKMK_CD_19,				'  ||
							'A.SNRYKMK_CD_20,				'  ||
							'A.SNRYKMK_CD_21,				'  ||
							'A.SNRYKMK_CD_22,				'  ||
							'A.SNRYKMK_CD_23,				'  ||
							'A.SNRYKMK_CD_24,				'  ||
							'A.SNRYKMK_CD_25,				'  ||
							'A.SNRYKMK_CD_26,				'  ||
							'A.SNRYKMK_CD_27,				'  ||
							'A.SNRYKMK_CD_28,				'  ||
							'A.SNRYKMK_CD_29,				'  ||
							'A.SNRYKMK_CD_30,				'  ||
							'A.SNRYKMK_CD_31,				'  ||
							'A.SNRYKMK_CD_32,				'  ||
							'A.SNRYKMK_CD_33,				'  ||
							'A.SNRYKMK_CD_34,				'  ||
							'A.SNRYKMK_CD_35,				'  ||
							'A.SNRYKMK_CD_36,				'  ||
							'A.SNRYKMK_CD_37,				'  ||
							'A.SNRYKMK_CD_38,				'  ||
							'A.SNRYKMK_CD_39,				'  ||
							'A.SNRYKMK_CD_40,				'  ||
							'A.SNRYKMK_CD_41,				'  ||
							'A.SNRYKMK_CD_42,				'  ||
							'A.SNRYKMK_CD_43,				'  ||
							'A.SNRYKMK_CD_44,				'  ||
							'A.SNRYKMK_CD_45,				'  ||
							'A.SNRYKMK_CD_46,				'  ||
							'A.SNRYKMK_CD_47,				'  ||
							'A.SNRYKMK_CD_48,				'  ||
							'A.SNRYKMK_CD_49,				'  ||
							'A.SNRYKMK_CD_50,				'  ||
							'A.SNRYKMK_CD_51,				'  ||
							'A.SNRYKMK_CD_52,				'  ||
							'A.SNRYKMK_CD_53,				'  ||
							'A.SNRYKMK_CD_54,				'  ||
							'A.SNRYKMK_CD_55,				'  ||
							'A.SNRYKMK_CD_56,				'  ||
							'A.SNRYKMK_CD_57,				'  ||
							'A.SNRYKMK_CD_58,				'  ||
							'A.SNRYKMK_CD_59,				'  ||
							'A.SNRYKMK_CD_60,				'  ||
							'A.SEISHIKI_SHI_NM30,			'  ||
							'A.SHI_RN,				'  ||
							'A.JUSHO_KANJI_RENKETSU,		'  ||
							'A.DAIHYO_REC_ID,			'  ||
							'A.DAIHYO_KJN_CD,			'  ||
							'NULL,					'  ||
							'B.KJN_NM_KANA,				'  ||
							'B.KJN_NM,				'  ||
							'NULL,					'  ||
							'A.CHOFUKU_AITSK_REC_ID,		'  ||
							'A.CHOFUKU_AITSK_SHI_CD,		'  ||
							'NULL,					'  ||
							'SUBSTR(A.UPD_EIGY_YMD,1,4),		'  ||
							'SUBSTR(A.UPD_EIGY_YMD,5,2),		'  ||
							'SUBSTR(A.UPD_EIGY_YMD,7,2),		'  ||
							'SUBSTR(iTensoYMD,1,4),			'  ||
							'SUBSTR(iTensoYMD,5,2),			'  ||
							'SUBSTR(iTensoYMD,7,2),			'  ||
							'A.SEISHIKI_SHI_NM,			'  ||
							'A.SEISHIKI_SHI_NM_KANA,		'  ||
							'NULL,					'  ||
							 iOPE_CD 				|| ','	||
							 iDATE 					|| ','	||
							 iPGM_ID 				|| ','	||
							 iOPE_CD 				|| ','	||
							 iDATE 					|| ','	||
							 iPGM_ID				||
							'FROM TT_TIKY_SHI A			'  ||
							'LEFT OUTER JOIN TT_TIKY_KJN B		'  ||
							'ON A.DAIHYO_REC_ID = B.REC_ID		'  ||
							'AND A.DAIHYO_KJN_CD = B.KJN_CD		'  ||
							'WHERE A.REC_ID = ''04''		'  ||
							'AND A.DEL_FLG IS NULL			';

				ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);
		END IF;
	END IF;
	COMMIT;

        -- �I�����O�o��
        ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'PL/SQL End',PGM_ID || '�̏������I�����܂����B',iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

	return 0;
    -- ��O����
	EXCEPTION
		-- ���̑��G���[
		WHEN OTHERS THEN
			W_ERR_INF_RCD.ERR_CD 		:= TO_CHAR(SQLCODE);
			W_ERR_INF_RCD.ERR_MSG 		:= SUBSTR(SQLERRM, 0, 500);
			W_ERR_INF_RCD.ERR_KEY_INF 	:= SUBSTR('iLayoutKind:' || iLayoutKind || ', iShimeKind:' || iShimeKind , 0,500);
			W_INDEX_N 			:= W_ERR_INF_TBL.COUNT + 1;
			W_ERR_INF_TBL.EXTEND;
			W_ERR_INF_TBL(W_INDEX_N) 	:= W_ERR_INF_RCD;

			OPEN oOUT_ERR_INF_CSR FOR
				SELECT * FROM TABLE(W_ERR_INF_TBL);

			ROLLBACK;
			-- �G���[���O�̓o�^
          		ULT_INSERT_LOG_TABLE('ERROR',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'ERROR_INFO',W_ERR_INF_RCD.ERR_MSG,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);
			return 1;
        END;
    END;
/
