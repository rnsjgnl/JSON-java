CREATE OR REPLACE PACKAGE NH010107B001_101
/* **********************************************************
 *  Copyright(c) 2011 beyond, INTEC Inc. All rights reserved.
 * **********************************************************/
AUTHID CURRENT_USER
IS
	/*** �J�[�\���^ ***************************************************************/
	-- �G���[���i�[�p�J�[�\���^
	TYPE ERR_INF_CSR		IS REF CURSOR;
  

  
  

	/*
	************************************************************************
	*  DCF�{�ݑf��DB�f�[�^�̍쐬
	*  CREATE_DCF_SHISETSU
	************************************************************************
	*/
	FUNCTION CREATE_DCF_SHISETSU(
	iLayoutKind	IN	VARCHAR2,										-- ���C�A�E�g�敪
	iShimeKind	IN	VARCHAR2,										-- ���ߓ��敪
  iShimeFrom	IN	VARCHAR2,										-- ���ߔ͈́iFrom�j
  iShimeTo	IN	VARCHAR2,										-- ���ߔ͈́iTo�j
  iTensoYMD	IN	VARCHAR2,										-- �]���N���� 
  iM2Flg IN	VARCHAR2,										    -- ���Q���߃t���O
	iIP_ADDR	IN TL_STORED_SHORI.IP%TYPE,							-- ���s�[��IP�A�h���X (FW�Őݒ�)
	iWINDOWS_LOGIN_USER	IN TL_STORED_SHORI.WINDOWS_LOGIN_USER%TYPE, -- ���s�[��OS���[�U�[ (FW�Őݒ�)
	oROW_COUNT	OUT NUMBER,         -- �o�^����
	oOUT_ERR_INF_CSR 	OUT ERR_INF_CSR,    -- �G���[���J�[�\��
  iOPE_CD IN Varchar2,                      -- �I�y���[�^�R�[�h
  iPGM_ID IN Varchar2,                      -- �v���O����ID
  iDATE DATE                              -- �V�X�e������
	) RETURN NUMBER;
  
 
END;
/
CREATE OR REPLACE PACKAGE BODY NH010107B001_101
/* **********************************************************
 *  Copyright(c) 2011 beyond, INTEC Inc. All rights reserved.
 * **********************************************************/
IS
	/*
	 ************************************************************************
	 * Function ID  : CREATE_DCF_SHISETSU
	 * Program Name : DCF�{�ݑf��DB�f�[�^�̍쐬
	 * Parameter    :  <I> iLayoutKind		�F���C�A�E�g�敪
	 *				         <I> iShimeKind		�F���ߓ��敪
   *				         <I> iShimeFrom		�F���ߔ͈́iFrom�j
   *				         <I> iShimeTo		�F���ߔ͈́iTo�j
   *				         <I> iTensoYMD		�F�]���N����
   *				         <I> iM2Flg		  �F���Q���߃t���O
   *		             <I> iIP_ADDR		�F���s�[��IP�A�h���X
	 *		             <I> iWINDOWS_LOGIN_USER  �F���s�[��IP�A�h���X
	 *                <O> oROW_COUNT		    �F�X�V����
	 *                <O> oOUT_ERR_INF_CSR	�F�G���[���J�[�\��
   *				         <I> iOPE_CD		�F�I�y���[�^�R�[�h
   *				         <I> iPGM_ID		�F�v���O����ID
   *				         <I> iDATE		�F�V�X�e������    
	 * Return       �F�������ʁi0:����I���A1:�ُ�I���j
	 ************************************************************************
	 */
	FUNCTION CREATE_DCF_SHISETSU(
	iLayoutKind	IN	VARCHAR2,										-- ���C�A�E�g�敪
	iShimeKind	IN	VARCHAR2,										-- ���ߓ��敪
  iShimeFrom	IN	VARCHAR2,								 -- ���ߔ͈́iFrom�j
  iShimeTo	IN	VARCHAR2,										-- ���ߔ͈́iTo�j
  iTensoYMD	IN	VARCHAR2,										-- �]���N���� 
  iM2Flg IN	VARCHAR2,										    -- ���Q���߃t���O
	iIP_ADDR	IN TL_STORED_SHORI.IP%TYPE,							-- ���s�[��IP�A�h���X (FW�Őݒ�)
	iWINDOWS_LOGIN_USER	IN TL_STORED_SHORI.WINDOWS_LOGIN_USER%TYPE, -- ���s�[��OS���[�U�[ (FW�Őݒ�)
	oROW_COUNT	OUT NUMBER,         -- �o�^����
	oOUT_ERR_INF_CSR 	OUT ERR_INF_CSR,    -- �G���[���J�[�\��
  iOPE_CD IN Varchar2,                      -- �I�y���[�^�R�[�h
  iPGM_ID IN Varchar2,                      -- �v���O����ID
  iDATE DATE                            -- �V�X�e������  
	)RETURN NUMBER IS
  
  PRAGMA AUTONOMOUS_TRANSACTION;
	/************************************************************************/
	/*                              �G���[����                              */
	/************************************************************************/
	W_INDEX_N 					NUMBER(10) := 0;
	W_ERR_INF_TBL 				TYPE_ERR_INFO_TBL := TYPE_ERR_INFO_TBL();
	W_ERR_INF_RCD 				TYPE_ERR_INFO_RCD := TYPE_ERR_INFO_RCD(NULL,NULL,NULL,NULL);
  
  vMODKBN VARCHAR2(1);  --�C���敪
  vSPECIAL_FLG_1 VARCHAR2(1):='0'; --����ҏW���ڃt���O(�폜�\�藝�R�R�[�h�A�d�������R�[�h�̂����ꂩ�ɕύX���������ꍇ�A1�G����ȊO�A0)
  vSchemaNm     TM_JOSU.HANYO_KOMOKU%TYPE := NULL; -- �X�L�[�}����
	PGM_ID        VARCHAR2(50) := 'NH010107B001_101.CREATE_DCF_SHISETSU';
	EXECUTE_SQL   VARCHAR2(32767) := NULL;

	vNEW_KAIGYO_YOTEI_YM VARCHAR2(6) := NULL;
	vOLD_KAIGYO_YOTEI_YM VARCHAR2(6) := NULL;
  -- �񋟗p�ƑO������{�݃e�[�u������f�ރf�[�^���擾����J�[�\��
  CURSOR dayCSR IS
       SELECT                                                    
          TTS.REC_ID                              ,                                                  
          TTS.SHI_CD                              ,                                                  
          TTS.DEL_FLG                             ,                                                  
          TTS.DEL_YOTEI_RIYU_CD                   ,                                                  
          TTS.CHOFUKU_AITSK_REC_ID                ,                                                  
          TTS.CHOFUKU_AITSK_SHI_CD                ,                                                  
          TTS.KYUIN_FLG                     ,                                                  
          TTS.KYUIN_S_YM                    ,                                                  
          TTS.KAIGYO_YOTEI_FLG       ,                                                  
          TTS.KAIGYO_YOTEI_YM        ,                                                  
          TTS.KANREN_DAIGAKU_OYA_REC_ID           ,                                                  
          TTS.KANREN_DAIGAKU_OYA_SHI_CD           ,                                                  
          TTS.SEISHIKI_SHI_NM                     ,                                                  
          TTS.SEISHIKI_SHI_NM30                   ,                                                  
          TTS.SEISHIKI_SHI_NM_KANA                ,                                                  
          TTS.SEISHIKI_SHI_NM_KANA40              ,                                                  
          TTS.SHI_RN                              ,                                                  
          TTS.SHI_RN_KANA                         ,                                                  
          TTS.KEN_CD                              ,                                                  
          TTS.SHIKU_CD                            ,                                                  
          TTS.OAZA_CD                             ,                                                  
          TTS.AZA_CD                              ,                                                  
          TTS.ZIP                                 ,                                                  
          TTS.JUSHO_KANJI_RENKETSU                ,                                                  
          TTS.JUSHO_KANA_RENKETSU                 ,                                                  
          TTS.KEN_NM_KANJI_MOJI_SU                ,                                                  
          TTS.SHIKU_NM_KANJI_MOJI_SU              ,                                                  
          TTS.OAZA_NM_KANJI_MOJI_SU               ,                                                  
          TTS.AZA_NM_KANJI_MOJI_SU                ,                                                  
          TTS.KEN_NM_KANA_MOJI_SU                 ,                                                  
          TTS.SHIKU_NM_KANA_MOJI_SU               ,                                                  
          TTS.OAZA_NM_KANA_MOJI_SU                ,                                                  
          TTS.AZA_NM_KANA_MOJI_SU                 ,                                                  
          TTS.JUSHO_HYOJI_NO                      ,                                                  
          TTS.JUSHOFUMEI_CD                       ,                                                  
          TTS.TEL                                 ,                                                  
          TTS.KEIEITAI_CD                         ,                                                  
          TTS.SHI_KBN_CD                          ,                                                  
          TTS.IMUSHITSU_REC_ID                    ,                                                  
          TTS.IMUSHITSU_SHI_CD                    ,                                                  
          TTS.SAISHINSA_KBN_CD                    ,                                                  
          TTS.BYOTO_HEISA_KBN                     ,                                                  
          TTS.TEL_NASHI_FLG                       ,                                                  
          TTS.MIKAKUNIN_FLG                       ,                                                  
          TTS.DAIHYO_REC_ID                       ,                                                  
          TTS.DAIHYO_KJN_CD                       ,                                                  
          TTK.KJN_NM                            ,                                                  
          TTK.KJN_NM_KANA                     ,                                                  
          TO_CHAR(TTS.SHI_BED_SU,'FM9999') AS SHI_BED_SU,                                                  
          TTS.BYOIN_SBT_CD                        ,                                                  
          TTS.KYOKA_BED_SU_SONOTA                 ,                                                  
          TTS.KYOKA_BED_SU_SEISHIN                ,                                                  
          TTS.KYOKA_BED_SU_KEKKAKU                ,                                                  
          TTS.KYOKA_BED_SU_KANSEN                 ,                                                  
          TO_CHAR(TTS.KYOKA_BED_SU_GOKEI,'FM9999') AS KYOKA_BED_SU_GOKEI,                                                  
          TTS.KYOKA_BED_SU_IPPAN                  ,                                                  
          TTS.KYOKA_BED_SU_RYOYO                  ,                                                  
          TTS.BED_SU_KKNN_EIGY_YMD                ,                                                  
          TTS.SNRYKMK_CD_01                       ,                                                  
          TTS.SNRYKMK_CD_02                       ,                                                  
          TTS.SNRYKMK_CD_03                       ,                                                  
          TTS.SNRYKMK_CD_04                       ,                                                  
          TTS.SNRYKMK_CD_05                       ,                                                  
          TTS.SNRYKMK_CD_06                       ,                                                  
          TTS.SNRYKMK_CD_07                       ,                                                  
          TTS.SNRYKMK_CD_08                       ,                                                  
          TTS.SNRYKMK_CD_09                       ,                                                  
          TTS.SNRYKMK_CD_10                       ,                                                  
          TTS.SNRYKMK_CD_11                       ,                                                  
          TTS.SNRYKMK_CD_12                       ,                                                  
          TTS.SNRYKMK_CD_13                       ,                                                  
          TTS.SNRYKMK_CD_14                       ,                                                  
          TTS.SNRYKMK_CD_15                       ,                                                  
          TTS.SNRYKMK_CD_16                       ,                                                  
          TTS.SNRYKMK_CD_17                       ,                                                  
          TTS.SNRYKMK_CD_18                       ,                                                  
          TTS.SNRYKMK_CD_19                       ,                                                  
          TTS.SNRYKMK_CD_20                       ,                                                  
          TTS.SNRYKMK_CD_21                       ,                                                  
          TTS.SNRYKMK_CD_22                       ,                                                  
          TTS.SNRYKMK_CD_23                       ,                                                  
          TTS.SNRYKMK_CD_24                       ,                                                  
          TTS.SNRYKMK_CD_25                       ,                                                  
          TTS.SNRYKMK_CD_26                       ,                                                  
          TTS.SNRYKMK_CD_27                       ,                                                  
          TTS.SNRYKMK_CD_28                       ,                                                  
          TTS.SNRYKMK_CD_29                       ,                                                  
          TTS.SNRYKMK_CD_30                       ,                                                  
          TTS.SNRYKMK_CD_31                       ,                                                  
          TTS.SNRYKMK_CD_32                       ,                                                  
          TTS.SNRYKMK_CD_33                       ,                                                  
          TTS.SNRYKMK_CD_34                       ,                                                  
          TTS.SNRYKMK_CD_35                       ,                                                  
          TTS.SNRYKMK_CD_36                       ,                                                  
          TTS.SNRYKMK_CD_37                       ,                                                  
          TTS.SNRYKMK_CD_38                       ,                                                  
          TTS.SNRYKMK_CD_39                       ,                                                  
          TTS.SNRYKMK_CD_40                       ,                                                  
          TTS.SNRYKMK_CD_41                       ,                                                  
          TTS.SNRYKMK_CD_42                       ,                                                  
          TTS.SNRYKMK_CD_43                       ,                                                  
          TTS.SNRYKMK_CD_44                       ,                                                  
          TTS.SNRYKMK_CD_45                       ,                                                  
          TTS.SNRYKMK_CD_46                       ,                                                  
          TTS.SNRYKMK_CD_47                       ,                                                  
          TTS.SNRYKMK_CD_48                       ,                                                  
          TTS.SNRYKMK_CD_49                       ,                                                  
          TTS.SNRYKMK_CD_50                       ,                                                  
          TTS.SNRYKMK_CD_51                       ,                                                  
          TTS.SNRYKMK_CD_52                       ,                                                  
          TTS.SNRYKMK_CD_53                       ,                                                  
          TTS.SNRYKMK_CD_54                       ,                                                  
          TTS.SNRYKMK_CD_55                       ,                                                  
          TTS.SNRYKMK_CD_56                       ,                                                  
          TTS.SNRYKMK_CD_57                       ,                                                  
          TTS.SNRYKMK_CD_58                       ,                                                  
          TTS.SNRYKMK_CD_59                       ,                                                  
          TTS.SNRYKMK_CD_60                       ,                                                  
          TTS.KENSAKOMOKU_BISEIBUTSU_FLG          ,                                                  
          TTS.KENSAKOMOKU_KESSEI_FLG              ,                                                  
          TTS.KENSAKOMOKU_KETSUEKI_FLG            ,                                                  
          TTS.KENSAKOMOKU_BYORI_FLG               ,                                                  
          TTS.KENSAKOMOKU_KISEICHU_FLG            ,                                                  
          TTS.KENSAKOMOKU_SEIKA_FLG               ,                                                  
          TTS.KENSAKOMOKU_RI_FLG                  ,                                                  
          TTS.UPD_EIGY_YMD ,                                                                                                           
          TZDS.REC_ID                              AS  zREC_ID                              ,                                                  
          TZDS.SHI_CD                              AS  zSHI_CD                              ,                                                  
          TZDS.DEL_FLG                             AS  zDEL_FLG                             ,                                                  
          TZDS.DEL_YOTEI_RIYU_CD                   AS  zDEL_YOTEI_RIYU_CD                   ,                                                  
          TZDS.CHOFUKU_AITSK_REC_ID                AS  zCHOFUKU_AITSK_REC_ID                ,                                                  
          TZDS.CHOFUKU_AITSK_SHI_CD                AS  zCHOFUKU_AITSK_SHI_CD                ,                                                  
          TZDS.KYUIN_FLG               AS  zKYUIN_FLG                           ,                                                  
          TZDS.KYUIN_S_YM              AS  zKYUIN_S_YM                          ,                                                  
          TZDS.KAIGYO_YOTEI_FLG       AS  zKAIGYO_YOTEI_FLG                    ,                                                  
          TZDS.KAIGYO_YOTEI_YM        AS  zKAIGYO_YOTEI_YM                     ,                                                  
          TZDS.KANREN_DAIGAKU_OYA_REC_ID           AS  zKANREN_DAIGAKU_OYA_REC_ID           ,                                                  
          TZDS.KANREN_DAIGAKU_OYA_SHI_CD           AS  zKANREN_DAIGAKU_OYA_SHI_CD           ,                                                  
          TZDS.SEISHIKI_SHI_NM                     AS  zSEISHIKI_SHI_NM                     ,                                                  
          TZDS.SEISHIKI_SHI_NM30                   AS  zSEISHIKI_SHI_NM30                   ,                                                  
          TZDS.SEISHIKI_SHI_NM_KANA                AS  zSEISHIKI_SHI_NM_KANA                ,                                                  
          TZDS.SEISHIKI_SHI_NM_KANA40              AS  zSEISHIKI_SHI_NM_KANA40              ,                                                  
          TZDS.SHI_RN                              AS  zSHI_RN                              ,                                                  
          TZDS.SHI_RN_KANA                         AS  zSHI_RN_KANA                         ,                                                  
          TZDS.KEN_CD                              AS  zKEN_CD                              ,                                                  
          TZDS.SHIKU_CD                            AS  zSHIKU_CD                            ,                                                  
          TZDS.OAZA_CD                             AS  zOAZA_CD                             ,                                                  
          TZDS.AZA_CD                              AS  zAZA_CD                              ,                                                  
          TZDS.ZIP                                 AS  zZIP                                 ,                                                  
          TZDS.JUSHO_KANJI_RENKETSU                AS  zJUSHO_KANJI_RENKETSU                ,                                                  
          TZDS.JUSHO_KANA_RENKETSU                 AS  zJUSHO_KANA_RENKETSU                 ,                                                  
          TZDS.KEN_NM_KANJI_MOJI_SU                AS  zKEN_NM_KANJI_MOJI_SU                ,                                                  
          TZDS.SHIKU_NM_KANJI_MOJI_SU              AS  zSHIKU_NM_KANJI_MOJI_SU              ,                                                  
          TZDS.OAZA_NM_KANJI_MOJI_SU               AS  zOAZA_NM_KANJI_MOJI_SU               ,                                                  
          TZDS.AZA_NM_KANJI_MOJI_SU                AS  zAZA_NM_KANJI_MOJI_SU                ,                                                  
          TZDS.KEN_NM_KANA_MOJI_SU                 AS  zKEN_NM_KANA_MOJI_SU                 ,                                                  
          TZDS.SHIKU_NM_KANA_MOJI_SU               AS  zSHIKU_NM_KANA_MOJI_SU               ,                                                  
          TZDS.OAZA_NM_KANA_MOJI_SU                AS  zOAZA_NM_KANA_MOJI_SU                ,                                                  
          TZDS.AZA_NM_KANA_MOJI_SU                 AS  zAZA_NM_KANA_MOJI_SU                 ,                                                  
          TZDS.JUSHO_HYOJI_NO                      AS  zJUSHO_HYOJI_NO                      ,                                                  
          TZDS.JUSHOFUMEI_CD                       AS  zJUSHOFUMEI_CD                       ,                                                  
          TZDS.TEL                                 AS  zTEL                                 ,                                                  
          TZDS.KEIEITAI_CD                         AS  zKEIEITAI_CD                         ,                                                  
          TZDS.SHI_KBN_CD                          AS  zSHI_KBN_CD                          ,                                                  
          TZDS.IMUSHITSU_REC_ID                    AS  zIMUSHITSU_REC_ID                    ,                                                  
          TZDS.IMUSHITSU_SHI_CD                    AS  zIMUSHITSU_SHI_CD                    ,                                                  
          TZDS.SAISHINSA_KBN_CD                    AS  zSAISHINSA_KBN_CD                    ,                                                  
          TZDS.BYOTO_HEISA_KBN                     AS  zBYOTO_HEISA_KBN                     ,                                                  
          TZDS.TEL_NASHI_FLG                       AS  zTEL_NASHI_FLG                       ,                                                  
          TZDS.MIKAKUNIN_FLG                       AS  zMIKAKUNIN_FLG                       ,                                                  
          TZDS.DAIHYO_REC_ID                       AS  zDAIHYO_REC_ID                       ,                                                  
          TZDS.DAIHYO_KJN_CD                       AS  zDAIHYO_KJN_CD                       ,                                                  
          TZDK.KJN_NM                              AS  zKJN_NM                              ,                                                  
          TZDK.KJN_NM_KANA                         AS  zKJN_NM_KANA                         ,                                                  
          TO_CHAR(TZDS.SHI_BED_SU,'FM9999')        AS  zSHI_BED_SU                          ,                                                  
          TZDS.BYOIN_SBT_CD                        AS  zBYOIN_SBT_CD                        ,                                                  
          TZDS.KYOKA_BED_SU_SONOTA                 AS  zKYOKA_BED_SU_SONOTA                 ,                                                  
          TZDS.KYOKA_BED_SU_SEISHIN                AS  zKYOKA_BED_SU_SEISHIN                ,                                                  
          TZDS.KYOKA_BED_SU_KEKKAKU                AS  zKYOKA_BED_SU_KEKKAKU                ,                                                  
          TZDS.KYOKA_BED_SU_KANSEN                 AS  zKYOKA_BED_SU_KANSEN                 ,                                                  
          TO_CHAR(TZDS.KYOKA_BED_SU_GOKEI,'FM9999') AS  zKYOKA_BED_SU_GOKEI                  ,                                                  
          TZDS.KYOKA_BED_SU_IPPAN                  AS  zKYOKA_BED_SU_IPPAN                  ,                                                  
          TZDS.KYOKA_BED_SU_RYOYO                  AS  zKYOKA_BED_SU_RYOYO                  ,                                                  
          TZDS.BED_SU_KKNN_EIGY_YMD                AS  zBED_SU_KKNN_EIGY_YMD                ,                                                  
          TZDS.SNRYKMK_CD_01                       AS  zSNRYKMK_CD_01                       ,                                                  
          TZDS.SNRYKMK_CD_02                       AS  zSNRYKMK_CD_02                       ,                                                  
          TZDS.SNRYKMK_CD_03                       AS  zSNRYKMK_CD_03                       ,                                                  
          TZDS.SNRYKMK_CD_04                       AS  zSNRYKMK_CD_04                       ,                                                  
          TZDS.SNRYKMK_CD_05                       AS  zSNRYKMK_CD_05                       ,                                                  
          TZDS.SNRYKMK_CD_06                       AS  zSNRYKMK_CD_06                       ,                                                  
          TZDS.SNRYKMK_CD_07                       AS  zSNRYKMK_CD_07                       ,                                                  
          TZDS.SNRYKMK_CD_08                       AS  zSNRYKMK_CD_08                       ,                                                  
          TZDS.SNRYKMK_CD_09                       AS  zSNRYKMK_CD_09                       ,                                                  
          TZDS.SNRYKMK_CD_10                       AS  zSNRYKMK_CD_10                       ,                                                  
          TZDS.SNRYKMK_CD_11                       AS  zSNRYKMK_CD_11                       ,                                                  
          TZDS.SNRYKMK_CD_12                       AS  zSNRYKMK_CD_12                       ,                                                  
          TZDS.SNRYKMK_CD_13                       AS  zSNRYKMK_CD_13                       ,                                                  
          TZDS.SNRYKMK_CD_14                       AS  zSNRYKMK_CD_14                       ,                                                  
          TZDS.SNRYKMK_CD_15                       AS  zSNRYKMK_CD_15                       ,                                                  
          TZDS.SNRYKMK_CD_16                       AS  zSNRYKMK_CD_16                       ,                                                  
          TZDS.SNRYKMK_CD_17                       AS  zSNRYKMK_CD_17                       ,                                                  
          TZDS.SNRYKMK_CD_18                       AS  zSNRYKMK_CD_18                       ,                                                  
          TZDS.SNRYKMK_CD_19                       AS  zSNRYKMK_CD_19                       ,                                                  
          TZDS.SNRYKMK_CD_20                       AS  zSNRYKMK_CD_20                       ,                                                  
          TZDS.SNRYKMK_CD_21                       AS  zSNRYKMK_CD_21                       ,                                                  
          TZDS.SNRYKMK_CD_22                       AS  zSNRYKMK_CD_22                       ,                                                  
          TZDS.SNRYKMK_CD_23                       AS  zSNRYKMK_CD_23                       ,                                                  
          TZDS.SNRYKMK_CD_24                       AS  zSNRYKMK_CD_24                       ,                                                  
          TZDS.SNRYKMK_CD_25                       AS  zSNRYKMK_CD_25                       ,                                                  
          TZDS.SNRYKMK_CD_26                       AS  zSNRYKMK_CD_26                       ,                                                  
          TZDS.SNRYKMK_CD_27                       AS  zSNRYKMK_CD_27                       ,                                                  
          TZDS.SNRYKMK_CD_28                       AS  zSNRYKMK_CD_28                       ,                                                  
          TZDS.SNRYKMK_CD_29                       AS  zSNRYKMK_CD_29                       ,                                                  
          TZDS.SNRYKMK_CD_30                       AS  zSNRYKMK_CD_30                       ,                                                  
          TZDS.SNRYKMK_CD_31                       AS  zSNRYKMK_CD_31                       ,                                                  
          TZDS.SNRYKMK_CD_32                       AS  zSNRYKMK_CD_32                       ,                                                  
          TZDS.SNRYKMK_CD_33                       AS  zSNRYKMK_CD_33                       ,                                                  
          TZDS.SNRYKMK_CD_34                       AS  zSNRYKMK_CD_34                       ,                                                  
          TZDS.SNRYKMK_CD_35                       AS  zSNRYKMK_CD_35                       ,                                                  
          TZDS.SNRYKMK_CD_36                       AS  zSNRYKMK_CD_36                       ,                                                  
          TZDS.SNRYKMK_CD_37                       AS  zSNRYKMK_CD_37                       ,                                                  
          TZDS.SNRYKMK_CD_38                       AS  zSNRYKMK_CD_38                       ,                                                  
          TZDS.SNRYKMK_CD_39                       AS  zSNRYKMK_CD_39                       ,                                                  
          TZDS.SNRYKMK_CD_40                       AS  zSNRYKMK_CD_40                       ,                                                  
          TZDS.SNRYKMK_CD_41                       AS  zSNRYKMK_CD_41                       ,                                                  
          TZDS.SNRYKMK_CD_42                       AS  zSNRYKMK_CD_42                       ,                                                  
          TZDS.SNRYKMK_CD_43                       AS  zSNRYKMK_CD_43                       ,                                                  
          TZDS.SNRYKMK_CD_44                       AS  zSNRYKMK_CD_44                       ,                                                  
          TZDS.SNRYKMK_CD_45                       AS  zSNRYKMK_CD_45                       ,                                                  
          TZDS.SNRYKMK_CD_46                       AS  zSNRYKMK_CD_46                       ,                                                  
          TZDS.SNRYKMK_CD_47                       AS  zSNRYKMK_CD_47                       ,                                                  
          TZDS.SNRYKMK_CD_48                       AS  zSNRYKMK_CD_48                       ,                                                  
          TZDS.SNRYKMK_CD_49                       AS  zSNRYKMK_CD_49                       ,                                                  
          TZDS.SNRYKMK_CD_50                       AS  zSNRYKMK_CD_50                       ,                                                  
          TZDS.SNRYKMK_CD_51                       AS  zSNRYKMK_CD_51                       ,                                                  
          TZDS.SNRYKMK_CD_52                       AS  zSNRYKMK_CD_52                       ,                                                  
          TZDS.SNRYKMK_CD_53                       AS  zSNRYKMK_CD_53                       ,                                  								
          TZDS.SNRYKMK_CD_54                       AS  zSNRYKMK_CD_54                       ,																									
          TZDS.SNRYKMK_CD_55                       AS  zSNRYKMK_CD_55                       ,																									
          TZDS.SNRYKMK_CD_56                       AS  zSNRYKMK_CD_56                       ,																									
          TZDS.SNRYKMK_CD_57                       AS  zSNRYKMK_CD_57                       ,																									
          TZDS.SNRYKMK_CD_58                       AS  zSNRYKMK_CD_58                       ,																									
          TZDS.SNRYKMK_CD_59                       AS  zSNRYKMK_CD_59                       ,																									
          TZDS.SNRYKMK_CD_60                       AS  zSNRYKMK_CD_60                       ,																									
          TZDS.KENSAKOMOKU_BISEIBUTSU_FLG          AS  zKENSAKOMOKU_BISEIBUTSU_FLG          ,																									
          TZDS.KENSAKOMOKU_KESSEI_FLG              AS  zKENSAKOMOKU_KESSEI_FLG              ,																									
          TZDS.KENSAKOMOKU_KETSUEKI_FLG            AS  zKENSAKOMOKU_KETSUEKI_FLG            ,																									
          TZDS.KENSAKOMOKU_BYORI_FLG               AS  zKENSAKOMOKU_BYORI_FLG               ,																									
          TZDS.KENSAKOMOKU_KISEICHU_FLG            AS  zKENSAKOMOKU_KISEICHU_FLG            ,																									
          TZDS.KENSAKOMOKU_SEIKA_FLG               AS  zKENSAKOMOKU_SEIKA_FLG               ,																									
          TZDS.KENSAKOMOKU_RI_FLG                  AS  zKENSAKOMOKU_RI_FLG                  ,																									
          TZDS.UPD_EIGY_YMD                        AS  zUPD_EIGY_YMD	
        FROM TT_TIKY_SHI�@TTS							
        LEFT OUTER JOIN TT_TIKY_KJN TTK											
        ON  TTS.DAIHYO_REC_ID = TTK.REC_ID											
        AND TTS.DAIHYO_KJN_CD = TTK.KJN_CD											
        AND TTK.DEL_FLG IS NULL											
        LEFT OUTER JOIN TT_Z_D_SHI�@TZDS											
        ON  TTS.REC_ID = TZDS.REC_ID											
        AND TTS.SHI_CD = TZDS.SHI_CD											
        LEFT OUTER JOIN TT_Z_D_KJN TZDK											
        ON  TZDS.DAIHYO_REC_ID = TZDK.REC_ID											
        AND TZDS.DAIHYO_KJN_CD = TZDK.KJN_CD	
        WHERE�@TTS.REC_ID�@= '00'
          -- ��������2012/01/24
          AND (TTS.DEL_FLG IS NULL OR TZDS.DEL_FLG IS NULL)
          -- ��������2012/01/24
          AND TTS.UPD_EIGY_YMD�@>= NVL(iShimeFrom, '19700101')																
          AND TTS.UPD_EIGY_YMD�@<= iShimeTo ; 
  dayRow dayCSR%ROWTYPE; 
  
  -- �񋟗p�ƑO��T���{�݃e�[�u������f�ރf�[�^���擾����J�[�\��
  CURSOR weekCSR IS
       SELECT                                                    
          TTS.REC_ID                              ,                                                  
          TTS.SHI_CD                              ,                                                  
          TTS.DEL_FLG                             ,                                                  
          TTS.DEL_YOTEI_RIYU_CD                   ,                                                  
          TTS.CHOFUKU_AITSK_REC_ID                ,                                                  
          TTS.CHOFUKU_AITSK_SHI_CD                ,                                                  
          TTS.KYUIN_FLG                           ,                                                  
          TTS.KYUIN_S_YM                          ,                                                  
          TTS.KAIGYO_YOTEI_FLG                    ,                                                  
          TTS.KAIGYO_YOTEI_YM                     ,                                                  
          TTS.KANREN_DAIGAKU_OYA_REC_ID           ,                                                  
          TTS.KANREN_DAIGAKU_OYA_SHI_CD           ,                                                  
          TTS.SEISHIKI_SHI_NM                     ,                                                  
          TTS.SEISHIKI_SHI_NM30                   ,                                                  
          TTS.SEISHIKI_SHI_NM_KANA                ,                                                  
          TTS.SEISHIKI_SHI_NM_KANA40              ,                                                  
          TTS.SHI_RN                              ,                                                  
          TTS.SHI_RN_KANA                         ,                                                  
          TTS.KEN_CD                              ,                                                  
          TTS.SHIKU_CD                            ,                                                  
          TTS.OAZA_CD                             ,                                                  
          TTS.AZA_CD                              ,                                                  
          TTS.ZIP                                 ,                                                  
          TTS.JUSHO_KANJI_RENKETSU                ,                                                  
          TTS.JUSHO_KANA_RENKETSU                 ,                                                  
          TTS.KEN_NM_KANJI_MOJI_SU                ,                                                  
          TTS.SHIKU_NM_KANJI_MOJI_SU              ,                                                  
          TTS.OAZA_NM_KANJI_MOJI_SU               ,                                                  
          TTS.AZA_NM_KANJI_MOJI_SU                ,                                                  
          TTS.KEN_NM_KANA_MOJI_SU                 ,                                                  
          TTS.SHIKU_NM_KANA_MOJI_SU               ,                                                  
          TTS.OAZA_NM_KANA_MOJI_SU                ,                                                  
          TTS.AZA_NM_KANA_MOJI_SU                 ,                                                  
          TTS.JUSHO_HYOJI_NO                      ,                                                  
          TTS.JUSHOFUMEI_CD                       ,                                                  
          TTS.TEL                                 ,                                                  
          TTS.KEIEITAI_CD                         ,                                                  
          TTS.SHI_KBN_CD                          ,                                                  
          TTS.IMUSHITSU_REC_ID                    ,                                                  
          TTS.IMUSHITSU_SHI_CD                    ,                                                  
          TTS.SAISHINSA_KBN_CD                    ,                                                  
          TTS.BYOTO_HEISA_KBN                     ,                                                  
          TTS.TEL_NASHI_FLG                       ,                                                  
          TTS.MIKAKUNIN_FLG                       ,                                                  
          TTS.DAIHYO_REC_ID                       ,                                                  
          TTS.DAIHYO_KJN_CD                       ,                                                  
          TTK.KJN_NM                            ,                                                  
          TTK.KJN_NM_KANA                     ,                                                  
          TO_CHAR(TTS.SHI_BED_SU,'FM9999') AS SHI_BED_SU,                                                  
          TTS.BYOIN_SBT_CD                        ,                                                  
          TO_CHAR(TTS.KYOKA_BED_SU_SONOTA,'FM9999') AS KYOKA_BED_SU_SONOTA,                                                  
          TO_CHAR(TTS.KYOKA_BED_SU_SEISHIN,'FM9999') AS KYOKA_BED_SU_SEISHIN,                                                  
          TO_CHAR(TTS.KYOKA_BED_SU_KEKKAKU,'FM9999') AS KYOKA_BED_SU_KEKKAKU,                                                  
          TO_CHAR(TTS.KYOKA_BED_SU_KANSEN,'FM9999') AS KYOKA_BED_SU_KANSEN,                                                  
          TO_CHAR(TTS.KYOKA_BED_SU_GOKEI,'FM9999') AS KYOKA_BED_SU_GOKEI,                                                  
          TO_CHAR(TTS.KYOKA_BED_SU_IPPAN,'FM9999') AS KYOKA_BED_SU_IPPAN,                                                  
          TTS.KYOKA_BED_SU_RYOYO                  ,                                                  
          TTS.BED_SU_KKNN_EIGY_YMD                ,                                                  
          TTS.SNRYKMK_CD_01                       ,                                                  
          TTS.SNRYKMK_CD_02                       ,                                                  
          TTS.SNRYKMK_CD_03                       ,                                                  
          TTS.SNRYKMK_CD_04                       ,                                                  
          TTS.SNRYKMK_CD_05                       ,                                                  
          TTS.SNRYKMK_CD_06                       ,                                                  
          TTS.SNRYKMK_CD_07                       ,                                                  
          TTS.SNRYKMK_CD_08                       ,                                                  
          TTS.SNRYKMK_CD_09                       ,                                                  
          TTS.SNRYKMK_CD_10                       ,                                                  
          TTS.SNRYKMK_CD_11                       ,                                                  
          TTS.SNRYKMK_CD_12                       ,                                                  
          TTS.SNRYKMK_CD_13                       ,                                                  
          TTS.SNRYKMK_CD_14                       ,                                                  
          TTS.SNRYKMK_CD_15                       ,                                                  
          TTS.SNRYKMK_CD_16                       ,                                                  
          TTS.SNRYKMK_CD_17                       ,                                                  
          TTS.SNRYKMK_CD_18                       ,                                                  
          TTS.SNRYKMK_CD_19                       ,                                                  
          TTS.SNRYKMK_CD_20                       ,                                                  
          TTS.SNRYKMK_CD_21                       ,                                                  
          TTS.SNRYKMK_CD_22                       ,                                                  
          TTS.SNRYKMK_CD_23                       ,                                                  
          TTS.SNRYKMK_CD_24                       ,                                                  
          TTS.SNRYKMK_CD_25                       ,                                                  
          TTS.SNRYKMK_CD_26                       ,                                                  
          TTS.SNRYKMK_CD_27                       ,                                                  
          TTS.SNRYKMK_CD_28                       ,                                                  
          TTS.SNRYKMK_CD_29                       ,                                                  
          TTS.SNRYKMK_CD_30                       ,                                                  
          TTS.SNRYKMK_CD_31                       ,                                                  
          TTS.SNRYKMK_CD_32                       ,                                                  
          TTS.SNRYKMK_CD_33                       ,                                                  
          TTS.SNRYKMK_CD_34                       ,                                                  
          TTS.SNRYKMK_CD_35                       ,                                                  
          TTS.SNRYKMK_CD_36                       ,                                                  
          TTS.SNRYKMK_CD_37                       ,                                                  
          TTS.SNRYKMK_CD_38                       ,                                                  
          TTS.SNRYKMK_CD_39                       ,                                                  
          TTS.SNRYKMK_CD_40                       ,                                                  
          TTS.SNRYKMK_CD_41                       ,                                                  
          TTS.SNRYKMK_CD_42                       ,                                                  
          TTS.SNRYKMK_CD_43                       ,                                                  
          TTS.SNRYKMK_CD_44                       ,                                                  
          TTS.SNRYKMK_CD_45                       ,                                                  
          TTS.SNRYKMK_CD_46                       ,                                                  
          TTS.SNRYKMK_CD_47                       ,                                                  
          TTS.SNRYKMK_CD_48                       ,                                                  
          TTS.SNRYKMK_CD_49                       ,                                                  
          TTS.SNRYKMK_CD_50                       ,                                                  
          TTS.SNRYKMK_CD_51                       ,                                                  
          TTS.SNRYKMK_CD_52                       ,                                                  
          TTS.SNRYKMK_CD_53                       ,                                                  
          TTS.SNRYKMK_CD_54                       ,                                                  
          TTS.SNRYKMK_CD_55                       ,                                                  
          TTS.SNRYKMK_CD_56                       ,                                                  
          TTS.SNRYKMK_CD_57                       ,                                                  
          TTS.SNRYKMK_CD_58                       ,                                                  
          TTS.SNRYKMK_CD_59                       ,                                                  
          TTS.SNRYKMK_CD_60                       ,                                                  
          TTS.KENSAKOMOKU_BISEIBUTSU_FLG          ,                                                  
          TTS.KENSAKOMOKU_KESSEI_FLG              ,                                                  
          TTS.KENSAKOMOKU_KETSUEKI_FLG            ,                                                  
          TTS.KENSAKOMOKU_BYORI_FLG               ,                                                  
          TTS.KENSAKOMOKU_KISEICHU_FLG            ,                                                  
          TTS.KENSAKOMOKU_SEIKA_FLG               ,                                                  
          TTS.KENSAKOMOKU_RI_FLG                  ,                                                  
          TTS.UPD_EIGY_YMD ,                                                                                                           
          TZWS.REC_ID                              AS  zREC_ID                              ,                                                  
          TZWS.SHI_CD                              AS  zSHI_CD                              ,                                                  
          TZWS.DEL_FLG                             AS  zDEL_FLG                             ,                                                  
          TZWS.DEL_YOTEI_RIYU_CD                   AS  zDEL_YOTEI_RIYU_CD                   ,                                                  
          TZWS.CHOFUKU_AITSK_REC_ID                AS  zCHOFUKU_AITSK_REC_ID                ,                                                  
          TZWS.CHOFUKU_AITSK_SHI_CD                AS  zCHOFUKU_AITSK_SHI_CD                ,                                                  
          TZWS.KYUIN_FLG                           AS  zKYUIN_FLG                           ,                                                  
          TZWS.KYUIN_S_YM                          AS  zKYUIN_S_YM                          ,                                                  
          TZWS.KAIGYO_YOTEI_FLG                    AS  zKAIGYO_YOTEI_FLG                    ,                                                  
          TZWS.KAIGYO_YOTEI_YM                     AS  zKAIGYO_YOTEI_YM                     ,                                                  
          TZWS.KANREN_DAIGAKU_OYA_REC_ID           AS  zKANREN_DAIGAKU_OYA_REC_ID           ,                                                  
          TZWS.KANREN_DAIGAKU_OYA_SHI_CD           AS  zKANREN_DAIGAKU_OYA_SHI_CD           ,                                                  
          TZWS.SEISHIKI_SHI_NM                     AS  zSEISHIKI_SHI_NM                     ,                                                  
          TZWS.SEISHIKI_SHI_NM30                   AS  zSEISHIKI_SHI_NM30                   ,                                                  
          TZWS.SEISHIKI_SHI_NM_KANA                AS  zSEISHIKI_SHI_NM_KANA                ,                                                  
          TZWS.SEISHIKI_SHI_NM_KANA40              AS  zSEISHIKI_SHI_NM_KANA40              ,                                                  
          TZWS.SHI_RN                              AS  zSHI_RN                              ,                                                  
          TZWS.SHI_RN_KANA                         AS  zSHI_RN_KANA                         ,                                                  
          TZWS.KEN_CD                              AS  zKEN_CD                              ,                                                  
          TZWS.SHIKU_CD                            AS  zSHIKU_CD                            ,                                                  
          TZWS.OAZA_CD                             AS  zOAZA_CD                             ,                                                  
          TZWS.AZA_CD                              AS  zAZA_CD                              ,                                                  
          TZWS.ZIP                                 AS  zZIP                                 ,                                                  
          TZWS.JUSHO_KANJI_RENKETSU                AS  zJUSHO_KANJI_RENKETSU                ,                                                  
          TZWS.JUSHO_KANA_RENKETSU                 AS  zJUSHO_KANA_RENKETSU                 ,                                                  
          TZWS.KEN_NM_KANJI_MOJI_SU                AS  zKEN_NM_KANJI_MOJI_SU                ,                                                  
          TZWS.SHIKU_NM_KANJI_MOJI_SU              AS  zSHIKU_NM_KANJI_MOJI_SU              ,                                                  
          TZWS.OAZA_NM_KANJI_MOJI_SU               AS  zOAZA_NM_KANJI_MOJI_SU               ,                                                  
          TZWS.AZA_NM_KANJI_MOJI_SU                AS  zAZA_NM_KANJI_MOJI_SU                ,                                                  
          TZWS.KEN_NM_KANA_MOJI_SU                 AS  zKEN_NM_KANA_MOJI_SU                 ,                                                  
          TZWS.SHIKU_NM_KANA_MOJI_SU               AS  zSHIKU_NM_KANA_MOJI_SU               ,                                                  
          TZWS.OAZA_NM_KANA_MOJI_SU                AS  zOAZA_NM_KANA_MOJI_SU                ,                                                  
          TZWS.AZA_NM_KANA_MOJI_SU                 AS  zAZA_NM_KANA_MOJI_SU                 ,                                                  
          TZWS.JUSHO_HYOJI_NO                      AS  zJUSHO_HYOJI_NO                      ,                                                  
          TZWS.JUSHOFUMEI_CD                       AS  zJUSHOFUMEI_CD                       ,                                                  
          TZWS.TEL                                 AS  zTEL                                 ,                                                  
          TZWS.KEIEITAI_CD                         AS  zKEIEITAI_CD                         ,                                                  
          TZWS.SHI_KBN_CD                          AS  zSHI_KBN_CD                          ,                                                  
          TZWS.IMUSHITSU_REC_ID                    AS  zIMUSHITSU_REC_ID                    ,                                                  
          TZWS.IMUSHITSU_SHI_CD                    AS  zIMUSHITSU_SHI_CD                    ,                                                  
          TZWS.SAISHINSA_KBN_CD                    AS  zSAISHINSA_KBN_CD                    ,                                                  
          TZWS.BYOTO_HEISA_KBN                     AS  zBYOTO_HEISA_KBN                     ,                                                  
          TZWS.TEL_NASHI_FLG                       AS  zTEL_NASHI_FLG                       ,                                                  
          TZWS.MIKAKUNIN_FLG                       AS  zMIKAKUNIN_FLG                       ,                                                  
          TZWS.DAIHYO_REC_ID                       AS  zDAIHYO_REC_ID                       ,                                                  
          TZWS.DAIHYO_KJN_CD                       AS  zDAIHYO_KJN_CD                       ,                                                  
          TZWK.KJN_NM                              AS  zKJN_NM                              ,                                                  
          TZWK.KJN_NM_KANA                         AS  zKJN_NM_KANA                         ,                                                  
          TO_CHAR(TZWS.SHI_BED_SU,'FM9999')        AS  zSHI_BED_SU                          ,                                                  
          TZWS.BYOIN_SBT_CD                        AS  zBYOIN_SBT_CD                        ,                                                  
          TO_CHAR(TZWS.KYOKA_BED_SU_SONOTA,'FM9999') AS  zKYOKA_BED_SU_SONOTA                 ,                                                  
          TO_CHAR(TZWS.KYOKA_BED_SU_SEISHIN,'FM9999') AS  zKYOKA_BED_SU_SEISHIN                ,                                                  
          TO_CHAR(TZWS.KYOKA_BED_SU_KEKKAKU,'FM9999') AS  zKYOKA_BED_SU_KEKKAKU                ,                                                  
          TO_CHAR(TZWS.KYOKA_BED_SU_KANSEN,'FM9999') AS  zKYOKA_BED_SU_KANSEN                 ,                                                  
          TO_CHAR(TZWS.KYOKA_BED_SU_GOKEI,'FM9999') AS  zKYOKA_BED_SU_GOKEI                  ,                                                  
          TO_CHAR(TZWS.KYOKA_BED_SU_IPPAN,'FM9999') AS  zKYOKA_BED_SU_IPPAN                  ,                                                  
          TZWS.KYOKA_BED_SU_RYOYO                  AS  zKYOKA_BED_SU_RYOYO                  ,                                                  
          TZWS.BED_SU_KKNN_EIGY_YMD                AS  zBED_SU_KKNN_EIGY_YMD                ,                                                  
          TZWS.SNRYKMK_CD_01                       AS  zSNRYKMK_CD_01                       ,                                                  
          TZWS.SNRYKMK_CD_02                       AS  zSNRYKMK_CD_02                       ,                                                  
          TZWS.SNRYKMK_CD_03                       AS  zSNRYKMK_CD_03                       ,                                                  
          TZWS.SNRYKMK_CD_04                       AS  zSNRYKMK_CD_04                       ,                                                  
          TZWS.SNRYKMK_CD_05                       AS  zSNRYKMK_CD_05                       ,                                                  
          TZWS.SNRYKMK_CD_06                       AS  zSNRYKMK_CD_06                       ,                                                  
          TZWS.SNRYKMK_CD_07                       AS  zSNRYKMK_CD_07                       ,                                                  
          TZWS.SNRYKMK_CD_08                       AS  zSNRYKMK_CD_08                       ,                                                  
          TZWS.SNRYKMK_CD_09                       AS  zSNRYKMK_CD_09                       ,                                                  
          TZWS.SNRYKMK_CD_10                       AS  zSNRYKMK_CD_10                       ,                                                  
          TZWS.SNRYKMK_CD_11                       AS  zSNRYKMK_CD_11                       ,                                                  
          TZWS.SNRYKMK_CD_12                       AS  zSNRYKMK_CD_12                       ,                                                  
          TZWS.SNRYKMK_CD_13                       AS  zSNRYKMK_CD_13                       ,                                                  
          TZWS.SNRYKMK_CD_14                       AS  zSNRYKMK_CD_14                       ,                                                  
          TZWS.SNRYKMK_CD_15                       AS  zSNRYKMK_CD_15                       ,                                                  
          TZWS.SNRYKMK_CD_16                       AS  zSNRYKMK_CD_16                       ,                                                  
          TZWS.SNRYKMK_CD_17                       AS  zSNRYKMK_CD_17                       ,                                                  
          TZWS.SNRYKMK_CD_18                       AS  zSNRYKMK_CD_18                       ,                                                  
          TZWS.SNRYKMK_CD_19                       AS  zSNRYKMK_CD_19                       ,                                                  
          TZWS.SNRYKMK_CD_20                       AS  zSNRYKMK_CD_20                       ,                                                  
          TZWS.SNRYKMK_CD_21                       AS  zSNRYKMK_CD_21                       ,                                                  
          TZWS.SNRYKMK_CD_22                       AS  zSNRYKMK_CD_22                       ,                                                  
          TZWS.SNRYKMK_CD_23                       AS  zSNRYKMK_CD_23                       ,                                                  
          TZWS.SNRYKMK_CD_24                       AS  zSNRYKMK_CD_24                       ,                                                  
          TZWS.SNRYKMK_CD_25                       AS  zSNRYKMK_CD_25                       ,                                                  
          TZWS.SNRYKMK_CD_26                       AS  zSNRYKMK_CD_26                       ,                                                  
          TZWS.SNRYKMK_CD_27                       AS  zSNRYKMK_CD_27                       ,                                                  
          TZWS.SNRYKMK_CD_28                       AS  zSNRYKMK_CD_28                       ,                                                  
          TZWS.SNRYKMK_CD_29                       AS  zSNRYKMK_CD_29                       ,                                                  
          TZWS.SNRYKMK_CD_30                       AS  zSNRYKMK_CD_30                       ,                                                  
          TZWS.SNRYKMK_CD_31                       AS  zSNRYKMK_CD_31                       ,                                                  
          TZWS.SNRYKMK_CD_32                       AS  zSNRYKMK_CD_32                       ,                                                  
          TZWS.SNRYKMK_CD_33                       AS  zSNRYKMK_CD_33                       ,                                                  
          TZWS.SNRYKMK_CD_34                       AS  zSNRYKMK_CD_34                       ,                                                  
          TZWS.SNRYKMK_CD_35                       AS  zSNRYKMK_CD_35                       ,                                                  
          TZWS.SNRYKMK_CD_36                       AS  zSNRYKMK_CD_36                       ,                                                  
          TZWS.SNRYKMK_CD_37                       AS  zSNRYKMK_CD_37                       ,                                                  
          TZWS.SNRYKMK_CD_38                       AS  zSNRYKMK_CD_38                       ,                                                  
          TZWS.SNRYKMK_CD_39                       AS  zSNRYKMK_CD_39                       ,                                                  
          TZWS.SNRYKMK_CD_40                       AS  zSNRYKMK_CD_40                       ,                                                  
          TZWS.SNRYKMK_CD_41                       AS  zSNRYKMK_CD_41                       ,                                                  
          TZWS.SNRYKMK_CD_42                       AS  zSNRYKMK_CD_42                       ,                                                  
          TZWS.SNRYKMK_CD_43                       AS  zSNRYKMK_CD_43                       ,                                                  
          TZWS.SNRYKMK_CD_44                       AS  zSNRYKMK_CD_44                       ,                                                  
          TZWS.SNRYKMK_CD_45                       AS  zSNRYKMK_CD_45                       ,                                                  
          TZWS.SNRYKMK_CD_46                       AS  zSNRYKMK_CD_46                       ,                                                  
          TZWS.SNRYKMK_CD_47                       AS  zSNRYKMK_CD_47                       ,                                                  
          TZWS.SNRYKMK_CD_48                       AS  zSNRYKMK_CD_48                       ,                                                  
          TZWS.SNRYKMK_CD_49                       AS  zSNRYKMK_CD_49                       ,                                                  
          TZWS.SNRYKMK_CD_50                       AS  zSNRYKMK_CD_50                       ,                                                  
          TZWS.SNRYKMK_CD_51                       AS  zSNRYKMK_CD_51                       ,                                                  
          TZWS.SNRYKMK_CD_52                       AS  zSNRYKMK_CD_52                       ,                                                  
          TZWS.SNRYKMK_CD_53                       AS  zSNRYKMK_CD_53                       ,                                  								
          TZWS.SNRYKMK_CD_54                       AS  zSNRYKMK_CD_54                       ,																									
          TZWS.SNRYKMK_CD_55                       AS  zSNRYKMK_CD_55                       ,																									
          TZWS.SNRYKMK_CD_56                       AS  zSNRYKMK_CD_56                       ,																									
          TZWS.SNRYKMK_CD_57                       AS  zSNRYKMK_CD_57                       ,																									
          TZWS.SNRYKMK_CD_58                       AS  zSNRYKMK_CD_58                       ,																									
          TZWS.SNRYKMK_CD_59                       AS  zSNRYKMK_CD_59                       ,																									
          TZWS.SNRYKMK_CD_60                       AS  zSNRYKMK_CD_60                       ,																									
          TZWS.KENSAKOMOKU_BISEIBUTSU_FLG          AS  zKENSAKOMOKU_BISEIBUTSU_FLG          ,																									
          TZWS.KENSAKOMOKU_KESSEI_FLG              AS  zKENSAKOMOKU_KESSEI_FLG              ,																									
          TZWS.KENSAKOMOKU_KETSUEKI_FLG            AS  zKENSAKOMOKU_KETSUEKI_FLG            ,																									
          TZWS.KENSAKOMOKU_BYORI_FLG               AS  zKENSAKOMOKU_BYORI_FLG               ,																									
          TZWS.KENSAKOMOKU_KISEICHU_FLG            AS  zKENSAKOMOKU_KISEICHU_FLG            ,																									
          TZWS.KENSAKOMOKU_SEIKA_FLG               AS  zKENSAKOMOKU_SEIKA_FLG               ,																									
          TZWS.KENSAKOMOKU_RI_FLG                  AS  zKENSAKOMOKU_RI_FLG                  ,																									
          TZWS.UPD_EIGY_YMD                        AS  zUPD_EIGY_YMD	
        FROM TT_TIKY_SHI�@TTS						
        LEFT OUTER JOIN TT_TIKY_KJN TTK										
        ON  TTS.DAIHYO_REC_ID = TTK.REC_ID										
        AND TTS.DAIHYO_KJN_CD = TTK.KJN_CD										
        AND TTK.DEL_FLG IS NULL										
        LEFT OUTER JOIN TT_Z_W_SHI�@TZWS										
        ON  TTS.REC_ID = TZWS.REC_ID										
        AND TTS.SHI_CD = TZWS.SHI_CD										
        LEFT OUTER JOIN TT_Z_W_KJN TZWK										
        ON  TZWS.DAIHYO_REC_ID = TZWK.REC_ID										
        AND TZWS.DAIHYO_KJN_CD = TZWK.KJN_CD
        WHERE�@TTS.REC_ID�@= '00'
           -- ��������2012/01/24
           AND (TTS.DEL_FLG IS NULL OR TZWS.DEL_FLG IS NULL)
           -- ��������2012/01/24																	
           AND TTS.UPD_EIGY_YMD�@>= NVL(iShimeFrom, '19700101')																
           AND TTS.UPD_EIGY_YMD�@<= iShimeTo ;
  weekRow weekCSR%ROWTYPE; 
  
-- �񋟗p�ƑO�񖖒��{�݃e�[�u������f�ރf�[�^���擾����J�[�\��
  CURSOR m2CSR IS    
       SELECT
          TTS.REC_ID                              ,
          TTS.SHI_CD                              ,
          TTS.DEL_FLG                             ,
          TTS.DEL_YOTEI_RIYU_CD                   ,
          TTS.CHOFUKU_AITSK_REC_ID                ,
          TTS.CHOFUKU_AITSK_SHI_CD                ,
          TTS.KYUIN_FLG                           ,
          TTS.KYUIN_S_YM                          ,
          TTS.KAIGYO_YOTEI_FLG                    ,
          TTS.KAIGYO_YOTEI_YM                     ,
          TTS.KANREN_DAIGAKU_OYA_REC_ID           ,
          TTS.KANREN_DAIGAKU_OYA_SHI_CD           ,
          TTS.SEISHIKI_SHI_NM                     ,
          TTS.SEISHIKI_SHI_NM30                   ,
          TTS.SEISHIKI_SHI_NM_KANA                ,
          TTS.SEISHIKI_SHI_NM_KANA40              ,
          TTS.SHI_RN                              ,
          TTS.SHI_RN_KANA                         ,
          TTS.KEN_CD                              ,
          TTS.SHIKU_CD                            ,
          TTS.OAZA_CD                             ,
          TTS.AZA_CD                              ,
          TTS.ZIP                                 ,
          TTS.JUSHO_KANJI_RENKETSU                ,
          TTS.JUSHO_KANA_RENKETSU                 ,
          TTS.KEN_NM_KANJI_MOJI_SU                ,
          TTS.SHIKU_NM_KANJI_MOJI_SU              ,
          TTS.OAZA_NM_KANJI_MOJI_SU               ,
          TTS.AZA_NM_KANJI_MOJI_SU                ,
          TTS.KEN_NM_KANA_MOJI_SU                 ,
          TTS.SHIKU_NM_KANA_MOJI_SU               ,
          TTS.OAZA_NM_KANA_MOJI_SU                ,
          TTS.AZA_NM_KANA_MOJI_SU                 ,
          TTS.JUSHO_HYOJI_NO                      ,
          TTS.JUSHOFUMEI_CD                       ,
          TTS.TEL                                 ,
          TTS.KEIEITAI_CD                         ,
          TTS.SHI_KBN_CD                          ,
          TTS.IMUSHITSU_REC_ID                    ,
          TTS.IMUSHITSU_SHI_CD                    ,
          TTS.SAISHINSA_KBN_CD                    ,
          TTS.BYOTO_HEISA_KBN                     ,
          TTS.TEL_NASHI_FLG                       ,
          TTS.MIKAKUNIN_FLG                       ,
          TTS.DAIHYO_REC_ID                       ,
          TTS.DAIHYO_KJN_CD                       ,
          TTK.KJN_NM                            ,
          TTK.KJN_NM_KANA                     ,
          TTS.SHI_BED_SU                          ,
          TTS.BYOIN_SBT_CD                        ,
          TTS.KYOKA_BED_SU_SONOTA                 ,
          TTS.KYOKA_BED_SU_SEISHIN                ,
          TTS.KYOKA_BED_SU_KEKKAKU                ,
          TTS.KYOKA_BED_SU_KANSEN                 ,
          TTS.KYOKA_BED_SU_GOKEI,
          TTS.KYOKA_BED_SU_IPPAN                  ,
          TTS.KYOKA_BED_SU_RYOYO                  ,
          TTS.BED_SU_KKNN_EIGY_YMD                ,
          TTS.SNRYKMK_CD_01                       ,
          TTS.SNRYKMK_CD_02                       ,
          TTS.SNRYKMK_CD_03                       ,
          TTS.SNRYKMK_CD_04                       ,
          TTS.SNRYKMK_CD_05                       ,
          TTS.SNRYKMK_CD_06                       ,
          TTS.SNRYKMK_CD_07                       ,
          TTS.SNRYKMK_CD_08                       ,
          TTS.SNRYKMK_CD_09                       ,
          TTS.SNRYKMK_CD_10                       ,
          TTS.SNRYKMK_CD_11                       ,
          TTS.SNRYKMK_CD_12                       ,
          TTS.SNRYKMK_CD_13                       ,
          TTS.SNRYKMK_CD_14                       ,
          TTS.SNRYKMK_CD_15                       ,
          TTS.SNRYKMK_CD_16                       ,
          TTS.SNRYKMK_CD_17                       ,
          TTS.SNRYKMK_CD_18                       ,
          TTS.SNRYKMK_CD_19                       ,
          TTS.SNRYKMK_CD_20                       ,
          TTS.SNRYKMK_CD_21                       ,
          TTS.SNRYKMK_CD_22                       ,
          TTS.SNRYKMK_CD_23                       ,
          TTS.SNRYKMK_CD_24                       ,
          TTS.SNRYKMK_CD_25                       ,
          TTS.SNRYKMK_CD_26                       ,
          TTS.SNRYKMK_CD_27                       ,
          TTS.SNRYKMK_CD_28                       ,
          TTS.SNRYKMK_CD_29                       ,
          TTS.SNRYKMK_CD_30                       ,
          TTS.SNRYKMK_CD_31                       ,
          TTS.SNRYKMK_CD_32                       ,
          TTS.SNRYKMK_CD_33                       ,
          TTS.SNRYKMK_CD_34                       ,
          TTS.SNRYKMK_CD_35                       ,
          TTS.SNRYKMK_CD_36                       ,
          TTS.SNRYKMK_CD_37                       ,
          TTS.SNRYKMK_CD_38                       ,
          TTS.SNRYKMK_CD_39                       ,
          TTS.SNRYKMK_CD_40                       ,
          TTS.SNRYKMK_CD_41                       ,
          TTS.SNRYKMK_CD_42                       ,
          TTS.SNRYKMK_CD_43                       ,
          TTS.SNRYKMK_CD_44                       ,
          TTS.SNRYKMK_CD_45                       ,
          TTS.SNRYKMK_CD_46                       ,
          TTS.SNRYKMK_CD_47                       ,
          TTS.SNRYKMK_CD_48                       ,
          TTS.SNRYKMK_CD_49                       ,
          TTS.SNRYKMK_CD_50                       ,
          TTS.SNRYKMK_CD_51                       ,
          TTS.SNRYKMK_CD_52                       ,
          TTS.SNRYKMK_CD_53                       ,
          TTS.SNRYKMK_CD_54                       ,
          TTS.SNRYKMK_CD_55                       ,
          TTS.SNRYKMK_CD_56                       ,
          TTS.SNRYKMK_CD_57                       ,
          TTS.SNRYKMK_CD_58                       ,
          TTS.SNRYKMK_CD_59                       ,
          TTS.SNRYKMK_CD_60                       ,
          TTS.KENSAKOMOKU_BISEIBUTSU_FLG          ,
          TTS.KENSAKOMOKU_KESSEI_FLG              ,
          TTS.KENSAKOMOKU_KETSUEKI_FLG            ,
          TTS.KENSAKOMOKU_BYORI_FLG               ,
          TTS.KENSAKOMOKU_KISEICHU_FLG            ,
          TTS.KENSAKOMOKU_SEIKA_FLG               ,
          TTS.KENSAKOMOKU_RI_FLG                  ,
          TTS.UPD_EIGY_YMD ,
          TZMS.REC_ID                              AS  zREC_ID                              ,
          TZMS.SHI_CD                              AS  zSHI_CD                              ,
          TZMS.DEL_FLG                             AS  zDEL_FLG                             ,
          TZMS.DEL_YOTEI_RIYU_CD                   AS  zDEL_YOTEI_RIYU_CD                   ,
          TZMS.CHOFUKU_AITSK_REC_ID                AS  zCHOFUKU_AITSK_REC_ID                ,
          TZMS.CHOFUKU_AITSK_SHI_CD                AS  zCHOFUKU_AITSK_SHI_CD                ,
          TZMS.KYUIN_FLG                           AS  zKYUIN_FLG                           ,
          TZMS.KYUIN_S_YM                          AS  zKYUIN_S_YM                          ,
          TZMS.KAIGYO_YOTEI_FLG                    AS  zKAIGYO_YOTEI_FLG                    ,
          TZMS.KAIGYO_YOTEI_YM                     AS  zKAIGYO_YOTEI_YM                     ,
          TZMS.KANREN_DAIGAKU_OYA_REC_ID           AS  zKANREN_DAIGAKU_OYA_REC_ID           ,
          TZMS.KANREN_DAIGAKU_OYA_SHI_CD           AS  zKANREN_DAIGAKU_OYA_SHI_CD           ,
          TZMS.SEISHIKI_SHI_NM                     AS  zSEISHIKI_SHI_NM                     ,
          TZMS.SEISHIKI_SHI_NM30                   AS  zSEISHIKI_SHI_NM30                   ,
          TZMS.SEISHIKI_SHI_NM_KANA                AS  zSEISHIKI_SHI_NM_KANA                ,
          TZMS.SEISHIKI_SHI_NM_KANA40              AS  zSEISHIKI_SHI_NM_KANA40              ,
          TZMS.SHI_RN                              AS  zSHI_RN                              ,
          TZMS.SHI_RN_KANA                         AS  zSHI_RN_KANA                         ,
          TZMS.KEN_CD                              AS  zKEN_CD                              ,
          TZMS.SHIKU_CD                            AS  zSHIKU_CD                            ,
          TZMS.OAZA_CD                             AS  zOAZA_CD                             ,
          TZMS.AZA_CD                              AS  zAZA_CD                              ,
          TZMS.ZIP                                 AS  zZIP                                 ,
          TZMS.JUSHO_KANJI_RENKETSU                AS  zJUSHO_KANJI_RENKETSU                ,
          TZMS.JUSHO_KANA_RENKETSU                 AS  zJUSHO_KANA_RENKETSU                 ,
          TZMS.KEN_NM_KANJI_MOJI_SU                AS  zKEN_NM_KANJI_MOJI_SU                ,
          TZMS.SHIKU_NM_KANJI_MOJI_SU              AS  zSHIKU_NM_KANJI_MOJI_SU              ,
          TZMS.OAZA_NM_KANJI_MOJI_SU               AS  zOAZA_NM_KANJI_MOJI_SU               ,
          TZMS.AZA_NM_KANJI_MOJI_SU                AS  zAZA_NM_KANJI_MOJI_SU                ,
          TZMS.KEN_NM_KANA_MOJI_SU                 AS  zKEN_NM_KANA_MOJI_SU                 ,
          TZMS.SHIKU_NM_KANA_MOJI_SU               AS  zSHIKU_NM_KANA_MOJI_SU               ,
          TZMS.OAZA_NM_KANA_MOJI_SU                AS  zOAZA_NM_KANA_MOJI_SU                ,
          TZMS.AZA_NM_KANA_MOJI_SU                 AS  zAZA_NM_KANA_MOJI_SU                 ,
          TZMS.JUSHO_HYOJI_NO                      AS  zJUSHO_HYOJI_NO                      ,
          TZMS.JUSHOFUMEI_CD                       AS  zJUSHOFUMEI_CD                       ,
          TZMS.TEL                                 AS  zTEL                                 ,
          TZMS.KEIEITAI_CD                         AS  zKEIEITAI_CD                         ,
          TZMS.SHI_KBN_CD                          AS  zSHI_KBN_CD                          ,
          TZMS.IMUSHITSU_REC_ID                    AS  zIMUSHITSU_REC_ID                    ,
          TZMS.IMUSHITSU_SHI_CD                    AS  zIMUSHITSU_SHI_CD                    ,
          TZMS.SAISHINSA_KBN_CD                    AS  zSAISHINSA_KBN_CD                    ,
          TZMS.BYOTO_HEISA_KBN                     AS  zBYOTO_HEISA_KBN                     ,
          TZMS.TEL_NASHI_FLG                       AS  zTEL_NASHI_FLG                       ,
          TZMS.MIKAKUNIN_FLG                       AS  zMIKAKUNIN_FLG                       ,
          TZMS.DAIHYO_REC_ID                       AS  zDAIHYO_REC_ID                       ,
          TZMS.DAIHYO_KJN_CD                       AS  zDAIHYO_KJN_CD                       ,
          TZMK.KJN_NM                              AS  zKJN_NM                              ,
          TZMK.KJN_NM_KANA                         AS  zKJN_NM_KANA                         ,
          TZMS.SHI_BED_SU                          AS  zSHI_BED_SU                          ,
          TZMS.BYOIN_SBT_CD                        AS  zBYOIN_SBT_CD                        ,
          TZMS.KYOKA_BED_SU_SONOTA                 AS  zKYOKA_BED_SU_SONOTA                 ,
          TZMS.KYOKA_BED_SU_SEISHIN                AS  zKYOKA_BED_SU_SEISHIN                ,
          TZMS.KYOKA_BED_SU_KEKKAKU                AS  zKYOKA_BED_SU_KEKKAKU                ,
          TZMS.KYOKA_BED_SU_KANSEN                 AS  zKYOKA_BED_SU_KANSEN                 ,
          TZMS.KYOKA_BED_SU_GOKEI                  AS  zKYOKA_BED_SU_GOKEI                  ,
          TZMS.KYOKA_BED_SU_IPPAN                  AS  zKYOKA_BED_SU_IPPAN                  ,
          TZMS.KYOKA_BED_SU_RYOYO                  AS  zKYOKA_BED_SU_RYOYO                  ,
          TZMS.BED_SU_KKNN_EIGY_YMD                AS  zBED_SU_KKNN_EIGY_YMD                ,
          TZMS.SNRYKMK_CD_01                       AS  zSNRYKMK_CD_01                       ,
          TZMS.SNRYKMK_CD_02                       AS  zSNRYKMK_CD_02                       ,
          TZMS.SNRYKMK_CD_03                       AS  zSNRYKMK_CD_03                       ,
          TZMS.SNRYKMK_CD_04                       AS  zSNRYKMK_CD_04                       ,
          TZMS.SNRYKMK_CD_05                       AS  zSNRYKMK_CD_05                       ,
          TZMS.SNRYKMK_CD_06                       AS  zSNRYKMK_CD_06                       ,
          TZMS.SNRYKMK_CD_07                       AS  zSNRYKMK_CD_07                       ,
          TZMS.SNRYKMK_CD_08                       AS  zSNRYKMK_CD_08                       ,
          TZMS.SNRYKMK_CD_09                       AS  zSNRYKMK_CD_09                       ,
          TZMS.SNRYKMK_CD_10                       AS  zSNRYKMK_CD_10                       ,
          TZMS.SNRYKMK_CD_11                       AS  zSNRYKMK_CD_11                       ,
          TZMS.SNRYKMK_CD_12                       AS  zSNRYKMK_CD_12                       ,
          TZMS.SNRYKMK_CD_13                       AS  zSNRYKMK_CD_13                       ,
          TZMS.SNRYKMK_CD_14                       AS  zSNRYKMK_CD_14                       ,
          TZMS.SNRYKMK_CD_15                       AS  zSNRYKMK_CD_15                       ,
          TZMS.SNRYKMK_CD_16                       AS  zSNRYKMK_CD_16                       ,
          TZMS.SNRYKMK_CD_17                       AS  zSNRYKMK_CD_17                       ,
          TZMS.SNRYKMK_CD_18                       AS  zSNRYKMK_CD_18                       ,
          TZMS.SNRYKMK_CD_19                       AS  zSNRYKMK_CD_19                       ,
          TZMS.SNRYKMK_CD_20                       AS  zSNRYKMK_CD_20                       ,
          TZMS.SNRYKMK_CD_21                       AS  zSNRYKMK_CD_21                       ,
          TZMS.SNRYKMK_CD_22                       AS  zSNRYKMK_CD_22                       ,
          TZMS.SNRYKMK_CD_23                       AS  zSNRYKMK_CD_23                       ,
          TZMS.SNRYKMK_CD_24                       AS  zSNRYKMK_CD_24                       ,
          TZMS.SNRYKMK_CD_25                       AS  zSNRYKMK_CD_25                       ,
          TZMS.SNRYKMK_CD_26                       AS  zSNRYKMK_CD_26                       ,
          TZMS.SNRYKMK_CD_27                       AS  zSNRYKMK_CD_27                       ,
          TZMS.SNRYKMK_CD_28                       AS  zSNRYKMK_CD_28                       ,
          TZMS.SNRYKMK_CD_29                       AS  zSNRYKMK_CD_29                       ,
          TZMS.SNRYKMK_CD_30                       AS  zSNRYKMK_CD_30                       ,
          TZMS.SNRYKMK_CD_31                       AS  zSNRYKMK_CD_31                       ,
          TZMS.SNRYKMK_CD_32                       AS  zSNRYKMK_CD_32                       ,
          TZMS.SNRYKMK_CD_33                       AS  zSNRYKMK_CD_33                       ,
          TZMS.SNRYKMK_CD_34                       AS  zSNRYKMK_CD_34                       ,
          TZMS.SNRYKMK_CD_35                       AS  zSNRYKMK_CD_35                       ,
          TZMS.SNRYKMK_CD_36                       AS  zSNRYKMK_CD_36                       ,
          TZMS.SNRYKMK_CD_37                       AS  zSNRYKMK_CD_37                       ,
          TZMS.SNRYKMK_CD_38                       AS  zSNRYKMK_CD_38                       ,
          TZMS.SNRYKMK_CD_39                       AS  zSNRYKMK_CD_39                       ,
          TZMS.SNRYKMK_CD_40                       AS  zSNRYKMK_CD_40                       ,
          TZMS.SNRYKMK_CD_41                       AS  zSNRYKMK_CD_41                       ,
          TZMS.SNRYKMK_CD_42                       AS  zSNRYKMK_CD_42                       ,
          TZMS.SNRYKMK_CD_43                       AS  zSNRYKMK_CD_43                       ,
          TZMS.SNRYKMK_CD_44                       AS  zSNRYKMK_CD_44                       ,
          TZMS.SNRYKMK_CD_45                       AS  zSNRYKMK_CD_45                       ,
          TZMS.SNRYKMK_CD_46                       AS  zSNRYKMK_CD_46                       ,
          TZMS.SNRYKMK_CD_47                       AS  zSNRYKMK_CD_47                       ,
          TZMS.SNRYKMK_CD_48                       AS  zSNRYKMK_CD_48                       ,
          TZMS.SNRYKMK_CD_49                       AS  zSNRYKMK_CD_49                       ,
          TZMS.SNRYKMK_CD_50                       AS  zSNRYKMK_CD_50                       ,
          TZMS.SNRYKMK_CD_51                       AS  zSNRYKMK_CD_51                       ,
          TZMS.SNRYKMK_CD_52                       AS  zSNRYKMK_CD_52                       ,
          TZMS.SNRYKMK_CD_53                       AS  zSNRYKMK_CD_53                       ,
          TZMS.SNRYKMK_CD_54                       AS  zSNRYKMK_CD_54                       ,
          TZMS.SNRYKMK_CD_55                       AS  zSNRYKMK_CD_55                       ,
          TZMS.SNRYKMK_CD_56                       AS  zSNRYKMK_CD_56                       ,
          TZMS.SNRYKMK_CD_57                       AS  zSNRYKMK_CD_57                       ,
          TZMS.SNRYKMK_CD_58                       AS  zSNRYKMK_CD_58                       ,
          TZMS.SNRYKMK_CD_59                       AS  zSNRYKMK_CD_59                       ,
          TZMS.SNRYKMK_CD_60                       AS  zSNRYKMK_CD_60                       ,
          TZMS.KENSAKOMOKU_BISEIBUTSU_FLG          AS  zKENSAKOMOKU_BISEIBUTSU_FLG          ,
          TZMS.KENSAKOMOKU_KESSEI_FLG              AS  zKENSAKOMOKU_KESSEI_FLG              ,
          TZMS.KENSAKOMOKU_KETSUEKI_FLG            AS  zKENSAKOMOKU_KETSUEKI_FLG            ,
          TZMS.KENSAKOMOKU_BYORI_FLG               AS  zKENSAKOMOKU_BYORI_FLG               ,
          TZMS.KENSAKOMOKU_KISEICHU_FLG            AS  zKENSAKOMOKU_KISEICHU_FLG            ,
          TZMS.KENSAKOMOKU_SEIKA_FLG               AS  zKENSAKOMOKU_SEIKA_FLG               ,
          TZMS.KENSAKOMOKU_RI_FLG                  AS  zKENSAKOMOKU_RI_FLG                  ,
          TZMS.UPD_EIGY_YMD                        AS  zUPD_EIGY_YMD
        FROM TT_TIKY_SHI TTS
        LEFT OUTER JOIN TT_TIKY_KJN TTK
        ON  TTS.DAIHYO_REC_ID = TTK.REC_ID
        AND TTS.DAIHYO_KJN_CD = TTK.KJN_CD
        AND TTK.DEL_FLG IS NULL
        LEFT OUTER JOIN TT_Z_ME_SHI�@TZMS
        ON  TTS.REC_ID = TZMS.REC_ID
        AND TTS.SHI_CD = TZMS.SHI_CD
        LEFT OUTER JOIN TT_Z_ME_KJN TZMK
        ON  TZMS.DAIHYO_REC_ID = TZMK.REC_ID
        AND TZMS.DAIHYO_KJN_CD = TZMK.KJN_CD
        WHERE�@TTS.REC_ID�@= '00'
           -- ��������2012/01/24	
           AND (TTS.DEL_FLG IS NULL OR TZMS.DEL_FLG IS NULL)																
           -- ��������2012/01/24
           AND TTS.UPD_EIGY_YMD�@>= NVL(iShimeFrom, '19700101')																
           AND TTS.UPD_EIGY_YMD�@<= iShimeTo ;
    m2Row m2CSR%ROWTYPE;        

-- �񋟗p�ƑO�񒆒��{�݃e�[�u������f�ރf�[�^���擾����J�[�\��
  CURSOR m1CSR IS    
       SELECT
          TTS.REC_ID                              ,
          TTS.SHI_CD                              ,
          TTS.DEL_FLG                             ,
          TTS.DEL_YOTEI_RIYU_CD                   ,
          TTS.CHOFUKU_AITSK_REC_ID                ,
          TTS.CHOFUKU_AITSK_SHI_CD                ,
          TTS.KYUIN_FLG                           ,
          TTS.KYUIN_S_YM                          ,
          TTS.KAIGYO_YOTEI_FLG                    ,
          TTS.KAIGYO_YOTEI_YM                     ,
          TTS.KANREN_DAIGAKU_OYA_REC_ID           ,
          TTS.KANREN_DAIGAKU_OYA_SHI_CD           ,
          TTS.SEISHIKI_SHI_NM                     ,
          TTS.SEISHIKI_SHI_NM30                   ,
          TTS.SEISHIKI_SHI_NM_KANA                ,
          TTS.SEISHIKI_SHI_NM_KANA40              ,
          TTS.SHI_RN                              ,
          TTS.SHI_RN_KANA                         ,
          TTS.KEN_CD                              ,
          TTS.SHIKU_CD                            ,
          TTS.OAZA_CD                             ,
          TTS.AZA_CD                              ,
          TTS.ZIP                                 ,
          TTS.JUSHO_KANJI_RENKETSU                ,
          TTS.JUSHO_KANA_RENKETSU                 ,
          TTS.KEN_NM_KANJI_MOJI_SU                ,
          TTS.SHIKU_NM_KANJI_MOJI_SU              ,
          TTS.OAZA_NM_KANJI_MOJI_SU               ,
          TTS.AZA_NM_KANJI_MOJI_SU                ,
          TTS.KEN_NM_KANA_MOJI_SU                 ,
          TTS.SHIKU_NM_KANA_MOJI_SU               ,
          TTS.OAZA_NM_KANA_MOJI_SU                ,
          TTS.AZA_NM_KANA_MOJI_SU                 ,
          TTS.JUSHO_HYOJI_NO                      ,
          TTS.JUSHOFUMEI_CD                       ,
          TTS.TEL                                 ,
          TTS.KEIEITAI_CD                         ,
          TTS.SHI_KBN_CD                          ,
          TTS.IMUSHITSU_REC_ID                    ,
          TTS.IMUSHITSU_SHI_CD                    ,
          TTS.SAISHINSA_KBN_CD                    ,
          TTS.BYOTO_HEISA_KBN                     ,
          TTS.TEL_NASHI_FLG                       ,
          TTS.MIKAKUNIN_FLG                       ,
          TTS.DAIHYO_REC_ID                       ,
          TTS.DAIHYO_KJN_CD                       ,
          TTK.KJN_NM                            ,
          TTK.KJN_NM_KANA                     ,
          TTS.SHI_BED_SU                          ,
          TTS.BYOIN_SBT_CD                        ,
          TTS.KYOKA_BED_SU_SONOTA                 ,
          TTS.KYOKA_BED_SU_SEISHIN                ,
          TTS.KYOKA_BED_SU_KEKKAKU                ,
          TTS.KYOKA_BED_SU_KANSEN                 ,
          TTS.KYOKA_BED_SU_GOKEI,
          TTS.KYOKA_BED_SU_IPPAN                  ,
          TTS.KYOKA_BED_SU_RYOYO                  ,
          TTS.BED_SU_KKNN_EIGY_YMD                ,
          TTS.SNRYKMK_CD_01                       ,
          TTS.SNRYKMK_CD_02                       ,
          TTS.SNRYKMK_CD_03                       ,
          TTS.SNRYKMK_CD_04                       ,
          TTS.SNRYKMK_CD_05                       ,
          TTS.SNRYKMK_CD_06                       ,
          TTS.SNRYKMK_CD_07                       ,
          TTS.SNRYKMK_CD_08                       ,
          TTS.SNRYKMK_CD_09                       ,
          TTS.SNRYKMK_CD_10                       ,
          TTS.SNRYKMK_CD_11                       ,
          TTS.SNRYKMK_CD_12                       ,
          TTS.SNRYKMK_CD_13                       ,
          TTS.SNRYKMK_CD_14                       ,
          TTS.SNRYKMK_CD_15                       ,
          TTS.SNRYKMK_CD_16                       ,
          TTS.SNRYKMK_CD_17                       ,
          TTS.SNRYKMK_CD_18                       ,
          TTS.SNRYKMK_CD_19                       ,
          TTS.SNRYKMK_CD_20                       ,
          TTS.SNRYKMK_CD_21                       ,
          TTS.SNRYKMK_CD_22                       ,
          TTS.SNRYKMK_CD_23                       ,
          TTS.SNRYKMK_CD_24                       ,
          TTS.SNRYKMK_CD_25                       ,
          TTS.SNRYKMK_CD_26                       ,
          TTS.SNRYKMK_CD_27                       ,
          TTS.SNRYKMK_CD_28                       ,
          TTS.SNRYKMK_CD_29                       ,
          TTS.SNRYKMK_CD_30                       ,
          TTS.SNRYKMK_CD_31                       ,
          TTS.SNRYKMK_CD_32                       ,
          TTS.SNRYKMK_CD_33                       ,
          TTS.SNRYKMK_CD_34                       ,
          TTS.SNRYKMK_CD_35                       ,
          TTS.SNRYKMK_CD_36                       ,
          TTS.SNRYKMK_CD_37                       ,
          TTS.SNRYKMK_CD_38                       ,
          TTS.SNRYKMK_CD_39                       ,
          TTS.SNRYKMK_CD_40                       ,
          TTS.SNRYKMK_CD_41                       ,
          TTS.SNRYKMK_CD_42                       ,
          TTS.SNRYKMK_CD_43                       ,
          TTS.SNRYKMK_CD_44                       ,
          TTS.SNRYKMK_CD_45                       ,
          TTS.SNRYKMK_CD_46                       ,
          TTS.SNRYKMK_CD_47                       ,
          TTS.SNRYKMK_CD_48                       ,
          TTS.SNRYKMK_CD_49                       ,
          TTS.SNRYKMK_CD_50                       ,
          TTS.SNRYKMK_CD_51                       ,
          TTS.SNRYKMK_CD_52                       ,
          TTS.SNRYKMK_CD_53                       ,
          TTS.SNRYKMK_CD_54                       ,
          TTS.SNRYKMK_CD_55                       ,
          TTS.SNRYKMK_CD_56                       ,
          TTS.SNRYKMK_CD_57                       ,
          TTS.SNRYKMK_CD_58                       ,
          TTS.SNRYKMK_CD_59                       ,
          TTS.SNRYKMK_CD_60                       ,
          TTS.KENSAKOMOKU_BISEIBUTSU_FLG          ,
          TTS.KENSAKOMOKU_KESSEI_FLG              ,
          TTS.KENSAKOMOKU_KETSUEKI_FLG            ,
          TTS.KENSAKOMOKU_BYORI_FLG               ,
          TTS.KENSAKOMOKU_KISEICHU_FLG            ,
          TTS.KENSAKOMOKU_SEIKA_FLG               ,
          TTS.KENSAKOMOKU_RI_FLG                  ,
          TTS.UPD_EIGY_YMD ,
          TZMS.REC_ID                              AS  zREC_ID                              ,
          TZMS.SHI_CD                              AS  zSHI_CD                              ,
          TZMS.DEL_FLG                             AS  zDEL_FLG                             ,
          TZMS.DEL_YOTEI_RIYU_CD                   AS  zDEL_YOTEI_RIYU_CD                   ,
          TZMS.CHOFUKU_AITSK_REC_ID                AS  zCHOFUKU_AITSK_REC_ID                ,
          TZMS.CHOFUKU_AITSK_SHI_CD                AS  zCHOFUKU_AITSK_SHI_CD                ,
          TZMS.KYUIN_FLG                           AS  zKYUIN_FLG                           ,
          TZMS.KYUIN_S_YM                          AS  zKYUIN_S_YM                          ,
          TZMS.KAIGYO_YOTEI_FLG                    AS  zKAIGYO_YOTEI_FLG                    ,
          TZMS.KAIGYO_YOTEI_YM                     AS  zKAIGYO_YOTEI_YM                     ,
          TZMS.KANREN_DAIGAKU_OYA_REC_ID           AS  zKANREN_DAIGAKU_OYA_REC_ID           ,
          TZMS.KANREN_DAIGAKU_OYA_SHI_CD           AS  zKANREN_DAIGAKU_OYA_SHI_CD           ,
          TZMS.SEISHIKI_SHI_NM                     AS  zSEISHIKI_SHI_NM                     ,
          TZMS.SEISHIKI_SHI_NM30                   AS  zSEISHIKI_SHI_NM30                   ,
          TZMS.SEISHIKI_SHI_NM_KANA                AS  zSEISHIKI_SHI_NM_KANA                ,
          TZMS.SEISHIKI_SHI_NM_KANA40              AS  zSEISHIKI_SHI_NM_KANA40              ,
          TZMS.SHI_RN                              AS  zSHI_RN                              ,
          TZMS.SHI_RN_KANA                         AS  zSHI_RN_KANA                         ,
          TZMS.KEN_CD                              AS  zKEN_CD                              ,
          TZMS.SHIKU_CD                            AS  zSHIKU_CD                            ,
          TZMS.OAZA_CD                             AS  zOAZA_CD                             ,
          TZMS.AZA_CD                              AS  zAZA_CD                              ,
          TZMS.ZIP                                 AS  zZIP                                 ,
          TZMS.JUSHO_KANJI_RENKETSU                AS  zJUSHO_KANJI_RENKETSU                ,
          TZMS.JUSHO_KANA_RENKETSU                 AS  zJUSHO_KANA_RENKETSU                 ,
          TZMS.KEN_NM_KANJI_MOJI_SU                AS  zKEN_NM_KANJI_MOJI_SU                ,
          TZMS.SHIKU_NM_KANJI_MOJI_SU              AS  zSHIKU_NM_KANJI_MOJI_SU              ,
          TZMS.OAZA_NM_KANJI_MOJI_SU               AS  zOAZA_NM_KANJI_MOJI_SU               ,
          TZMS.AZA_NM_KANJI_MOJI_SU                AS  zAZA_NM_KANJI_MOJI_SU                ,
          TZMS.KEN_NM_KANA_MOJI_SU                 AS  zKEN_NM_KANA_MOJI_SU                 ,
          TZMS.SHIKU_NM_KANA_MOJI_SU               AS  zSHIKU_NM_KANA_MOJI_SU               ,
          TZMS.OAZA_NM_KANA_MOJI_SU                AS  zOAZA_NM_KANA_MOJI_SU                ,
          TZMS.AZA_NM_KANA_MOJI_SU                 AS  zAZA_NM_KANA_MOJI_SU                 ,
          TZMS.JUSHO_HYOJI_NO                      AS  zJUSHO_HYOJI_NO                      ,
          TZMS.JUSHOFUMEI_CD                       AS  zJUSHOFUMEI_CD                       ,
          TZMS.TEL                                 AS  zTEL                                 ,
          TZMS.KEIEITAI_CD                         AS  zKEIEITAI_CD                         ,
          TZMS.SHI_KBN_CD                          AS  zSHI_KBN_CD                          ,
          TZMS.IMUSHITSU_REC_ID                    AS  zIMUSHITSU_REC_ID                    ,
          TZMS.IMUSHITSU_SHI_CD                    AS  zIMUSHITSU_SHI_CD                    ,
          TZMS.SAISHINSA_KBN_CD                    AS  zSAISHINSA_KBN_CD                    ,
          TZMS.BYOTO_HEISA_KBN                     AS  zBYOTO_HEISA_KBN                     ,
          TZMS.TEL_NASHI_FLG                       AS  zTEL_NASHI_FLG                       ,
          TZMS.MIKAKUNIN_FLG                       AS  zMIKAKUNIN_FLG                       ,
          TZMS.DAIHYO_REC_ID                       AS  zDAIHYO_REC_ID                       ,
          TZMS.DAIHYO_KJN_CD                       AS  zDAIHYO_KJN_CD                       ,
          TZMK.KJN_NM                              AS  zKJN_NM                              ,
          TZMK.KJN_NM_KANA                         AS  zKJN_NM_KANA                         ,
          TZMS.SHI_BED_SU                          AS  zSHI_BED_SU                          ,
          TZMS.BYOIN_SBT_CD                        AS  zBYOIN_SBT_CD                        ,
          TZMS.KYOKA_BED_SU_SONOTA                 AS  zKYOKA_BED_SU_SONOTA                 ,
          TZMS.KYOKA_BED_SU_SEISHIN                AS  zKYOKA_BED_SU_SEISHIN                ,
          TZMS.KYOKA_BED_SU_KEKKAKU                AS  zKYOKA_BED_SU_KEKKAKU                ,
          TZMS.KYOKA_BED_SU_KANSEN                 AS  zKYOKA_BED_SU_KANSEN                 ,
          TZMS.KYOKA_BED_SU_GOKEI                  AS  zKYOKA_BED_SU_GOKEI                  ,
          TZMS.KYOKA_BED_SU_IPPAN                  AS  zKYOKA_BED_SU_IPPAN                  ,
          TZMS.KYOKA_BED_SU_RYOYO                  AS  zKYOKA_BED_SU_RYOYO                  ,
          TZMS.BED_SU_KKNN_EIGY_YMD                AS  zBED_SU_KKNN_EIGY_YMD                ,
          TZMS.SNRYKMK_CD_01                       AS  zSNRYKMK_CD_01                       ,
          TZMS.SNRYKMK_CD_02                       AS  zSNRYKMK_CD_02                       ,
          TZMS.SNRYKMK_CD_03                       AS  zSNRYKMK_CD_03                       ,
          TZMS.SNRYKMK_CD_04                       AS  zSNRYKMK_CD_04                       ,
          TZMS.SNRYKMK_CD_05                       AS  zSNRYKMK_CD_05                       ,
          TZMS.SNRYKMK_CD_06                       AS  zSNRYKMK_CD_06                       ,
          TZMS.SNRYKMK_CD_07                       AS  zSNRYKMK_CD_07                       ,
          TZMS.SNRYKMK_CD_08                       AS  zSNRYKMK_CD_08                       ,
          TZMS.SNRYKMK_CD_09                       AS  zSNRYKMK_CD_09                       ,
          TZMS.SNRYKMK_CD_10                       AS  zSNRYKMK_CD_10                       ,
          TZMS.SNRYKMK_CD_11                       AS  zSNRYKMK_CD_11                       ,
          TZMS.SNRYKMK_CD_12                       AS  zSNRYKMK_CD_12                       ,
          TZMS.SNRYKMK_CD_13                       AS  zSNRYKMK_CD_13                       ,
          TZMS.SNRYKMK_CD_14                       AS  zSNRYKMK_CD_14                       ,
          TZMS.SNRYKMK_CD_15                       AS  zSNRYKMK_CD_15                       ,
          TZMS.SNRYKMK_CD_16                       AS  zSNRYKMK_CD_16                       ,
          TZMS.SNRYKMK_CD_17                       AS  zSNRYKMK_CD_17                       ,
          TZMS.SNRYKMK_CD_18                       AS  zSNRYKMK_CD_18                       ,
          TZMS.SNRYKMK_CD_19                       AS  zSNRYKMK_CD_19                       ,
          TZMS.SNRYKMK_CD_20                       AS  zSNRYKMK_CD_20                       ,
          TZMS.SNRYKMK_CD_21                       AS  zSNRYKMK_CD_21                       ,
          TZMS.SNRYKMK_CD_22                       AS  zSNRYKMK_CD_22                       ,
          TZMS.SNRYKMK_CD_23                       AS  zSNRYKMK_CD_23                       ,
          TZMS.SNRYKMK_CD_24                       AS  zSNRYKMK_CD_24                       ,
          TZMS.SNRYKMK_CD_25                       AS  zSNRYKMK_CD_25                       ,
          TZMS.SNRYKMK_CD_26                       AS  zSNRYKMK_CD_26                       ,
          TZMS.SNRYKMK_CD_27                       AS  zSNRYKMK_CD_27                       ,
          TZMS.SNRYKMK_CD_28                       AS  zSNRYKMK_CD_28                       ,
          TZMS.SNRYKMK_CD_29                       AS  zSNRYKMK_CD_29                       ,
          TZMS.SNRYKMK_CD_30                       AS  zSNRYKMK_CD_30                       ,
          TZMS.SNRYKMK_CD_31                       AS  zSNRYKMK_CD_31                       ,
          TZMS.SNRYKMK_CD_32                       AS  zSNRYKMK_CD_32                       ,
          TZMS.SNRYKMK_CD_33                       AS  zSNRYKMK_CD_33                       ,
          TZMS.SNRYKMK_CD_34                       AS  zSNRYKMK_CD_34                       ,
          TZMS.SNRYKMK_CD_35                       AS  zSNRYKMK_CD_35                       ,
          TZMS.SNRYKMK_CD_36                       AS  zSNRYKMK_CD_36                       ,
          TZMS.SNRYKMK_CD_37                       AS  zSNRYKMK_CD_37                       ,
          TZMS.SNRYKMK_CD_38                       AS  zSNRYKMK_CD_38                       ,
          TZMS.SNRYKMK_CD_39                       AS  zSNRYKMK_CD_39                       ,
          TZMS.SNRYKMK_CD_40                       AS  zSNRYKMK_CD_40                       ,
          TZMS.SNRYKMK_CD_41                       AS  zSNRYKMK_CD_41                       ,
          TZMS.SNRYKMK_CD_42                       AS  zSNRYKMK_CD_42                       ,
          TZMS.SNRYKMK_CD_43                       AS  zSNRYKMK_CD_43                       ,
          TZMS.SNRYKMK_CD_44                       AS  zSNRYKMK_CD_44                       ,
          TZMS.SNRYKMK_CD_45                       AS  zSNRYKMK_CD_45                       ,
          TZMS.SNRYKMK_CD_46                       AS  zSNRYKMK_CD_46                       ,
          TZMS.SNRYKMK_CD_47                       AS  zSNRYKMK_CD_47                       ,
          TZMS.SNRYKMK_CD_48                       AS  zSNRYKMK_CD_48                       ,
          TZMS.SNRYKMK_CD_49                       AS  zSNRYKMK_CD_49                       ,
          TZMS.SNRYKMK_CD_50                       AS  zSNRYKMK_CD_50                       ,
          TZMS.SNRYKMK_CD_51                       AS  zSNRYKMK_CD_51                       ,
          TZMS.SNRYKMK_CD_52                       AS  zSNRYKMK_CD_52                       ,
          TZMS.SNRYKMK_CD_53                       AS  zSNRYKMK_CD_53                       ,
          TZMS.SNRYKMK_CD_54                       AS  zSNRYKMK_CD_54                       ,
          TZMS.SNRYKMK_CD_55                       AS  zSNRYKMK_CD_55                       ,
          TZMS.SNRYKMK_CD_56                       AS  zSNRYKMK_CD_56                       ,
          TZMS.SNRYKMK_CD_57                       AS  zSNRYKMK_CD_57                       ,
          TZMS.SNRYKMK_CD_58                       AS  zSNRYKMK_CD_58                       ,
          TZMS.SNRYKMK_CD_59                       AS  zSNRYKMK_CD_59                       ,
          TZMS.SNRYKMK_CD_60                       AS  zSNRYKMK_CD_60                       ,
          TZMS.KENSAKOMOKU_BISEIBUTSU_FLG          AS  zKENSAKOMOKU_BISEIBUTSU_FLG          ,
          TZMS.KENSAKOMOKU_KESSEI_FLG              AS  zKENSAKOMOKU_KESSEI_FLG              ,
          TZMS.KENSAKOMOKU_KETSUEKI_FLG            AS  zKENSAKOMOKU_KETSUEKI_FLG            ,
          TZMS.KENSAKOMOKU_BYORI_FLG               AS  zKENSAKOMOKU_BYORI_FLG               ,
          TZMS.KENSAKOMOKU_KISEICHU_FLG            AS  zKENSAKOMOKU_KISEICHU_FLG            ,
          TZMS.KENSAKOMOKU_SEIKA_FLG               AS  zKENSAKOMOKU_SEIKA_FLG               ,
          TZMS.KENSAKOMOKU_RI_FLG                  AS  zKENSAKOMOKU_RI_FLG                  ,
          TZMS.UPD_EIGY_YMD                        AS  zUPD_EIGY_YMD
        FROM TT_TIKY_SHI TTS
        LEFT OUTER JOIN TT_TIKY_KJN TTK
        ON  TTS.DAIHYO_REC_ID = TTK.REC_ID
        AND TTS.DAIHYO_KJN_CD = TTK.KJN_CD
        AND TTK.DEL_FLG IS NULL
        LEFT OUTER JOIN TT_Z_MM_SHI�@TZMS
        ON  TTS.REC_ID = TZMS.REC_ID
        AND TTS.SHI_CD = TZMS.SHI_CD
        LEFT OUTER JOIN TT_Z_MM_KJN TZMK
        ON  TZMS.DAIHYO_REC_ID = TZMK.REC_ID
        AND TZMS.DAIHYO_KJN_CD = TZMK.KJN_CD
        WHERE�@TTS.REC_ID�@= '00'
           -- ��������2012/01/24
           AND (TTS.DEL_FLG IS NULL OR TZMS.DEL_FLG IS NULL)
           -- ��������2012/01/24																	
           AND TTS.UPD_EIGY_YMD�@>= NVL(iShimeFrom, '19700101')																
           AND TTS.UPD_EIGY_YMD�@<= iShimeTo ;
    m1Row m1CSR%ROWTYPE; 
    
    
  
	BEGIN
      -- �J�n���O�o��
      ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'PL/SQL Start',PGM_ID || '�̏������J�n���܂��B',iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);
      -- �[�i�p�X�L�[�}�̎擾���s���B
		  vSchemaNm := ULT_COMMON.GET_SCHEMA_NAME(ULT_COMMON.SYS_ENV_JOSU_DAI_CD, ULT_COMMON.NOHIN_SHEMA_JOSU_SHO_CD);
      oROW_COUNT:=0;
     
	    IF iShimeKind = ULT_COMMON.SHIME_SBT_CD_HISHIME THEN
          -- �����߂̏ꍇ
        
        IF iLayoutKind = ULT_COMMON.LAYOUT_SBT_CD_SHIN THEN
          --�V���C�A�E�g
          --�V_������_DCF�{�݃e�[�u���̃f�[�^���N���A����B          
          EXECUTE_SQL := 'TRUNCATE TABLE ' || vSchemaNm || '.' || 'TD_ND_DCF_SHI';
          EXECUTE IMMEDIATE EXECUTE_SQL;
          ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);
          
          EXECUTE_SQL:='SELECT                                                    
          TTS.REC_ID                              ,                                                  
          TTS.SHI_CD                              ,                                                  
          TTS.DEL_FLG                             ,                                                  
          TTS.DEL_YOTEI_RIYU_CD                   ,                                                  
          TTS.CHOFUKU_AITSK_REC_ID                ,                                                  
          TTS.CHOFUKU_AITSK_SHI_CD                ,                                                  
          TTS.KYUIN_FLG                     ,                                                  
          TTS.KYUIN_S_YM                    ,                                                  
          TTS.KAIGYO_YOTEI_FLG       ,                                                  
          TTS.KAIGYO_YOTEI_YM        ,                                                  
          TTS.KANREN_DAIGAKU_OYA_REC_ID           ,                                                  
          TTS.KANREN_DAIGAKU_OYA_SHI_CD           ,                                                  
          TTS.SEISHIKI_SHI_NM                     ,                                                  
          TTS.SEISHIKI_SHI_NM30                   ,                                                  
          TTS.SEISHIKI_SHI_NM_KANA                ,                                                  
          TTS.SEISHIKI_SHI_NM_KANA40              ,                                                  
          TTS.SHI_RN                              ,                                                  
          TTS.SHI_RN_KANA                         ,                                                  
          TTS.KEN_CD                              ,                                                  
          TTS.SHIKU_CD                            ,                                                  
          TTS.OAZA_CD                             ,                                                  
          TTS.AZA_CD                              ,                                                  
          TTS.ZIP                                 ,                                                  
          TTS.JUSHO_KANJI_RENKETSU                ,                                                  
          TTS.JUSHO_KANA_RENKETSU                 ,                                                  
          TTS.KEN_NM_KANJI_MOJI_SU                ,                                                  
          TTS.SHIKU_NM_KANJI_MOJI_SU              ,                                                  
          TTS.OAZA_NM_KANJI_MOJI_SU               ,                                                  
          TTS.AZA_NM_KANJI_MOJI_SU                ,                                                  
          TTS.KEN_NM_KANA_MOJI_SU                 ,                                                  
          TTS.SHIKU_NM_KANA_MOJI_SU               ,                                                  
          TTS.OAZA_NM_KANA_MOJI_SU                ,                                                  
          TTS.AZA_NM_KANA_MOJI_SU                 ,                                                  
          TTS.JUSHO_HYOJI_NO                      ,                                                  
          TTS.JUSHOFUMEI_CD                       ,                                                  
          TTS.TEL                                 ,                                                  
          TTS.KEIEITAI_CD                         ,                                                  
          TTS.SHI_KBN_CD                          ,                                                  
          TTS.IMUSHITSU_REC_ID                    ,                                                  
          TTS.IMUSHITSU_SHI_CD                    ,                                                  
          TTS.SAISHINSA_KBN_CD                    ,                                                  
          TTS.BYOTO_HEISA_KBN                     ,                                                  
          TTS.TEL_NASHI_FLG                       ,                                                  
          TTS.MIKAKUNIN_FLG                       ,                                                  
          TTS.DAIHYO_REC_ID                       ,                                                  
          TTS.DAIHYO_KJN_CD                       ,                                                  
          TTK.KJN_NM                            ,                                                  
          TTK.KJN_NM_KANA                     ,                                                  
          TO_CHAR(TTS.SHI_BED_SU,''FM9999'') AS SHI_BED_SU,                                                  
          TTS.BYOIN_SBT_CD                        ,                                                  
          TTS.KYOKA_BED_SU_SONOTA                 ,                                                  
          TTS.KYOKA_BED_SU_SEISHIN                ,                                                  
          TTS.KYOKA_BED_SU_KEKKAKU                ,                                                  
          TTS.KYOKA_BED_SU_KANSEN                 ,                                                  
          TO_CHAR(TTS.KYOKA_BED_SU_GOKEI,''FM9999'') AS KYOKA_BED_SU_GOKEI,                                                  
          TTS.KYOKA_BED_SU_IPPAN                  ,                                                  
          TTS.KYOKA_BED_SU_RYOYO                  ,                                                  
          TTS.BED_SU_KKNN_EIGY_YMD                ,                                                  
          TTS.SNRYKMK_CD_01                       ,                                                  
          TTS.SNRYKMK_CD_02                       ,                                                  
          TTS.SNRYKMK_CD_03                       ,                                                  
          TTS.SNRYKMK_CD_04                       ,                                                  
          TTS.SNRYKMK_CD_05                       ,                                                  
          TTS.SNRYKMK_CD_06                       ,                                                  
          TTS.SNRYKMK_CD_07                       ,                                                  
          TTS.SNRYKMK_CD_08                       ,                                                  
          TTS.SNRYKMK_CD_09                       ,                                                  
          TTS.SNRYKMK_CD_10                       ,                                                  
          TTS.SNRYKMK_CD_11                       ,                                                  
          TTS.SNRYKMK_CD_12                       ,                                                  
          TTS.SNRYKMK_CD_13                       ,                                                  
          TTS.SNRYKMK_CD_14                       ,                                                  
          TTS.SNRYKMK_CD_15                       ,                                                  
          TTS.SNRYKMK_CD_16                       ,                                                  
          TTS.SNRYKMK_CD_17                       ,                                                  
          TTS.SNRYKMK_CD_18                       ,                                                  
          TTS.SNRYKMK_CD_19                       ,                                                  
          TTS.SNRYKMK_CD_20                       ,                                                  
          TTS.SNRYKMK_CD_21                       ,                                                  
          TTS.SNRYKMK_CD_22                       ,                                                  
          TTS.SNRYKMK_CD_23                       ,                                                  
          TTS.SNRYKMK_CD_24                       ,                                                  
          TTS.SNRYKMK_CD_25                       ,                                                  
          TTS.SNRYKMK_CD_26                       ,                                                  
          TTS.SNRYKMK_CD_27                       ,                                                  
          TTS.SNRYKMK_CD_28                       ,                                                  
          TTS.SNRYKMK_CD_29                       ,                                                  
          TTS.SNRYKMK_CD_30                       ,                                                  
          TTS.SNRYKMK_CD_31                       ,                                                  
          TTS.SNRYKMK_CD_32                       ,                                                  
          TTS.SNRYKMK_CD_33                       ,                                                  
          TTS.SNRYKMK_CD_34                       ,                                                  
          TTS.SNRYKMK_CD_35                       ,                                                  
          TTS.SNRYKMK_CD_36                       ,                                                  
          TTS.SNRYKMK_CD_37                       ,                                                  
          TTS.SNRYKMK_CD_38                       ,                                                  
          TTS.SNRYKMK_CD_39                       ,                                                  
          TTS.SNRYKMK_CD_40                       ,                                                  
          TTS.SNRYKMK_CD_41                       ,                                                  
          TTS.SNRYKMK_CD_42                       ,                                                  
          TTS.SNRYKMK_CD_43                       ,                                                  
          TTS.SNRYKMK_CD_44                       ,                                                  
          TTS.SNRYKMK_CD_45                       ,                                                  
          TTS.SNRYKMK_CD_46                       ,                                                  
          TTS.SNRYKMK_CD_47                       ,                                                  
          TTS.SNRYKMK_CD_48                       ,                                                  
          TTS.SNRYKMK_CD_49                       ,                                                  
          TTS.SNRYKMK_CD_50                       ,                                                  
          TTS.SNRYKMK_CD_51                       ,                                                  
          TTS.SNRYKMK_CD_52                       ,                                                  
          TTS.SNRYKMK_CD_53                       ,                                                  
          TTS.SNRYKMK_CD_54                       ,                                                  
          TTS.SNRYKMK_CD_55                       ,                                                  
          TTS.SNRYKMK_CD_56                       ,                                                  
          TTS.SNRYKMK_CD_57                       ,                                                  
          TTS.SNRYKMK_CD_58                       ,                                                  
          TTS.SNRYKMK_CD_59                       ,                                                  
          TTS.SNRYKMK_CD_60                       ,                                                  
          TTS.KENSAKOMOKU_BISEIBUTSU_FLG          ,                                                  
          TTS.KENSAKOMOKU_KESSEI_FLG              ,                                                  
          TTS.KENSAKOMOKU_KETSUEKI_FLG            ,                                                  
          TTS.KENSAKOMOKU_BYORI_FLG               ,                                                  
          TTS.KENSAKOMOKU_KISEICHU_FLG            ,                                                  
          TTS.KENSAKOMOKU_SEIKA_FLG               ,                                                  
          TTS.KENSAKOMOKU_RI_FLG                  ,                                                  
          TTS.UPD_EIGY_YMD ,                                                                                                           
          TZDS.REC_ID                              AS  zREC_ID                              ,                                                  
          TZDS.SHI_CD                              AS  zSHI_CD                              ,                                                  
          TZDS.DEL_FLG                             AS  zDEL_FLG                             ,                                                  
          TZDS.DEL_YOTEI_RIYU_CD                   AS  zDEL_YOTEI_RIYU_CD                   ,                                                  
          TZDS.CHOFUKU_AITSK_REC_ID                AS  zCHOFUKU_AITSK_REC_ID                ,                                                  
          TZDS.CHOFUKU_AITSK_SHI_CD                AS  zCHOFUKU_AITSK_SHI_CD                ,                                                  
          TZDS.KYUIN_FLG               AS  zKYUIN_FLG                           ,                                                  
          TZDS.KYUIN_S_YM              AS  zKYUIN_S_YM                          ,                                                  
          TZDS.KAIGYO_YOTEI_FLG       AS  zKAIGYO_YOTEI_FLG                    ,                                                  
          TZDS.KAIGYO_YOTEI_YM        AS  zKAIGYO_YOTEI_YM                     ,                                                  
          TZDS.KANREN_DAIGAKU_OYA_REC_ID           AS  zKANREN_DAIGAKU_OYA_REC_ID           ,                                                  
          TZDS.KANREN_DAIGAKU_OYA_SHI_CD           AS  zKANREN_DAIGAKU_OYA_SHI_CD           ,                                                  
          TZDS.SEISHIKI_SHI_NM                     AS  zSEISHIKI_SHI_NM                     ,                                                  
          TZDS.SEISHIKI_SHI_NM30                   AS  zSEISHIKI_SHI_NM30                   ,                                                  
          TZDS.SEISHIKI_SHI_NM_KANA                AS  zSEISHIKI_SHI_NM_KANA                ,                                                  
          TZDS.SEISHIKI_SHI_NM_KANA40              AS  zSEISHIKI_SHI_NM_KANA40              ,                                                  
          TZDS.SHI_RN                              AS  zSHI_RN                              ,                                                  
          TZDS.SHI_RN_KANA                         AS  zSHI_RN_KANA                         ,                                                  
          TZDS.KEN_CD                              AS  zKEN_CD                              ,                                                  
          TZDS.SHIKU_CD                            AS  zSHIKU_CD                            ,                                                  
          TZDS.OAZA_CD                             AS  zOAZA_CD                             ,                                                  
          TZDS.AZA_CD                              AS  zAZA_CD                              ,                                                  
          TZDS.ZIP                                 AS  zZIP                                 ,                                                  
          TZDS.JUSHO_KANJI_RENKETSU                AS  zJUSHO_KANJI_RENKETSU                ,                                                  
          TZDS.JUSHO_KANA_RENKETSU                 AS  zJUSHO_KANA_RENKETSU                 ,                                                  
          TZDS.KEN_NM_KANJI_MOJI_SU                AS  zKEN_NM_KANJI_MOJI_SU                ,                                                  
          TZDS.SHIKU_NM_KANJI_MOJI_SU              AS  zSHIKU_NM_KANJI_MOJI_SU              ,                                                  
          TZDS.OAZA_NM_KANJI_MOJI_SU               AS  zOAZA_NM_KANJI_MOJI_SU               ,                                                  
          TZDS.AZA_NM_KANJI_MOJI_SU                AS  zAZA_NM_KANJI_MOJI_SU                ,                                                  
          TZDS.KEN_NM_KANA_MOJI_SU                 AS  zKEN_NM_KANA_MOJI_SU                 ,                                                  
          TZDS.SHIKU_NM_KANA_MOJI_SU               AS  zSHIKU_NM_KANA_MOJI_SU               ,                                                  
          TZDS.OAZA_NM_KANA_MOJI_SU                AS  zOAZA_NM_KANA_MOJI_SU                ,                                                  
          TZDS.AZA_NM_KANA_MOJI_SU                 AS  zAZA_NM_KANA_MOJI_SU                 ,                                                  
          TZDS.JUSHO_HYOJI_NO                      AS  zJUSHO_HYOJI_NO                      ,                                                  
          TZDS.JUSHOFUMEI_CD                       AS  zJUSHOFUMEI_CD                       ,                                                  
          TZDS.TEL                                 AS  zTEL                                 ,                                                  
          TZDS.KEIEITAI_CD                         AS  zKEIEITAI_CD                         ,                                                  
          TZDS.SHI_KBN_CD                          AS  zSHI_KBN_CD                          ,                                                  
          TZDS.IMUSHITSU_REC_ID                    AS  zIMUSHITSU_REC_ID                    ,                                                  
          TZDS.IMUSHITSU_SHI_CD                    AS  zIMUSHITSU_SHI_CD                    ,                                                  
          TZDS.SAISHINSA_KBN_CD                    AS  zSAISHINSA_KBN_CD                    ,                                                  
          TZDS.BYOTO_HEISA_KBN                     AS  zBYOTO_HEISA_KBN                     ,                                                  
          TZDS.TEL_NASHI_FLG                       AS  zTEL_NASHI_FLG                       ,                                                  
          TZDS.MIKAKUNIN_FLG                       AS  zMIKAKUNIN_FLG                       ,                                                  
          TZDS.DAIHYO_REC_ID                       AS  zDAIHYO_REC_ID                       ,                                                  
          TZDS.DAIHYO_KJN_CD                       AS  zDAIHYO_KJN_CD                       ,                                                  
          TZDK.KJN_NM                              AS  zKJN_NM                              ,                                                  
          TZDK.KJN_NM_KANA                         AS  zKJN_NM_KANA                         ,                                                  
          TO_CHAR(TZDS.SHI_BED_SU,''FM9999'')        AS  zSHI_BED_SU                          ,                                                  
          TZDS.BYOIN_SBT_CD                        AS  zBYOIN_SBT_CD                        ,                                                  
          TZDS.KYOKA_BED_SU_SONOTA                 AS  zKYOKA_BED_SU_SONOTA                 ,                                                  
          TZDS.KYOKA_BED_SU_SEISHIN                AS  zKYOKA_BED_SU_SEISHIN                ,                                                  
          TZDS.KYOKA_BED_SU_KEKKAKU                AS  zKYOKA_BED_SU_KEKKAKU                ,                                                  
          TZDS.KYOKA_BED_SU_KANSEN                 AS  zKYOKA_BED_SU_KANSEN                 ,                                                  
          TO_CHAR(TZDS.KYOKA_BED_SU_GOKEI,''FM9999'') AS  zKYOKA_BED_SU_GOKEI                  ,                                                  
          TZDS.KYOKA_BED_SU_IPPAN                  AS  zKYOKA_BED_SU_IPPAN                  ,                                                  
          TZDS.KYOKA_BED_SU_RYOYO                  AS  zKYOKA_BED_SU_RYOYO                  ,                                                  
          TZDS.BED_SU_KKNN_EIGY_YMD                AS  zBED_SU_KKNN_EIGY_YMD                ,                                                  
          TZDS.SNRYKMK_CD_01                       AS  zSNRYKMK_CD_01                       ,                                                  
          TZDS.SNRYKMK_CD_02                       AS  zSNRYKMK_CD_02                       ,                                                  
          TZDS.SNRYKMK_CD_03                       AS  zSNRYKMK_CD_03                       ,                                                  
          TZDS.SNRYKMK_CD_04                       AS  zSNRYKMK_CD_04                       ,                                                  
          TZDS.SNRYKMK_CD_05                       AS  zSNRYKMK_CD_05                       ,                                                  
          TZDS.SNRYKMK_CD_06                       AS  zSNRYKMK_CD_06                       ,                                                  
          TZDS.SNRYKMK_CD_07                       AS  zSNRYKMK_CD_07                       ,                                                  
          TZDS.SNRYKMK_CD_08                       AS  zSNRYKMK_CD_08                       ,                                                  
          TZDS.SNRYKMK_CD_09                       AS  zSNRYKMK_CD_09                       ,                                                  
          TZDS.SNRYKMK_CD_10                       AS  zSNRYKMK_CD_10                       ,                                                  
          TZDS.SNRYKMK_CD_11                       AS  zSNRYKMK_CD_11                       ,                                                  
          TZDS.SNRYKMK_CD_12                       AS  zSNRYKMK_CD_12                       ,                                                  
          TZDS.SNRYKMK_CD_13                       AS  zSNRYKMK_CD_13                       ,                                                  
          TZDS.SNRYKMK_CD_14                       AS  zSNRYKMK_CD_14                       ,                                                  
          TZDS.SNRYKMK_CD_15                       AS  zSNRYKMK_CD_15                       ,                                                  
          TZDS.SNRYKMK_CD_16                       AS  zSNRYKMK_CD_16                       ,                                                  
          TZDS.SNRYKMK_CD_17                       AS  zSNRYKMK_CD_17                       ,                                                  
          TZDS.SNRYKMK_CD_18                       AS  zSNRYKMK_CD_18                       ,                                                  
          TZDS.SNRYKMK_CD_19                       AS  zSNRYKMK_CD_19                       ,                                                  
          TZDS.SNRYKMK_CD_20                       AS  zSNRYKMK_CD_20                       ,                                                  
          TZDS.SNRYKMK_CD_21                       AS  zSNRYKMK_CD_21                       ,                                                  
          TZDS.SNRYKMK_CD_22                       AS  zSNRYKMK_CD_22                       ,                                                  
          TZDS.SNRYKMK_CD_23                       AS  zSNRYKMK_CD_23                       ,                                                  
          TZDS.SNRYKMK_CD_24                       AS  zSNRYKMK_CD_24                       ,                                                  
          TZDS.SNRYKMK_CD_25                       AS  zSNRYKMK_CD_25                       ,                                                  
          TZDS.SNRYKMK_CD_26                       AS  zSNRYKMK_CD_26                       ,                                                  
          TZDS.SNRYKMK_CD_27                       AS  zSNRYKMK_CD_27                       ,                                                  
          TZDS.SNRYKMK_CD_28                       AS  zSNRYKMK_CD_28                       ,                                                  
          TZDS.SNRYKMK_CD_29                       AS  zSNRYKMK_CD_29                       ,                                                  
          TZDS.SNRYKMK_CD_30                       AS  zSNRYKMK_CD_30                       ,                                                  
          TZDS.SNRYKMK_CD_31                       AS  zSNRYKMK_CD_31                       ,                                                  
          TZDS.SNRYKMK_CD_32                       AS  zSNRYKMK_CD_32                       ,                                                  
          TZDS.SNRYKMK_CD_33                       AS  zSNRYKMK_CD_33                       ,                                                  
          TZDS.SNRYKMK_CD_34                       AS  zSNRYKMK_CD_34                       ,                                                  
          TZDS.SNRYKMK_CD_35                       AS  zSNRYKMK_CD_35                       ,                                                  
          TZDS.SNRYKMK_CD_36                       AS  zSNRYKMK_CD_36                       ,                                                  
          TZDS.SNRYKMK_CD_37                       AS  zSNRYKMK_CD_37                       ,                                                  
          TZDS.SNRYKMK_CD_38                       AS  zSNRYKMK_CD_38                       ,                                                  
          TZDS.SNRYKMK_CD_39                       AS  zSNRYKMK_CD_39                       ,                                                  
          TZDS.SNRYKMK_CD_40                       AS  zSNRYKMK_CD_40                       ,                                                  
          TZDS.SNRYKMK_CD_41                       AS  zSNRYKMK_CD_41                       ,                                                  
          TZDS.SNRYKMK_CD_42                       AS  zSNRYKMK_CD_42                       ,                                                  
          TZDS.SNRYKMK_CD_43                       AS  zSNRYKMK_CD_43                       ,                                                  
          TZDS.SNRYKMK_CD_44                       AS  zSNRYKMK_CD_44                       ,                                                  
          TZDS.SNRYKMK_CD_45                       AS  zSNRYKMK_CD_45                       ,                                                  
          TZDS.SNRYKMK_CD_46                       AS  zSNRYKMK_CD_46                       ,                                                  
          TZDS.SNRYKMK_CD_47                       AS  zSNRYKMK_CD_47                       ,                                                  
          TZDS.SNRYKMK_CD_48                       AS  zSNRYKMK_CD_48                       ,                                                  
          TZDS.SNRYKMK_CD_49                       AS  zSNRYKMK_CD_49                       ,                                                  
          TZDS.SNRYKMK_CD_50                       AS  zSNRYKMK_CD_50                       ,                                                  
          TZDS.SNRYKMK_CD_51                       AS  zSNRYKMK_CD_51                       ,                                                  
          TZDS.SNRYKMK_CD_52                       AS  zSNRYKMK_CD_52                       ,                                                  
          TZDS.SNRYKMK_CD_53                       AS  zSNRYKMK_CD_53                       ,                                  								
          TZDS.SNRYKMK_CD_54                       AS  zSNRYKMK_CD_54                       ,																									
          TZDS.SNRYKMK_CD_55                       AS  zSNRYKMK_CD_55                       ,																									
          TZDS.SNRYKMK_CD_56                       AS  zSNRYKMK_CD_56                       ,																									
          TZDS.SNRYKMK_CD_57                       AS  zSNRYKMK_CD_57                       ,																									
          TZDS.SNRYKMK_CD_58                       AS  zSNRYKMK_CD_58                       ,																									
          TZDS.SNRYKMK_CD_59                       AS  zSNRYKMK_CD_59                       ,																									
          TZDS.SNRYKMK_CD_60                       AS  zSNRYKMK_CD_60                       ,																									
          TZDS.KENSAKOMOKU_BISEIBUTSU_FLG          AS  zKENSAKOMOKU_BISEIBUTSU_FLG          ,																									
          TZDS.KENSAKOMOKU_KESSEI_FLG              AS  zKENSAKOMOKU_KESSEI_FLG              ,																									
          TZDS.KENSAKOMOKU_KETSUEKI_FLG            AS  zKENSAKOMOKU_KETSUEKI_FLG            ,																									
          TZDS.KENSAKOMOKU_BYORI_FLG               AS  zKENSAKOMOKU_BYORI_FLG               ,																									
          TZDS.KENSAKOMOKU_KISEICHU_FLG            AS  zKENSAKOMOKU_KISEICHU_FLG            ,																									
          TZDS.KENSAKOMOKU_SEIKA_FLG               AS  zKENSAKOMOKU_SEIKA_FLG               ,																									
          TZDS.KENSAKOMOKU_RI_FLG                  AS  zKENSAKOMOKU_RI_FLG                  ,																									
          TZDS.UPD_EIGY_YMD                        AS  zUPD_EIGY_YMD	
        FROM TT_TIKY_SHI TTS							
        LEFT OUTER JOIN TT_TIKY_KJN TTK											
        ON  TTS.DAIHYO_REC_ID = TTK.REC_ID											
        AND TTS.DAIHYO_KJN_CD = TTK.KJN_CD											
        AND TTK.DEL_FLG IS NULL											
        LEFT OUTER JOIN TT_Z_D_SHI TZDS											
        ON  TTS.REC_ID = TZDS.REC_ID											
        AND TTS.SHI_CD = TZDS.SHI_CD											
        LEFT OUTER JOIN TT_Z_D_KJN TZDK											
        ON  TZDS.DAIHYO_REC_ID = TZDK.REC_ID											
        AND TZDS.DAIHYO_KJN_CD = TZDK.KJN_CD	
        WHERE TTS.REC_ID = ''00''																	
          AND TTS.UPD_EIGY_YMD >= NVL('''||iShimeFrom||''', ''19700101'')																
          AND TTS.UPD_EIGY_YMD <= '''||iShimeTo||'''' ;
          ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);
          -- �擾�����f��DB�f�[�^���������J��Ԃ�
          OPEN dayCSR ;
          LOOP
            FETCH dayCSR INTO dayRow;     
            EXIT WHEN dayCSR%NOTFOUND; 
            vSPECIAL_FLG_1 :=0;
            oROW_COUNT:=oROW_COUNT+1;
            --�O���r���R�[�h�̎{�݃R�[�h�ƃ��R�[�hID��NULL�ł͂Ȃ����A
            IF dayRow.zREC_ID IS NOT  NULL AND dayRow.zSHI_CD IS NOT  NULL THEN
              --�񋟗p���R�[�h�̍폜�t���O = "1"�̎��A 
              IF dayRow.DEL_FLG = '1' THEN
                vMODKBN := ULT_COMMON.MOD_KBN_DEL;
              ELSE
                --�񋟗p���R�[�h�Ǝ擾�����O���r���R�[�h���r
               
                IF '1'||dayRow.MIKAKUNIN_FLG = '1'||dayRow.zMIKAKUNIN_FLG     
                  AND '1'||dayRow.DEL_YOTEI_RIYU_CD = '1'||dayRow.zDEL_YOTEI_RIYU_CD
                  AND '1'||dayRow.CHOFUKU_AITSK_REC_ID = '1'||dayRow.zCHOFUKU_AITSK_REC_ID
                  AND '1'||dayRow.CHOFUKU_AITSK_SHI_CD = '1'||dayRow.zCHOFUKU_AITSK_SHI_CD
                  AND '1'||dayRow.SEISHIKI_SHI_NM = '1'||dayRow.zSEISHIKI_SHI_NM
                  AND '1'||dayRow.SEISHIKI_SHI_NM_KANA = '1'||dayRow.zSEISHIKI_SHI_NM_KANA
                  AND '1'||dayRow.SHI_RN = '1'||dayRow.zSHI_RN
                  AND '1'||dayRow.SHI_RN_KANA = '1'||dayRow.zSHI_RN_KANA
                  AND '1'||dayRow.JUSHOFUMEI_CD = '1'||dayRow.zJUSHOFUMEI_CD
                  AND '1'||dayRow.KEN_CD = '1'||dayRow.zKEN_CD
                  AND '1'||dayRow.SHIKU_CD = '1'||dayRow.zSHIKU_CD
                  AND '1'||dayRow.OAZA_CD = '1'||dayRow.zOAZA_CD
                  AND '1'||dayRow.AZA_CD = '1'||dayRow.zAZA_CD
                  AND '1'||dayRow.ZIP = '1'||dayRow.zZIP
                  AND '1'||dayRow.JUSHO_KANJI_RENKETSU = '1'||dayRow.zJUSHO_KANJI_RENKETSU
                  AND '1'||dayRow.JUSHO_KANA_RENKETSU = '1'||dayRow.zJUSHO_KANA_RENKETSU
                  AND '1'||dayRow.JUSHO_HYOJI_NO = '1'||dayRow.zJUSHO_HYOJI_NO
                  AND '1'||dayRow.KEN_NM_KANJI_MOJI_SU = '1'||dayRow.zKEN_NM_KANJI_MOJI_SU
                  AND '1'||dayRow.SHIKU_NM_KANJI_MOJI_SU = '1'||dayRow.zSHIKU_NM_KANJI_MOJI_SU
                  AND '1'||dayRow.OAZA_NM_KANJI_MOJI_SU = '1'||dayRow.zOAZA_NM_KANJI_MOJI_SU
                  AND '1'||dayRow.AZA_NM_KANJI_MOJI_SU = '1'||dayRow.zAZA_NM_KANJI_MOJI_SU
                  AND '1'||dayRow.KEN_NM_KANA_MOJI_SU = '1'||dayRow.zKEN_NM_KANA_MOJI_SU
                  AND '1'||dayRow.SHIKU_NM_KANA_MOJI_SU = '1'||dayRow.zSHIKU_NM_KANA_MOJI_SU
                  AND '1'||dayRow.OAZA_NM_KANA_MOJI_SU = '1'||dayRow.zOAZA_NM_KANA_MOJI_SU
                  AND '1'||dayRow.AZA_NM_KANA_MOJI_SU = '1'||dayRow.zAZA_NM_KANA_MOJI_SU
                  AND '1'||dayRow.TEL_NASHI_FLG = '1'||dayRow.zTEL_NASHI_FLG
                  AND '1'||dayRow.TEL = '1'||dayRow.zTEL
                  AND '1'||dayRow.KEIEITAI_CD = '1'||dayRow.zKEIEITAI_CD
                  AND '1'||dayRow.SHI_KBN_CD = '1'||dayRow.zSHI_KBN_CD
                  AND '1'||dayRow.DAIHYO_REC_ID = '1'||dayRow.zDAIHYO_REC_ID
                  AND '1'||dayRow.DAIHYO_KJN_CD = '1'||dayRow.zDAIHYO_KJN_CD
                  AND '1'||dayRow.KJN_NM = '1'||dayRow.zKJN_NM
                  AND '1'||dayRow.KJN_NM_KANA = '1'||dayRow.zKJN_NM_KANA
                  AND '1'||dayRow.KAIGYO_YOTEI_FLG = '1'||dayRow.zKAIGYO_YOTEI_FLG
                  AND '1'||dayRow.KAIGYO_YOTEI_YM = '1'||dayRow.zKAIGYO_YOTEI_YM
                  AND '1'||dayRow.KYUIN_FLG = '1'||dayRow.zKYUIN_FLG
                  AND '1'||dayRow.KYUIN_S_YM = '1'||dayRow.zKYUIN_S_YM
                  AND '1'||dayRow.SNRYKMK_CD_01 = '1'||dayRow.zSNRYKMK_CD_01
                  AND '1'||dayRow.SNRYKMK_CD_02 = '1'||dayRow.zSNRYKMK_CD_02
                  AND '1'||dayRow.SNRYKMK_CD_03 = '1'||dayRow.zSNRYKMK_CD_03
                  AND '1'||dayRow.SNRYKMK_CD_04 = '1'||dayRow.zSNRYKMK_CD_04
                  AND '1'||dayRow.SNRYKMK_CD_05 = '1'||dayRow.zSNRYKMK_CD_05
                  AND '1'||dayRow.SNRYKMK_CD_06 = '1'||dayRow.zSNRYKMK_CD_06
                  AND '1'||dayRow.SNRYKMK_CD_07 = '1'||dayRow.zSNRYKMK_CD_07
                  AND '1'||dayRow.SNRYKMK_CD_08 = '1'||dayRow.zSNRYKMK_CD_08
                  AND '1'||dayRow.SNRYKMK_CD_09 = '1'||dayRow.zSNRYKMK_CD_09
                  AND '1'||dayRow.SNRYKMK_CD_10 = '1'||dayRow.zSNRYKMK_CD_10
                  AND '1'||dayRow.SNRYKMK_CD_11 = '1'||dayRow.zSNRYKMK_CD_11
                  AND '1'||dayRow.SNRYKMK_CD_12 = '1'||dayRow.zSNRYKMK_CD_12
                  AND '1'||dayRow.SNRYKMK_CD_13 = '1'||dayRow.zSNRYKMK_CD_13
                  AND '1'||dayRow.SNRYKMK_CD_14 = '1'||dayRow.zSNRYKMK_CD_14
                  AND '1'||dayRow.SNRYKMK_CD_15 = '1'||dayRow.zSNRYKMK_CD_15
                  AND '1'||dayRow.SNRYKMK_CD_16 = '1'||dayRow.zSNRYKMK_CD_16
                  AND '1'||dayRow.SNRYKMK_CD_17 = '1'||dayRow.zSNRYKMK_CD_17
                  AND '1'||dayRow.SNRYKMK_CD_18 = '1'||dayRow.zSNRYKMK_CD_18
                  AND '1'||dayRow.SNRYKMK_CD_19 = '1'||dayRow.zSNRYKMK_CD_19
                  AND '1'||dayRow.SNRYKMK_CD_20 = '1'||dayRow.zSNRYKMK_CD_20
                  AND '1'||dayRow.SNRYKMK_CD_21 = '1'||dayRow.zSNRYKMK_CD_21
                  AND '1'||dayRow.SNRYKMK_CD_22 = '1'||dayRow.zSNRYKMK_CD_22
                  AND '1'||dayRow.SNRYKMK_CD_23 = '1'||dayRow.zSNRYKMK_CD_23
                  AND '1'||dayRow.SNRYKMK_CD_24 = '1'||dayRow.zSNRYKMK_CD_24
                  AND '1'||dayRow.SNRYKMK_CD_25 = '1'||dayRow.zSNRYKMK_CD_25
                  AND '1'||dayRow.SNRYKMK_CD_26 = '1'||dayRow.zSNRYKMK_CD_26
                  AND '1'||dayRow.SNRYKMK_CD_27 = '1'||dayRow.zSNRYKMK_CD_27
                  AND '1'||dayRow.SNRYKMK_CD_28 = '1'||dayRow.zSNRYKMK_CD_28
                  AND '1'||dayRow.SNRYKMK_CD_29 = '1'||dayRow.zSNRYKMK_CD_29
                  AND '1'||dayRow.SNRYKMK_CD_30 = '1'||dayRow.zSNRYKMK_CD_30
                  AND '1'||dayRow.SNRYKMK_CD_31 = '1'||dayRow.zSNRYKMK_CD_31
                  AND '1'||dayRow.SNRYKMK_CD_32 = '1'||dayRow.zSNRYKMK_CD_32
                  AND '1'||dayRow.SNRYKMK_CD_33 = '1'||dayRow.zSNRYKMK_CD_33
                  AND '1'||dayRow.SNRYKMK_CD_34 = '1'||dayRow.zSNRYKMK_CD_34
                  AND '1'||dayRow.SNRYKMK_CD_35 = '1'||dayRow.zSNRYKMK_CD_35
                  AND '1'||dayRow.SNRYKMK_CD_36 = '1'||dayRow.zSNRYKMK_CD_36
                  AND '1'||dayRow.SNRYKMK_CD_37 = '1'||dayRow.zSNRYKMK_CD_37
                  AND '1'||dayRow.SNRYKMK_CD_38 = '1'||dayRow.zSNRYKMK_CD_38
                  AND '1'||dayRow.SNRYKMK_CD_39 = '1'||dayRow.zSNRYKMK_CD_39
                  AND '1'||dayRow.SNRYKMK_CD_40 = '1'||dayRow.zSNRYKMK_CD_40
                  AND '1'||dayRow.SNRYKMK_CD_41 = '1'||dayRow.zSNRYKMK_CD_41
                  AND '1'||dayRow.SNRYKMK_CD_42 = '1'||dayRow.zSNRYKMK_CD_42
                  AND '1'||dayRow.SNRYKMK_CD_43 = '1'||dayRow.zSNRYKMK_CD_43
                  AND '1'||dayRow.SNRYKMK_CD_44 = '1'||dayRow.zSNRYKMK_CD_44
                  AND '1'||dayRow.SNRYKMK_CD_45 = '1'||dayRow.zSNRYKMK_CD_45
                  AND '1'||dayRow.SNRYKMK_CD_46 = '1'||dayRow.zSNRYKMK_CD_46
                  AND '1'||dayRow.SNRYKMK_CD_47 = '1'||dayRow.zSNRYKMK_CD_47
                  AND '1'||dayRow.SNRYKMK_CD_48 = '1'||dayRow.zSNRYKMK_CD_48
                  AND '1'||dayRow.SNRYKMK_CD_49 = '1'||dayRow.zSNRYKMK_CD_49
                  AND '1'||dayRow.SNRYKMK_CD_50 = '1'||dayRow.zSNRYKMK_CD_50
                  AND '1'||dayRow.SNRYKMK_CD_51 = '1'||dayRow.zSNRYKMK_CD_51
                  AND '1'||dayRow.SNRYKMK_CD_52 = '1'||dayRow.zSNRYKMK_CD_52
                  AND '1'||dayRow.SNRYKMK_CD_53 = '1'||dayRow.zSNRYKMK_CD_53
                  AND '1'||dayRow.SNRYKMK_CD_54 = '1'||dayRow.zSNRYKMK_CD_54
                  AND '1'||dayRow.SNRYKMK_CD_55 = '1'||dayRow.zSNRYKMK_CD_55
                  AND '1'||dayRow.SNRYKMK_CD_56 = '1'||dayRow.zSNRYKMK_CD_56
                  AND '1'||dayRow.SNRYKMK_CD_57 = '1'||dayRow.zSNRYKMK_CD_57
                  AND '1'||dayRow.SNRYKMK_CD_58 = '1'||dayRow.zSNRYKMK_CD_58
                  AND '1'||dayRow.SNRYKMK_CD_59 = '1'||dayRow.zSNRYKMK_CD_59
                  AND '1'||dayRow.SNRYKMK_CD_60 = '1'||dayRow.zSNRYKMK_CD_60
                  AND '1'||dayRow.BYOIN_SBT_CD = '1'||dayRow.zBYOIN_SBT_CD
                  AND '1'||dayRow.SAISHINSA_KBN_CD = '1'||dayRow.zSAISHINSA_KBN_CD
                  AND '1'||dayRow.KANREN_DAIGAKU_OYA_REC_ID = '1'||dayRow.zKANREN_DAIGAKU_OYA_REC_ID
                  AND '1'||dayRow.KANREN_DAIGAKU_OYA_SHI_CD = '1'||dayRow.zKANREN_DAIGAKU_OYA_SHI_CD
                  AND '1'||dayRow.BYOTO_HEISA_KBN = '1'||dayRow.zBYOTO_HEISA_KBN
                  AND '1'||dayRow.SHI_BED_SU = '1'||dayRow.zSHI_BED_SU
                  AND '1'||dayRow.BED_SU_KKNN_EIGY_YMD = '1'||dayRow.zBED_SU_KKNN_EIGY_YMD
                  AND '1'||dayRow.KYOKA_BED_SU_GOKEI = '1'||dayRow.zKYOKA_BED_SU_GOKEI
                  AND '1'||dayRow.KYOKA_BED_SU_SEISHIN = '1'||dayRow.zKYOKA_BED_SU_SEISHIN
                  AND '1'||dayRow.KYOKA_BED_SU_KEKKAKU = '1'||dayRow.zKYOKA_BED_SU_KEKKAKU
                  AND '1'||dayRow.KYOKA_BED_SU_KANSEN = '1'||dayRow.zKYOKA_BED_SU_KANSEN
                  AND '1'||dayRow.KYOKA_BED_SU_SONOTA = '1'||dayRow.zKYOKA_BED_SU_SONOTA
                  AND '1'||dayRow.KYOKA_BED_SU_IPPAN = '1'||dayRow.zKYOKA_BED_SU_IPPAN
                  AND '1'||dayRow.KYOKA_BED_SU_RYOYO = '1'||dayRow.zKYOKA_BED_SU_RYOYO
                  AND '1'||dayRow.KENSAKOMOKU_BISEIBUTSU_FLG = '1'||dayRow.zKENSAKOMOKU_BISEIBUTSU_FLG
                  AND '1'||dayRow.KENSAKOMOKU_KESSEI_FLG = '1'||dayRow.zKENSAKOMOKU_KESSEI_FLG
                  AND '1'||dayRow.KENSAKOMOKU_KETSUEKI_FLG = '1'||dayRow.zKENSAKOMOKU_KETSUEKI_FLG
                  AND '1'||dayRow.KENSAKOMOKU_BYORI_FLG = '1'||dayRow.zKENSAKOMOKU_BYORI_FLG
                  AND '1'||dayRow.KENSAKOMOKU_KISEICHU_FLG = '1'||dayRow.zKENSAKOMOKU_KISEICHU_FLG
                  AND '1'||dayRow.KENSAKOMOKU_SEIKA_FLG = '1'||dayRow.zKENSAKOMOKU_SEIKA_FLG
                  AND '1'||dayRow.KENSAKOMOKU_RI_FLG = '1'||dayRow.zKENSAKOMOKU_RI_FLG
                  AND '1'||dayRow.IMUSHITSU_REC_ID = '1'||dayRow.zIMUSHITSU_REC_ID
                  AND '1'||dayRow.IMUSHITSU_SHI_CD = '1'||dayRow.zIMUSHITSU_SHI_CD
                THEN
                  vMODKBN := ULT_COMMON.MOD_KBN_NO;
                ELSE
                  vMODKBN := ULT_COMMON.MOD_KBN_YES;
                END IF;
                
              END IF;
            
            ELSIF dayRow.zREC_ID IS NULL AND dayRow.zSHI_CD IS NULL THEN
              --�񋟗p���R�[�h�Ə�L�Ŏ擾�����O���r���R�[�h�͓������̂̃A�C�e�����r���Ă����ꂩ���s��v�� �A
              vMODKBN := ULT_COMMON.MOD_KBN_ADD;
            END IF;            
            
            IF vMODKBN != ULT_COMMON.MOD_KBN_NO THEN
              --�C���敪���h�@�h�i���p�X�y�[�X�j�ł͂Ȃ��� 
              
              IF vMODKBN = ULT_COMMON.MOD_KBN_DEL THEN 
                -- �C���敪��"C"�̏ꍇ
                 INSERT INTO TD_ND_DCF_SHI(LAYOUT_KBN,SHIREC_ID,SHI_CD,MOD_KBN,MENTE_YMD,TENSO_YMD,TRK_OPE_CD,TRK_DATE,TRK_PGM_ID,UPD_OPE_CD,UPD_DATE,UPD_PGM_ID)
                 VALUES('101',dayRow.REC_ID,dayRow.SHI_CD,vMODKBN,dayRow.UPD_EIGY_YMD,iTensoYMD,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);
                 
                 EXECUTE_SQL := 'INSERT INTO TD_ND_DCF_SHI(LAYOUT_KBN,SHIREC_ID,SHI_CD,MOD_KBN,MENTE_YMD,TENSO_YMD,'
                 ||'TRK_OPE_CD,TRK_DATE,TRK_PGM_ID,UPD_OPE_CD,UPD_DATE,UPD_PGM_ID) VALUES(''101'','''||dayRow.REC_ID||''','''||dayRow.SHI_CD||''','''||vMODKBN
                 ||''','''||dayRow.UPD_EIGY_YMD||''','''||iTensoYMD||''','''||iOPE_CD||''','''||iDATE||''','''||iPGM_ID||''','''||iOPE_CD||''','''||iDATE
                 ||''','''||iPGM_ID||''')';
                 ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);
              ELSE
                -- �C���敪��"B"�̏ꍇ
                 IF vMODKBN = ULT_COMMON.MOD_KBN_YES THEN
                   
                    --�폜�\�藝�R�R�[�h�A�d�������R�[�h�̂����ꂩ�ɕύX���������ꍇ�A
                    IF ('1'||dayRow.DEL_YOTEI_RIYU_CD != '1'||dayRow.zDEL_YOTEI_RIYU_CD)
                      OR ('1'||dayRow.CHOFUKU_AITSK_REC_ID != '1'||dayRow.zCHOFUKU_AITSK_REC_ID)
                      OR ('1'||dayRow.CHOFUKU_AITSK_SHI_CD != '1'||dayRow.zCHOFUKU_AITSK_SHI_CD)
                    THEN
                      vSPECIAL_FLG_1 := '1';
                    END IF;
                    
                    -- ��W������(�����l�Ȃ�)
                    IF '1'||dayRow.SEISHIKI_SHI_NM = '1'||dayRow.zSEISHIKI_SHI_NM THEN
                      dayRow.SEISHIKI_SHI_NM := NULL;
                    END IF;
                    IF '1'||dayRow.SEISHIKI_SHI_NM_KANA = '1'||dayRow.zSEISHIKI_SHI_NM_KANA THEN
                      dayRow.SEISHIKI_SHI_NM_KANA := NULL;
                    END IF;
                    IF '1'||dayRow.SHI_RN = '1'||dayRow.zSHI_RN THEN
                      dayRow.SHI_RN := NULL;
                    END IF;
                    IF '1'||dayRow.SHI_RN_KANA = '1'||dayRow.zSHI_RN_KANA THEN
                      dayRow.SHI_RN_KANA := NULL;
                    END IF;
                    IF '1'||dayRow.KEIEITAI_CD = '1'||dayRow.zKEIEITAI_CD THEN
                      dayRow.KEIEITAI_CD := NULL;
                    END IF;
                    IF '1'||dayRow.SHI_KBN_CD = '1'||dayRow.zSHI_KBN_CD THEN
                      dayRow.SHI_KBN_CD := NULL;
                    END IF;
                    IF '1'||dayRow.BYOIN_SBT_CD = '1'||dayRow.zBYOIN_SBT_CD THEN
                      dayRow.BYOIN_SBT_CD := NULL;
                    END IF;
                    IF '1'||dayRow.SAISHINSA_KBN_CD = '1'||dayRow.zSAISHINSA_KBN_CD THEN
                      dayRow.SAISHINSA_KBN_CD := NULL;
                    END IF;
                    
                    -- ��W������(�����l����)
                    IF '1'||dayRow.MIKAKUNIN_FLG = '1'||dayRow.zMIKAKUNIN_FLG THEN
                      dayRow.MIKAKUNIN_FLG := NULL;
                    ELSIF  dayRow.MIKAKUNIN_FLG IS NULL THEN
                      dayRow.MIKAKUNIN_FLG := ULT_COMMON.INSERT_HALF_DEFAULT;
                    END IF;
                    IF '1'||dayRow.DEL_YOTEI_RIYU_CD = '1'||dayRow.zDEL_YOTEI_RIYU_CD THEN
                      IF vSPECIAL_FLG_1 = '0' THEN
                        dayRow.DEL_YOTEI_RIYU_CD := NULL;
                      END IF;
                    ELSIF  dayRow.DEL_YOTEI_RIYU_CD IS NULL THEN
                      dayRow.DEL_YOTEI_RIYU_CD := ULT_COMMON.INSERT_HALF_DEFAULT;
                    END IF;
                    IF '1'||dayRow.JUSHOFUMEI_CD = '1'||dayRow.zJUSHOFUMEI_CD THEN
                      IF vSPECIAL_FLG_1 = '0' THEN
                         dayRow.JUSHOFUMEI_CD := NULL;
                      END IF;
                    ELSIF  dayRow.JUSHOFUMEI_CD IS NULL THEN
                      dayRow.JUSHOFUMEI_CD := ULT_COMMON.INSERT_HALF_DEFAULT;
                    END IF;
                    IF '1'||dayRow.TEL_NASHI_FLG = '1'||dayRow.zTEL_NASHI_FLG THEN
                      dayRow.TEL_NASHI_FLG := NULL;
                    ELSIF  dayRow.TEL_NASHI_FLG IS NULL THEN
                      dayRow.TEL_NASHI_FLG := ULT_COMMON.INSERT_HALF_DEFAULT;
                    END IF;
                    IF '1'||dayRow.TEL = '1'||dayRow.zTEL THEN
                      dayRow.TEL := NULL;
                    ELSIF  dayRow.TEL IS NULL THEN
                      dayRow.TEL := ULT_COMMON.INSERT_HALF_DEFAULT;
                    END IF;
                    IF '1'||dayRow.BYOTO_HEISA_KBN = '1'||dayRow.zBYOTO_HEISA_KBN THEN
                      dayRow.BYOTO_HEISA_KBN := NULL;
                    ELSIF  dayRow.BYOTO_HEISA_KBN IS NULL THEN
                      dayRow.BYOTO_HEISA_KBN := ULT_COMMON.INSERT_HALF_DEFAULT;
                    END IF;
                    IF '1'||dayRow.SHI_BED_SU = '1'||dayRow.zSHI_BED_SU THEN
                      dayRow.SHI_BED_SU := NULL;
                    ELSIF  dayRow.SHI_BED_SU IS NULL THEN
                      dayRow.SHI_BED_SU := ULT_COMMON.INSERT_HALF_DEFAULT;
                    END IF;
                    IF '1'||dayRow.BED_SU_KKNN_EIGY_YMD = '1'||dayRow.zBED_SU_KKNN_EIGY_YMD THEN
                      dayRow.BED_SU_KKNN_EIGY_YMD := NULL;
                    ELSIF  dayRow.BED_SU_KKNN_EIGY_YMD IS NULL THEN
                      dayRow.BED_SU_KKNN_EIGY_YMD := ULT_COMMON.INSERT_HALF_DEFAULT;
                    END IF;                    
                    
                    --�W������(�����l�Ȃ�)
                    IF '1'||dayRow.KEN_CD = '1'||dayRow.zKEN_CD
                      AND '1'||dayRow.SHIKU_CD = '1'||dayRow.zSHIKU_CD
                      AND '1'||dayRow.OAZA_CD = '1'||dayRow.zOAZA_CD
                      AND '1'||dayRow.AZA_CD = '1'||dayRow.zAZA_CD
                      AND '1'||dayRow.ZIP = '1'||dayRow.zZIP
                      AND '1'||dayRow.JUSHO_KANJI_RENKETSU = '1'||dayRow.zJUSHO_KANJI_RENKETSU
                      AND '1'||dayRow.JUSHO_KANA_RENKETSU = '1'||dayRow.zJUSHO_KANA_RENKETSU
                      AND '1'||dayRow.JUSHO_HYOJI_NO = '1'||dayRow.zJUSHO_HYOJI_NO
                      AND '1'||dayRow.KEN_NM_KANJI_MOJI_SU = '1'||dayRow.zKEN_NM_KANJI_MOJI_SU
                      AND '1'||dayRow.SHIKU_NM_KANJI_MOJI_SU = '1'||dayRow.zSHIKU_NM_KANJI_MOJI_SU
                      AND '1'||dayRow.OAZA_NM_KANJI_MOJI_SU = '1'||dayRow.zOAZA_NM_KANJI_MOJI_SU
                      AND '1'||dayRow.AZA_NM_KANJI_MOJI_SU = '1'||dayRow.zAZA_NM_KANJI_MOJI_SU
                      AND '1'||dayRow.KEN_NM_KANA_MOJI_SU = '1'||dayRow.zKEN_NM_KANA_MOJI_SU
                      AND '1'||dayRow.SHIKU_NM_KANA_MOJI_SU = '1'||dayRow.zSHIKU_NM_KANA_MOJI_SU
                      AND '1'||dayRow.OAZA_NM_KANA_MOJI_SU = '1'||dayRow.zOAZA_NM_KANA_MOJI_SU
                      AND '1'||dayRow.AZA_NM_KANA_MOJI_SU = '1'||dayRow.zAZA_NM_KANA_MOJI_SU
                    THEN
                      dayRow.KEN_CD := NULL;
                      dayRow.SHIKU_CD := NULL;
                      dayRow.OAZA_CD := NULL;
                      dayRow.AZA_CD := NULL;
                      dayRow.ZIP := NULL;
                      dayRow.JUSHO_KANJI_RENKETSU := NULL;
                      dayRow.JUSHO_KANA_RENKETSU := NULL;
                      dayRow.JUSHO_HYOJI_NO := NULL;
                      dayRow.KEN_NM_KANJI_MOJI_SU := NULL;
                      dayRow.SHIKU_NM_KANJI_MOJI_SU := NULL;
                      dayRow.OAZA_NM_KANJI_MOJI_SU := NULL;
                      dayRow.AZA_NM_KANJI_MOJI_SU := NULL;
                      dayRow.KEN_NM_KANA_MOJI_SU := NULL;
                      dayRow.SHIKU_NM_KANA_MOJI_SU := NULL;
                      dayRow.OAZA_NM_KANA_MOJI_SU := NULL;
                      dayRow.AZA_NM_KANA_MOJI_SU := NULL;
                    END IF;

                    --�W������(�����l����)
                    IF '1'||dayRow.CHOFUKU_AITSK_REC_ID = '1'||dayRow.zCHOFUKU_AITSK_REC_ID
                      AND '1'||dayRow.CHOFUKU_AITSK_SHI_CD = '1'||dayRow.zCHOFUKU_AITSK_SHI_CD
                    THEN
                      IF vSPECIAL_FLG_1 = '0' THEN
                         dayRow.CHOFUKU_AITSK_REC_ID := NULL;
                         dayRow.CHOFUKU_AITSK_SHI_CD := NULL;
                      END IF;
                    ELSIF dayRow.CHOFUKU_AITSK_REC_ID IS NULL
                      AND dayRow.CHOFUKU_AITSK_SHI_CD IS NULL
                    THEN
                      dayRow.CHOFUKU_AITSK_REC_ID := ULT_COMMON.INSERT_HALF_DEFAULT;
                    END IF;
                    IF '1'||dayRow.DAIHYO_REC_ID = '1'||dayRow.zDAIHYO_REC_ID
                      AND '1'||dayRow.DAIHYO_KJN_CD = '1'||dayRow.zDAIHYO_KJN_CD
                      AND '1'||dayRow.KJN_NM = '1'||dayRow.zKJN_NM
                      AND '1'||dayRow.KJN_NM_KANA = '1'||dayRow.zKJN_NM_KANA
                    THEN
                      dayRow.DAIHYO_REC_ID := NULL;
                      dayRow.DAIHYO_KJN_CD := NULL;
                      dayRow.KJN_NM := NULL;
                      dayRow.KJN_NM_KANA := NULL;
                    ELSE
                      IF dayRow.DAIHYO_REC_ID IS NULL AND dayRow.DAIHYO_KJN_CD IS NULL
                          AND dayRow.zDAIHYO_REC_ID IS NOT NULL AND  dayRow.zDAIHYO_KJN_CD IS NOT NULL
                        THEN
                          dayRow.DAIHYO_REC_ID := ULT_COMMON.INSERT_HALF_DEFAULT;
                        END IF;
                        IF dayRow.KJN_NM_KANA IS NULL AND dayRow.zKJN_NM_KANA IS NOT NULL THEN
                          dayRow.KJN_NM_KANA := ULT_COMMON.INSERT_HALF_DEFAULT;
                        END IF;
                        IF dayRow.KJN_NM IS NULL AND dayRow.zKJN_NM IS NOT NULL THEN
                          dayRow.KJN_NM := ULT_COMMON.INSERT_FULL_DEFAULT;
                        END IF; 
                    END IF;  
                    IF '1'||dayRow.KAIGYO_YOTEI_FLG = '1'||dayRow.zKAIGYO_YOTEI_FLG
                      AND '1'||dayRow.KAIGYO_YOTEI_YM = '1'||dayRow.zKAIGYO_YOTEI_YM
                    THEN
                      dayRow.KAIGYO_YOTEI_FLG := NULL;
                      dayRow.KAIGYO_YOTEI_YM := NULL;
                    ELSIF dayRow.KAIGYO_YOTEI_FLG IS NULL
                      AND dayRow.KAIGYO_YOTEI_YM IS NULL
                    THEN
                      dayRow.KAIGYO_YOTEI_FLG := ULT_COMMON.INSERT_HALF_DEFAULT;
                    END IF;
                    IF '1'||dayRow.KYUIN_FLG = '1'||dayRow.zKYUIN_FLG
                      AND '1'||dayRow.KYUIN_S_YM = '1'||dayRow.zKYUIN_S_YM
                    THEN
                      dayRow.KYUIN_FLG := NULL;
                      dayRow.KYUIN_S_YM := NULL;
                    ELSIF dayRow.KYUIN_FLG IS NULL
                      AND dayRow.KYUIN_S_YM IS NULL
                    THEN
                      dayRow.KYUIN_FLG := ULT_COMMON.INSERT_HALF_DEFAULT;
                    END IF;
                    IF '1'||dayRow.SNRYKMK_CD_01 = '1'||dayRow.zSNRYKMK_CD_01
                      AND '1'||dayRow.SNRYKMK_CD_02 = '1'||dayRow.zSNRYKMK_CD_02
                      AND '1'||dayRow.SNRYKMK_CD_03 = '1'||dayRow.zSNRYKMK_CD_03
                      AND '1'||dayRow.SNRYKMK_CD_04 = '1'||dayRow.zSNRYKMK_CD_04
                      AND '1'||dayRow.SNRYKMK_CD_05 = '1'||dayRow.zSNRYKMK_CD_05
                      AND '1'||dayRow.SNRYKMK_CD_06 = '1'||dayRow.zSNRYKMK_CD_06
                      AND '1'||dayRow.SNRYKMK_CD_07 = '1'||dayRow.zSNRYKMK_CD_07
                      AND '1'||dayRow.SNRYKMK_CD_08 = '1'||dayRow.zSNRYKMK_CD_08
                      AND '1'||dayRow.SNRYKMK_CD_09 = '1'||dayRow.zSNRYKMK_CD_09
                      AND '1'||dayRow.SNRYKMK_CD_10 = '1'||dayRow.zSNRYKMK_CD_10
                      AND '1'||dayRow.SNRYKMK_CD_11 = '1'||dayRow.zSNRYKMK_CD_11
                      AND '1'||dayRow.SNRYKMK_CD_12 = '1'||dayRow.zSNRYKMK_CD_12
                      AND '1'||dayRow.SNRYKMK_CD_13 = '1'||dayRow.zSNRYKMK_CD_13
                      AND '1'||dayRow.SNRYKMK_CD_14 = '1'||dayRow.zSNRYKMK_CD_14
                      AND '1'||dayRow.SNRYKMK_CD_15 = '1'||dayRow.zSNRYKMK_CD_15
                      AND '1'||dayRow.SNRYKMK_CD_16 = '1'||dayRow.zSNRYKMK_CD_16
                      AND '1'||dayRow.SNRYKMK_CD_17 = '1'||dayRow.zSNRYKMK_CD_17
                      AND '1'||dayRow.SNRYKMK_CD_18 = '1'||dayRow.zSNRYKMK_CD_18
                      AND '1'||dayRow.SNRYKMK_CD_19 = '1'||dayRow.zSNRYKMK_CD_19
                      AND '1'||dayRow.SNRYKMK_CD_20 = '1'||dayRow.zSNRYKMK_CD_20
                      AND '1'||dayRow.SNRYKMK_CD_21 = '1'||dayRow.zSNRYKMK_CD_21
                      AND '1'||dayRow.SNRYKMK_CD_22 = '1'||dayRow.zSNRYKMK_CD_22
                      AND '1'||dayRow.SNRYKMK_CD_23 = '1'||dayRow.zSNRYKMK_CD_23
                      AND '1'||dayRow.SNRYKMK_CD_24 = '1'||dayRow.zSNRYKMK_CD_24
                      AND '1'||dayRow.SNRYKMK_CD_25 = '1'||dayRow.zSNRYKMK_CD_25
                      AND '1'||dayRow.SNRYKMK_CD_26 = '1'||dayRow.zSNRYKMK_CD_26
                      AND '1'||dayRow.SNRYKMK_CD_27 = '1'||dayRow.zSNRYKMK_CD_27
                      AND '1'||dayRow.SNRYKMK_CD_28 = '1'||dayRow.zSNRYKMK_CD_28
                      AND '1'||dayRow.SNRYKMK_CD_29 = '1'||dayRow.zSNRYKMK_CD_29
                      AND '1'||dayRow.SNRYKMK_CD_30 = '1'||dayRow.zSNRYKMK_CD_30
                      AND '1'||dayRow.SNRYKMK_CD_31 = '1'||dayRow.zSNRYKMK_CD_31
                      AND '1'||dayRow.SNRYKMK_CD_32 = '1'||dayRow.zSNRYKMK_CD_32
                      AND '1'||dayRow.SNRYKMK_CD_33 = '1'||dayRow.zSNRYKMK_CD_33
                      AND '1'||dayRow.SNRYKMK_CD_34 = '1'||dayRow.zSNRYKMK_CD_34
                      AND '1'||dayRow.SNRYKMK_CD_35 = '1'||dayRow.zSNRYKMK_CD_35
                      AND '1'||dayRow.SNRYKMK_CD_36 = '1'||dayRow.zSNRYKMK_CD_36
                      AND '1'||dayRow.SNRYKMK_CD_37 = '1'||dayRow.zSNRYKMK_CD_37
                      AND '1'||dayRow.SNRYKMK_CD_38 = '1'||dayRow.zSNRYKMK_CD_38
                      AND '1'||dayRow.SNRYKMK_CD_39 = '1'||dayRow.zSNRYKMK_CD_39
                      AND '1'||dayRow.SNRYKMK_CD_40 = '1'||dayRow.zSNRYKMK_CD_40
                      AND '1'||dayRow.SNRYKMK_CD_41 = '1'||dayRow.zSNRYKMK_CD_41
                      AND '1'||dayRow.SNRYKMK_CD_42 = '1'||dayRow.zSNRYKMK_CD_42
                      AND '1'||dayRow.SNRYKMK_CD_43 = '1'||dayRow.zSNRYKMK_CD_43
                      AND '1'||dayRow.SNRYKMK_CD_44 = '1'||dayRow.zSNRYKMK_CD_44
                      AND '1'||dayRow.SNRYKMK_CD_45 = '1'||dayRow.zSNRYKMK_CD_45
                      AND '1'||dayRow.SNRYKMK_CD_46 = '1'||dayRow.zSNRYKMK_CD_46
                      AND '1'||dayRow.SNRYKMK_CD_47 = '1'||dayRow.zSNRYKMK_CD_47
                      AND '1'||dayRow.SNRYKMK_CD_48 = '1'||dayRow.zSNRYKMK_CD_48
                      AND '1'||dayRow.SNRYKMK_CD_49 = '1'||dayRow.zSNRYKMK_CD_49
                      AND '1'||dayRow.SNRYKMK_CD_50 = '1'||dayRow.zSNRYKMK_CD_50
                      AND '1'||dayRow.SNRYKMK_CD_51 = '1'||dayRow.zSNRYKMK_CD_51
                      AND '1'||dayRow.SNRYKMK_CD_52 = '1'||dayRow.zSNRYKMK_CD_52
                      AND '1'||dayRow.SNRYKMK_CD_53 = '1'||dayRow.zSNRYKMK_CD_53
                      AND '1'||dayRow.SNRYKMK_CD_54 = '1'||dayRow.zSNRYKMK_CD_54
                      AND '1'||dayRow.SNRYKMK_CD_55 = '1'||dayRow.zSNRYKMK_CD_55
                      AND '1'||dayRow.SNRYKMK_CD_56 = '1'||dayRow.zSNRYKMK_CD_56
                      AND '1'||dayRow.SNRYKMK_CD_57 = '1'||dayRow.zSNRYKMK_CD_57
                      AND '1'||dayRow.SNRYKMK_CD_58 = '1'||dayRow.zSNRYKMK_CD_58
                      AND '1'||dayRow.SNRYKMK_CD_59 = '1'||dayRow.zSNRYKMK_CD_59
                      AND '1'||dayRow.SNRYKMK_CD_60 = '1'||dayRow.zSNRYKMK_CD_60
                    THEN
                      dayRow.SNRYKMK_CD_01 := NULL;
                      dayRow.SNRYKMK_CD_02 := NULL;
                      dayRow.SNRYKMK_CD_03 := NULL;
                      dayRow.SNRYKMK_CD_04 := NULL;
                      dayRow.SNRYKMK_CD_05 := NULL;
                      dayRow.SNRYKMK_CD_06 := NULL;
                      dayRow.SNRYKMK_CD_07 := NULL;
                      dayRow.SNRYKMK_CD_08 := NULL;
                      dayRow.SNRYKMK_CD_09 := NULL;
                      dayRow.SNRYKMK_CD_10 := NULL;
                      dayRow.SNRYKMK_CD_11 := NULL;
                      dayRow.SNRYKMK_CD_12 := NULL;
                      dayRow.SNRYKMK_CD_13 := NULL;
                      dayRow.SNRYKMK_CD_14 := NULL;
                      dayRow.SNRYKMK_CD_15 := NULL;
                      dayRow.SNRYKMK_CD_16 := NULL;
                      dayRow.SNRYKMK_CD_17 := NULL;
                      dayRow.SNRYKMK_CD_18 := NULL;
                      dayRow.SNRYKMK_CD_19 := NULL;
                      dayRow.SNRYKMK_CD_20 := NULL;
                      dayRow.SNRYKMK_CD_21 := NULL;
                      dayRow.SNRYKMK_CD_22 := NULL;
                      dayRow.SNRYKMK_CD_23 := NULL;
                      dayRow.SNRYKMK_CD_24 := NULL;
                      dayRow.SNRYKMK_CD_25 := NULL;
                      dayRow.SNRYKMK_CD_26 := NULL;
                      dayRow.SNRYKMK_CD_27 := NULL;
                      dayRow.SNRYKMK_CD_28 := NULL;
                      dayRow.SNRYKMK_CD_29 := NULL;
                      dayRow.SNRYKMK_CD_30 := NULL;
                      dayRow.SNRYKMK_CD_31 := NULL;
                      dayRow.SNRYKMK_CD_32 := NULL;
                      dayRow.SNRYKMK_CD_33 := NULL;
                      dayRow.SNRYKMK_CD_34 := NULL;
                      dayRow.SNRYKMK_CD_35 := NULL;
                      dayRow.SNRYKMK_CD_36 := NULL;
                      dayRow.SNRYKMK_CD_37 := NULL;
                      dayRow.SNRYKMK_CD_38 := NULL;
                      dayRow.SNRYKMK_CD_39 := NULL;
                      dayRow.SNRYKMK_CD_40 := NULL;
                      dayRow.SNRYKMK_CD_41 := NULL;
                      dayRow.SNRYKMK_CD_42 := NULL;
                      dayRow.SNRYKMK_CD_43 := NULL;
                      dayRow.SNRYKMK_CD_44 := NULL;
                      dayRow.SNRYKMK_CD_45 := NULL;
                      dayRow.SNRYKMK_CD_46 := NULL;
                      dayRow.SNRYKMK_CD_47 := NULL;
                      dayRow.SNRYKMK_CD_48 := NULL;
                      dayRow.SNRYKMK_CD_49 := NULL;
                      dayRow.SNRYKMK_CD_50 := NULL;
                      dayRow.SNRYKMK_CD_51 := NULL;
                      dayRow.SNRYKMK_CD_52 := NULL;
                      dayRow.SNRYKMK_CD_53 := NULL;
                      dayRow.SNRYKMK_CD_54 := NULL;
                      dayRow.SNRYKMK_CD_55 := NULL;
                      dayRow.SNRYKMK_CD_56 := NULL;
                      dayRow.SNRYKMK_CD_57 := NULL;
                      dayRow.SNRYKMK_CD_58 := NULL;
                      dayRow.SNRYKMK_CD_59 := NULL;
                      dayRow.SNRYKMK_CD_60 := NULL;
                    ELSIF dayRow.SNRYKMK_CD_01 IS NULL
                      AND dayRow.SNRYKMK_CD_02 IS NULL
                      AND dayRow.SNRYKMK_CD_03 IS NULL
                      AND dayRow.SNRYKMK_CD_04 IS NULL
                      AND dayRow.SNRYKMK_CD_05 IS NULL
                      AND dayRow.SNRYKMK_CD_06 IS NULL
                      AND dayRow.SNRYKMK_CD_07 IS NULL
                      AND dayRow.SNRYKMK_CD_08 IS NULL
                      AND dayRow.SNRYKMK_CD_09 IS NULL
                      AND dayRow.SNRYKMK_CD_10 IS NULL
                      AND dayRow.SNRYKMK_CD_11 IS NULL
                      AND dayRow.SNRYKMK_CD_12 IS NULL
                      AND dayRow.SNRYKMK_CD_13 IS NULL
                      AND dayRow.SNRYKMK_CD_14 IS NULL
                      AND dayRow.SNRYKMK_CD_15 IS NULL
                      AND dayRow.SNRYKMK_CD_16 IS NULL
                      AND dayRow.SNRYKMK_CD_17 IS NULL
                      AND dayRow.SNRYKMK_CD_18 IS NULL
                      AND dayRow.SNRYKMK_CD_19 IS NULL
                      AND dayRow.SNRYKMK_CD_20 IS NULL
                      AND dayRow.SNRYKMK_CD_21 IS NULL
                      AND dayRow.SNRYKMK_CD_22 IS NULL
                      AND dayRow.SNRYKMK_CD_23 IS NULL
                      AND dayRow.SNRYKMK_CD_24 IS NULL
                      AND dayRow.SNRYKMK_CD_25 IS NULL
                      AND dayRow.SNRYKMK_CD_26 IS NULL
                      AND dayRow.SNRYKMK_CD_27 IS NULL
                      AND dayRow.SNRYKMK_CD_28 IS NULL
                      AND dayRow.SNRYKMK_CD_29 IS NULL
                      AND dayRow.SNRYKMK_CD_30 IS NULL
                      AND dayRow.SNRYKMK_CD_31 IS NULL
                      AND dayRow.SNRYKMK_CD_32 IS NULL
                      AND dayRow.SNRYKMK_CD_33 IS NULL
                      AND dayRow.SNRYKMK_CD_34 IS NULL
                      AND dayRow.SNRYKMK_CD_35 IS NULL
                      AND dayRow.SNRYKMK_CD_36 IS NULL
                      AND dayRow.SNRYKMK_CD_37 IS NULL
                      AND dayRow.SNRYKMK_CD_38 IS NULL
                      AND dayRow.SNRYKMK_CD_39 IS NULL
                      AND dayRow.SNRYKMK_CD_40 IS NULL
                      AND dayRow.SNRYKMK_CD_41 IS NULL
                      AND dayRow.SNRYKMK_CD_42 IS NULL
                      AND dayRow.SNRYKMK_CD_43 IS NULL
                      AND dayRow.SNRYKMK_CD_44 IS NULL
                      AND dayRow.SNRYKMK_CD_45 IS NULL
                      AND dayRow.SNRYKMK_CD_46 IS NULL
                      AND dayRow.SNRYKMK_CD_47 IS NULL
                      AND dayRow.SNRYKMK_CD_48 IS NULL
                      AND dayRow.SNRYKMK_CD_49 IS NULL
                      AND dayRow.SNRYKMK_CD_50 IS NULL
                      AND dayRow.SNRYKMK_CD_51 IS NULL
                      AND dayRow.SNRYKMK_CD_52 IS NULL
                      AND dayRow.SNRYKMK_CD_53 IS NULL
                      AND dayRow.SNRYKMK_CD_54 IS NULL
                      AND dayRow.SNRYKMK_CD_55 IS NULL
                      AND dayRow.SNRYKMK_CD_56 IS NULL
                      AND dayRow.SNRYKMK_CD_57 IS NULL
                      AND dayRow.SNRYKMK_CD_58 IS NULL
                      AND dayRow.SNRYKMK_CD_59 IS NULL
                      AND dayRow.SNRYKMK_CD_60 IS NULL
                    THEN
                      dayRow.SNRYKMK_CD_01 := ULT_COMMON.INSERT_HALF_DEFAULT;
                    END IF;
                    IF '1'||dayRow.KANREN_DAIGAKU_OYA_REC_ID = '1'||dayRow.zKANREN_DAIGAKU_OYA_REC_ID
                      AND '1'||dayRow.KANREN_DAIGAKU_OYA_SHI_CD = '1'||dayRow.zKANREN_DAIGAKU_OYA_SHI_CD
                    THEN
                      dayRow.KANREN_DAIGAKU_OYA_REC_ID := NULL;
                      dayRow.KANREN_DAIGAKU_OYA_SHI_CD := NULL;
                    ELSIF dayRow.KANREN_DAIGAKU_OYA_REC_ID IS NULL
                      AND dayRow.KANREN_DAIGAKU_OYA_SHI_CD IS NULL
                    THEN
                      dayRow.KANREN_DAIGAKU_OYA_REC_ID := ULT_COMMON.INSERT_HALF_DEFAULT;
                    END IF;
                    IF '1'||dayRow.KYOKA_BED_SU_GOKEI = '1'||dayRow.zKYOKA_BED_SU_GOKEI
                      AND '1'||dayRow.KYOKA_BED_SU_SEISHIN = '1'||dayRow.zKYOKA_BED_SU_SEISHIN
                      AND '1'||dayRow.KYOKA_BED_SU_KEKKAKU = '1'||dayRow.zKYOKA_BED_SU_KEKKAKU
                      AND '1'||dayRow.KYOKA_BED_SU_KANSEN = '1'||dayRow.zKYOKA_BED_SU_KANSEN
                      AND '1'||dayRow.KYOKA_BED_SU_SONOTA = '1'||dayRow.zKYOKA_BED_SU_SONOTA
                      AND '1'||dayRow.KYOKA_BED_SU_IPPAN = '1'||dayRow.zKYOKA_BED_SU_IPPAN
                      AND '1'||dayRow.KYOKA_BED_SU_RYOYO = '1'||dayRow.zKYOKA_BED_SU_RYOYO
                    THEN
                      dayRow.KYOKA_BED_SU_GOKEI := NULL;
                      dayRow.KYOKA_BED_SU_SEISHIN := NULL;
                      dayRow.KYOKA_BED_SU_KEKKAKU := NULL;
                      dayRow.KYOKA_BED_SU_KANSEN := NULL;
                      dayRow.KYOKA_BED_SU_SONOTA := NULL;
                      dayRow.KYOKA_BED_SU_IPPAN := NULL;
                      dayRow.KYOKA_BED_SU_RYOYO := NULL;
                    ELSIF dayRow.KYOKA_BED_SU_GOKEI IS NULL
                      AND dayRow.KYOKA_BED_SU_SEISHIN IS NULL
                      AND dayRow.KYOKA_BED_SU_KEKKAKU IS NULL
                      AND dayRow.KYOKA_BED_SU_KANSEN IS NULL
                      AND dayRow.KYOKA_BED_SU_SONOTA IS NULL
                      AND dayRow.KYOKA_BED_SU_IPPAN IS NULL
                      AND dayRow.KYOKA_BED_SU_RYOYO IS NULL
                    THEN
                      dayRow.KYOKA_BED_SU_GOKEI := ULT_COMMON.INSERT_HALF_DEFAULT;
                    END IF;
                    IF '1'||dayRow.KENSAKOMOKU_BISEIBUTSU_FLG = '1'||dayRow.zKENSAKOMOKU_BISEIBUTSU_FLG
                      AND '1'||dayRow.KENSAKOMOKU_KESSEI_FLG = '1'||dayRow.zKENSAKOMOKU_KESSEI_FLG
                      AND '1'||dayRow.KENSAKOMOKU_KETSUEKI_FLG = '1'||dayRow.zKENSAKOMOKU_KETSUEKI_FLG
                      AND '1'||dayRow.KENSAKOMOKU_BYORI_FLG = '1'||dayRow.zKENSAKOMOKU_BYORI_FLG
                      AND '1'||dayRow.KENSAKOMOKU_KISEICHU_FLG = '1'||dayRow.zKENSAKOMOKU_KISEICHU_FLG
                      AND '1'||dayRow.KENSAKOMOKU_SEIKA_FLG = '1'||dayRow.zKENSAKOMOKU_SEIKA_FLG
                      AND '1'||dayRow.KENSAKOMOKU_RI_FLG = '1'||dayRow.zKENSAKOMOKU_RI_FLG
                    THEN
                      dayRow.KENSAKOMOKU_BISEIBUTSU_FLG := NULL;
                      dayRow.KENSAKOMOKU_KESSEI_FLG := NULL;
                      dayRow.KENSAKOMOKU_KETSUEKI_FLG := NULL;
                      dayRow.KENSAKOMOKU_BYORI_FLG := NULL;
                      dayRow.KENSAKOMOKU_KISEICHU_FLG := NULL;
                      dayRow.KENSAKOMOKU_SEIKA_FLG := NULL;
                      dayRow.KENSAKOMOKU_RI_FLG := NULL;
                    ELSIF dayRow.KENSAKOMOKU_BISEIBUTSU_FLG IS NULL
                      AND dayRow.KENSAKOMOKU_KESSEI_FLG IS NULL
                      AND dayRow.KENSAKOMOKU_KETSUEKI_FLG IS NULL
                      AND dayRow.KENSAKOMOKU_BYORI_FLG IS NULL
                      AND dayRow.KENSAKOMOKU_KISEICHU_FLG IS NULL
                      AND dayRow.KENSAKOMOKU_SEIKA_FLG IS NULL
                      AND dayRow.KENSAKOMOKU_RI_FLG IS NULL
                    THEN
                      dayRow.KENSAKOMOKU_BISEIBUTSU_FLG := ULT_COMMON.INSERT_HALF_DEFAULT;
                    END IF;
                    IF '1'||dayRow.IMUSHITSU_REC_ID = '1'||dayRow.zIMUSHITSU_REC_ID 
                      AND '1'||dayRow.IMUSHITSU_SHI_CD = '1'||dayRow.zIMUSHITSU_SHI_CD
                    THEN
                      dayRow.IMUSHITSU_REC_ID := NULL;
                      dayRow.IMUSHITSU_SHI_CD := NULL;
                    ELSIF  dayRow.IMUSHITSU_REC_ID IS NULL 
                      AND dayRow.IMUSHITSU_SHI_CD IS NULL 
                    THEN
                      dayRow.IMUSHITSU_REC_ID := ULT_COMMON.INSERT_HALF_DEFAULT;
                    END IF;                    
                 END IF;
                   INSERT INTO TD_ND_DCF_SHI(
                      LAYOUT_KBN,
                      SHIREC_ID,
                      SHI_CD,
                      MOD_KBN,
                      MENTE_YMD,
                      TENSO_YMD,
                      MIKAKUNIN_FLG,
                      DEL_YOTEI_RIYU,
                      AITSK_CD_SHIREC_ID,
                      AITSK_CD_SHI_CD,
                      SEISHIKI_SHI_NM_KANJI,
                      SEISHIKI_SHI_NM_KANA,
                      RYKSK_SHI_NM_KANJI,
                      RYKSK_SHI_NM_KANA,
                      JUSHOFUMEI,
                      JUSHO_CD_KEN_CD,
                      JUSHO_CD_SHIKU_CD,
                      JUSHO_CD_OAZA_CD,
                      JUSHO_CD_AZA_CD,
                      ZIP,
                      JUSHO_KANJI,
                      JUSHO_KANA,
                      JUSHO_HYOJI_NO,
                      JUSHO_COUNT_KANJI_KEN,
                      JUSHO_COUNT_KANJI_SHIKU,
                      JUSHO_COUNT_KANJI_OAZA,
                      JUSHO_COUNT_KANJI_AZA,
                      JUSHO_COUNT_KANA_KEN,
                      JUSHO_COUNT_KANA_SHIKU,
                      JUSHO_COUNT_KANA_OAZA,
                      JUSHO_COUNT_KANA_AZA,
                      TEL_NASHI_FLG,
                      TEL,
                      KEIEITAI,
                      SHI_KBN,
                      DAIHYO_KJNREC_ID,
                      DAIHYO_KJN_CD,
                      DAIHYO_KANJI,
                      DAIHYO_KANA,
                      KAIGYO_YOTEI_KAIGYO_YOTEI_FLG,
                      KAIGYO_YOTEI_KAIGYO_YOTEI_YM,
                      KYUIN_KYUIN_FLG,
                      KYUIN_KYUIN_S_YM,
                      SNRYKMK_1,
                      SNRYKMK_2,
                      SNRYKMK_3,
                      SNRYKMK_4,
                      SNRYKMK_5,
                      SNRYKMK_6,
                      SNRYKMK_7,
                      SNRYKMK_8,
                      SNRYKMK_9,
                      SNRYKMK_10,
                      SNRYKMK_11,
                      SNRYKMK_12,
                      SNRYKMK_13,
                      SNRYKMK_14,
                      SNRYKMK_15,
                      SNRYKMK_16,
                      SNRYKMK_17,
                      SNRYKMK_18,
                      SNRYKMK_19,
                      SNRYKMK_20,
                      SNRYKMK_21,
                      SNRYKMK_22,
                      SNRYKMK_23,
                      SNRYKMK_24,
                      SNRYKMK_25,
                      SNRYKMK_26,
                      SNRYKMK_27,
                      SNRYKMK_28,
                      SNRYKMK_29,
                      SNRYKMK_30,
                      SNRYKMK_31,
                      SNRYKMK_32,
                      SNRYKMK_33,
                      SNRYKMK_34,
                      SNRYKMK_35,
                      SNRYKMK_36,
                      SNRYKMK_37,
                      SNRYKMK_38,
                      SNRYKMK_39,
                      SNRYKMK_40,
                      SNRYKMK_41,
                      SNRYKMK_42,
                      SNRYKMK_43,
                      SNRYKMK_44,
                      SNRYKMK_45,
                      SNRYKMK_46,
                      SNRYKMK_47,
                      SNRYKMK_48,
                      SNRYKMK_49,
                      SNRYKMK_50,
                      SNRYKMK_51,
                      SNRYKMK_52,
                      SNRYKMK_53,
                      SNRYKMK_54,
                      SNRYKMK_55,
                      SNRYKMK_56,
                      SNRYKMK_57,
                      SNRYKMK_58,
                      SNRYKMK_59,
                      SNRYKMK_60,
                      BYOIN_SBT,
                      SAISHINSA_KBN,
                      KANREN_DAIGAKU_OYA_SHIREC_ID,
                      KANREN_DAIGAKU_OYA_SHI_CD,
                      BYOTO_HEISA_FLG,
                      BED_SU_TEIIN,
                      KYOKA_BED_MENTE_HIZUKE,
                      KYOKA_BED_SU_GOKEI,
                      KYOKA_BED_SU_SEISHIN,
                      KYOKA_BED_SU_KEKKAKU,
                      KYOKA_BED_SU_KANSEN,
                      KYOKA_BED_SU_SONOTA,
                      KYOKA_BED_SU_IPPAN_BED,
                      KYOKA_BED_SU_RYOYO_BED,
                      KENSAKOMOKU_BISEIBUTSU,
                      KENSAKOMOKU_KESSEI,
                      KENSAKOMOKU_KETSUEKI,
                      KENSAKOMOKU_BYORI,
                      KENSAKOMOKU_KISEICHU,
                      KENSAKOMOKU_SEIKA,
                      KENSAKOMOKU_RI,
                      TOKUI_CD_REC_ID,
                      TOKUI_CD_SHI_CD,
                      TRK_OPE_CD,
                      TRK_DATE,
                      TRK_PGM_ID,
                      UPD_OPE_CD,
                      UPD_DATE,
                      UPD_PGM_ID
                   )
                   VALUES(
                      '101',
                      dayRow.REC_ID,
                      dayRow.SHI_CD,
                      vMODKBN,
                      dayRow.UPD_EIGY_YMD,
                      iTensoYMD,
                      TRIM(dayRow.MIKAKUNIN_FLG),
                      TRIM(dayRow.DEL_YOTEI_RIYU_CD),
                      TRIM(dayRow.CHOFUKU_AITSK_REC_ID),
                      TRIM(dayRow.CHOFUKU_AITSK_SHI_CD),
                      dayRow.SEISHIKI_SHI_NM,
                      dayRow.SEISHIKI_SHI_NM_KANA,
                      dayRow.SHI_RN,
                      dayRow.SHI_RN_KANA,
                      TRIM(dayRow.JUSHOFUMEI_CD),
                      dayRow.KEN_CD,
                      dayRow.SHIKU_CD,
                      dayRow.OAZA_CD,
                      dayRow.AZA_CD,
                      NVL2(dayRow.ZIP,SUBSTR(dayRow.ZIP,1,3)||'-'||SUBSTR(dayRow.ZIP,4),NULL),
                      dayRow.JUSHO_KANJI_RENKETSU,
                      dayRow.JUSHO_KANA_RENKETSU,
                      dayRow.JUSHO_HYOJI_NO,
                      dayRow.KEN_NM_KANJI_MOJI_SU,
                      dayRow.SHIKU_NM_KANJI_MOJI_SU,
                      dayRow.OAZA_NM_KANJI_MOJI_SU,
                      dayRow.AZA_NM_KANJI_MOJI_SU,
                      dayRow.KEN_NM_KANA_MOJI_SU,
                      dayRow.SHIKU_NM_KANA_MOJI_SU,
                      dayRow.OAZA_NM_KANA_MOJI_SU,
                      dayRow.AZA_NM_KANA_MOJI_SU,
                      TRIM(dayRow.TEL_NASHI_FLG),
                      TRIM(dayRow.TEL),
                      dayRow.KEIEITAI_CD,
                      dayRow.SHI_KBN_CD,
                      TRIM(dayRow.DAIHYO_REC_ID),
                      TRIM(dayRow.DAIHYO_KJN_CD),
                      TRIM(dayRow.KJN_NM),
                      TRIM(dayRow.KJN_NM_KANA),
                      TRIM(dayRow.KAIGYO_YOTEI_FLG),
                      TRIM(dayRow.KAIGYO_YOTEI_YM),
                      TRIM(dayRow.KYUIN_FLG),
                      TRIM(dayRow.KYUIN_S_YM),
                      TRIM(dayRow.SNRYKMK_CD_01),
                      TRIM(dayRow.SNRYKMK_CD_02),
                      TRIM(dayRow.SNRYKMK_CD_03),
                      TRIM(dayRow.SNRYKMK_CD_04),
                      TRIM(dayRow.SNRYKMK_CD_05),
                      TRIM(dayRow.SNRYKMK_CD_06),
                      TRIM(dayRow.SNRYKMK_CD_07),
                      TRIM(dayRow.SNRYKMK_CD_08),
                      TRIM(dayRow.SNRYKMK_CD_09),
                      TRIM(dayRow.SNRYKMK_CD_10),
                      TRIM(dayRow.SNRYKMK_CD_11),
                      TRIM(dayRow.SNRYKMK_CD_12),
                      TRIM(dayRow.SNRYKMK_CD_13),
                      TRIM(dayRow.SNRYKMK_CD_14),
                      TRIM(dayRow.SNRYKMK_CD_15),
                      TRIM(dayRow.SNRYKMK_CD_16),
                      TRIM(dayRow.SNRYKMK_CD_17),
                      TRIM(dayRow.SNRYKMK_CD_18),
                      TRIM(dayRow.SNRYKMK_CD_19),
                      TRIM(dayRow.SNRYKMK_CD_20),
                      TRIM(dayRow.SNRYKMK_CD_21),
                      TRIM(dayRow.SNRYKMK_CD_22),
                      TRIM(dayRow.SNRYKMK_CD_23),
                      TRIM(dayRow.SNRYKMK_CD_24),
                      TRIM(dayRow.SNRYKMK_CD_25),
                      TRIM(dayRow.SNRYKMK_CD_26),
                      TRIM(dayRow.SNRYKMK_CD_27),
                      TRIM(dayRow.SNRYKMK_CD_28),
                      TRIM(dayRow.SNRYKMK_CD_29),
                      TRIM(dayRow.SNRYKMK_CD_30),
                      TRIM(dayRow.SNRYKMK_CD_31),
                      TRIM(dayRow.SNRYKMK_CD_32),
                      TRIM(dayRow.SNRYKMK_CD_33),
                      TRIM(dayRow.SNRYKMK_CD_34),
                      TRIM(dayRow.SNRYKMK_CD_35),
                      TRIM(dayRow.SNRYKMK_CD_36),
                      TRIM(dayRow.SNRYKMK_CD_37),
                      TRIM(dayRow.SNRYKMK_CD_38),
                      TRIM(dayRow.SNRYKMK_CD_39),
                      TRIM(dayRow.SNRYKMK_CD_40),
                      TRIM(dayRow.SNRYKMK_CD_41),
                      TRIM(dayRow.SNRYKMK_CD_42),
                      TRIM(dayRow.SNRYKMK_CD_43),
                      TRIM(dayRow.SNRYKMK_CD_44),
                      TRIM(dayRow.SNRYKMK_CD_45),
                      TRIM(dayRow.SNRYKMK_CD_46),
                      TRIM(dayRow.SNRYKMK_CD_47),
                      TRIM(dayRow.SNRYKMK_CD_48),
                      TRIM(dayRow.SNRYKMK_CD_49),
                      TRIM(dayRow.SNRYKMK_CD_50),
                      TRIM(dayRow.SNRYKMK_CD_51),
                      TRIM(dayRow.SNRYKMK_CD_52),
                      TRIM(dayRow.SNRYKMK_CD_53),
                      TRIM(dayRow.SNRYKMK_CD_54),
                      TRIM(dayRow.SNRYKMK_CD_55),
                      TRIM(dayRow.SNRYKMK_CD_56),
                      TRIM(dayRow.SNRYKMK_CD_57),
                      TRIM(dayRow.SNRYKMK_CD_58),
                      TRIM(dayRow.SNRYKMK_CD_59),
                      TRIM(dayRow.SNRYKMK_CD_60),
                      dayRow.BYOIN_SBT_CD,
                      dayRow.SAISHINSA_KBN_CD,
                      TRIM(dayRow.KANREN_DAIGAKU_OYA_REC_ID),
                      TRIM(dayRow.KANREN_DAIGAKU_OYA_SHI_CD),
                      TRIM(dayRow.BYOTO_HEISA_KBN),
                      TRIM(dayRow.SHI_BED_SU),
                      TRIM(dayRow.BED_SU_KKNN_EIGY_YMD),
                      TRIM(dayRow.KYOKA_BED_SU_GOKEI),
                      TRIM(dayRow.KYOKA_BED_SU_SEISHIN),
                      TRIM(dayRow.KYOKA_BED_SU_KEKKAKU),
                      TRIM(dayRow.KYOKA_BED_SU_KANSEN),
                      TRIM(dayRow.KYOKA_BED_SU_SONOTA),
                      TRIM(dayRow.KYOKA_BED_SU_IPPAN),
                      TRIM(dayRow.KYOKA_BED_SU_RYOYO),
                      TRIM(dayRow.KENSAKOMOKU_BISEIBUTSU_FLG),
                      TRIM(dayRow.KENSAKOMOKU_KESSEI_FLG),
                      TRIM(dayRow.KENSAKOMOKU_KETSUEKI_FLG),
                      TRIM(dayRow.KENSAKOMOKU_BYORI_FLG),
                      TRIM(dayRow.KENSAKOMOKU_KISEICHU_FLG),
                      TRIM(dayRow.KENSAKOMOKU_SEIKA_FLG),
                      TRIM(dayRow.KENSAKOMOKU_RI_FLG),
                      TRIM(dayRow.IMUSHITSU_REC_ID),
                      TRIM(dayRow.IMUSHITSU_SHI_CD),
                      iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID
                   );
                   EXECUTE_SQL := 'INSERT INTO TD_ND_DCF_SHI(
                      LAYOUT_KBN,
                      SHIREC_ID,
                      SHI_CD,
                      MOD_KBN,
                      MENTE_YMD,
                      TENSO_YMD,
                      MIKAKUNIN_FLG,
                      DEL_YOTEI_RIYU,
                      AITSK_CD_SHIREC_ID,
                      AITSK_CD_SHI_CD,
                      SEISHIKI_SHI_NM_KANJI,
                      SEISHIKI_SHI_NM_KANA,
                      RYKSK_SHI_NM_KANJI,
                      RYKSK_SHI_NM_KANA,
                      JUSHOFUMEI,
                      JUSHO_CD_KEN_CD,
                      JUSHO_CD_SHIKU_CD,
                      JUSHO_CD_OAZA_CD,
                      JUSHO_CD_AZA_CD,
                      ZIP,
                      JUSHO_KANJI,
                      JUSHO_KANA,
                      JUSHO_HYOJI_NO,
                      JUSHO_COUNT_KANJI_KEN,
                      JUSHO_COUNT_KANJI_SHIKU,
                      JUSHO_COUNT_KANJI_OAZA,
                      JUSHO_COUNT_KANJI_AZA,
                      JUSHO_COUNT_KANA_KEN,
                      JUSHO_COUNT_KANA_SHIKU,
                      JUSHO_COUNT_KANA_OAZA,
                      JUSHO_COUNT_KANA_AZA,
                      TEL_NASHI_FLG,
                      TEL,
                      KEIEITAI,
                      SHI_KBN,
                      DAIHYO_KJNREC_ID,
                      DAIHYO_KJN_CD,
                      DAIHYO_KANJI,
                      DAIHYO_KANA,
                      KAIGYO_YOTEI_KAIGYO_YOTEI_FLG,
                      KAIGYO_YOTEI_KAIGYO_YOTEI_YM,
                      KYUIN_KYUIN_FLG,
                      KYUIN_KYUIN_S_YM,
                      SNRYKMK_1,
                      SNRYKMK_2,
                      SNRYKMK_3,
                      SNRYKMK_4,
                      SNRYKMK_5,
                      SNRYKMK_6,
                      SNRYKMK_7,
                      SNRYKMK_8,
                      SNRYKMK_9,
                      SNRYKMK_10,
                      SNRYKMK_11,
                      SNRYKMK_12,
                      SNRYKMK_13,
                      SNRYKMK_14,
                      SNRYKMK_15,
                      SNRYKMK_16,
                      SNRYKMK_17,
                      SNRYKMK_18,
                      SNRYKMK_19,
                      SNRYKMK_20,
                      SNRYKMK_21,
                      SNRYKMK_22,
                      SNRYKMK_23,
                      SNRYKMK_24,
                      SNRYKMK_25,
                      SNRYKMK_26,
                      SNRYKMK_27,
                      SNRYKMK_28,
                      SNRYKMK_29,
                      SNRYKMK_30,
                      SNRYKMK_31,
                      SNRYKMK_32,
                      SNRYKMK_33,
                      SNRYKMK_34,
                      SNRYKMK_35,
                      SNRYKMK_36,
                      SNRYKMK_37,
                      SNRYKMK_38,
                      SNRYKMK_39,
                      SNRYKMK_40,
                      SNRYKMK_41,
                      SNRYKMK_42,
                      SNRYKMK_43,
                      SNRYKMK_44,
                      SNRYKMK_45,
                      SNRYKMK_46,
                      SNRYKMK_47,
                      SNRYKMK_48,
                      SNRYKMK_49,
                      SNRYKMK_50,
                      SNRYKMK_51,
                      SNRYKMK_52,
                      SNRYKMK_53,
                      SNRYKMK_54,
                      SNRYKMK_55,
                      SNRYKMK_56,
                      SNRYKMK_57,
                      SNRYKMK_58,
                      SNRYKMK_59,
                      SNRYKMK_60,
                      BYOIN_SBT,
                      SAISHINSA_KBN,
                      KANREN_DAIGAKU_OYA_SHIREC_ID,
                      KANREN_DAIGAKU_OYA_SHI_CD,
                      BYOTO_HEISA_FLG,
                      BED_SU_TEIIN,
                      KYOKA_BED_MENTE_HIZUKE,
                      KYOKA_BED_SU_GOKEI,
                      KYOKA_BED_SU_SEISHIN,
                      KYOKA_BED_SU_KEKKAKU,
                      KYOKA_BED_SU_KANSEN,
                      KYOKA_BED_SU_SONOTA,
                      KYOKA_BED_SU_IPPAN_BED,
                      KYOKA_BED_SU_RYOYO_BED,
                      KENSAKOMOKU_BISEIBUTSU,
                      KENSAKOMOKU_KESSEI,
                      KENSAKOMOKU_KETSUEKI,
                      KENSAKOMOKU_BYORI,
                      KENSAKOMOKU_KISEICHU,
                      KENSAKOMOKU_SEIKA,
                      KENSAKOMOKU_RI,
                      TOKUI_CD_REC_ID,
                      TOKUI_CD_SHI_CD,
                      TRK_OPE_CD,
                      TRK_DATE,
                      TRK_PGM_ID,
                      UPD_OPE_CD,
                      UPD_DATE,
                      UPD_PGM_ID
                   )
                   VALUES(
                     ''101'',
                     '''||dayRow.REC_ID||''',
                     '''||dayRow.SHI_CD||''',
                     '''||vMODKBN||''',
                     '''||dayRow.UPD_EIGY_YMD||''',
                     '''||iTensoYMD||''',
                     '''||dayRow.MIKAKUNIN_FLG||''',
                     '''||dayRow.DEL_YOTEI_RIYU_CD||''',
                     '''||dayRow.CHOFUKU_AITSK_REC_ID||''',
                     '''||dayRow.CHOFUKU_AITSK_SHI_CD||''',
                     '''||dayRow.SEISHIKI_SHI_NM||''',
                     '''||dayRow.SEISHIKI_SHI_NM_KANA||''',
                     '''||dayRow.SHI_RN||''',
                     '''||dayRow.SHI_RN_KANA||''',
                     '''||dayRow.JUSHOFUMEI_CD||''',
                     '''||dayRow.KEN_CD||''',
                     '''||dayRow.SHIKU_CD||''',
                     '''||dayRow.OAZA_CD||''',
                     '''||dayRow.AZA_CD||''',
                     '''||CASE WHEN dayRow.ZIP IS NOT NULL THEN SUBSTR(dayRow.ZIP,1,3)||'-'||SUBSTR(dayRow.ZIP,4) ELSE NULL END ||''',
                     '''||dayRow.JUSHO_KANJI_RENKETSU||''',
                     '''||dayRow.JUSHO_KANA_RENKETSU||''',
                     '''||dayRow.JUSHO_HYOJI_NO||''',
                     '''||dayRow.KEN_NM_KANJI_MOJI_SU||''',
                     '''||dayRow.SHIKU_NM_KANJI_MOJI_SU||''',
                     '''||dayRow.OAZA_NM_KANJI_MOJI_SU||''',
                     '''||dayRow.AZA_NM_KANJI_MOJI_SU||''',
                     '''||dayRow.KEN_NM_KANA_MOJI_SU||''',
                     '''||dayRow.SHIKU_NM_KANA_MOJI_SU||''',
                     '''||dayRow.OAZA_NM_KANA_MOJI_SU||''',
                     '''||dayRow.AZA_NM_KANA_MOJI_SU||''',
                     '''||dayRow.TEL_NASHI_FLG||''',
                     '''||dayRow.TEL||''',
                     '''||dayRow.KEIEITAI_CD||''',
                     '''||dayRow.SHI_KBN_CD||''',
                     '''||dayRow.DAIHYO_REC_ID||''',
                     '''||dayRow.DAIHYO_KJN_CD||''',
                     '''||dayRow.KJN_NM||''',
                     '''||dayRow.KJN_NM_KANA||''',
                     '''||dayRow.KAIGYO_YOTEI_FLG||''',
                     '''||dayRow.KAIGYO_YOTEI_YM||''',
                     '''||dayRow.KYUIN_FLG||''',
                     '''||dayRow.KYUIN_S_YM||''',
                     '''||dayRow.SNRYKMK_CD_01||''',
                     '''||dayRow.SNRYKMK_CD_02||''',
                     '''||dayRow.SNRYKMK_CD_03||''',
                     '''||dayRow.SNRYKMK_CD_04||''',
                     '''||dayRow.SNRYKMK_CD_05||''',
                     '''||dayRow.SNRYKMK_CD_06||''',
                     '''||dayRow.SNRYKMK_CD_07||''',
                     '''||dayRow.SNRYKMK_CD_08||''',
                     '''||dayRow.SNRYKMK_CD_09||''',
                     '''||dayRow.SNRYKMK_CD_10||''',
                     '''||dayRow.SNRYKMK_CD_11||''',
                     '''||dayRow.SNRYKMK_CD_12||''',
                     '''||dayRow.SNRYKMK_CD_13||''',
                     '''||dayRow.SNRYKMK_CD_14||''',
                     '''||dayRow.SNRYKMK_CD_15||''',
                     '''||dayRow.SNRYKMK_CD_16||''',
                     '''||dayRow.SNRYKMK_CD_17||''',
                     '''||dayRow.SNRYKMK_CD_18||''',
                     '''||dayRow.SNRYKMK_CD_19||''',
                     '''||dayRow.SNRYKMK_CD_20||''',
                     '''||dayRow.SNRYKMK_CD_21||''',
                     '''||dayRow.SNRYKMK_CD_22||''',
                     '''||dayRow.SNRYKMK_CD_23||''',
                     '''||dayRow.SNRYKMK_CD_24||''',
                     '''||dayRow.SNRYKMK_CD_25||''',
                     '''||dayRow.SNRYKMK_CD_26||''',
                     '''||dayRow.SNRYKMK_CD_27||''',
                     '''||dayRow.SNRYKMK_CD_28||''',
                     '''||dayRow.SNRYKMK_CD_29||''',
                     '''||dayRow.SNRYKMK_CD_30||''',
                     '''||dayRow.SNRYKMK_CD_31||''',
                     '''||dayRow.SNRYKMK_CD_32||''',
                     '''||dayRow.SNRYKMK_CD_33||''',
                     '''||dayRow.SNRYKMK_CD_34||''',
                     '''||dayRow.SNRYKMK_CD_35||''',
                     '''||dayRow.SNRYKMK_CD_36||''',
                     '''||dayRow.SNRYKMK_CD_37||''',
                     '''||dayRow.SNRYKMK_CD_38||''',
                     '''||dayRow.SNRYKMK_CD_39||''',
                     '''||dayRow.SNRYKMK_CD_40||''',
                     '''||dayRow.SNRYKMK_CD_41||''',
                     '''||dayRow.SNRYKMK_CD_42||''',
                     '''||dayRow.SNRYKMK_CD_43||''',
                     '''||dayRow.SNRYKMK_CD_44||''',
                     '''||dayRow.SNRYKMK_CD_45||''',
                     '''||dayRow.SNRYKMK_CD_46||''',
                     '''||dayRow.SNRYKMK_CD_47||''',
                     '''||dayRow.SNRYKMK_CD_48||''',
                     '''||dayRow.SNRYKMK_CD_49||''',
                     '''||dayRow.SNRYKMK_CD_50||''',
                     '''||dayRow.SNRYKMK_CD_51||''',
                     '''||dayRow.SNRYKMK_CD_52||''',
                     '''||dayRow.SNRYKMK_CD_53||''',
                     '''||dayRow.SNRYKMK_CD_54||''',
                     '''||dayRow.SNRYKMK_CD_55||''',
                     '''||dayRow.SNRYKMK_CD_56||''',
                     '''||dayRow.SNRYKMK_CD_57||''',
                     '''||dayRow.SNRYKMK_CD_58||''',
                     '''||dayRow.SNRYKMK_CD_59||''',
                     '''||dayRow.SNRYKMK_CD_60||''',
                     '''||dayRow.BYOIN_SBT_CD||''',
                     '''||dayRow.SAISHINSA_KBN_CD||''',
                     '''||dayRow.KANREN_DAIGAKU_OYA_REC_ID||''',
                     '''||dayRow.KANREN_DAIGAKU_OYA_SHI_CD||''',
                     '''||dayRow.BYOTO_HEISA_KBN||''',
                     '''||dayRow.SHI_BED_SU||''',
                     '''||dayRow.BED_SU_KKNN_EIGY_YMD||''',
                     '''||dayRow.KYOKA_BED_SU_GOKEI||''',
                     '''||dayRow.KYOKA_BED_SU_SEISHIN||''',
                     '''||dayRow.KYOKA_BED_SU_KEKKAKU||''',
                     '''||dayRow.KYOKA_BED_SU_KANSEN||''',
                     '''||dayRow.KYOKA_BED_SU_SONOTA||''',
                     '''||dayRow.KYOKA_BED_SU_IPPAN||''',
                     '''||dayRow.KYOKA_BED_SU_RYOYO||''',
                     '''||dayRow.KENSAKOMOKU_BISEIBUTSU_FLG||''',
                     '''||dayRow.KENSAKOMOKU_KESSEI_FLG||''',
                     '''||dayRow.KENSAKOMOKU_KETSUEKI_FLG||''',
                     '''||dayRow.KENSAKOMOKU_BYORI_FLG||''',
                     '''||dayRow.KENSAKOMOKU_KISEICHU_FLG||''',
                     '''||dayRow.KENSAKOMOKU_SEIKA_FLG||''',
                     '''||dayRow.KENSAKOMOKU_RI_FLG||''',
                     '''||dayRow.IMUSHITSU_REC_ID||''',
                     '''||dayRow.IMUSHITSU_SHI_CD||''',
                     '''||iOPE_CD||''',
                     '''||iDATE||''',
                     '''||iPGM_ID||''',
                     '''||iOPE_CD||''',
                     '''||iDATE||''',
                     '''||iPGM_ID||''')';
                     ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);
              END IF;
            
            END IF;
                   
          END LOOP;
          CLOSE dayCSR;
        END IF;
        
      ELSIF iShimeKind = ULT_COMMON.SHIME_SBT_CD_SHUSHIME THEN
        -- �T���߂̏ꍇ
        
          IF iLayoutKind = ULT_COMMON.LAYOUT_SBT_CD_SHIN THEN
            --�V_�T����_DCF�{�݃e�[�u���̃f�[�^���N���A����B
            EXECUTE_SQL := 'TRUNCATE TABLE ' || vSchemaNm || '.' || 'TD_NW_DCF_SHI';
            EXECUTE IMMEDIATE EXECUTE_SQL;
            ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);        
          END IF; 
          IF iLayoutKind = ULT_COMMON.LAYOUT_SBT_CD_ZANTEI THEN
            --�b��_�T����_DCF�{�݃e�[�u���̃f�[�^���N���A����B
            EXECUTE_SQL := 'TRUNCATE TABLE ' || vSchemaNm || '.' || 'TD_PW_DCF_SHI';
            EXECUTE IMMEDIATE EXECUTE_SQL;
            ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);        

            --�b��_�T����_���{�㖱���e�[�u���̃f�[�^���N���A����B
            EXECUTE_SQL := 'TRUNCATE TABLE ' || vSchemaNm || '.' || 'TD_PW_TOKUITBL';
            EXECUTE IMMEDIATE EXECUTE_SQL;
            ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);        
    
          END IF; 
        
          EXECUTE_SQL := 'SELECT                                                    
          TTS.REC_ID                              ,                                                  
          TTS.SHI_CD                              ,                                                  
          TTS.DEL_FLG                             ,                                                  
          TTS.DEL_YOTEI_RIYU_CD                   ,                                                  
          TTS.CHOFUKU_AITSK_REC_ID                ,                                                  
          TTS.CHOFUKU_AITSK_SHI_CD                ,                                                  
          TTS.KYUIN_FLG                           ,                                                  
          TTS.KYUIN_S_YM                          ,                                                  
          TTS.KAIGYO_YOTEI_FLG                    ,                                                  
          TTS.KAIGYO_YOTEI_YM                     ,                                                  
          TTS.KANREN_DAIGAKU_OYA_REC_ID           ,                                                  
          TTS.KANREN_DAIGAKU_OYA_SHI_CD           ,                                                  
          TTS.SEISHIKI_SHI_NM                     ,                                                  
          TTS.SEISHIKI_SHI_NM30                   ,                                                  
          TTS.SEISHIKI_SHI_NM_KANA                ,                                                  
          TTS.SEISHIKI_SHI_NM_KANA40              ,                                                  
          TTS.SHI_RN                              ,                                                  
          TTS.SHI_RN_KANA                         ,                                                  
          TTS.KEN_CD                              ,                                                  
          TTS.SHIKU_CD                            ,                                                  
          TTS.OAZA_CD                             ,                                                  
          TTS.AZA_CD                              ,                                                  
          TTS.ZIP                                 ,                                                  
          TTS.JUSHO_KANJI_RENKETSU                ,                                                  
          TTS.JUSHO_KANA_RENKETSU                 ,                                                  
          TTS.KEN_NM_KANJI_MOJI_SU                ,                                                  
          TTS.SHIKU_NM_KANJI_MOJI_SU              ,                                                  
          TTS.OAZA_NM_KANJI_MOJI_SU               ,                                                  
          TTS.AZA_NM_KANJI_MOJI_SU                ,                                                  
          TTS.KEN_NM_KANA_MOJI_SU                 ,                                                  
          TTS.SHIKU_NM_KANA_MOJI_SU               ,                                                  
          TTS.OAZA_NM_KANA_MOJI_SU                ,                                                  
          TTS.AZA_NM_KANA_MOJI_SU                 ,                                                  
          TTS.JUSHO_HYOJI_NO                      ,                                                  
          TTS.JUSHOFUMEI_CD                       ,                                                  
          TTS.TEL                                 ,                                                  
          TTS.KEIEITAI_CD                         ,                                                  
          TTS.SHI_KBN_CD                          ,                                                  
          TTS.IMUSHITSU_REC_ID                    ,                                                  
          TTS.IMUSHITSU_SHI_CD                    ,                                                  
          TTS.SAISHINSA_KBN_CD                    ,                                                  
          TTS.BYOTO_HEISA_KBN                     ,                                                  
          TTS.TEL_NASHI_FLG                       ,                                                  
          TTS.MIKAKUNIN_FLG                       ,                                                  
          TTS.DAIHYO_REC_ID                       ,                                                  
          TTS.DAIHYO_KJN_CD                       ,                                                  
          TTK.KJN_NM                            ,                                                  
          TTK.KJN_NM_KANA                     ,                                                  
          TO_CHAR(TTS.SHI_BED_SU,''FM9999'') AS SHI_BED_SU,                                                  
          TTS.BYOIN_SBT_CD                        ,                                                  
          TO_CHAR(TTS.KYOKA_BED_SU_SONOTA,''FM9999'') AS KYOKA_BED_SU_SONOTA,                                                  
          TO_CHAR(TTS.KYOKA_BED_SU_SEISHIN,''FM9999'') AS KYOKA_BED_SU_SEISHIN,                                                  
          TO_CHAR(TTS.KYOKA_BED_SU_KEKKAKU,''FM9999'') AS KYOKA_BED_SU_KEKKAKU,                                                  
          TO_CHAR(TTS.KYOKA_BED_SU_KANSEN,''FM9999'') AS KYOKA_BED_SU_KANSEN,                                                  
          TO_CHAR(TTS.KYOKA_BED_SU_GOKEI,''FM9999'') AS KYOKA_BED_SU_GOKEI,                                                  
          TO_CHAR(TTS.KYOKA_BED_SU_IPPAN,''FM9999'') AS KYOKA_BED_SU_IPPAN,                                                  
          TTS.KYOKA_BED_SU_RYOYO                  ,                                                  
          TTS.BED_SU_KKNN_EIGY_YMD                ,                                                  
          TTS.SNRYKMK_CD_01                       ,                                                  
          TTS.SNRYKMK_CD_02                       ,                                                  
          TTS.SNRYKMK_CD_03                       ,                                                  
          TTS.SNRYKMK_CD_04                       ,                                                  
          TTS.SNRYKMK_CD_05                       ,                                                  
          TTS.SNRYKMK_CD_06                       ,                                                  
          TTS.SNRYKMK_CD_07                       ,                                                  
          TTS.SNRYKMK_CD_08                       ,                                                  
          TTS.SNRYKMK_CD_09                       ,                                                  
          TTS.SNRYKMK_CD_10                       ,                                                  
          TTS.SNRYKMK_CD_11                       ,                                                  
          TTS.SNRYKMK_CD_12                       ,                                                  
          TTS.SNRYKMK_CD_13                       ,                                                  
          TTS.SNRYKMK_CD_14                       ,                                                  
          TTS.SNRYKMK_CD_15                       ,                                                  
          TTS.SNRYKMK_CD_16                       ,                                                  
          TTS.SNRYKMK_CD_17                       ,                                                  
          TTS.SNRYKMK_CD_18                       ,                                                  
          TTS.SNRYKMK_CD_19                       ,                                                  
          TTS.SNRYKMK_CD_20                       ,                                                  
          TTS.SNRYKMK_CD_21                       ,                                                  
          TTS.SNRYKMK_CD_22                       ,                                                  
          TTS.SNRYKMK_CD_23                       ,                                                  
          TTS.SNRYKMK_CD_24                       ,                                                  
          TTS.SNRYKMK_CD_25                       ,                                                  
          TTS.SNRYKMK_CD_26                       ,                                                  
          TTS.SNRYKMK_CD_27                       ,                                                  
          TTS.SNRYKMK_CD_28                       ,                                                  
          TTS.SNRYKMK_CD_29                       ,                                                  
          TTS.SNRYKMK_CD_30                       ,                                                  
          TTS.SNRYKMK_CD_31                       ,                                                  
          TTS.SNRYKMK_CD_32                       ,                                                  
          TTS.SNRYKMK_CD_33                       ,                                                  
          TTS.SNRYKMK_CD_34                       ,                                                  
          TTS.SNRYKMK_CD_35                       ,                                                  
          TTS.SNRYKMK_CD_36                       ,                                                  
          TTS.SNRYKMK_CD_37                       ,                                                  
          TTS.SNRYKMK_CD_38                       ,                                                  
          TTS.SNRYKMK_CD_39                       ,                                                  
          TTS.SNRYKMK_CD_40                       ,                                                  
          TTS.SNRYKMK_CD_41                       ,                                                  
          TTS.SNRYKMK_CD_42                       ,                                                  
          TTS.SNRYKMK_CD_43                       ,                                                  
          TTS.SNRYKMK_CD_44                       ,                                                  
          TTS.SNRYKMK_CD_45                       ,                                                  
          TTS.SNRYKMK_CD_46                       ,                                                  
          TTS.SNRYKMK_CD_47                       ,                                                  
          TTS.SNRYKMK_CD_48                       ,                                                  
          TTS.SNRYKMK_CD_49                       ,                                                  
          TTS.SNRYKMK_CD_50                       ,                                                  
          TTS.SNRYKMK_CD_51                       ,                                                  
          TTS.SNRYKMK_CD_52                       ,                                                  
          TTS.SNRYKMK_CD_53                       ,                                                  
          TTS.SNRYKMK_CD_54                       ,                                                  
          TTS.SNRYKMK_CD_55                       ,                                                  
          TTS.SNRYKMK_CD_56                       ,                                                  
          TTS.SNRYKMK_CD_57                       ,                                                  
          TTS.SNRYKMK_CD_58                       ,                                                  
          TTS.SNRYKMK_CD_59                       ,                                                  
          TTS.SNRYKMK_CD_60                       ,                                                  
          TTS.KENSAKOMOKU_BISEIBUTSU_FLG          ,                                                  
          TTS.KENSAKOMOKU_KESSEI_FLG              ,                                                  
          TTS.KENSAKOMOKU_KETSUEKI_FLG            ,                                                  
          TTS.KENSAKOMOKU_BYORI_FLG               ,                                                  
          TTS.KENSAKOMOKU_KISEICHU_FLG            ,                                                  
          TTS.KENSAKOMOKU_SEIKA_FLG               ,                                                  
          TTS.KENSAKOMOKU_RI_FLG                  ,                                                  
          TTS.UPD_EIGY_YMD ,                                                                                                           
          TZWS.REC_ID                              AS  zREC_ID                              ,                                                  
          TZWS.SHI_CD                              AS  zSHI_CD                              ,                                                  
          TZWS.DEL_FLG                             AS  zDEL_FLG                             ,                                                  
          TZWS.DEL_YOTEI_RIYU_CD                   AS  zDEL_YOTEI_RIYU_CD                   ,                                                  
          TZWS.CHOFUKU_AITSK_REC_ID                AS  zCHOFUKU_AITSK_REC_ID                ,                                                  
          TZWS.CHOFUKU_AITSK_SHI_CD                AS  zCHOFUKU_AITSK_SHI_CD                ,                                                  
          TZWS.KYUIN_FLG                           AS  zKYUIN_FLG                           ,                                                  
          TZWS.KYUIN_S_YM                          AS  zKYUIN_S_YM                          ,                                                  
          TZWS.KAIGYO_YOTEI_FLG                    AS  zKAIGYO_YOTEI_FLG                    ,                                                  
          TZWS.KAIGYO_YOTEI_YM                     AS  zKAIGYO_YOTEI_YM                     ,                                                  
          TZWS.KANREN_DAIGAKU_OYA_REC_ID           AS  zKANREN_DAIGAKU_OYA_REC_ID           ,                                                  
          TZWS.KANREN_DAIGAKU_OYA_SHI_CD           AS  zKANREN_DAIGAKU_OYA_SHI_CD           ,                                                  
          TZWS.SEISHIKI_SHI_NM                     AS  zSEISHIKI_SHI_NM                     ,                                                  
          TZWS.SEISHIKI_SHI_NM30                   AS  zSEISHIKI_SHI_NM30                   ,                                                  
          TZWS.SEISHIKI_SHI_NM_KANA                AS  zSEISHIKI_SHI_NM_KANA                ,                                                  
          TZWS.SEISHIKI_SHI_NM_KANA40              AS  zSEISHIKI_SHI_NM_KANA40              ,                                                  
          TZWS.SHI_RN                              AS  zSHI_RN                              ,                                                  
          TZWS.SHI_RN_KANA                         AS  zSHI_RN_KANA                         ,                                                  
          TZWS.KEN_CD                              AS  zKEN_CD                              ,                                                  
          TZWS.SHIKU_CD                            AS  zSHIKU_CD                            ,                                                  
          TZWS.OAZA_CD                             AS  zOAZA_CD                             ,                                                  
          TZWS.AZA_CD                              AS  zAZA_CD                              ,                                                  
          TZWS.ZIP                                 AS  zZIP                                 ,                                                  
          TZWS.JUSHO_KANJI_RENKETSU                AS  zJUSHO_KANJI_RENKETSU                ,                                                  
          TZWS.JUSHO_KANA_RENKETSU                 AS  zJUSHO_KANA_RENKETSU                 ,                                                  
          TZWS.KEN_NM_KANJI_MOJI_SU                AS  zKEN_NM_KANJI_MOJI_SU                ,                                                  
          TZWS.SHIKU_NM_KANJI_MOJI_SU              AS  zSHIKU_NM_KANJI_MOJI_SU              ,                                                  
          TZWS.OAZA_NM_KANJI_MOJI_SU               AS  zOAZA_NM_KANJI_MOJI_SU               ,                                                  
          TZWS.AZA_NM_KANJI_MOJI_SU                AS  zAZA_NM_KANJI_MOJI_SU                ,                                                  
          TZWS.KEN_NM_KANA_MOJI_SU                 AS  zKEN_NM_KANA_MOJI_SU                 ,                                                  
          TZWS.SHIKU_NM_KANA_MOJI_SU               AS  zSHIKU_NM_KANA_MOJI_SU               ,                                                  
          TZWS.OAZA_NM_KANA_MOJI_SU                AS  zOAZA_NM_KANA_MOJI_SU                ,                                                  
          TZWS.AZA_NM_KANA_MOJI_SU                 AS  zAZA_NM_KANA_MOJI_SU                 ,                                                  
          TZWS.JUSHO_HYOJI_NO                      AS  zJUSHO_HYOJI_NO                      ,                                                  
          TZWS.JUSHOFUMEI_CD                       AS  zJUSHOFUMEI_CD                       ,                                                  
          TZWS.TEL                                 AS  zTEL                                 ,                                                  
          TZWS.KEIEITAI_CD                         AS  zKEIEITAI_CD                         ,                                                  
          TZWS.SHI_KBN_CD                          AS  zSHI_KBN_CD                          ,                                                  
          TZWS.IMUSHITSU_REC_ID                    AS  zIMUSHITSU_REC_ID                    ,                                                  
          TZWS.IMUSHITSU_SHI_CD                    AS  zIMUSHITSU_SHI_CD                    ,                                                  
          TZWS.SAISHINSA_KBN_CD                    AS  zSAISHINSA_KBN_CD                    ,                                                  
          TZWS.BYOTO_HEISA_KBN                     AS  zBYOTO_HEISA_KBN                     ,                                                  
          TZWS.TEL_NASHI_FLG                       AS  zTEL_NASHI_FLG                       ,                                                  
          TZWS.MIKAKUNIN_FLG                       AS  zMIKAKUNIN_FLG                       ,                                                  
          TZWS.DAIHYO_REC_ID                       AS  zDAIHYO_REC_ID                       ,                                                  
          TZWS.DAIHYO_KJN_CD                       AS  zDAIHYO_KJN_CD                       ,                                                  
          TZWK.KJN_NM                              AS  zKJN_NM                              ,                                                  
          TZWK.KJN_NM_KANA                         AS  zKJN_NM_KANA                         ,                                                  
          TO_CHAR(TZWS.SHI_BED_SU,''FM9999'')        AS  zSHI_BED_SU                          ,                                                  
          TZWS.BYOIN_SBT_CD                        AS  zBYOIN_SBT_CD                        ,                                                  
          TO_CHAR(TZWS.KYOKA_BED_SU_SONOTA,''FM9999'') AS  zKYOKA_BED_SU_SONOTA                 ,                                                  
          TO_CHAR(TZWS.KYOKA_BED_SU_SEISHIN,''FM9999'') AS  zKYOKA_BED_SU_SEISHIN                ,                                                  
          TO_CHAR(TZWS.KYOKA_BED_SU_KEKKAKU,''FM9999'') AS  zKYOKA_BED_SU_KEKKAKU                ,                                                  
          TO_CHAR(TZWS.KYOKA_BED_SU_KANSEN,''FM9999'') AS  zKYOKA_BED_SU_KANSEN                 ,                                                  
          TO_CHAR(TZWS.KYOKA_BED_SU_GOKEI,''FM9999'') AS  zKYOKA_BED_SU_GOKEI                  ,                                                  
          TO_CHAR(TZWS.KYOKA_BED_SU_IPPAN,''FM9999'') AS  zKYOKA_BED_SU_IPPAN                  ,                                                  
          TZWS.KYOKA_BED_SU_RYOYO                  AS  zKYOKA_BED_SU_RYOYO                  ,                                                  
          TZWS.BED_SU_KKNN_EIGY_YMD                AS  zBED_SU_KKNN_EIGY_YMD                ,                                                  
          TZWS.SNRYKMK_CD_01                       AS  zSNRYKMK_CD_01                       ,                                                  
          TZWS.SNRYKMK_CD_02                       AS  zSNRYKMK_CD_02                       ,                                                  
          TZWS.SNRYKMK_CD_03                       AS  zSNRYKMK_CD_03                       ,                                                  
          TZWS.SNRYKMK_CD_04                       AS  zSNRYKMK_CD_04                       ,                                                  
          TZWS.SNRYKMK_CD_05                       AS  zSNRYKMK_CD_05                       ,                                                  
          TZWS.SNRYKMK_CD_06                       AS  zSNRYKMK_CD_06                       ,                                                  
          TZWS.SNRYKMK_CD_07                       AS  zSNRYKMK_CD_07                       ,                                                  
          TZWS.SNRYKMK_CD_08                       AS  zSNRYKMK_CD_08                       ,                                                  
          TZWS.SNRYKMK_CD_09                       AS  zSNRYKMK_CD_09                       ,                                                  
          TZWS.SNRYKMK_CD_10                       AS  zSNRYKMK_CD_10                       ,                                                  
          TZWS.SNRYKMK_CD_11                       AS  zSNRYKMK_CD_11                       ,                                                  
          TZWS.SNRYKMK_CD_12                       AS  zSNRYKMK_CD_12                       ,                                                  
          TZWS.SNRYKMK_CD_13                       AS  zSNRYKMK_CD_13                       ,                                                  
          TZWS.SNRYKMK_CD_14                       AS  zSNRYKMK_CD_14                       ,                                                  
          TZWS.SNRYKMK_CD_15                       AS  zSNRYKMK_CD_15                       ,                                                  
          TZWS.SNRYKMK_CD_16                       AS  zSNRYKMK_CD_16                       ,                                                  
          TZWS.SNRYKMK_CD_17                       AS  zSNRYKMK_CD_17                       ,                                                  
          TZWS.SNRYKMK_CD_18                       AS  zSNRYKMK_CD_18                       ,                                                  
          TZWS.SNRYKMK_CD_19                       AS  zSNRYKMK_CD_19                       ,                                                  
          TZWS.SNRYKMK_CD_20                       AS  zSNRYKMK_CD_20                       ,                                                  
          TZWS.SNRYKMK_CD_21                       AS  zSNRYKMK_CD_21                       ,                                                  
          TZWS.SNRYKMK_CD_22                       AS  zSNRYKMK_CD_22                       ,                                                  
          TZWS.SNRYKMK_CD_23                       AS  zSNRYKMK_CD_23                       ,                                                  
          TZWS.SNRYKMK_CD_24                       AS  zSNRYKMK_CD_24                       ,                                                  
          TZWS.SNRYKMK_CD_25                       AS  zSNRYKMK_CD_25                       ,                                                  
          TZWS.SNRYKMK_CD_26                       AS  zSNRYKMK_CD_26                       ,                                                  
          TZWS.SNRYKMK_CD_27                       AS  zSNRYKMK_CD_27                       ,                                                  
          TZWS.SNRYKMK_CD_28                       AS  zSNRYKMK_CD_28                       ,                                                  
          TZWS.SNRYKMK_CD_29                       AS  zSNRYKMK_CD_29                       ,                                                  
          TZWS.SNRYKMK_CD_30                       AS  zSNRYKMK_CD_30                       ,                                                  
          TZWS.SNRYKMK_CD_31                       AS  zSNRYKMK_CD_31                       ,                                                  
          TZWS.SNRYKMK_CD_32                       AS  zSNRYKMK_CD_32                       ,                                                  
          TZWS.SNRYKMK_CD_33                       AS  zSNRYKMK_CD_33                       ,                                                  
          TZWS.SNRYKMK_CD_34                       AS  zSNRYKMK_CD_34                       ,                                                  
          TZWS.SNRYKMK_CD_35                       AS  zSNRYKMK_CD_35                       ,                                                  
          TZWS.SNRYKMK_CD_36                       AS  zSNRYKMK_CD_36                       ,                                                  
          TZWS.SNRYKMK_CD_37                       AS  zSNRYKMK_CD_37                       ,                                                  
          TZWS.SNRYKMK_CD_38                       AS  zSNRYKMK_CD_38                       ,                                                  
          TZWS.SNRYKMK_CD_39                       AS  zSNRYKMK_CD_39                       ,                                                  
          TZWS.SNRYKMK_CD_40                       AS  zSNRYKMK_CD_40                       ,                                                  
          TZWS.SNRYKMK_CD_41                       AS  zSNRYKMK_CD_41                       ,                                                  
          TZWS.SNRYKMK_CD_42                       AS  zSNRYKMK_CD_42                       ,                                                  
          TZWS.SNRYKMK_CD_43                       AS  zSNRYKMK_CD_43                       ,                                                  
          TZWS.SNRYKMK_CD_44                       AS  zSNRYKMK_CD_44                       ,                                                  
          TZWS.SNRYKMK_CD_45                       AS  zSNRYKMK_CD_45                       ,                                                  
          TZWS.SNRYKMK_CD_46                       AS  zSNRYKMK_CD_46                       ,                                                  
          TZWS.SNRYKMK_CD_47                       AS  zSNRYKMK_CD_47                       ,                                                  
          TZWS.SNRYKMK_CD_48                       AS  zSNRYKMK_CD_48                       ,                                                  
          TZWS.SNRYKMK_CD_49                       AS  zSNRYKMK_CD_49                       ,                                                  
          TZWS.SNRYKMK_CD_50                       AS  zSNRYKMK_CD_50                       ,                                                  
          TZWS.SNRYKMK_CD_51                       AS  zSNRYKMK_CD_51                       ,                                                  
          TZWS.SNRYKMK_CD_52                       AS  zSNRYKMK_CD_52                       ,                                                  
          TZWS.SNRYKMK_CD_53                       AS  zSNRYKMK_CD_53                       ,                                  								
          TZWS.SNRYKMK_CD_54                       AS  zSNRYKMK_CD_54                       ,																									
          TZWS.SNRYKMK_CD_55                       AS  zSNRYKMK_CD_55                       ,																									
          TZWS.SNRYKMK_CD_56                       AS  zSNRYKMK_CD_56                       ,																									
          TZWS.SNRYKMK_CD_57                       AS  zSNRYKMK_CD_57                       ,																									
          TZWS.SNRYKMK_CD_58                       AS  zSNRYKMK_CD_58                       ,																									
          TZWS.SNRYKMK_CD_59                       AS  zSNRYKMK_CD_59                       ,																									
          TZWS.SNRYKMK_CD_60                       AS  zSNRYKMK_CD_60                       ,																									
          TZWS.KENSAKOMOKU_BISEIBUTSU_FLG          AS  zKENSAKOMOKU_BISEIBUTSU_FLG          ,																									
          TZWS.KENSAKOMOKU_KESSEI_FLG              AS  zKENSAKOMOKU_KESSEI_FLG              ,																									
          TZWS.KENSAKOMOKU_KETSUEKI_FLG            AS  zKENSAKOMOKU_KETSUEKI_FLG            ,																									
          TZWS.KENSAKOMOKU_BYORI_FLG               AS  zKENSAKOMOKU_BYORI_FLG               ,																									
          TZWS.KENSAKOMOKU_KISEICHU_FLG            AS  zKENSAKOMOKU_KISEICHU_FLG            ,																									
          TZWS.KENSAKOMOKU_SEIKA_FLG               AS  zKENSAKOMOKU_SEIKA_FLG               ,																									
          TZWS.KENSAKOMOKU_RI_FLG                  AS  zKENSAKOMOKU_RI_FLG                  ,																									
          TZWS.UPD_EIGY_YMD                        AS  zUPD_EIGY_YMD	
          FROM TT_TIKY_SHI�@TTS						
          LEFT OUTER JOIN TT_TIKY_KJN TTK										
          ON  TTS.DAIHYO_REC_ID = TTK.REC_ID										
          AND TTS.DAIHYO_KJN_CD = TTK.KJN_CD										
          AND TTK.DEL_FLG IS NULL										
          LEFT OUTER JOIN TT_Z_W_SHI�@TZWS										
          ON  TTS.REC_ID = TZWS.REC_ID										
          AND TTS.SHI_CD = TZWS.SHI_CD										
          LEFT OUTER JOIN TT_Z_W_KJN TZWK										
          ON  TZWS.DAIHYO_REC_ID = TZWK.REC_ID										
          AND TZWS.DAIHYO_KJN_CD = TZWK.KJN_CD
          WHERE�@TTS.REC_ID�@= ''00''																	
             AND TTS.UPD_EIGY_YMD�@>= NVL(iShimeFrom, ''19700101'')																
             AND TTS.UPD_EIGY_YMD�@<= iShimeTo' ;
          ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);   
          -- �擾�����f��DB�f�[�^���������J��Ԃ�
          OPEN weekCSR ;
          LOOP
            FETCH weekCSR INTO weekRow;     
            EXIT WHEN weekCSR%NOTFOUND; 
            vSPECIAL_FLG_1 :=0;
            oROW_COUNT:=oROW_COUNT+1;
            --�O���r���R�[�h�̎{�݃R�[�h�ƃ��R�[�hID��NULL�ł͂Ȃ����A
            IF weekRow.zREC_ID IS NOT  NULL AND weekRow.zSHI_CD IS NOT  NULL THEN
              --�񋟗p���R�[�h�̍폜�t���O = "1"�̎��A 
              IF weekRow.DEL_FLG = '1' THEN
                vMODKBN := ULT_COMMON.MOD_KBN_DEL;
              ELSE
                --�񋟗p���R�[�h�Ǝ擾�����O���r���R�[�h���r
                IF '1'||weekRow.MIKAKUNIN_FLG = '1'||weekRow.zMIKAKUNIN_FLG     
                  AND '1'||weekRow.DEL_YOTEI_RIYU_CD = '1'||weekRow.zDEL_YOTEI_RIYU_CD
                  AND '1'||weekRow.CHOFUKU_AITSK_REC_ID = '1'||weekRow.zCHOFUKU_AITSK_REC_ID
                  AND '1'||weekRow.CHOFUKU_AITSK_SHI_CD = '1'||weekRow.zCHOFUKU_AITSK_SHI_CD                  
                  AND '1'||weekRow.SEISHIKI_SHI_NM = '1'||weekRow.zSEISHIKI_SHI_NM
                  AND '1'||weekRow.SEISHIKI_SHI_NM_KANA = '1'||weekRow.zSEISHIKI_SHI_NM_KANA
                  AND '1'||weekRow.SHI_RN = '1'||weekRow.zSHI_RN
                  AND '1'||weekRow.SHI_RN_KANA = '1'||weekRow.zSHI_RN_KANA
                  AND '1'||weekRow.JUSHOFUMEI_CD = '1'||weekRow.zJUSHOFUMEI_CD
                  AND '1'||weekRow.KEN_CD = '1'||weekRow.zKEN_CD
                  AND '1'||weekRow.SHIKU_CD = '1'||weekRow.zSHIKU_CD
                  AND '1'||weekRow.OAZA_CD = '1'||weekRow.zOAZA_CD
                  AND '1'||weekRow.AZA_CD = '1'||weekRow.zAZA_CD
                  AND '1'||weekRow.ZIP = '1'||weekRow.zZIP
                  AND '1'||weekRow.JUSHO_KANJI_RENKETSU = '1'||weekRow.zJUSHO_KANJI_RENKETSU
                  AND '1'||weekRow.JUSHO_KANA_RENKETSU = '1'||weekRow.zJUSHO_KANA_RENKETSU
                  AND '1'||weekRow.JUSHO_HYOJI_NO = '1'||weekRow.zJUSHO_HYOJI_NO
                  AND '1'||weekRow.KEN_NM_KANJI_MOJI_SU = '1'||weekRow.zKEN_NM_KANJI_MOJI_SU
                  AND '1'||weekRow.SHIKU_NM_KANJI_MOJI_SU = '1'||weekRow.zSHIKU_NM_KANJI_MOJI_SU
                  AND '1'||weekRow.OAZA_NM_KANJI_MOJI_SU = '1'||weekRow.zOAZA_NM_KANJI_MOJI_SU
                  AND '1'||weekRow.AZA_NM_KANJI_MOJI_SU = '1'||weekRow.zAZA_NM_KANJI_MOJI_SU
                  AND '1'||weekRow.KEN_NM_KANA_MOJI_SU = '1'||weekRow.zKEN_NM_KANA_MOJI_SU
                  AND '1'||weekRow.SHIKU_NM_KANA_MOJI_SU = '1'||weekRow.zSHIKU_NM_KANA_MOJI_SU
                  AND '1'||weekRow.OAZA_NM_KANA_MOJI_SU = '1'||weekRow.zOAZA_NM_KANA_MOJI_SU
                  AND '1'||weekRow.AZA_NM_KANA_MOJI_SU = '1'||weekRow.zAZA_NM_KANA_MOJI_SU
                  AND '1'||weekRow.TEL_NASHI_FLG = '1'||weekRow.zTEL_NASHI_FLG
                  AND '1'||weekRow.TEL = '1'||weekRow.zTEL
                  AND '1'||weekRow.KEIEITAI_CD = '1'||weekRow.zKEIEITAI_CD
                  AND '1'||weekRow.SHI_KBN_CD = '1'||weekRow.zSHI_KBN_CD
                  AND '1'||weekRow.DAIHYO_REC_ID = '1'||weekRow.zDAIHYO_REC_ID
                  AND '1'||weekRow.DAIHYO_KJN_CD = '1'||weekRow.zDAIHYO_KJN_CD
                  AND '1'||weekRow.KJN_NM = '1'||weekRow.zKJN_NM
                  AND '1'||weekRow.KJN_NM_KANA = '1'||weekRow.zKJN_NM_KANA
                  AND '1'||weekRow.KAIGYO_YOTEI_FLG = '1'||weekRow.zKAIGYO_YOTEI_FLG
                  AND '1'||weekRow.KAIGYO_YOTEI_YM = '1'||weekRow.zKAIGYO_YOTEI_YM
                  AND '1'||weekRow.KYUIN_FLG = '1'||weekRow.zKYUIN_FLG
                  AND '1'||weekRow.KYUIN_S_YM = '1'||weekRow.zKYUIN_S_YM
                  AND '1'||weekRow.SNRYKMK_CD_01 = '1'||weekRow.zSNRYKMK_CD_01
                  AND '1'||weekRow.SNRYKMK_CD_02 = '1'||weekRow.zSNRYKMK_CD_02
                  AND '1'||weekRow.SNRYKMK_CD_03 = '1'||weekRow.zSNRYKMK_CD_03
                  AND '1'||weekRow.SNRYKMK_CD_04 = '1'||weekRow.zSNRYKMK_CD_04
                  AND '1'||weekRow.SNRYKMK_CD_05 = '1'||weekRow.zSNRYKMK_CD_05
                  AND '1'||weekRow.SNRYKMK_CD_06 = '1'||weekRow.zSNRYKMK_CD_06
                  AND '1'||weekRow.SNRYKMK_CD_07 = '1'||weekRow.zSNRYKMK_CD_07
                  AND '1'||weekRow.SNRYKMK_CD_08 = '1'||weekRow.zSNRYKMK_CD_08
                  AND '1'||weekRow.SNRYKMK_CD_09 = '1'||weekRow.zSNRYKMK_CD_09
                  AND '1'||weekRow.SNRYKMK_CD_10 = '1'||weekRow.zSNRYKMK_CD_10
                  AND '1'||weekRow.SNRYKMK_CD_11 = '1'||weekRow.zSNRYKMK_CD_11
                  AND '1'||weekRow.SNRYKMK_CD_12 = '1'||weekRow.zSNRYKMK_CD_12
                  AND '1'||weekRow.SNRYKMK_CD_13 = '1'||weekRow.zSNRYKMK_CD_13
                  AND '1'||weekRow.SNRYKMK_CD_14 = '1'||weekRow.zSNRYKMK_CD_14
                  AND '1'||weekRow.SNRYKMK_CD_15 = '1'||weekRow.zSNRYKMK_CD_15
                  AND '1'||weekRow.SNRYKMK_CD_16 = '1'||weekRow.zSNRYKMK_CD_16
                  AND '1'||weekRow.SNRYKMK_CD_17 = '1'||weekRow.zSNRYKMK_CD_17
                  AND '1'||weekRow.SNRYKMK_CD_18 = '1'||weekRow.zSNRYKMK_CD_18
                  AND '1'||weekRow.SNRYKMK_CD_19 = '1'||weekRow.zSNRYKMK_CD_19
                  AND '1'||weekRow.SNRYKMK_CD_20 = '1'||weekRow.zSNRYKMK_CD_20
                  AND '1'||weekRow.SNRYKMK_CD_21 = '1'||weekRow.zSNRYKMK_CD_21
                  AND '1'||weekRow.SNRYKMK_CD_22 = '1'||weekRow.zSNRYKMK_CD_22
                  AND '1'||weekRow.SNRYKMK_CD_23 = '1'||weekRow.zSNRYKMK_CD_23
                  AND '1'||weekRow.SNRYKMK_CD_24 = '1'||weekRow.zSNRYKMK_CD_24
                  AND '1'||weekRow.SNRYKMK_CD_25 = '1'||weekRow.zSNRYKMK_CD_25
                  AND '1'||weekRow.SNRYKMK_CD_26 = '1'||weekRow.zSNRYKMK_CD_26
                  AND '1'||weekRow.SNRYKMK_CD_27 = '1'||weekRow.zSNRYKMK_CD_27
                  AND '1'||weekRow.SNRYKMK_CD_28 = '1'||weekRow.zSNRYKMK_CD_28
                  AND '1'||weekRow.SNRYKMK_CD_29 = '1'||weekRow.zSNRYKMK_CD_29
                  AND '1'||weekRow.SNRYKMK_CD_30 = '1'||weekRow.zSNRYKMK_CD_30
                  AND '1'||weekRow.SNRYKMK_CD_31 = '1'||weekRow.zSNRYKMK_CD_31
                  AND '1'||weekRow.SNRYKMK_CD_32 = '1'||weekRow.zSNRYKMK_CD_32
                  AND '1'||weekRow.SNRYKMK_CD_33 = '1'||weekRow.zSNRYKMK_CD_33
                  AND '1'||weekRow.SNRYKMK_CD_34 = '1'||weekRow.zSNRYKMK_CD_34
                  AND '1'||weekRow.SNRYKMK_CD_35 = '1'||weekRow.zSNRYKMK_CD_35
                  AND '1'||weekRow.SNRYKMK_CD_36 = '1'||weekRow.zSNRYKMK_CD_36
                  AND '1'||weekRow.SNRYKMK_CD_37 = '1'||weekRow.zSNRYKMK_CD_37
                  AND '1'||weekRow.SNRYKMK_CD_38 = '1'||weekRow.zSNRYKMK_CD_38
                  AND '1'||weekRow.SNRYKMK_CD_39 = '1'||weekRow.zSNRYKMK_CD_39
                  AND '1'||weekRow.SNRYKMK_CD_40 = '1'||weekRow.zSNRYKMK_CD_40
                  AND '1'||weekRow.SNRYKMK_CD_41 = '1'||weekRow.zSNRYKMK_CD_41
                  AND '1'||weekRow.SNRYKMK_CD_42 = '1'||weekRow.zSNRYKMK_CD_42
                  AND '1'||weekRow.SNRYKMK_CD_43 = '1'||weekRow.zSNRYKMK_CD_43
                  AND '1'||weekRow.SNRYKMK_CD_44 = '1'||weekRow.zSNRYKMK_CD_44
                  AND '1'||weekRow.SNRYKMK_CD_45 = '1'||weekRow.zSNRYKMK_CD_45
                  AND '1'||weekRow.SNRYKMK_CD_46 = '1'||weekRow.zSNRYKMK_CD_46
                  AND '1'||weekRow.SNRYKMK_CD_47 = '1'||weekRow.zSNRYKMK_CD_47
                  AND '1'||weekRow.SNRYKMK_CD_48 = '1'||weekRow.zSNRYKMK_CD_48
                  AND '1'||weekRow.SNRYKMK_CD_49 = '1'||weekRow.zSNRYKMK_CD_49
                  AND '1'||weekRow.SNRYKMK_CD_50 = '1'||weekRow.zSNRYKMK_CD_50
                  AND '1'||weekRow.SNRYKMK_CD_51 = '1'||weekRow.zSNRYKMK_CD_51
                  AND '1'||weekRow.SNRYKMK_CD_52 = '1'||weekRow.zSNRYKMK_CD_52
                  AND '1'||weekRow.SNRYKMK_CD_53 = '1'||weekRow.zSNRYKMK_CD_53
                  AND '1'||weekRow.SNRYKMK_CD_54 = '1'||weekRow.zSNRYKMK_CD_54
                  AND '1'||weekRow.SNRYKMK_CD_55 = '1'||weekRow.zSNRYKMK_CD_55
                  AND '1'||weekRow.SNRYKMK_CD_56 = '1'||weekRow.zSNRYKMK_CD_56
                  AND '1'||weekRow.SNRYKMK_CD_57 = '1'||weekRow.zSNRYKMK_CD_57
                  AND '1'||weekRow.SNRYKMK_CD_58 = '1'||weekRow.zSNRYKMK_CD_58
                  AND '1'||weekRow.SNRYKMK_CD_59 = '1'||weekRow.zSNRYKMK_CD_59
                  AND '1'||weekRow.SNRYKMK_CD_60 = '1'||weekRow.zSNRYKMK_CD_60
                  AND '1'||weekRow.BYOIN_SBT_CD = '1'||weekRow.zBYOIN_SBT_CD
                  AND '1'||weekRow.SAISHINSA_KBN_CD = '1'||weekRow.zSAISHINSA_KBN_CD
                  AND '1'||weekRow.KANREN_DAIGAKU_OYA_REC_ID = '1'||weekRow.zKANREN_DAIGAKU_OYA_REC_ID
                  AND '1'||weekRow.KANREN_DAIGAKU_OYA_SHI_CD = '1'||weekRow.zKANREN_DAIGAKU_OYA_SHI_CD
                  AND '1'||weekRow.BYOTO_HEISA_KBN = '1'||weekRow.zBYOTO_HEISA_KBN
                  AND '1'||weekRow.SHI_BED_SU = '1'||weekRow.zSHI_BED_SU
                  AND '1'||weekRow.BED_SU_KKNN_EIGY_YMD = '1'||weekRow.zBED_SU_KKNN_EIGY_YMD
                  AND '1'||weekRow.KYOKA_BED_SU_GOKEI = '1'||weekRow.zKYOKA_BED_SU_GOKEI
                  AND '1'||weekRow.KYOKA_BED_SU_SEISHIN = '1'||weekRow.zKYOKA_BED_SU_SEISHIN
                  AND '1'||weekRow.KYOKA_BED_SU_KEKKAKU = '1'||weekRow.zKYOKA_BED_SU_KEKKAKU
                  AND '1'||weekRow.KYOKA_BED_SU_KANSEN = '1'||weekRow.zKYOKA_BED_SU_KANSEN
                  AND '1'||weekRow.KYOKA_BED_SU_SONOTA = '1'||weekRow.zKYOKA_BED_SU_SONOTA
                  AND '1'||weekRow.KYOKA_BED_SU_IPPAN = '1'||weekRow.zKYOKA_BED_SU_IPPAN
                  AND '1'||weekRow.KYOKA_BED_SU_RYOYO = '1'||weekRow.zKYOKA_BED_SU_RYOYO
                  AND '1'||weekRow.KENSAKOMOKU_BISEIBUTSU_FLG = '1'||weekRow.zKENSAKOMOKU_BISEIBUTSU_FLG
                  AND '1'||weekRow.KENSAKOMOKU_KESSEI_FLG = '1'||weekRow.zKENSAKOMOKU_KESSEI_FLG
                  AND '1'||weekRow.KENSAKOMOKU_KETSUEKI_FLG = '1'||weekRow.zKENSAKOMOKU_KETSUEKI_FLG
                  AND '1'||weekRow.KENSAKOMOKU_BYORI_FLG = '1'||weekRow.zKENSAKOMOKU_BYORI_FLG
                  AND '1'||weekRow.KENSAKOMOKU_KISEICHU_FLG = '1'||weekRow.zKENSAKOMOKU_KISEICHU_FLG
                  AND '1'||weekRow.KENSAKOMOKU_SEIKA_FLG = '1'||weekRow.zKENSAKOMOKU_SEIKA_FLG
                  AND '1'||weekRow.KENSAKOMOKU_RI_FLG = '1'||weekRow.zKENSAKOMOKU_RI_FLG
                  AND '1'||weekRow.IMUSHITSU_REC_ID = '1'||weekRow.zIMUSHITSU_REC_ID
                  AND '1'||weekRow.IMUSHITSU_SHI_CD = '1'||weekRow.zIMUSHITSU_SHI_CD
                  AND (
                      (iLayoutKind = ULT_COMMON.LAYOUT_SBT_CD_ZANTEI
                      AND '1'||weekRow.SEISHIKI_SHI_NM_KANA40 = '1'||weekRow.zSEISHIKI_SHI_NM_KANA40
                      AND '1'||weekRow.SEISHIKI_SHI_NM30 = '1'||weekRow.zSEISHIKI_SHI_NM30)
                      OR iLayoutKind = ULT_COMMON.LAYOUT_SBT_CD_SHIN
                      )
                THEN
                  vMODKBN := ULT_COMMON.MOD_KBN_NO;
                ELSE
                  vMODKBN := ULT_COMMON.MOD_KBN_YES;
                END IF;
                
              END IF;
            
            ELSIF weekRow.zREC_ID IS NULL AND weekRow.zSHI_CD IS NULL THEN
              --�񋟗p���R�[�h�Ə�L�Ŏ擾�����O���r���R�[�h�͓������̂̃A�C�e�����r���Ă����ꂩ���s��v�� �A
              vMODKBN := ULT_COMMON.MOD_KBN_ADD;
            END IF;            
            
            IF vMODKBN != ULT_COMMON.MOD_KBN_NO THEN
              --�C���敪���h�@�h�i���p�X�y�[�X�j�ł͂Ȃ��� 
              
              -- ���C�A�E�g�敪��"1"(�V���C�A�E�g)�̎��A�u�V_�T����_DCF�{�݁v�e�[�u���ɓo�^����B
              IF iLayoutKind = ULT_COMMON.LAYOUT_SBT_CD_SHIN THEN              
                IF vMODKBN = ULT_COMMON.MOD_KBN_DEL THEN 
                  -- �C���敪��"C"�̏ꍇ
                   INSERT INTO TD_NW_DCF_SHI(LAYOUT_KBN,SHIREC_ID,SHI_CD,MOD_KBN,MENTE_YMD,TENSO_YMD,TRK_OPE_CD,TRK_DATE,TRK_PGM_ID,UPD_OPE_CD,UPD_DATE,UPD_PGM_ID)
                   VALUES('101',weekRow.REC_ID,weekRow.SHI_CD,vMODKBN,weekRow.UPD_EIGY_YMD,iTensoYMD,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);
                   
                   EXECUTE_SQL := 'INSERT INTO TD_NW_DCF_SHI(LAYOUT_KBN,SHIREC_ID,SHI_CD,MOD_KBN,MENTE_YMD,TENSO_YMD,TRK_OPE_CD,TRK_DATE,TRK_PGM_ID,UPD_OPE_CD,UPD_DATE,UPD_PGM_ID)
                   VALUES(''101'','''||weekRow.REC_ID||''','''||weekRow.SHI_CD||''','''||vMODKBN||''','''||weekRow.UPD_EIGY_YMD||''','''||
                   iTensoYMD||''','''||iOPE_CD||''','''||iDATE||''','''||iPGM_ID||''','''||iOPE_CD||''','''||iDATE||''','''||iPGM_ID||''')';
                   ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);
                ELSE
                  -- �C���敪��"B"�̏ꍇ
                   IF vMODKBN = ULT_COMMON.MOD_KBN_YES THEN
                     
                      --�폜�\�藝�R�R�[�h�A�d�������R�[�h�̂����ꂩ�ɕύX���������ꍇ�A
                      IF '1'||weekRow.DEL_YOTEI_RIYU_CD != '1'||weekRow.zDEL_YOTEI_RIYU_CD
                        OR '1'||weekRow.CHOFUKU_AITSK_REC_ID != '1'||weekRow.zCHOFUKU_AITSK_REC_ID
                        OR '1'||weekRow.CHOFUKU_AITSK_SHI_CD != '1'||weekRow.zCHOFUKU_AITSK_SHI_CD
                      THEN
                        vSPECIAL_FLG_1 := '1';
                      END IF;
                      
                      -- ��W������(�����l�Ȃ�)
                      IF weekRow.SEISHIKI_SHI_NM = weekRow.zSEISHIKI_SHI_NM THEN
                        weekRow.SEISHIKI_SHI_NM := NULL;
                      END IF;
                      IF weekRow.SEISHIKI_SHI_NM_KANA = weekRow.zSEISHIKI_SHI_NM_KANA THEN
                        weekRow.SEISHIKI_SHI_NM_KANA := NULL;
                      END IF;
                      IF weekRow.SHI_RN = weekRow.zSHI_RN THEN
                        weekRow.SHI_RN := NULL;
                      END IF;
                      IF weekRow.SHI_RN_KANA = weekRow.zSHI_RN_KANA THEN
                        weekRow.SHI_RN_KANA := NULL;
                      END IF;
                      IF weekRow.KEIEITAI_CD = weekRow.zKEIEITAI_CD THEN
                        weekRow.KEIEITAI_CD := NULL;
                      END IF;
                      IF weekRow.SHI_KBN_CD = weekRow.zSHI_KBN_CD THEN
                        weekRow.SHI_KBN_CD := NULL;
                      END IF;
                      IF weekRow.BYOIN_SBT_CD = weekRow.zBYOIN_SBT_CD THEN
                        weekRow.BYOIN_SBT_CD := NULL;
                      END IF;
                      IF weekRow.SAISHINSA_KBN_CD = weekRow.zSAISHINSA_KBN_CD THEN
                        weekRow.SAISHINSA_KBN_CD := NULL;
                      END IF;
                      
                      -- ��W������(�����l����)
                      IF '1'||weekRow.MIKAKUNIN_FLG = '1'||weekRow.zMIKAKUNIN_FLG THEN
                        weekRow.MIKAKUNIN_FLG := NULL;
                      ELSIF  weekRow.MIKAKUNIN_FLG IS NULL THEN
                        weekRow.MIKAKUNIN_FLG := ULT_COMMON.INSERT_HALF_DEFAULT;
                      END IF;
                      IF '1'||weekRow.DEL_YOTEI_RIYU_CD = '1'||weekRow.zDEL_YOTEI_RIYU_CD THEN
                        IF vSPECIAL_FLG_1 = '0' THEN
                          weekRow.DEL_YOTEI_RIYU_CD := NULL;
                        END IF;
                      ELSIF  weekRow.DEL_YOTEI_RIYU_CD IS NULL THEN
                        weekRow.DEL_YOTEI_RIYU_CD := ULT_COMMON.INSERT_HALF_DEFAULT;
                      END IF;
                      IF '1'||weekRow.JUSHOFUMEI_CD = '1'||weekRow.zJUSHOFUMEI_CD THEN
                        IF vSPECIAL_FLG_1 = '0' THEN
                           weekRow.JUSHOFUMEI_CD := NULL;
                        END IF;
                      ELSIF  weekRow.JUSHOFUMEI_CD IS NULL THEN
                        weekRow.JUSHOFUMEI_CD := ULT_COMMON.INSERT_HALF_DEFAULT;
                      END IF;
                      IF '1'||weekRow.TEL_NASHI_FLG = '1'||weekRow.zTEL_NASHI_FLG THEN
                        weekRow.TEL_NASHI_FLG := NULL;
                      ELSIF  weekRow.TEL_NASHI_FLG IS NULL THEN
                        weekRow.TEL_NASHI_FLG := ULT_COMMON.INSERT_HALF_DEFAULT;
                      END IF;
                      IF '1'||weekRow.TEL = '1'||weekRow.zTEL THEN
                        weekRow.TEL := NULL;
                      ELSIF  weekRow.TEL IS NULL THEN
                        weekRow.TEL := ULT_COMMON.INSERT_HALF_DEFAULT;
                      END IF;
                      IF '1'||weekRow.BYOTO_HEISA_KBN = '1'||weekRow.zBYOTO_HEISA_KBN THEN
                        weekRow.BYOTO_HEISA_KBN := NULL;
                      ELSIF  weekRow.BYOTO_HEISA_KBN IS NULL THEN
                        weekRow.BYOTO_HEISA_KBN := ULT_COMMON.INSERT_HALF_DEFAULT;
                      END IF;
                      IF '1'||weekRow.SHI_BED_SU = '1'||weekRow.zSHI_BED_SU THEN
                        weekRow.SHI_BED_SU := NULL;
                      ELSIF  weekRow.SHI_BED_SU IS NULL THEN
                        weekRow.SHI_BED_SU := ULT_COMMON.INSERT_HALF_DEFAULT;
                      END IF;
                      IF '1'||weekRow.BED_SU_KKNN_EIGY_YMD = '1'||weekRow.zBED_SU_KKNN_EIGY_YMD THEN
                        weekRow.BED_SU_KKNN_EIGY_YMD := NULL;
                      ELSIF  weekRow.BED_SU_KKNN_EIGY_YMD IS NULL THEN
                        weekRow.BED_SU_KKNN_EIGY_YMD := ULT_COMMON.INSERT_HALF_DEFAULT;
                      END IF;                      
                      
                      --�W������(�����l�Ȃ�)
                      IF '1'||weekRow.KEN_CD = '1'||weekRow.zKEN_CD
                        AND '1'||weekRow.SHIKU_CD = '1'||weekRow.zSHIKU_CD
                        AND '1'||weekRow.OAZA_CD = '1'||weekRow.zOAZA_CD
                        AND '1'||weekRow.AZA_CD = '1'||weekRow.zAZA_CD
                        AND '1'||weekRow.ZIP = '1'||weekRow.zZIP
                        AND '1'||weekRow.JUSHO_KANJI_RENKETSU = '1'||weekRow.zJUSHO_KANJI_RENKETSU
                        AND '1'||weekRow.JUSHO_KANA_RENKETSU = '1'||weekRow.zJUSHO_KANA_RENKETSU
                        AND '1'||weekRow.JUSHO_HYOJI_NO = '1'||weekRow.zJUSHO_HYOJI_NO
                        AND '1'||weekRow.KEN_NM_KANJI_MOJI_SU = '1'||weekRow.zKEN_NM_KANJI_MOJI_SU
                        AND '1'||weekRow.SHIKU_NM_KANJI_MOJI_SU = '1'||weekRow.zSHIKU_NM_KANJI_MOJI_SU
                        AND '1'||weekRow.OAZA_NM_KANJI_MOJI_SU = '1'||weekRow.zOAZA_NM_KANJI_MOJI_SU
                        AND '1'||weekRow.AZA_NM_KANJI_MOJI_SU = '1'||weekRow.zAZA_NM_KANJI_MOJI_SU
                        AND '1'||weekRow.KEN_NM_KANA_MOJI_SU = '1'||weekRow.zKEN_NM_KANA_MOJI_SU
                        AND '1'||weekRow.SHIKU_NM_KANA_MOJI_SU = '1'||weekRow.zSHIKU_NM_KANA_MOJI_SU
                        AND '1'||weekRow.OAZA_NM_KANA_MOJI_SU = '1'||weekRow.zOAZA_NM_KANA_MOJI_SU
                        AND '1'||weekRow.AZA_NM_KANA_MOJI_SU = '1'||weekRow.zAZA_NM_KANA_MOJI_SU
                      THEN
                        weekRow.KEN_CD := NULL;
                        weekRow.SHIKU_CD := NULL;
                        weekRow.OAZA_CD := NULL;
                        weekRow.AZA_CD := NULL;
                        weekRow.ZIP := NULL;
                        weekRow.JUSHO_KANJI_RENKETSU := NULL;
                        weekRow.JUSHO_KANA_RENKETSU := NULL;
                        weekRow.JUSHO_HYOJI_NO := NULL;
                        weekRow.KEN_NM_KANJI_MOJI_SU := NULL;
                        weekRow.SHIKU_NM_KANJI_MOJI_SU := NULL;
                        weekRow.OAZA_NM_KANJI_MOJI_SU := NULL;
                        weekRow.AZA_NM_KANJI_MOJI_SU := NULL;
                        weekRow.KEN_NM_KANA_MOJI_SU := NULL;
                        weekRow.SHIKU_NM_KANA_MOJI_SU := NULL;
                        weekRow.OAZA_NM_KANA_MOJI_SU := NULL;
                        weekRow.AZA_NM_KANA_MOJI_SU := NULL;
                      END IF;

                      --�W������(�����l����)
                      IF '1'||weekRow.CHOFUKU_AITSK_REC_ID = '1'||weekRow.zCHOFUKU_AITSK_REC_ID
                        AND '1'||weekRow.CHOFUKU_AITSK_SHI_CD = '1'||weekRow.zCHOFUKU_AITSK_SHI_CD
                      THEN
                        IF vSPECIAL_FLG_1 = '0' THEN
                           weekRow.CHOFUKU_AITSK_REC_ID := NULL;
                           weekRow.CHOFUKU_AITSK_SHI_CD := NULL;
                        END IF;
                      ELSIF weekRow.CHOFUKU_AITSK_REC_ID IS NULL
                        AND weekRow.CHOFUKU_AITSK_SHI_CD IS NULL
                      THEN
                        weekRow.CHOFUKU_AITSK_REC_ID := ULT_COMMON.INSERT_HALF_DEFAULT;
                      END IF;
                      IF '1'||weekRow.DAIHYO_REC_ID = '1'||weekRow.zDAIHYO_REC_ID
                        AND '1'||weekRow.DAIHYO_KJN_CD = '1'||weekRow.zDAIHYO_KJN_CD
                        AND '1'||weekRow.KJN_NM = '1'||weekRow.zKJN_NM
                        AND '1'||weekRow.KJN_NM_KANA = '1'||weekRow.zKJN_NM_KANA
                      THEN
                        weekRow.DAIHYO_REC_ID := NULL;
                        weekRow.DAIHYO_KJN_CD := NULL;
                        weekRow.KJN_NM := NULL;
                        weekRow.KJN_NM_KANA := NULL;
                      ELSE
                        IF weekRow.DAIHYO_REC_ID IS NULL AND weekRow.DAIHYO_KJN_CD IS NULL
                          AND weekRow.zDAIHYO_REC_ID IS NOT NULL AND  weekRow.zDAIHYO_KJN_CD IS NOT NULL
                        THEN
                          weekRow.DAIHYO_REC_ID := ULT_COMMON.INSERT_HALF_DEFAULT;
                        END IF;
                        IF weekRow.KJN_NM_KANA IS NULL AND weekRow.zKJN_NM_KANA IS NOT NULL THEN
                          weekRow.KJN_NM_KANA := ULT_COMMON.INSERT_HALF_DEFAULT;
                        END IF;
                        IF weekRow.KJN_NM IS NULL AND weekRow.zKJN_NM IS NOT NULL THEN
                          weekRow.KJN_NM := ULT_COMMON.INSERT_FULL_DEFAULT;
                        END IF;                       
                      END IF;
                      IF '1'||weekRow.KAIGYO_YOTEI_FLG = '1'||weekRow.zKAIGYO_YOTEI_FLG
                        AND '1'||weekRow.KAIGYO_YOTEI_YM = '1'||weekRow.zKAIGYO_YOTEI_YM
                      THEN
                        weekRow.KAIGYO_YOTEI_FLG := NULL;
                        weekRow.KAIGYO_YOTEI_YM := NULL;
                      ELSIF weekRow.KAIGYO_YOTEI_FLG IS NULL
                        AND weekRow.KAIGYO_YOTEI_YM IS NULL
                      THEN
                        weekRow.KAIGYO_YOTEI_FLG := ULT_COMMON.INSERT_HALF_DEFAULT;
                      END IF;
                      IF '1'||weekRow.KYUIN_FLG = '1'||weekRow.zKYUIN_FLG
                        AND '1'||weekRow.KYUIN_S_YM = '1'||weekRow.zKYUIN_S_YM
                      THEN
                        weekRow.KYUIN_FLG := NULL;
                        weekRow.KYUIN_S_YM := NULL;
                      ELSIF weekRow.KYUIN_FLG IS NULL
                        AND weekRow.KYUIN_S_YM IS NULL
                      THEN
                        weekRow.KYUIN_FLG := ULT_COMMON.INSERT_HALF_DEFAULT;
                      END IF;
                      IF '1'||weekRow.SNRYKMK_CD_01 = '1'||weekRow.zSNRYKMK_CD_01
                        AND '1'||weekRow.SNRYKMK_CD_02 = '1'||weekRow.zSNRYKMK_CD_02
                        AND '1'||weekRow.SNRYKMK_CD_03 = '1'||weekRow.zSNRYKMK_CD_03
                        AND '1'||weekRow.SNRYKMK_CD_04 = '1'||weekRow.zSNRYKMK_CD_04
                        AND '1'||weekRow.SNRYKMK_CD_05 = '1'||weekRow.zSNRYKMK_CD_05
                        AND '1'||weekRow.SNRYKMK_CD_06 = '1'||weekRow.zSNRYKMK_CD_06
                        AND '1'||weekRow.SNRYKMK_CD_07 = '1'||weekRow.zSNRYKMK_CD_07
                        AND '1'||weekRow.SNRYKMK_CD_08 = '1'||weekRow.zSNRYKMK_CD_08
                        AND '1'||weekRow.SNRYKMK_CD_09 = '1'||weekRow.zSNRYKMK_CD_09
                        AND '1'||weekRow.SNRYKMK_CD_10 = '1'||weekRow.zSNRYKMK_CD_10
                        AND '1'||weekRow.SNRYKMK_CD_11 = '1'||weekRow.zSNRYKMK_CD_11
                        AND '1'||weekRow.SNRYKMK_CD_12 = '1'||weekRow.zSNRYKMK_CD_12
                        AND '1'||weekRow.SNRYKMK_CD_13 = '1'||weekRow.zSNRYKMK_CD_13
                        AND '1'||weekRow.SNRYKMK_CD_14 = '1'||weekRow.zSNRYKMK_CD_14
                        AND '1'||weekRow.SNRYKMK_CD_15 = '1'||weekRow.zSNRYKMK_CD_15
                        AND '1'||weekRow.SNRYKMK_CD_16 = '1'||weekRow.zSNRYKMK_CD_16
                        AND '1'||weekRow.SNRYKMK_CD_17 = '1'||weekRow.zSNRYKMK_CD_17
                        AND '1'||weekRow.SNRYKMK_CD_18 = '1'||weekRow.zSNRYKMK_CD_18
                        AND '1'||weekRow.SNRYKMK_CD_19 = '1'||weekRow.zSNRYKMK_CD_19
                        AND '1'||weekRow.SNRYKMK_CD_20 = '1'||weekRow.zSNRYKMK_CD_20
                        AND '1'||weekRow.SNRYKMK_CD_21 = '1'||weekRow.zSNRYKMK_CD_21
                        AND '1'||weekRow.SNRYKMK_CD_22 = '1'||weekRow.zSNRYKMK_CD_22
                        AND '1'||weekRow.SNRYKMK_CD_23 = '1'||weekRow.zSNRYKMK_CD_23
                        AND '1'||weekRow.SNRYKMK_CD_24 = '1'||weekRow.zSNRYKMK_CD_24
                        AND '1'||weekRow.SNRYKMK_CD_25 = '1'||weekRow.zSNRYKMK_CD_25
                        AND '1'||weekRow.SNRYKMK_CD_26 = '1'||weekRow.zSNRYKMK_CD_26
                        AND '1'||weekRow.SNRYKMK_CD_27 = '1'||weekRow.zSNRYKMK_CD_27
                        AND '1'||weekRow.SNRYKMK_CD_28 = '1'||weekRow.zSNRYKMK_CD_28
                        AND '1'||weekRow.SNRYKMK_CD_29 = '1'||weekRow.zSNRYKMK_CD_29
                        AND '1'||weekRow.SNRYKMK_CD_30 = '1'||weekRow.zSNRYKMK_CD_30
                        AND '1'||weekRow.SNRYKMK_CD_31 = '1'||weekRow.zSNRYKMK_CD_31
                        AND '1'||weekRow.SNRYKMK_CD_32 = '1'||weekRow.zSNRYKMK_CD_32
                        AND '1'||weekRow.SNRYKMK_CD_33 = '1'||weekRow.zSNRYKMK_CD_33
                        AND '1'||weekRow.SNRYKMK_CD_34 = '1'||weekRow.zSNRYKMK_CD_34
                        AND '1'||weekRow.SNRYKMK_CD_35 = '1'||weekRow.zSNRYKMK_CD_35
                        AND '1'||weekRow.SNRYKMK_CD_36 = '1'||weekRow.zSNRYKMK_CD_36
                        AND '1'||weekRow.SNRYKMK_CD_37 = '1'||weekRow.zSNRYKMK_CD_37
                        AND '1'||weekRow.SNRYKMK_CD_38 = '1'||weekRow.zSNRYKMK_CD_38
                        AND '1'||weekRow.SNRYKMK_CD_39 = '1'||weekRow.zSNRYKMK_CD_39
                        AND '1'||weekRow.SNRYKMK_CD_40 = '1'||weekRow.zSNRYKMK_CD_40
                        AND '1'||weekRow.SNRYKMK_CD_41 = '1'||weekRow.zSNRYKMK_CD_41
                        AND '1'||weekRow.SNRYKMK_CD_42 = '1'||weekRow.zSNRYKMK_CD_42
                        AND '1'||weekRow.SNRYKMK_CD_43 = '1'||weekRow.zSNRYKMK_CD_43
                        AND '1'||weekRow.SNRYKMK_CD_44 = '1'||weekRow.zSNRYKMK_CD_44
                        AND '1'||weekRow.SNRYKMK_CD_45 = '1'||weekRow.zSNRYKMK_CD_45
                        AND '1'||weekRow.SNRYKMK_CD_46 = '1'||weekRow.zSNRYKMK_CD_46
                        AND '1'||weekRow.SNRYKMK_CD_47 = '1'||weekRow.zSNRYKMK_CD_47
                        AND '1'||weekRow.SNRYKMK_CD_48 = '1'||weekRow.zSNRYKMK_CD_48
                        AND '1'||weekRow.SNRYKMK_CD_49 = '1'||weekRow.zSNRYKMK_CD_49
                        AND '1'||weekRow.SNRYKMK_CD_50 = '1'||weekRow.zSNRYKMK_CD_50
                        AND '1'||weekRow.SNRYKMK_CD_51 = '1'||weekRow.zSNRYKMK_CD_51
                        AND '1'||weekRow.SNRYKMK_CD_52 = '1'||weekRow.zSNRYKMK_CD_52
                        AND '1'||weekRow.SNRYKMK_CD_53 = '1'||weekRow.zSNRYKMK_CD_53
                        AND '1'||weekRow.SNRYKMK_CD_54 = '1'||weekRow.zSNRYKMK_CD_54
                        AND '1'||weekRow.SNRYKMK_CD_55 = '1'||weekRow.zSNRYKMK_CD_55
                        AND '1'||weekRow.SNRYKMK_CD_56 = '1'||weekRow.zSNRYKMK_CD_56
                        AND '1'||weekRow.SNRYKMK_CD_57 = '1'||weekRow.zSNRYKMK_CD_57
                        AND '1'||weekRow.SNRYKMK_CD_58 = '1'||weekRow.zSNRYKMK_CD_58
                        AND '1'||weekRow.SNRYKMK_CD_59 = '1'||weekRow.zSNRYKMK_CD_59
                        AND '1'||weekRow.SNRYKMK_CD_60 = '1'||weekRow.zSNRYKMK_CD_60
                      THEN
                        weekRow.SNRYKMK_CD_01 := NULL;
                        weekRow.SNRYKMK_CD_02 := NULL;
                        weekRow.SNRYKMK_CD_03 := NULL;
                        weekRow.SNRYKMK_CD_04 := NULL;
                        weekRow.SNRYKMK_CD_05 := NULL;
                        weekRow.SNRYKMK_CD_06 := NULL;
                        weekRow.SNRYKMK_CD_07 := NULL;
                        weekRow.SNRYKMK_CD_08 := NULL;
                        weekRow.SNRYKMK_CD_09 := NULL;
                        weekRow.SNRYKMK_CD_10 := NULL;
                        weekRow.SNRYKMK_CD_11 := NULL;
                        weekRow.SNRYKMK_CD_12 := NULL;
                        weekRow.SNRYKMK_CD_13 := NULL;
                        weekRow.SNRYKMK_CD_14 := NULL;
                        weekRow.SNRYKMK_CD_15 := NULL;
                        weekRow.SNRYKMK_CD_16 := NULL;
                        weekRow.SNRYKMK_CD_17 := NULL;
                        weekRow.SNRYKMK_CD_18 := NULL;
                        weekRow.SNRYKMK_CD_19 := NULL;
                        weekRow.SNRYKMK_CD_20 := NULL;
                        weekRow.SNRYKMK_CD_21 := NULL;
                        weekRow.SNRYKMK_CD_22 := NULL;
                        weekRow.SNRYKMK_CD_23 := NULL;
                        weekRow.SNRYKMK_CD_24 := NULL;
                        weekRow.SNRYKMK_CD_25 := NULL;
                        weekRow.SNRYKMK_CD_26 := NULL;
                        weekRow.SNRYKMK_CD_27 := NULL;
                        weekRow.SNRYKMK_CD_28 := NULL;
                        weekRow.SNRYKMK_CD_29 := NULL;
                        weekRow.SNRYKMK_CD_30 := NULL;
                        weekRow.SNRYKMK_CD_31 := NULL;
                        weekRow.SNRYKMK_CD_32 := NULL;
                        weekRow.SNRYKMK_CD_33 := NULL;
                        weekRow.SNRYKMK_CD_34 := NULL;
                        weekRow.SNRYKMK_CD_35 := NULL;
                        weekRow.SNRYKMK_CD_36 := NULL;
                        weekRow.SNRYKMK_CD_37 := NULL;
                        weekRow.SNRYKMK_CD_38 := NULL;
                        weekRow.SNRYKMK_CD_39 := NULL;
                        weekRow.SNRYKMK_CD_40 := NULL;
                        weekRow.SNRYKMK_CD_41 := NULL;
                        weekRow.SNRYKMK_CD_42 := NULL;
                        weekRow.SNRYKMK_CD_43 := NULL;
                        weekRow.SNRYKMK_CD_44 := NULL;
                        weekRow.SNRYKMK_CD_45 := NULL;
                        weekRow.SNRYKMK_CD_46 := NULL;
                        weekRow.SNRYKMK_CD_47 := NULL;
                        weekRow.SNRYKMK_CD_48 := NULL;
                        weekRow.SNRYKMK_CD_49 := NULL;
                        weekRow.SNRYKMK_CD_50 := NULL;
                        weekRow.SNRYKMK_CD_51 := NULL;
                        weekRow.SNRYKMK_CD_52 := NULL;
                        weekRow.SNRYKMK_CD_53 := NULL;
                        weekRow.SNRYKMK_CD_54 := NULL;
                        weekRow.SNRYKMK_CD_55 := NULL;
                        weekRow.SNRYKMK_CD_56 := NULL;
                        weekRow.SNRYKMK_CD_57 := NULL;
                        weekRow.SNRYKMK_CD_58 := NULL;
                        weekRow.SNRYKMK_CD_59 := NULL;
                        weekRow.SNRYKMK_CD_60 := NULL;
                      ELSIF weekRow.SNRYKMK_CD_01 IS NULL
                        AND weekRow.SNRYKMK_CD_02 IS NULL
                        AND weekRow.SNRYKMK_CD_03 IS NULL
                        AND weekRow.SNRYKMK_CD_04 IS NULL
                        AND weekRow.SNRYKMK_CD_05 IS NULL
                        AND weekRow.SNRYKMK_CD_06 IS NULL
                        AND weekRow.SNRYKMK_CD_07 IS NULL
                        AND weekRow.SNRYKMK_CD_08 IS NULL
                        AND weekRow.SNRYKMK_CD_09 IS NULL
                        AND weekRow.SNRYKMK_CD_10 IS NULL
                        AND weekRow.SNRYKMK_CD_11 IS NULL
                        AND weekRow.SNRYKMK_CD_12 IS NULL
                        AND weekRow.SNRYKMK_CD_13 IS NULL
                        AND weekRow.SNRYKMK_CD_14 IS NULL
                        AND weekRow.SNRYKMK_CD_15 IS NULL
                        AND weekRow.SNRYKMK_CD_16 IS NULL
                        AND weekRow.SNRYKMK_CD_17 IS NULL
                        AND weekRow.SNRYKMK_CD_18 IS NULL
                        AND weekRow.SNRYKMK_CD_19 IS NULL
                        AND weekRow.SNRYKMK_CD_20 IS NULL
                        AND weekRow.SNRYKMK_CD_21 IS NULL
                        AND weekRow.SNRYKMK_CD_22 IS NULL
                        AND weekRow.SNRYKMK_CD_23 IS NULL
                        AND weekRow.SNRYKMK_CD_24 IS NULL
                        AND weekRow.SNRYKMK_CD_25 IS NULL
                        AND weekRow.SNRYKMK_CD_26 IS NULL
                        AND weekRow.SNRYKMK_CD_27 IS NULL
                        AND weekRow.SNRYKMK_CD_28 IS NULL
                        AND weekRow.SNRYKMK_CD_29 IS NULL
                        AND weekRow.SNRYKMK_CD_30 IS NULL
                        AND weekRow.SNRYKMK_CD_31 IS NULL
                        AND weekRow.SNRYKMK_CD_32 IS NULL
                        AND weekRow.SNRYKMK_CD_33 IS NULL
                        AND weekRow.SNRYKMK_CD_34 IS NULL
                        AND weekRow.SNRYKMK_CD_35 IS NULL
                        AND weekRow.SNRYKMK_CD_36 IS NULL
                        AND weekRow.SNRYKMK_CD_37 IS NULL
                        AND weekRow.SNRYKMK_CD_38 IS NULL
                        AND weekRow.SNRYKMK_CD_39 IS NULL
                        AND weekRow.SNRYKMK_CD_40 IS NULL
                        AND weekRow.SNRYKMK_CD_41 IS NULL
                        AND weekRow.SNRYKMK_CD_42 IS NULL
                        AND weekRow.SNRYKMK_CD_43 IS NULL
                        AND weekRow.SNRYKMK_CD_44 IS NULL
                        AND weekRow.SNRYKMK_CD_45 IS NULL
                        AND weekRow.SNRYKMK_CD_46 IS NULL
                        AND weekRow.SNRYKMK_CD_47 IS NULL
                        AND weekRow.SNRYKMK_CD_48 IS NULL
                        AND weekRow.SNRYKMK_CD_49 IS NULL
                        AND weekRow.SNRYKMK_CD_50 IS NULL
                        AND weekRow.SNRYKMK_CD_51 IS NULL
                        AND weekRow.SNRYKMK_CD_52 IS NULL
                        AND weekRow.SNRYKMK_CD_53 IS NULL
                        AND weekRow.SNRYKMK_CD_54 IS NULL
                        AND weekRow.SNRYKMK_CD_55 IS NULL
                        AND weekRow.SNRYKMK_CD_56 IS NULL
                        AND weekRow.SNRYKMK_CD_57 IS NULL
                        AND weekRow.SNRYKMK_CD_58 IS NULL
                        AND weekRow.SNRYKMK_CD_59 IS NULL
                        AND weekRow.SNRYKMK_CD_60 IS NULL
                      THEN
                        weekRow.SNRYKMK_CD_01 := ULT_COMMON.INSERT_HALF_DEFAULT;
                      END IF;
                      IF '1'||weekRow.KANREN_DAIGAKU_OYA_REC_ID = '1'||weekRow.zKANREN_DAIGAKU_OYA_REC_ID
                        AND '1'||weekRow.KANREN_DAIGAKU_OYA_SHI_CD = '1'||weekRow.zKANREN_DAIGAKU_OYA_SHI_CD
                      THEN
                        weekRow.KANREN_DAIGAKU_OYA_REC_ID := NULL;
                        weekRow.KANREN_DAIGAKU_OYA_SHI_CD := NULL;
                      ELSIF weekRow.KANREN_DAIGAKU_OYA_REC_ID IS NULL
                        AND weekRow.KANREN_DAIGAKU_OYA_SHI_CD IS NULL
                      THEN
                        weekRow.KANREN_DAIGAKU_OYA_REC_ID := ULT_COMMON.INSERT_HALF_DEFAULT;
                      END IF;
                      IF '1'||weekRow.KYOKA_BED_SU_GOKEI = '1'||weekRow.zKYOKA_BED_SU_GOKEI
                        AND '1'||weekRow.KYOKA_BED_SU_SEISHIN = '1'||weekRow.zKYOKA_BED_SU_SEISHIN
                        AND '1'||weekRow.KYOKA_BED_SU_KEKKAKU = '1'||weekRow.zKYOKA_BED_SU_KEKKAKU
                        AND '1'||weekRow.KYOKA_BED_SU_KANSEN = '1'||weekRow.zKYOKA_BED_SU_KANSEN
                        AND '1'||weekRow.KYOKA_BED_SU_SONOTA = '1'||weekRow.zKYOKA_BED_SU_SONOTA
                        AND '1'||weekRow.KYOKA_BED_SU_IPPAN = '1'||weekRow.zKYOKA_BED_SU_IPPAN
                        AND '1'||weekRow.KYOKA_BED_SU_RYOYO = '1'||weekRow.zKYOKA_BED_SU_RYOYO
                      THEN
                        weekRow.KYOKA_BED_SU_GOKEI := NULL;
                        weekRow.KYOKA_BED_SU_SEISHIN := NULL;
                        weekRow.KYOKA_BED_SU_KEKKAKU := NULL;
                        weekRow.KYOKA_BED_SU_KANSEN := NULL;
                        weekRow.KYOKA_BED_SU_SONOTA := NULL;
                        weekRow.KYOKA_BED_SU_IPPAN := NULL;
                        weekRow.KYOKA_BED_SU_RYOYO := NULL;
                      ELSIF weekRow.KYOKA_BED_SU_GOKEI IS NULL
                        AND weekRow.KYOKA_BED_SU_SEISHIN IS NULL
                        AND weekRow.KYOKA_BED_SU_KEKKAKU IS NULL
                        AND weekRow.KYOKA_BED_SU_KANSEN IS NULL
                        AND weekRow.KYOKA_BED_SU_SONOTA IS NULL
                        AND weekRow.KYOKA_BED_SU_IPPAN IS NULL
                        AND weekRow.KYOKA_BED_SU_RYOYO IS NULL
                      THEN
                        weekRow.KYOKA_BED_SU_GOKEI := ULT_COMMON.INSERT_HALF_DEFAULT;
                      END IF;
                      IF '1'||weekRow.KENSAKOMOKU_BISEIBUTSU_FLG = '1'||weekRow.zKENSAKOMOKU_BISEIBUTSU_FLG
                        AND '1'||weekRow.KENSAKOMOKU_KESSEI_FLG = '1'||weekRow.zKENSAKOMOKU_KESSEI_FLG
                        AND '1'||weekRow.KENSAKOMOKU_KETSUEKI_FLG = '1'||weekRow.zKENSAKOMOKU_KETSUEKI_FLG
                        AND '1'||weekRow.KENSAKOMOKU_BYORI_FLG = '1'||weekRow.zKENSAKOMOKU_BYORI_FLG
                        AND '1'||weekRow.KENSAKOMOKU_KISEICHU_FLG = '1'||weekRow.zKENSAKOMOKU_KISEICHU_FLG
                        AND '1'||weekRow.KENSAKOMOKU_SEIKA_FLG = '1'||weekRow.zKENSAKOMOKU_SEIKA_FLG
                        AND '1'||weekRow.KENSAKOMOKU_RI_FLG = '1'||weekRow.zKENSAKOMOKU_RI_FLG
                      THEN
                        weekRow.KENSAKOMOKU_BISEIBUTSU_FLG := NULL;
                        weekRow.KENSAKOMOKU_KESSEI_FLG := NULL;
                        weekRow.KENSAKOMOKU_KETSUEKI_FLG := NULL;
                        weekRow.KENSAKOMOKU_BYORI_FLG := NULL;
                        weekRow.KENSAKOMOKU_KISEICHU_FLG := NULL;
                        weekRow.KENSAKOMOKU_SEIKA_FLG := NULL;
                        weekRow.KENSAKOMOKU_RI_FLG := NULL;
                      ELSIF weekRow.KENSAKOMOKU_BISEIBUTSU_FLG IS NULL
                        AND weekRow.KENSAKOMOKU_KESSEI_FLG IS NULL
                        AND weekRow.KENSAKOMOKU_KETSUEKI_FLG IS NULL
                        AND weekRow.KENSAKOMOKU_BYORI_FLG IS NULL
                        AND weekRow.KENSAKOMOKU_KISEICHU_FLG IS NULL
                        AND weekRow.KENSAKOMOKU_SEIKA_FLG IS NULL
                        AND weekRow.KENSAKOMOKU_RI_FLG IS NULL
                      THEN
                        weekRow.KENSAKOMOKU_BISEIBUTSU_FLG := ULT_COMMON.INSERT_HALF_DEFAULT;
                      END IF; 
                      IF '1'||weekRow.IMUSHITSU_REC_ID = '1'||weekRow.zIMUSHITSU_REC_ID 
                        AND '1'||weekRow.IMUSHITSU_SHI_CD = '1'||weekRow.zIMUSHITSU_SHI_CD
                      THEN
                        weekRow.IMUSHITSU_REC_ID := NULL;
                        weekRow.IMUSHITSU_SHI_CD := NULL;
                      ELSIF  weekRow.IMUSHITSU_REC_ID IS NULL 
                        AND weekRow.IMUSHITSU_SHI_CD IS NULL 
                      THEN
                        weekRow.IMUSHITSU_REC_ID := ULT_COMMON.INSERT_HALF_DEFAULT;
                      END IF;                       
                   END IF;
                   INSERT INTO TD_NW_DCF_SHI(
                        LAYOUT_KBN,
                        SHIREC_ID,
                        SHI_CD,
                        MOD_KBN,
                        MENTE_YMD,
                        TENSO_YMD,
                        MIKAKUNIN_FLG,
                        DEL_YOTEI_RIYU,
                        AITSK_CD_SHIREC_ID,
                        AITSK_CD_SHI_CD,
                        SEISHIKI_SHI_NM_KANJI,
                        SEISHIKI_SHI_NM_KANA,
                        RYKSK_SHI_NM_KANJI,
                        RYKSK_SHI_NM_KANA,
                        JUSHOFUMEI,
                        JUSHO_CD_KEN_CD,
                        JUSHO_CD_SHIKU_CD,
                        JUSHO_CD_OAZA_CD,
                        JUSHO_CD_AZA_CD,
                        ZIP,
                        JUSHO_KANJI,
                        JUSHO_KANA,
                        JUSHO_HYOJI_NO,
                        JUSHO_COUNT_KANJI_KEN,
                        JUSHO_COUNT_KANJI_SHIKU,
                        JUSHO_COUNT_KANJI_OAZA,
                        JUSHO_COUNT_KANJI_AZA,
                        JUSHO_COUNT_KANA_KEN,
                        JUSHO_COUNT_KANA_SHIKU,
                        JUSHO_COUNT_KANA_OAZA,
                        JUSHO_COUNT_KANA_AZA,
                        TEL_NASHI_FLG,
                        TEL,
                        KEIEITAI,
                        SHI_KBN,
                        DAIHYO_KJNREC_ID,
                        DAIHYO_KJN_CD,
                        DAIHYO_KANJI,
                        DAIHYO_KANA,
                        KAIGYO_YOTEI_KAIGYO_YOTEI_FLG,
                        KAIGYO_YOTEI_KAIGYO_YOTEI_YM,
                        KYUIN_KYUIN_FLG,
                        KYUIN_KYUIN_S_YM,
                        SNRYKMK_1,
                        SNRYKMK_2,
                        SNRYKMK_3,
                        SNRYKMK_4,
                        SNRYKMK_5,
                        SNRYKMK_6,
                        SNRYKMK_7,
                        SNRYKMK_8,
                        SNRYKMK_9,
                        SNRYKMK_10,
                        SNRYKMK_11,
                        SNRYKMK_12,
                        SNRYKMK_13,
                        SNRYKMK_14,
                        SNRYKMK_15,
                        SNRYKMK_16,
                        SNRYKMK_17,
                        SNRYKMK_18,
                        SNRYKMK_19,
                        SNRYKMK_20,
                        SNRYKMK_21,
                        SNRYKMK_22,
                        SNRYKMK_23,
                        SNRYKMK_24,
                        SNRYKMK_25,
                        SNRYKMK_26,
                        SNRYKMK_27,
                        SNRYKMK_28,
                        SNRYKMK_29,
                        SNRYKMK_30,
                        SNRYKMK_31,
                        SNRYKMK_32,
                        SNRYKMK_33,
                        SNRYKMK_34,
                        SNRYKMK_35,
                        SNRYKMK_36,
                        SNRYKMK_37,
                        SNRYKMK_38,
                        SNRYKMK_39,
                        SNRYKMK_40,
                        SNRYKMK_41,
                        SNRYKMK_42,
                        SNRYKMK_43,
                        SNRYKMK_44,
                        SNRYKMK_45,
                        SNRYKMK_46,
                        SNRYKMK_47,
                        SNRYKMK_48,
                        SNRYKMK_49,
                        SNRYKMK_50,
                        SNRYKMK_51,
                        SNRYKMK_52,
                        SNRYKMK_53,
                        SNRYKMK_54,
                        SNRYKMK_55,
                        SNRYKMK_56,
                        SNRYKMK_57,
                        SNRYKMK_58,
                        SNRYKMK_59,
                        SNRYKMK_60,
                        BYOIN_SBT,
                        SAISHINSA_KBN,
                        KANREN_DAIGAKU_OYA_SHIREC_ID,
                        KANREN_DAIGAKU_OYA_SHI_CD,
                        BYOTO_HEISA_FLG,
                        BED_SU_TEIIN,
                        KYOKA_BED_MENTE_HIZUKE,
                        KYOKA_BED_SU_GOKEI,
                        KYOKA_BED_SU_SEISHIN,
                        KYOKA_BED_SU_KEKKAKU,
                        KYOKA_BED_SU_KANSEN,
                        KYOKA_BED_SU_SONOTA,
                        KYOKA_BED_SU_IPPAN_BED,
                        KYOKA_BED_SU_RYOYO_BED,
                        KENSAKOMOKU_BISEIBUTSU,
                        KENSAKOMOKU_KESSEI,
                        KENSAKOMOKU_KETSUEKI,
                        KENSAKOMOKU_BYORI,
                        KENSAKOMOKU_KISEICHU,
                        KENSAKOMOKU_SEIKA,
                        KENSAKOMOKU_RI,
                        TOKUI_CD_REC_ID,
                        TOKUI_CD_SHI_CD,
                        TRK_OPE_CD,TRK_DATE,TRK_PGM_ID,UPD_OPE_CD,UPD_DATE,UPD_PGM_ID
                     )
                     VALUES(
                        '101',
                        weekRow.REC_ID,
                        weekRow.SHI_CD,
                        vMODKBN,
                        weekRow.UPD_EIGY_YMD,
                        iTensoYMD,
                        weekRow.MIKAKUNIN_FLG,
                        weekRow.DEL_YOTEI_RIYU_CD,
                        TRIM(weekRow.CHOFUKU_AITSK_REC_ID),
                        TRIM(weekRow.CHOFUKU_AITSK_SHI_CD),
                        TRIM(weekRow.SEISHIKI_SHI_NM),
                        TRIM(weekRow.SEISHIKI_SHI_NM_KANA),
                        TRIM(weekRow.SHI_RN),
                        TRIM(weekRow.SHI_RN_KANA),
                        TRIM(weekRow.JUSHOFUMEI_CD),
                        TRIM(weekRow.KEN_CD),
                        TRIM(weekRow.SHIKU_CD),
                        TRIM(weekRow.OAZA_CD),
                        TRIM(weekRow.AZA_CD),
                        NVL2(weekRow.ZIP,SUBSTR(weekRow.ZIP,1,3)||'-'||SUBSTR(weekRow.ZIP,4),NULL),
                        TRIM(weekRow.JUSHO_KANJI_RENKETSU),
                        TRIM(weekRow.JUSHO_KANA_RENKETSU),
                        TRIM(weekRow.JUSHO_HYOJI_NO),
                        weekRow.KEN_NM_KANJI_MOJI_SU,
                        weekRow.SHIKU_NM_KANJI_MOJI_SU,
                        weekRow.OAZA_NM_KANJI_MOJI_SU,
                        weekRow.AZA_NM_KANJI_MOJI_SU,
                        weekRow.KEN_NM_KANA_MOJI_SU,
                        weekRow.SHIKU_NM_KANA_MOJI_SU,
                        weekRow.OAZA_NM_KANA_MOJI_SU,
                        weekRow.AZA_NM_KANA_MOJI_SU,
                        weekRow.TEL_NASHI_FLG,
                        TRIM(weekRow.TEL),
                        TRIM(weekRow.KEIEITAI_CD),
                        TRIM(weekRow.SHI_KBN_CD),
                        TRIM(weekRow.DAIHYO_REC_ID),
                        TRIM(weekRow.DAIHYO_KJN_CD),
                        TRIM(weekRow.KJN_NM),
                        TRIM(weekRow.KJN_NM_KANA),
                        TRIM(weekRow.KAIGYO_YOTEI_FLG),
                        TRIM(weekRow.KAIGYO_YOTEI_YM),
                        TRIM(weekRow.KYUIN_FLG),
                        TRIM(weekRow.KYUIN_S_YM),
                        TRIM(weekRow.SNRYKMK_CD_01),
                        TRIM(weekRow.SNRYKMK_CD_02),
                        TRIM(weekRow.SNRYKMK_CD_03),
                        TRIM(weekRow.SNRYKMK_CD_04),
                        TRIM(weekRow.SNRYKMK_CD_05),
                        TRIM(weekRow.SNRYKMK_CD_06),
                        TRIM(weekRow.SNRYKMK_CD_07),
                        TRIM(weekRow.SNRYKMK_CD_08),
                        TRIM(weekRow.SNRYKMK_CD_09),
                        TRIM(weekRow.SNRYKMK_CD_10),
                        TRIM(weekRow.SNRYKMK_CD_11),
                        TRIM(weekRow.SNRYKMK_CD_12),
                        TRIM(weekRow.SNRYKMK_CD_13),
                        TRIM(weekRow.SNRYKMK_CD_14),
                        TRIM(weekRow.SNRYKMK_CD_15),
                        TRIM(weekRow.SNRYKMK_CD_16),
                        TRIM(weekRow.SNRYKMK_CD_17),
                        TRIM(weekRow.SNRYKMK_CD_18),
                        TRIM(weekRow.SNRYKMK_CD_19),
                        TRIM(weekRow.SNRYKMK_CD_20),
                        TRIM(weekRow.SNRYKMK_CD_21),
                        TRIM(weekRow.SNRYKMK_CD_22),
                        TRIM(weekRow.SNRYKMK_CD_23),
                        TRIM(weekRow.SNRYKMK_CD_24),
                        TRIM(weekRow.SNRYKMK_CD_25),
                        TRIM(weekRow.SNRYKMK_CD_26),
                        TRIM(weekRow.SNRYKMK_CD_27),
                        TRIM(weekRow.SNRYKMK_CD_28),
                        TRIM(weekRow.SNRYKMK_CD_29),
                        TRIM(weekRow.SNRYKMK_CD_30),
                        TRIM(weekRow.SNRYKMK_CD_31),
                        TRIM(weekRow.SNRYKMK_CD_32),
                        TRIM(weekRow.SNRYKMK_CD_33),
                        TRIM(weekRow.SNRYKMK_CD_34),
                        TRIM(weekRow.SNRYKMK_CD_35),
                        TRIM(weekRow.SNRYKMK_CD_36),
                        TRIM(weekRow.SNRYKMK_CD_37),
                        TRIM(weekRow.SNRYKMK_CD_38),
                        TRIM(weekRow.SNRYKMK_CD_39),
                        TRIM(weekRow.SNRYKMK_CD_40),
                        TRIM(weekRow.SNRYKMK_CD_41),
                        TRIM(weekRow.SNRYKMK_CD_42),
                        TRIM(weekRow.SNRYKMK_CD_43),
                        TRIM(weekRow.SNRYKMK_CD_44),
                        TRIM(weekRow.SNRYKMK_CD_45),
                        TRIM(weekRow.SNRYKMK_CD_46),
                        TRIM(weekRow.SNRYKMK_CD_47),
                        TRIM(weekRow.SNRYKMK_CD_48),
                        TRIM(weekRow.SNRYKMK_CD_49),
                        TRIM(weekRow.SNRYKMK_CD_50),
                        TRIM(weekRow.SNRYKMK_CD_51),
                        TRIM(weekRow.SNRYKMK_CD_52),
                        TRIM(weekRow.SNRYKMK_CD_53),
                        TRIM(weekRow.SNRYKMK_CD_54),
                        TRIM(weekRow.SNRYKMK_CD_55),
                        TRIM(weekRow.SNRYKMK_CD_56),
                        TRIM(weekRow.SNRYKMK_CD_57),
                        TRIM(weekRow.SNRYKMK_CD_58),
                        TRIM(weekRow.SNRYKMK_CD_59),
                        TRIM(weekRow.SNRYKMK_CD_60),
                        TRIM(weekRow.BYOIN_SBT_CD),
                        TRIM(weekRow.SAISHINSA_KBN_CD),
                        TRIM(weekRow.KANREN_DAIGAKU_OYA_REC_ID),
                        TRIM(weekRow.KANREN_DAIGAKU_OYA_SHI_CD),
                        TRIM(weekRow.BYOTO_HEISA_KBN),
                        TRIM(weekRow.SHI_BED_SU),
                        TRIM(weekRow.BED_SU_KKNN_EIGY_YMD),
                        TRIM(weekRow.KYOKA_BED_SU_GOKEI),
                        TRIM(weekRow.KYOKA_BED_SU_SEISHIN),
                        TRIM(weekRow.KYOKA_BED_SU_KEKKAKU),
                        TRIM(weekRow.KYOKA_BED_SU_KANSEN),
                        TRIM(weekRow.KYOKA_BED_SU_SONOTA),
                        TRIM(weekRow.KYOKA_BED_SU_IPPAN),
                        TRIM(weekRow.KYOKA_BED_SU_RYOYO),
                        TRIM(weekRow.KENSAKOMOKU_BISEIBUTSU_FLG),
                        TRIM(weekRow.KENSAKOMOKU_KESSEI_FLG),
                        TRIM(weekRow.KENSAKOMOKU_KETSUEKI_FLG),
                        TRIM(weekRow.KENSAKOMOKU_BYORI_FLG),
                        TRIM(weekRow.KENSAKOMOKU_KISEICHU_FLG),
                        TRIM(weekRow.KENSAKOMOKU_SEIKA_FLG),
                        TRIM(weekRow.KENSAKOMOKU_RI_FLG),
                        TRIM(weekRow.IMUSHITSU_REC_ID),
                        TRIM(weekRow.IMUSHITSU_SHI_CD),
                        iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID
                     );
                     EXECUTE_SQL := 'INSERT INTO TD_NW_DCF_SHI(
                        LAYOUT_KBN,
                        SHIREC_ID,
                        SHI_CD,
                        MOD_KBN,
                        MENTE_YMD,
                        TENSO_YMD,
                        MIKAKUNIN_FLG,
                        DEL_YOTEI_RIYU,
                        AITSK_CD_SHIREC_ID,
                        AITSK_CD_SHI_CD,
                        SEISHIKI_SHI_NM_KANJI,
                        SEISHIKI_SHI_NM_KANA,
                        RYKSK_SHI_NM_KANJI,
                        RYKSK_SHI_NM_KANA,
                        JUSHOFUMEI,
                        JUSHO_CD_KEN_CD,
                        JUSHO_CD_SHIKU_CD,
                        JUSHO_CD_OAZA_CD,
                        JUSHO_CD_AZA_CD,
                        ZIP,
                        JUSHO_KANJI,
                        JUSHO_KANA,
                        JUSHO_HYOJI_NO,
                        JUSHO_COUNT_KANJI_KEN,
                        JUSHO_COUNT_KANJI_SHIKU,
                        JUSHO_COUNT_KANJI_OAZA,
                        JUSHO_COUNT_KANJI_AZA,
                        JUSHO_COUNT_KANA_KEN,
                        JUSHO_COUNT_KANA_SHIKU,
                        JUSHO_COUNT_KANA_OAZA,
                        JUSHO_COUNT_KANA_AZA,
                        TEL_NASHI_FLG,
                        TEL,
                        KEIEITAI,
                        SHI_KBN,
                        DAIHYO_KJNREC_ID,
                        DAIHYO_KJN_CD,
                        DAIHYO_KANJI,
                        DAIHYO_KANA,
                        KAIGYO_YOTEI_KAIGYO_YOTEI_FLG,
                        KAIGYO_YOTEI_KAIGYO_YOTEI_YM,
                        KYUIN_KYUIN_FLG,
                        KYUIN_KYUIN_S_YM,
                        SNRYKMK_1,
                        SNRYKMK_2,
                        SNRYKMK_3,
                        SNRYKMK_4,
                        SNRYKMK_5,
                        SNRYKMK_6,
                        SNRYKMK_7,
                        SNRYKMK_8,
                        SNRYKMK_9,
                        SNRYKMK_10,
                        SNRYKMK_11,
                        SNRYKMK_12,
                        SNRYKMK_13,
                        SNRYKMK_14,
                        SNRYKMK_15,
                        SNRYKMK_16,
                        SNRYKMK_17,
                        SNRYKMK_18,
                        SNRYKMK_19,
                        SNRYKMK_20,
                        SNRYKMK_21,
                        SNRYKMK_22,
                        SNRYKMK_23,
                        SNRYKMK_24,
                        SNRYKMK_25,
                        SNRYKMK_26,
                        SNRYKMK_27,
                        SNRYKMK_28,
                        SNRYKMK_29,
                        SNRYKMK_30,
                        SNRYKMK_31,
                        SNRYKMK_32,
                        SNRYKMK_33,
                        SNRYKMK_34,
                        SNRYKMK_35,
                        SNRYKMK_36,
                        SNRYKMK_37,
                        SNRYKMK_38,
                        SNRYKMK_39,
                        SNRYKMK_40,
                        SNRYKMK_41,
                        SNRYKMK_42,
                        SNRYKMK_43,
                        SNRYKMK_44,
                        SNRYKMK_45,
                        SNRYKMK_46,
                        SNRYKMK_47,
                        SNRYKMK_48,
                        SNRYKMK_49,
                        SNRYKMK_50,
                        SNRYKMK_51,
                        SNRYKMK_52,
                        SNRYKMK_53,
                        SNRYKMK_54,
                        SNRYKMK_55,
                        SNRYKMK_56,
                        SNRYKMK_57,
                        SNRYKMK_58,
                        SNRYKMK_59,
                        SNRYKMK_60,
                        BYOIN_SBT,
                        SAISHINSA_KBN,
                        KANREN_DAIGAKU_OYA_SHIREC_ID,
                        KANREN_DAIGAKU_OYA_SHI_CD,
                        BYOTO_HEISA_FLG,
                        BED_SU_TEIIN,
                        KYOKA_BED_MENTE_HIZUKE,
                        KYOKA_BED_SU_GOKEI,
                        KYOKA_BED_SU_SEISHIN,
                        KYOKA_BED_SU_KEKKAKU,
                        KYOKA_BED_SU_KANSEN,
                        KYOKA_BED_SU_SONOTA,
                        KYOKA_BED_SU_IPPAN_BED,
                        KYOKA_BED_SU_RYOYO_BED,
                        KENSAKOMOKU_BISEIBUTSU,
                        KENSAKOMOKU_KESSEI,
                        KENSAKOMOKU_KETSUEKI,
                        KENSAKOMOKU_BYORI,
                        KENSAKOMOKU_KISEICHU,
                        KENSAKOMOKU_SEIKA,
                        KENSAKOMOKU_RI,
                        TOKUI_CD_REC_ID,
                        TOKUI_CD_SHI_CD,
                        TRK_OPE_CD,TRK_DATE,TRK_PGM_ID,UPD_OPE_CD,UPD_DATE,UPD_PGM_ID
                     )
                     VALUES(
                     ''101'',
                     '''||weekRow.REC_ID||''',
                     '''||weekRow.SHI_CD||''',
                     '''||vMODKBN||''',
                     '''||weekRow.UPD_EIGY_YMD||''',
                     '''||iTensoYMD||''',
                     '''||weekRow.MIKAKUNIN_FLG||''',
                     '''||weekRow.DEL_YOTEI_RIYU_CD||''',
                     '''||weekRow.CHOFUKU_AITSK_REC_ID||''',
                     '''||weekRow.CHOFUKU_AITSK_SHI_CD||''',
                     '''||weekRow.SEISHIKI_SHI_NM||''',
                     '''||weekRow.SEISHIKI_SHI_NM_KANA||''',
                     '''||weekRow.SHI_RN||''',
                     '''||weekRow.SHI_RN_KANA||''',
                     '''||weekRow.JUSHOFUMEI_CD||''',
                     '''||weekRow.KEN_CD||''',
                     '''||weekRow.SHIKU_CD||''',
                     '''||weekRow.OAZA_CD||''',
                     '''||weekRow.AZA_CD||''',
                     '''||CASE WHEN weekRow.ZIP IS NOT NULL THEN SUBSTR(weekRow.ZIP,1,3)||'-'||SUBSTR(weekRow.ZIP,4) ELSE NULL END ||''',
                     '''||weekRow.JUSHO_KANJI_RENKETSU||''',
                     '''||weekRow.JUSHO_KANA_RENKETSU||''',
                     '''||weekRow.JUSHO_HYOJI_NO||''',
                     '''||weekRow.KEN_NM_KANJI_MOJI_SU||''',
                     '''||weekRow.SHIKU_NM_KANJI_MOJI_SU||''',
                     '''||weekRow.OAZA_NM_KANJI_MOJI_SU||''',
                     '''||weekRow.AZA_NM_KANJI_MOJI_SU||''',
                     '''||weekRow.KEN_NM_KANA_MOJI_SU||''',
                     '''||weekRow.SHIKU_NM_KANA_MOJI_SU||''',
                     '''||weekRow.OAZA_NM_KANA_MOJI_SU||''',
                     '''||weekRow.AZA_NM_KANA_MOJI_SU||''',
                     '''||weekRow.TEL_NASHI_FLG||''',
                     '''||weekRow.TEL||''',
                     '''||weekRow.KEIEITAI_CD||''',
                     '''||weekRow.SHI_KBN_CD||''',
                     '''||weekRow.DAIHYO_REC_ID||''',
                     '''||weekRow.DAIHYO_KJN_CD||''',
                     '''||weekRow.KJN_NM||''',
                     '''||weekRow.KJN_NM_KANA||''',
                     '''||weekRow.KAIGYO_YOTEI_FLG||''',
                     '''||weekRow.KAIGYO_YOTEI_YM||''',
                     '''||weekRow.KYUIN_FLG||''',
                     '''||weekRow.KYUIN_S_YM||''',
                     '''||weekRow.SNRYKMK_CD_01||''',
                     '''||weekRow.SNRYKMK_CD_02||''',
                     '''||weekRow.SNRYKMK_CD_03||''',
                     '''||weekRow.SNRYKMK_CD_04||''',
                     '''||weekRow.SNRYKMK_CD_05||''',
                     '''||weekRow.SNRYKMK_CD_06||''',
                     '''||weekRow.SNRYKMK_CD_07||''',
                     '''||weekRow.SNRYKMK_CD_08||''',
                     '''||weekRow.SNRYKMK_CD_09||''',
                     '''||weekRow.SNRYKMK_CD_10||''',
                     '''||weekRow.SNRYKMK_CD_11||''',
                     '''||weekRow.SNRYKMK_CD_12||''',
                     '''||weekRow.SNRYKMK_CD_13||''',
                     '''||weekRow.SNRYKMK_CD_14||''',
                     '''||weekRow.SNRYKMK_CD_15||''',
                     '''||weekRow.SNRYKMK_CD_16||''',
                     '''||weekRow.SNRYKMK_CD_17||''',
                     '''||weekRow.SNRYKMK_CD_18||''',
                     '''||weekRow.SNRYKMK_CD_19||''',
                     '''||weekRow.SNRYKMK_CD_20||''',
                     '''||weekRow.SNRYKMK_CD_21||''',
                     '''||weekRow.SNRYKMK_CD_22||''',
                     '''||weekRow.SNRYKMK_CD_23||''',
                     '''||weekRow.SNRYKMK_CD_24||''',
                     '''||weekRow.SNRYKMK_CD_25||''',
                     '''||weekRow.SNRYKMK_CD_26||''',
                     '''||weekRow.SNRYKMK_CD_27||''',
                     '''||weekRow.SNRYKMK_CD_28||''',
                     '''||weekRow.SNRYKMK_CD_29||''',
                     '''||weekRow.SNRYKMK_CD_30||''',
                     '''||weekRow.SNRYKMK_CD_31||''',
                     '''||weekRow.SNRYKMK_CD_32||''',
                     '''||weekRow.SNRYKMK_CD_33||''',
                     '''||weekRow.SNRYKMK_CD_34||''',
                     '''||weekRow.SNRYKMK_CD_35||''',
                     '''||weekRow.SNRYKMK_CD_36||''',
                     '''||weekRow.SNRYKMK_CD_37||''',
                     '''||weekRow.SNRYKMK_CD_38||''',
                     '''||weekRow.SNRYKMK_CD_39||''',
                     '''||weekRow.SNRYKMK_CD_40||''',
                     '''||weekRow.SNRYKMK_CD_41||''',
                     '''||weekRow.SNRYKMK_CD_42||''',
                     '''||weekRow.SNRYKMK_CD_43||''',
                     '''||weekRow.SNRYKMK_CD_44||''',
                     '''||weekRow.SNRYKMK_CD_45||''',
                     '''||weekRow.SNRYKMK_CD_46||''',
                     '''||weekRow.SNRYKMK_CD_47||''',
                     '''||weekRow.SNRYKMK_CD_48||''',
                     '''||weekRow.SNRYKMK_CD_49||''',
                     '''||weekRow.SNRYKMK_CD_50||''',
                     '''||weekRow.SNRYKMK_CD_51||''',
                     '''||weekRow.SNRYKMK_CD_52||''',
                     '''||weekRow.SNRYKMK_CD_53||''',
                     '''||weekRow.SNRYKMK_CD_54||''',
                     '''||weekRow.SNRYKMK_CD_55||''',
                     '''||weekRow.SNRYKMK_CD_56||''',
                     '''||weekRow.SNRYKMK_CD_57||''',
                     '''||weekRow.SNRYKMK_CD_58||''',
                     '''||weekRow.SNRYKMK_CD_59||''',
                     '''||weekRow.SNRYKMK_CD_60||''',
                     '''||weekRow.BYOIN_SBT_CD||''',
                     '''||weekRow.SAISHINSA_KBN_CD||''',
                     '''||weekRow.KANREN_DAIGAKU_OYA_REC_ID||''',
                     '''||weekRow.KANREN_DAIGAKU_OYA_SHI_CD||''',
                     '''||weekRow.BYOTO_HEISA_KBN||''',
                     '''||weekRow.SHI_BED_SU||''',
                     '''||weekRow.BED_SU_KKNN_EIGY_YMD||''',
                     '''||weekRow.KYOKA_BED_SU_GOKEI||''',
                     '''||weekRow.KYOKA_BED_SU_SEISHIN||''',
                     '''||weekRow.KYOKA_BED_SU_KEKKAKU||''',
                     '''||weekRow.KYOKA_BED_SU_KANSEN||''',
                     '''||weekRow.KYOKA_BED_SU_SONOTA||''',
                     '''||weekRow.KYOKA_BED_SU_IPPAN||''',
                     '''||weekRow.KYOKA_BED_SU_RYOYO||''',
                     '''||weekRow.KENSAKOMOKU_BISEIBUTSU_FLG||''',
                     '''||weekRow.KENSAKOMOKU_KESSEI_FLG||''',
                     '''||weekRow.KENSAKOMOKU_KETSUEKI_FLG||''',
                     '''||weekRow.KENSAKOMOKU_BYORI_FLG||''',
                     '''||weekRow.KENSAKOMOKU_KISEICHU_FLG||''',
                     '''||weekRow.KENSAKOMOKU_SEIKA_FLG||''',
                     '''||weekRow.KENSAKOMOKU_RI_FLG||''',
                     '''||weekRow.IMUSHITSU_REC_ID||''',
                     '''||weekRow.IMUSHITSU_SHI_CD||''',                        
                     '''||iOPE_CD||''',
                     '''||iDATE||''',
                     '''||iPGM_ID||''',
                     '''||iOPE_CD||''',
                     '''||iDATE||''',
                     '''||iPGM_ID||''')';
                     ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);
                END IF;
              END IF;
              -- ���C�A�E�g�敪��"2"(�b�背�C�A�E�g)�̎��A�u�b��_�T����_DCF�{�݁v�e�[�u���ɓo�^�B
              IF iLayoutKind = ULT_COMMON.LAYOUT_SBT_CD_ZANTEI THEN              
                 IF vMODKBN = ULT_COMMON.MOD_KBN_DEL THEN 
                  -- �C���敪��"C"�̏ꍇ
                   INSERT INTO TD_PW_DCF_SHI(SHIREC_ID,SHI_CD,MOD_KBN,MOD_SHORI_HIZUKE_Y,MOD_SHORI_HIZUKE_M,MOD_SHORI_HIZUKE_D,TENSO_Y,TENSO_M,TENSO_D,TRK_OPE_CD,TRK_DATE,TRK_PGM_ID,UPD_OPE_CD,UPD_DATE,UPD_PGM_ID)
                   VALUES(weekRow.REC_ID,weekRow.SHI_CD,vMODKBN,SUBSTR(weekRow.UPD_EIGY_YMD,1,4),SUBSTR(weekRow.UPD_EIGY_YMD,5,2),SUBSTR(weekRow.UPD_EIGY_YMD,7),SUBSTR(iTensoYMD,1,4),SUBSTR(iTensoYMD,5,2),SUBSTR(iTensoYMD,7),iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);
                   EXECUTE_SQL := 'INSERT INTO TD_PW_DCF_SHI(SHIREC_ID,SHI_CD,MOD_KBN,MOD_SHORI_HIZUKE_Y,MOD_SHORI_HIZUKE_M,MOD_SHORI_HIZUKE_D,TENSO_Y,TENSO_M,TENSO_D,TRK_OPE_CD,TRK_DATE,TRK_PGM_ID,UPD_OPE_CD,UPD_DATE,UPD_PGM_ID)
                   VALUES('''||weekRow.REC_ID||''','''||weekRow.SHI_CD||''','''||vMODKBN||''','''||SUBSTR(weekRow.UPD_EIGY_YMD,1,4)||''','''||SUBSTR(weekRow.UPD_EIGY_YMD,5,2)||''','''||SUBSTR(weekRow.UPD_EIGY_YMD,7)||''','''||SUBSTR(iTensoYMD,1,4)
                   ||''','''||SUBSTR(iTensoYMD,5,2)||''','''||SUBSTR(iTensoYMD,7)||''','''||iOPE_CD||''','''||iDATE||''','''||iPGM_ID||''','''||iOPE_CD||''','''||iDATE||''','''||iPGM_ID||''')';
                   ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);
                ELSE
                  -- �J�Ɨ\��N���Ƌx�@�J�n�N���̏�����("A"��"B"����)
                  vNEW_KAIGYO_YOTEI_YM := NULL;
	                IF NVL(weekRow.KAIGYO_YOTEI_FLG, '0') = '1' THEN
	                vNEW_KAIGYO_YOTEI_YM := weekRow.KAIGYO_YOTEI_YM;
	                --�x�@�J�n�N��
	                ELSIF NVL(weekRow.KYUIN_FLG, '0') = '1' THEN
	                vNEW_KAIGYO_YOTEI_YM := weekRow.KYUIN_S_YM;
	                END IF;

                  -- �C���敪��"B"�̏ꍇ
                   IF vMODKBN = ULT_COMMON.MOD_KBN_YES THEN
                     
                      --�폜�\�藝�R�R�[�h�A�d�������R�[�h�̂����ꂩ�ɕύX���������ꍇ�A
                      IF '1'||weekRow.DEL_YOTEI_RIYU_CD != '1'||weekRow.zDEL_YOTEI_RIYU_CD
                        OR '1'||weekRow.CHOFUKU_AITSK_REC_ID != '1'||weekRow.zCHOFUKU_AITSK_REC_ID
                        OR '1'||weekRow.CHOFUKU_AITSK_SHI_CD != '1'||weekRow.zCHOFUKU_AITSK_SHI_CD
                      THEN
                        vSPECIAL_FLG_1 := '1';
                      END IF;
                      
                      -- ��W������(�����l�Ȃ�)                      
                      IF '1'||weekRow.SEISHIKI_SHI_NM_KANA40 = '1'||weekRow.zSEISHIKI_SHI_NM_KANA40 THEN
                        weekRow.SEISHIKI_SHI_NM_KANA40 := NULL;
                      ELSIF weekRow.SEISHIKI_SHI_NM_KANA40 IS NULL THEN
                        weekRow.SEISHIKI_SHI_NM_KANA40 := ' ';
                      END IF;
                      IF '1'||weekRow.SHI_RN_KANA = '1'||weekRow.zSHI_RN_KANA THEN
                        weekRow.SHI_RN_KANA := NULL;
                      ELSIF weekRow.SHI_RN_KANA IS NULL THEN
                        weekRow.SHI_RN_KANA := ' ';
                      END IF;
                      IF '1'||weekRow.SEISHIKI_SHI_NM30 = '1'||weekRow.zSEISHIKI_SHI_NM30 THEN
                        weekRow.SEISHIKI_SHI_NM30 := NULL;
                      ELSIF weekRow.SEISHIKI_SHI_NM30 IS NULL THEN
                        weekRow.SEISHIKI_SHI_NM30 := ' ';
                      END IF;
                      IF '1'||weekRow.SHI_RN = '1'||weekRow.zSHI_RN THEN
                        weekRow.SHI_RN := NULL;
                      ELSIF weekRow.SHI_RN IS NULL THEN
                        weekRow.SHI_RN := ' ';
                      END IF;
                      IF '1'||weekRow.KEIEITAI_CD = '1'||weekRow.zKEIEITAI_CD THEN
                        weekRow.KEIEITAI_CD := NULL;
                      ELSIF weekRow.KEIEITAI_CD IS NULL THEN
                        weekRow.KEIEITAI_CD := ' ';  
                      END IF;
                      IF '1'||weekRow.SHI_KBN_CD = '1'||weekRow.zSHI_KBN_CD THEN
                        weekRow.SHI_KBN_CD := NULL;
                      ELSIF weekRow.SHI_KBN_CD IS NULL THEN
                        weekRow.SHI_KBN_CD := ' ';
                      END IF;
                      IF '1'||weekRow.SAISHINSA_KBN_CD = '1'||weekRow.zSAISHINSA_KBN_CD THEN
                        weekRow.SAISHINSA_KBN_CD := NULL;
                      ELSIF weekRow.SAISHINSA_KBN_CD IS NULL THEN
                        weekRow.SAISHINSA_KBN_CD := ' ';  
                      END IF;
                      IF '1'||weekRow.BYOIN_SBT_CD = '1'||weekRow.zBYOIN_SBT_CD THEN
                        weekRow.BYOIN_SBT_CD := NULL;
                      ELSIF weekRow.BYOIN_SBT_CD IS NULL THEN
                        weekRow.BYOIN_SBT_CD := ' ';
                      END IF;
                      IF '1'||weekRow.SEISHIKI_SHI_NM = '1'||weekRow.zSEISHIKI_SHI_NM THEN
                        weekRow.SEISHIKI_SHI_NM := NULL;
                      ELSIF weekRow.SEISHIKI_SHI_NM IS NULL THEN
                        weekRow.SEISHIKI_SHI_NM := ' ';
                      END IF;
                      IF '1'||weekRow.SEISHIKI_SHI_NM_KANA = '1'||weekRow.zSEISHIKI_SHI_NM_KANA THEN
                        weekRow.SEISHIKI_SHI_NM_KANA := NULL;
                      ELSIF weekRow.SEISHIKI_SHI_NM_KANA IS NULL THEN
                        weekRow.SEISHIKI_SHI_NM_KANA := ' ';
                      END IF;
                      
                      -- ��W������(�����l����)
                      IF '1'||weekRow.TEL = '1'||weekRow.zTEL THEN
                        weekRow.TEL := NULL;
                      ELSIF  weekRow.TEL IS NULL THEN
                        weekRow.TEL := ULT_COMMON.INSERT_HALF_DEFAULT;
                      END IF;
                      IF '1'||weekRow.SHI_BED_SU = '1'||weekRow.zSHI_BED_SU THEN
                        weekRow.SHI_BED_SU := NULL;
                      ELSIF  weekRow.SHI_BED_SU IS NULL THEN
                        weekRow.SHI_BED_SU := ULT_COMMON.INSERT_HALF_DEFAULT;
                      END IF;
                      IF '1'||weekRow.JUSHOFUMEI_CD = '1'||weekRow.zJUSHOFUMEI_CD THEN
                        IF vSPECIAL_FLG_1 = '0' THEN
                           weekRow.JUSHOFUMEI_CD := NULL;
                        END IF;
                      ELSIF  weekRow.JUSHOFUMEI_CD IS NULL THEN
                        weekRow.JUSHOFUMEI_CD := ULT_COMMON.INSERT_HALF_DEFAULT;
                      END IF;
                      
                      IF '1'||weekRow.DEL_YOTEI_RIYU_CD = '1'||weekRow.zDEL_YOTEI_RIYU_CD THEN
                        IF vSPECIAL_FLG_1 = '0' THEN
                           weekRow.DEL_YOTEI_RIYU_CD := NULL;
                        END IF;
                      ELSIF  weekRow.DEL_YOTEI_RIYU_CD IS NULL THEN
                        weekRow.DEL_YOTEI_RIYU_CD := ULT_COMMON.INSERT_HALF_DEFAULT;
                      END IF;
                      
                      IF '1'||weekRow.BYOTO_HEISA_KBN = '1'||weekRow.zBYOTO_HEISA_KBN THEN
                        weekRow.BYOTO_HEISA_KBN := NULL;
                      ELSIF  weekRow.BYOTO_HEISA_KBN IS NULL THEN
                        weekRow.BYOTO_HEISA_KBN := ULT_COMMON.INSERT_HALF_DEFAULT;
                      END IF;
                      IF '1'||weekRow.TEL_NASHI_FLG = '1'||weekRow.zTEL_NASHI_FLG THEN
                        weekRow.TEL_NASHI_FLG := NULL;
                      ELSIF  weekRow.TEL_NASHI_FLG IS NULL THEN
                        weekRow.TEL_NASHI_FLG := ULT_COMMON.INSERT_HALF_DEFAULT;
                      END IF;
                      IF '1'||weekRow.MIKAKUNIN_FLG = '1'||weekRow.zMIKAKUNIN_FLG THEN
                        weekRow.MIKAKUNIN_FLG := NULL;
                      ELSIF  weekRow.MIKAKUNIN_FLG IS NULL THEN
                        weekRow.MIKAKUNIN_FLG := ULT_COMMON.INSERT_HALF_DEFAULT;
                      END IF;
                      IF '1'||weekRow.BED_SU_KKNN_EIGY_YMD = '1'||weekRow.zBED_SU_KKNN_EIGY_YMD THEN
                        weekRow.BED_SU_KKNN_EIGY_YMD := NULL;
                      ELSIF  weekRow.BED_SU_KKNN_EIGY_YMD IS NULL THEN
                        weekRow.BED_SU_KKNN_EIGY_YMD := ULT_COMMON.INSERT_HALF_DEFAULT;
                      END IF;
                      IF '1'||weekRow.KYOKA_BED_SU_SONOTA = '1'||weekRow.zKYOKA_BED_SU_SONOTA THEN
                        weekRow.KYOKA_BED_SU_SONOTA := NULL;
                      ELSIF  weekRow.KYOKA_BED_SU_SONOTA IS NULL THEN
                        weekRow.KYOKA_BED_SU_SONOTA := ULT_COMMON.INSERT_HALF_DEFAULT;
                      END IF;
                      IF '1'||weekRow.KYOKA_BED_SU_SEISHIN = '1'||weekRow.zKYOKA_BED_SU_SEISHIN THEN
                        weekRow.KYOKA_BED_SU_SEISHIN := NULL;
                      ELSIF  weekRow.KYOKA_BED_SU_SEISHIN IS NULL THEN
                        weekRow.KYOKA_BED_SU_SEISHIN := ULT_COMMON.INSERT_HALF_DEFAULT;
                      END IF;
                      IF '1'||weekRow.KYOKA_BED_SU_KEKKAKU = '1'||weekRow.zKYOKA_BED_SU_KEKKAKU THEN
                        weekRow.KYOKA_BED_SU_KEKKAKU := NULL;
                      ELSIF  weekRow.KYOKA_BED_SU_KEKKAKU IS NULL THEN
                        weekRow.KYOKA_BED_SU_KEKKAKU := ULT_COMMON.INSERT_HALF_DEFAULT;
                      END IF;
                      IF '1'||weekRow.KYOKA_BED_SU_KANSEN = '1'||weekRow.zKYOKA_BED_SU_KANSEN THEN
                        weekRow.KYOKA_BED_SU_KANSEN := NULL;
                      ELSIF  weekRow.KYOKA_BED_SU_KANSEN IS NULL THEN
                        weekRow.KYOKA_BED_SU_KANSEN := ULT_COMMON.INSERT_HALF_DEFAULT;
                      END IF;
                      IF '1'||weekRow.KYOKA_BED_SU_GOKEI = '1'||weekRow.zKYOKA_BED_SU_GOKEI THEN
                        weekRow.KYOKA_BED_SU_GOKEI := NULL;
                      ELSIF  weekRow.KYOKA_BED_SU_GOKEI IS NULL THEN
                        weekRow.KYOKA_BED_SU_GOKEI := ULT_COMMON.INSERT_HALF_DEFAULT;
                      END IF;
                      
                      -- ������2012/11/28 NH000032�̑Ή�
                      -- �J�Ɨ\��N���Ƌx�@�J�n�N���̏�����
                      vNEW_KAIGYO_YOTEI_YM := NULL;
					  vOLD_KAIGYO_YOTEI_YM := NULL;
					  
                      --�J�Ɨ\��N��
                      IF NVL(weekRow.KAIGYO_YOTEI_FLG, '0') = '1' THEN
                      	vNEW_KAIGYO_YOTEI_YM := weekRow.KAIGYO_YOTEI_YM;
                      --�x�@�J�n�N��
                      ELSIF NVL(weekRow.KYUIN_FLG, '0') = '1' THEN
                      	vNEW_KAIGYO_YOTEI_YM := weekRow.KYUIN_S_YM;
                      END IF;
                      
                      --�J�Ɨ\��N��
                      IF NVL(weekRow.zKAIGYO_YOTEI_FLG, '0') = '1' THEN
                      	vOLD_KAIGYO_YOTEI_YM := weekRow.zKAIGYO_YOTEI_YM;
                      --�x�@�J�n�N��
                      ELSIF NVL(weekRow.zKYUIN_FLG, '0') = '1' THEN
                      	vOLD_KAIGYO_YOTEI_YM := weekRow.zKYUIN_S_YM;
                      END IF;
                      
                      IF '1' || vNEW_KAIGYO_YOTEI_YM = '1' || vOLD_KAIGYO_YOTEI_YM THEN
                      	vNEW_KAIGYO_YOTEI_YM := NULL;
                      ELSIF vNEW_KAIGYO_YOTEI_YM IS NULL AND vOLD_KAIGYO_YOTEI_YM IS NOT NULL THEN
                      	vNEW_KAIGYO_YOTEI_YM := ULT_COMMON.INSERT_HALF_DEFAULT;
                      END IF;
                      
                      IF '1'||weekRow.KYUIN_FLG = '1'||weekRow.zKYUIN_FLG THEN
                        weekRow.KYUIN_FLG := NULL;
                      ELSIF  weekRow.KYUIN_FLG IS NULL THEN
                        weekRow.KYUIN_FLG := ULT_COMMON.INSERT_HALF_DEFAULT;
                      END IF;
                      
                      IF '1'||weekRow.KAIGYO_YOTEI_FLG = '1'||weekRow.zKAIGYO_YOTEI_FLG THEN
                        weekRow.KAIGYO_YOTEI_FLG := NULL;
                      ELSIF  weekRow.KAIGYO_YOTEI_FLG IS NULL THEN
                        weekRow.KAIGYO_YOTEI_FLG := ULT_COMMON.INSERT_HALF_DEFAULT;
                      END IF;
                      -- ������2012/11/28 NH000032�̑Ή�
                      
                      --�W������(�����l�Ȃ�)
                      IF '1'||weekRow.JUSHO_KANA_RENKETSU = '1'||weekRow.zJUSHO_KANA_RENKETSU
                        AND '1'||weekRow.JUSHO_KANJI_RENKETSU = '1'||weekRow.zJUSHO_KANJI_RENKETSU
                        AND '1'||weekRow.KEN_CD = '1'||weekRow.zKEN_CD
                        AND '1'||weekRow.SHIKU_CD = '1'||weekRow.zSHIKU_CD
                        AND '1'||weekRow.OAZA_CD = '1'||weekRow.zOAZA_CD
                        AND '1'||weekRow.AZA_CD = '1'||weekRow.zAZA_CD
                        AND '1'||weekRow.ZIP = '1'||weekRow.zZIP
                        AND '1'||weekRow.JUSHO_HYOJI_NO = '1'||weekRow.zJUSHO_HYOJI_NO
                        AND '1'||weekRow.KEN_NM_KANA_MOJI_SU = '1'||weekRow.zKEN_NM_KANA_MOJI_SU
                        AND '1'||weekRow.SHIKU_NM_KANA_MOJI_SU = '1'||weekRow.zSHIKU_NM_KANA_MOJI_SU
                        AND '1'||weekRow.OAZA_NM_KANA_MOJI_SU = '1'||weekRow.zOAZA_NM_KANA_MOJI_SU
                        AND '1'||weekRow.KEN_NM_KANJI_MOJI_SU = '1'||weekRow.zKEN_NM_KANJI_MOJI_SU
                        AND '1'||weekRow.SHIKU_NM_KANJI_MOJI_SU = '1'||weekRow.zSHIKU_NM_KANJI_MOJI_SU
                        AND '1'||weekRow.OAZA_NM_KANJI_MOJI_SU = '1'||weekRow.zOAZA_NM_KANJI_MOJI_SU
                        AND '1'||weekRow.AZA_NM_KANA_MOJI_SU = '1'||weekRow.zAZA_NM_KANA_MOJI_SU
                        AND '1'||weekRow.AZA_NM_KANJI_MOJI_SU = '1'||weekRow.zAZA_NM_KANJI_MOJI_SU
                      THEN
                        weekRow.JUSHO_KANA_RENKETSU := NULL;
                        weekRow.JUSHO_KANJI_RENKETSU := NULL;
                        weekRow.KEN_CD := NULL;
                        weekRow.SHIKU_CD := NULL;
                        weekRow.OAZA_CD := NULL;
                        weekRow.AZA_CD := NULL;
                        weekRow.ZIP := NULL;
                        weekRow.JUSHO_HYOJI_NO := NULL;
                        weekRow.KEN_NM_KANA_MOJI_SU := NULL;
                        weekRow.SHIKU_NM_KANA_MOJI_SU := NULL;
                        weekRow.OAZA_NM_KANA_MOJI_SU := NULL;
                        weekRow.KEN_NM_KANJI_MOJI_SU := NULL;
                        weekRow.SHIKU_NM_KANJI_MOJI_SU := NULL;
                        weekRow.OAZA_NM_KANJI_MOJI_SU := NULL;
                        weekRow.AZA_NM_KANA_MOJI_SU := NULL;
                        weekRow.AZA_NM_KANJI_MOJI_SU := NULL;
                      ELSIF weekRow.JUSHO_HYOJI_NO IS NULL AND weekRow.zJUSHO_HYOJI_NO IS NOT NULL THEN
                        weekRow.JUSHO_HYOJI_NO := ULT_COMMON.INSERT_HALF_DEFAULT;   --�Z���\���ԍ�
                      ELSE
                        IF weekRow.JUSHO_KANA_RENKETSU IS NULL THEN
                           weekRow.JUSHO_KANA_RENKETSU := ' ';
                        END IF;
                        IF weekRow.JUSHO_KANJI_RENKETSU IS NULL THEN
                           weekRow.JUSHO_KANJI_RENKETSU := ' ';
                        END IF;
                        IF weekRow.KEN_CD IS NULL THEN
                           weekRow.KEN_CD := ' ';
                        END IF;
                        IF weekRow.SHIKU_CD IS NULL THEN
                           weekRow.SHIKU_CD := ' ';
                        END IF;
                        IF weekRow.OAZA_CD IS NULL THEN
                           weekRow.OAZA_CD := ' ';
                        END IF;
                        IF weekRow.AZA_CD IS NULL THEN
                           weekRow.AZA_CD := ' ';
                        END IF;
                        IF weekRow.ZIP IS NULL THEN
                           weekRow.ZIP := ' ';
                        END IF;
                        IF weekRow.JUSHO_HYOJI_NO IS NULL THEN
                           weekRow.JUSHO_HYOJI_NO := ' ';
                        END IF;
                        IF weekRow.KEN_NM_KANA_MOJI_SU IS NULL THEN
                           weekRow.KEN_NM_KANA_MOJI_SU := ' ';
                        END IF;
                        IF weekRow.SHIKU_NM_KANA_MOJI_SU IS NULL THEN
                           weekRow.SHIKU_NM_KANA_MOJI_SU := ' ';
                        END IF;
                        IF weekRow.OAZA_NM_KANA_MOJI_SU IS NULL THEN
                           weekRow.OAZA_NM_KANA_MOJI_SU := ' ';
                        END IF;
                        IF weekRow.KEN_NM_KANJI_MOJI_SU IS NULL THEN
                           weekRow.KEN_NM_KANJI_MOJI_SU := ' ';
                        END IF;
                        IF weekRow.SHIKU_NM_KANJI_MOJI_SU IS NULL THEN
                           weekRow.SHIKU_NM_KANJI_MOJI_SU := ' ';
                        END IF;
                        IF weekRow.OAZA_NM_KANJI_MOJI_SU IS NULL THEN
                           weekRow.OAZA_NM_KANJI_MOJI_SU := ' ';
                        END IF;
                        IF weekRow.AZA_NM_KANA_MOJI_SU IS NULL THEN
                           weekRow.AZA_NM_KANA_MOJI_SU := ' ';
                        END IF;
                        IF weekRow.AZA_NM_KANJI_MOJI_SU IS NULL THEN
                           weekRow.AZA_NM_KANJI_MOJI_SU := ' ';
                        END IF;
                      END IF;

                      --�W������(�����l����)
                      IF '1'||weekRow.KANREN_DAIGAKU_OYA_REC_ID = '1'||weekRow.zKANREN_DAIGAKU_OYA_REC_ID
                        AND '1'||weekRow.KANREN_DAIGAKU_OYA_SHI_CD = '1'||weekRow.zKANREN_DAIGAKU_OYA_SHI_CD
                      THEN
                        weekRow.KANREN_DAIGAKU_OYA_REC_ID := NULL;
                        weekRow.KANREN_DAIGAKU_OYA_SHI_CD := NULL;
                      ELSIF weekRow.KANREN_DAIGAKU_OYA_REC_ID IS NULL
                        AND weekRow.KANREN_DAIGAKU_OYA_SHI_CD IS NULL
                      THEN
                        weekRow.KANREN_DAIGAKU_OYA_REC_ID := ULT_COMMON.INSERT_HALF_DEFAULT;
                      END IF;
                      IF '1'||weekRow.KENSAKOMOKU_BISEIBUTSU_FLG = '1'||weekRow.zKENSAKOMOKU_BISEIBUTSU_FLG
                        AND '1'||weekRow.KENSAKOMOKU_KESSEI_FLG = '1'||weekRow.zKENSAKOMOKU_KESSEI_FLG
                        AND '1'||weekRow.KENSAKOMOKU_KETSUEKI_FLG = '1'||weekRow.zKENSAKOMOKU_KETSUEKI_FLG
                        AND '1'||weekRow.KENSAKOMOKU_BYORI_FLG = '1'||weekRow.zKENSAKOMOKU_BYORI_FLG
                        AND '1'||weekRow.KENSAKOMOKU_KISEICHU_FLG = '1'||weekRow.zKENSAKOMOKU_KISEICHU_FLG
                        AND '1'||weekRow.KENSAKOMOKU_SEIKA_FLG = '1'||weekRow.zKENSAKOMOKU_SEIKA_FLG
                        AND '1'||weekRow.KENSAKOMOKU_RI_FLG = '1'||weekRow.zKENSAKOMOKU_RI_FLG
                      THEN
                        weekRow.KENSAKOMOKU_BISEIBUTSU_FLG := NULL;
                        weekRow.KENSAKOMOKU_KESSEI_FLG := NULL;
                        weekRow.KENSAKOMOKU_KETSUEKI_FLG := NULL;
                        weekRow.KENSAKOMOKU_BYORI_FLG := NULL;
                        weekRow.KENSAKOMOKU_KISEICHU_FLG := NULL;
                        weekRow.KENSAKOMOKU_SEIKA_FLG := NULL;
                        weekRow.KENSAKOMOKU_RI_FLG := NULL;
                      ELSIF weekRow.KENSAKOMOKU_BISEIBUTSU_FLG IS NULL
                        AND weekRow.KENSAKOMOKU_KESSEI_FLG IS NULL
                        AND weekRow.KENSAKOMOKU_KETSUEKI_FLG IS NULL
                        AND weekRow.KENSAKOMOKU_BYORI_FLG IS NULL
                        AND weekRow.KENSAKOMOKU_KISEICHU_FLG IS NULL
                        AND weekRow.KENSAKOMOKU_SEIKA_FLG IS NULL
                        AND weekRow.KENSAKOMOKU_RI_FLG IS NULL
                      THEN
                        weekRow.KENSAKOMOKU_BISEIBUTSU_FLG := ULT_COMMON.INSERT_HALF_DEFAULT;
                      END IF;
                      IF '1'||weekRow.DAIHYO_REC_ID = '1'||weekRow.zDAIHYO_REC_ID
                        AND '1'||weekRow.DAIHYO_KJN_CD = '1'||weekRow.zDAIHYO_KJN_CD
                        AND '1'||weekRow.KJN_NM_KANA = '1'||weekRow.zKJN_NM_KANA
                        AND '1'||weekRow.KJN_NM = '1'||weekRow.zKJN_NM
                      THEN
                        weekRow.DAIHYO_REC_ID := NULL;
                        weekRow.DAIHYO_KJN_CD := NULL;
                        weekRow.KJN_NM_KANA := NULL;
                        weekRow.KJN_NM := NULL;
                      ELSE
                        IF weekRow.DAIHYO_REC_ID IS NULL AND weekRow.DAIHYO_KJN_CD IS NULL
                          AND weekRow.zDAIHYO_REC_ID IS NOT NULL AND  weekRow.zDAIHYO_KJN_CD IS NOT NULL
                        THEN
                          weekRow.DAIHYO_REC_ID := ULT_COMMON.INSERT_HALF_DEFAULT;
                        END IF;
                        IF weekRow.KJN_NM_KANA IS NULL AND weekRow.zKJN_NM_KANA IS NOT NULL THEN
                          weekRow.KJN_NM_KANA := ULT_COMMON.INSERT_HALF_DEFAULT;
                        END IF;
                        IF weekRow.KJN_NM IS NULL AND weekRow.zKJN_NM IS NOT NULL THEN
						---- 2012/10/24 START CP000164�Ή�----
                          --weekRow.KJN_NM := ULT_COMMON.INSERT_HALF_DEFAULT;
                          weekRow.KJN_NM := ULT_COMMON.INSERT_FULL_DEFAULT;
						---- 2012/10/24 END CP000164�Ή�----
                        END IF;                       
                      END IF;
                      IF '1'||weekRow.CHOFUKU_AITSK_REC_ID = '1'||weekRow.zCHOFUKU_AITSK_REC_ID
                        AND '1'||weekRow.CHOFUKU_AITSK_SHI_CD = '1'||weekRow.zCHOFUKU_AITSK_SHI_CD
                      THEN
                        IF vSPECIAL_FLG_1 = '0' THEN
                          weekRow.CHOFUKU_AITSK_REC_ID := NULL;
                          weekRow.CHOFUKU_AITSK_SHI_CD := NULL;
                        END IF;
                      ELSIF weekRow.CHOFUKU_AITSK_REC_ID IS NULL
                        AND weekRow.CHOFUKU_AITSK_SHI_CD IS NULL
                      THEN
                        weekRow.CHOFUKU_AITSK_REC_ID := ULT_COMMON.INSERT_HALF_DEFAULT;
                      END IF;
                      IF '1'||weekRow.KYOKA_BED_SU_IPPAN = '1'||weekRow.zKYOKA_BED_SU_IPPAN
                        AND '1'||weekRow.KYOKA_BED_SU_RYOYO = '1'||weekRow.zKYOKA_BED_SU_RYOYO
                      THEN
                        weekRow.KYOKA_BED_SU_IPPAN := NULL;
                        weekRow.KYOKA_BED_SU_RYOYO := NULL;
                      ELSIF weekRow.KYOKA_BED_SU_IPPAN IS NULL
                        AND weekRow.KYOKA_BED_SU_RYOYO IS NULL
                      THEN
                        weekRow.KYOKA_BED_SU_IPPAN := ULT_COMMON.INSERT_HALF_DEFAULT;
                      END IF;
                      IF '1'||weekRow.SNRYKMK_CD_01 = '1'||weekRow.zSNRYKMK_CD_01
                        AND '1'||weekRow.SNRYKMK_CD_02 = '1'||weekRow.zSNRYKMK_CD_02
                        AND '1'||weekRow.SNRYKMK_CD_03 = '1'||weekRow.zSNRYKMK_CD_03
                        AND '1'||weekRow.SNRYKMK_CD_04 = '1'||weekRow.zSNRYKMK_CD_04
                        AND '1'||weekRow.SNRYKMK_CD_05 = '1'||weekRow.zSNRYKMK_CD_05
                        AND '1'||weekRow.SNRYKMK_CD_06 = '1'||weekRow.zSNRYKMK_CD_06
                        AND '1'||weekRow.SNRYKMK_CD_07 = '1'||weekRow.zSNRYKMK_CD_07
                        AND '1'||weekRow.SNRYKMK_CD_08 = '1'||weekRow.zSNRYKMK_CD_08
                        AND '1'||weekRow.SNRYKMK_CD_09 = '1'||weekRow.zSNRYKMK_CD_09
                        AND '1'||weekRow.SNRYKMK_CD_10 = '1'||weekRow.zSNRYKMK_CD_10
                        AND '1'||weekRow.SNRYKMK_CD_11 = '1'||weekRow.zSNRYKMK_CD_11
                        AND '1'||weekRow.SNRYKMK_CD_12 = '1'||weekRow.zSNRYKMK_CD_12
                        AND '1'||weekRow.SNRYKMK_CD_13 = '1'||weekRow.zSNRYKMK_CD_13
                        AND '1'||weekRow.SNRYKMK_CD_14 = '1'||weekRow.zSNRYKMK_CD_14
                        AND '1'||weekRow.SNRYKMK_CD_15 = '1'||weekRow.zSNRYKMK_CD_15
                        AND '1'||weekRow.SNRYKMK_CD_16 = '1'||weekRow.zSNRYKMK_CD_16
                        AND '1'||weekRow.SNRYKMK_CD_17 = '1'||weekRow.zSNRYKMK_CD_17
                        AND '1'||weekRow.SNRYKMK_CD_18 = '1'||weekRow.zSNRYKMK_CD_18
                        AND '1'||weekRow.SNRYKMK_CD_19 = '1'||weekRow.zSNRYKMK_CD_19
                        AND '1'||weekRow.SNRYKMK_CD_20 = '1'||weekRow.zSNRYKMK_CD_20
                        AND '1'||weekRow.SNRYKMK_CD_21 = '1'||weekRow.zSNRYKMK_CD_21
                        AND '1'||weekRow.SNRYKMK_CD_22 = '1'||weekRow.zSNRYKMK_CD_22
                        AND '1'||weekRow.SNRYKMK_CD_23 = '1'||weekRow.zSNRYKMK_CD_23
                        AND '1'||weekRow.SNRYKMK_CD_24 = '1'||weekRow.zSNRYKMK_CD_24
                        AND '1'||weekRow.SNRYKMK_CD_25 = '1'||weekRow.zSNRYKMK_CD_25
                        AND '1'||weekRow.SNRYKMK_CD_26 = '1'||weekRow.zSNRYKMK_CD_26
                        AND '1'||weekRow.SNRYKMK_CD_27 = '1'||weekRow.zSNRYKMK_CD_27
                        AND '1'||weekRow.SNRYKMK_CD_28 = '1'||weekRow.zSNRYKMK_CD_28
                        AND '1'||weekRow.SNRYKMK_CD_29 = '1'||weekRow.zSNRYKMK_CD_29
                        AND '1'||weekRow.SNRYKMK_CD_30 = '1'||weekRow.zSNRYKMK_CD_30
                        AND '1'||weekRow.SNRYKMK_CD_31 = '1'||weekRow.zSNRYKMK_CD_31
                        AND '1'||weekRow.SNRYKMK_CD_32 = '1'||weekRow.zSNRYKMK_CD_32
                        AND '1'||weekRow.SNRYKMK_CD_33 = '1'||weekRow.zSNRYKMK_CD_33
                        AND '1'||weekRow.SNRYKMK_CD_34 = '1'||weekRow.zSNRYKMK_CD_34
                        AND '1'||weekRow.SNRYKMK_CD_35 = '1'||weekRow.zSNRYKMK_CD_35
                        AND '1'||weekRow.SNRYKMK_CD_36 = '1'||weekRow.zSNRYKMK_CD_36
                        AND '1'||weekRow.SNRYKMK_CD_37 = '1'||weekRow.zSNRYKMK_CD_37
                        AND '1'||weekRow.SNRYKMK_CD_38 = '1'||weekRow.zSNRYKMK_CD_38
                        AND '1'||weekRow.SNRYKMK_CD_39 = '1'||weekRow.zSNRYKMK_CD_39
                        AND '1'||weekRow.SNRYKMK_CD_40 = '1'||weekRow.zSNRYKMK_CD_40
                        AND '1'||weekRow.SNRYKMK_CD_41 = '1'||weekRow.zSNRYKMK_CD_41
                        AND '1'||weekRow.SNRYKMK_CD_42 = '1'||weekRow.zSNRYKMK_CD_42
                        AND '1'||weekRow.SNRYKMK_CD_43 = '1'||weekRow.zSNRYKMK_CD_43
                        AND '1'||weekRow.SNRYKMK_CD_44 = '1'||weekRow.zSNRYKMK_CD_44
                        AND '1'||weekRow.SNRYKMK_CD_45 = '1'||weekRow.zSNRYKMK_CD_45
                        AND '1'||weekRow.SNRYKMK_CD_46 = '1'||weekRow.zSNRYKMK_CD_46
                        AND '1'||weekRow.SNRYKMK_CD_47 = '1'||weekRow.zSNRYKMK_CD_47
                        AND '1'||weekRow.SNRYKMK_CD_48 = '1'||weekRow.zSNRYKMK_CD_48
                        AND '1'||weekRow.SNRYKMK_CD_49 = '1'||weekRow.zSNRYKMK_CD_49
                        AND '1'||weekRow.SNRYKMK_CD_50 = '1'||weekRow.zSNRYKMK_CD_50
                        AND '1'||weekRow.SNRYKMK_CD_51 = '1'||weekRow.zSNRYKMK_CD_51
                        AND '1'||weekRow.SNRYKMK_CD_52 = '1'||weekRow.zSNRYKMK_CD_52
                        AND '1'||weekRow.SNRYKMK_CD_53 = '1'||weekRow.zSNRYKMK_CD_53
                        AND '1'||weekRow.SNRYKMK_CD_54 = '1'||weekRow.zSNRYKMK_CD_54
                        AND '1'||weekRow.SNRYKMK_CD_55 = '1'||weekRow.zSNRYKMK_CD_55
                        AND '1'||weekRow.SNRYKMK_CD_56 = '1'||weekRow.zSNRYKMK_CD_56
                        AND '1'||weekRow.SNRYKMK_CD_57 = '1'||weekRow.zSNRYKMK_CD_57
                        AND '1'||weekRow.SNRYKMK_CD_58 = '1'||weekRow.zSNRYKMK_CD_58
                        AND '1'||weekRow.SNRYKMK_CD_59 = '1'||weekRow.zSNRYKMK_CD_59
                        AND '1'||weekRow.SNRYKMK_CD_60 = '1'||weekRow.zSNRYKMK_CD_60
                      THEN
                        weekRow.SNRYKMK_CD_01 := NULL;
                        weekRow.SNRYKMK_CD_02 := NULL;
                        weekRow.SNRYKMK_CD_03 := NULL;
                        weekRow.SNRYKMK_CD_04 := NULL;
                        weekRow.SNRYKMK_CD_05 := NULL;
                        weekRow.SNRYKMK_CD_06 := NULL;
                        weekRow.SNRYKMK_CD_07 := NULL;
                        weekRow.SNRYKMK_CD_08 := NULL;
                        weekRow.SNRYKMK_CD_09 := NULL;
                        weekRow.SNRYKMK_CD_10 := NULL;
                        weekRow.SNRYKMK_CD_11 := NULL;
                        weekRow.SNRYKMK_CD_12 := NULL;
                        weekRow.SNRYKMK_CD_13 := NULL;
                        weekRow.SNRYKMK_CD_14 := NULL;
                        weekRow.SNRYKMK_CD_15 := NULL;
                        weekRow.SNRYKMK_CD_16 := NULL;
                        weekRow.SNRYKMK_CD_17 := NULL;
                        weekRow.SNRYKMK_CD_18 := NULL;
                        weekRow.SNRYKMK_CD_19 := NULL;
                        weekRow.SNRYKMK_CD_20 := NULL;
                        weekRow.SNRYKMK_CD_21 := NULL;
                        weekRow.SNRYKMK_CD_22 := NULL;
                        weekRow.SNRYKMK_CD_23 := NULL;
                        weekRow.SNRYKMK_CD_24 := NULL;
                        weekRow.SNRYKMK_CD_25 := NULL;
                        weekRow.SNRYKMK_CD_26 := NULL;
                        weekRow.SNRYKMK_CD_27 := NULL;
                        weekRow.SNRYKMK_CD_28 := NULL;
                        weekRow.SNRYKMK_CD_29 := NULL;
                        weekRow.SNRYKMK_CD_30 := NULL;
                        weekRow.SNRYKMK_CD_31 := NULL;
                        weekRow.SNRYKMK_CD_32 := NULL;
                        weekRow.SNRYKMK_CD_33 := NULL;
                        weekRow.SNRYKMK_CD_34 := NULL;
                        weekRow.SNRYKMK_CD_35 := NULL;
                        weekRow.SNRYKMK_CD_36 := NULL;
                        weekRow.SNRYKMK_CD_37 := NULL;
                        weekRow.SNRYKMK_CD_38 := NULL;
                        weekRow.SNRYKMK_CD_39 := NULL;
                        weekRow.SNRYKMK_CD_40 := NULL;
                        weekRow.SNRYKMK_CD_41 := NULL;
                        weekRow.SNRYKMK_CD_42 := NULL;
                        weekRow.SNRYKMK_CD_43 := NULL;
                        weekRow.SNRYKMK_CD_44 := NULL;
                        weekRow.SNRYKMK_CD_45 := NULL;
                        weekRow.SNRYKMK_CD_46 := NULL;
                        weekRow.SNRYKMK_CD_47 := NULL;
                        weekRow.SNRYKMK_CD_48 := NULL;
                        weekRow.SNRYKMK_CD_49 := NULL;
                        weekRow.SNRYKMK_CD_50 := NULL;
                        weekRow.SNRYKMK_CD_51 := NULL;
                        weekRow.SNRYKMK_CD_52 := NULL;
                        weekRow.SNRYKMK_CD_53 := NULL;
                        weekRow.SNRYKMK_CD_54 := NULL;
                        weekRow.SNRYKMK_CD_55 := NULL;
                        weekRow.SNRYKMK_CD_56 := NULL;
                        weekRow.SNRYKMK_CD_57 := NULL;
                        weekRow.SNRYKMK_CD_58 := NULL;
                        weekRow.SNRYKMK_CD_59 := NULL;
                        weekRow.SNRYKMK_CD_60 := NULL;
                      ELSIF weekRow.SNRYKMK_CD_01 IS NULL
                        AND weekRow.SNRYKMK_CD_02 IS NULL
                        AND weekRow.SNRYKMK_CD_03 IS NULL
                        AND weekRow.SNRYKMK_CD_04 IS NULL
                        AND weekRow.SNRYKMK_CD_05 IS NULL
                        AND weekRow.SNRYKMK_CD_06 IS NULL
                        AND weekRow.SNRYKMK_CD_07 IS NULL
                        AND weekRow.SNRYKMK_CD_08 IS NULL
                        AND weekRow.SNRYKMK_CD_09 IS NULL
                        AND weekRow.SNRYKMK_CD_10 IS NULL
                        AND weekRow.SNRYKMK_CD_11 IS NULL
                        AND weekRow.SNRYKMK_CD_12 IS NULL
                        AND weekRow.SNRYKMK_CD_13 IS NULL
                        AND weekRow.SNRYKMK_CD_14 IS NULL
                        AND weekRow.SNRYKMK_CD_15 IS NULL
                        AND weekRow.SNRYKMK_CD_16 IS NULL
                        AND weekRow.SNRYKMK_CD_17 IS NULL
                        AND weekRow.SNRYKMK_CD_18 IS NULL
                        AND weekRow.SNRYKMK_CD_19 IS NULL
                        AND weekRow.SNRYKMK_CD_20 IS NULL
                        AND weekRow.SNRYKMK_CD_21 IS NULL
                        AND weekRow.SNRYKMK_CD_22 IS NULL
                        AND weekRow.SNRYKMK_CD_23 IS NULL
                        AND weekRow.SNRYKMK_CD_24 IS NULL
                        AND weekRow.SNRYKMK_CD_25 IS NULL
                        AND weekRow.SNRYKMK_CD_26 IS NULL
                        AND weekRow.SNRYKMK_CD_27 IS NULL
                        AND weekRow.SNRYKMK_CD_28 IS NULL
                        AND weekRow.SNRYKMK_CD_29 IS NULL
                        AND weekRow.SNRYKMK_CD_30 IS NULL
                        AND weekRow.SNRYKMK_CD_31 IS NULL
                        AND weekRow.SNRYKMK_CD_32 IS NULL
                        AND weekRow.SNRYKMK_CD_33 IS NULL
                        AND weekRow.SNRYKMK_CD_34 IS NULL
                        AND weekRow.SNRYKMK_CD_35 IS NULL
                        AND weekRow.SNRYKMK_CD_36 IS NULL
                        AND weekRow.SNRYKMK_CD_37 IS NULL
                        AND weekRow.SNRYKMK_CD_38 IS NULL
                        AND weekRow.SNRYKMK_CD_39 IS NULL
                        AND weekRow.SNRYKMK_CD_40 IS NULL
                        AND weekRow.SNRYKMK_CD_41 IS NULL
                        AND weekRow.SNRYKMK_CD_42 IS NULL
                        AND weekRow.SNRYKMK_CD_43 IS NULL
                        AND weekRow.SNRYKMK_CD_44 IS NULL
                        AND weekRow.SNRYKMK_CD_45 IS NULL
                        AND weekRow.SNRYKMK_CD_46 IS NULL
                        AND weekRow.SNRYKMK_CD_47 IS NULL
                        AND weekRow.SNRYKMK_CD_48 IS NULL
                        AND weekRow.SNRYKMK_CD_49 IS NULL
                        AND weekRow.SNRYKMK_CD_50 IS NULL
                        AND weekRow.SNRYKMK_CD_51 IS NULL
                        AND weekRow.SNRYKMK_CD_52 IS NULL
                        AND weekRow.SNRYKMK_CD_53 IS NULL
                        AND weekRow.SNRYKMK_CD_54 IS NULL
                        AND weekRow.SNRYKMK_CD_55 IS NULL
                        AND weekRow.SNRYKMK_CD_56 IS NULL
                        AND weekRow.SNRYKMK_CD_57 IS NULL
                        AND weekRow.SNRYKMK_CD_58 IS NULL
                        AND weekRow.SNRYKMK_CD_59 IS NULL
                        AND weekRow.SNRYKMK_CD_60 IS NULL
                      THEN
                        weekRow.SNRYKMK_CD_01 := ULT_COMMON.INSERT_HALF_DEFAULT;
                      END IF;
                      IF '1'||weekRow.IMUSHITSU_REC_ID = '1'||weekRow.zIMUSHITSU_REC_ID
                        AND '1'||weekRow.IMUSHITSU_SHI_CD = '1'||weekRow.zIMUSHITSU_SHI_CD
                      THEN
                        weekRow.IMUSHITSU_REC_ID := NULL;
                        weekRow.IMUSHITSU_SHI_CD := NULL;
                      ELSIF weekRow.IMUSHITSU_REC_ID IS NULL
                        AND weekRow.IMUSHITSU_SHI_CD IS NULL
                      THEN
                        weekRow.IMUSHITSU_REC_ID := ULT_COMMON.INSERT_HALF_DEFAULT;
                      END IF;
                                              
                   END IF;
                   INSERT INTO TD_PW_DCF_SHI(
                      SHIREC_ID,
                      SHI_CD,
                      SEISHIKI_SHI_NM_KANA,
                      RYKSK_SHI_NM_KANA,
                      SEISHIKI_SHI_NM_KANJI,
                      RYKSK_SHI_NM_KANJI,
                      KANREN_DAIGAKU_OYA_SHIREC_ID,
                      KANREN_DAIGAKU_OYA_SHI_CD,
                      JUSHO_KANA,
                      JUSHO_KANJI,
                      JUSHO_CD_KEN_CD,
                      JUSHO_CD_SHIKU_CD,
                      JUSHO_CD_OAZA_CD,
                      JUSHO_CD_AZA_CD,
                      ZIP,
                      JUSHO_HYOJI_NO,
                      JUSHO_COUNT_KANA_KEN,
                      JUSHO_COUNT_KANA_SHIKU,
                      JUSHO_COUNT_KANA_OAZA,
                      JUSHO_COUNT_KANJI_KEN,
                      JUSHO_COUNT_KANJI_SHIKU,
                      JUSHO_COUNT_KANJI_OAZA,
                      JUSHO_COUNT_KANA_AZA,
                      JUSHO_COUNT_KANJI_AZA,
                      SHI_TEL,
                      BED_SU_TEIIN,
                      KEIEITAI,
                      SHI_KBN,
                      KENSAKOMOKU_BISEIBUTSU,
                      KENSAKOMOKU_KESSEI,
                      KENSAKOMOKU_KETSUEKI,
                      KENSAKOMOKU_BYORI,
                      KENSAKOMOKU_KISEICHU,
                      KENSAKOMOKU_SEIKA,
                      KENSAKOMOKU_RI,
                      STATUS_JUSHOFUMEI,
                      STATUS_KYUIN_FLG,
                      STATUS_DEL_YOTEI_RIYU,
                      STATUS_KAIGYO_YOTEI_FLG,
                      STATUS_BYOTO_HEISA_FLG,
                      STATUS_TEL_NASHI_FLG,
                      STATUS_MIKAKUNIN_FLG,
                      STATUS_SAISHINSA_KBN,
                      KYOKA_BED_MENTE_HIZUKE_Y,
                      KYOKA_BED_MENTE_HIZUKE_M,
                      KYOKA_BED_MENTE_HIZUKE_D,
                      KYOKA_BED_SU_SONOTA,
                      KYOKA_BED_SU_SEISHIN,
                      KYOKA_BED_SU_KEKKAKU,
                      KYOKA_BED_SU_KANSEN,
                      KYOKA_BED_SU_GOKEI,
                      BYOIN_SBT,
                      SHI_DAIHYO_KJNREC_ID,
                      SHI_DAIHYO_KJN_CD,
                      SHI_DAIHYO_KANA,
                      SHI_DAIHYO_KANJI,
                      AITSK_CD_SHIREC_ID,
                      AITSK_CD_SHI_CD,
                      KYUIN_S_KAIGYO_YOTEI_Y,
                      KYUIN_S_KAIGYO_YOTEI_M,
                      SHIN_BED_KBN_IPPAN_BED,
                      SHIN_BED_KBN_RYOYO_BED,
                      SNRYKMK_1,
                      SNRYKMK_2,
                      SNRYKMK_3,
                      SNRYKMK_4,
                      SNRYKMK_5,
                      SNRYKMK_6,
                      SNRYKMK_7,
                      SNRYKMK_8,
                      SNRYKMK_9,
                      SNRYKMK_10,
                      SNRYKMK_11,
                      SNRYKMK_12,
                      SNRYKMK_13,
                      SNRYKMK_14,
                      SNRYKMK_15,
                      SNRYKMK_16,
                      SNRYKMK_17,
                      SNRYKMK_18,
                      SNRYKMK_19,
                      SNRYKMK_20,
                      SNRYKMK_21,
                      SNRYKMK_22,
                      SNRYKMK_23,
                      SNRYKMK_24,
                      SNRYKMK_25,
                      SNRYKMK_26,
                      SNRYKMK_27,
                      SNRYKMK_28,
                      SNRYKMK_29,
                      SNRYKMK_30,
                      SNRYKMK_31,
                      SNRYKMK_32,
                      SNRYKMK_33,
                      SNRYKMK_34,
                      SNRYKMK_35,
                      SNRYKMK_36,
                      SNRYKMK_37,
                      SNRYKMK_38,
                      SNRYKMK_39,
                      SNRYKMK_40,
                      SNRYKMK_41,
                      SNRYKMK_42,
                      SNRYKMK_43,
                      SNRYKMK_44,
                      SNRYKMK_45,
                      SNRYKMK_46,
                      SNRYKMK_47,
                      SNRYKMK_48,
                      SNRYKMK_49,
                      SNRYKMK_50,
                      SNRYKMK_51,
                      SNRYKMK_52,
                      SNRYKMK_53,
                      SNRYKMK_54,
                      SNRYKMK_55,
                      SNRYKMK_56,
                      SNRYKMK_57,
                      SNRYKMK_58,
                      SNRYKMK_59,
                      SNRYKMK_60,
                      SHIN_SEISHIKI_SHI_NM_KANJI,
                      SHIN_SEISHIKI_SHI_NM_KANA,
                      TENSO_Y,
                      TENSO_M,
                      TENSO_D,
                      MOD_SHORI_HIZUKE_Y,
                      MOD_SHORI_HIZUKE_M,
                      MOD_SHORI_HIZUKE_D,
                      MOD_KBN,
                      TRK_OPE_CD,TRK_DATE,TRK_PGM_ID,UPD_OPE_CD,UPD_DATE,UPD_PGM_ID
                     )
                     VALUES(
                        weekRow.REC_ID,
                        weekRow.SHI_CD,
                        weekRow.SEISHIKI_SHI_NM_KANA40,
                        weekRow.SHI_RN_KANA,
                        weekRow.SEISHIKI_SHI_NM30,
                        weekRow.SHI_RN,
                        weekRow.KANREN_DAIGAKU_OYA_REC_ID,
                        weekRow.KANREN_DAIGAKU_OYA_SHI_CD,
                        weekRow.JUSHO_KANA_RENKETSU,
                        weekRow.JUSHO_KANJI_RENKETSU,
                        weekRow.KEN_CD,
                        weekRow.SHIKU_CD,
                        weekRow.OAZA_CD,
                        weekRow.AZA_CD,
                        NVL2(weekRow.ZIP,SUBSTR(weekRow.ZIP,1,3)||'-'||SUBSTR(weekRow.ZIP,4),NULL),
                        weekRow.JUSHO_HYOJI_NO,
                        weekRow.KEN_NM_KANA_MOJI_SU,
                        weekRow.SHIKU_NM_KANA_MOJI_SU,
                        weekRow.OAZA_NM_KANA_MOJI_SU,
                        weekRow.KEN_NM_KANJI_MOJI_SU,
                        weekRow.SHIKU_NM_KANJI_MOJI_SU,
                        weekRow.OAZA_NM_KANJI_MOJI_SU,
                        weekRow.AZA_NM_KANA_MOJI_SU,
                        weekRow.AZA_NM_KANJI_MOJI_SU,
                        weekRow.TEL,
                        weekRow.SHI_BED_SU,
                        weekRow.KEIEITAI_CD,
                        weekRow.SHI_KBN_CD,
                        weekRow.KENSAKOMOKU_BISEIBUTSU_FLG,
                        weekRow.KENSAKOMOKU_KESSEI_FLG,
                        weekRow.KENSAKOMOKU_KETSUEKI_FLG,
                        weekRow.KENSAKOMOKU_BYORI_FLG,
                        weekRow.KENSAKOMOKU_KISEICHU_FLG,
                        weekRow.KENSAKOMOKU_SEIKA_FLG,
                        weekRow.KENSAKOMOKU_RI_FLG,
                        weekRow.JUSHOFUMEI_CD,
                        weekRow.KYUIN_FLG,
                        weekRow.DEL_YOTEI_RIYU_CD,
                        weekRow.KAIGYO_YOTEI_FLG,
                        weekRow.BYOTO_HEISA_KBN,
                        weekRow.TEL_NASHI_FLG,
                        weekRow.MIKAKUNIN_FLG,
                        weekRow.SAISHINSA_KBN_CD,
                        SUBSTR(weekRow.BED_SU_KKNN_EIGY_YMD,1,4),
                        SUBSTR(weekRow.BED_SU_KKNN_EIGY_YMD,5,2),
                        SUBSTR(weekRow.BED_SU_KKNN_EIGY_YMD,7,2),
                        weekRow.KYOKA_BED_SU_SONOTA,
                        weekRow.KYOKA_BED_SU_SEISHIN,
                        weekRow.KYOKA_BED_SU_KEKKAKU,
                        weekRow.KYOKA_BED_SU_KANSEN,
                        weekRow.KYOKA_BED_SU_GOKEI,
                        weekRow.BYOIN_SBT_CD,
                        weekRow.DAIHYO_REC_ID,
                        weekRow.DAIHYO_KJN_CD,
                        weekRow.KJN_NM_KANA,
                        weekRow.KJN_NM,
                        weekRow.CHOFUKU_AITSK_REC_ID,
                        weekRow.CHOFUKU_AITSK_SHI_CD,
                        -- ������2012/11/28 NH000032�̑Ή�
                        SUBSTR(vNEW_KAIGYO_YOTEI_YM,1,4),
                        SUBSTR(vNEW_KAIGYO_YOTEI_YM,5,2),
                        --CASE
                        --  WHEN weekRow.KAIGYO_YOTEI_FLG = '1' THEN SUBSTR(weekRow.KAIGYO_YOTEI_YM,1,4)
                        --  WHEN weekRow.KYUIN_FLG = '1' THEN SUBSTR(weekRow.KYUIN_S_YM,1,4)
                        --  ELSE NULL
                        --END,
                        --CASE
                        --  WHEN weekRow.KAIGYO_YOTEI_FLG = '1' THEN SUBSTR(weekRow.KAIGYO_YOTEI_YM,5,2)
                        --  WHEN weekRow.KYUIN_FLG = '1' THEN SUBSTR(weekRow.KYUIN_S_YM,5,2)
                        --  ELSE NULL
                        --END,
                        -- ������2012/11/28 NH000032�̑Ή�
                        weekRow.KYOKA_BED_SU_IPPAN,
                        weekRow.KYOKA_BED_SU_RYOYO,
                        weekRow.SNRYKMK_CD_01,
                        weekRow.SNRYKMK_CD_02,
                        weekRow.SNRYKMK_CD_03,
                        weekRow.SNRYKMK_CD_04,
                        weekRow.SNRYKMK_CD_05,
                        weekRow.SNRYKMK_CD_06,
                        weekRow.SNRYKMK_CD_07,
                        weekRow.SNRYKMK_CD_08,
                        weekRow.SNRYKMK_CD_09,
                        weekRow.SNRYKMK_CD_10,
                        weekRow.SNRYKMK_CD_11,
                        weekRow.SNRYKMK_CD_12,
                        weekRow.SNRYKMK_CD_13,
                        weekRow.SNRYKMK_CD_14,
                        weekRow.SNRYKMK_CD_15,
                        weekRow.SNRYKMK_CD_16,
                        weekRow.SNRYKMK_CD_17,
                        weekRow.SNRYKMK_CD_18,
                        weekRow.SNRYKMK_CD_19,
                        weekRow.SNRYKMK_CD_20,
                        weekRow.SNRYKMK_CD_21,
                        weekRow.SNRYKMK_CD_22,
                        weekRow.SNRYKMK_CD_23,
                        weekRow.SNRYKMK_CD_24,
                        weekRow.SNRYKMK_CD_25,
                        weekRow.SNRYKMK_CD_26,
                        weekRow.SNRYKMK_CD_27,
                        weekRow.SNRYKMK_CD_28,
                        weekRow.SNRYKMK_CD_29,
                        weekRow.SNRYKMK_CD_30,
                        weekRow.SNRYKMK_CD_31,
                        weekRow.SNRYKMK_CD_32,
                        weekRow.SNRYKMK_CD_33,
                        weekRow.SNRYKMK_CD_34,
                        weekRow.SNRYKMK_CD_35,
                        weekRow.SNRYKMK_CD_36,
                        weekRow.SNRYKMK_CD_37,
                        weekRow.SNRYKMK_CD_38,
                        weekRow.SNRYKMK_CD_39,
                        weekRow.SNRYKMK_CD_40,
                        weekRow.SNRYKMK_CD_41,
                        weekRow.SNRYKMK_CD_42,
                        weekRow.SNRYKMK_CD_43,
                        weekRow.SNRYKMK_CD_44,
                        weekRow.SNRYKMK_CD_45,
                        weekRow.SNRYKMK_CD_46,
                        weekRow.SNRYKMK_CD_47,
                        weekRow.SNRYKMK_CD_48,
                        weekRow.SNRYKMK_CD_49,
                        weekRow.SNRYKMK_CD_50,
                        weekRow.SNRYKMK_CD_51,
                        weekRow.SNRYKMK_CD_52,
                        weekRow.SNRYKMK_CD_53,
                        weekRow.SNRYKMK_CD_54,
                        weekRow.SNRYKMK_CD_55,
                        weekRow.SNRYKMK_CD_56,
                        weekRow.SNRYKMK_CD_57,
                        weekRow.SNRYKMK_CD_58,
                        weekRow.SNRYKMK_CD_59,
                        weekRow.SNRYKMK_CD_60,
                        weekRow.SEISHIKI_SHI_NM,
                        weekRow.SEISHIKI_SHI_NM_KANA,
                        SUBSTR(iTensoYMD,1,4),
                        SUBSTR(iTensoYMD,5,2),
                        SUBSTR(iTensoYMD,7,2),
                        SUBSTR(weekRow.UPD_EIGY_YMD,1,4),
                        SUBSTR(weekRow.UPD_EIGY_YMD,5,2),
                        SUBSTR(weekRow.UPD_EIGY_YMD,7,2),
                        vMODKBN,
                        iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID
                     );
                     EXECUTE_SQL := 'INSERT INTO TD_PW_DCF_SHI(
                      SHIREC_ID,
                      SHI_CD,
                      SEISHIKI_SHI_NM_KANA,
                      RYKSK_SHI_NM_KANA,
                      SEISHIKI_SHI_NM_KANJI,
                      RYKSK_SHI_NM_KANJI,
                      KANREN_DAIGAKU_OYA_SHIREC_ID,
                      KANREN_DAIGAKU_OYA_SHI_CD,
                      JUSHO_KANA,
                      JUSHO_KANJI,
                      JUSHO_CD_KEN_CD,
                      JUSHO_CD_SHIKU_CD,
                      JUSHO_CD_OAZA_CD,
                      JUSHO_CD_AZA_CD,
                      ZIP,
                      JUSHO_HYOJI_NO,
                      JUSHO_COUNT_KANA_KEN,
                      JUSHO_COUNT_KANA_SHIKU,
                      JUSHO_COUNT_KANA_OAZA,
                      JUSHO_COUNT_KANJI_KEN,
                      JUSHO_COUNT_KANJI_SHIKU,
                      JUSHO_COUNT_KANJI_OAZA,
                      JUSHO_COUNT_KANA_AZA,
                      JUSHO_COUNT_KANJI_AZA,
                      SHI_TEL,
                      BED_SU_TEIIN,
                      KEIEITAI,
                      SHI_KBN,
                      KENSAKOMOKU_BISEIBUTSU,
                      KENSAKOMOKU_KESSEI,
                      KENSAKOMOKU_KETSUEKI,
                      KENSAKOMOKU_BYORI,
                      KENSAKOMOKU_KISEICHU,
                      KENSAKOMOKU_SEIKA,
                      KENSAKOMOKU_RI,
                      STATUS_JUSHOFUMEI,
                      STATUS_KYUIN_FLG,
                      STATUS_DEL_YOTEI_RIYU,
                      STATUS_KAIGYO_YOTEI_FLG,
                      STATUS_BYOTO_HEISA_FLG,
                      STATUS_TEL_NASHI_FLG,
                      STATUS_MIKAKUNIN_FLG,
                      STATUS_SAISHINSA_KBN,
                      KYOKA_BED_MENTE_HIZUKE_Y,
                      KYOKA_BED_MENTE_HIZUKE_M,
                      KYOKA_BED_MENTE_HIZUKE_D,
                      KYOKA_BED_SU_SONOTA,
                      KYOKA_BED_SU_SEISHIN,
                      KYOKA_BED_SU_KEKKAKU,
                      KYOKA_BED_SU_KANSEN,
                      KYOKA_BED_SU_GOKEI,
                      BYOIN_SBT,
                      SHI_DAIHYO_KJNREC_ID,
                      SHI_DAIHYO_KJN_CD,
                      SHI_DAIHYO_KANA,
                      SHI_DAIHYO_KANJI,
                      AITSK_CD_SHIREC_ID,
                      AITSK_CD_SHI_CD,
                      KYUIN_S_KAIGYO_YOTEI_Y,
                      KYUIN_S_KAIGYO_YOTEI_M,
                      SHIN_BED_KBN_IPPAN_BED,
                      SHIN_BED_KBN_RYOYO_BED,
                      SNRYKMK_1,
                      SNRYKMK_2,
                      SNRYKMK_3,
                      SNRYKMK_4,
                      SNRYKMK_5,
                      SNRYKMK_6,
                      SNRYKMK_7,
                      SNRYKMK_8,
                      SNRYKMK_9,
                      SNRYKMK_10,
                      SNRYKMK_11,
                      SNRYKMK_12,
                      SNRYKMK_13,
                      SNRYKMK_14,
                      SNRYKMK_15,
                      SNRYKMK_16,
                      SNRYKMK_17,
                      SNRYKMK_18,
                      SNRYKMK_19,
                      SNRYKMK_20,
                      SNRYKMK_21,
                      SNRYKMK_22,
                      SNRYKMK_23,
                      SNRYKMK_24,
                      SNRYKMK_25,
                      SNRYKMK_26,
                      SNRYKMK_27,
                      SNRYKMK_28,
                      SNRYKMK_29,
                      SNRYKMK_30,
                      SNRYKMK_31,
                      SNRYKMK_32,
                      SNRYKMK_33,
                      SNRYKMK_34,
                      SNRYKMK_35,
                      SNRYKMK_36,
                      SNRYKMK_37,
                      SNRYKMK_38,
                      SNRYKMK_39,
                      SNRYKMK_40,
                      SNRYKMK_41,
                      SNRYKMK_42,
                      SNRYKMK_43,
                      SNRYKMK_44,
                      SNRYKMK_45,
                      SNRYKMK_46,
                      SNRYKMK_47,
                      SNRYKMK_48,
                      SNRYKMK_49,
                      SNRYKMK_50,
                      SNRYKMK_51,
                      SNRYKMK_52,
                      SNRYKMK_53,
                      SNRYKMK_54,
                      SNRYKMK_55,
                      SNRYKMK_56,
                      SNRYKMK_57,
                      SNRYKMK_58,
                      SNRYKMK_59,
                      SNRYKMK_60,
                      SHIN_SEISHIKI_SHI_NM_KANJI,
                      SHIN_SEISHIKI_SHI_NM_KANA,
                      TENSO_Y,
                      TENSO_M,
                      TENSO_D,
                      MOD_SHORI_HIZUKE_Y,
                      MOD_SHORI_HIZUKE_M,
                      MOD_SHORI_HIZUKE_D,
                      MOD_KBN,
                      TRK_OPE_CD,TRK_DATE,TRK_PGM_ID,UPD_OPE_CD,UPD_DATE,UPD_PGM_ID
                     )
                     VALUES(
                       '''||weekRow.REC_ID||''',
                       '''||weekRow.SHI_CD||''',
                       '''||weekRow.SEISHIKI_SHI_NM_KANA40||''',
                       '''||weekRow.SHI_RN_KANA||''',
                       '''||weekRow.SEISHIKI_SHI_NM30||''',
                       '''||weekRow.SHI_RN||''',
                       '''||weekRow.KANREN_DAIGAKU_OYA_REC_ID||''',
                       '''||weekRow.KANREN_DAIGAKU_OYA_SHI_CD||''',
                       '''||weekRow.JUSHO_KANA_RENKETSU||''',
                       '''||weekRow.JUSHO_KANJI_RENKETSU||''',
                       '''||weekRow.KEN_CD||''',
                       '''||weekRow.SHIKU_CD||''',
                       '''||weekRow.OAZA_CD||''',
                       '''||weekRow.AZA_CD||''',
                       '''||CASE WHEN weekRow.ZIP IS NOT NULL THEN SUBSTR(weekRow.ZIP,1,3)||'-'||SUBSTR(weekRow.ZIP,4) ELSE NULL END ||''',
                       '''||weekRow.JUSHO_HYOJI_NO||''',
                       '''||weekRow.KEN_NM_KANA_MOJI_SU||''',
                       '''||weekRow.SHIKU_NM_KANA_MOJI_SU||''',
                       '''||weekRow.OAZA_NM_KANA_MOJI_SU||''',
                       '''||weekRow.KEN_NM_KANJI_MOJI_SU||''',
                       '''||weekRow.SHIKU_NM_KANJI_MOJI_SU||''',
                       '''||weekRow.OAZA_NM_KANJI_MOJI_SU||''',
                       '''||weekRow.AZA_NM_KANA_MOJI_SU||''',
                       '''||weekRow.AZA_NM_KANJI_MOJI_SU||''',
                       '''||weekRow.TEL||''',
                       '''||weekRow.SHI_BED_SU||''',
                       '''||weekRow.KEIEITAI_CD||''',
                       '''||weekRow.SHI_KBN_CD||''',
                       '''||weekRow.KENSAKOMOKU_BISEIBUTSU_FLG||''',
                       '''||weekRow.KENSAKOMOKU_KESSEI_FLG||''',
                       '''||weekRow.KENSAKOMOKU_KETSUEKI_FLG||''',
                       '''||weekRow.KENSAKOMOKU_BYORI_FLG||''',
                       '''||weekRow.KENSAKOMOKU_KISEICHU_FLG||''',
                       '''||weekRow.KENSAKOMOKU_SEIKA_FLG||''',
                       '''||weekRow.KENSAKOMOKU_RI_FLG||''',
                       '''||weekRow.JUSHOFUMEI_CD||''',
                       '''||weekRow.KYUIN_FLG||''',
                       '''||weekRow.DEL_YOTEI_RIYU_CD||''',
                       '''||weekRow.KAIGYO_YOTEI_FLG||''',
                       '''||weekRow.BYOTO_HEISA_KBN||''',
                       '''||weekRow.TEL_NASHI_FLG||''',
                       '''||weekRow.MIKAKUNIN_FLG||''',
                       '''||weekRow.SAISHINSA_KBN_CD||''',
                       '''||SUBSTR(weekRow.BED_SU_KKNN_EIGY_YMD,1,4)||''',
                       '''||SUBSTR(weekRow.BED_SU_KKNN_EIGY_YMD,5,2)||''',
                       '''||SUBSTR(weekRow.BED_SU_KKNN_EIGY_YMD,7,2)||''',
                       '''||weekRow.KYOKA_BED_SU_SONOTA||''',
                       '''||weekRow.KYOKA_BED_SU_SEISHIN||''',
                       '''||weekRow.KYOKA_BED_SU_KEKKAKU||''',
                       '''||weekRow.KYOKA_BED_SU_KANSEN||''',
                       '''||weekRow.KYOKA_BED_SU_GOKEI||''',
                       '''||weekRow.BYOIN_SBT_CD||''',
                       '''||weekRow.DAIHYO_REC_ID||''',
                       '''||weekRow.DAIHYO_KJN_CD||''',
                       '''||weekRow.KJN_NM_KANA||''',
                       '''||weekRow.KJN_NM||''',
                       '''||weekRow.CHOFUKU_AITSK_REC_ID||''',
                       '''||weekRow.CHOFUKU_AITSK_SHI_CD||''',
                       '''||CASE
                          WHEN weekRow.KAIGYO_YOTEI_FLG = '1' THEN SUBSTR(weekRow.KAIGYO_YOTEI_YM,1,4)
                          WHEN weekRow.KYUIN_FLG = '1' THEN SUBSTR(weekRow.KYUIN_S_YM,1,4)
                          ELSE NULL
                        END||''',
                       '''||CASE
                          WHEN weekRow.KAIGYO_YOTEI_FLG = '1' THEN SUBSTR(weekRow.KAIGYO_YOTEI_YM,5,2)
                          WHEN weekRow.KYUIN_FLG = '1' THEN SUBSTR(weekRow.KYUIN_S_YM,5,2)
                          ELSE NULL
                        END||''',
                       '''||weekRow.KYOKA_BED_SU_IPPAN||''',
                       '''||weekRow.KYOKA_BED_SU_RYOYO||''',
                       '''||weekRow.SNRYKMK_CD_01||''',
                       '''||weekRow.SNRYKMK_CD_02||''',
                       '''||weekRow.SNRYKMK_CD_03||''',
                       '''||weekRow.SNRYKMK_CD_04||''',
                       '''||weekRow.SNRYKMK_CD_05||''',
                       '''||weekRow.SNRYKMK_CD_06||''',
                       '''||weekRow.SNRYKMK_CD_07||''',
                       '''||weekRow.SNRYKMK_CD_08||''',
                       '''||weekRow.SNRYKMK_CD_09||''',
                       '''||weekRow.SNRYKMK_CD_10||''',
                       '''||weekRow.SNRYKMK_CD_11||''',
                       '''||weekRow.SNRYKMK_CD_12||''',
                       '''||weekRow.SNRYKMK_CD_13||''',
                       '''||weekRow.SNRYKMK_CD_14||''',
                       '''||weekRow.SNRYKMK_CD_15||''',
                       '''||weekRow.SNRYKMK_CD_16||''',
                       '''||weekRow.SNRYKMK_CD_17||''',
                       '''||weekRow.SNRYKMK_CD_18||''',
                       '''||weekRow.SNRYKMK_CD_19||''',
                       '''||weekRow.SNRYKMK_CD_20||''',
                       '''||weekRow.SNRYKMK_CD_21||''',
                       '''||weekRow.SNRYKMK_CD_22||''',
                       '''||weekRow.SNRYKMK_CD_23||''',
                       '''||weekRow.SNRYKMK_CD_24||''',
                       '''||weekRow.SNRYKMK_CD_25||''',
                       '''||weekRow.SNRYKMK_CD_26||''',
                       '''||weekRow.SNRYKMK_CD_27||''',
                       '''||weekRow.SNRYKMK_CD_28||''',
                       '''||weekRow.SNRYKMK_CD_29||''',
                       '''||weekRow.SNRYKMK_CD_30||''',
                       '''||weekRow.SNRYKMK_CD_31||''',
                       '''||weekRow.SNRYKMK_CD_32||''',
                       '''||weekRow.SNRYKMK_CD_33||''',
                       '''||weekRow.SNRYKMK_CD_34||''',
                       '''||weekRow.SNRYKMK_CD_35||''',
                       '''||weekRow.SNRYKMK_CD_36||''',
                       '''||weekRow.SNRYKMK_CD_37||''',
                       '''||weekRow.SNRYKMK_CD_38||''',
                       '''||weekRow.SNRYKMK_CD_39||''',
                       '''||weekRow.SNRYKMK_CD_40||''',
                       '''||weekRow.SNRYKMK_CD_41||''',
                       '''||weekRow.SNRYKMK_CD_42||''',
                       '''||weekRow.SNRYKMK_CD_43||''',
                       '''||weekRow.SNRYKMK_CD_44||''',
                       '''||weekRow.SNRYKMK_CD_45||''',
                       '''||weekRow.SNRYKMK_CD_46||''',
                       '''||weekRow.SNRYKMK_CD_47||''',
                       '''||weekRow.SNRYKMK_CD_48||''',
                       '''||weekRow.SNRYKMK_CD_49||''',
                       '''||weekRow.SNRYKMK_CD_50||''',
                       '''||weekRow.SNRYKMK_CD_51||''',
                       '''||weekRow.SNRYKMK_CD_52||''',
                       '''||weekRow.SNRYKMK_CD_53||''',
                       '''||weekRow.SNRYKMK_CD_54||''',
                       '''||weekRow.SNRYKMK_CD_55||''',
                       '''||weekRow.SNRYKMK_CD_56||''',
                       '''||weekRow.SNRYKMK_CD_57||''',
                       '''||weekRow.SNRYKMK_CD_58||''',
                       '''||weekRow.SNRYKMK_CD_59||''',
                       '''||weekRow.SNRYKMK_CD_60||''',
                       '''||weekRow.SEISHIKI_SHI_NM||''',
                       '''||weekRow.SEISHIKI_SHI_NM_KANA||''',
                       '''||SUBSTR(iTensoYMD,1,4)||''',
                       '''||SUBSTR(iTensoYMD,5,2)||''',
                       '''||SUBSTR(iTensoYMD,7,2)||''',
                       '''||SUBSTR(weekRow.UPD_EIGY_YMD,1,4)||''',
                       '''||SUBSTR(weekRow.UPD_EIGY_YMD,5,2)||''',
                       '''||SUBSTR(weekRow.UPD_EIGY_YMD,7,2)||''',
                       '''||vMODKBN||''',                                          
                       '''||iOPE_CD||''',
                       '''||iDATE||''',
                       '''||iPGM_ID||''',
                       '''||iOPE_CD||''',
                       '''||iDATE||''',
                       '''||iPGM_ID||''')';
                     ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);  
                     IF  weekRow.IMUSHITSU_REC_ID IS NOT NULL THEN
                       INSERT INTO TD_PW_TOKUITBL(
                          KO_SHIREC_ID,
                          KO_SHI_CD,
                          OYA_SHIREC_ID,
                          OYA_SHI_CD,
                          TENSO_Y,
                          TENSO_M,
                          TENSO_D,
                          MENTE_Y,
                          MENTE_M,
                          MENTE_D,
                          MOD_KBN,                   
                          TRK_OPE_CD,TRK_DATE,TRK_PGM_ID,UPD_OPE_CD,UPD_DATE,UPD_PGM_ID
                       )
                       VALUES(
                          weekRow.REC_ID,
                          weekRow.SHI_CD,
                          weekRow.IMUSHITSU_REC_ID,
                          weekRow.IMUSHITSU_SHI_CD,
                          SUBSTR(iTensoYMD,1,4),
                          SUBSTR(iTensoYMD,5,2),
                          SUBSTR(iTensoYMD,7,2),
                          SUBSTR(weekRow.UPD_EIGY_YMD,1,4),
                          SUBSTR(weekRow.UPD_EIGY_YMD,5,2),
                          SUBSTR(weekRow.UPD_EIGY_YMD,7,2),
                          vMODKBN,
                          iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID
                       );
                       EXECUTE_SQL := 'INSERT INTO TD_PW_TOKUITBL(
                          KO_SHIREC_ID,
                          KO_SHI_CD,
                          OYA_SHIREC_ID,
                          OYA_SHI_CD,
                          TENSO_Y,
                          TENSO_M,
                          TENSO_D,
                          MENTE_Y,
                          MENTE_M,
                          MENTE_D,
                          MOD_KBN,                   
                          TRK_OPE_CD,TRK_DATE,TRK_PGM_ID,UPD_OPE_CD,UPD_DATE,UPD_PGM_ID
                       )
                       VALUES(
                          '''||weekRow.REC_ID||''',
                          '''||weekRow.SHI_CD||''',
                          '''||weekRow.IMUSHITSU_REC_ID||''',
                          '''||weekRow.IMUSHITSU_SHI_CD||''',
                          '''||SUBSTR(iTensoYMD,1,4)||''',
                          '''||SUBSTR(iTensoYMD,5,2)||''',
                          '''||SUBSTR(iTensoYMD,7,2)||''',
                          '''||SUBSTR(weekRow.UPD_EIGY_YMD,1,4)||''',
                          '''||SUBSTR(weekRow.UPD_EIGY_YMD,5,2)||''',
                          '''||SUBSTR(weekRow.UPD_EIGY_YMD,7,2)||''',
                          '''||vMODKBN||''',
                          '''||iOPE_CD||''',
                          '''||iDATE||''',
                          '''||iPGM_ID||''',
                          '''||iOPE_CD||''',
                          '''||iDATE||''',
                          '''||iPGM_ID||''')';
                       ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);   
                     END IF;
                END IF;
              END IF;
            END IF;
                   
          END LOOP;
          CLOSE weekCSR;

      --���ߓ��敪��"4"(������)�A�܂��́A"5"(������)�̎��A
      ELSIF iShimeKind = ULT_COMMON.SHIME_SBT_CD_NAKASHIME OR iShimeKind = ULT_COMMON.SHIME_SBT_CD_MATSUSHIME THEN
        
          --��1���߂̏ꍇ
          IF iM2Flg = ULT_COMMON.FLG_NO THEN
            IF iLayoutKind = ULT_COMMON.LAYOUT_SBT_CD_SHIN THEN
              --�V_��1����_DCF�{�݃e�[�u���̃f�[�^���N���A����B
              EXECUTE_SQL := 'TRUNCATE TABLE ' || vSchemaNm || '.' || 'TD_NM_DCF_SHI';                       
            END IF; 
            IF iLayoutKind = ULT_COMMON.LAYOUT_SBT_CD_ZANTEI THEN
              --�b��_��1����_DCF�{�݃e�[�u���̃f�[�^���N���A����B
              EXECUTE_SQL := 'TRUNCATE TABLE ' || vSchemaNm || '.' || 'TD_PM_DCF_SHI';                     
            END IF;
          ELSIF iM2Flg = ULT_COMMON.FLG_YES THEN
            --��2���߂̏ꍇ
            IF iLayoutKind = ULT_COMMON.LAYOUT_SBT_CD_SHIN THEN
              --�V_��2����_DCF�{�݃e�[�u���̃f�[�^���N���A����B
              EXECUTE_SQL := 'TRUNCATE TABLE ' || vSchemaNm || '.' || 'TD_N2_DCF_SHI';                     
            END IF; 
            IF iLayoutKind = ULT_COMMON.LAYOUT_SBT_CD_ZANTEI THEN
              --�b��_��2����_DCF�{�݃e�[�u���̃f�[�^���N���A����B
              EXECUTE_SQL := 'TRUNCATE TABLE ' || vSchemaNm || '.' || 'TD_P2_DCF_SHI';                    
            END IF;
          END IF;
          EXECUTE IMMEDIATE EXECUTE_SQL;         
          ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);
          
          EXECUTE_SQL := 'SELECT
          TTS.REC_ID                              ,
          TTS.SHI_CD                              ,
          TTS.DEL_FLG                             ,
          TTS.DEL_YOTEI_RIYU_CD                   ,
          TTS.CHOFUKU_AITSK_REC_ID                ,
          TTS.CHOFUKU_AITSK_SHI_CD                ,
          TTS.KYUIN_FLG                           ,
          TTS.KYUIN_S_YM                          ,
          TTS.KAIGYO_YOTEI_FLG                    ,
          TTS.KAIGYO_YOTEI_YM                     ,
          TTS.KANREN_DAIGAKU_OYA_REC_ID           ,
          TTS.KANREN_DAIGAKU_OYA_SHI_CD           ,
          TTS.SEISHIKI_SHI_NM                     ,
          TTS.SEISHIKI_SHI_NM30                   ,
          TTS.SEISHIKI_SHI_NM_KANA                ,
          TTS.SEISHIKI_SHI_NM_KANA40              ,
          TTS.SHI_RN                              ,
          TTS.SHI_RN_KANA                         ,
          TTS.KEN_CD                              ,
          TTS.SHIKU_CD                            ,
          TTS.OAZA_CD                             ,
          TTS.AZA_CD                              ,
          TTS.ZIP                                 ,
          TTS.JUSHO_KANJI_RENKETSU                ,
          TTS.JUSHO_KANA_RENKETSU                 ,
          TTS.KEN_NM_KANJI_MOJI_SU                ,
          TTS.SHIKU_NM_KANJI_MOJI_SU              ,
          TTS.OAZA_NM_KANJI_MOJI_SU               ,
          TTS.AZA_NM_KANJI_MOJI_SU                ,
          TTS.KEN_NM_KANA_MOJI_SU                 ,
          TTS.SHIKU_NM_KANA_MOJI_SU               ,
          TTS.OAZA_NM_KANA_MOJI_SU                ,
          TTS.AZA_NM_KANA_MOJI_SU                 ,
          TTS.JUSHO_HYOJI_NO                      ,
          TTS.JUSHOFUMEI_CD                       ,
          TTS.TEL                                 ,
          TTS.KEIEITAI_CD                         ,
          TTS.SHI_KBN_CD                          ,
          TTS.IMUSHITSU_REC_ID                    ,
          TTS.IMUSHITSU_SHI_CD                    ,
          TTS.SAISHINSA_KBN_CD                    ,
          TTS.BYOTO_HEISA_KBN                     ,
          TTS.TEL_NASHI_FLG                       ,
          TTS.MIKAKUNIN_FLG                       ,
          TTS.DAIHYO_REC_ID                       ,
          TTS.DAIHYO_KJN_CD                       ,
          TTK.KJN_NM                            ,
          TTK.KJN_NM_KANA                     ,
          TTS.SHI_BED_SU                          ,
          TTS.BYOIN_SBT_CD                        ,
          TTS.KYOKA_BED_SU_SONOTA                 ,
          TTS.KYOKA_BED_SU_SEISHIN                ,
          TTS.KYOKA_BED_SU_KEKKAKU                ,
          TTS.KYOKA_BED_SU_KANSEN                 ,
          TTS.KYOKA_BED_SU_GOKEI,
          TTS.KYOKA_BED_SU_IPPAN                  ,
          TTS.KYOKA_BED_SU_RYOYO                  ,
          TTS.BED_SU_KKNN_EIGY_YMD                ,
          TTS.SNRYKMK_CD_01                       ,
          TTS.SNRYKMK_CD_02                       ,
          TTS.SNRYKMK_CD_03                       ,
          TTS.SNRYKMK_CD_04                       ,
          TTS.SNRYKMK_CD_05                       ,
          TTS.SNRYKMK_CD_06                       ,
          TTS.SNRYKMK_CD_07                       ,
          TTS.SNRYKMK_CD_08                       ,
          TTS.SNRYKMK_CD_09                       ,
          TTS.SNRYKMK_CD_10                       ,
          TTS.SNRYKMK_CD_11                       ,
          TTS.SNRYKMK_CD_12                       ,
          TTS.SNRYKMK_CD_13                       ,
          TTS.SNRYKMK_CD_14                       ,
          TTS.SNRYKMK_CD_15                       ,
          TTS.SNRYKMK_CD_16                       ,
          TTS.SNRYKMK_CD_17                       ,
          TTS.SNRYKMK_CD_18                       ,
          TTS.SNRYKMK_CD_19                       ,
          TTS.SNRYKMK_CD_20                       ,
          TTS.SNRYKMK_CD_21                       ,
          TTS.SNRYKMK_CD_22                       ,
          TTS.SNRYKMK_CD_23                       ,
          TTS.SNRYKMK_CD_24                       ,
          TTS.SNRYKMK_CD_25                       ,
          TTS.SNRYKMK_CD_26                       ,
          TTS.SNRYKMK_CD_27                       ,
          TTS.SNRYKMK_CD_28                       ,
          TTS.SNRYKMK_CD_29                       ,
          TTS.SNRYKMK_CD_30                       ,
          TTS.SNRYKMK_CD_31                       ,
          TTS.SNRYKMK_CD_32                       ,
          TTS.SNRYKMK_CD_33                       ,
          TTS.SNRYKMK_CD_34                       ,
          TTS.SNRYKMK_CD_35                       ,
          TTS.SNRYKMK_CD_36                       ,
          TTS.SNRYKMK_CD_37                       ,
          TTS.SNRYKMK_CD_38                       ,
          TTS.SNRYKMK_CD_39                       ,
          TTS.SNRYKMK_CD_40                       ,
          TTS.SNRYKMK_CD_41                       ,
          TTS.SNRYKMK_CD_42                       ,
          TTS.SNRYKMK_CD_43                       ,
          TTS.SNRYKMK_CD_44                       ,
          TTS.SNRYKMK_CD_45                       ,
          TTS.SNRYKMK_CD_46                       ,
          TTS.SNRYKMK_CD_47                       ,
          TTS.SNRYKMK_CD_48                       ,
          TTS.SNRYKMK_CD_49                       ,
          TTS.SNRYKMK_CD_50                       ,
          TTS.SNRYKMK_CD_51                       ,
          TTS.SNRYKMK_CD_52                       ,
          TTS.SNRYKMK_CD_53                       ,
          TTS.SNRYKMK_CD_54                       ,
          TTS.SNRYKMK_CD_55                       ,
          TTS.SNRYKMK_CD_56                       ,
          TTS.SNRYKMK_CD_57                       ,
          TTS.SNRYKMK_CD_58                       ,
          TTS.SNRYKMK_CD_59                       ,
          TTS.SNRYKMK_CD_60                       ,
          TTS.KENSAKOMOKU_BISEIBUTSU_FLG          ,
          TTS.KENSAKOMOKU_KESSEI_FLG              ,
          TTS.KENSAKOMOKU_KETSUEKI_FLG            ,
          TTS.KENSAKOMOKU_BYORI_FLG               ,
          TTS.KENSAKOMOKU_KISEICHU_FLG            ,
          TTS.KENSAKOMOKU_SEIKA_FLG               ,
          TTS.KENSAKOMOKU_RI_FLG                  ,
          TTS.UPD_EIGY_YMD ,
          TZMS.REC_ID                              AS  zREC_ID                              ,
          TZMS.SHI_CD                              AS  zSHI_CD                              ,
          TZMS.DEL_FLG                             AS  zDEL_FLG                             ,
          TZMS.DEL_YOTEI_RIYU_CD                   AS  zDEL_YOTEI_RIYU_CD                   ,
          TZMS.CHOFUKU_AITSK_REC_ID                AS  zCHOFUKU_AITSK_REC_ID                ,
          TZMS.CHOFUKU_AITSK_SHI_CD                AS  zCHOFUKU_AITSK_SHI_CD                ,
          TZMS.KYUIN_FLG                           AS  zKYUIN_FLG                           ,
          TZMS.KYUIN_S_YM                          AS  zKYUIN_S_YM                          ,
          TZMS.KAIGYO_YOTEI_FLG                    AS  zKAIGYO_YOTEI_FLG                    ,
          TZMS.KAIGYO_YOTEI_YM                     AS  zKAIGYO_YOTEI_YM                     ,
          TZMS.KANREN_DAIGAKU_OYA_REC_ID           AS  zKANREN_DAIGAKU_OYA_REC_ID           ,
          TZMS.KANREN_DAIGAKU_OYA_SHI_CD           AS  zKANREN_DAIGAKU_OYA_SHI_CD           ,
          TZMS.SEISHIKI_SHI_NM                     AS  zSEISHIKI_SHI_NM                     ,
          TZMS.SEISHIKI_SHI_NM30                   AS  zSEISHIKI_SHI_NM30                   ,
          TZMS.SEISHIKI_SHI_NM_KANA                AS  zSEISHIKI_SHI_NM_KANA                ,
          TZMS.SEISHIKI_SHI_NM_KANA40              AS  zSEISHIKI_SHI_NM_KANA40              ,
          TZMS.SHI_RN                              AS  zSHI_RN                              ,
          TZMS.SHI_RN_KANA                         AS  zSHI_RN_KANA                         ,
          TZMS.KEN_CD                              AS  zKEN_CD                              ,
          TZMS.SHIKU_CD                            AS  zSHIKU_CD                            ,
          TZMS.OAZA_CD                             AS  zOAZA_CD                             ,
          TZMS.AZA_CD                              AS  zAZA_CD                              ,
          TZMS.ZIP                                 AS  zZIP                                 ,
          TZMS.JUSHO_KANJI_RENKETSU                AS  zJUSHO_KANJI_RENKETSU                ,
          TZMS.JUSHO_KANA_RENKETSU                 AS  zJUSHO_KANA_RENKETSU                 ,
          TZMS.KEN_NM_KANJI_MOJI_SU                AS  zKEN_NM_KANJI_MOJI_SU                ,
          TZMS.SHIKU_NM_KANJI_MOJI_SU              AS  zSHIKU_NM_KANJI_MOJI_SU              ,
          TZMS.OAZA_NM_KANJI_MOJI_SU               AS  zOAZA_NM_KANJI_MOJI_SU               ,
          TZMS.AZA_NM_KANJI_MOJI_SU                AS  zAZA_NM_KANJI_MOJI_SU                ,
          TZMS.KEN_NM_KANA_MOJI_SU                 AS  zKEN_NM_KANA_MOJI_SU                 ,
          TZMS.SHIKU_NM_KANA_MOJI_SU               AS  zSHIKU_NM_KANA_MOJI_SU               ,
          TZMS.OAZA_NM_KANA_MOJI_SU                AS  zOAZA_NM_KANA_MOJI_SU                ,
          TZMS.AZA_NM_KANA_MOJI_SU                 AS  zAZA_NM_KANA_MOJI_SU                 ,
          TZMS.JUSHO_HYOJI_NO                      AS  zJUSHO_HYOJI_NO                      ,
          TZMS.JUSHOFUMEI_CD                       AS  zJUSHOFUMEI_CD                       ,
          TZMS.TEL                                 AS  zTEL                                 ,
          TZMS.KEIEITAI_CD                         AS  zKEIEITAI_CD                         ,
          TZMS.SHI_KBN_CD                          AS  zSHI_KBN_CD                          ,
          TZMS.IMUSHITSU_REC_ID                    AS  zIMUSHITSU_REC_ID                    ,
          TZMS.IMUSHITSU_SHI_CD                    AS  zIMUSHITSU_SHI_CD                    ,
          TZMS.SAISHINSA_KBN_CD                    AS  zSAISHINSA_KBN_CD                    ,
          TZMS.BYOTO_HEISA_KBN                     AS  zBYOTO_HEISA_KBN                     ,
          TZMS.TEL_NASHI_FLG                       AS  zTEL_NASHI_FLG                       ,
          TZMS.MIKAKUNIN_FLG                       AS  zMIKAKUNIN_FLG                       ,
          TZMS.DAIHYO_REC_ID                       AS  zDAIHYO_REC_ID                       ,
          TZMS.DAIHYO_KJN_CD                       AS  zDAIHYO_KJN_CD                       ,
          TZMK.KJN_NM                              AS  zKJN_NM                              ,
          TZMK.KJN_NM_KANA                         AS  zKJN_NM_KANA                         ,
          TZMS.SHI_BED_SU                          AS  zSHI_BED_SU                          ,
          TZMS.BYOIN_SBT_CD                        AS  zBYOIN_SBT_CD                        ,
          TZMS.KYOKA_BED_SU_SONOTA                 AS  zKYOKA_BED_SU_SONOTA                 ,
          TZMS.KYOKA_BED_SU_SEISHIN                AS  zKYOKA_BED_SU_SEISHIN                ,
          TZMS.KYOKA_BED_SU_KEKKAKU                AS  zKYOKA_BED_SU_KEKKAKU                ,
          TZMS.KYOKA_BED_SU_KANSEN                 AS  zKYOKA_BED_SU_KANSEN                 ,
          TZMS.KYOKA_BED_SU_GOKEI                  AS  zKYOKA_BED_SU_GOKEI                  ,
          TZMS.KYOKA_BED_SU_IPPAN                  AS  zKYOKA_BED_SU_IPPAN                  ,
          TZMS.KYOKA_BED_SU_RYOYO                  AS  zKYOKA_BED_SU_RYOYO                  ,
          TZMS.BED_SU_KKNN_EIGY_YMD                AS  zBED_SU_KKNN_EIGY_YMD                ,
          TZMS.SNRYKMK_CD_01                       AS  zSNRYKMK_CD_01                       ,
          TZMS.SNRYKMK_CD_02                       AS  zSNRYKMK_CD_02                       ,
          TZMS.SNRYKMK_CD_03                       AS  zSNRYKMK_CD_03                       ,
          TZMS.SNRYKMK_CD_04                       AS  zSNRYKMK_CD_04                       ,
          TZMS.SNRYKMK_CD_05                       AS  zSNRYKMK_CD_05                       ,
          TZMS.SNRYKMK_CD_06                       AS  zSNRYKMK_CD_06                       ,
          TZMS.SNRYKMK_CD_07                       AS  zSNRYKMK_CD_07                       ,
          TZMS.SNRYKMK_CD_08                       AS  zSNRYKMK_CD_08                       ,
          TZMS.SNRYKMK_CD_09                       AS  zSNRYKMK_CD_09                       ,
          TZMS.SNRYKMK_CD_10                       AS  zSNRYKMK_CD_10                       ,
          TZMS.SNRYKMK_CD_11                       AS  zSNRYKMK_CD_11                       ,
          TZMS.SNRYKMK_CD_12                       AS  zSNRYKMK_CD_12                       ,
          TZMS.SNRYKMK_CD_13                       AS  zSNRYKMK_CD_13                       ,
          TZMS.SNRYKMK_CD_14                       AS  zSNRYKMK_CD_14                       ,
          TZMS.SNRYKMK_CD_15                       AS  zSNRYKMK_CD_15                       ,
          TZMS.SNRYKMK_CD_16                       AS  zSNRYKMK_CD_16                       ,
          TZMS.SNRYKMK_CD_17                       AS  zSNRYKMK_CD_17                       ,
          TZMS.SNRYKMK_CD_18                       AS  zSNRYKMK_CD_18                       ,
          TZMS.SNRYKMK_CD_19                       AS  zSNRYKMK_CD_19                       ,
          TZMS.SNRYKMK_CD_20                       AS  zSNRYKMK_CD_20                       ,
          TZMS.SNRYKMK_CD_21                       AS  zSNRYKMK_CD_21                       ,
          TZMS.SNRYKMK_CD_22                       AS  zSNRYKMK_CD_22                       ,
          TZMS.SNRYKMK_CD_23                       AS  zSNRYKMK_CD_23                       ,
          TZMS.SNRYKMK_CD_24                       AS  zSNRYKMK_CD_24                       ,
          TZMS.SNRYKMK_CD_25                       AS  zSNRYKMK_CD_25                       ,
          TZMS.SNRYKMK_CD_26                       AS  zSNRYKMK_CD_26                       ,
          TZMS.SNRYKMK_CD_27                       AS  zSNRYKMK_CD_27                       ,
          TZMS.SNRYKMK_CD_28                       AS  zSNRYKMK_CD_28                       ,
          TZMS.SNRYKMK_CD_29                       AS  zSNRYKMK_CD_29                       ,
          TZMS.SNRYKMK_CD_30                       AS  zSNRYKMK_CD_30                       ,
          TZMS.SNRYKMK_CD_31                       AS  zSNRYKMK_CD_31                       ,
          TZMS.SNRYKMK_CD_32                       AS  zSNRYKMK_CD_32                       ,
          TZMS.SNRYKMK_CD_33                       AS  zSNRYKMK_CD_33                       ,
          TZMS.SNRYKMK_CD_34                       AS  zSNRYKMK_CD_34                       ,
          TZMS.SNRYKMK_CD_35                       AS  zSNRYKMK_CD_35                       ,
          TZMS.SNRYKMK_CD_36                       AS  zSNRYKMK_CD_36                       ,
          TZMS.SNRYKMK_CD_37                       AS  zSNRYKMK_CD_37                       ,
          TZMS.SNRYKMK_CD_38                       AS  zSNRYKMK_CD_38                       ,
          TZMS.SNRYKMK_CD_39                       AS  zSNRYKMK_CD_39                       ,
          TZMS.SNRYKMK_CD_40                       AS  zSNRYKMK_CD_40                       ,
          TZMS.SNRYKMK_CD_41                       AS  zSNRYKMK_CD_41                       ,
          TZMS.SNRYKMK_CD_42                       AS  zSNRYKMK_CD_42                       ,
          TZMS.SNRYKMK_CD_43                       AS  zSNRYKMK_CD_43                       ,
          TZMS.SNRYKMK_CD_44                       AS  zSNRYKMK_CD_44                       ,
          TZMS.SNRYKMK_CD_45                       AS  zSNRYKMK_CD_45                       ,
          TZMS.SNRYKMK_CD_46                       AS  zSNRYKMK_CD_46                       ,
          TZMS.SNRYKMK_CD_47                       AS  zSNRYKMK_CD_47                       ,
          TZMS.SNRYKMK_CD_48                       AS  zSNRYKMK_CD_48                       ,
          TZMS.SNRYKMK_CD_49                       AS  zSNRYKMK_CD_49                       ,
          TZMS.SNRYKMK_CD_50                       AS  zSNRYKMK_CD_50                       ,
          TZMS.SNRYKMK_CD_51                       AS  zSNRYKMK_CD_51                       ,
          TZMS.SNRYKMK_CD_52                       AS  zSNRYKMK_CD_52                       ,
          TZMS.SNRYKMK_CD_53                       AS  zSNRYKMK_CD_53                       ,
          TZMS.SNRYKMK_CD_54                       AS  zSNRYKMK_CD_54                       ,
          TZMS.SNRYKMK_CD_55                       AS  zSNRYKMK_CD_55                       ,
          TZMS.SNRYKMK_CD_56                       AS  zSNRYKMK_CD_56                       ,
          TZMS.SNRYKMK_CD_57                       AS  zSNRYKMK_CD_57                       ,
          TZMS.SNRYKMK_CD_58                       AS  zSNRYKMK_CD_58                       ,
          TZMS.SNRYKMK_CD_59                       AS  zSNRYKMK_CD_59                       ,
          TZMS.SNRYKMK_CD_60                       AS  zSNRYKMK_CD_60                       ,
          TZMS.KENSAKOMOKU_BISEIBUTSU_FLG          AS  zKENSAKOMOKU_BISEIBUTSU_FLG          ,
          TZMS.KENSAKOMOKU_KESSEI_FLG              AS  zKENSAKOMOKU_KESSEI_FLG              ,
          TZMS.KENSAKOMOKU_KETSUEKI_FLG            AS  zKENSAKOMOKU_KETSUEKI_FLG            ,
          TZMS.KENSAKOMOKU_BYORI_FLG               AS  zKENSAKOMOKU_BYORI_FLG               ,
          TZMS.KENSAKOMOKU_KISEICHU_FLG            AS  zKENSAKOMOKU_KISEICHU_FLG            ,
          TZMS.KENSAKOMOKU_SEIKA_FLG               AS  zKENSAKOMOKU_SEIKA_FLG               ,
          TZMS.KENSAKOMOKU_RI_FLG                  AS  zKENSAKOMOKU_RI_FLG                  ,
          TZMS.UPD_EIGY_YMD                        AS  zUPD_EIGY_YMD';
        
          --�����߂̏ꍇ
          IF iShimeKind = ULT_COMMON.SHIME_SBT_CD_NAKASHIME THEN
            -- �擾�����f��DB�f�[�^���������J��Ԃ�
            IF iM2Flg = ULT_COMMON.FLG_YES THEN  
               EXECUTE_SQL := EXECUTE_SQL||'
                FROM TT_TIKY_SHI TTS
                LEFT OUTER JOIN TT_TIKY_KJN TTK
                ON  TTS.DAIHYO_REC_ID = TTK.REC_ID
                AND TTS.DAIHYO_KJN_CD = TTK.KJN_CD
                AND TTK.DEL_FLG IS NULL
                LEFT OUTER JOIN TT_Z_ME_SHI�@TZMS
                ON  TTS.REC_ID = TZMS.REC_ID
                AND TTS.SHI_CD = TZMS.SHI_CD
                LEFT OUTER JOIN TT_Z_ME_KJN TZMK
                ON  TZMS.DAIHYO_REC_ID = TZMK.REC_ID
                AND TZMS.DAIHYO_KJN_CD = TZMK.KJN_CD
                WHERE�@TTS.REC_ID�@= ''00''																	
                   AND TTS.UPD_EIGY_YMD�@>= NVL('''||iShimeFrom||''', ''19700101'')																
                   AND TTS.UPD_EIGY_YMD�@<= iShimeTo' ;
               ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);    
               OPEN m2CSR ;
            ELSE
               EXECUTE_SQL := EXECUTE_SQL||'
                FROM TT_TIKY_SHI TTS
                LEFT OUTER JOIN TT_TIKY_KJN TTK
                ON  TTS.DAIHYO_REC_ID = TTK.REC_ID
                AND TTS.DAIHYO_KJN_CD = TTK.KJN_CD
                AND TTK.DEL_FLG IS NULL
                LEFT OUTER JOIN TT_Z_MM_SHI�@TZMS
                ON  TTS.REC_ID = TZMS.REC_ID
                AND TTS.SHI_CD = TZMS.SHI_CD
                LEFT OUTER JOIN TT_Z_MM_KJN TZMK
                ON  TZMS.DAIHYO_REC_ID = TZMK.REC_ID
                AND TZMS.DAIHYO_KJN_CD = TZMK.KJN_CD
                WHERE�@TTS.REC_ID�@= ''00''																	
                   AND TTS.UPD_EIGY_YMD�@>= NVL('''||iShimeFrom||''', ''19700101'')																
                   AND TTS.UPD_EIGY_YMD�@<= iShimeTo' ;
               ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);    
               OPEN m1CSR ;    
            END IF;
            
            LOOP
              IF iM2Flg = ULT_COMMON.FLG_YES THEN  
                 FETCH m2CSR INTO m1Row;
                 EXIT WHEN m2CSR%NOTFOUND;
              ELSE
                 FETCH m1CSR INTO m1Row;  
                 EXIT WHEN m1CSR%NOTFOUND;   
              END IF;
                             
              oROW_COUNT:=oROW_COUNT+1;
              --�O���r���R�[�h�̎{�݃R�[�h�ƃ��R�[�hID��NULL�ł͂Ȃ����A
              IF m1Row.zREC_ID IS NOT  NULL AND m1Row.zSHI_CD IS NOT  NULL THEN
                --�񋟗p���R�[�h�̍폜�t���O = "1"�̎��A 
                IF m1Row.DEL_FLG = '1' THEN
                  vMODKBN := ULT_COMMON.MOD_KBN_DEL;
                ELSE
                  --���C�A�E�g�敪��"1"(�V���C�A�E�g)
                  IF iLayoutKind = ULT_COMMON.LAYOUT_SBT_CD_SHIN THEN
                     --�񋟗p���R�[�h�Ǝ擾�����O���r���R�[�h���r  
                      IF    '1'||m1Row.MIKAKUNIN_FLG = '1'||m1Row.zMIKAKUNIN_FLG
                        AND '1'||m1Row.DEL_YOTEI_RIYU_CD = '1'||m1Row.zDEL_YOTEI_RIYU_CD
                        AND '1'||m1Row.CHOFUKU_AITSK_REC_ID = '1'||m1Row.zCHOFUKU_AITSK_REC_ID
                        AND '1'||m1Row.CHOFUKU_AITSK_SHI_CD = '1'||m1Row.zCHOFUKU_AITSK_SHI_CD
                        AND '1'||m1Row.SEISHIKI_SHI_NM = '1'||m1Row.zSEISHIKI_SHI_NM
                        AND '1'||m1Row.SEISHIKI_SHI_NM_KANA = '1'||m1Row.zSEISHIKI_SHI_NM_KANA
                        AND '1'||m1Row.SHI_RN = '1'||m1Row.zSHI_RN
                        AND '1'||m1Row.SHI_RN_KANA = '1'||m1Row.zSHI_RN_KANA
                        AND '1'||m1Row.JUSHOFUMEI_CD = '1'||m1Row.zJUSHOFUMEI_CD
                        AND '1'||m1Row.KEN_CD = '1'||m1Row.zKEN_CD
                        AND '1'||m1Row.SHIKU_CD = '1'||m1Row.zSHIKU_CD
                        AND '1'||m1Row.OAZA_CD = '1'||m1Row.zOAZA_CD
                        AND '1'||m1Row.AZA_CD = '1'||m1Row.zAZA_CD
                        AND '1'||m1Row.ZIP = '1'||m1Row.zZIP
                        AND '1'||m1Row.JUSHO_KANJI_RENKETSU = '1'||m1Row.zJUSHO_KANJI_RENKETSU
                        AND '1'||m1Row.JUSHO_KANA_RENKETSU = '1'||m1Row.zJUSHO_KANA_RENKETSU
                        AND '1'||m1Row.JUSHO_HYOJI_NO = '1'||m1Row.zJUSHO_HYOJI_NO
                        AND '1'||m1Row.KEN_NM_KANJI_MOJI_SU = '1'||m1Row.zKEN_NM_KANJI_MOJI_SU
                        AND '1'||m1Row.SHIKU_NM_KANJI_MOJI_SU = '1'||m1Row.zSHIKU_NM_KANJI_MOJI_SU
                        AND '1'||m1Row.OAZA_NM_KANJI_MOJI_SU = '1'||m1Row.zOAZA_NM_KANJI_MOJI_SU
                        AND '1'||m1Row.AZA_NM_KANJI_MOJI_SU = '1'||m1Row.zAZA_NM_KANJI_MOJI_SU
                        AND '1'||m1Row.KEN_NM_KANA_MOJI_SU = '1'||m1Row.zKEN_NM_KANA_MOJI_SU
                        AND '1'||m1Row.SHIKU_NM_KANA_MOJI_SU = '1'||m1Row.zSHIKU_NM_KANA_MOJI_SU
                        AND '1'||m1Row.OAZA_NM_KANA_MOJI_SU = '1'||m1Row.zOAZA_NM_KANA_MOJI_SU
                        AND '1'||m1Row.AZA_NM_KANA_MOJI_SU = '1'||m1Row.zAZA_NM_KANA_MOJI_SU
                        AND '1'||m1Row.TEL_NASHI_FLG = '1'||m1Row.zTEL_NASHI_FLG
                        AND '1'||m1Row.TEL = '1'||m1Row.zTEL
                        AND '1'||m1Row.KEIEITAI_CD = '1'||m1Row.zKEIEITAI_CD
                        AND '1'||m1Row.SHI_KBN_CD = '1'||m1Row.zSHI_KBN_CD
                        AND '1'||m1Row.DAIHYO_REC_ID = '1'||m1Row.zDAIHYO_REC_ID
                        AND '1'||m1Row.DAIHYO_KJN_CD = '1'||m1Row.zDAIHYO_KJN_CD
                        AND '1'||m1Row.KJN_NM = '1'||m1Row.zKJN_NM
                        AND '1'||m1Row.KJN_NM_KANA = '1'||m1Row.zKJN_NM_KANA
                        AND '1'||m1Row.KAIGYO_YOTEI_FLG = '1'||m1Row.zKAIGYO_YOTEI_FLG
                        AND '1'||m1Row.KAIGYO_YOTEI_YM = '1'||m1Row.zKAIGYO_YOTEI_YM
                        AND '1'||m1Row.KYUIN_FLG = '1'||m1Row.zKYUIN_FLG
                        AND '1'||m1Row.KYUIN_S_YM = '1'||m1Row.zKYUIN_S_YM
                        AND '1'||m1Row.SNRYKMK_CD_01 = '1'||m1Row.zSNRYKMK_CD_01
                        AND '1'||m1Row.SNRYKMK_CD_02 = '1'||m1Row.zSNRYKMK_CD_02
                        AND '1'||m1Row.SNRYKMK_CD_03 = '1'||m1Row.zSNRYKMK_CD_03
                        AND '1'||m1Row.SNRYKMK_CD_04 = '1'||m1Row.zSNRYKMK_CD_04
                        AND '1'||m1Row.SNRYKMK_CD_05 = '1'||m1Row.zSNRYKMK_CD_05
                        AND '1'||m1Row.SNRYKMK_CD_06 = '1'||m1Row.zSNRYKMK_CD_06
                        AND '1'||m1Row.SNRYKMK_CD_07 = '1'||m1Row.zSNRYKMK_CD_07
                        AND '1'||m1Row.SNRYKMK_CD_08 = '1'||m1Row.zSNRYKMK_CD_08
                        AND '1'||m1Row.SNRYKMK_CD_09 = '1'||m1Row.zSNRYKMK_CD_09
                        AND '1'||m1Row.SNRYKMK_CD_10 = '1'||m1Row.zSNRYKMK_CD_10
                        AND '1'||m1Row.SNRYKMK_CD_11 = '1'||m1Row.zSNRYKMK_CD_11
                        AND '1'||m1Row.SNRYKMK_CD_12 = '1'||m1Row.zSNRYKMK_CD_12
                        AND '1'||m1Row.SNRYKMK_CD_13 = '1'||m1Row.zSNRYKMK_CD_13
                        AND '1'||m1Row.SNRYKMK_CD_14 = '1'||m1Row.zSNRYKMK_CD_14
                        AND '1'||m1Row.SNRYKMK_CD_15 = '1'||m1Row.zSNRYKMK_CD_15
                        AND '1'||m1Row.SNRYKMK_CD_16 = '1'||m1Row.zSNRYKMK_CD_16
                        AND '1'||m1Row.SNRYKMK_CD_17 = '1'||m1Row.zSNRYKMK_CD_17
                        AND '1'||m1Row.SNRYKMK_CD_18 = '1'||m1Row.zSNRYKMK_CD_18
                        AND '1'||m1Row.SNRYKMK_CD_19 = '1'||m1Row.zSNRYKMK_CD_19
                        AND '1'||m1Row.SNRYKMK_CD_20 = '1'||m1Row.zSNRYKMK_CD_20
                        AND '1'||m1Row.SNRYKMK_CD_21 = '1'||m1Row.zSNRYKMK_CD_21
                        AND '1'||m1Row.SNRYKMK_CD_22 = '1'||m1Row.zSNRYKMK_CD_22
                        AND '1'||m1Row.SNRYKMK_CD_23 = '1'||m1Row.zSNRYKMK_CD_23
                        AND '1'||m1Row.SNRYKMK_CD_24 = '1'||m1Row.zSNRYKMK_CD_24
                        AND '1'||m1Row.SNRYKMK_CD_25 = '1'||m1Row.zSNRYKMK_CD_25
                        AND '1'||m1Row.SNRYKMK_CD_26 = '1'||m1Row.zSNRYKMK_CD_26
                        AND '1'||m1Row.SNRYKMK_CD_27 = '1'||m1Row.zSNRYKMK_CD_27
                        AND '1'||m1Row.SNRYKMK_CD_28 = '1'||m1Row.zSNRYKMK_CD_28
                        AND '1'||m1Row.SNRYKMK_CD_29 = '1'||m1Row.zSNRYKMK_CD_29
                        AND '1'||m1Row.SNRYKMK_CD_30 = '1'||m1Row.zSNRYKMK_CD_30
                        AND '1'||m1Row.SNRYKMK_CD_31 = '1'||m1Row.zSNRYKMK_CD_31
                        AND '1'||m1Row.SNRYKMK_CD_32 = '1'||m1Row.zSNRYKMK_CD_32
                        AND '1'||m1Row.SNRYKMK_CD_33 = '1'||m1Row.zSNRYKMK_CD_33
                        AND '1'||m1Row.SNRYKMK_CD_34 = '1'||m1Row.zSNRYKMK_CD_34
                        AND '1'||m1Row.SNRYKMK_CD_35 = '1'||m1Row.zSNRYKMK_CD_35
                        AND '1'||m1Row.SNRYKMK_CD_36 = '1'||m1Row.zSNRYKMK_CD_36
                        AND '1'||m1Row.SNRYKMK_CD_37 = '1'||m1Row.zSNRYKMK_CD_37
                        AND '1'||m1Row.SNRYKMK_CD_38 = '1'||m1Row.zSNRYKMK_CD_38
                        AND '1'||m1Row.SNRYKMK_CD_39 = '1'||m1Row.zSNRYKMK_CD_39
                        AND '1'||m1Row.SNRYKMK_CD_40 = '1'||m1Row.zSNRYKMK_CD_40
                        AND '1'||m1Row.SNRYKMK_CD_41 = '1'||m1Row.zSNRYKMK_CD_41
                        AND '1'||m1Row.SNRYKMK_CD_42 = '1'||m1Row.zSNRYKMK_CD_42
                        AND '1'||m1Row.SNRYKMK_CD_43 = '1'||m1Row.zSNRYKMK_CD_43
                        AND '1'||m1Row.SNRYKMK_CD_44 = '1'||m1Row.zSNRYKMK_CD_44
                        AND '1'||m1Row.SNRYKMK_CD_45 = '1'||m1Row.zSNRYKMK_CD_45
                        AND '1'||m1Row.SNRYKMK_CD_46 = '1'||m1Row.zSNRYKMK_CD_46
                        AND '1'||m1Row.SNRYKMK_CD_47 = '1'||m1Row.zSNRYKMK_CD_47
                        AND '1'||m1Row.SNRYKMK_CD_48 = '1'||m1Row.zSNRYKMK_CD_48
                        AND '1'||m1Row.SNRYKMK_CD_49 = '1'||m1Row.zSNRYKMK_CD_49
                        AND '1'||m1Row.SNRYKMK_CD_50 = '1'||m1Row.zSNRYKMK_CD_50
                        AND '1'||m1Row.SNRYKMK_CD_51 = '1'||m1Row.zSNRYKMK_CD_51
                        AND '1'||m1Row.SNRYKMK_CD_52 = '1'||m1Row.zSNRYKMK_CD_52
                        AND '1'||m1Row.SNRYKMK_CD_53 = '1'||m1Row.zSNRYKMK_CD_53
                        AND '1'||m1Row.SNRYKMK_CD_54 = '1'||m1Row.zSNRYKMK_CD_54
                        AND '1'||m1Row.SNRYKMK_CD_55 = '1'||m1Row.zSNRYKMK_CD_55
                        AND '1'||m1Row.SNRYKMK_CD_56 = '1'||m1Row.zSNRYKMK_CD_56
                        AND '1'||m1Row.SNRYKMK_CD_57 = '1'||m1Row.zSNRYKMK_CD_57
                        AND '1'||m1Row.SNRYKMK_CD_58 = '1'||m1Row.zSNRYKMK_CD_58
                        AND '1'||m1Row.SNRYKMK_CD_59 = '1'||m1Row.zSNRYKMK_CD_59
                        AND '1'||m1Row.SNRYKMK_CD_60 = '1'||m1Row.zSNRYKMK_CD_60
                        AND '1'||m1Row.BYOIN_SBT_CD = '1'||m1Row.zBYOIN_SBT_CD
                        AND '1'||m1Row.SAISHINSA_KBN_CD = '1'||m1Row.zSAISHINSA_KBN_CD
                        AND '1'||m1Row.KANREN_DAIGAKU_OYA_REC_ID = '1'||m1Row.zKANREN_DAIGAKU_OYA_REC_ID
                        AND '1'||m1Row.KANREN_DAIGAKU_OYA_SHI_CD = '1'||m1Row.zKANREN_DAIGAKU_OYA_SHI_CD
                        AND '1'||m1Row.BYOTO_HEISA_KBN = '1'||m1Row.zBYOTO_HEISA_KBN
                        AND '1'||m1Row.SHI_BED_SU = '1'||m1Row.zSHI_BED_SU
                        AND '1'||m1Row.BED_SU_KKNN_EIGY_YMD = '1'||m1Row.zBED_SU_KKNN_EIGY_YMD
                        AND '1'||m1Row.KYOKA_BED_SU_GOKEI = '1'||m1Row.zKYOKA_BED_SU_GOKEI
                        AND '1'||m1Row.KYOKA_BED_SU_SEISHIN = '1'||m1Row.zKYOKA_BED_SU_SEISHIN
                        AND '1'||m1Row.KYOKA_BED_SU_KEKKAKU = '1'||m1Row.zKYOKA_BED_SU_KEKKAKU
                        AND '1'||m1Row.KYOKA_BED_SU_KANSEN = '1'||m1Row.zKYOKA_BED_SU_KANSEN
                        AND '1'||m1Row.KYOKA_BED_SU_SONOTA = '1'||m1Row.zKYOKA_BED_SU_SONOTA
                        AND '1'||m1Row.KYOKA_BED_SU_IPPAN = '1'||m1Row.zKYOKA_BED_SU_IPPAN
                        AND '1'||m1Row.KYOKA_BED_SU_RYOYO = '1'||m1Row.zKYOKA_BED_SU_RYOYO
                        AND '1'||m1Row.KENSAKOMOKU_BISEIBUTSU_FLG = '1'||m1Row.zKENSAKOMOKU_BISEIBUTSU_FLG
                        AND '1'||m1Row.KENSAKOMOKU_KESSEI_FLG = '1'||m1Row.zKENSAKOMOKU_KESSEI_FLG
                        AND '1'||m1Row.KENSAKOMOKU_KETSUEKI_FLG = '1'||m1Row.zKENSAKOMOKU_KETSUEKI_FLG
                        AND '1'||m1Row.KENSAKOMOKU_BYORI_FLG = '1'||m1Row.zKENSAKOMOKU_BYORI_FLG
                        AND '1'||m1Row.KENSAKOMOKU_KISEICHU_FLG = '1'||m1Row.zKENSAKOMOKU_KISEICHU_FLG
                        AND '1'||m1Row.KENSAKOMOKU_SEIKA_FLG = '1'||m1Row.zKENSAKOMOKU_SEIKA_FLG
                        AND '1'||m1Row.KENSAKOMOKU_RI_FLG = '1'||m1Row.zKENSAKOMOKU_RI_FLG
                        AND '1'||m1Row.IMUSHITSU_REC_ID = '1'||m1Row.zIMUSHITSU_REC_ID
                        AND '1'||m1Row.IMUSHITSU_SHI_CD = '1'||m1Row.zIMUSHITSU_SHI_CD
                      THEN
                        vMODKBN := ULT_COMMON.MOD_KBN_NO;
                      ELSE  
                        vMODKBN := ULT_COMMON.MOD_KBN_YES;
                      END IF;
                  
                  END IF;
                  --���C�A�E�g�敪��"2"(�����C�A�E�g)
                  IF iLayoutKind = ULT_COMMON.LAYOUT_SBT_CD_ZANTEI THEN
                     --�񋟗p���R�[�h�Ǝ擾�����O���r���R�[�h���r  
                     IF     '1'||m1Row.SEISHIKI_SHI_NM_KANA40 = '1'||m1Row.zSEISHIKI_SHI_NM_KANA40
                        AND '1'||m1Row.SHI_RN_KANA = '1'||m1Row.zSHI_RN_KANA
                        AND '1'||m1Row.KEN_CD = '1'||m1Row.zKEN_CD
                        AND '1'||m1Row.SHIKU_CD = '1'||m1Row.zSHIKU_CD
                        AND '1'||m1Row.OAZA_CD = '1'||m1Row.zOAZA_CD
                        AND '1'||m1Row.AZA_CD = '1'||m1Row.zAZA_CD
                        AND '1'||m1Row.ZIP = '1'||m1Row.zZIP
                        AND '1'||m1Row.JUSHO_HYOJI_NO = '1'||m1Row.zJUSHO_HYOJI_NO
                        AND '1'||m1Row.JUSHO_KANA_RENKETSU = '1'||m1Row.zJUSHO_KANA_RENKETSU
                        AND '1'||m1Row.KEN_NM_KANA_MOJI_SU = '1'||m1Row.zKEN_NM_KANA_MOJI_SU
                        AND '1'||m1Row.SHIKU_NM_KANA_MOJI_SU = '1'||m1Row.zSHIKU_NM_KANA_MOJI_SU
                        AND '1'||m1Row.OAZA_NM_KANA_MOJI_SU = '1'||m1Row.zOAZA_NM_KANA_MOJI_SU
                        AND '1'||m1Row.KEN_NM_KANJI_MOJI_SU = '1'||m1Row.zKEN_NM_KANJI_MOJI_SU
                        AND '1'||m1Row.SHIKU_NM_KANJI_MOJI_SU = '1'||m1Row.zSHIKU_NM_KANJI_MOJI_SU
                        AND '1'||m1Row.OAZA_NM_KANJI_MOJI_SU = '1'||m1Row.zOAZA_NM_KANJI_MOJI_SU
                        AND '1'||m1Row.TEL = '1'||m1Row.zTEL
                        AND '1'||m1Row.SHI_BED_SU = '1'||m1Row.zSHI_BED_SU
                        AND '1'||m1Row.KEIEITAI_CD = '1'||m1Row.zKEIEITAI_CD
                        AND '1'||m1Row.SHI_KBN_CD = '1'||m1Row.zSHI_KBN_CD
                        AND '1'||m1Row.BYOIN_SBT_CD = '1'||m1Row.zBYOIN_SBT_CD
                        AND '1'||m1Row.KANREN_DAIGAKU_OYA_REC_ID = '1'||m1Row.zKANREN_DAIGAKU_OYA_REC_ID
                        AND '1'||m1Row.KANREN_DAIGAKU_OYA_SHI_CD = '1'||m1Row.zKANREN_DAIGAKU_OYA_SHI_CD
                        AND '1'||m1Row.JUSHOFUMEI_CD = '1'||m1Row.zJUSHOFUMEI_CD
                        AND '1'||m1Row.KYUIN_FLG = '1'||m1Row.zKYUIN_FLG
                        AND '1'||m1Row.DEL_YOTEI_RIYU_CD = '1'||m1Row.zDEL_YOTEI_RIYU_CD
                        AND '1'||m1Row.KAIGYO_YOTEI_FLG = '1'||m1Row.zKAIGYO_YOTEI_FLG
                        AND '1'||m1Row.BYOTO_HEISA_KBN = '1'||m1Row.zBYOTO_HEISA_KBN
                        AND '1'||m1Row.TEL_NASHI_FLG = '1'||m1Row.zTEL_NASHI_FLG
                        AND '1'||m1Row.MIKAKUNIN_FLG = '1'||m1Row.zMIKAKUNIN_FLG
                        AND '1'||m1Row.SAISHINSA_KBN_CD = '1'||m1Row.zSAISHINSA_KBN_CD
                        AND '1'||m1Row.KAIGYO_YOTEI_YM = '1'||m1Row.zKAIGYO_YOTEI_YM
                        AND '1'||m1Row.KYUIN_S_YM = '1'||m1Row.zKYUIN_S_YM
                        AND '1'||m1Row.BED_SU_KKNN_EIGY_YMD = '1'||m1Row.zBED_SU_KKNN_EIGY_YMD
                        AND '1'||m1Row.KYOKA_BED_SU_SONOTA = '1'||m1Row.zKYOKA_BED_SU_SONOTA
                        AND '1'||m1Row.KYOKA_BED_SU_SEISHIN = '1'||m1Row.zKYOKA_BED_SU_SEISHIN
                        AND '1'||m1Row.KYOKA_BED_SU_KEKKAKU = '1'||m1Row.zKYOKA_BED_SU_KEKKAKU
                        AND '1'||m1Row.KYOKA_BED_SU_KANSEN = '1'||m1Row.zKYOKA_BED_SU_KANSEN
                        AND '1'||m1Row.KYOKA_BED_SU_GOKEI = '1'||m1Row.zKYOKA_BED_SU_GOKEI
                        AND '1'||m1Row.KENSAKOMOKU_BISEIBUTSU_FLG = '1'||m1Row.zKENSAKOMOKU_BISEIBUTSU_FLG
                        AND '1'||m1Row.KENSAKOMOKU_KESSEI_FLG = '1'||m1Row.zKENSAKOMOKU_KESSEI_FLG
                        AND '1'||m1Row.KENSAKOMOKU_KETSUEKI_FLG = '1'||m1Row.zKENSAKOMOKU_KETSUEKI_FLG
                        AND '1'||m1Row.KENSAKOMOKU_BYORI_FLG = '1'||m1Row.zKENSAKOMOKU_BYORI_FLG
                        AND '1'||m1Row.KENSAKOMOKU_KISEICHU_FLG = '1'||m1Row.zKENSAKOMOKU_KISEICHU_FLG
                        AND '1'||m1Row.KENSAKOMOKU_SEIKA_FLG = '1'||m1Row.zKENSAKOMOKU_SEIKA_FLG
                        AND '1'||m1Row.KENSAKOMOKU_RI_FLG = '1'||m1Row.zKENSAKOMOKU_RI_FLG
                        AND '1'||m1Row.SNRYKMK_CD_01 = '1'||m1Row.zSNRYKMK_CD_01
                        AND '1'||m1Row.SNRYKMK_CD_02 = '1'||m1Row.zSNRYKMK_CD_02
                        AND '1'||m1Row.SNRYKMK_CD_03 = '1'||m1Row.zSNRYKMK_CD_03
                        AND '1'||m1Row.SNRYKMK_CD_04 = '1'||m1Row.zSNRYKMK_CD_04
                        AND '1'||m1Row.SNRYKMK_CD_05 = '1'||m1Row.zSNRYKMK_CD_05
                        AND '1'||m1Row.SNRYKMK_CD_06 = '1'||m1Row.zSNRYKMK_CD_06
                        AND '1'||m1Row.SNRYKMK_CD_07 = '1'||m1Row.zSNRYKMK_CD_07
                        AND '1'||m1Row.SNRYKMK_CD_08 = '1'||m1Row.zSNRYKMK_CD_08
                        AND '1'||m1Row.SNRYKMK_CD_09 = '1'||m1Row.zSNRYKMK_CD_09
                        AND '1'||m1Row.SNRYKMK_CD_10 = '1'||m1Row.zSNRYKMK_CD_10
                        AND '1'||m1Row.SNRYKMK_CD_11 = '1'||m1Row.zSNRYKMK_CD_11
                        AND '1'||m1Row.SNRYKMK_CD_12 = '1'||m1Row.zSNRYKMK_CD_12
                        AND '1'||m1Row.SNRYKMK_CD_13 = '1'||m1Row.zSNRYKMK_CD_13
                        AND '1'||m1Row.SNRYKMK_CD_14 = '1'||m1Row.zSNRYKMK_CD_14
                        AND '1'||m1Row.SNRYKMK_CD_15 = '1'||m1Row.zSNRYKMK_CD_15
                        AND '1'||m1Row.SNRYKMK_CD_16 = '1'||m1Row.zSNRYKMK_CD_16
                        AND '1'||m1Row.SNRYKMK_CD_17 = '1'||m1Row.zSNRYKMK_CD_17
                        AND '1'||m1Row.SNRYKMK_CD_18 = '1'||m1Row.zSNRYKMK_CD_18
                        AND '1'||m1Row.SNRYKMK_CD_19 = '1'||m1Row.zSNRYKMK_CD_19
                        AND '1'||m1Row.SNRYKMK_CD_20 = '1'||m1Row.zSNRYKMK_CD_20
                        AND '1'||m1Row.SNRYKMK_CD_21 = '1'||m1Row.zSNRYKMK_CD_21
                        AND '1'||m1Row.SNRYKMK_CD_22 = '1'||m1Row.zSNRYKMK_CD_22
                        AND '1'||m1Row.SNRYKMK_CD_23 = '1'||m1Row.zSNRYKMK_CD_23
                        AND '1'||m1Row.SNRYKMK_CD_24 = '1'||m1Row.zSNRYKMK_CD_24
                        AND '1'||m1Row.SNRYKMK_CD_25 = '1'||m1Row.zSNRYKMK_CD_25
                        AND '1'||m1Row.SNRYKMK_CD_26 = '1'||m1Row.zSNRYKMK_CD_26
                        AND '1'||m1Row.SNRYKMK_CD_27 = '1'||m1Row.zSNRYKMK_CD_27
                        AND '1'||m1Row.SNRYKMK_CD_28 = '1'||m1Row.zSNRYKMK_CD_28
                        AND '1'||m1Row.SNRYKMK_CD_29 = '1'||m1Row.zSNRYKMK_CD_29
                        AND '1'||m1Row.SNRYKMK_CD_30 = '1'||m1Row.zSNRYKMK_CD_30
                        AND '1'||m1Row.SNRYKMK_CD_31 = '1'||m1Row.zSNRYKMK_CD_31
                        AND '1'||m1Row.SNRYKMK_CD_32 = '1'||m1Row.zSNRYKMK_CD_32
                        AND '1'||m1Row.SNRYKMK_CD_33 = '1'||m1Row.zSNRYKMK_CD_33
                        AND '1'||m1Row.SNRYKMK_CD_34 = '1'||m1Row.zSNRYKMK_CD_34
                        AND '1'||m1Row.SNRYKMK_CD_35 = '1'||m1Row.zSNRYKMK_CD_35
                        AND '1'||m1Row.SNRYKMK_CD_36 = '1'||m1Row.zSNRYKMK_CD_36
                        AND '1'||m1Row.SNRYKMK_CD_37 = '1'||m1Row.zSNRYKMK_CD_37
                        AND '1'||m1Row.SNRYKMK_CD_38 = '1'||m1Row.zSNRYKMK_CD_38
                        AND '1'||m1Row.SNRYKMK_CD_39 = '1'||m1Row.zSNRYKMK_CD_39
                        AND '1'||m1Row.SNRYKMK_CD_40 = '1'||m1Row.zSNRYKMK_CD_40
                        AND '1'||m1Row.SEISHIKI_SHI_NM30 = '1'||m1Row.zSEISHIKI_SHI_NM30
                        AND '1'||m1Row.SHI_RN = '1'||m1Row.zSHI_RN
                        AND '1'||m1Row.JUSHO_KANJI_RENKETSU = '1'||m1Row.zJUSHO_KANJI_RENKETSU
                        AND '1'||m1Row.DAIHYO_REC_ID = '1'||m1Row.zDAIHYO_REC_ID
                        AND '1'||m1Row.DAIHYO_KJN_CD = '1'||m1Row.zDAIHYO_KJN_CD
                        AND '1'||m1Row.KJN_NM_KANA = '1'||m1Row.zKJN_NM_KANA
                        AND '1'||m1Row.KJN_NM = '1'||m1Row.zKJN_NM
                        AND '1'||m1Row.KYOKA_BED_SU_IPPAN = '1'||m1Row.zKYOKA_BED_SU_IPPAN
                        AND '1'||m1Row.KYOKA_BED_SU_RYOYO = '1'||m1Row.zKYOKA_BED_SU_RYOYO
                        AND '1'||m1Row.CHOFUKU_AITSK_REC_ID = '1'||m1Row.zCHOFUKU_AITSK_REC_ID
                        AND '1'||m1Row.CHOFUKU_AITSK_SHI_CD = '1'||m1Row.zCHOFUKU_AITSK_SHI_CD                     
                     THEN
                        vMODKBN := ULT_COMMON.MOD_KBN_NO;
                     ELSE  
                        vMODKBN := ULT_COMMON.MOD_KBN_YES;
                     END IF;
                  
                  END IF;
                END IF;  
                  
              ELSIF m1Row.zREC_ID IS NULL AND m1Row.zSHI_CD IS NULL THEN
              --�񋟗p���R�[�h�Ə�L�Ŏ擾�����O���r���R�[�h�͓������̂̃A�C�e�����r���Ă����ꂩ���s��v�� �A
                vMODKBN := ULT_COMMON.MOD_KBN_ADD;
              END IF;            
              
              IF vMODKBN != ULT_COMMON.MOD_KBN_NO THEN
                --�C���敪���h�@�h�i���p�X�y�[�X�j�ł͂Ȃ��� 
                IF iLayoutKind = ULT_COMMON.LAYOUT_SBT_CD_SHIN THEN
                  
                   IF iM2Flg = ULT_COMMON.FLG_NO THEN                     
                      --�V_��1����_DCF�{��
                      INSERT INTO TD_NM_DCF_SHI(
                          LAYOUT_KBN,
                          SHIREC_ID,
                          SHI_CD,
                          MOD_KBN,
                          MENTE_YMD,
                          MIKAKUNIN_FLG,
                          DEL_YOTEI_RIYU,
                          AITSK_CD_SHIREC_ID,
                          AITSK_CD_SHI_CD,
                          SEISHIKI_SHI_NM_KANJI,
                          SEISHIKI_SHI_NM_KANA,
                          RYKSK_SHI_NM_KANJI,
                          RYKSK_SHI_NM_KANA,
                          JUSHOFUMEI,
                          JUSHO_CD_KEN_CD,
                          JUSHO_CD_SHIKU_CD,
                          JUSHO_CD_OAZA_CD,
                          JUSHO_CD_AZA_CD,
                          ZIP,
                          JUSHO_KANJI,
                          JUSHO_KANA,
                          JUSHO_HYOJI_NO,
                          JUSHO_COUNT_KANJI_KEN,
                          JUSHO_COUNT_KANJI_SHIKU,
                          JUSHO_COUNT_KANJI_OAZA,
                          JUSHO_COUNT_KANJI_AZA,
                          JUSHO_COUNT_KANA_KEN,
                          JUSHO_COUNT_KANA_SHIKU,
                          JUSHO_COUNT_KANA_OAZA,
                          JUSHO_COUNT_KANA_AZA,
                          TEL_NASHI_FLG,
                          TEL,
                          KEIEITAI,
                          SHI_KBN,
                          DAIHYO_KJNREC_ID,
                          DAIHYO_KJN_CD,
                          DAIHYO_KANJI,
                          DAIHYO_KANA,
                          KAIGYO_YOTEI_KAIGYO_YOTEI_FLG,
                          KAIGYO_YOTEI_KAIGYO_YOTEI_YM,
                          KYUIN_KYUIN_FLG,
                          KYUIN_KYUIN_S_YM,
                          SNRYKMK_1,
                          SNRYKMK_2,
                          SNRYKMK_3,
                          SNRYKMK_4,
                          SNRYKMK_5,
                          SNRYKMK_6,
                          SNRYKMK_7,
                          SNRYKMK_8,
                          SNRYKMK_9,
                          SNRYKMK_10,
                          SNRYKMK_11,
                          SNRYKMK_12,
                          SNRYKMK_13,
                          SNRYKMK_14,
                          SNRYKMK_15,
                          SNRYKMK_16,
                          SNRYKMK_17,
                          SNRYKMK_18,
                          SNRYKMK_19,
                          SNRYKMK_20,
                          SNRYKMK_21,
                          SNRYKMK_22,
                          SNRYKMK_23,
                          SNRYKMK_24,
                          SNRYKMK_25,
                          SNRYKMK_26,
                          SNRYKMK_27,
                          SNRYKMK_28,
                          SNRYKMK_29,
                          SNRYKMK_30,
                          SNRYKMK_31,
                          SNRYKMK_32,
                          SNRYKMK_33,
                          SNRYKMK_34,
                          SNRYKMK_35,
                          SNRYKMK_36,
                          SNRYKMK_37,
                          SNRYKMK_38,
                          SNRYKMK_39,
                          SNRYKMK_40,
                          SNRYKMK_41,
                          SNRYKMK_42,
                          SNRYKMK_43,
                          SNRYKMK_44,
                          SNRYKMK_45,
                          SNRYKMK_46,
                          SNRYKMK_47,
                          SNRYKMK_48,
                          SNRYKMK_49,
                          SNRYKMK_50,
                          SNRYKMK_51,
                          SNRYKMK_52,
                          SNRYKMK_53,
                          SNRYKMK_54,
                          SNRYKMK_55,
                          SNRYKMK_56,
                          SNRYKMK_57,
                          SNRYKMK_58,
                          SNRYKMK_59,
                          SNRYKMK_60,
                          BYOIN_SBT,
                          SAISHINSA_KBN,
                          KANREN_DAIGAKU_OYA_SHIREC_ID,
                          KANREN_DAIGAKU_OYA_SHI_CD,
                          BYOTO_HEISA_FLG,
                          BED_SU_TEIIN,
                          KYOKA_BED_MENTE_HIZUKE,
                          KYOKA_BED_SU_GOKEI,
                          KYOKA_BED_SU_SEISHIN,
                          KYOKA_BED_SU_KEKKAKU,
                          KYOKA_BED_SU_KANSEN,
                          KYOKA_BED_SU_SONOTA,
                          KYOKA_BED_SU_IPPAN_BED,
                          KYOKA_BED_SU_RYOYO_BED,
                          KENSAKOMOKU_BISEIBUTSU,
                          KENSAKOMOKU_KESSEI,
                          KENSAKOMOKU_KETSUEKI,
                          KENSAKOMOKU_BYORI,
                          KENSAKOMOKU_KISEICHU,
                          KENSAKOMOKU_SEIKA,
                          KENSAKOMOKU_RI,
                          TOKUI_CD_REC_ID,
                          TOKUI_CD_SHI_CD,
                          TRK_OPE_CD,TRK_DATE,TRK_PGM_ID,UPD_OPE_CD,UPD_DATE,UPD_PGM_ID
                      ) VALUES(
                          '101',
                          m1Row.REC_ID,
                          m1Row.SHI_CD,
                          vMODKBN,
                          m1Row.UPD_EIGY_YMD,
                          m1Row.MIKAKUNIN_FLG,
                          m1Row.DEL_YOTEI_RIYU_CD,
                          m1Row.CHOFUKU_AITSK_REC_ID,
                          m1Row.CHOFUKU_AITSK_SHI_CD,
                          m1Row.SEISHIKI_SHI_NM,
                          m1Row.SEISHIKI_SHI_NM_KANA,
                          m1Row.SHI_RN,
                          m1Row.SHI_RN_KANA,
                          m1Row.JUSHOFUMEI_CD,
                          m1Row.KEN_CD,
                          m1Row.SHIKU_CD,
                          m1Row.OAZA_CD,
                          m1Row.AZA_CD,
                          NVL2(m1Row.ZIP,SUBSTR(m1Row.ZIP,1,3)||'-'||SUBSTR(m1Row.ZIP,4),NULL),
                          m1Row.JUSHO_KANJI_RENKETSU,
                          m1Row.JUSHO_KANA_RENKETSU,
                          m1Row.JUSHO_HYOJI_NO,
                          m1Row.KEN_NM_KANJI_MOJI_SU,
                          m1Row.SHIKU_NM_KANJI_MOJI_SU,
                          m1Row.OAZA_NM_KANJI_MOJI_SU,
                          m1Row.AZA_NM_KANJI_MOJI_SU,
                          m1Row.KEN_NM_KANA_MOJI_SU,
                          m1Row.SHIKU_NM_KANA_MOJI_SU,
                          m1Row.OAZA_NM_KANA_MOJI_SU,
                          m1Row.AZA_NM_KANA_MOJI_SU,
                          m1Row.TEL_NASHI_FLG,
                          m1Row.TEL,
                          m1Row.KEIEITAI_CD,
                          m1Row.SHI_KBN_CD,
                          m1Row.DAIHYO_REC_ID,
                          m1Row.DAIHYO_KJN_CD,
                          m1Row.KJN_NM,
                          m1Row.KJN_NM_KANA,
                          m1Row.KAIGYO_YOTEI_FLG,
                          m1Row.KAIGYO_YOTEI_YM,
                          m1Row.KYUIN_FLG,
                          m1Row.KYUIN_S_YM,
                          m1Row.SNRYKMK_CD_01,
                          m1Row.SNRYKMK_CD_02,
                          m1Row.SNRYKMK_CD_03,
                          m1Row.SNRYKMK_CD_04,
                          m1Row.SNRYKMK_CD_05,
                          m1Row.SNRYKMK_CD_06,
                          m1Row.SNRYKMK_CD_07,
                          m1Row.SNRYKMK_CD_08,
                          m1Row.SNRYKMK_CD_09,
                          m1Row.SNRYKMK_CD_10,
                          m1Row.SNRYKMK_CD_11,
                          m1Row.SNRYKMK_CD_12,
                          m1Row.SNRYKMK_CD_13,
                          m1Row.SNRYKMK_CD_14,
                          m1Row.SNRYKMK_CD_15,
                          m1Row.SNRYKMK_CD_16,
                          m1Row.SNRYKMK_CD_17,
                          m1Row.SNRYKMK_CD_18,
                          m1Row.SNRYKMK_CD_19,
                          m1Row.SNRYKMK_CD_20,
                          m1Row.SNRYKMK_CD_21,
                          m1Row.SNRYKMK_CD_22,
                          m1Row.SNRYKMK_CD_23,
                          m1Row.SNRYKMK_CD_24,
                          m1Row.SNRYKMK_CD_25,
                          m1Row.SNRYKMK_CD_26,
                          m1Row.SNRYKMK_CD_27,
                          m1Row.SNRYKMK_CD_28,
                          m1Row.SNRYKMK_CD_29,
                          m1Row.SNRYKMK_CD_30,
                          m1Row.SNRYKMK_CD_31,
                          m1Row.SNRYKMK_CD_32,
                          m1Row.SNRYKMK_CD_33,
                          m1Row.SNRYKMK_CD_34,
                          m1Row.SNRYKMK_CD_35,
                          m1Row.SNRYKMK_CD_36,
                          m1Row.SNRYKMK_CD_37,
                          m1Row.SNRYKMK_CD_38,
                          m1Row.SNRYKMK_CD_39,
                          m1Row.SNRYKMK_CD_40,
                          m1Row.SNRYKMK_CD_41,
                          m1Row.SNRYKMK_CD_42,
                          m1Row.SNRYKMK_CD_43,
                          m1Row.SNRYKMK_CD_44,
                          m1Row.SNRYKMK_CD_45,
                          m1Row.SNRYKMK_CD_46,
                          m1Row.SNRYKMK_CD_47,
                          m1Row.SNRYKMK_CD_48,
                          m1Row.SNRYKMK_CD_49,
                          m1Row.SNRYKMK_CD_50,
                          m1Row.SNRYKMK_CD_51,
                          m1Row.SNRYKMK_CD_52,
                          m1Row.SNRYKMK_CD_53,
                          m1Row.SNRYKMK_CD_54,
                          m1Row.SNRYKMK_CD_55,
                          m1Row.SNRYKMK_CD_56,
                          m1Row.SNRYKMK_CD_57,
                          m1Row.SNRYKMK_CD_58,
                          m1Row.SNRYKMK_CD_59,
                          m1Row.SNRYKMK_CD_60,
                          m1Row.BYOIN_SBT_CD,
                          m1Row.SAISHINSA_KBN_CD,
                          m1Row.KANREN_DAIGAKU_OYA_REC_ID,
                          m1Row.KANREN_DAIGAKU_OYA_SHI_CD,
                          m1Row.BYOTO_HEISA_KBN,
                          m1Row.SHI_BED_SU,
                          m1Row.BED_SU_KKNN_EIGY_YMD,
                          m1Row.KYOKA_BED_SU_GOKEI,
                          m1Row.KYOKA_BED_SU_SEISHIN,
                          m1Row.KYOKA_BED_SU_KEKKAKU,
                          m1Row.KYOKA_BED_SU_KANSEN,
                          m1Row.KYOKA_BED_SU_SONOTA,
                          m1Row.KYOKA_BED_SU_IPPAN,
                          m1Row.KYOKA_BED_SU_RYOYO,
                          m1Row.KENSAKOMOKU_BISEIBUTSU_FLG,
                          m1Row.KENSAKOMOKU_KESSEI_FLG,
                          m1Row.KENSAKOMOKU_KETSUEKI_FLG,
                          m1Row.KENSAKOMOKU_BYORI_FLG,
                          m1Row.KENSAKOMOKU_KISEICHU_FLG,
                          m1Row.KENSAKOMOKU_SEIKA_FLG,
                          m1Row.KENSAKOMOKU_RI_FLG,
                          m1Row.IMUSHITSU_REC_ID,
                          m1Row.IMUSHITSU_SHI_CD,
                          iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID                      
                      );
                      EXECUTE_SQL := 'INSERT INTO TD_NM_DCF_SHI(';
                   ELSE
                     --�V_��2����_DCF�{��
                     INSERT INTO TD_N2_DCF_SHI(
                          LAYOUT_KBN,
                          SHIREC_ID,
                          SHI_CD,
                          MOD_KBN,
                          MENTE_YMD,
                          MIKAKUNIN_FLG,
                          DEL_YOTEI_RIYU,
                          AITSK_CD_SHIREC_ID,
                          AITSK_CD_SHI_CD,
                          SEISHIKI_SHI_NM_KANJI,
                          SEISHIKI_SHI_NM_KANA,
                          RYKSK_SHI_NM_KANJI,
                          RYKSK_SHI_NM_KANA,
                          JUSHOFUMEI,
                          JUSHO_CD_KEN_CD,
                          JUSHO_CD_SHIKU_CD,
                          JUSHO_CD_OAZA_CD,
                          JUSHO_CD_AZA_CD,
                          ZIP,
                          JUSHO_KANJI,
                          JUSHO_KANA,
                          JUSHO_HYOJI_NO,
                          JUSHO_COUNT_KANJI_KEN,
                          JUSHO_COUNT_KANJI_SHIKU,
                          JUSHO_COUNT_KANJI_OAZA,
                          JUSHO_COUNT_KANJI_AZA,
                          JUSHO_COUNT_KANA_KEN,
                          JUSHO_COUNT_KANA_SHIKU,
                          JUSHO_COUNT_KANA_OAZA,
                          JUSHO_COUNT_KANA_AZA,
                          TEL_NASHI_FLG,
                          TEL,
                          KEIEITAI,
                          SHI_KBN,
                          DAIHYO_KJNREC_ID,
                          DAIHYO_KJN_CD,
                          DAIHYO_KANJI,
                          DAIHYO_KANA,
                          KAIGYO_YOTEI_KAIGYO_YOTEI_FLG,
                          KAIGYO_YOTEI_KAIGYO_YOTEI_YM,
                          KYUIN_KYUIN_FLG,
                          KYUIN_KYUIN_S_YM,
                          SNRYKMK_1,
                          SNRYKMK_2,
                          SNRYKMK_3,
                          SNRYKMK_4,
                          SNRYKMK_5,
                          SNRYKMK_6,
                          SNRYKMK_7,
                          SNRYKMK_8,
                          SNRYKMK_9,
                          SNRYKMK_10,
                          SNRYKMK_11,
                          SNRYKMK_12,
                          SNRYKMK_13,
                          SNRYKMK_14,
                          SNRYKMK_15,
                          SNRYKMK_16,
                          SNRYKMK_17,
                          SNRYKMK_18,
                          SNRYKMK_19,
                          SNRYKMK_20,
                          SNRYKMK_21,
                          SNRYKMK_22,
                          SNRYKMK_23,
                          SNRYKMK_24,
                          SNRYKMK_25,
                          SNRYKMK_26,
                          SNRYKMK_27,
                          SNRYKMK_28,
                          SNRYKMK_29,
                          SNRYKMK_30,
                          SNRYKMK_31,
                          SNRYKMK_32,
                          SNRYKMK_33,
                          SNRYKMK_34,
                          SNRYKMK_35,
                          SNRYKMK_36,
                          SNRYKMK_37,
                          SNRYKMK_38,
                          SNRYKMK_39,
                          SNRYKMK_40,
                          SNRYKMK_41,
                          SNRYKMK_42,
                          SNRYKMK_43,
                          SNRYKMK_44,
                          SNRYKMK_45,
                          SNRYKMK_46,
                          SNRYKMK_47,
                          SNRYKMK_48,
                          SNRYKMK_49,
                          SNRYKMK_50,
                          SNRYKMK_51,
                          SNRYKMK_52,
                          SNRYKMK_53,
                          SNRYKMK_54,
                          SNRYKMK_55,
                          SNRYKMK_56,
                          SNRYKMK_57,
                          SNRYKMK_58,
                          SNRYKMK_59,
                          SNRYKMK_60,
                          BYOIN_SBT,
                          SAISHINSA_KBN,
                          KANREN_DAIGAKU_OYA_SHIREC_ID,
                          KANREN_DAIGAKU_OYA_SHI_CD,
                          BYOTO_HEISA_FLG,
                          BED_SU_TEIIN,
                          KYOKA_BED_MENTE_HIZUKE,
                          KYOKA_BED_SU_GOKEI,
                          KYOKA_BED_SU_SEISHIN,
                          KYOKA_BED_SU_KEKKAKU,
                          KYOKA_BED_SU_KANSEN,
                          KYOKA_BED_SU_SONOTA,
                          KYOKA_BED_SU_IPPAN_BED,
                          KYOKA_BED_SU_RYOYO_BED,
                          KENSAKOMOKU_BISEIBUTSU,
                          KENSAKOMOKU_KESSEI,
                          KENSAKOMOKU_KETSUEKI,
                          KENSAKOMOKU_BYORI,
                          KENSAKOMOKU_KISEICHU,
                          KENSAKOMOKU_SEIKA,
                          KENSAKOMOKU_RI,
                          TOKUI_CD_REC_ID,
                          TOKUI_CD_SHI_CD,
                          TRK_OPE_CD,TRK_DATE,TRK_PGM_ID,UPD_OPE_CD,UPD_DATE,UPD_PGM_ID
                      ) VALUES(
                          '101',
                          m1Row.REC_ID,
                          m1Row.SHI_CD,
                          vMODKBN,
                          m1Row.UPD_EIGY_YMD,
                          m1Row.MIKAKUNIN_FLG,
                          m1Row.DEL_YOTEI_RIYU_CD,
                          m1Row.CHOFUKU_AITSK_REC_ID,
                          m1Row.CHOFUKU_AITSK_SHI_CD,
                          m1Row.SEISHIKI_SHI_NM,
                          m1Row.SEISHIKI_SHI_NM_KANA,
                          m1Row.SHI_RN,
                          m1Row.SHI_RN_KANA,
                          m1Row.JUSHOFUMEI_CD,
                          m1Row.KEN_CD,
                          m1Row.SHIKU_CD,
                          m1Row.OAZA_CD,
                          m1Row.AZA_CD,
                          NVL2(m1Row.ZIP,SUBSTR(m1Row.ZIP,1,3)||'-'||SUBSTR(m1Row.ZIP,4),NULL),
                          m1Row.JUSHO_KANJI_RENKETSU,
                          m1Row.JUSHO_KANA_RENKETSU,
                          m1Row.JUSHO_HYOJI_NO,
                          m1Row.KEN_NM_KANJI_MOJI_SU,
                          m1Row.SHIKU_NM_KANJI_MOJI_SU,
                          m1Row.OAZA_NM_KANJI_MOJI_SU,
                          m1Row.AZA_NM_KANJI_MOJI_SU,
                          m1Row.KEN_NM_KANA_MOJI_SU,
                          m1Row.SHIKU_NM_KANA_MOJI_SU,
                          m1Row.OAZA_NM_KANA_MOJI_SU,
                          m1Row.AZA_NM_KANA_MOJI_SU,
                          m1Row.TEL_NASHI_FLG,
                          m1Row.TEL,
                          m1Row.KEIEITAI_CD,
                          m1Row.SHI_KBN_CD,
                          m1Row.DAIHYO_REC_ID,
                          m1Row.DAIHYO_KJN_CD,
                          m1Row.KJN_NM,
                          m1Row.KJN_NM_KANA,
                          m1Row.KAIGYO_YOTEI_FLG,
                          m1Row.KAIGYO_YOTEI_YM,
                          m1Row.KYUIN_FLG,
                          m1Row.KYUIN_S_YM,
                          m1Row.SNRYKMK_CD_01,
                          m1Row.SNRYKMK_CD_02,
                          m1Row.SNRYKMK_CD_03,
                          m1Row.SNRYKMK_CD_04,
                          m1Row.SNRYKMK_CD_05,
                          m1Row.SNRYKMK_CD_06,
                          m1Row.SNRYKMK_CD_07,
                          m1Row.SNRYKMK_CD_08,
                          m1Row.SNRYKMK_CD_09,
                          m1Row.SNRYKMK_CD_10,
                          m1Row.SNRYKMK_CD_11,
                          m1Row.SNRYKMK_CD_12,
                          m1Row.SNRYKMK_CD_13,
                          m1Row.SNRYKMK_CD_14,
                          m1Row.SNRYKMK_CD_15,
                          m1Row.SNRYKMK_CD_16,
                          m1Row.SNRYKMK_CD_17,
                          m1Row.SNRYKMK_CD_18,
                          m1Row.SNRYKMK_CD_19,
                          m1Row.SNRYKMK_CD_20,
                          m1Row.SNRYKMK_CD_21,
                          m1Row.SNRYKMK_CD_22,
                          m1Row.SNRYKMK_CD_23,
                          m1Row.SNRYKMK_CD_24,
                          m1Row.SNRYKMK_CD_25,
                          m1Row.SNRYKMK_CD_26,
                          m1Row.SNRYKMK_CD_27,
                          m1Row.SNRYKMK_CD_28,
                          m1Row.SNRYKMK_CD_29,
                          m1Row.SNRYKMK_CD_30,
                          m1Row.SNRYKMK_CD_31,
                          m1Row.SNRYKMK_CD_32,
                          m1Row.SNRYKMK_CD_33,
                          m1Row.SNRYKMK_CD_34,
                          m1Row.SNRYKMK_CD_35,
                          m1Row.SNRYKMK_CD_36,
                          m1Row.SNRYKMK_CD_37,
                          m1Row.SNRYKMK_CD_38,
                          m1Row.SNRYKMK_CD_39,
                          m1Row.SNRYKMK_CD_40,
                          m1Row.SNRYKMK_CD_41,
                          m1Row.SNRYKMK_CD_42,
                          m1Row.SNRYKMK_CD_43,
                          m1Row.SNRYKMK_CD_44,
                          m1Row.SNRYKMK_CD_45,
                          m1Row.SNRYKMK_CD_46,
                          m1Row.SNRYKMK_CD_47,
                          m1Row.SNRYKMK_CD_48,
                          m1Row.SNRYKMK_CD_49,
                          m1Row.SNRYKMK_CD_50,
                          m1Row.SNRYKMK_CD_51,
                          m1Row.SNRYKMK_CD_52,
                          m1Row.SNRYKMK_CD_53,
                          m1Row.SNRYKMK_CD_54,
                          m1Row.SNRYKMK_CD_55,
                          m1Row.SNRYKMK_CD_56,
                          m1Row.SNRYKMK_CD_57,
                          m1Row.SNRYKMK_CD_58,
                          m1Row.SNRYKMK_CD_59,
                          m1Row.SNRYKMK_CD_60,
                          m1Row.BYOIN_SBT_CD,
                          m1Row.SAISHINSA_KBN_CD,
                          m1Row.KANREN_DAIGAKU_OYA_REC_ID,
                          m1Row.KANREN_DAIGAKU_OYA_SHI_CD,
                          m1Row.BYOTO_HEISA_KBN,
                          m1Row.SHI_BED_SU,
                          m1Row.BED_SU_KKNN_EIGY_YMD,
                          m1Row.KYOKA_BED_SU_GOKEI,
                          m1Row.KYOKA_BED_SU_SEISHIN,
                          m1Row.KYOKA_BED_SU_KEKKAKU,
                          m1Row.KYOKA_BED_SU_KANSEN,
                          m1Row.KYOKA_BED_SU_SONOTA,
                          m1Row.KYOKA_BED_SU_IPPAN,
                          m1Row.KYOKA_BED_SU_RYOYO,
                          m1Row.KENSAKOMOKU_BISEIBUTSU_FLG,
                          m1Row.KENSAKOMOKU_KESSEI_FLG,
                          m1Row.KENSAKOMOKU_KETSUEKI_FLG,
                          m1Row.KENSAKOMOKU_BYORI_FLG,
                          m1Row.KENSAKOMOKU_KISEICHU_FLG,
                          m1Row.KENSAKOMOKU_SEIKA_FLG,
                          m1Row.KENSAKOMOKU_RI_FLG,
                          m1Row.IMUSHITSU_REC_ID,
                          m1Row.IMUSHITSU_SHI_CD,
                          iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID                      
                      );
                     EXECUTE_SQL := 'INSERT INTO TD_N2_DCF_SHI(';
                   END IF;
                   EXECUTE_SQL := EXECUTE_SQL||'
                          LAYOUT_KBN,
                          SHIREC_ID,
                          SHI_CD,
                          MOD_KBN,
                          MENTE_YMD,
                          MIKAKUNIN_FLG,
                          DEL_YOTEI_RIYU,
                          AITSK_CD_SHIREC_ID,
                          AITSK_CD_SHI_CD,
                          SEISHIKI_SHI_NM_KANJI,
                          SEISHIKI_SHI_NM_KANA,
                          RYKSK_SHI_NM_KANJI,
                          RYKSK_SHI_NM_KANA,
                          JUSHOFUMEI,
                          JUSHO_CD_KEN_CD,
                          JUSHO_CD_SHIKU_CD,
                          JUSHO_CD_OAZA_CD,
                          JUSHO_CD_AZA_CD,
                          ZIP,
                          JUSHO_KANJI,
                          JUSHO_KANA,
                          JUSHO_HYOJI_NO,
                          JUSHO_COUNT_KANJI_KEN,
                          JUSHO_COUNT_KANJI_SHIKU,
                          JUSHO_COUNT_KANJI_OAZA,
                          JUSHO_COUNT_KANJI_AZA,
                          JUSHO_COUNT_KANA_KEN,
                          JUSHO_COUNT_KANA_SHIKU,
                          JUSHO_COUNT_KANA_OAZA,
                          JUSHO_COUNT_KANA_AZA,
                          TEL_NASHI_FLG,
                          TEL,
                          KEIEITAI,
                          SHI_KBN,
                          DAIHYO_KJNREC_ID,
                          DAIHYO_KJN_CD,
                          DAIHYO_KANJI,
                          DAIHYO_KANA,
                          KAIGYO_YOTEI_KAIGYO_YOTEI_FLG,
                          KAIGYO_YOTEI_KAIGYO_YOTEI_YM,
                          KYUIN_KYUIN_FLG,
                          KYUIN_KYUIN_S_YM,
                          SNRYKMK_1,
                          SNRYKMK_2,
                          SNRYKMK_3,
                          SNRYKMK_4,
                          SNRYKMK_5,
                          SNRYKMK_6,
                          SNRYKMK_7,
                          SNRYKMK_8,
                          SNRYKMK_9,
                          SNRYKMK_10,
                          SNRYKMK_11,
                          SNRYKMK_12,
                          SNRYKMK_13,
                          SNRYKMK_14,
                          SNRYKMK_15,
                          SNRYKMK_16,
                          SNRYKMK_17,
                          SNRYKMK_18,
                          SNRYKMK_19,
                          SNRYKMK_20,
                          SNRYKMK_21,
                          SNRYKMK_22,
                          SNRYKMK_23,
                          SNRYKMK_24,
                          SNRYKMK_25,
                          SNRYKMK_26,
                          SNRYKMK_27,
                          SNRYKMK_28,
                          SNRYKMK_29,
                          SNRYKMK_30,
                          SNRYKMK_31,
                          SNRYKMK_32,
                          SNRYKMK_33,
                          SNRYKMK_34,
                          SNRYKMK_35,
                          SNRYKMK_36,
                          SNRYKMK_37,
                          SNRYKMK_38,
                          SNRYKMK_39,
                          SNRYKMK_40,
                          SNRYKMK_41,
                          SNRYKMK_42,
                          SNRYKMK_43,
                          SNRYKMK_44,
                          SNRYKMK_45,
                          SNRYKMK_46,
                          SNRYKMK_47,
                          SNRYKMK_48,
                          SNRYKMK_49,
                          SNRYKMK_50,
                          SNRYKMK_51,
                          SNRYKMK_52,
                          SNRYKMK_53,
                          SNRYKMK_54,
                          SNRYKMK_55,
                          SNRYKMK_56,
                          SNRYKMK_57,
                          SNRYKMK_58,
                          SNRYKMK_59,
                          SNRYKMK_60,
                          BYOIN_SBT,
                          SAISHINSA_KBN,
                          KANREN_DAIGAKU_OYA_SHIREC_ID,
                          KANREN_DAIGAKU_OYA_SHI_CD,
                          BYOTO_HEISA_FLG,
                          BED_SU_TEIIN,
                          KYOKA_BED_MENTE_HIZUKE,
                          KYOKA_BED_SU_GOKEI,
                          KYOKA_BED_SU_SEISHIN,
                          KYOKA_BED_SU_KEKKAKU,
                          KYOKA_BED_SU_KANSEN,
                          KYOKA_BED_SU_SONOTA,
                          KYOKA_BED_SU_IPPAN_BED,
                          KYOKA_BED_SU_RYOYO_BED,
                          KENSAKOMOKU_BISEIBUTSU,
                          KENSAKOMOKU_KESSEI,
                          KENSAKOMOKU_KETSUEKI,
                          KENSAKOMOKU_BYORI,
                          KENSAKOMOKU_KISEICHU,
                          KENSAKOMOKU_SEIKA,
                          KENSAKOMOKU_RI,
                          TOKUI_CD_REC_ID,
                          TOKUI_CD_SHI_CD,
                          TRK_OPE_CD,TRK_DATE,TRK_PGM_ID,UPD_OPE_CD,UPD_DATE,UPD_PGM_ID
                      ) VALUES(
                        ''101'',
                        '''||m1Row.REC_ID||''',
                        '''||m1Row.SHI_CD||''',
                        '''||vMODKBN||''',
                        '''||m1Row.UPD_EIGY_YMD||''',
                        '''||m1Row.MIKAKUNIN_FLG||''',
                        '''||m1Row.DEL_YOTEI_RIYU_CD||''',
                        '''||m1Row.CHOFUKU_AITSK_REC_ID||''',
                        '''||m1Row.CHOFUKU_AITSK_SHI_CD||''',
                        '''||m1Row.SEISHIKI_SHI_NM||''',
                        '''||m1Row.SEISHIKI_SHI_NM_KANA||''',
                        '''||m1Row.SHI_RN||''',
                        '''||m1Row.SHI_RN_KANA||''',
                        '''||m1Row.JUSHOFUMEI_CD||''',
                        '''||m1Row.KEN_CD||''',
                        '''||m1Row.SHIKU_CD||''',
                        '''||m1Row.OAZA_CD||''',
                        '''||m1Row.AZA_CD||''',
                        '''||CASE WHEN m1Row.ZIP IS NOT NULL THEN SUBSTR(m1Row.ZIP,1,3)||'-'||SUBSTR(m1Row.ZIP,4) ELSE NULL END ||''',
                        '''||m1Row.JUSHO_KANJI_RENKETSU||''',
                        '''||m1Row.JUSHO_KANA_RENKETSU||''',
                        '''||m1Row.JUSHO_HYOJI_NO||''',
                        '''||m1Row.KEN_NM_KANJI_MOJI_SU||''',
                        '''||m1Row.SHIKU_NM_KANJI_MOJI_SU||''',
                        '''||m1Row.OAZA_NM_KANJI_MOJI_SU||''',
                        '''||m1Row.AZA_NM_KANJI_MOJI_SU||''',
                        '''||m1Row.KEN_NM_KANA_MOJI_SU||''',
                        '''||m1Row.SHIKU_NM_KANA_MOJI_SU||''',
                        '''||m1Row.OAZA_NM_KANA_MOJI_SU||''',
                        '''||m1Row.AZA_NM_KANA_MOJI_SU||''',
                        '''||m1Row.TEL_NASHI_FLG||''',
                        '''||m1Row.TEL||''',
                        '''||m1Row.KEIEITAI_CD||''',
                        '''||m1Row.SHI_KBN_CD||''',
                        '''||m1Row.DAIHYO_REC_ID||''',
                        '''||m1Row.DAIHYO_KJN_CD||''',
                        '''||m1Row.KJN_NM||''',
                        '''||m1Row.KJN_NM_KANA||''',
                        '''||m1Row.KAIGYO_YOTEI_FLG||''',
                        '''||m1Row.KAIGYO_YOTEI_YM||''',
                        '''||m1Row.KYUIN_FLG||''',
                        '''||m1Row.KYUIN_S_YM||''',
                        '''||m1Row.SNRYKMK_CD_01||''',
                        '''||m1Row.SNRYKMK_CD_02||''',
                        '''||m1Row.SNRYKMK_CD_03||''',
                        '''||m1Row.SNRYKMK_CD_04||''',
                        '''||m1Row.SNRYKMK_CD_05||''',
                        '''||m1Row.SNRYKMK_CD_06||''',
                        '''||m1Row.SNRYKMK_CD_07||''',
                        '''||m1Row.SNRYKMK_CD_08||''',
                        '''||m1Row.SNRYKMK_CD_09||''',
                        '''||m1Row.SNRYKMK_CD_10||''',
                        '''||m1Row.SNRYKMK_CD_11||''',
                        '''||m1Row.SNRYKMK_CD_12||''',
                        '''||m1Row.SNRYKMK_CD_13||''',
                        '''||m1Row.SNRYKMK_CD_14||''',
                        '''||m1Row.SNRYKMK_CD_15||''',
                        '''||m1Row.SNRYKMK_CD_16||''',
                        '''||m1Row.SNRYKMK_CD_17||''',
                        '''||m1Row.SNRYKMK_CD_18||''',
                        '''||m1Row.SNRYKMK_CD_19||''',
                        '''||m1Row.SNRYKMK_CD_20||''',
                        '''||m1Row.SNRYKMK_CD_21||''',
                        '''||m1Row.SNRYKMK_CD_22||''',
                        '''||m1Row.SNRYKMK_CD_23||''',
                        '''||m1Row.SNRYKMK_CD_24||''',
                        '''||m1Row.SNRYKMK_CD_25||''',
                        '''||m1Row.SNRYKMK_CD_26||''',
                        '''||m1Row.SNRYKMK_CD_27||''',
                        '''||m1Row.SNRYKMK_CD_28||''',
                        '''||m1Row.SNRYKMK_CD_29||''',
                        '''||m1Row.SNRYKMK_CD_30||''',
                        '''||m1Row.SNRYKMK_CD_31||''',
                        '''||m1Row.SNRYKMK_CD_32||''',
                        '''||m1Row.SNRYKMK_CD_33||''',
                        '''||m1Row.SNRYKMK_CD_34||''',
                        '''||m1Row.SNRYKMK_CD_35||''',
                        '''||m1Row.SNRYKMK_CD_36||''',
                        '''||m1Row.SNRYKMK_CD_37||''',
                        '''||m1Row.SNRYKMK_CD_38||''',
                        '''||m1Row.SNRYKMK_CD_39||''',
                        '''||m1Row.SNRYKMK_CD_40||''',
                        '''||m1Row.SNRYKMK_CD_41||''',
                        '''||m1Row.SNRYKMK_CD_42||''',
                        '''||m1Row.SNRYKMK_CD_43||''',
                        '''||m1Row.SNRYKMK_CD_44||''',
                        '''||m1Row.SNRYKMK_CD_45||''',
                        '''||m1Row.SNRYKMK_CD_46||''',
                        '''||m1Row.SNRYKMK_CD_47||''',
                        '''||m1Row.SNRYKMK_CD_48||''',
                        '''||m1Row.SNRYKMK_CD_49||''',
                        '''||m1Row.SNRYKMK_CD_50||''',
                        '''||m1Row.SNRYKMK_CD_51||''',
                        '''||m1Row.SNRYKMK_CD_52||''',
                        '''||m1Row.SNRYKMK_CD_53||''',
                        '''||m1Row.SNRYKMK_CD_54||''',
                        '''||m1Row.SNRYKMK_CD_55||''',
                        '''||m1Row.SNRYKMK_CD_56||''',
                        '''||m1Row.SNRYKMK_CD_57||''',
                        '''||m1Row.SNRYKMK_CD_58||''',
                        '''||m1Row.SNRYKMK_CD_59||''',
                        '''||m1Row.SNRYKMK_CD_60||''',
                        '''||m1Row.BYOIN_SBT_CD||''',
                        '''||m1Row.SAISHINSA_KBN_CD||''',
                        '''||m1Row.KANREN_DAIGAKU_OYA_REC_ID||''',
                        '''||m1Row.KANREN_DAIGAKU_OYA_SHI_CD||''',
                        '''||m1Row.BYOTO_HEISA_KBN||''',
                        '''||m1Row.SHI_BED_SU||''',
                        '''||m1Row.BED_SU_KKNN_EIGY_YMD||''',
                        '''||m1Row.KYOKA_BED_SU_GOKEI||''',
                        '''||m1Row.KYOKA_BED_SU_SEISHIN||''',
                        '''||m1Row.KYOKA_BED_SU_KEKKAKU||''',
                        '''||m1Row.KYOKA_BED_SU_KANSEN||''',
                        '''||m1Row.KYOKA_BED_SU_SONOTA||''',
                        '''||m1Row.KYOKA_BED_SU_IPPAN||''',
                        '''||m1Row.KYOKA_BED_SU_RYOYO||''',
                        '''||m1Row.KENSAKOMOKU_BISEIBUTSU_FLG||''',
                        '''||m1Row.KENSAKOMOKU_KESSEI_FLG||''',
                        '''||m1Row.KENSAKOMOKU_KETSUEKI_FLG||''',
                        '''||m1Row.KENSAKOMOKU_BYORI_FLG||''',
                        '''||m1Row.KENSAKOMOKU_KISEICHU_FLG||''',
                        '''||m1Row.KENSAKOMOKU_SEIKA_FLG||''',
                        '''||m1Row.KENSAKOMOKU_RI_FLG||''',
                        '''||m1Row.IMUSHITSU_REC_ID||''',
                        '''||m1Row.IMUSHITSU_SHI_CD||''',                                       
                        '''||iOPE_CD||''',
                        '''||iDATE||''',
                        '''||iPGM_ID||''',
                        '''||iOPE_CD||''',
                        '''||iDATE||''',
                        '''||iPGM_ID||''')';
                   
                ELSIF iLayoutKind = ULT_COMMON.LAYOUT_SBT_CD_ZANTEI THEN
                   IF iM2Flg = ULT_COMMON.FLG_NO THEN                     
                      --�b��_��1����_DCF�{��
                      INSERT INTO TD_PM_DCF_SHI(
                          SHIREC_ID,
                          SHI_CD,
                          SEISHIKI_SHI_NM_KANA,
                          RYKSK_SHI_NM_KANA,
                          JUSHO_CD_KEN_CD,
                          JUSHO_CD_SHIKU_CD,
                          JUSHO_CD_OAZA_CD,
                          JUSHO_CD_AZA_CD,
                          ZIP,
                          JUSHO_HYOJI_NO,
                          JUSHO_KANA,
                          JUSHO_COUNT_KANA_KEN,
                          JUSHO_COUNT_KANA_SHIKU,
                          JUSHO_COUNT_KANA_OAZA,
                          JUSHO_COUNT_KANJI_KEN,
                          JUSHO_COUNT_KANJI_SHIKU,
                          JUSHO_COUNT_KANJI_OAZA,
                          SHI_TEL,
                          BED_SU_TEIIN,
                          KEIEITAI,
                          SHI_KBN,
                          BYOIN_SBT,
                          KANREN_DAIGAKU_OYA_SHIREC_ID,
                          KANREN_DAIGAKU_OYA_SHI_CD,
                          STATUS_JUSHOFUMEI,
                          STATUS_KYUIN_FLG,
                          STATUS_DEL_YOTEI_RIYU,
                          STATUS_KAIGYO_YOTEI_FLG,
                          STATUS_BYOTO_HEISA_FLG,
                          STATUS_TEL_NASHI_FLG,
                          STATUS_MIKAKUNIN_FLG,
                          STATUS_SAISHINSA_KBN,
                          KYUIN_S_KAIGYO_YOTEI_Y,
                          KYUIN_S_KAIGYO_YOTEI_M,
                          KYOKA_BED_MENTE_HIZUKE_Y,
                          KYOKA_BED_MENTE_HIZUKE_M,
                          KYOKA_BED_MENTE_HIZUKE_D,
                          KYOKA_BED_SU_SONOTA,
                          KYOKA_BED_SU_SEISHIN,
                          KYOKA_BED_SU_KEKKAKU,
                          KYOKA_BED_SU_KANSEN,
                          KYOKA_BED_SU_GOKEI,
                          KENSAKOMOKU_BISEIBUTSU,
                          KENSAKOMOKU_KESSEI,
                          KENSAKOMOKU_KETSUEKI,
                          KENSAKOMOKU_BYORI,
                          KENSAKOMOKU_KISEICHU,
                          KENSAKOMOKU_SEIKA,
                          KENSAKOMOKU_RI,
                          SNRYKMK_1,
                          SNRYKMK_2,
                          SNRYKMK_3,
                          SNRYKMK_4,
                          SNRYKMK_5,
                          SNRYKMK_6,
                          SNRYKMK_7,
                          SNRYKMK_8,
                          SNRYKMK_9,
                          SNRYKMK_10,
                          SNRYKMK_11,
                          SNRYKMK_12,
                          SNRYKMK_13,
                          SNRYKMK_14,
                          SNRYKMK_15,
                          SNRYKMK_16,
                          SNRYKMK_17,
                          SNRYKMK_18,
                          SNRYKMK_19,
                          SNRYKMK_20,
                          SNRYKMK_21,
                          SNRYKMK_22,
                          SNRYKMK_23,
                          SNRYKMK_24,
                          SNRYKMK_25,
                          SNRYKMK_26,
                          SNRYKMK_27,
                          SNRYKMK_28,
                          SNRYKMK_29,
                          SNRYKMK_30,
                          SNRYKMK_31,
                          SNRYKMK_32,
                          SNRYKMK_33,
                          SNRYKMK_34,
                          SNRYKMK_35,
                          SNRYKMK_36,
                          SNRYKMK_37,
                          SNRYKMK_38,
                          SNRYKMK_39,
                          SNRYKMK_40,
                          SEISHIKI_SHI_NM_KANJI,
                          RYKSK_SHI_NM_KANJI,
                          JUSHO_KANJI,
                          SHI_DAIHYO_KJNREC_ID,
                          SHI_DAIHYO_KJN_CD,
                          SHI_DAIHYO_KANA,
                          SHI_DAIHYO_KANJI,
                          SHIN_BED_KBN_IPPAN_BED,
                          SHIN_BED_KBN_RYOYO_BED,
                          AITSK_CD_SHIREC_ID,
                          AITSK_CD_SHI_CD,
                          MOD_SHORI_HIZUKE_Y,
                          MOD_SHORI_HIZUKE_M,
                          MOD_SHORI_HIZUKE_D,
                          MOD_KBN,
                          TRK_OPE_CD,TRK_DATE,TRK_PGM_ID,UPD_OPE_CD,UPD_DATE,UPD_PGM_ID
                     ) VALUES(
                          m1Row.REC_ID,
                          m1Row.SHI_CD,
                          m1Row.SEISHIKI_SHI_NM_KANA40,
                          m1Row.SHI_RN_KANA,
                          m1Row.KEN_CD,
                          m1Row.SHIKU_CD,
                          m1Row.OAZA_CD,
                          m1Row.AZA_CD,
                          NVL2(m1Row.ZIP,SUBSTR(m1Row.ZIP,1,3)||'-'||SUBSTR(m1Row.ZIP,4),NULL),
                          m1Row.JUSHO_HYOJI_NO,
                          m1Row.JUSHO_KANA_RENKETSU,
                          TO_CHAR(m1Row.KEN_NM_KANA_MOJI_SU,'FM09'),
                          TO_CHAR(m1Row.SHIKU_NM_KANA_MOJI_SU,'FM09'),
                          TO_CHAR(m1Row.OAZA_NM_KANA_MOJI_SU,'FM09'),
                          TO_CHAR(m1Row.KEN_NM_KANJI_MOJI_SU,'FM09'),
                          TO_CHAR(m1Row.SHIKU_NM_KANJI_MOJI_SU,'FM09'),
                          TO_CHAR(m1Row.OAZA_NM_KANJI_MOJI_SU,'FM09'),
                          m1Row.TEL,
                          TO_CHAR(m1Row.SHI_BED_SU,'FM0009'),
                          m1Row.KEIEITAI_CD,
                          m1Row.SHI_KBN_CD,
                          m1Row.BYOIN_SBT_CD,
                          m1Row.KANREN_DAIGAKU_OYA_REC_ID,
                          m1Row.KANREN_DAIGAKU_OYA_SHI_CD,
                          m1Row.JUSHOFUMEI_CD,
                          m1Row.KYUIN_FLG,
                          m1Row.DEL_YOTEI_RIYU_CD,
                          m1Row.KAIGYO_YOTEI_FLG,
                          m1Row.BYOTO_HEISA_KBN,
                          m1Row.TEL_NASHI_FLG,
                          m1Row.MIKAKUNIN_FLG,
                          m1Row.SAISHINSA_KBN_CD,
                          CASE
                            WHEN NVL(m1Row.KAIGYO_YOTEI_FLG,'0') = '1' THEN SUBSTR(m1Row.KAIGYO_YOTEI_YM,1,4)
                            WHEN NVL(m1Row.KYUIN_FLG,'0') = '1' THEN SUBSTR(m1Row.KYUIN_S_YM,1,4)
                            ELSE NULL
                          END,
                          CASE
                            WHEN NVL(m1Row.KAIGYO_YOTEI_FLG,'0') = '1' THEN SUBSTR(m1Row.KAIGYO_YOTEI_YM,5,2)
                            WHEN NVL(m1Row.KYUIN_FLG,'0') = '1' THEN SUBSTR(m1Row.KYUIN_S_YM,5,2)
                            ELSE NULL
                          END, 
                          SUBSTR(m1Row.BED_SU_KKNN_EIGY_YMD,1,4),                     
                          SUBSTR(m1Row.BED_SU_KKNN_EIGY_YMD,5,2),
                          SUBSTR(m1Row.BED_SU_KKNN_EIGY_YMD,7,2),
                          TO_CHAR(m1Row.KYOKA_BED_SU_SONOTA,'FM0009'),
                          TO_CHAR(m1Row.KYOKA_BED_SU_SEISHIN,'FM0009'),
                          TO_CHAR(m1Row.KYOKA_BED_SU_KEKKAKU,'FM0009'),
                          TO_CHAR(m1Row.KYOKA_BED_SU_KANSEN,'FM0009'),
                          TO_CHAR(m1Row.KYOKA_BED_SU_GOKEI,'FM0009'),
                          m1Row.KENSAKOMOKU_BISEIBUTSU_FLG,
                          m1Row.KENSAKOMOKU_KESSEI_FLG,
                          m1Row.KENSAKOMOKU_KETSUEKI_FLG,
                          m1Row.KENSAKOMOKU_BYORI_FLG,
                          m1Row.KENSAKOMOKU_KISEICHU_FLG,
                          m1Row.KENSAKOMOKU_SEIKA_FLG,
                          m1Row.KENSAKOMOKU_RI_FLG,
                          m1Row.SNRYKMK_CD_01,
                          m1Row.SNRYKMK_CD_02,
                          m1Row.SNRYKMK_CD_03,
                          m1Row.SNRYKMK_CD_04,
                          m1Row.SNRYKMK_CD_05,
                          m1Row.SNRYKMK_CD_06,
                          m1Row.SNRYKMK_CD_07,
                          m1Row.SNRYKMK_CD_08,
                          m1Row.SNRYKMK_CD_09,
                          m1Row.SNRYKMK_CD_10,
                          m1Row.SNRYKMK_CD_11,
                          m1Row.SNRYKMK_CD_12,
                          m1Row.SNRYKMK_CD_13,
                          m1Row.SNRYKMK_CD_14,
                          m1Row.SNRYKMK_CD_15,
                          m1Row.SNRYKMK_CD_16,
                          m1Row.SNRYKMK_CD_17,
                          m1Row.SNRYKMK_CD_18,
                          m1Row.SNRYKMK_CD_19,
                          m1Row.SNRYKMK_CD_20,
                          m1Row.SNRYKMK_CD_21,
                          m1Row.SNRYKMK_CD_22,
                          m1Row.SNRYKMK_CD_23,
                          m1Row.SNRYKMK_CD_24,
                          m1Row.SNRYKMK_CD_25,
                          m1Row.SNRYKMK_CD_26,
                          m1Row.SNRYKMK_CD_27,
                          m1Row.SNRYKMK_CD_28,
                          m1Row.SNRYKMK_CD_29,
                          m1Row.SNRYKMK_CD_30,
                          m1Row.SNRYKMK_CD_31,
                          m1Row.SNRYKMK_CD_32,
                          m1Row.SNRYKMK_CD_33,
                          m1Row.SNRYKMK_CD_34,
                          m1Row.SNRYKMK_CD_35,
                          m1Row.SNRYKMK_CD_36,
                          m1Row.SNRYKMK_CD_37,
                          m1Row.SNRYKMK_CD_38,
                          m1Row.SNRYKMK_CD_39,
                          m1Row.SNRYKMK_CD_40,
                          m1Row.SEISHIKI_SHI_NM30,
                          m1Row.SHI_RN,
                          m1Row.JUSHO_KANJI_RENKETSU,
                          m1Row.DAIHYO_REC_ID,
                          m1Row.DAIHYO_KJN_CD,
                          m1Row.KJN_NM_KANA,
                          m1Row.KJN_NM,
                          TO_CHAR(m1Row.KYOKA_BED_SU_IPPAN,'FM0009'),
                          TO_CHAR(m1Row.KYOKA_BED_SU_RYOYO,'FM0009'),
                          m1Row.CHOFUKU_AITSK_REC_ID,
                          m1Row.CHOFUKU_AITSK_SHI_CD,
                          SUBSTR(m1Row.UPD_EIGY_YMD,1,4),
                          SUBSTR(m1Row.UPD_EIGY_YMD,5,2),
                          SUBSTR(m1Row.UPD_EIGY_YMD,7,2),
                          vMODKBN,
                          iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID                     
                     );
                      EXECUTE_SQL := 'INSERT INTO TD_PM_DCF_SHI(';
                   ELSE
                      --�b��_��2����_DCF�{��
                      INSERT INTO TD_P2_DCF_SHI(
                          SHIREC_ID,
                          SHI_CD,
                          SEISHIKI_SHI_NM_KANA,
                          RYKSK_SHI_NM_KANA,
                          JUSHO_CD_KEN_CD,
                          JUSHO_CD_SHIKU_CD,
                          JUSHO_CD_OAZA_CD,
                          JUSHO_CD_AZA_CD,
                          ZIP,
                          JUSHO_HYOJI_NO,
                          JUSHO_KANA,
                          JUSHO_COUNT_KANA_KEN,
                          JUSHO_COUNT_KANA_SHIKU,
                          JUSHO_COUNT_KANA_OAZA,
                          JUSHO_COUNT_KANJI_KEN,
                          JUSHO_COUNT_KANJI_SHIKU,
                          JUSHO_COUNT_KANJI_OAZA,
                          SHI_TEL,
                          BED_SU_TEIIN,
                          KEIEITAI,
                          SHI_KBN,
                          BYOIN_SBT,
                          KANREN_DAIGAKU_OYA_SHIREC_ID,
                          KANREN_DAIGAKU_OYA_SHI_CD,
                          STATUS_JUSHOFUMEI,
                          STATUS_KYUIN_FLG,
                          STATUS_DEL_YOTEI_RIYU,
                          STATUS_KAIGYO_YOTEI_FLG,
                          STATUS_BYOTO_HEISA_FLG,
                          STATUS_TEL_NASHI_FLG,
                          STATUS_MIKAKUNIN_FLG,
                          STATUS_SAISHINSA_KBN,
                          KYUIN_S_KAIGYO_YOTEI_Y,
                          KYUIN_S_KAIGYO_YOTEI_M,
                          KYOKA_BED_MENTE_HIZUKE_Y,
                          KYOKA_BED_MENTE_HIZUKE_M,
                          KYOKA_BED_MENTE_HIZUKE_D,
                          KYOKA_BED_SU_SONOTA,
                          KYOKA_BED_SU_SEISHIN,
                          KYOKA_BED_SU_KEKKAKU,
                          KYOKA_BED_SU_KANSEN,
                          KYOKA_BED_SU_GOKEI,
                          KENSAKOMOKU_BISEIBUTSU,
                          KENSAKOMOKU_KESSEI,
                          KENSAKOMOKU_KETSUEKI,
                          KENSAKOMOKU_BYORI,
                          KENSAKOMOKU_KISEICHU,
                          KENSAKOMOKU_SEIKA,
                          KENSAKOMOKU_RI,
                          SNRYKMK_1,
                          SNRYKMK_2,
                          SNRYKMK_3,
                          SNRYKMK_4,
                          SNRYKMK_5,
                          SNRYKMK_6,
                          SNRYKMK_7,
                          SNRYKMK_8,
                          SNRYKMK_9,
                          SNRYKMK_10,
                          SNRYKMK_11,
                          SNRYKMK_12,
                          SNRYKMK_13,
                          SNRYKMK_14,
                          SNRYKMK_15,
                          SNRYKMK_16,
                          SNRYKMK_17,
                          SNRYKMK_18,
                          SNRYKMK_19,
                          SNRYKMK_20,
                          SNRYKMK_21,
                          SNRYKMK_22,
                          SNRYKMK_23,
                          SNRYKMK_24,
                          SNRYKMK_25,
                          SNRYKMK_26,
                          SNRYKMK_27,
                          SNRYKMK_28,
                          SNRYKMK_29,
                          SNRYKMK_30,
                          SNRYKMK_31,
                          SNRYKMK_32,
                          SNRYKMK_33,
                          SNRYKMK_34,
                          SNRYKMK_35,
                          SNRYKMK_36,
                          SNRYKMK_37,
                          SNRYKMK_38,
                          SNRYKMK_39,
                          SNRYKMK_40,
                          SEISHIKI_SHI_NM_KANJI,
                          RYKSK_SHI_NM_KANJI,
                          JUSHO_KANJI,
                          SHI_DAIHYO_KJNREC_ID,
                          SHI_DAIHYO_KJN_CD,
                          SHI_DAIHYO_KANA,
                          SHI_DAIHYO_KANJI,
                          SHIN_BED_KBN_IPPAN_BED,
                          SHIN_BED_KBN_RYOYO_BED,
                          AITSK_CD_SHIREC_ID,
                          AITSK_CD_SHI_CD,
                          MOD_SHORI_HIZUKE_Y,
                          MOD_SHORI_HIZUKE_M,
                          MOD_SHORI_HIZUKE_D,
                          MOD_KBN,
                          TRK_OPE_CD,TRK_DATE,TRK_PGM_ID,UPD_OPE_CD,UPD_DATE,UPD_PGM_ID
                     ) VALUES(
                          m1Row.REC_ID,
                          m1Row.SHI_CD,
                          m1Row.SEISHIKI_SHI_NM_KANA40,
                          m1Row.SHI_RN_KANA,
                          m1Row.KEN_CD,
                          m1Row.SHIKU_CD,
                          m1Row.OAZA_CD,
                          m1Row.AZA_CD,
                          NVL2(m1Row.ZIP,SUBSTR(m1Row.ZIP,1,3)||'-'||SUBSTR(m1Row.ZIP,4),NULL),
                          m1Row.JUSHO_HYOJI_NO,
                          m1Row.JUSHO_KANA_RENKETSU,
                          TO_CHAR(m1Row.KEN_NM_KANA_MOJI_SU,'FM09'),
                          TO_CHAR(m1Row.SHIKU_NM_KANA_MOJI_SU,'FM09'),
                          TO_CHAR(m1Row.OAZA_NM_KANA_MOJI_SU,'FM09'),
                          TO_CHAR(m1Row.KEN_NM_KANJI_MOJI_SU,'FM09'),
                          TO_CHAR(m1Row.SHIKU_NM_KANJI_MOJI_SU,'FM09'),
                          TO_CHAR(m1Row.OAZA_NM_KANJI_MOJI_SU,'FM09'),
                          m1Row.TEL,
                          TO_CHAR(m1Row.SHI_BED_SU,'FM0009'),
                          m1Row.KEIEITAI_CD,
                          m1Row.SHI_KBN_CD,
                          m1Row.BYOIN_SBT_CD,
                          m1Row.KANREN_DAIGAKU_OYA_REC_ID,
                          m1Row.KANREN_DAIGAKU_OYA_SHI_CD,
                          m1Row.JUSHOFUMEI_CD,
                          m1Row.KYUIN_FLG,
                          m1Row.DEL_YOTEI_RIYU_CD,
                          m1Row.KAIGYO_YOTEI_FLG,
                          m1Row.BYOTO_HEISA_KBN,
                          m1Row.TEL_NASHI_FLG,
                          m1Row.MIKAKUNIN_FLG,
                          m1Row.SAISHINSA_KBN_CD,
                          CASE
                            WHEN NVL(m1Row.KAIGYO_YOTEI_FLG,'0') = '1' THEN SUBSTR(m1Row.KAIGYO_YOTEI_YM,1,4)
                            WHEN NVL(m1Row.KYUIN_FLG,'0') = '1' THEN SUBSTR(m1Row.KYUIN_S_YM,1,4)
                            ELSE NULL
                          END,
                          CASE
                            WHEN NVL(m1Row.KAIGYO_YOTEI_FLG,'0') = '1' THEN SUBSTR(m1Row.KAIGYO_YOTEI_YM,5,2)
                            WHEN NVL(m1Row.KYUIN_FLG,'0') = '1' THEN SUBSTR(m1Row.KYUIN_S_YM,5,2)
                            ELSE NULL
                          END, 
                          SUBSTR(m1Row.BED_SU_KKNN_EIGY_YMD,1,4),                     
                          SUBSTR(m1Row.BED_SU_KKNN_EIGY_YMD,5,2),
                          SUBSTR(m1Row.BED_SU_KKNN_EIGY_YMD,7,2),
                          TO_CHAR(m1Row.KYOKA_BED_SU_SONOTA,'FM0009'),
                          TO_CHAR(m1Row.KYOKA_BED_SU_SEISHIN,'FM0009'),
                          TO_CHAR(m1Row.KYOKA_BED_SU_KEKKAKU,'FM0009'),
                          TO_CHAR(m1Row.KYOKA_BED_SU_KANSEN,'FM0009'),
                          TO_CHAR(m1Row.KYOKA_BED_SU_GOKEI,'FM0009'),
                          m1Row.KENSAKOMOKU_BISEIBUTSU_FLG,
                          m1Row.KENSAKOMOKU_KESSEI_FLG,
                          m1Row.KENSAKOMOKU_KETSUEKI_FLG,
                          m1Row.KENSAKOMOKU_BYORI_FLG,
                          m1Row.KENSAKOMOKU_KISEICHU_FLG,
                          m1Row.KENSAKOMOKU_SEIKA_FLG,
                          m1Row.KENSAKOMOKU_RI_FLG,
                          m1Row.SNRYKMK_CD_01,
                          m1Row.SNRYKMK_CD_02,
                          m1Row.SNRYKMK_CD_03,
                          m1Row.SNRYKMK_CD_04,
                          m1Row.SNRYKMK_CD_05,
                          m1Row.SNRYKMK_CD_06,
                          m1Row.SNRYKMK_CD_07,
                          m1Row.SNRYKMK_CD_08,
                          m1Row.SNRYKMK_CD_09,
                          m1Row.SNRYKMK_CD_10,
                          m1Row.SNRYKMK_CD_11,
                          m1Row.SNRYKMK_CD_12,
                          m1Row.SNRYKMK_CD_13,
                          m1Row.SNRYKMK_CD_14,
                          m1Row.SNRYKMK_CD_15,
                          m1Row.SNRYKMK_CD_16,
                          m1Row.SNRYKMK_CD_17,
                          m1Row.SNRYKMK_CD_18,
                          m1Row.SNRYKMK_CD_19,
                          m1Row.SNRYKMK_CD_20,
                          m1Row.SNRYKMK_CD_21,
                          m1Row.SNRYKMK_CD_22,
                          m1Row.SNRYKMK_CD_23,
                          m1Row.SNRYKMK_CD_24,
                          m1Row.SNRYKMK_CD_25,
                          m1Row.SNRYKMK_CD_26,
                          m1Row.SNRYKMK_CD_27,
                          m1Row.SNRYKMK_CD_28,
                          m1Row.SNRYKMK_CD_29,
                          m1Row.SNRYKMK_CD_30,
                          m1Row.SNRYKMK_CD_31,
                          m1Row.SNRYKMK_CD_32,
                          m1Row.SNRYKMK_CD_33,
                          m1Row.SNRYKMK_CD_34,
                          m1Row.SNRYKMK_CD_35,
                          m1Row.SNRYKMK_CD_36,
                          m1Row.SNRYKMK_CD_37,
                          m1Row.SNRYKMK_CD_38,
                          m1Row.SNRYKMK_CD_39,
                          m1Row.SNRYKMK_CD_40,
                          m1Row.SEISHIKI_SHI_NM30,
                          m1Row.SHI_RN,
                          m1Row.JUSHO_KANJI_RENKETSU,
                          m1Row.DAIHYO_REC_ID,
                          m1Row.DAIHYO_KJN_CD,
                          m1Row.KJN_NM_KANA,
                          m1Row.KJN_NM,
                          TO_CHAR(m1Row.KYOKA_BED_SU_IPPAN,'FM0009'),
                          TO_CHAR(m1Row.KYOKA_BED_SU_RYOYO,'FM0009'),
                          m1Row.CHOFUKU_AITSK_REC_ID,
                          m1Row.CHOFUKU_AITSK_SHI_CD,
                          SUBSTR(m1Row.UPD_EIGY_YMD,1,4),
                          SUBSTR(m1Row.UPD_EIGY_YMD,5,2),
                          SUBSTR(m1Row.UPD_EIGY_YMD,7,2),
                          vMODKBN,
                          iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID                     
                     );
                      EXECUTE_SQL := 'INSERT INTO TD_P2_DCF_SHI(';
                   END IF;
                   EXECUTE_SQL := EXECUTE_SQL||'
                          SHIREC_ID,
                          SHI_CD,
                          SEISHIKI_SHI_NM_KANA,
                          RYKSK_SHI_NM_KANA,
                          JUSHO_CD_KEN_CD,
                          JUSHO_CD_SHIKU_CD,
                          JUSHO_CD_OAZA_CD,
                          JUSHO_CD_AZA_CD,
                          ZIP,
                          JUSHO_HYOJI_NO,
                          JUSHO_KANA,
                          JUSHO_COUNT_KANA_KEN,
                          JUSHO_COUNT_KANA_SHIKU,
                          JUSHO_COUNT_KANA_OAZA,
                          JUSHO_COUNT_KANJI_KEN,
                          JUSHO_COUNT_KANJI_SHIKU,
                          JUSHO_COUNT_KANJI_OAZA,
                          SHI_TEL,
                          BED_SU_TEIIN,
                          KEIEITAI,
                          SHI_KBN,
                          BYOIN_SBT,
                          KANREN_DAIGAKU_OYA_SHIREC_ID,
                          KANREN_DAIGAKU_OYA_SHI_CD,
                          STATUS_JUSHOFUMEI,
                          STATUS_KYUIN_FLG,
                          STATUS_DEL_YOTEI_RIYU,
                          STATUS_KAIGYO_YOTEI_FLG,
                          STATUS_BYOTO_HEISA_FLG,
                          STATUS_TEL_NASHI_FLG,
                          STATUS_MIKAKUNIN_FLG,
                          STATUS_SAISHINSA_KBN,
                          KYUIN_S_KAIGYO_YOTEI_Y,
                          KYUIN_S_KAIGYO_YOTEI_M,
                          KYOKA_BED_MENTE_HIZUKE_Y,
                          KYOKA_BED_MENTE_HIZUKE_M,
                          KYOKA_BED_MENTE_HIZUKE_D,
                          KYOKA_BED_SU_SONOTA,
                          KYOKA_BED_SU_SEISHIN,
                          KYOKA_BED_SU_KEKKAKU,
                          KYOKA_BED_SU_KANSEN,
                          KYOKA_BED_SU_GOKEI,
                          KENSAKOMOKU_BISEIBUTSU,
                          KENSAKOMOKU_KESSEI,
                          KENSAKOMOKU_KETSUEKI,
                          KENSAKOMOKU_BYORI,
                          KENSAKOMOKU_KISEICHU,
                          KENSAKOMOKU_SEIKA,
                          KENSAKOMOKU_RI,
                          SNRYKMK_1,
                          SNRYKMK_2,
                          SNRYKMK_3,
                          SNRYKMK_4,
                          SNRYKMK_5,
                          SNRYKMK_6,
                          SNRYKMK_7,
                          SNRYKMK_8,
                          SNRYKMK_9,
                          SNRYKMK_10,
                          SNRYKMK_11,
                          SNRYKMK_12,
                          SNRYKMK_13,
                          SNRYKMK_14,
                          SNRYKMK_15,
                          SNRYKMK_16,
                          SNRYKMK_17,
                          SNRYKMK_18,
                          SNRYKMK_19,
                          SNRYKMK_20,
                          SNRYKMK_21,
                          SNRYKMK_22,
                          SNRYKMK_23,
                          SNRYKMK_24,
                          SNRYKMK_25,
                          SNRYKMK_26,
                          SNRYKMK_27,
                          SNRYKMK_28,
                          SNRYKMK_29,
                          SNRYKMK_30,
                          SNRYKMK_31,
                          SNRYKMK_32,
                          SNRYKMK_33,
                          SNRYKMK_34,
                          SNRYKMK_35,
                          SNRYKMK_36,
                          SNRYKMK_37,
                          SNRYKMK_38,
                          SNRYKMK_39,
                          SNRYKMK_40,
                          SEISHIKI_SHI_NM_KANJI,
                          RYKSK_SHI_NM_KANJI,
                          JUSHO_KANJI,
                          SHI_DAIHYO_KJNREC_ID,
                          SHI_DAIHYO_KJN_CD,
                          SHI_DAIHYO_KANA,
                          SHI_DAIHYO_KANJI,
                          SHIN_BED_KBN_IPPAN_BED,
                          SHIN_BED_KBN_RYOYO_BED,
                          AITSK_CD_SHIREC_ID,
                          AITSK_CD_SHI_CD,
                          MOD_SHORI_HIZUKE_Y,
                          MOD_SHORI_HIZUKE_M,
                          MOD_SHORI_HIZUKE_D,
                          MOD_KBN,
                          TRK_OPE_CD,TRK_DATE,TRK_PGM_ID,UPD_OPE_CD,UPD_DATE,UPD_PGM_ID
                     ) VALUES(
                        '''||m1Row.REC_ID||''',
                        '''||m1Row.SHI_CD||''',
                        '''||m1Row.SEISHIKI_SHI_NM_KANA40||''',
                        '''||m1Row.SHI_RN_KANA||''',
                        '''||m1Row.KEN_CD||''',
                        '''||m1Row.SHIKU_CD||''',
                        '''||m1Row.OAZA_CD||''',
                        '''||m1Row.AZA_CD||''',
                        '''||CASE WHEN m1Row.ZIP IS NOT NULL THEN SUBSTR(m1Row.ZIP,1,3)||'-'||SUBSTR(m1Row.ZIP,4) ELSE NULL END ||''',
                        '''||m1Row.JUSHO_HYOJI_NO||''',
                        '''||m1Row.JUSHO_KANA_RENKETSU||''',
                        '''||TO_CHAR(m1Row.KEN_NM_KANA_MOJI_SU,'FM09')||''',
                        '''||TO_CHAR(m1Row.SHIKU_NM_KANA_MOJI_SU,'FM09')||''',
                        '''||TO_CHAR(m1Row.OAZA_NM_KANA_MOJI_SU,'FM09')||''',
                        '''||TO_CHAR(m1Row.KEN_NM_KANJI_MOJI_SU,'FM09')||''',
                        '''||TO_CHAR(m1Row.SHIKU_NM_KANJI_MOJI_SU,'FM09')||''',
                        '''||TO_CHAR(m1Row.OAZA_NM_KANJI_MOJI_SU,'FM09')||''',
                        '''||m1Row.TEL||''',
                        '''||TO_CHAR(m1Row.SHI_BED_SU,'FM0009')||''',
                        '''||m1Row.KEIEITAI_CD||''',
                        '''||m1Row.SHI_KBN_CD||''',
                        '''||m1Row.BYOIN_SBT_CD||''',
                        '''||m1Row.KANREN_DAIGAKU_OYA_REC_ID||''',
                        '''||m1Row.KANREN_DAIGAKU_OYA_SHI_CD||''',
                        '''||m1Row.JUSHOFUMEI_CD||''',
                        '''||m1Row.KYUIN_FLG||''',
                        '''||m1Row.DEL_YOTEI_RIYU_CD||''',
                        '''||m1Row.KAIGYO_YOTEI_FLG||''',
                        '''||m1Row.BYOTO_HEISA_KBN||''',
                        '''||m1Row.TEL_NASHI_FLG||''',
                        '''||m1Row.MIKAKUNIN_FLG||''',
                        '''||m1Row.SAISHINSA_KBN_CD||''',
                        '''||CASE
                              WHEN NVL(m1Row.KAIGYO_YOTEI_FLG,'0') = '1' THEN SUBSTR(m1Row.KAIGYO_YOTEI_YM,1,4)
                              WHEN NVL(m1Row.KYUIN_FLG,'0') = '1' THEN SUBSTR(m1Row.KYUIN_S_YM,1,4)
                              ELSE NULL
                             END||''',
                        '''||CASE
                              WHEN NVL(m1Row.KAIGYO_YOTEI_FLG,'0') = '1' THEN SUBSTR(m1Row.KAIGYO_YOTEI_YM,5,2)
                              WHEN NVL(m1Row.KYUIN_FLG,'0') = '1' THEN SUBSTR(m1Row.KYUIN_S_YM,5,2)
                             ELSE NULL
                             END||''', 
                        '''||SUBSTR(m1Row.BED_SU_KKNN_EIGY_YMD,1,4)||''',                     
                        '''||SUBSTR(m1Row.BED_SU_KKNN_EIGY_YMD,5,2)||''',
                        '''||SUBSTR(m1Row.BED_SU_KKNN_EIGY_YMD,7,2)||''',
                        '''||TO_CHAR(m1Row.KYOKA_BED_SU_SONOTA,'FM0009')||''',
                        '''||TO_CHAR(m1Row.KYOKA_BED_SU_SEISHIN,'FM0009')||''',
                        '''||TO_CHAR(m1Row.KYOKA_BED_SU_KEKKAKU,'FM0009')||''',
                        '''||TO_CHAR(m1Row.KYOKA_BED_SU_KANSEN,'FM0009')||''',
                        '''||TO_CHAR(m1Row.KYOKA_BED_SU_GOKEI,'FM0009')||''',
                        '''||m1Row.KENSAKOMOKU_BISEIBUTSU_FLG||''',
                        '''||m1Row.KENSAKOMOKU_KESSEI_FLG||''',
                        '''||m1Row.KENSAKOMOKU_KETSUEKI_FLG||''',
                        '''||m1Row.KENSAKOMOKU_BYORI_FLG||''',
                        '''||m1Row.KENSAKOMOKU_KISEICHU_FLG||''',
                        '''||m1Row.KENSAKOMOKU_SEIKA_FLG||''',
                        '''||m1Row.KENSAKOMOKU_RI_FLG||''',
                        '''||m1Row.SNRYKMK_CD_01||''',
                        '''||m1Row.SNRYKMK_CD_02||''',
                        '''||m1Row.SNRYKMK_CD_03||''',
                        '''||m1Row.SNRYKMK_CD_04||''',
                        '''||m1Row.SNRYKMK_CD_05||''',
                        '''||m1Row.SNRYKMK_CD_06||''',
                        '''||m1Row.SNRYKMK_CD_07||''',
                        '''||m1Row.SNRYKMK_CD_08||''',
                        '''||m1Row.SNRYKMK_CD_09||''',
                        '''||m1Row.SNRYKMK_CD_10||''',
                        '''||m1Row.SNRYKMK_CD_11||''',
                        '''||m1Row.SNRYKMK_CD_12||''',
                        '''||m1Row.SNRYKMK_CD_13||''',
                        '''||m1Row.SNRYKMK_CD_14||''',
                        '''||m1Row.SNRYKMK_CD_15||''',
                        '''||m1Row.SNRYKMK_CD_16||''',
                        '''||m1Row.SNRYKMK_CD_17||''',
                        '''||m1Row.SNRYKMK_CD_18||''',
                        '''||m1Row.SNRYKMK_CD_19||''',
                        '''||m1Row.SNRYKMK_CD_20||''',
                        '''||m1Row.SNRYKMK_CD_21||''',
                        '''||m1Row.SNRYKMK_CD_22||''',
                        '''||m1Row.SNRYKMK_CD_23||''',
                        '''||m1Row.SNRYKMK_CD_24||''',
                        '''||m1Row.SNRYKMK_CD_25||''',
                        '''||m1Row.SNRYKMK_CD_26||''',
                        '''||m1Row.SNRYKMK_CD_27||''',
                        '''||m1Row.SNRYKMK_CD_28||''',
                        '''||m1Row.SNRYKMK_CD_29||''',
                        '''||m1Row.SNRYKMK_CD_30||''',
                        '''||m1Row.SNRYKMK_CD_31||''',
                        '''||m1Row.SNRYKMK_CD_32||''',
                        '''||m1Row.SNRYKMK_CD_33||''',
                        '''||m1Row.SNRYKMK_CD_34||''',
                        '''||m1Row.SNRYKMK_CD_35||''',
                        '''||m1Row.SNRYKMK_CD_36||''',
                        '''||m1Row.SNRYKMK_CD_37||''',
                        '''||m1Row.SNRYKMK_CD_38||''',
                        '''||m1Row.SNRYKMK_CD_39||''',
                        '''||m1Row.SNRYKMK_CD_40||''',
                        '''||m1Row.SEISHIKI_SHI_NM30||''',
                        '''||m1Row.SHI_RN||''',
                        '''||m1Row.JUSHO_KANJI_RENKETSU||''',
                        '''||m1Row.DAIHYO_REC_ID||''',
                        '''||m1Row.DAIHYO_KJN_CD||''',
                        '''||m1Row.KJN_NM_KANA||''',
                        '''||m1Row.KJN_NM||''',
                        '''||TO_CHAR(m1Row.KYOKA_BED_SU_IPPAN,'FM0009')||''',
                        '''||TO_CHAR(m1Row.KYOKA_BED_SU_RYOYO,'FM0009')||''',
                        '''||m1Row.CHOFUKU_AITSK_REC_ID||''',
                        '''||m1Row.CHOFUKU_AITSK_SHI_CD||''',
                        '''||SUBSTR(m1Row.UPD_EIGY_YMD,1,4)||''',
                        '''||SUBSTR(m1Row.UPD_EIGY_YMD,5,2)||''',
                        '''||SUBSTR(m1Row.UPD_EIGY_YMD,7,2)||''',
                        '''||vMODKBN||''',                                       
                        '''||iOPE_CD||''',
                        '''||iDATE||''',
                        '''||iPGM_ID||''',
                        '''||iOPE_CD||''',
                        '''||iDATE||''',
                        '''||iPGM_ID||''')';
                END IF;
                ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID); 
             END IF;
            END LOOP;
            IF iM2Flg = ULT_COMMON.FLG_YES THEN  
               CLOSE m2CSR;
            ELSE
               CLOSE m1CSR;   
            END IF;
            
          ELSE
            --�����߂̏ꍇ
            -- �擾�����f��DB�f�[�^���������J��Ԃ�
            IF iM2Flg = ULT_COMMON.FLG_YES THEN  
              EXECUTE_SQL := EXECUTE_SQL||'
                FROM TT_TIKY_SHI TTS
                LEFT OUTER JOIN TT_TIKY_KJN TTK
                ON  TTS.DAIHYO_REC_ID = TTK.REC_ID
                AND TTS.DAIHYO_KJN_CD = TTK.KJN_CD
                AND TTK.DEL_FLG IS NULL
                LEFT OUTER JOIN TT_Z_MM_SHI�@TZMS
                ON  TTS.REC_ID = TZMS.REC_ID
                AND TTS.SHI_CD = TZMS.SHI_CD
                LEFT OUTER JOIN TT_Z_MM_KJN TZMK
                ON  TZMS.DAIHYO_REC_ID = TZMK.REC_ID
                AND TZMS.DAIHYO_KJN_CD = TZMK.KJN_CD
                WHERE�@TTS.REC_ID�@= ''00''																	
                   AND TTS.UPD_EIGY_YMD�@>= NVL('''||iShimeFrom||''', ''19700101'')																
                   AND TTS.UPD_EIGY_YMD�@<= iShimeTo' ;
               ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);  
               OPEN m1CSR ;
            ELSE
              EXECUTE_SQL := EXECUTE_SQL||'
                FROM TT_TIKY_SHI TTS
                LEFT OUTER JOIN TT_TIKY_KJN TTK
                ON  TTS.DAIHYO_REC_ID = TTK.REC_ID
                AND TTS.DAIHYO_KJN_CD = TTK.KJN_CD
                AND TTK.DEL_FLG IS NULL
                LEFT OUTER JOIN TT_Z_ME_SHI�@TZMS
                ON  TTS.REC_ID = TZMS.REC_ID
                AND TTS.SHI_CD = TZMS.SHI_CD
                LEFT OUTER JOIN TT_Z_ME_KJN TZMK
                ON  TZMS.DAIHYO_REC_ID = TZMK.REC_ID
                AND TZMS.DAIHYO_KJN_CD = TZMK.KJN_CD
                WHERE�@TTS.REC_ID�@= ''00''																	
                   AND TTS.UPD_EIGY_YMD�@>= NVL('''||iShimeFrom||''', ''19700101'')																
                   AND TTS.UPD_EIGY_YMD�@<= iShimeTo' ;
               ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);  
               OPEN m2CSR ;    
            END IF;            
            LOOP
              IF iM2Flg = ULT_COMMON.FLG_YES THEN  
                FETCH m1CSR INTO m2Row;     
                EXIT WHEN m1CSR%NOTFOUND; 
              ELSE
                FETCH m2CSR INTO m2Row;     
                EXIT WHEN m2CSR%NOTFOUND;    
              END IF;
              
              oROW_COUNT:=oROW_COUNT+1;
              --�O���r���R�[�h�̎{�݃R�[�h�ƃ��R�[�hID��NULL�ł͂Ȃ����A
              IF m2Row.zREC_ID IS NOT  NULL AND m2Row.zSHI_CD IS NOT  NULL THEN
                --�񋟗p���R�[�h�̍폜�t���O = "1"�̎��A 
                IF m2Row.DEL_FLG = '1' THEN
                  vMODKBN := ULT_COMMON.MOD_KBN_DEL;
                ELSE
                  --���C�A�E�g�敪��"1"(�V���C�A�E�g)
                  IF iLayoutKind = ULT_COMMON.LAYOUT_SBT_CD_SHIN THEN
                     --�񋟗p���R�[�h�Ǝ擾�����O���r���R�[�h���r  
                      IF    '1'||m2Row.MIKAKUNIN_FLG = '1'||m2Row.zMIKAKUNIN_FLG
                        AND '1'||m2Row.DEL_YOTEI_RIYU_CD = '1'||m2Row.zDEL_YOTEI_RIYU_CD
                        AND '1'||m2Row.CHOFUKU_AITSK_REC_ID = '1'||m2Row.zCHOFUKU_AITSK_REC_ID
                        AND '1'||m2Row.CHOFUKU_AITSK_SHI_CD = '1'||m2Row.zCHOFUKU_AITSK_SHI_CD
                        AND '1'||m2Row.SEISHIKI_SHI_NM = '1'||m2Row.zSEISHIKI_SHI_NM
                        AND '1'||m2Row.SEISHIKI_SHI_NM_KANA = '1'||m2Row.zSEISHIKI_SHI_NM_KANA
                        AND '1'||m2Row.SHI_RN = '1'||m2Row.zSHI_RN
                        AND '1'||m2Row.SHI_RN_KANA = '1'||m2Row.zSHI_RN_KANA
                        AND '1'||m2Row.JUSHOFUMEI_CD = '1'||m2Row.zJUSHOFUMEI_CD
                        AND '1'||m2Row.KEN_CD = '1'||m2Row.zKEN_CD
                        AND '1'||m2Row.SHIKU_CD = '1'||m2Row.zSHIKU_CD
                        AND '1'||m2Row.OAZA_CD = '1'||m2Row.zOAZA_CD
                        AND '1'||m2Row.AZA_CD = '1'||m2Row.zAZA_CD
                        AND '1'||m2Row.ZIP = '1'||m2Row.zZIP
                        AND '1'||m2Row.JUSHO_KANJI_RENKETSU = '1'||m2Row.zJUSHO_KANJI_RENKETSU
                        AND '1'||m2Row.JUSHO_KANA_RENKETSU = '1'||m2Row.zJUSHO_KANA_RENKETSU
                        AND '1'||m2Row.JUSHO_HYOJI_NO = '1'||m2Row.zJUSHO_HYOJI_NO
                        AND '1'||m2Row.KEN_NM_KANJI_MOJI_SU = '1'||m2Row.zKEN_NM_KANJI_MOJI_SU
                        AND '1'||m2Row.SHIKU_NM_KANJI_MOJI_SU = '1'||m2Row.zSHIKU_NM_KANJI_MOJI_SU
                        AND '1'||m2Row.OAZA_NM_KANJI_MOJI_SU = '1'||m2Row.zOAZA_NM_KANJI_MOJI_SU
                        AND '1'||m2Row.AZA_NM_KANJI_MOJI_SU = '1'||m2Row.zAZA_NM_KANJI_MOJI_SU
                        AND '1'||m2Row.KEN_NM_KANA_MOJI_SU = '1'||m2Row.zKEN_NM_KANA_MOJI_SU
                        AND '1'||m2Row.SHIKU_NM_KANA_MOJI_SU = '1'||m2Row.zSHIKU_NM_KANA_MOJI_SU
                        AND '1'||m2Row.OAZA_NM_KANA_MOJI_SU = '1'||m2Row.zOAZA_NM_KANA_MOJI_SU
                        AND '1'||m2Row.AZA_NM_KANA_MOJI_SU = '1'||m2Row.zAZA_NM_KANA_MOJI_SU
                        AND '1'||m2Row.TEL_NASHI_FLG = '1'||m2Row.zTEL_NASHI_FLG
                        AND '1'||m2Row.TEL = '1'||m2Row.zTEL
                        AND '1'||m2Row.KEIEITAI_CD = '1'||m2Row.zKEIEITAI_CD
                        AND '1'||m2Row.SHI_KBN_CD = '1'||m2Row.zSHI_KBN_CD
                        AND '1'||m2Row.DAIHYO_REC_ID = '1'||m2Row.zDAIHYO_REC_ID
                        AND '1'||m2Row.DAIHYO_KJN_CD = '1'||m2Row.zDAIHYO_KJN_CD
                        AND '1'||m2Row.KJN_NM = '1'||m2Row.zKJN_NM
                        AND '1'||m2Row.KJN_NM_KANA = '1'||m2Row.zKJN_NM_KANA
                        AND '1'||m2Row.KAIGYO_YOTEI_FLG = '1'||m2Row.zKAIGYO_YOTEI_FLG
                        AND '1'||m2Row.KAIGYO_YOTEI_YM = '1'||m2Row.zKAIGYO_YOTEI_YM
                        AND '1'||m2Row.KYUIN_FLG = '1'||m2Row.zKYUIN_FLG
                        AND '1'||m2Row.KYUIN_S_YM = '1'||m2Row.zKYUIN_S_YM
                        AND '1'||m2Row.SNRYKMK_CD_01 = '1'||m2Row.zSNRYKMK_CD_01
                        AND '1'||m2Row.SNRYKMK_CD_02 = '1'||m2Row.zSNRYKMK_CD_02
                        AND '1'||m2Row.SNRYKMK_CD_03 = '1'||m2Row.zSNRYKMK_CD_03
                        AND '1'||m2Row.SNRYKMK_CD_04 = '1'||m2Row.zSNRYKMK_CD_04
                        AND '1'||m2Row.SNRYKMK_CD_05 = '1'||m2Row.zSNRYKMK_CD_05
                        AND '1'||m2Row.SNRYKMK_CD_06 = '1'||m2Row.zSNRYKMK_CD_06
                        AND '1'||m2Row.SNRYKMK_CD_07 = '1'||m2Row.zSNRYKMK_CD_07
                        AND '1'||m2Row.SNRYKMK_CD_08 = '1'||m2Row.zSNRYKMK_CD_08
                        AND '1'||m2Row.SNRYKMK_CD_09 = '1'||m2Row.zSNRYKMK_CD_09
                        AND '1'||m2Row.SNRYKMK_CD_10 = '1'||m2Row.zSNRYKMK_CD_10
                        AND '1'||m2Row.SNRYKMK_CD_11 = '1'||m2Row.zSNRYKMK_CD_11
                        AND '1'||m2Row.SNRYKMK_CD_12 = '1'||m2Row.zSNRYKMK_CD_12
                        AND '1'||m2Row.SNRYKMK_CD_13 = '1'||m2Row.zSNRYKMK_CD_13
                        AND '1'||m2Row.SNRYKMK_CD_14 = '1'||m2Row.zSNRYKMK_CD_14
                        AND '1'||m2Row.SNRYKMK_CD_15 = '1'||m2Row.zSNRYKMK_CD_15
                        AND '1'||m2Row.SNRYKMK_CD_16 = '1'||m2Row.zSNRYKMK_CD_16
                        AND '1'||m2Row.SNRYKMK_CD_17 = '1'||m2Row.zSNRYKMK_CD_17
                        AND '1'||m2Row.SNRYKMK_CD_18 = '1'||m2Row.zSNRYKMK_CD_18
                        AND '1'||m2Row.SNRYKMK_CD_19 = '1'||m2Row.zSNRYKMK_CD_19
                        AND '1'||m2Row.SNRYKMK_CD_20 = '1'||m2Row.zSNRYKMK_CD_20
                        AND '1'||m2Row.SNRYKMK_CD_21 = '1'||m2Row.zSNRYKMK_CD_21
                        AND '1'||m2Row.SNRYKMK_CD_22 = '1'||m2Row.zSNRYKMK_CD_22
                        AND '1'||m2Row.SNRYKMK_CD_23 = '1'||m2Row.zSNRYKMK_CD_23
                        AND '1'||m2Row.SNRYKMK_CD_24 = '1'||m2Row.zSNRYKMK_CD_24
                        AND '1'||m2Row.SNRYKMK_CD_25 = '1'||m2Row.zSNRYKMK_CD_25
                        AND '1'||m2Row.SNRYKMK_CD_26 = '1'||m2Row.zSNRYKMK_CD_26
                        AND '1'||m2Row.SNRYKMK_CD_27 = '1'||m2Row.zSNRYKMK_CD_27
                        AND '1'||m2Row.SNRYKMK_CD_28 = '1'||m2Row.zSNRYKMK_CD_28
                        AND '1'||m2Row.SNRYKMK_CD_29 = '1'||m2Row.zSNRYKMK_CD_29
                        AND '1'||m2Row.SNRYKMK_CD_30 = '1'||m2Row.zSNRYKMK_CD_30
                        AND '1'||m2Row.SNRYKMK_CD_31 = '1'||m2Row.zSNRYKMK_CD_31
                        AND '1'||m2Row.SNRYKMK_CD_32 = '1'||m2Row.zSNRYKMK_CD_32
                        AND '1'||m2Row.SNRYKMK_CD_33 = '1'||m2Row.zSNRYKMK_CD_33
                        AND '1'||m2Row.SNRYKMK_CD_34 = '1'||m2Row.zSNRYKMK_CD_34
                        AND '1'||m2Row.SNRYKMK_CD_35 = '1'||m2Row.zSNRYKMK_CD_35
                        AND '1'||m2Row.SNRYKMK_CD_36 = '1'||m2Row.zSNRYKMK_CD_36
                        AND '1'||m2Row.SNRYKMK_CD_37 = '1'||m2Row.zSNRYKMK_CD_37
                        AND '1'||m2Row.SNRYKMK_CD_38 = '1'||m2Row.zSNRYKMK_CD_38
                        AND '1'||m2Row.SNRYKMK_CD_39 = '1'||m2Row.zSNRYKMK_CD_39
                        AND '1'||m2Row.SNRYKMK_CD_40 = '1'||m2Row.zSNRYKMK_CD_40
                        AND '1'||m2Row.SNRYKMK_CD_41 = '1'||m2Row.zSNRYKMK_CD_41
                        AND '1'||m2Row.SNRYKMK_CD_42 = '1'||m2Row.zSNRYKMK_CD_42
                        AND '1'||m2Row.SNRYKMK_CD_43 = '1'||m2Row.zSNRYKMK_CD_43
                        AND '1'||m2Row.SNRYKMK_CD_44 = '1'||m2Row.zSNRYKMK_CD_44
                        AND '1'||m2Row.SNRYKMK_CD_45 = '1'||m2Row.zSNRYKMK_CD_45
                        AND '1'||m2Row.SNRYKMK_CD_46 = '1'||m2Row.zSNRYKMK_CD_46
                        AND '1'||m2Row.SNRYKMK_CD_47 = '1'||m2Row.zSNRYKMK_CD_47
                        AND '1'||m2Row.SNRYKMK_CD_48 = '1'||m2Row.zSNRYKMK_CD_48
                        AND '1'||m2Row.SNRYKMK_CD_49 = '1'||m2Row.zSNRYKMK_CD_49
                        AND '1'||m2Row.SNRYKMK_CD_50 = '1'||m2Row.zSNRYKMK_CD_50
                        AND '1'||m2Row.SNRYKMK_CD_51 = '1'||m2Row.zSNRYKMK_CD_51
                        AND '1'||m2Row.SNRYKMK_CD_52 = '1'||m2Row.zSNRYKMK_CD_52
                        AND '1'||m2Row.SNRYKMK_CD_53 = '1'||m2Row.zSNRYKMK_CD_53
                        AND '1'||m2Row.SNRYKMK_CD_54 = '1'||m2Row.zSNRYKMK_CD_54
                        AND '1'||m2Row.SNRYKMK_CD_55 = '1'||m2Row.zSNRYKMK_CD_55
                        AND '1'||m2Row.SNRYKMK_CD_56 = '1'||m2Row.zSNRYKMK_CD_56
                        AND '1'||m2Row.SNRYKMK_CD_57 = '1'||m2Row.zSNRYKMK_CD_57
                        AND '1'||m2Row.SNRYKMK_CD_58 = '1'||m2Row.zSNRYKMK_CD_58
                        AND '1'||m2Row.SNRYKMK_CD_59 = '1'||m2Row.zSNRYKMK_CD_59
                        AND '1'||m2Row.SNRYKMK_CD_60 = '1'||m2Row.zSNRYKMK_CD_60
                        AND '1'||m2Row.BYOIN_SBT_CD = '1'||m2Row.zBYOIN_SBT_CD
                        AND '1'||m2Row.SAISHINSA_KBN_CD = '1'||m2Row.zSAISHINSA_KBN_CD
                        AND '1'||m2Row.KANREN_DAIGAKU_OYA_REC_ID = '1'||m2Row.zKANREN_DAIGAKU_OYA_REC_ID
                        AND '1'||m2Row.KANREN_DAIGAKU_OYA_SHI_CD = '1'||m2Row.zKANREN_DAIGAKU_OYA_SHI_CD
                        AND '1'||m2Row.BYOTO_HEISA_KBN = '1'||m2Row.zBYOTO_HEISA_KBN
                        AND '1'||m2Row.SHI_BED_SU = '1'||m2Row.zSHI_BED_SU
                        AND '1'||m2Row.BED_SU_KKNN_EIGY_YMD = '1'||m2Row.zBED_SU_KKNN_EIGY_YMD
                        AND '1'||m2Row.KYOKA_BED_SU_GOKEI = '1'||m2Row.zKYOKA_BED_SU_GOKEI
                        AND '1'||m2Row.KYOKA_BED_SU_SEISHIN = '1'||m2Row.zKYOKA_BED_SU_SEISHIN
                        AND '1'||m2Row.KYOKA_BED_SU_KEKKAKU = '1'||m2Row.zKYOKA_BED_SU_KEKKAKU
                        AND '1'||m2Row.KYOKA_BED_SU_KANSEN = '1'||m2Row.zKYOKA_BED_SU_KANSEN
                        AND '1'||m2Row.KYOKA_BED_SU_SONOTA = '1'||m2Row.zKYOKA_BED_SU_SONOTA
                        AND '1'||m2Row.KYOKA_BED_SU_IPPAN = '1'||m2Row.zKYOKA_BED_SU_IPPAN
                        AND '1'||m2Row.KYOKA_BED_SU_RYOYO = '1'||m2Row.zKYOKA_BED_SU_RYOYO
                        AND '1'||m2Row.KENSAKOMOKU_BISEIBUTSU_FLG = '1'||m2Row.zKENSAKOMOKU_BISEIBUTSU_FLG
                        AND '1'||m2Row.KENSAKOMOKU_KESSEI_FLG = '1'||m2Row.zKENSAKOMOKU_KESSEI_FLG
                        AND '1'||m2Row.KENSAKOMOKU_KETSUEKI_FLG = '1'||m2Row.zKENSAKOMOKU_KETSUEKI_FLG
                        AND '1'||m2Row.KENSAKOMOKU_BYORI_FLG = '1'||m2Row.zKENSAKOMOKU_BYORI_FLG
                        AND '1'||m2Row.KENSAKOMOKU_KISEICHU_FLG = '1'||m2Row.zKENSAKOMOKU_KISEICHU_FLG
                        AND '1'||m2Row.KENSAKOMOKU_SEIKA_FLG = '1'||m2Row.zKENSAKOMOKU_SEIKA_FLG
                        AND '1'||m2Row.KENSAKOMOKU_RI_FLG = '1'||m2Row.zKENSAKOMOKU_RI_FLG
                        AND '1'||m2Row.IMUSHITSU_REC_ID = '1'||m2Row.zIMUSHITSU_REC_ID
                        AND '1'||m2Row.IMUSHITSU_SHI_CD = '1'||m2Row.zIMUSHITSU_SHI_CD
                      THEN
                        vMODKBN := ULT_COMMON.MOD_KBN_NO;
                      ELSE  
                        vMODKBN := ULT_COMMON.MOD_KBN_YES;
                      END IF;
                  
                  END IF;
                  --���C�A�E�g�敪��"2"(�����C�A�E�g)
                  IF iLayoutKind = ULT_COMMON.LAYOUT_SBT_CD_ZANTEI THEN
                     --�񋟗p���R�[�h�Ǝ擾�����O���r���R�[�h���r  
                     IF     '1'||m2Row.SEISHIKI_SHI_NM_KANA40 = '1'||m2Row.zSEISHIKI_SHI_NM_KANA40
                        AND '1'||m2Row.SHI_RN_KANA = '1'||m2Row.zSHI_RN_KANA
                        AND '1'||m2Row.KEN_CD = '1'||m2Row.zKEN_CD
                        AND '1'||m2Row.SHIKU_CD = '1'||m2Row.zSHIKU_CD
                        AND '1'||m2Row.OAZA_CD = '1'||m2Row.zOAZA_CD
                        AND '1'||m2Row.AZA_CD = '1'||m2Row.zAZA_CD
                        AND '1'||m2Row.ZIP = '1'||m2Row.zZIP
                        AND '1'||m2Row.JUSHO_HYOJI_NO = '1'||m2Row.zJUSHO_HYOJI_NO
                        AND '1'||m2Row.JUSHO_KANA_RENKETSU = '1'||m2Row.zJUSHO_KANA_RENKETSU
                        AND '1'||m2Row.KEN_NM_KANA_MOJI_SU = '1'||m2Row.zKEN_NM_KANA_MOJI_SU
                        AND '1'||m2Row.SHIKU_NM_KANA_MOJI_SU = '1'||m2Row.zSHIKU_NM_KANA_MOJI_SU
                        AND '1'||m2Row.OAZA_NM_KANA_MOJI_SU = '1'||m2Row.zOAZA_NM_KANA_MOJI_SU
                        AND '1'||m2Row.KEN_NM_KANJI_MOJI_SU = '1'||m2Row.zKEN_NM_KANJI_MOJI_SU
                        AND '1'||m2Row.SHIKU_NM_KANJI_MOJI_SU = '1'||m2Row.zSHIKU_NM_KANJI_MOJI_SU
                        AND '1'||m2Row.OAZA_NM_KANJI_MOJI_SU = '1'||m2Row.zOAZA_NM_KANJI_MOJI_SU
                        AND '1'||m2Row.TEL = '1'||m2Row.zTEL
                        AND '1'||m2Row.SHI_BED_SU = '1'||m2Row.zSHI_BED_SU
                        AND '1'||m2Row.KEIEITAI_CD = '1'||m2Row.zKEIEITAI_CD
                        AND '1'||m2Row.SHI_KBN_CD = '1'||m2Row.zSHI_KBN_CD
                        AND '1'||m2Row.BYOIN_SBT_CD = '1'||m2Row.zBYOIN_SBT_CD
                        AND '1'||m2Row.KANREN_DAIGAKU_OYA_REC_ID = '1'||m2Row.zKANREN_DAIGAKU_OYA_REC_ID
                        AND '1'||m2Row.KANREN_DAIGAKU_OYA_SHI_CD = '1'||m2Row.zKANREN_DAIGAKU_OYA_SHI_CD
                        AND '1'||m2Row.JUSHOFUMEI_CD = '1'||m2Row.zJUSHOFUMEI_CD
                        AND '1'||m2Row.KYUIN_FLG = '1'||m2Row.zKYUIN_FLG
                        AND '1'||m2Row.DEL_YOTEI_RIYU_CD = '1'||m2Row.zDEL_YOTEI_RIYU_CD
                        AND '1'||m2Row.KAIGYO_YOTEI_FLG = '1'||m2Row.zKAIGYO_YOTEI_FLG
                        AND '1'||m2Row.BYOTO_HEISA_KBN = '1'||m2Row.zBYOTO_HEISA_KBN
                        AND '1'||m2Row.TEL_NASHI_FLG = '1'||m2Row.zTEL_NASHI_FLG
                        AND '1'||m2Row.MIKAKUNIN_FLG = '1'||m2Row.zMIKAKUNIN_FLG
                        AND '1'||m2Row.SAISHINSA_KBN_CD = '1'||m2Row.zSAISHINSA_KBN_CD
                        AND '1'||m2Row.KAIGYO_YOTEI_YM = '1'||m2Row.zKAIGYO_YOTEI_YM
                        AND '1'||m2Row.KYUIN_S_YM = '1'||m2Row.zKYUIN_S_YM
                        AND '1'||m2Row.BED_SU_KKNN_EIGY_YMD = '1'||m2Row.zBED_SU_KKNN_EIGY_YMD
                        AND '1'||m2Row.KYOKA_BED_SU_SONOTA = '1'||m2Row.zKYOKA_BED_SU_SONOTA
                        AND '1'||m2Row.KYOKA_BED_SU_SEISHIN = '1'||m2Row.zKYOKA_BED_SU_SEISHIN
                        AND '1'||m2Row.KYOKA_BED_SU_KEKKAKU = '1'||m2Row.zKYOKA_BED_SU_KEKKAKU
                        AND '1'||m2Row.KYOKA_BED_SU_KANSEN = '1'||m2Row.zKYOKA_BED_SU_KANSEN
                        AND '1'||m2Row.KYOKA_BED_SU_GOKEI = '1'||m2Row.zKYOKA_BED_SU_GOKEI
                        AND '1'||m2Row.KENSAKOMOKU_BISEIBUTSU_FLG = '1'||m2Row.zKENSAKOMOKU_BISEIBUTSU_FLG
                        AND '1'||m2Row.KENSAKOMOKU_KESSEI_FLG = '1'||m2Row.zKENSAKOMOKU_KESSEI_FLG
                        AND '1'||m2Row.KENSAKOMOKU_KETSUEKI_FLG = '1'||m2Row.zKENSAKOMOKU_KETSUEKI_FLG
                        AND '1'||m2Row.KENSAKOMOKU_BYORI_FLG = '1'||m2Row.zKENSAKOMOKU_BYORI_FLG
                        AND '1'||m2Row.KENSAKOMOKU_KISEICHU_FLG = '1'||m2Row.zKENSAKOMOKU_KISEICHU_FLG
                        AND '1'||m2Row.KENSAKOMOKU_SEIKA_FLG = '1'||m2Row.zKENSAKOMOKU_SEIKA_FLG
                        AND '1'||m2Row.KENSAKOMOKU_RI_FLG = '1'||m2Row.zKENSAKOMOKU_RI_FLG
                        AND '1'||m2Row.SNRYKMK_CD_01 = '1'||m2Row.zSNRYKMK_CD_01
                        AND '1'||m2Row.SNRYKMK_CD_02 = '1'||m2Row.zSNRYKMK_CD_02
                        AND '1'||m2Row.SNRYKMK_CD_03 = '1'||m2Row.zSNRYKMK_CD_03
                        AND '1'||m2Row.SNRYKMK_CD_04 = '1'||m2Row.zSNRYKMK_CD_04
                        AND '1'||m2Row.SNRYKMK_CD_05 = '1'||m2Row.zSNRYKMK_CD_05
                        AND '1'||m2Row.SNRYKMK_CD_06 = '1'||m2Row.zSNRYKMK_CD_06
                        AND '1'||m2Row.SNRYKMK_CD_07 = '1'||m2Row.zSNRYKMK_CD_07
                        AND '1'||m2Row.SNRYKMK_CD_08 = '1'||m2Row.zSNRYKMK_CD_08
                        AND '1'||m2Row.SNRYKMK_CD_09 = '1'||m2Row.zSNRYKMK_CD_09
                        AND '1'||m2Row.SNRYKMK_CD_10 = '1'||m2Row.zSNRYKMK_CD_10
                        AND '1'||m2Row.SNRYKMK_CD_11 = '1'||m2Row.zSNRYKMK_CD_11
                        AND '1'||m2Row.SNRYKMK_CD_12 = '1'||m2Row.zSNRYKMK_CD_12
                        AND '1'||m2Row.SNRYKMK_CD_13 = '1'||m2Row.zSNRYKMK_CD_13
                        AND '1'||m2Row.SNRYKMK_CD_14 = '1'||m2Row.zSNRYKMK_CD_14
                        AND '1'||m2Row.SNRYKMK_CD_15 = '1'||m2Row.zSNRYKMK_CD_15
                        AND '1'||m2Row.SNRYKMK_CD_16 = '1'||m2Row.zSNRYKMK_CD_16
                        AND '1'||m2Row.SNRYKMK_CD_17 = '1'||m2Row.zSNRYKMK_CD_17
                        AND '1'||m2Row.SNRYKMK_CD_18 = '1'||m2Row.zSNRYKMK_CD_18
                        AND '1'||m2Row.SNRYKMK_CD_19 = '1'||m2Row.zSNRYKMK_CD_19
                        AND '1'||m2Row.SNRYKMK_CD_20 = '1'||m2Row.zSNRYKMK_CD_20
                        AND '1'||m2Row.SNRYKMK_CD_21 = '1'||m2Row.zSNRYKMK_CD_21
                        AND '1'||m2Row.SNRYKMK_CD_22 = '1'||m2Row.zSNRYKMK_CD_22
                        AND '1'||m2Row.SNRYKMK_CD_23 = '1'||m2Row.zSNRYKMK_CD_23
                        AND '1'||m2Row.SNRYKMK_CD_24 = '1'||m2Row.zSNRYKMK_CD_24
                        AND '1'||m2Row.SNRYKMK_CD_25 = '1'||m2Row.zSNRYKMK_CD_25
                        AND '1'||m2Row.SNRYKMK_CD_26 = '1'||m2Row.zSNRYKMK_CD_26
                        AND '1'||m2Row.SNRYKMK_CD_27 = '1'||m2Row.zSNRYKMK_CD_27
                        AND '1'||m2Row.SNRYKMK_CD_28 = '1'||m2Row.zSNRYKMK_CD_28
                        AND '1'||m2Row.SNRYKMK_CD_29 = '1'||m2Row.zSNRYKMK_CD_29
                        AND '1'||m2Row.SNRYKMK_CD_30 = '1'||m2Row.zSNRYKMK_CD_30
                        AND '1'||m2Row.SNRYKMK_CD_31 = '1'||m2Row.zSNRYKMK_CD_31
                        AND '1'||m2Row.SNRYKMK_CD_32 = '1'||m2Row.zSNRYKMK_CD_32
                        AND '1'||m2Row.SNRYKMK_CD_33 = '1'||m2Row.zSNRYKMK_CD_33
                        AND '1'||m2Row.SNRYKMK_CD_34 = '1'||m2Row.zSNRYKMK_CD_34
                        AND '1'||m2Row.SNRYKMK_CD_35 = '1'||m2Row.zSNRYKMK_CD_35
                        AND '1'||m2Row.SNRYKMK_CD_36 = '1'||m2Row.zSNRYKMK_CD_36
                        AND '1'||m2Row.SNRYKMK_CD_37 = '1'||m2Row.zSNRYKMK_CD_37
                        AND '1'||m2Row.SNRYKMK_CD_38 = '1'||m2Row.zSNRYKMK_CD_38
                        AND '1'||m2Row.SNRYKMK_CD_39 = '1'||m2Row.zSNRYKMK_CD_39
                        AND '1'||m2Row.SNRYKMK_CD_40 = '1'||m2Row.zSNRYKMK_CD_40
                        AND '1'||m2Row.SEISHIKI_SHI_NM30 = '1'||m2Row.zSEISHIKI_SHI_NM30
                        AND '1'||m2Row.SHI_RN = '1'||m2Row.zSHI_RN
                        AND '1'||m2Row.JUSHO_KANJI_RENKETSU = '1'||m2Row.zJUSHO_KANJI_RENKETSU
                        AND '1'||m2Row.DAIHYO_REC_ID = '1'||m2Row.zDAIHYO_REC_ID
                        AND '1'||m2Row.DAIHYO_KJN_CD = '1'||m2Row.zDAIHYO_KJN_CD
                        AND '1'||m2Row.KJN_NM_KANA = '1'||m2Row.zKJN_NM_KANA
                        AND '1'||m2Row.KJN_NM = '1'||m2Row.zKJN_NM
                        AND '1'||m2Row.KYOKA_BED_SU_IPPAN = '1'||m2Row.zKYOKA_BED_SU_IPPAN
                        AND '1'||m2Row.KYOKA_BED_SU_RYOYO = '1'||m2Row.zKYOKA_BED_SU_RYOYO
                        AND '1'||m2Row.CHOFUKU_AITSK_REC_ID = '1'||m2Row.zCHOFUKU_AITSK_REC_ID
                        AND '1'||m2Row.CHOFUKU_AITSK_SHI_CD = '1'||m2Row.zCHOFUKU_AITSK_SHI_CD                     
                     THEN
                        vMODKBN := ULT_COMMON.MOD_KBN_NO;
                     ELSE  
                        vMODKBN := ULT_COMMON.MOD_KBN_YES;
                     END IF;
                  
                  END IF;
                END IF;  
                  
              ELSIF m2Row.zREC_ID IS NULL AND m2Row.zSHI_CD IS NULL THEN
              --�񋟗p���R�[�h�Ə�L�Ŏ擾�����O���r���R�[�h�͓������̂̃A�C�e�����r���Ă����ꂩ���s��v�� �A
                vMODKBN := ULT_COMMON.MOD_KBN_ADD;
              END IF;            
              
              IF vMODKBN != ULT_COMMON.MOD_KBN_NO THEN
                --�C���敪���h�@�h�i���p�X�y�[�X�j�ł͂Ȃ��� 
                IF iLayoutKind = ULT_COMMON.LAYOUT_SBT_CD_SHIN THEN
                  
                   IF iM2Flg = ULT_COMMON.FLG_NO THEN                     
                      --�V_��1����_DCF�{��
                      INSERT INTO TD_NM_DCF_SHI(
                          LAYOUT_KBN,
                          SHIREC_ID,
                          SHI_CD,
                          MOD_KBN,
                          MENTE_YMD,
                          MIKAKUNIN_FLG,
                          DEL_YOTEI_RIYU,
                          AITSK_CD_SHIREC_ID,
                          AITSK_CD_SHI_CD,
                          SEISHIKI_SHI_NM_KANJI,
                          SEISHIKI_SHI_NM_KANA,
                          RYKSK_SHI_NM_KANJI,
                          RYKSK_SHI_NM_KANA,
                          JUSHOFUMEI,
                          JUSHO_CD_KEN_CD,
                          JUSHO_CD_SHIKU_CD,
                          JUSHO_CD_OAZA_CD,
                          JUSHO_CD_AZA_CD,
                          ZIP,
                          JUSHO_KANJI,
                          JUSHO_KANA,
                          JUSHO_HYOJI_NO,
                          JUSHO_COUNT_KANJI_KEN,
                          JUSHO_COUNT_KANJI_SHIKU,
                          JUSHO_COUNT_KANJI_OAZA,
                          JUSHO_COUNT_KANJI_AZA,
                          JUSHO_COUNT_KANA_KEN,
                          JUSHO_COUNT_KANA_SHIKU,
                          JUSHO_COUNT_KANA_OAZA,
                          JUSHO_COUNT_KANA_AZA,
                          TEL_NASHI_FLG,
                          TEL,
                          KEIEITAI,
                          SHI_KBN,
                          DAIHYO_KJNREC_ID,
                          DAIHYO_KJN_CD,
                          DAIHYO_KANJI,
                          DAIHYO_KANA,
                          KAIGYO_YOTEI_KAIGYO_YOTEI_FLG,
                          KAIGYO_YOTEI_KAIGYO_YOTEI_YM,
                          KYUIN_KYUIN_FLG,
                          KYUIN_KYUIN_S_YM,
                          SNRYKMK_1,
                          SNRYKMK_2,
                          SNRYKMK_3,
                          SNRYKMK_4,
                          SNRYKMK_5,
                          SNRYKMK_6,
                          SNRYKMK_7,
                          SNRYKMK_8,
                          SNRYKMK_9,
                          SNRYKMK_10,
                          SNRYKMK_11,
                          SNRYKMK_12,
                          SNRYKMK_13,
                          SNRYKMK_14,
                          SNRYKMK_15,
                          SNRYKMK_16,
                          SNRYKMK_17,
                          SNRYKMK_18,
                          SNRYKMK_19,
                          SNRYKMK_20,
                          SNRYKMK_21,
                          SNRYKMK_22,
                          SNRYKMK_23,
                          SNRYKMK_24,
                          SNRYKMK_25,
                          SNRYKMK_26,
                          SNRYKMK_27,
                          SNRYKMK_28,
                          SNRYKMK_29,
                          SNRYKMK_30,
                          SNRYKMK_31,
                          SNRYKMK_32,
                          SNRYKMK_33,
                          SNRYKMK_34,
                          SNRYKMK_35,
                          SNRYKMK_36,
                          SNRYKMK_37,
                          SNRYKMK_38,
                          SNRYKMK_39,
                          SNRYKMK_40,
                          SNRYKMK_41,
                          SNRYKMK_42,
                          SNRYKMK_43,
                          SNRYKMK_44,
                          SNRYKMK_45,
                          SNRYKMK_46,
                          SNRYKMK_47,
                          SNRYKMK_48,
                          SNRYKMK_49,
                          SNRYKMK_50,
                          SNRYKMK_51,
                          SNRYKMK_52,
                          SNRYKMK_53,
                          SNRYKMK_54,
                          SNRYKMK_55,
                          SNRYKMK_56,
                          SNRYKMK_57,
                          SNRYKMK_58,
                          SNRYKMK_59,
                          SNRYKMK_60,
                          BYOIN_SBT,
                          SAISHINSA_KBN,
                          KANREN_DAIGAKU_OYA_SHIREC_ID,
                          KANREN_DAIGAKU_OYA_SHI_CD,
                          BYOTO_HEISA_FLG,
                          BED_SU_TEIIN,
                          KYOKA_BED_MENTE_HIZUKE,
                          KYOKA_BED_SU_GOKEI,
                          KYOKA_BED_SU_SEISHIN,
                          KYOKA_BED_SU_KEKKAKU,
                          KYOKA_BED_SU_KANSEN,
                          KYOKA_BED_SU_SONOTA,
                          KYOKA_BED_SU_IPPAN_BED,
                          KYOKA_BED_SU_RYOYO_BED,
                          KENSAKOMOKU_BISEIBUTSU,
                          KENSAKOMOKU_KESSEI,
                          KENSAKOMOKU_KETSUEKI,
                          KENSAKOMOKU_BYORI,
                          KENSAKOMOKU_KISEICHU,
                          KENSAKOMOKU_SEIKA,
                          KENSAKOMOKU_RI,
                          TOKUI_CD_REC_ID,
                          TOKUI_CD_SHI_CD,
                          TRK_OPE_CD,TRK_DATE,TRK_PGM_ID,UPD_OPE_CD,UPD_DATE,UPD_PGM_ID
                      ) VALUES(
                          '101',
                          m2Row.REC_ID,
                          m2Row.SHI_CD,
                          vMODKBN,
                          m2Row.UPD_EIGY_YMD,
                          m2Row.MIKAKUNIN_FLG,
                          m2Row.DEL_YOTEI_RIYU_CD,
                          m2Row.CHOFUKU_AITSK_REC_ID,
                          m2Row.CHOFUKU_AITSK_SHI_CD,
                          m2Row.SEISHIKI_SHI_NM,
                          m2Row.SEISHIKI_SHI_NM_KANA,
                          m2Row.SHI_RN,
                          m2Row.SHI_RN_KANA,
                          m2Row.JUSHOFUMEI_CD,
                          m2Row.KEN_CD,
                          m2Row.SHIKU_CD,
                          m2Row.OAZA_CD,
                          m2Row.AZA_CD,
                          NVL2(m2Row.ZIP,SUBSTR(m2Row.ZIP,1,3)||'-'||SUBSTR(m2Row.ZIP,4),NULL),
                          m2Row.JUSHO_KANJI_RENKETSU,
                          m2Row.JUSHO_KANA_RENKETSU,
                          m2Row.JUSHO_HYOJI_NO,
                          m2Row.KEN_NM_KANJI_MOJI_SU,
                          m2Row.SHIKU_NM_KANJI_MOJI_SU,
                          m2Row.OAZA_NM_KANJI_MOJI_SU,
                          m2Row.AZA_NM_KANJI_MOJI_SU,
                          m2Row.KEN_NM_KANA_MOJI_SU,
                          m2Row.SHIKU_NM_KANA_MOJI_SU,
                          m2Row.OAZA_NM_KANA_MOJI_SU,
                          m2Row.AZA_NM_KANA_MOJI_SU,
                          m2Row.TEL_NASHI_FLG,
                          m2Row.TEL,
                          m2Row.KEIEITAI_CD,
                          m2Row.SHI_KBN_CD,
                          m2Row.DAIHYO_REC_ID,
                          m2Row.DAIHYO_KJN_CD,
                          m2Row.KJN_NM,
                          m2Row.KJN_NM_KANA,
                          m2Row.KAIGYO_YOTEI_FLG,
                          m2Row.KAIGYO_YOTEI_YM,
                          m2Row.KYUIN_FLG,
                          m2Row.KYUIN_S_YM,
                          m2Row.SNRYKMK_CD_01,
                          m2Row.SNRYKMK_CD_02,
                          m2Row.SNRYKMK_CD_03,
                          m2Row.SNRYKMK_CD_04,
                          m2Row.SNRYKMK_CD_05,
                          m2Row.SNRYKMK_CD_06,
                          m2Row.SNRYKMK_CD_07,
                          m2Row.SNRYKMK_CD_08,
                          m2Row.SNRYKMK_CD_09,
                          m2Row.SNRYKMK_CD_10,
                          m2Row.SNRYKMK_CD_11,
                          m2Row.SNRYKMK_CD_12,
                          m2Row.SNRYKMK_CD_13,
                          m2Row.SNRYKMK_CD_14,
                          m2Row.SNRYKMK_CD_15,
                          m2Row.SNRYKMK_CD_16,
                          m2Row.SNRYKMK_CD_17,
                          m2Row.SNRYKMK_CD_18,
                          m2Row.SNRYKMK_CD_19,
                          m2Row.SNRYKMK_CD_20,
                          m2Row.SNRYKMK_CD_21,
                          m2Row.SNRYKMK_CD_22,
                          m2Row.SNRYKMK_CD_23,
                          m2Row.SNRYKMK_CD_24,
                          m2Row.SNRYKMK_CD_25,
                          m2Row.SNRYKMK_CD_26,
                          m2Row.SNRYKMK_CD_27,
                          m2Row.SNRYKMK_CD_28,
                          m2Row.SNRYKMK_CD_29,
                          m2Row.SNRYKMK_CD_30,
                          m2Row.SNRYKMK_CD_31,
                          m2Row.SNRYKMK_CD_32,
                          m2Row.SNRYKMK_CD_33,
                          m2Row.SNRYKMK_CD_34,
                          m2Row.SNRYKMK_CD_35,
                          m2Row.SNRYKMK_CD_36,
                          m2Row.SNRYKMK_CD_37,
                          m2Row.SNRYKMK_CD_38,
                          m2Row.SNRYKMK_CD_39,
                          m2Row.SNRYKMK_CD_40,
                          m2Row.SNRYKMK_CD_41,
                          m2Row.SNRYKMK_CD_42,
                          m2Row.SNRYKMK_CD_43,
                          m2Row.SNRYKMK_CD_44,
                          m2Row.SNRYKMK_CD_45,
                          m2Row.SNRYKMK_CD_46,
                          m2Row.SNRYKMK_CD_47,
                          m2Row.SNRYKMK_CD_48,
                          m2Row.SNRYKMK_CD_49,
                          m2Row.SNRYKMK_CD_50,
                          m2Row.SNRYKMK_CD_51,
                          m2Row.SNRYKMK_CD_52,
                          m2Row.SNRYKMK_CD_53,
                          m2Row.SNRYKMK_CD_54,
                          m2Row.SNRYKMK_CD_55,
                          m2Row.SNRYKMK_CD_56,
                          m2Row.SNRYKMK_CD_57,
                          m2Row.SNRYKMK_CD_58,
                          m2Row.SNRYKMK_CD_59,
                          m2Row.SNRYKMK_CD_60,
                          m2Row.BYOIN_SBT_CD,
                          m2Row.SAISHINSA_KBN_CD,
                          m2Row.KANREN_DAIGAKU_OYA_REC_ID,
                          m2Row.KANREN_DAIGAKU_OYA_SHI_CD,
                          m2Row.BYOTO_HEISA_KBN,
                          m2Row.SHI_BED_SU,
                          m2Row.BED_SU_KKNN_EIGY_YMD,
                          m2Row.KYOKA_BED_SU_GOKEI,
                          m2Row.KYOKA_BED_SU_SEISHIN,
                          m2Row.KYOKA_BED_SU_KEKKAKU,
                          m2Row.KYOKA_BED_SU_KANSEN,
                          m2Row.KYOKA_BED_SU_SONOTA,
                          m2Row.KYOKA_BED_SU_IPPAN,
                          m2Row.KYOKA_BED_SU_RYOYO,
                          m2Row.KENSAKOMOKU_BISEIBUTSU_FLG,
                          m2Row.KENSAKOMOKU_KESSEI_FLG,
                          m2Row.KENSAKOMOKU_KETSUEKI_FLG,
                          m2Row.KENSAKOMOKU_BYORI_FLG,
                          m2Row.KENSAKOMOKU_KISEICHU_FLG,
                          m2Row.KENSAKOMOKU_SEIKA_FLG,
                          m2Row.KENSAKOMOKU_RI_FLG,
                          m2Row.IMUSHITSU_REC_ID,
                          m2Row.IMUSHITSU_SHI_CD,
                          iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID                      
                      );
                      EXECUTE_SQL := 'INSERT INTO TD_NM_DCF_SHI(';
                   ELSE
                     --�V_��2����_DCF�{��
                      INSERT INTO TD_N2_DCF_SHI(
                          LAYOUT_KBN,
                          SHIREC_ID,
                          SHI_CD,
                          MOD_KBN,
                          MENTE_YMD,
                          MIKAKUNIN_FLG,
                          DEL_YOTEI_RIYU,
                          AITSK_CD_SHIREC_ID,
                          AITSK_CD_SHI_CD,
                          SEISHIKI_SHI_NM_KANJI,
                          SEISHIKI_SHI_NM_KANA,
                          RYKSK_SHI_NM_KANJI,
                          RYKSK_SHI_NM_KANA,
                          JUSHOFUMEI,
                          JUSHO_CD_KEN_CD,
                          JUSHO_CD_SHIKU_CD,
                          JUSHO_CD_OAZA_CD,
                          JUSHO_CD_AZA_CD,
                          ZIP,
                          JUSHO_KANJI,
                          JUSHO_KANA,
                          JUSHO_HYOJI_NO,
                          JUSHO_COUNT_KANJI_KEN,
                          JUSHO_COUNT_KANJI_SHIKU,
                          JUSHO_COUNT_KANJI_OAZA,
                          JUSHO_COUNT_KANJI_AZA,
                          JUSHO_COUNT_KANA_KEN,
                          JUSHO_COUNT_KANA_SHIKU,
                          JUSHO_COUNT_KANA_OAZA,
                          JUSHO_COUNT_KANA_AZA,
                          TEL_NASHI_FLG,
                          TEL,
                          KEIEITAI,
                          SHI_KBN,
                          DAIHYO_KJNREC_ID,
                          DAIHYO_KJN_CD,
                          DAIHYO_KANJI,
                          DAIHYO_KANA,
                          KAIGYO_YOTEI_KAIGYO_YOTEI_FLG,
                          KAIGYO_YOTEI_KAIGYO_YOTEI_YM,
                          KYUIN_KYUIN_FLG,
                          KYUIN_KYUIN_S_YM,
                          SNRYKMK_1,
                          SNRYKMK_2,
                          SNRYKMK_3,
                          SNRYKMK_4,
                          SNRYKMK_5,
                          SNRYKMK_6,
                          SNRYKMK_7,
                          SNRYKMK_8,
                          SNRYKMK_9,
                          SNRYKMK_10,
                          SNRYKMK_11,
                          SNRYKMK_12,
                          SNRYKMK_13,
                          SNRYKMK_14,
                          SNRYKMK_15,
                          SNRYKMK_16,
                          SNRYKMK_17,
                          SNRYKMK_18,
                          SNRYKMK_19,
                          SNRYKMK_20,
                          SNRYKMK_21,
                          SNRYKMK_22,
                          SNRYKMK_23,
                          SNRYKMK_24,
                          SNRYKMK_25,
                          SNRYKMK_26,
                          SNRYKMK_27,
                          SNRYKMK_28,
                          SNRYKMK_29,
                          SNRYKMK_30,
                          SNRYKMK_31,
                          SNRYKMK_32,
                          SNRYKMK_33,
                          SNRYKMK_34,
                          SNRYKMK_35,
                          SNRYKMK_36,
                          SNRYKMK_37,
                          SNRYKMK_38,
                          SNRYKMK_39,
                          SNRYKMK_40,
                          SNRYKMK_41,
                          SNRYKMK_42,
                          SNRYKMK_43,
                          SNRYKMK_44,
                          SNRYKMK_45,
                          SNRYKMK_46,
                          SNRYKMK_47,
                          SNRYKMK_48,
                          SNRYKMK_49,
                          SNRYKMK_50,
                          SNRYKMK_51,
                          SNRYKMK_52,
                          SNRYKMK_53,
                          SNRYKMK_54,
                          SNRYKMK_55,
                          SNRYKMK_56,
                          SNRYKMK_57,
                          SNRYKMK_58,
                          SNRYKMK_59,
                          SNRYKMK_60,
                          BYOIN_SBT,
                          SAISHINSA_KBN,
                          KANREN_DAIGAKU_OYA_SHIREC_ID,
                          KANREN_DAIGAKU_OYA_SHI_CD,
                          BYOTO_HEISA_FLG,
                          BED_SU_TEIIN,
                          KYOKA_BED_MENTE_HIZUKE,
                          KYOKA_BED_SU_GOKEI,
                          KYOKA_BED_SU_SEISHIN,
                          KYOKA_BED_SU_KEKKAKU,
                          KYOKA_BED_SU_KANSEN,
                          KYOKA_BED_SU_SONOTA,
                          KYOKA_BED_SU_IPPAN_BED,
                          KYOKA_BED_SU_RYOYO_BED,
                          KENSAKOMOKU_BISEIBUTSU,
                          KENSAKOMOKU_KESSEI,
                          KENSAKOMOKU_KETSUEKI,
                          KENSAKOMOKU_BYORI,
                          KENSAKOMOKU_KISEICHU,
                          KENSAKOMOKU_SEIKA,
                          KENSAKOMOKU_RI,
                          TOKUI_CD_REC_ID,
                          TOKUI_CD_SHI_CD,
                          TRK_OPE_CD,TRK_DATE,TRK_PGM_ID,UPD_OPE_CD,UPD_DATE,UPD_PGM_ID
                      ) VALUES(
                          '101',
                          m2Row.REC_ID,
                          m2Row.SHI_CD,
                          vMODKBN,
                          m2Row.UPD_EIGY_YMD,
                          m2Row.MIKAKUNIN_FLG,
                          m2Row.DEL_YOTEI_RIYU_CD,
                          m2Row.CHOFUKU_AITSK_REC_ID,
                          m2Row.CHOFUKU_AITSK_SHI_CD,
                          m2Row.SEISHIKI_SHI_NM,
                          m2Row.SEISHIKI_SHI_NM_KANA,
                          m2Row.SHI_RN,
                          m2Row.SHI_RN_KANA,
                          m2Row.JUSHOFUMEI_CD,
                          m2Row.KEN_CD,
                          m2Row.SHIKU_CD,
                          m2Row.OAZA_CD,
                          m2Row.AZA_CD,
                          NVL2(m2Row.ZIP,SUBSTR(m2Row.ZIP,1,3)||'-'||SUBSTR(m2Row.ZIP,4),NULL),
                          m2Row.JUSHO_KANJI_RENKETSU,
                          m2Row.JUSHO_KANA_RENKETSU,
                          m2Row.JUSHO_HYOJI_NO,
                          m2Row.KEN_NM_KANJI_MOJI_SU,
                          m2Row.SHIKU_NM_KANJI_MOJI_SU,
                          m2Row.OAZA_NM_KANJI_MOJI_SU,
                          m2Row.AZA_NM_KANJI_MOJI_SU,
                          m2Row.KEN_NM_KANA_MOJI_SU,
                          m2Row.SHIKU_NM_KANA_MOJI_SU,
                          m2Row.OAZA_NM_KANA_MOJI_SU,
                          m2Row.AZA_NM_KANA_MOJI_SU,
                          m2Row.TEL_NASHI_FLG,
                          m2Row.TEL,
                          m2Row.KEIEITAI_CD,
                          m2Row.SHI_KBN_CD,
                          m2Row.DAIHYO_REC_ID,
                          m2Row.DAIHYO_KJN_CD,
                          m2Row.KJN_NM,
                          m2Row.KJN_NM_KANA,
                          m2Row.KAIGYO_YOTEI_FLG,
                          m2Row.KAIGYO_YOTEI_YM,
                          m2Row.KYUIN_FLG,
                          m2Row.KYUIN_S_YM,
                          m2Row.SNRYKMK_CD_01,
                          m2Row.SNRYKMK_CD_02,
                          m2Row.SNRYKMK_CD_03,
                          m2Row.SNRYKMK_CD_04,
                          m2Row.SNRYKMK_CD_05,
                          m2Row.SNRYKMK_CD_06,
                          m2Row.SNRYKMK_CD_07,
                          m2Row.SNRYKMK_CD_08,
                          m2Row.SNRYKMK_CD_09,
                          m2Row.SNRYKMK_CD_10,
                          m2Row.SNRYKMK_CD_11,
                          m2Row.SNRYKMK_CD_12,
                          m2Row.SNRYKMK_CD_13,
                          m2Row.SNRYKMK_CD_14,
                          m2Row.SNRYKMK_CD_15,
                          m2Row.SNRYKMK_CD_16,
                          m2Row.SNRYKMK_CD_17,
                          m2Row.SNRYKMK_CD_18,
                          m2Row.SNRYKMK_CD_19,
                          m2Row.SNRYKMK_CD_20,
                          m2Row.SNRYKMK_CD_21,
                          m2Row.SNRYKMK_CD_22,
                          m2Row.SNRYKMK_CD_23,
                          m2Row.SNRYKMK_CD_24,
                          m2Row.SNRYKMK_CD_25,
                          m2Row.SNRYKMK_CD_26,
                          m2Row.SNRYKMK_CD_27,
                          m2Row.SNRYKMK_CD_28,
                          m2Row.SNRYKMK_CD_29,
                          m2Row.SNRYKMK_CD_30,
                          m2Row.SNRYKMK_CD_31,
                          m2Row.SNRYKMK_CD_32,
                          m2Row.SNRYKMK_CD_33,
                          m2Row.SNRYKMK_CD_34,
                          m2Row.SNRYKMK_CD_35,
                          m2Row.SNRYKMK_CD_36,
                          m2Row.SNRYKMK_CD_37,
                          m2Row.SNRYKMK_CD_38,
                          m2Row.SNRYKMK_CD_39,
                          m2Row.SNRYKMK_CD_40,
                          m2Row.SNRYKMK_CD_41,
                          m2Row.SNRYKMK_CD_42,
                          m2Row.SNRYKMK_CD_43,
                          m2Row.SNRYKMK_CD_44,
                          m2Row.SNRYKMK_CD_45,
                          m2Row.SNRYKMK_CD_46,
                          m2Row.SNRYKMK_CD_47,
                          m2Row.SNRYKMK_CD_48,
                          m2Row.SNRYKMK_CD_49,
                          m2Row.SNRYKMK_CD_50,
                          m2Row.SNRYKMK_CD_51,
                          m2Row.SNRYKMK_CD_52,
                          m2Row.SNRYKMK_CD_53,
                          m2Row.SNRYKMK_CD_54,
                          m2Row.SNRYKMK_CD_55,
                          m2Row.SNRYKMK_CD_56,
                          m2Row.SNRYKMK_CD_57,
                          m2Row.SNRYKMK_CD_58,
                          m2Row.SNRYKMK_CD_59,
                          m2Row.SNRYKMK_CD_60,
                          m2Row.BYOIN_SBT_CD,
                          m2Row.SAISHINSA_KBN_CD,
                          m2Row.KANREN_DAIGAKU_OYA_REC_ID,
                          m2Row.KANREN_DAIGAKU_OYA_SHI_CD,
                          m2Row.BYOTO_HEISA_KBN,
                          m2Row.SHI_BED_SU,
                          m2Row.BED_SU_KKNN_EIGY_YMD,
                          m2Row.KYOKA_BED_SU_GOKEI,
                          m2Row.KYOKA_BED_SU_SEISHIN,
                          m2Row.KYOKA_BED_SU_KEKKAKU,
                          m2Row.KYOKA_BED_SU_KANSEN,
                          m2Row.KYOKA_BED_SU_SONOTA,
                          m2Row.KYOKA_BED_SU_IPPAN,
                          m2Row.KYOKA_BED_SU_RYOYO,
                          m2Row.KENSAKOMOKU_BISEIBUTSU_FLG,
                          m2Row.KENSAKOMOKU_KESSEI_FLG,
                          m2Row.KENSAKOMOKU_KETSUEKI_FLG,
                          m2Row.KENSAKOMOKU_BYORI_FLG,
                          m2Row.KENSAKOMOKU_KISEICHU_FLG,
                          m2Row.KENSAKOMOKU_SEIKA_FLG,
                          m2Row.KENSAKOMOKU_RI_FLG,
                          m2Row.IMUSHITSU_REC_ID,
                          m2Row.IMUSHITSU_SHI_CD,
                          iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID                      
                      );
                      EXECUTE_SQL := 'INSERT INTO TD_N2_DCF_SHI(';                     
                   END IF;
                   EXECUTE_SQL := EXECUTE_SQL||'
                          LAYOUT_KBN,
                          SHIREC_ID,
                          SHI_CD,
                          MOD_KBN,
                          MENTE_YMD,
                          MIKAKUNIN_FLG,
                          DEL_YOTEI_RIYU,
                          AITSK_CD_SHIREC_ID,
                          AITSK_CD_SHI_CD,
                          SEISHIKI_SHI_NM_KANJI,
                          SEISHIKI_SHI_NM_KANA,
                          RYKSK_SHI_NM_KANJI,
                          RYKSK_SHI_NM_KANA,
                          JUSHOFUMEI,
                          JUSHO_CD_KEN_CD,
                          JUSHO_CD_SHIKU_CD,
                          JUSHO_CD_OAZA_CD,
                          JUSHO_CD_AZA_CD,
                          ZIP,
                          JUSHO_KANJI,
                          JUSHO_KANA,
                          JUSHO_HYOJI_NO,
                          JUSHO_COUNT_KANJI_KEN,
                          JUSHO_COUNT_KANJI_SHIKU,
                          JUSHO_COUNT_KANJI_OAZA,
                          JUSHO_COUNT_KANJI_AZA,
                          JUSHO_COUNT_KANA_KEN,
                          JUSHO_COUNT_KANA_SHIKU,
                          JUSHO_COUNT_KANA_OAZA,
                          JUSHO_COUNT_KANA_AZA,
                          TEL_NASHI_FLG,
                          TEL,
                          KEIEITAI,
                          SHI_KBN,
                          DAIHYO_KJNREC_ID,
                          DAIHYO_KJN_CD,
                          DAIHYO_KANJI,
                          DAIHYO_KANA,
                          KAIGYO_YOTEI_KAIGYO_YOTEI_FLG,
                          KAIGYO_YOTEI_KAIGYO_YOTEI_YM,
                          KYUIN_KYUIN_FLG,
                          KYUIN_KYUIN_S_YM,
                          SNRYKMK_1,
                          SNRYKMK_2,
                          SNRYKMK_3,
                          SNRYKMK_4,
                          SNRYKMK_5,
                          SNRYKMK_6,
                          SNRYKMK_7,
                          SNRYKMK_8,
                          SNRYKMK_9,
                          SNRYKMK_10,
                          SNRYKMK_11,
                          SNRYKMK_12,
                          SNRYKMK_13,
                          SNRYKMK_14,
                          SNRYKMK_15,
                          SNRYKMK_16,
                          SNRYKMK_17,
                          SNRYKMK_18,
                          SNRYKMK_19,
                          SNRYKMK_20,
                          SNRYKMK_21,
                          SNRYKMK_22,
                          SNRYKMK_23,
                          SNRYKMK_24,
                          SNRYKMK_25,
                          SNRYKMK_26,
                          SNRYKMK_27,
                          SNRYKMK_28,
                          SNRYKMK_29,
                          SNRYKMK_30,
                          SNRYKMK_31,
                          SNRYKMK_32,
                          SNRYKMK_33,
                          SNRYKMK_34,
                          SNRYKMK_35,
                          SNRYKMK_36,
                          SNRYKMK_37,
                          SNRYKMK_38,
                          SNRYKMK_39,
                          SNRYKMK_40,
                          SNRYKMK_41,
                          SNRYKMK_42,
                          SNRYKMK_43,
                          SNRYKMK_44,
                          SNRYKMK_45,
                          SNRYKMK_46,
                          SNRYKMK_47,
                          SNRYKMK_48,
                          SNRYKMK_49,
                          SNRYKMK_50,
                          SNRYKMK_51,
                          SNRYKMK_52,
                          SNRYKMK_53,
                          SNRYKMK_54,
                          SNRYKMK_55,
                          SNRYKMK_56,
                          SNRYKMK_57,
                          SNRYKMK_58,
                          SNRYKMK_59,
                          SNRYKMK_60,
                          BYOIN_SBT,
                          SAISHINSA_KBN,
                          KANREN_DAIGAKU_OYA_SHIREC_ID,
                          KANREN_DAIGAKU_OYA_SHI_CD,
                          BYOTO_HEISA_FLG,
                          BED_SU_TEIIN,
                          KYOKA_BED_MENTE_HIZUKE,
                          KYOKA_BED_SU_GOKEI,
                          KYOKA_BED_SU_SEISHIN,
                          KYOKA_BED_SU_KEKKAKU,
                          KYOKA_BED_SU_KANSEN,
                          KYOKA_BED_SU_SONOTA,
                          KYOKA_BED_SU_IPPAN_BED,
                          KYOKA_BED_SU_RYOYO_BED,
                          KENSAKOMOKU_BISEIBUTSU,
                          KENSAKOMOKU_KESSEI,
                          KENSAKOMOKU_KETSUEKI,
                          KENSAKOMOKU_BYORI,
                          KENSAKOMOKU_KISEICHU,
                          KENSAKOMOKU_SEIKA,
                          KENSAKOMOKU_RI,
                          TOKUI_CD_REC_ID,
                          TOKUI_CD_SHI_CD,
                          TRK_OPE_CD,TRK_DATE,TRK_PGM_ID,UPD_OPE_CD,UPD_DATE,UPD_PGM_ID
                      ) VALUES(
                        ''101'',
                        '''||m2Row.REC_ID||''',
                        '''||m2Row.SHI_CD||''',
                        '''||vMODKBN||''',
                        '''||m2Row.UPD_EIGY_YMD||''',
                        '''||m2Row.MIKAKUNIN_FLG||''',
                        '''||m2Row.DEL_YOTEI_RIYU_CD||''',
                        '''||m2Row.CHOFUKU_AITSK_REC_ID||''',
                        '''||m2Row.CHOFUKU_AITSK_SHI_CD||''',
                        '''||m2Row.SEISHIKI_SHI_NM||''',
                        '''||m2Row.SEISHIKI_SHI_NM_KANA||''',
                        '''||m2Row.SHI_RN||''',
                        '''||m2Row.SHI_RN_KANA||''',
                        '''||m2Row.JUSHOFUMEI_CD||''',
                        '''||m2Row.KEN_CD||''',
                        '''||m2Row.SHIKU_CD||''',
                        '''||m2Row.OAZA_CD||''',
                        '''||m2Row.AZA_CD||''',
                        '''||CASE WHEN m2Row.ZIP IS NOT NULL THEN SUBSTR(m2Row.ZIP,1,3)||'-'||SUBSTR(m2Row.ZIP,4) ELSE NULL END ||''',
                        '''||m2Row.JUSHO_KANJI_RENKETSU||''',
                        '''||m2Row.JUSHO_KANA_RENKETSU||''',
                        '''||m2Row.JUSHO_HYOJI_NO||''',
                        '''||m2Row.KEN_NM_KANJI_MOJI_SU||''',
                        '''||m2Row.SHIKU_NM_KANJI_MOJI_SU||''',
                        '''||m2Row.OAZA_NM_KANJI_MOJI_SU||''',
                        '''||m2Row.AZA_NM_KANJI_MOJI_SU||''',
                        '''||m2Row.KEN_NM_KANA_MOJI_SU||''',
                        '''||m2Row.SHIKU_NM_KANA_MOJI_SU||''',
                        '''||m2Row.OAZA_NM_KANA_MOJI_SU||''',
                        '''||m2Row.AZA_NM_KANA_MOJI_SU||''',
                        '''||m2Row.TEL_NASHI_FLG||''',
                        '''||m2Row.TEL||''',
                        '''||m2Row.KEIEITAI_CD||''',
                        '''||m2Row.SHI_KBN_CD||''',
                        '''||m2Row.DAIHYO_REC_ID||''',
                        '''||m2Row.DAIHYO_KJN_CD||''',
                        '''||m2Row.KJN_NM||''',
                        '''||m2Row.KJN_NM_KANA||''',
                        '''||m2Row.KAIGYO_YOTEI_FLG||''',
                        '''||m2Row.KAIGYO_YOTEI_YM||''',
                        '''||m2Row.KYUIN_FLG||''',
                        '''||m2Row.KYUIN_S_YM||''',
                        '''||m2Row.SNRYKMK_CD_01||''',
                        '''||m2Row.SNRYKMK_CD_02||''',
                        '''||m2Row.SNRYKMK_CD_03||''',
                        '''||m2Row.SNRYKMK_CD_04||''',
                        '''||m2Row.SNRYKMK_CD_05||''',
                        '''||m2Row.SNRYKMK_CD_06||''',
                        '''||m2Row.SNRYKMK_CD_07||''',
                        '''||m2Row.SNRYKMK_CD_08||''',
                        '''||m2Row.SNRYKMK_CD_09||''',
                        '''||m2Row.SNRYKMK_CD_10||''',
                        '''||m2Row.SNRYKMK_CD_11||''',
                        '''||m2Row.SNRYKMK_CD_12||''',
                        '''||m2Row.SNRYKMK_CD_13||''',
                        '''||m2Row.SNRYKMK_CD_14||''',
                        '''||m2Row.SNRYKMK_CD_15||''',
                        '''||m2Row.SNRYKMK_CD_16||''',
                        '''||m2Row.SNRYKMK_CD_17||''',
                        '''||m2Row.SNRYKMK_CD_18||''',
                        '''||m2Row.SNRYKMK_CD_19||''',
                        '''||m2Row.SNRYKMK_CD_20||''',
                        '''||m2Row.SNRYKMK_CD_21||''',
                        '''||m2Row.SNRYKMK_CD_22||''',
                        '''||m2Row.SNRYKMK_CD_23||''',
                        '''||m2Row.SNRYKMK_CD_24||''',
                        '''||m2Row.SNRYKMK_CD_25||''',
                        '''||m2Row.SNRYKMK_CD_26||''',
                        '''||m2Row.SNRYKMK_CD_27||''',
                        '''||m2Row.SNRYKMK_CD_28||''',
                        '''||m2Row.SNRYKMK_CD_29||''',
                        '''||m2Row.SNRYKMK_CD_30||''',
                        '''||m2Row.SNRYKMK_CD_31||''',
                        '''||m2Row.SNRYKMK_CD_32||''',
                        '''||m2Row.SNRYKMK_CD_33||''',
                        '''||m2Row.SNRYKMK_CD_34||''',
                        '''||m2Row.SNRYKMK_CD_35||''',
                        '''||m2Row.SNRYKMK_CD_36||''',
                        '''||m2Row.SNRYKMK_CD_37||''',
                        '''||m2Row.SNRYKMK_CD_38||''',
                        '''||m2Row.SNRYKMK_CD_39||''',
                        '''||m2Row.SNRYKMK_CD_40||''',
                        '''||m2Row.SNRYKMK_CD_41||''',
                        '''||m2Row.SNRYKMK_CD_42||''',
                        '''||m2Row.SNRYKMK_CD_43||''',
                        '''||m2Row.SNRYKMK_CD_44||''',
                        '''||m2Row.SNRYKMK_CD_45||''',
                        '''||m2Row.SNRYKMK_CD_46||''',
                        '''||m2Row.SNRYKMK_CD_47||''',
                        '''||m2Row.SNRYKMK_CD_48||''',
                        '''||m2Row.SNRYKMK_CD_49||''',
                        '''||m2Row.SNRYKMK_CD_50||''',
                        '''||m2Row.SNRYKMK_CD_51||''',
                        '''||m2Row.SNRYKMK_CD_52||''',
                        '''||m2Row.SNRYKMK_CD_53||''',
                        '''||m2Row.SNRYKMK_CD_54||''',
                        '''||m2Row.SNRYKMK_CD_55||''',
                        '''||m2Row.SNRYKMK_CD_56||''',
                        '''||m2Row.SNRYKMK_CD_57||''',
                        '''||m2Row.SNRYKMK_CD_58||''',
                        '''||m2Row.SNRYKMK_CD_59||''',
                        '''||m2Row.SNRYKMK_CD_60||''',
                        '''||m2Row.BYOIN_SBT_CD||''',
                        '''||m2Row.SAISHINSA_KBN_CD||''',
                        '''||m2Row.KANREN_DAIGAKU_OYA_REC_ID||''',
                        '''||m2Row.KANREN_DAIGAKU_OYA_SHI_CD||''',
                        '''||m2Row.BYOTO_HEISA_KBN||''',
                        '''||m2Row.SHI_BED_SU||''',
                        '''||m2Row.BED_SU_KKNN_EIGY_YMD||''',
                        '''||m2Row.KYOKA_BED_SU_GOKEI||''',
                        '''||m2Row.KYOKA_BED_SU_SEISHIN||''',
                        '''||m2Row.KYOKA_BED_SU_KEKKAKU||''',
                        '''||m2Row.KYOKA_BED_SU_KANSEN||''',
                        '''||m2Row.KYOKA_BED_SU_SONOTA||''',
                        '''||m2Row.KYOKA_BED_SU_IPPAN||''',
                        '''||m2Row.KYOKA_BED_SU_RYOYO||''',
                        '''||m2Row.KENSAKOMOKU_BISEIBUTSU_FLG||''',
                        '''||m2Row.KENSAKOMOKU_KESSEI_FLG||''',
                        '''||m2Row.KENSAKOMOKU_KETSUEKI_FLG||''',
                        '''||m2Row.KENSAKOMOKU_BYORI_FLG||''',
                        '''||m2Row.KENSAKOMOKU_KISEICHU_FLG||''',
                        '''||m2Row.KENSAKOMOKU_SEIKA_FLG||''',
                        '''||m2Row.KENSAKOMOKU_RI_FLG||''',
                        '''||m2Row.IMUSHITSU_REC_ID||''',
                        '''||m2Row.IMUSHITSU_SHI_CD||''',                                       
                        '''||iOPE_CD||''',
                        '''||iDATE||''',
                        '''||iPGM_ID||''',
                        '''||iOPE_CD||''',
                        '''||iDATE||''',
                        '''||iPGM_ID||''')';
                ELSIF iLayoutKind = ULT_COMMON.LAYOUT_SBT_CD_ZANTEI THEN
                   IF iM2Flg = ULT_COMMON.FLG_NO THEN                     
                      --�b��_��1����_DCF�{��
                      INSERT INTO TD_PM_DCF_SHI(
                          SHIREC_ID,
                          SHI_CD,
                          SEISHIKI_SHI_NM_KANA,
                          RYKSK_SHI_NM_KANA,
                          JUSHO_CD_KEN_CD,
                          JUSHO_CD_SHIKU_CD,
                          JUSHO_CD_OAZA_CD,
                          JUSHO_CD_AZA_CD,
                          ZIP,
                          JUSHO_HYOJI_NO,
                          JUSHO_KANA,
                          JUSHO_COUNT_KANA_KEN,
                          JUSHO_COUNT_KANA_SHIKU,
                          JUSHO_COUNT_KANA_OAZA,
                          JUSHO_COUNT_KANJI_KEN,
                          JUSHO_COUNT_KANJI_SHIKU,
                          JUSHO_COUNT_KANJI_OAZA,
                          SHI_TEL,
                          BED_SU_TEIIN,
                          KEIEITAI,
                          SHI_KBN,
                          BYOIN_SBT,
                          KANREN_DAIGAKU_OYA_SHIREC_ID,
                          KANREN_DAIGAKU_OYA_SHI_CD,
                          STATUS_JUSHOFUMEI,
                          STATUS_KYUIN_FLG,
                          STATUS_DEL_YOTEI_RIYU,
                          STATUS_KAIGYO_YOTEI_FLG,
                          STATUS_BYOTO_HEISA_FLG,
                          STATUS_TEL_NASHI_FLG,
                          STATUS_MIKAKUNIN_FLG,
                          STATUS_SAISHINSA_KBN,
                          KYUIN_S_KAIGYO_YOTEI_Y,
                          KYUIN_S_KAIGYO_YOTEI_M,
                          KYOKA_BED_MENTE_HIZUKE_Y,
                          KYOKA_BED_MENTE_HIZUKE_M,
                          KYOKA_BED_MENTE_HIZUKE_D,
                          KYOKA_BED_SU_SONOTA,
                          KYOKA_BED_SU_SEISHIN,
                          KYOKA_BED_SU_KEKKAKU,
                          KYOKA_BED_SU_KANSEN,
                          KYOKA_BED_SU_GOKEI,
                          KENSAKOMOKU_BISEIBUTSU,
                          KENSAKOMOKU_KESSEI,
                          KENSAKOMOKU_KETSUEKI,
                          KENSAKOMOKU_BYORI,
                          KENSAKOMOKU_KISEICHU,
                          KENSAKOMOKU_SEIKA,
                          KENSAKOMOKU_RI,
                          SNRYKMK_1,
                          SNRYKMK_2,
                          SNRYKMK_3,
                          SNRYKMK_4,
                          SNRYKMK_5,
                          SNRYKMK_6,
                          SNRYKMK_7,
                          SNRYKMK_8,
                          SNRYKMK_9,
                          SNRYKMK_10,
                          SNRYKMK_11,
                          SNRYKMK_12,
                          SNRYKMK_13,
                          SNRYKMK_14,
                          SNRYKMK_15,
                          SNRYKMK_16,
                          SNRYKMK_17,
                          SNRYKMK_18,
                          SNRYKMK_19,
                          SNRYKMK_20,
                          SNRYKMK_21,
                          SNRYKMK_22,
                          SNRYKMK_23,
                          SNRYKMK_24,
                          SNRYKMK_25,
                          SNRYKMK_26,
                          SNRYKMK_27,
                          SNRYKMK_28,
                          SNRYKMK_29,
                          SNRYKMK_30,
                          SNRYKMK_31,
                          SNRYKMK_32,
                          SNRYKMK_33,
                          SNRYKMK_34,
                          SNRYKMK_35,
                          SNRYKMK_36,
                          SNRYKMK_37,
                          SNRYKMK_38,
                          SNRYKMK_39,
                          SNRYKMK_40,
                          SEISHIKI_SHI_NM_KANJI,
                          RYKSK_SHI_NM_KANJI,
                          JUSHO_KANJI,
                          SHI_DAIHYO_KJNREC_ID,
                          SHI_DAIHYO_KJN_CD,
                          SHI_DAIHYO_KANA,
                          SHI_DAIHYO_KANJI,
                          SHIN_BED_KBN_IPPAN_BED,
                          SHIN_BED_KBN_RYOYO_BED,
                          AITSK_CD_SHIREC_ID,
                          AITSK_CD_SHI_CD,
                          MOD_SHORI_HIZUKE_Y,
                          MOD_SHORI_HIZUKE_M,
                          MOD_SHORI_HIZUKE_D,
                          MOD_KBN,
                          TRK_OPE_CD,TRK_DATE,TRK_PGM_ID,UPD_OPE_CD,UPD_DATE,UPD_PGM_ID
                     ) VALUES(
                          m2Row.REC_ID,
                          m2Row.SHI_CD,
                          m2Row.SEISHIKI_SHI_NM_KANA40,
                          m2Row.SHI_RN_KANA,
                          m2Row.KEN_CD,
                          m2Row.SHIKU_CD,
                          m2Row.OAZA_CD,
                          m2Row.AZA_CD,
                          NVL2(m2Row.ZIP,SUBSTR(m2Row.ZIP,1,3)||'-'||SUBSTR(m2Row.ZIP,4),NULL),
                          m2Row.JUSHO_HYOJI_NO,
                          m2Row.JUSHO_KANA_RENKETSU,
                          TO_CHAR(m2Row.KEN_NM_KANA_MOJI_SU,'FM09'),
                          TO_CHAR(m2Row.SHIKU_NM_KANA_MOJI_SU,'FM09'),
                          TO_CHAR(m2Row.OAZA_NM_KANA_MOJI_SU,'FM09'),
                          TO_CHAR(m2Row.KEN_NM_KANJI_MOJI_SU,'FM09'),
                          TO_CHAR(m2Row.SHIKU_NM_KANJI_MOJI_SU,'FM09'),
                          TO_CHAR(m2Row.OAZA_NM_KANJI_MOJI_SU,'FM09'),
                          m2Row.TEL,
                          TO_CHAR(m2Row.SHI_BED_SU,'FM0009'),
                          m2Row.KEIEITAI_CD,
                          m2Row.SHI_KBN_CD,
                          m2Row.BYOIN_SBT_CD,
                          m2Row.KANREN_DAIGAKU_OYA_REC_ID,
                          m2Row.KANREN_DAIGAKU_OYA_SHI_CD,
                          m2Row.JUSHOFUMEI_CD,
                          m2Row.KYUIN_FLG,
                          m2Row.DEL_YOTEI_RIYU_CD,
                          m2Row.KAIGYO_YOTEI_FLG,
                          m2Row.BYOTO_HEISA_KBN,
                          m2Row.TEL_NASHI_FLG,
                          m2Row.MIKAKUNIN_FLG,
                          m2Row.SAISHINSA_KBN_CD,
                          CASE
                            WHEN NVL(m2Row.KAIGYO_YOTEI_FLG,'0') = '1' THEN SUBSTR(m2Row.KAIGYO_YOTEI_YM,1,4)
                            WHEN NVL(m2Row.KYUIN_FLG,'0') = '1' THEN SUBSTR(m2Row.KYUIN_S_YM,1,4)
                            ELSE NULL
                          END,
                          CASE
                            WHEN NVL(m2Row.KAIGYO_YOTEI_FLG,'0') = '1' THEN SUBSTR(m2Row.KAIGYO_YOTEI_YM,5,2)
                            WHEN NVL(m2Row.KYUIN_FLG,'0') = '1' THEN SUBSTR(m2Row.KYUIN_S_YM,5,2)
                            ELSE NULL
                          END, 
                          SUBSTR(m2Row.BED_SU_KKNN_EIGY_YMD,1,4),                     
                          SUBSTR(m2Row.BED_SU_KKNN_EIGY_YMD,5,2),
                          SUBSTR(m2Row.BED_SU_KKNN_EIGY_YMD,7,2),
                          TO_CHAR(m2Row.KYOKA_BED_SU_SONOTA,'FM0009'),
                          TO_CHAR(m2Row.KYOKA_BED_SU_SEISHIN,'FM0009'),
                          TO_CHAR(m2Row.KYOKA_BED_SU_KEKKAKU,'FM0009'),
                          TO_CHAR(m2Row.KYOKA_BED_SU_KANSEN,'FM0009'),
                          TO_CHAR(m2Row.KYOKA_BED_SU_GOKEI,'FM0009'),
                          m2Row.KENSAKOMOKU_BISEIBUTSU_FLG,
                          m2Row.KENSAKOMOKU_KESSEI_FLG,
                          m2Row.KENSAKOMOKU_KETSUEKI_FLG,
                          m2Row.KENSAKOMOKU_BYORI_FLG,
                          m2Row.KENSAKOMOKU_KISEICHU_FLG,
                          m2Row.KENSAKOMOKU_SEIKA_FLG,
                          m2Row.KENSAKOMOKU_RI_FLG,
                          m2Row.SNRYKMK_CD_01,
                          m2Row.SNRYKMK_CD_02,
                          m2Row.SNRYKMK_CD_03,
                          m2Row.SNRYKMK_CD_04,
                          m2Row.SNRYKMK_CD_05,
                          m2Row.SNRYKMK_CD_06,
                          m2Row.SNRYKMK_CD_07,
                          m2Row.SNRYKMK_CD_08,
                          m2Row.SNRYKMK_CD_09,
                          m2Row.SNRYKMK_CD_10,
                          m2Row.SNRYKMK_CD_11,
                          m2Row.SNRYKMK_CD_12,
                          m2Row.SNRYKMK_CD_13,
                          m2Row.SNRYKMK_CD_14,
                          m2Row.SNRYKMK_CD_15,
                          m2Row.SNRYKMK_CD_16,
                          m2Row.SNRYKMK_CD_17,
                          m2Row.SNRYKMK_CD_18,
                          m2Row.SNRYKMK_CD_19,
                          m2Row.SNRYKMK_CD_20,
                          m2Row.SNRYKMK_CD_21,
                          m2Row.SNRYKMK_CD_22,
                          m2Row.SNRYKMK_CD_23,
                          m2Row.SNRYKMK_CD_24,
                          m2Row.SNRYKMK_CD_25,
                          m2Row.SNRYKMK_CD_26,
                          m2Row.SNRYKMK_CD_27,
                          m2Row.SNRYKMK_CD_28,
                          m2Row.SNRYKMK_CD_29,
                          m2Row.SNRYKMK_CD_30,
                          m2Row.SNRYKMK_CD_31,
                          m2Row.SNRYKMK_CD_32,
                          m2Row.SNRYKMK_CD_33,
                          m2Row.SNRYKMK_CD_34,
                          m2Row.SNRYKMK_CD_35,
                          m2Row.SNRYKMK_CD_36,
                          m2Row.SNRYKMK_CD_37,
                          m2Row.SNRYKMK_CD_38,
                          m2Row.SNRYKMK_CD_39,
                          m2Row.SNRYKMK_CD_40,
                          m2Row.SEISHIKI_SHI_NM30,
                          m2Row.SHI_RN,
                          m2Row.JUSHO_KANJI_RENKETSU,
                          m2Row.DAIHYO_REC_ID,
                          m2Row.DAIHYO_KJN_CD,
                          m2Row.KJN_NM_KANA,
                          m2Row.KJN_NM,
                          TO_CHAR(m2Row.KYOKA_BED_SU_IPPAN,'FM0009'),
                          TO_CHAR(m2Row.KYOKA_BED_SU_RYOYO,'FM0009'),
                          m2Row.CHOFUKU_AITSK_REC_ID,
                          m2Row.CHOFUKU_AITSK_SHI_CD,
                          SUBSTR(m2Row.UPD_EIGY_YMD,1,4),
                          SUBSTR(m2Row.UPD_EIGY_YMD,5,2),
                          SUBSTR(m2Row.UPD_EIGY_YMD,7,2),
                          vMODKBN,
                          iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID                     
                     );
                      EXECUTE_SQL := 'INSERT INTO TD_PM_DCF_SHI(';
                   ELSE
                      --�b��_��2����_DCF�{��
                      INSERT INTO TD_P2_DCF_SHI(
                          SHIREC_ID,
                          SHI_CD,
                          SEISHIKI_SHI_NM_KANA,
                          RYKSK_SHI_NM_KANA,
                          JUSHO_CD_KEN_CD,
                          JUSHO_CD_SHIKU_CD,
                          JUSHO_CD_OAZA_CD,
                          JUSHO_CD_AZA_CD,
                          ZIP,
                          JUSHO_HYOJI_NO,
                          JUSHO_KANA,
                          JUSHO_COUNT_KANA_KEN,
                          JUSHO_COUNT_KANA_SHIKU,
                          JUSHO_COUNT_KANA_OAZA,
                          JUSHO_COUNT_KANJI_KEN,
                          JUSHO_COUNT_KANJI_SHIKU,
                          JUSHO_COUNT_KANJI_OAZA,
                          SHI_TEL,
                          BED_SU_TEIIN,
                          KEIEITAI,
                          SHI_KBN,
                          BYOIN_SBT,
                          KANREN_DAIGAKU_OYA_SHIREC_ID,
                          KANREN_DAIGAKU_OYA_SHI_CD,
                          STATUS_JUSHOFUMEI,
                          STATUS_KYUIN_FLG,
                          STATUS_DEL_YOTEI_RIYU,
                          STATUS_KAIGYO_YOTEI_FLG,
                          STATUS_BYOTO_HEISA_FLG,
                          STATUS_TEL_NASHI_FLG,
                          STATUS_MIKAKUNIN_FLG,
                          STATUS_SAISHINSA_KBN,
                          KYUIN_S_KAIGYO_YOTEI_Y,
                          KYUIN_S_KAIGYO_YOTEI_M,
                          KYOKA_BED_MENTE_HIZUKE_Y,
                          KYOKA_BED_MENTE_HIZUKE_M,
                          KYOKA_BED_MENTE_HIZUKE_D,
                          KYOKA_BED_SU_SONOTA,
                          KYOKA_BED_SU_SEISHIN,
                          KYOKA_BED_SU_KEKKAKU,
                          KYOKA_BED_SU_KANSEN,
                          KYOKA_BED_SU_GOKEI,
                          KENSAKOMOKU_BISEIBUTSU,
                          KENSAKOMOKU_KESSEI,
                          KENSAKOMOKU_KETSUEKI,
                          KENSAKOMOKU_BYORI,
                          KENSAKOMOKU_KISEICHU,
                          KENSAKOMOKU_SEIKA,
                          KENSAKOMOKU_RI,
                          SNRYKMK_1,
                          SNRYKMK_2,
                          SNRYKMK_3,
                          SNRYKMK_4,
                          SNRYKMK_5,
                          SNRYKMK_6,
                          SNRYKMK_7,
                          SNRYKMK_8,
                          SNRYKMK_9,
                          SNRYKMK_10,
                          SNRYKMK_11,
                          SNRYKMK_12,
                          SNRYKMK_13,
                          SNRYKMK_14,
                          SNRYKMK_15,
                          SNRYKMK_16,
                          SNRYKMK_17,
                          SNRYKMK_18,
                          SNRYKMK_19,
                          SNRYKMK_20,
                          SNRYKMK_21,
                          SNRYKMK_22,
                          SNRYKMK_23,
                          SNRYKMK_24,
                          SNRYKMK_25,
                          SNRYKMK_26,
                          SNRYKMK_27,
                          SNRYKMK_28,
                          SNRYKMK_29,
                          SNRYKMK_30,
                          SNRYKMK_31,
                          SNRYKMK_32,
                          SNRYKMK_33,
                          SNRYKMK_34,
                          SNRYKMK_35,
                          SNRYKMK_36,
                          SNRYKMK_37,
                          SNRYKMK_38,
                          SNRYKMK_39,
                          SNRYKMK_40,
                          SEISHIKI_SHI_NM_KANJI,
                          RYKSK_SHI_NM_KANJI,
                          JUSHO_KANJI,
                          SHI_DAIHYO_KJNREC_ID,
                          SHI_DAIHYO_KJN_CD,
                          SHI_DAIHYO_KANA,
                          SHI_DAIHYO_KANJI,
                          SHIN_BED_KBN_IPPAN_BED,
                          SHIN_BED_KBN_RYOYO_BED,
                          AITSK_CD_SHIREC_ID,
                          AITSK_CD_SHI_CD,
                          MOD_SHORI_HIZUKE_Y,
                          MOD_SHORI_HIZUKE_M,
                          MOD_SHORI_HIZUKE_D,
                          MOD_KBN,
                          TRK_OPE_CD,TRK_DATE,TRK_PGM_ID,UPD_OPE_CD,UPD_DATE,UPD_PGM_ID
                     ) VALUES(
                          m2Row.REC_ID,
                          m2Row.SHI_CD,
                          m2Row.SEISHIKI_SHI_NM_KANA40,
                          m2Row.SHI_RN_KANA,
                          m2Row.KEN_CD,
                          m2Row.SHIKU_CD,
                          m2Row.OAZA_CD,
                          m2Row.AZA_CD,
                          NVL2(m2Row.ZIP,SUBSTR(m2Row.ZIP,1,3)||'-'||SUBSTR(m2Row.ZIP,4),NULL),
                          m2Row.JUSHO_HYOJI_NO,
                          m2Row.JUSHO_KANA_RENKETSU,
                          TO_CHAR(m2Row.KEN_NM_KANA_MOJI_SU,'FM09'),
                          TO_CHAR(m2Row.SHIKU_NM_KANA_MOJI_SU,'FM09'),
                          TO_CHAR(m2Row.OAZA_NM_KANA_MOJI_SU,'FM09'),
                          TO_CHAR(m2Row.KEN_NM_KANJI_MOJI_SU,'FM09'),
                          TO_CHAR(m2Row.SHIKU_NM_KANJI_MOJI_SU,'FM09'),
                          TO_CHAR(m2Row.OAZA_NM_KANJI_MOJI_SU,'FM09'),
                          m2Row.TEL,
                          TO_CHAR(m2Row.SHI_BED_SU,'FM0009'),
                          m2Row.KEIEITAI_CD,
                          m2Row.SHI_KBN_CD,
                          m2Row.BYOIN_SBT_CD,
                          m2Row.KANREN_DAIGAKU_OYA_REC_ID,
                          m2Row.KANREN_DAIGAKU_OYA_SHI_CD,
                          m2Row.JUSHOFUMEI_CD,
                          m2Row.KYUIN_FLG,
                          m2Row.DEL_YOTEI_RIYU_CD,
                          m2Row.KAIGYO_YOTEI_FLG,
                          m2Row.BYOTO_HEISA_KBN,
                          m2Row.TEL_NASHI_FLG,
                          m2Row.MIKAKUNIN_FLG,
                          m2Row.SAISHINSA_KBN_CD,
                          CASE
                            WHEN NVL(m2Row.KAIGYO_YOTEI_FLG,'0') = '1' THEN SUBSTR(m2Row.KAIGYO_YOTEI_YM,1,4)
                            WHEN NVL(m2Row.KYUIN_FLG,'0') = '1' THEN SUBSTR(m2Row.KYUIN_S_YM,1,4)
                            ELSE NULL
                          END,
                          CASE
                            WHEN NVL(m2Row.KAIGYO_YOTEI_FLG,'0') = '1' THEN SUBSTR(m2Row.KAIGYO_YOTEI_YM,5,2)
                            WHEN NVL(m2Row.KYUIN_FLG,'0') = '1' THEN SUBSTR(m2Row.KYUIN_S_YM,5,2)
                            ELSE NULL
                          END, 
                          SUBSTR(m2Row.BED_SU_KKNN_EIGY_YMD,1,4),                     
                          SUBSTR(m2Row.BED_SU_KKNN_EIGY_YMD,5,2),
                          SUBSTR(m2Row.BED_SU_KKNN_EIGY_YMD,7,2),
                          TO_CHAR(m2Row.KYOKA_BED_SU_SONOTA,'FM0009'),
                          TO_CHAR(m2Row.KYOKA_BED_SU_SEISHIN,'FM0009'),
                          TO_CHAR(m2Row.KYOKA_BED_SU_KEKKAKU,'FM0009'),
                          TO_CHAR(m2Row.KYOKA_BED_SU_KANSEN,'FM0009'),
                          TO_CHAR(m2Row.KYOKA_BED_SU_GOKEI,'FM0009'),
                          m2Row.KENSAKOMOKU_BISEIBUTSU_FLG,
                          m2Row.KENSAKOMOKU_KESSEI_FLG,
                          m2Row.KENSAKOMOKU_KETSUEKI_FLG,
                          m2Row.KENSAKOMOKU_BYORI_FLG,
                          m2Row.KENSAKOMOKU_KISEICHU_FLG,
                          m2Row.KENSAKOMOKU_SEIKA_FLG,
                          m2Row.KENSAKOMOKU_RI_FLG,
                          m2Row.SNRYKMK_CD_01,
                          m2Row.SNRYKMK_CD_02,
                          m2Row.SNRYKMK_CD_03,
                          m2Row.SNRYKMK_CD_04,
                          m2Row.SNRYKMK_CD_05,
                          m2Row.SNRYKMK_CD_06,
                          m2Row.SNRYKMK_CD_07,
                          m2Row.SNRYKMK_CD_08,
                          m2Row.SNRYKMK_CD_09,
                          m2Row.SNRYKMK_CD_10,
                          m2Row.SNRYKMK_CD_11,
                          m2Row.SNRYKMK_CD_12,
                          m2Row.SNRYKMK_CD_13,
                          m2Row.SNRYKMK_CD_14,
                          m2Row.SNRYKMK_CD_15,
                          m2Row.SNRYKMK_CD_16,
                          m2Row.SNRYKMK_CD_17,
                          m2Row.SNRYKMK_CD_18,
                          m2Row.SNRYKMK_CD_19,
                          m2Row.SNRYKMK_CD_20,
                          m2Row.SNRYKMK_CD_21,
                          m2Row.SNRYKMK_CD_22,
                          m2Row.SNRYKMK_CD_23,
                          m2Row.SNRYKMK_CD_24,
                          m2Row.SNRYKMK_CD_25,
                          m2Row.SNRYKMK_CD_26,
                          m2Row.SNRYKMK_CD_27,
                          m2Row.SNRYKMK_CD_28,
                          m2Row.SNRYKMK_CD_29,
                          m2Row.SNRYKMK_CD_30,
                          m2Row.SNRYKMK_CD_31,
                          m2Row.SNRYKMK_CD_32,
                          m2Row.SNRYKMK_CD_33,
                          m2Row.SNRYKMK_CD_34,
                          m2Row.SNRYKMK_CD_35,
                          m2Row.SNRYKMK_CD_36,
                          m2Row.SNRYKMK_CD_37,
                          m2Row.SNRYKMK_CD_38,
                          m2Row.SNRYKMK_CD_39,
                          m2Row.SNRYKMK_CD_40,
                          m2Row.SEISHIKI_SHI_NM30,
                          m2Row.SHI_RN,
                          m2Row.JUSHO_KANJI_RENKETSU,
                          m2Row.DAIHYO_REC_ID,
                          m2Row.DAIHYO_KJN_CD,
                          m2Row.KJN_NM_KANA,
                          m2Row.KJN_NM,
                          TO_CHAR(m2Row.KYOKA_BED_SU_IPPAN,'FM0009'),
                          TO_CHAR(m2Row.KYOKA_BED_SU_RYOYO,'FM0009'),
                          m2Row.CHOFUKU_AITSK_REC_ID,
                          m2Row.CHOFUKU_AITSK_SHI_CD,
                          SUBSTR(m2Row.UPD_EIGY_YMD,1,4),
                          SUBSTR(m2Row.UPD_EIGY_YMD,5,2),
                          SUBSTR(m2Row.UPD_EIGY_YMD,7,2),
                          vMODKBN,
                          iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID                     
                     );
                      EXECUTE_SQL := 'INSERT INTO TD_P2_DCF_SHI(';
                   END IF;
                   EXECUTE_SQL := EXECUTE_SQL||'
                          SHIREC_ID,
                          SHI_CD,
                          SEISHIKI_SHI_NM_KANA,
                          RYKSK_SHI_NM_KANA,
                          JUSHO_CD_KEN_CD,
                          JUSHO_CD_SHIKU_CD,
                          JUSHO_CD_OAZA_CD,
                          JUSHO_CD_AZA_CD,
                          ZIP,
                          JUSHO_HYOJI_NO,
                          JUSHO_KANA,
                          JUSHO_COUNT_KANA_KEN,
                          JUSHO_COUNT_KANA_SHIKU,
                          JUSHO_COUNT_KANA_OAZA,
                          JUSHO_COUNT_KANJI_KEN,
                          JUSHO_COUNT_KANJI_SHIKU,
                          JUSHO_COUNT_KANJI_OAZA,
                          SHI_TEL,
                          BED_SU_TEIIN,
                          KEIEITAI,
                          SHI_KBN,
                          BYOIN_SBT,
                          KANREN_DAIGAKU_OYA_SHIREC_ID,
                          KANREN_DAIGAKU_OYA_SHI_CD,
                          STATUS_JUSHOFUMEI,
                          STATUS_KYUIN_FLG,
                          STATUS_DEL_YOTEI_RIYU,
                          STATUS_KAIGYO_YOTEI_FLG,
                          STATUS_BYOTO_HEISA_FLG,
                          STATUS_TEL_NASHI_FLG,
                          STATUS_MIKAKUNIN_FLG,
                          STATUS_SAISHINSA_KBN,
                          KYUIN_S_KAIGYO_YOTEI_Y,
                          KYUIN_S_KAIGYO_YOTEI_M,
                          KYOKA_BED_MENTE_HIZUKE_Y,
                          KYOKA_BED_MENTE_HIZUKE_M,
                          KYOKA_BED_MENTE_HIZUKE_D,
                          KYOKA_BED_SU_SONOTA,
                          KYOKA_BED_SU_SEISHIN,
                          KYOKA_BED_SU_KEKKAKU,
                          KYOKA_BED_SU_KANSEN,
                          KYOKA_BED_SU_GOKEI,
                          KENSAKOMOKU_BISEIBUTSU,
                          KENSAKOMOKU_KESSEI,
                          KENSAKOMOKU_KETSUEKI,
                          KENSAKOMOKU_BYORI,
                          KENSAKOMOKU_KISEICHU,
                          KENSAKOMOKU_SEIKA,
                          KENSAKOMOKU_RI,
                          SNRYKMK_1,
                          SNRYKMK_2,
                          SNRYKMK_3,
                          SNRYKMK_4,
                          SNRYKMK_5,
                          SNRYKMK_6,
                          SNRYKMK_7,
                          SNRYKMK_8,
                          SNRYKMK_9,
                          SNRYKMK_10,
                          SNRYKMK_11,
                          SNRYKMK_12,
                          SNRYKMK_13,
                          SNRYKMK_14,
                          SNRYKMK_15,
                          SNRYKMK_16,
                          SNRYKMK_17,
                          SNRYKMK_18,
                          SNRYKMK_19,
                          SNRYKMK_20,
                          SNRYKMK_21,
                          SNRYKMK_22,
                          SNRYKMK_23,
                          SNRYKMK_24,
                          SNRYKMK_25,
                          SNRYKMK_26,
                          SNRYKMK_27,
                          SNRYKMK_28,
                          SNRYKMK_29,
                          SNRYKMK_30,
                          SNRYKMK_31,
                          SNRYKMK_32,
                          SNRYKMK_33,
                          SNRYKMK_34,
                          SNRYKMK_35,
                          SNRYKMK_36,
                          SNRYKMK_37,
                          SNRYKMK_38,
                          SNRYKMK_39,
                          SNRYKMK_40,
                          SEISHIKI_SHI_NM_KANJI,
                          RYKSK_SHI_NM_KANJI,
                          JUSHO_KANJI,
                          SHI_DAIHYO_KJNREC_ID,
                          SHI_DAIHYO_KJN_CD,
                          SHI_DAIHYO_KANA,
                          SHI_DAIHYO_KANJI,
                          SHIN_BED_KBN_IPPAN_BED,
                          SHIN_BED_KBN_RYOYO_BED,
                          AITSK_CD_SHIREC_ID,
                          AITSK_CD_SHI_CD,
                          MOD_SHORI_HIZUKE_Y,
                          MOD_SHORI_HIZUKE_M,
                          MOD_SHORI_HIZUKE_D,
                          MOD_KBN,
                          TRK_OPE_CD,TRK_DATE,TRK_PGM_ID,UPD_OPE_CD,UPD_DATE,UPD_PGM_ID
                     ) VALUES(
                        '''||m2Row.REC_ID||''',
                        '''||m2Row.SHI_CD||''',
                        '''||m2Row.SEISHIKI_SHI_NM_KANA40||''',
                        '''||m2Row.SHI_RN_KANA||''',
                        '''||m2Row.KEN_CD||''',
                        '''||m2Row.SHIKU_CD||''',
                        '''||m2Row.OAZA_CD||''',
                        '''||m2Row.AZA_CD||''',
                        '''||CASE WHEN m2Row.ZIP IS NOT NULL THEN SUBSTR(m2Row.ZIP,1,3)||'-'||SUBSTR(m2Row.ZIP,4) ELSE NULL END ||''',
                        '''||m2Row.JUSHO_HYOJI_NO||''',
                        '''||m2Row.JUSHO_KANA_RENKETSU||''',
                        '''||TO_CHAR(m2Row.KEN_NM_KANA_MOJI_SU,'FM09')||''',
                        '''||TO_CHAR(m2Row.SHIKU_NM_KANA_MOJI_SU,'FM09')||''',
                        '''||TO_CHAR(m2Row.OAZA_NM_KANA_MOJI_SU,'FM09')||''',
                        '''||TO_CHAR(m2Row.KEN_NM_KANJI_MOJI_SU,'FM09')||''',
                        '''||TO_CHAR(m2Row.SHIKU_NM_KANJI_MOJI_SU,'FM09')||''',
                        '''||TO_CHAR(m2Row.OAZA_NM_KANJI_MOJI_SU,'FM09')||''',
                        '''||m2Row.TEL||''',
                        '''||TO_CHAR(m2Row.SHI_BED_SU,'FM0009')||''',
                        '''||m2Row.KEIEITAI_CD||''',
                        '''||m2Row.SHI_KBN_CD||''',
                        '''||m2Row.BYOIN_SBT_CD||''',
                        '''||m2Row.KANREN_DAIGAKU_OYA_REC_ID||''',
                        '''||m2Row.KANREN_DAIGAKU_OYA_SHI_CD||''',
                        '''||m2Row.JUSHOFUMEI_CD||''',
                        '''||m2Row.KYUIN_FLG||''',
                        '''||m2Row.DEL_YOTEI_RIYU_CD||''',
                        '''||m2Row.KAIGYO_YOTEI_FLG||''',
                        '''||m2Row.BYOTO_HEISA_KBN||''',
                        '''||m2Row.TEL_NASHI_FLG||''',
                        '''||m2Row.MIKAKUNIN_FLG||''',
                        '''||m2Row.SAISHINSA_KBN_CD||''',
                        '''||CASE
                              WHEN NVL(m2Row.KAIGYO_YOTEI_FLG,'0') = '1' THEN SUBSTR(m2Row.KAIGYO_YOTEI_YM,1,4)
                              WHEN NVL(m2Row.KYUIN_FLG,'0') = '1' THEN SUBSTR(m2Row.KYUIN_S_YM,1,4)
                              ELSE NULL
                             END||''',
                        '''||CASE
                              WHEN NVL(m2Row.KAIGYO_YOTEI_FLG,'0') = '1' THEN SUBSTR(m2Row.KAIGYO_YOTEI_YM,5,2)
                              WHEN NVL(m2Row.KYUIN_FLG,'0') = '1' THEN SUBSTR(m2Row.KYUIN_S_YM,5,2)
                             ELSE NULL
                             END||''', 
                        '''||SUBSTR(m2Row.BED_SU_KKNN_EIGY_YMD,1,4)||''',                     
                        '''||SUBSTR(m2Row.BED_SU_KKNN_EIGY_YMD,5,2)||''',
                        '''||SUBSTR(m2Row.BED_SU_KKNN_EIGY_YMD,7,2)||''',
                        '''||TO_CHAR(m2Row.KYOKA_BED_SU_SONOTA,'FM0009')||''',
                        '''||TO_CHAR(m2Row.KYOKA_BED_SU_SEISHIN,'FM0009')||''',
                        '''||TO_CHAR(m2Row.KYOKA_BED_SU_KEKKAKU,'FM0009')||''',
                        '''||TO_CHAR(m2Row.KYOKA_BED_SU_KANSEN,'FM0009')||''',
                        '''||TO_CHAR(m2Row.KYOKA_BED_SU_GOKEI,'FM0009')||''',
                        '''||m2Row.KENSAKOMOKU_BISEIBUTSU_FLG||''',
                        '''||m2Row.KENSAKOMOKU_KESSEI_FLG||''',
                        '''||m2Row.KENSAKOMOKU_KETSUEKI_FLG||''',
                        '''||m2Row.KENSAKOMOKU_BYORI_FLG||''',
                        '''||m2Row.KENSAKOMOKU_KISEICHU_FLG||''',
                        '''||m2Row.KENSAKOMOKU_SEIKA_FLG||''',
                        '''||m2Row.KENSAKOMOKU_RI_FLG||''',
                        '''||m2Row.SNRYKMK_CD_01||''',
                        '''||m2Row.SNRYKMK_CD_02||''',
                        '''||m2Row.SNRYKMK_CD_03||''',
                        '''||m2Row.SNRYKMK_CD_04||''',
                        '''||m2Row.SNRYKMK_CD_05||''',
                        '''||m2Row.SNRYKMK_CD_06||''',
                        '''||m2Row.SNRYKMK_CD_07||''',
                        '''||m2Row.SNRYKMK_CD_08||''',
                        '''||m2Row.SNRYKMK_CD_09||''',
                        '''||m2Row.SNRYKMK_CD_10||''',
                        '''||m2Row.SNRYKMK_CD_11||''',
                        '''||m2Row.SNRYKMK_CD_12||''',
                        '''||m2Row.SNRYKMK_CD_13||''',
                        '''||m2Row.SNRYKMK_CD_14||''',
                        '''||m2Row.SNRYKMK_CD_15||''',
                        '''||m2Row.SNRYKMK_CD_16||''',
                        '''||m2Row.SNRYKMK_CD_17||''',
                        '''||m2Row.SNRYKMK_CD_18||''',
                        '''||m2Row.SNRYKMK_CD_19||''',
                        '''||m2Row.SNRYKMK_CD_20||''',
                        '''||m2Row.SNRYKMK_CD_21||''',
                        '''||m2Row.SNRYKMK_CD_22||''',
                        '''||m2Row.SNRYKMK_CD_23||''',
                        '''||m2Row.SNRYKMK_CD_24||''',
                        '''||m2Row.SNRYKMK_CD_25||''',
                        '''||m2Row.SNRYKMK_CD_26||''',
                        '''||m2Row.SNRYKMK_CD_27||''',
                        '''||m2Row.SNRYKMK_CD_28||''',
                        '''||m2Row.SNRYKMK_CD_29||''',
                        '''||m2Row.SNRYKMK_CD_30||''',
                        '''||m2Row.SNRYKMK_CD_31||''',
                        '''||m2Row.SNRYKMK_CD_32||''',
                        '''||m2Row.SNRYKMK_CD_33||''',
                        '''||m2Row.SNRYKMK_CD_34||''',
                        '''||m2Row.SNRYKMK_CD_35||''',
                        '''||m2Row.SNRYKMK_CD_36||''',
                        '''||m2Row.SNRYKMK_CD_37||''',
                        '''||m2Row.SNRYKMK_CD_38||''',
                        '''||m2Row.SNRYKMK_CD_39||''',
                        '''||m2Row.SNRYKMK_CD_40||''',
                        '''||m2Row.SEISHIKI_SHI_NM30||''',
                        '''||m2Row.SHI_RN||''',
                        '''||m2Row.JUSHO_KANJI_RENKETSU||''',
                        '''||m2Row.DAIHYO_REC_ID||''',
                        '''||m2Row.DAIHYO_KJN_CD||''',
                        '''||m2Row.KJN_NM_KANA||''',
                        '''||m2Row.KJN_NM||''',
                        '''||TO_CHAR(m2Row.KYOKA_BED_SU_IPPAN,'FM0009')||''',
                        '''||TO_CHAR(m2Row.KYOKA_BED_SU_RYOYO,'FM0009')||''',
                        '''||m2Row.CHOFUKU_AITSK_REC_ID||''',
                        '''||m2Row.CHOFUKU_AITSK_SHI_CD||''',
                        '''||SUBSTR(m2Row.UPD_EIGY_YMD,1,4)||''',
                        '''||SUBSTR(m2Row.UPD_EIGY_YMD,5,2)||''',
                        '''||SUBSTR(m2Row.UPD_EIGY_YMD,7,2)||''',
                        '''||vMODKBN||''',                                       
                        '''||iOPE_CD||''',
                        '''||iDATE||''',
                        '''||iPGM_ID||''',
                        '''||iOPE_CD||''',
                        '''||iDATE||''',
                        '''||iPGM_ID||''')';
                END IF;
                ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);
              END IF;
            
            END LOOP;
            
            IF iM2Flg = ULT_COMMON.FLG_YES THEN  
               CLOSE m1CSR;
            ELSE
               CLOSE m2CSR;   
            END IF;            
          END IF;            
          
      END IF;
      
	   commit;
     
      -- �I�����O�o��
    	ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'PL/SQL End',PGM_ID || '�̏������I�����܂����B',iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);
      
      oROW_COUNT := -1;  
      return 0;
    -- ��O����
	EXCEPTION
		-- ���̑��G���[
		WHEN OTHERS THEN
			W_ERR_INF_RCD.ERR_CD 		:= TO_CHAR(SQLCODE);
			W_ERR_INF_RCD.ERR_MSG 		:= SUBSTR(SQLERRM, 0, 500);
			W_ERR_INF_RCD.ERR_KEY_INF 	:= SUBSTR('iLayoutKind:' || iLayoutKind || ', iShimeKind:' || iShimeKind , 0,500);
			W_INDEX_N 					:= W_ERR_INF_TBL.COUNT + 1;
			W_ERR_INF_TBL.EXTEND;
			W_ERR_INF_TBL(W_INDEX_N) 	:= W_ERR_INF_RCD;

			OPEN oOUT_ERR_INF_CSR FOR
				SELECT * FROM TABLE(W_ERR_INF_TBL);
      ROLLBACK;
      
       --�G���[���O�̓o�^
      ULT_INSERT_LOG_TABLE('ERROR',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'ERROR_INFO',W_ERR_INF_RCD.ERR_MSG,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

			raise;
END;

END;
/
