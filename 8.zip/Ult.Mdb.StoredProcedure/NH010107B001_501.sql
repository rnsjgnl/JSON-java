CREATE OR REPLACE PACKAGE NH010107B001_501
/* **********************************************************
 *  Copyright(c) 2011 beyond, INTEC Inc. All rights reserved.
 * **********************************************************/
AUTHID CURRENT_USER
IS
	/*** �J�[�\���^ ***************************************************************/
	-- �G���[���i�[�p�J�[�\���^
	TYPE ERR_INF_CSR		IS REF CURSOR;
  --�ҏW��`�z��(��W��)�̌^
  TYPE EditInfoArray IS TABLE OF NUMBER;
   --�ҏW��`�z��(�W��)�̌^
  TYPE EditInfoArrayArray is table of EditInfoArray;
  /*
	************************************************************************
	*  �ҏW���̔z��ɂ���āA����f�[�^�ƑO��f�[�^�������ꍇ�A
  *  ����f�[�^�̔z��Ɏw�肳�ꂽ�l��ݒ肷��
  *  ChangeToNull
  ************************************************************************
  */
  PROCEDURE ChangeToNull(
     array1 IN OUT ULT_COMMON.VarcharArray,     --����f�[�^
     array2 IN ULT_COMMON.VarcharArray,         --�O��f�[�^
     editArray IN EditInfoArray             --�ҏW���̔z��
  );
  /*
  ************************************************************************
  *  �ҏW���̔z��ɂ���āA����f�[�^�ƑO��f�[�^�������ꍇ�A
  *  ����f�[�^�̔z��Ɏw�肳�ꂽ�l��ݒ肷��
  *  ChangeToDefault
  ************************************************************************
  */
  PROCEDURE ChangeToDefault(
     array1 IN OUT ULT_COMMON.VarcharArray,     --����f�[�^
     array2 IN ULT_COMMON.VarcharArray,         --�O��f�[�^
     editArray IN EditInfoArray             --�ҏW���̔z��
  );
 /*
  ************************************************************************
  *  �ҏW����2�����z��ɂ���āA����f�[�^�ƑO��f�[�^�������ꍇ�A
  *  ����f�[�^�̔z��ɏ����l��ݒ肷��
  *  ChangeToNullForArray
  ************************************************************************
  */
  PROCEDURE ChangeToNullForArray(
     array1 IN OUT ULT_COMMON.VarcharArray,     --����f�[�^
     array2 IN ULT_COMMON.VarcharArray,         --�O��f�[�^
     editArray IN EditInfoArrayArray        --�ҏW����2�����z��
  );
 /*
  ************************************************************************
  *  �ҏW����2�����z��ɂ���āA����f�[�^�ƑO��f�[�^�������ꍇ�A
  *  ����f�[�^�̔z��ɏ����l��ݒ肷��
  *  ChangeToDefaultForArray
  ************************************************************************
  */
  PROCEDURE ChangeToDefaultForArray(
     array1 IN OUT ULT_COMMON.VarcharArray,     --����f�[�^
     array2 IN ULT_COMMON.VarcharArray,         --�O��f�[�^
     editArray IN EditInfoArrayArray        --�ҏW����2�����z��
  );
  /*
  ************************************************************************
  *  DCF��t�f��DB�f�[�^�̍쐬
  *  CREATE_DCF_SHISETSU
  ************************************************************************
  */
  FUNCTION CREATE_DCF_ISHI_SABUN(
  iLayoutKind  IN  VARCHAR2,                    -- ���C�A�E�g�敪
  iShimeKind  IN  VARCHAR2,                    -- ���ߓ��敪
  iShimeFrom  IN  VARCHAR2,                    -- ���ߔ͈́iFrom�j
  iShimeTo  IN  VARCHAR2,                    -- ���ߔ͈́iTo�j
  iTensoYMD  IN  VARCHAR2,                    -- �]���N����
  iM2Flg IN  VARCHAR2,                        -- ���Q���߃t���O
  iIP_ADDR  IN TL_STORED_SHORI.IP%TYPE,              -- ���s�[��IP�A�h���X (FW�Őݒ�)
  iWINDOWS_LOGIN_USER  IN TL_STORED_SHORI.WINDOWS_LOGIN_USER%TYPE, -- ���s�[��OS���[�U�[ (FW�Őݒ�)
  oROW_COUNT  OUT NUMBER,         -- �o�^����
  oOUT_ERR_INF_CSR   OUT ERR_INF_CSR,    -- �G���[���J�[�\��
  iOPE_CD IN Varchar2,                      -- �I�y���[�^�R�[�h
  iPGM_ID IN Varchar2,                      -- �v���O����ID
  iDATE DATE                              -- �V�X�e������
  ) RETURN NUMBER;


END;
/
CREATE OR REPLACE PACKAGE BODY NH010107B001_501
/* **********************************************************
 *  Copyright(c) 2011 beyond, INTEC Inc. All rights reserved.
 * **********************************************************/
IS
/*
   ************************************************************************
   * Function ID  : ChangeToNull
   * Program Name : �ҏW���̔z��ɂ���āA����f�[�^�ƑO��f�[�^�������ꍇ�A
   *                ����f�[�^�̔z���NULL��ݒ肷��
   * Parameter    :  <IO> array1    �F����f�[�^
   *                 <I> array2    �F�O��f�[�^
   *                 <I> editArray    �F�ҏW���
   ************************************************************************
   */
  PROCEDURE ChangeToNull(
     array1 IN OUT ULT_COMMON.VarcharArray,     --����f�[�^
     array2 IN ULT_COMMON.VarcharArray,         --�O��f�[�^
     editArray IN EditInfoArray             --�ҏW���̔z��
  ) IS
  BEGIN
    FOR i in 1..editArray.COUNT LOOP
      IF array1(editArray(i)) = array2(editArray(i)) THEN
        array1(editArray(i)) := NULL;
      END IF;
    END LOOP;
  END;
 /*
   ************************************************************************
   * Function ID  : ChangeToDefault
   * Program Name : �ҏW���̔z��ɂ���āA����f�[�^�ƑO��f�[�^�������ꍇ�A
   *                ����f�[�^�̔z��ɏ����l��ݒ肷��
   * Parameter    :  <IO> array1    �F����f�[�^
   *                 <I> array2    �F�O��f�[�^
   *                 <I> editArray    �F�ҏW���̔z��
   ************************************************************************
   */
  PROCEDURE ChangeToDefault(
     array1 IN OUT ULT_COMMON.VarcharArray,     --����f�[�^
     array2 IN ULT_COMMON.VarcharArray,         --�O��f�[�^
     editArray IN EditInfoArray             --�ҏW���
  ) IS
  BEGIN
    FOR i in 1..editArray.COUNT LOOP
      IF '1'||array1(editArray(i)) = '1'||array2(editArray(i)) THEN
        array1(editArray(i)) := NULL;
      ELSIF array1(editArray(i)) IS NULL AND array2(editArray(i)) IS NOT NULL THEN
        array1(editArray(i)) := ULT_COMMON.INSERT_HALF_DEFAULT;
      END IF;
    END LOOP;
  END;
/*
   ************************************************************************
   * Function ID  : ChangeToNullForArray
   * Program Name : �ҏW���̂Q�����z��ɂ���āA����f�[�^�ƑO��f�[�^�������ꍇ�A
   *                ����f�[�^�̔z���NULL��ݒ肷��
   * Parameter    :  <I> array1    �F����f�[�^
   *                 <I> array2    �F�O��f�[�^
   *                 <I> editArray    �F�ҏW���
   ************************************************************************
   */
  PROCEDURE ChangeToNullForArray(
     array1 IN OUT ULT_COMMON.VarcharArray,     --����f�[�^
     array2 IN ULT_COMMON.VarcharArray,         --�O��f�[�^
     editArray IN EditInfoArrayArray             --�ҏW���
  ) IS
  ret int:=0;
  BEGIN
    FOR i in 1..editArray.COUNT LOOP
      ret := 0;
      FOR j IN 1..editArray(i).COUNT LOOP
        IF NVL(array1(editArray(i)(j)),0) != NVL(array2(editArray(i)(j)),0) THEN
          ret := 1;
          EXIT;
        END IF;
      END LOOP;
      IF ret = 0 THEN
        FOR j IN 1..editArray(i).COUNT LOOP
           array1(editArray(i)(j)):=NULL;
        END LOOP;
      END IF;
    END LOOP;
  END;
  /*
   ************************************************************************
   * Function ID  : ChangeToDefaultForArray
   * Program Name : �ҏW���̂Q�����z��ɂ���āA����f�[�^�ƑO��f�[�^�������ꍇ�A
   *                ����f�[�^�̔z���NULL��ݒ肷��
   * Parameter    :  <I> array1    �F����f�[�^
   *                 <I> array2    �F�O��f�[�^
   *                 <I> editArray    �F�ҏW���
   ************************************************************************
   */
  PROCEDURE ChangeToDefaultForArray(
     array1 IN OUT ULT_COMMON.VarcharArray,     --����f�[�^
     array2 IN ULT_COMMON.VarcharArray,         --�O��f�[�^
     editArray IN EditInfoArrayArray             --�ҏW���
  ) IS
  ret int:=0;
  ncount int:=0;
  BEGIN
    FOR i in 1..editArray.COUNT LOOP
      ret := 0;
      ncount:=0;
      FOR j IN 1..editArray(i).COUNT LOOP
        IF NVL(array1(editArray(i)(j)),0) != NVL(array2(editArray(i)(j)),0) THEN
          ret := 1;
          EXIT;
        END IF;
      END LOOP;
      IF ret = 0 THEN
        FOR j IN 1..editArray(i).COUNT LOOP
           array1(editArray(i)(j)):=NULL;
        END LOOP;
      ELSE
        FOR j IN 1..editArray(i).COUNT LOOP
          IF array1(editArray(i)(j)) IS NULL THEN
            ncount:=ncount + 1;
          END IF;
        END LOOP;
        IF ncount = editArray(i).COUNT THEN
          array1(editArray(i)(1)):=ULT_COMMON.INSERT_HALF_DEFAULT;
        END IF;
      END IF;
    END LOOP;
  END;
  /*
   ************************************************************************
   * Function ID  : CREATE_DCF_ISHI_SABUN
   * Program Name : DCF��t�f��DB�f�[�^�̍쐬
   * Parameter    :  <I> iLayoutKind    �F���C�A�E�g�敪
   *                 <I> iShimeKind    �F���ߓ��敪
   *                 <I> iShimeFrom    �F���ߔ͈�(From)
   *                 <I> iShimeTo    �F���ߔ͈�(To)
   *                 <I> iTensoYMD    �F�]���N����
   *                 <I> iM2Flg      �F���Q���߃t���O
   *                 <I> iIP_ADDR    �F���s�[��IP�A�h���X
   *                 <I> iWINDOWS_LOGIN_USER  �F���s�[��IP�A�h���X
   *                <O> oROW_COUNT        �F�X�V����
   *                <O> oOUT_ERR_INF_CSR  �F�G���[���J�[�\��
   *                 <I> iOPE_CD    �F�I�y���[�^�R�[�h
   *                 <I> iPGM_ID    �F�v���O����ID
   *                 <I> iDATE    �F�V�X�e������
   * Return       �F��������(0:����I���A1:�ُ�I��)
   ************************************************************************
   */
  FUNCTION CREATE_DCF_ISHI_SABUN(
  iLayoutKind  IN  VARCHAR2,                    -- ���C�A�E�g�敪
  iShimeKind  IN  VARCHAR2,                    -- ���ߓ��敪
  iShimeFrom  IN  VARCHAR2,                 -- ���ߔ͈�(From)
  iShimeTo  IN  VARCHAR2,                    -- ���ߔ͈�(To)
  iTensoYMD  IN  VARCHAR2,                    -- �]���N����
  iM2Flg IN  VARCHAR2,                        -- ���Q���߃t���O
  iIP_ADDR  IN TL_STORED_SHORI.IP%TYPE,              -- ���s�[��IP�A�h���X (FW�Őݒ�)
  iWINDOWS_LOGIN_USER  IN TL_STORED_SHORI.WINDOWS_LOGIN_USER%TYPE, -- ���s�[��OS���[�U�[ (FW�Őݒ�)
  oROW_COUNT  OUT NUMBER,         -- �o�^����
  oOUT_ERR_INF_CSR   OUT ERR_INF_CSR,    -- �G���[���J�[�\��
  iOPE_CD IN Varchar2,                      -- �I�y���[�^�R�[�h
  iPGM_ID IN Varchar2,                      -- �v���O����ID
  iDATE DATE                            -- �V�X�e������
  )RETURN NUMBER IS

  PRAGMA AUTONOMOUS_TRANSACTION;
  /************************************************************************/
  /*                              �G���[����                              */
  /************************************************************************/
  W_INDEX_N           NUMBER(10) := 0;
  W_ERR_INF_TBL         TYPE_ERR_INFO_TBL := TYPE_ERR_INFO_TBL();
  W_ERR_INF_RCD         TYPE_ERR_INFO_RCD := TYPE_ERR_INFO_RCD(NULL,NULL,NULL,NULL);
  
  nKINMUSAKI_REC_CNT NUMBER := 0;	-- �Ζ���̌������J�E���g����i�ސE�ς݂������j

  -- �b��_�T����_DCF��t�̔�r�p�f�[�^�𒊏o����J�[�\��
  CURSOR weekDcfCSR  IS
    SELECT
        A.REC_ID||ULT_COMMON.DELIMITER||
        A.KJN_CD||ULT_COMMON.DELIMITER||
        A.KJN_NM_KANA||ULT_COMMON.DELIMITER||
        A.KJN_NM||ULT_COMMON.DELIMITER||
        A.SEIBETSU_KBN||ULT_COMMON.DELIMITER||
        A.BIRTH_GENGO_CD||ULT_COMMON.DELIMITER||
        A.BIRTH_WY||ULT_COMMON.DELIMITER||
        A.BIRTH_M||ULT_COMMON.DELIMITER||
        A.BIRTH_D||ULT_COMMON.DELIMITER||
        A.SHUSSHINCHI_RIDAI_CD||ULT_COMMON.DELIMITER||
        A.KANYU_ISHIKAI_RIDAI_CD||ULT_COMMON.DELIMITER||
        A.STNEN_GENGO_CD||ULT_COMMON.DELIMITER||
        A.STNEN_WY||ULT_COMMON.DELIMITER||
        A.SHUSSHINKO_CD||ULT_COMMON.DELIMITER||
        A.GAKUBU_SHIKIBETSU_KBN||ULT_COMMON.DELIMITER||
        A.KAIKIN_KBN||ULT_COMMON.DELIMITER||
        A.KAIGYONEN_GENGO_CD||ULT_COMMON.DELIMITER||
        A.KAIGYONEN_WY||ULT_COMMON.DELIMITER||
        A.SNRYKMK_CD_1||ULT_COMMON.DELIMITER||
        A.SNRYKMK_CD_2||ULT_COMMON.DELIMITER||
        A.SNRYKMK_CD_3||ULT_COMMON.DELIMITER||
        A.SNRYKMK_CD_4||ULT_COMMON.DELIMITER||
        A.SNRYKMK_CD_5||ULT_COMMON.DELIMITER||
        A.TEL||ULT_COMMON.DELIMITER||
        A.JUSHOFUMEI_CD||ULT_COMMON.DELIMITER||
        A.DEL_YOTEI_RIYU_CD||ULT_COMMON.DELIMITER||
        A.IKKATSU_TRK_FLG||ULT_COMMON.DELIMITER||
        A.CHOFUKU_AITSK_REC_ID||ULT_COMMON.DELIMITER||
        A.CHOFUKU_AITSK_KJN_CD||ULT_COMMON.DELIMITER||
        A.TRKNEN_GENGO_CD||ULT_COMMON.DELIMITER||
        A.TRKNEN_WY||ULT_COMMON.DELIMITER||
        A.JUSHO_KANA_RENKETSU||ULT_COMMON.DELIMITER||
        A.JUSHO_KANJI_RENKETSU||ULT_COMMON.DELIMITER||
        A.KEN_CD||ULT_COMMON.DELIMITER||
        A.SHIKU_CD||ULT_COMMON.DELIMITER||
        A.OAZA_CD||ULT_COMMON.DELIMITER||
        A.AZA_CD||ULT_COMMON.DELIMITER||
        A.ZIP||ULT_COMMON.DELIMITER||
        A.JUSHO_HYOJI_NO||ULT_COMMON.DELIMITER||
        A.KEN_NM_KANA_MOJI_SU||ULT_COMMON.DELIMITER||
        A.SHIKU_NM_KANA_MOJI_SU||ULT_COMMON.DELIMITER||
        A.OAZA_NM_KANA_MOJI_SU||ULT_COMMON.DELIMITER||
        A.KEN_NM_KANJI_MOJI_SU||ULT_COMMON.DELIMITER||
        A.SHIKU_NM_KANJI_MOJI_SU||ULT_COMMON.DELIMITER||
        A.OAZA_NM_KANJI_MOJI_SU||ULT_COMMON.DELIMITER||
        A.AZA_NM_KANA_MOJI_SU||ULT_COMMON.DELIMITER||
        A.AZA_NM_KANJI_MOJI_SU||ULT_COMMON.DELIMITER||
        B.KINMUSAKI_REC_ID||ULT_COMMON.DELIMITER||
        B.KINMUSAKI_SHI_CD||ULT_COMMON.DELIMITER||
        B.YAKUSHOKU_CD||ULT_COMMON.DELIMITER||
        B.SHOKUI_CD||ULT_COMMON.DELIMITER||
        B.KINMUSAKI_DM_FUKA_FLG||ULT_COMMON.DELIMITER||
        B.TAISHOKU_FLG AS FIELD1,
        E.REC_ID||ULT_COMMON.DELIMITER||
        E.KJN_CD||ULT_COMMON.DELIMITER||
        E.KJN_NM_KANA||ULT_COMMON.DELIMITER||
        E.KJN_NM||ULT_COMMON.DELIMITER||
        E.SEIBETSU_KBN||ULT_COMMON.DELIMITER||
        E.BIRTH_GENGO_CD||ULT_COMMON.DELIMITER||
        E.BIRTH_WY||ULT_COMMON.DELIMITER||
        E.BIRTH_M||ULT_COMMON.DELIMITER||
        E.BIRTH_D||ULT_COMMON.DELIMITER||
        E.SHUSSHINCHI_RIDAI_CD||ULT_COMMON.DELIMITER||
        E.KANYU_ISHIKAI_RIDAI_CD||ULT_COMMON.DELIMITER||
        E.STNEN_GENGO_CD||ULT_COMMON.DELIMITER||
        E.STNEN_WY||ULT_COMMON.DELIMITER||
        E.SHUSSHINKO_CD||ULT_COMMON.DELIMITER||
        E.GAKUBU_SHIKIBETSU_KBN||ULT_COMMON.DELIMITER||
        E.KAIKIN_KBN||ULT_COMMON.DELIMITER||
        E.KAIGYONEN_GENGO_CD||ULT_COMMON.DELIMITER||
        E.KAIGYONEN_WY||ULT_COMMON.DELIMITER||
        E.SNRYKMK_CD_1||ULT_COMMON.DELIMITER||
        E.SNRYKMK_CD_2||ULT_COMMON.DELIMITER||
        E.SNRYKMK_CD_3||ULT_COMMON.DELIMITER||
        E.SNRYKMK_CD_4||ULT_COMMON.DELIMITER||
        E.SNRYKMK_CD_5||ULT_COMMON.DELIMITER||
        E.TEL||ULT_COMMON.DELIMITER||
        E.JUSHOFUMEI_CD||ULT_COMMON.DELIMITER||
        E.DEL_YOTEI_RIYU_CD||ULT_COMMON.DELIMITER||
        E.IKKATSU_TRK_FLG||ULT_COMMON.DELIMITER||
        E.CHOFUKU_AITSK_REC_ID||ULT_COMMON.DELIMITER||
        E.CHOFUKU_AITSK_KJN_CD||ULT_COMMON.DELIMITER||
        E.TRKNEN_GENGO_CD||ULT_COMMON.DELIMITER||
        E.TRKNEN_WY||ULT_COMMON.DELIMITER||
        E.JUSHO_KANA_RENKETSU||ULT_COMMON.DELIMITER||
        E.JUSHO_KANJI_RENKETSU||ULT_COMMON.DELIMITER||
        E.KEN_CD||ULT_COMMON.DELIMITER||
        E.SHIKU_CD||ULT_COMMON.DELIMITER||
        E.OAZA_CD||ULT_COMMON.DELIMITER||
        E.AZA_CD||ULT_COMMON.DELIMITER||
        E.ZIP||ULT_COMMON.DELIMITER||
        E.JUSHO_HYOJI_NO||ULT_COMMON.DELIMITER||
        E.KEN_NM_KANA_MOJI_SU||ULT_COMMON.DELIMITER||
        E.SHIKU_NM_KANA_MOJI_SU||ULT_COMMON.DELIMITER||
        E.OAZA_NM_KANA_MOJI_SU||ULT_COMMON.DELIMITER||
        E.KEN_NM_KANJI_MOJI_SU||ULT_COMMON.DELIMITER||
        E.SHIKU_NM_KANJI_MOJI_SU||ULT_COMMON.DELIMITER||
        E.OAZA_NM_KANJI_MOJI_SU||ULT_COMMON.DELIMITER||
        E.AZA_NM_KANA_MOJI_SU||ULT_COMMON.DELIMITER||
        E.AZA_NM_KANJI_MOJI_SU||ULT_COMMON.DELIMITER||
        F.KINMUSAKI_REC_ID||ULT_COMMON.DELIMITER||
        F.KINMUSAKI_SHI_CD||ULT_COMMON.DELIMITER||
        F.YAKUSHOKU_CD||ULT_COMMON.DELIMITER||
        F.SHOKUI_CD||ULT_COMMON.DELIMITER||
        F.KINMUSAKI_DM_FUKA_FLG||ULT_COMMON.DELIMITER||
        F.TAISHOKU_FLG AS FIELD2,
        A.DEL_FLG AS DEL_FLG,
        B.SZKBUKA_CD AS SZKBUKA_CD1,
        DECODE(B.SZKBUKA_CD, '9999', B.NYURYOKU_SZKBUKA_NM_KANA, SUBSTR(D.SZKBUKA_NM_KANA, 1, 20)) AS SZKBUKA_NM_KANA1,
        DECODE(B.SZKBUKA_CD, '9999', B.NYURYOKU_SZKBUKA_NM, SUBSTR(D.SZKBUKA_NM, 1, 15)) AS SZKBUKA_NM1,
        F.SZKBUKA_CD AS SZKBUKA_CD2,
        DECODE(F.SZKBUKA_CD, '9999', F.NYURYOKU_SZKBUKA_NM_KANA, SUBSTR(H.SZKBUKA_NM_KANA, 1, 20)) AS SZKBUKA_NM_KANA2,
        DECODE(F.SZKBUKA_CD, '9999', F.NYURYOKU_SZKBUKA_NM, SUBSTR(H.SZKBUKA_NM, 1, 15)) AS SZKBUKA_NM2,
        X.MAX_UPD_EIGY_YMD AS UPD_EIGY_YMD
      FROM TT_TIKY_KJN A
      LEFT OUTER JOIN TT_TIKY_KJN_KINMUSAKI B
        ON A.REC_ID = B.REC_ID
        AND A.KJN_CD = B.KJN_CD
      LEFT OUTER JOIN TM_TIKY_HIFG_SSY_SZKBUKA D
        ON B.SZKBUKA_CD = D.SZKBUKA_CD
      LEFT OUTER JOIN TT_Z_W_KJN E
        ON A.REC_ID = E.REC_ID
        AND A.KJN_CD = E.KJN_CD
      LEFT OUTER JOIN TT_Z_W_KJN_KINMUSAKI F
        ON A.REC_ID = F.REC_ID
        AND A.KJN_CD = F.KJN_CD
        AND B.KINMUSAKI_REC_ID = F.KINMUSAKI_REC_ID
        AND B.KINMUSAKI_SHI_CD = F.KINMUSAKI_SHI_CD
      LEFT OUTER JOIN TM_Z_W_HIFG_SSY_SZKBUKA H
        ON F.SZKBUKA_CD = H.SZKBUKA_CD
      LEFT OUTER JOIN (
        SELECT Y.KJN_CD,
          MAX(CASE WHEN Y.UPD_EIGY_YMD||'1'>Z.UPD_EIGY_YMD||'1' THEN Y.UPD_EIGY_YMD ELSE Z.UPD_EIGY_YMD END) AS MAX_UPD_EIGY_YMD
        FROM TT_TIKY_KJN Y
        LEFT OUTER JOIN TT_TIKY_KJN_KINMUSAKI Z
          ON Y.REC_ID = Z.REC_ID
         AND Y.KJN_CD = Z.KJN_CD
        WHERE Y.REC_ID = '01'
          AND ((Y.UPD_EIGY_YMD >= NVL(iShimeFrom,ULT_COMMON.ORIGINAL_YMD) AND Y.UPD_EIGY_YMD <= iShimeTo)
           OR (Z.UPD_EIGY_YMD >= NVL(iShimeFrom,ULT_COMMON.ORIGINAL_YMD) AND Z.UPD_EIGY_YMD <= iShimeTo))
        GROUP BY Y.KJN_CD) X
      ON A.KJN_CD = X.KJN_CD
    WHERE A.REC_ID = '01'
      AND ((A.UPD_EIGY_YMD >= NVL(iShimeFrom,ULT_COMMON.ORIGINAL_YMD) AND A.UPD_EIGY_YMD <= iShimeTo)
        OR (B.UPD_EIGY_YMD >= NVL(iShimeFrom,ULT_COMMON.ORIGINAL_YMD) AND B.UPD_EIGY_YMD <= iShimeTo))
      AND (A.DEL_FLG IS NULL OR (E.REC_ID IS NOT NULL AND E.DEL_FLG IS NULL))
    -- 2010/10/03 �\�[�g����ǉ�����
    ORDER BY
    	A.REC_ID,
    	A.KJN_CD,
    	B.KINMUSAKI_REC_ID,
    	B.KINMUSAKI_SHI_CD;
    -- 2010/10/03 �\�[�g����ǉ�����
  weekDcfRow weekDcfCSR%ROWTYPE;  --�b��_�T����_DCF��t���R�[�h

  -- �b��_�T����_���p��~�iDCF��t�j�̔�r�p�f�[�^�𒊏o����J�[�\��
  CURSOR weekTisCSR  IS
    SELECT
      A.REC_ID||ULT_COMMON.DELIMITER||
      A.KJN_CD||ULT_COMMON.DELIMITER||
      A.RIYOTEISHI_KBN_CD||ULT_COMMON.DELIMITER||
      A.RIYOTEISHI_RIYU_CD||ULT_COMMON.DELIMITER||
      A.RIYOTEISHI_TRK_YMD||ULT_COMMON.DELIMITER||
      A.RIYOTEISHI_KAIJO_YMD
      AS FIELD1,
      B.REC_ID||ULT_COMMON.DELIMITER||
      B.KJN_CD||ULT_COMMON.DELIMITER||
      B.RIYOTEISHI_KBN_CD||ULT_COMMON.DELIMITER||
      B.RIYOTEISHI_RIYU_CD||ULT_COMMON.DELIMITER||
      B.RIYOTEISHI_TRK_YMD||ULT_COMMON.DELIMITER||
      B.RIYOTEISHI_KAIJO_YMD
      AS FIELD2,
      A.UPD_EIGY_YMD AS UPD_EIGY_YMD
    FROM TT_TIKY_KJN A
    LEFT OUTER JOIN TT_Z_W_KJN B
    ON A.REC_ID = B.REC_ID
    AND A.KJN_CD = B.KJN_CD
    WHERE A.REC_ID = '01'
      AND A.UPD_EIGY_YMD >= NVL(iShimeFrom,ULT_COMMON.ORIGINAL_YMD) AND A.UPD_EIGY_YMD <= iShimeTo
      AND A.DEL_FLG IS NULL
    -- 2010/10/03 �\�[�g����ǉ�����
    ORDER BY
    	A.REC_ID,
    	A.KJN_CD;
    -- 2010/10/03 �\�[�g����ǉ�����;
  weekTisRow weekTisCSR%ROWTYPE;    --�b��_�T����_���p��~�iDCF��t�j���R�[�h

  -- �b��_�T����_�w�����̔�r�p�f�[�^�𒊏o����J�[�\��
  CURSOR weekSenmoniCSR  IS
    SELECT
      A.REC_ID||ULT_COMMON.DELIMITER||
      A.KJN_CD||ULT_COMMON.DELIMITER||
      B.SENMONI_CD||ULT_COMMON.DELIMITER||
      B.SENMONI_FLG||ULT_COMMON.DELIMITER||
      B.SENMONI_KEISAI_YMD||ULT_COMMON.DELIMITER||
      B.NINTEII_FLG||ULT_COMMON.DELIMITER||
      B.NINTEII_KEISAI_YMD||ULT_COMMON.DELIMITER||
      B.SHIDOI_FLG||ULT_COMMON.DELIMITER||
      B.SHIDOI_KEISAI_YMD||ULT_COMMON.DELIMITER||
      B.SOSHITSU_FLG
      AS FIELD1,
      D.REC_ID||ULT_COMMON.DELIMITER||
      D.KJN_CD||ULT_COMMON.DELIMITER||
      C.SENMONI_CD||ULT_COMMON.DELIMITER||
      C.SENMONI_FLG||ULT_COMMON.DELIMITER||
      C.SENMONI_KEISAI_YMD||ULT_COMMON.DELIMITER||
      C.NINTEII_FLG||ULT_COMMON.DELIMITER||
      C.NINTEII_KEISAI_YMD||ULT_COMMON.DELIMITER||
      C.SHIDOI_FLG||ULT_COMMON.DELIMITER||
      C.SHIDOI_KEISAI_YMD||ULT_COMMON.DELIMITER||
      C.SOSHITSU_FLG
      AS FIELD2,
      X.MAX_UPD_EIGY_YMD AS UPD_EIGY_YMD
    FROM TT_TIKY_KJN A
    LEFT OUTER JOIN TT_TIKY_KJN_SENMONI B
      ON A.REC_ID = B.REC_ID
      AND A.KJN_CD = B.KJN_CD
    LEFT OUTER JOIN TT_Z_W_KJN_SENMONI C
      ON A.REC_ID = C.REC_ID
      AND A.KJN_CD = C.KJN_CD
      AND B.SENMONI_CD = C.SENMONI_CD
    LEFT OUTER JOIN TT_Z_W_KJN D
    ON A.REC_ID = D.REC_ID
    AND A.KJN_CD = D.KJN_CD
    LEFT OUTER JOIN (
      SELECT Y.KJN_CD,
      MAX(CASE WHEN Y.UPD_EIGY_YMD||'1'>Z.UPD_EIGY_YMD||'1' THEN Y.UPD_EIGY_YMD ELSE Z.UPD_EIGY_YMD END) AS MAX_UPD_EIGY_YMD
      FROM TT_TIKY_KJN Y
      -- ������2012/10/16 ST000104�̑Ή�
      -- LEFT OUTER JOIN TT_TIKY_KJN_KINMUSAKI Z
      LEFT OUTER JOIN TT_TIKY_KJN_SENMONI Z
      -- ������2012/10/16 ST000104�̑Ή�
      ON Y.REC_ID = Z.REC_ID
      AND Y.KJN_CD = Z.KJN_CD
      WHERE Y.REC_ID = '01'
          AND ((Y.UPD_EIGY_YMD >= NVL(iShimeFrom,ULT_COMMON.ORIGINAL_YMD) AND Y.UPD_EIGY_YMD <= iShimeTo)
           OR (Z.UPD_EIGY_YMD >= NVL(iShimeFrom,ULT_COMMON.ORIGINAL_YMD) AND Z.UPD_EIGY_YMD <= iShimeTo))
      GROUP BY Y.KJN_CD  ) X
    ON A.KJN_CD = X.KJN_CD
    WHERE A.REC_ID = '01'
    AND ((A.UPD_EIGY_YMD >= NVL(iShimeFrom,ULT_COMMON.ORIGINAL_YMD) AND A.UPD_EIGY_YMD <= iShimeTo)
          OR (B.UPD_EIGY_YMD >= NVL(iShimeFrom,ULT_COMMON.ORIGINAL_YMD) AND B.UPD_EIGY_YMD <= iShimeTo))
    AND A.DEL_FLG IS NULL
    AND (B.SOSHITSU_FLG IS NULL OR C.SOSHITSU_FLG IS NULL) 
     -- 2010/10/03 �\�[�g����ǉ�����
    ORDER BY
    	A.REC_ID,
    	A.KJN_CD;
    -- 2010/10/03 �\�[�g����ǉ�����
  weekSenmoniRow weekSenmoniCSR%ROWTYPE;    --�b��_�T����_�w����ヌ�R�[�h

  vTempModKbn VARCHAR2(1);  --�C���敪(�ꎞ�p)
  vMODKBN VARCHAR2(1);  --�C���敪
  vTAISHOKU_FLG VARCHAR2(1);  --�ސE�ٓ��t���O
  vSENMONI_MENTE VARCHAR2(1);  --���チ���e�敪
  vLastRecord VARCHAR2(10):='        ';  --�O��f�[�^������
  vSelectSQL VARCHAR2(32767);     --SQL��Select��
  vFromSQL VARCHAR2(32767);       --SQL��From��
  vWhereSQL VARCHAR2(32767);      --SQL��Where��
  vTABLE1 VARCHAR2(50);           --�e�[�u����1
  vTABLE2 VARCHAR2(50);           --�e�[�u����2
  vTABLE3 VARCHAR2(50);           --�e�[�u����3
  vTABLE4 VARCHAR2(50);           --�e�[�u����4
  vLAYOUT_KBN VARCHAR(3):= '501';  --���C�A�E�g�敪
  vRet INTEGER:=0;                 --���s����
  vNowData ULT_COMMON.VarcharArray;    --����f�[�^�̔z��
  vLastData ULT_COMMON.VarcharArray;    --�O��f�[�^�̔z��
  vLen int:=8+LENGTH(ULT_COMMON.DELIMITER);   --���R�[�h�h�c�ƌl�R�[�h�̒���
  vLastDcfKey VARCHAR2(20):='        ';  --�O��DCF��L�[������
  vSchemaNm     TM_JOSU.HANYO_KOMOKU%TYPE := NULL; -- �X�L�[�}����
  PGM_ID        VARCHAR2(50) := 'NH010107B001_501.CREATE_DCF_ISHI_SABUN';
  EXECUTE_SQL   VARCHAR2(32767) := NULL;
  vINSERT_TBL VARCHAR2(100):= '';	-- INSERT�Ώۃe�[�u����ҏW����
  vINSERT_SQL VARCHAR2(32767):= '';	-- INSERT����ҏW����
  vKojinCount INTEGER:=0;  --�ޔ��lDUMMY����
  
  vIsKojinChangedFlg VARCHAR2(1):=NULL;  --�l����ς�邩�ǂ������f�t���O

  -- ��r�p�f�[�^�̃J�[�\���^
  TYPE compareCSR    IS REF CURSOR;
  cur compareCSR;
  --�V���C�A�E�gVAN�p��r�p�f�[�^�̃��R�[�h�^
  TYPE tVAN_SHIN_RECORD IS RECORD (
    FIELD1 VARCHAR(4000),           --��r����1
    FIELD2 VARCHAR(4000),           --��r����2
    DEL_FLG VARCHAR(1),             --�폜�t���O
    UPD_EIGY_YMD VARCHAR(8)         --�X�V�����c�ƔN����
  );

  vVAN_SHIN_RECORD tVAN_SHIN_RECORD;--VAN�p��r�p�f�[�^

  --�V���C�A�E�g�}�̗p��r�p�f�[�^�̃��R�[�h�^
  TYPE tBAITAI_SHIN_RECORD IS RECORD (
    FIELD1 VARCHAR(4000),           --��r����1
    FIELD2 VARCHAR(4000),           --��r����2
    DEL_FLG VARCHAR(1),             --�폜�t���O
    UPD_EIGY_YMD VARCHAR(8),        --�X�V�����c�ƔN����
    zDEL_FLG VARCHAR(1),            --�O��폜�t���O
    ALL_TAISHOKU_KJN_CD  TT_TIKY_KJN.KJN_CD%TYPE,  --�l�R�[�h
    KIMUSAKI_HENKO_KJN_CD TT_TIKY_KJN.KJN_CD%TYPE  --�l�Ζ���ύX���f
  );

  vBAITAI_SHIN_RECORD tBAITAI_SHIN_RECORD;

  --�b�背�C�A�E�g�}�̗p��r�p�f�[�^�̃��R�[�h�^
  TYPE tBAITAI_ZANTEI_RECORD IS RECORD (
    FIELD1 VARCHAR(4000),           --��r����1
    FIELD2 VARCHAR(4000),           --��r����2
    DEL_FLG VARCHAR(1),             --�폜�t���O
    TAISHOKU_FLG VARCHAR(1),        --�ސE�t���O
    ZEN_TAISHOKU_FLG VARCHAR(1),    --�O��ސE�t���O
    KJN_CD       VARCHAR(6),        --�l�R�[�h
    SZKBUKA_CD1  VARCHAR(4),        --���񏊑����ȃR�[�h
    SZKBUKA_CD2  VARCHAR(4),        --�O�񏊑����ȃR�[�h
    SZKBUKA_NM_KANA1  VARCHAR(60),        --���񏊑����Ȗ��J�i
    SZKBUKA_NM1  VARCHAR(100),        --���񏊑����Ȗ�
    SZKBUKA_NM_KANA2  VARCHAR(60),        --�O�񏊑����Ȗ��J�i
    SZKBUKA_NM2  VARCHAR(100),        --�O�񏊑����Ȗ�
    UPD_EIGY_YMD VARCHAR(8),        --�X�V�����c�ƔN����
    ALL_TAISHOKU_KJN_CD  TT_TIKY_KJN.KJN_CD%TYPE  --�l�R�[�h
    
  );
  
  --������2012/10/12 CP000112�̑Ή�
  vIsTaiShoku VARCHAR2(1) := ULT_COMMON.FLG_NO;  
  --������2012/10/12 CP000112�̑Ή�

  vBAITAI_ZANTEI_RECORD tBAITAI_ZANTEI_RECORD;
  tempRecord tBAITAI_ZANTEI_RECORD;

  --�b�背�C�A�E�g�}�̗p��r�p�f�[�^�̃��R�[�h�̔z��̌^
  TYPE tBAITAI_ZANTEI_TABLE IS table of tBAITAI_ZANTEI_RECORD;
  tempTABLE tBAITAI_ZANTEI_TABLE:=tBAITAI_ZANTEI_TABLE();

  editInfo1 EditInfoArray;     --�ҏW��`�z��(��W���A�����l�Ȃ�)
  editInfo2 EditInfoArray;   --�ҏW��`�z��(��W���A�����l����)
  editInfoArray1 EditInfoArrayArray;   --�ҏW��`�z��(�W���A�����l�Ȃ�)
  editInfoArray2 EditInfoArrayArray;   --�ҏW��`�z��(�W���A�����l����)


  BEGIN
    -- �J�n���O�o��
    ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'PL/SQL Start',PGM_ID || '�̏������J�n���܂��B',iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);
    -- �[�i�p�X�L�[�}�̎擾���s���B
    vSchemaNm := ULT_COMMON.GET_SCHEMA_NAME(ULT_COMMON.SYS_ENV_JOSU_DAI_CD, ULT_COMMON.NOHIN_SHEMA_JOSU_SHO_CD);

    oROW_COUNT:=0;
    --�V���C�A�E�g�̏ꍇ
    IF iLayoutKind = ULT_COMMON.LAYOUT_SBT_CD_SHIN THEN
      vSelectSQL :=
        'SELECT
          A.REC_ID ||'''||ULT_COMMON.DELIMITER||'''||
          A.KJN_CD ||'''||ULT_COMMON.DELIMITER||'''||
          A.DEL_YOTEI_RIYU_CD ||'''||ULT_COMMON.DELIMITER||'''||
          A.CHOFUKU_AITSK_REC_ID ||'''||ULT_COMMON.DELIMITER||'''||
          A.CHOFUKU_AITSK_KJN_CD ||'''||ULT_COMMON.DELIMITER||'''||
          A.KJN_NM ||'''||ULT_COMMON.DELIMITER||'''||
          A.KJN_NM_KANA ||'''||ULT_COMMON.DELIMITER||'''||
          A.SEIBETSU_KBN ||'''||ULT_COMMON.DELIMITER||'''||
          A.BIRTH_GENGO_CD ||'''||ULT_COMMON.DELIMITER||'''||
          A.BIRTH_WY ||'''||ULT_COMMON.DELIMITER||'''||
          A.BIRTH_M ||'''||ULT_COMMON.DELIMITER||'''||
          A.BIRTH_D ||'''||ULT_COMMON.DELIMITER||'''||
          A.SHUSSHINCHI_RIDAI_CD ||'''||ULT_COMMON.DELIMITER||'''||
          A.KANYU_ISHIKAI_RIDAI_CD ||'''||ULT_COMMON.DELIMITER||'''||
          A.STNEN_GENGO_CD ||'''||ULT_COMMON.DELIMITER||'''||
          A.STNEN_WY ||'''||ULT_COMMON.DELIMITER||'''||
          A.SHUSSHINKO_CD ||'''||ULT_COMMON.DELIMITER||'''||
          A.GAKUBU_SHIKIBETSU_KBN ||'''||ULT_COMMON.DELIMITER||'''||
          A.TRKNEN_GENGO_CD ||'''||ULT_COMMON.DELIMITER||'''||
          A.TRKNEN_WY ||'''||ULT_COMMON.DELIMITER||'''||
          A.SNRYKMK_CD_1 ||'''||ULT_COMMON.DELIMITER||'''||
          A.SNRYKMK_CD_2 ||'''||ULT_COMMON.DELIMITER||'''||
          A.SNRYKMK_CD_3 ||'''||ULT_COMMON.DELIMITER||'''||
          A.SNRYKMK_CD_4 ||'''||ULT_COMMON.DELIMITER||'''||
          A.SNRYKMK_CD_5 ||'''||ULT_COMMON.DELIMITER||'''||
          A.JUSHOFUMEI_CD ||'''||ULT_COMMON.DELIMITER||'''||
          A.KEN_CD ||'''||ULT_COMMON.DELIMITER||'''||
          A.SHIKU_CD ||'''||ULT_COMMON.DELIMITER||'''||
          A.OAZA_CD ||'''||ULT_COMMON.DELIMITER||'''||
          A.AZA_CD ||'''||ULT_COMMON.DELIMITER||'''||
          A.ZIP ||'''||ULT_COMMON.DELIMITER||'''||
          A.JUSHO_KANJI_RENKETSU ||'''||ULT_COMMON.DELIMITER||'''||
          A.JUSHO_KANA_RENKETSU ||'''||ULT_COMMON.DELIMITER||'''||
          A.JUSHO_HYOJI_NO ||'''||ULT_COMMON.DELIMITER||'''||
          A.KEN_NM_KANJI_MOJI_SU ||'''||ULT_COMMON.DELIMITER||'''||
          A.SHIKU_NM_KANJI_MOJI_SU ||'''||ULT_COMMON.DELIMITER||'''||
          A.OAZA_NM_KANJI_MOJI_SU ||'''||ULT_COMMON.DELIMITER||'''||
          A.AZA_NM_KANJI_MOJI_SU ||'''||ULT_COMMON.DELIMITER||'''||
          A.KEN_NM_KANA_MOJI_SU ||'''||ULT_COMMON.DELIMITER||'''||
          A.SHIKU_NM_KANA_MOJI_SU ||'''||ULT_COMMON.DELIMITER||'''||
          A.OAZA_NM_KANA_MOJI_SU ||'''||ULT_COMMON.DELIMITER||'''||
          A.AZA_NM_KANA_MOJI_SU ||'''||ULT_COMMON.DELIMITER||'''||
          A.TEL ||'''||ULT_COMMON.DELIMITER||'''||
          A.RIYOTEISHI_KBN_CD ||'''||ULT_COMMON.DELIMITER||'''||
          A.RIYOTEISHI_RIYU_CD ||'''||ULT_COMMON.DELIMITER||'''||
          A.RIYOTEISHI_TRK_YMD ||'''||ULT_COMMON.DELIMITER||'''||
          A.RIYOTEISHI_KAIJO_YMD ||'''||ULT_COMMON.DELIMITER||'''||
          A.KAIKIN_KBN ||'''||ULT_COMMON.DELIMITER||'''||
          A.KAIGYONEN_GENGO_CD ||'''||ULT_COMMON.DELIMITER||'''||
          A.KAIGYONEN_WY ||'''||ULT_COMMON.DELIMITER||'''||
          A.IKKATSU_TRK_FLG ||'''||ULT_COMMON.DELIMITER||'''||
          A.DEL_FLG
          AS FIELD1,
          B.REC_ID ||'''||ULT_COMMON.DELIMITER||'''||
          B.KJN_CD ||'''||ULT_COMMON.DELIMITER||'''||
          B.DEL_YOTEI_RIYU_CD ||'''||ULT_COMMON.DELIMITER||'''||
          B.CHOFUKU_AITSK_REC_ID ||'''||ULT_COMMON.DELIMITER||'''||
          B.CHOFUKU_AITSK_KJN_CD ||'''||ULT_COMMON.DELIMITER||'''||
          B.KJN_NM ||'''||ULT_COMMON.DELIMITER||'''||
          B.KJN_NM_KANA ||'''||ULT_COMMON.DELIMITER||'''||
          B.SEIBETSU_KBN ||'''||ULT_COMMON.DELIMITER||'''||
          B.BIRTH_GENGO_CD ||'''||ULT_COMMON.DELIMITER||'''||
          B.BIRTH_WY ||'''||ULT_COMMON.DELIMITER||'''||
          B.BIRTH_M ||'''||ULT_COMMON.DELIMITER||'''||
          B.BIRTH_D ||'''||ULT_COMMON.DELIMITER||'''||
          B.SHUSSHINCHI_RIDAI_CD ||'''||ULT_COMMON.DELIMITER||'''||
          B.KANYU_ISHIKAI_RIDAI_CD ||'''||ULT_COMMON.DELIMITER||'''||
          B.STNEN_GENGO_CD ||'''||ULT_COMMON.DELIMITER||'''||
          B.STNEN_WY ||'''||ULT_COMMON.DELIMITER||'''||
          B.SHUSSHINKO_CD ||'''||ULT_COMMON.DELIMITER||'''||
          B.GAKUBU_SHIKIBETSU_KBN ||'''||ULT_COMMON.DELIMITER||'''||
          B.TRKNEN_GENGO_CD ||'''||ULT_COMMON.DELIMITER||'''||
          B.TRKNEN_WY ||'''||ULT_COMMON.DELIMITER||'''||
          B.SNRYKMK_CD_1 ||'''||ULT_COMMON.DELIMITER||'''||
          B.SNRYKMK_CD_2 ||'''||ULT_COMMON.DELIMITER||'''||
          B.SNRYKMK_CD_3 ||'''||ULT_COMMON.DELIMITER||'''||
          B.SNRYKMK_CD_4 ||'''||ULT_COMMON.DELIMITER||'''||
          B.SNRYKMK_CD_5 ||'''||ULT_COMMON.DELIMITER||'''||
          B.JUSHOFUMEI_CD ||'''||ULT_COMMON.DELIMITER||'''||
          B.KEN_CD ||'''||ULT_COMMON.DELIMITER||'''||
          B.SHIKU_CD ||'''||ULT_COMMON.DELIMITER||'''||
          B.OAZA_CD ||'''||ULT_COMMON.DELIMITER||'''||
          B.AZA_CD ||'''||ULT_COMMON.DELIMITER||'''||
          B.ZIP ||'''||ULT_COMMON.DELIMITER||'''||
          B.JUSHO_KANJI_RENKETSU ||'''||ULT_COMMON.DELIMITER||'''||
          B.JUSHO_KANA_RENKETSU ||'''||ULT_COMMON.DELIMITER||'''||
          B.JUSHO_HYOJI_NO ||'''||ULT_COMMON.DELIMITER||'''||
          B.KEN_NM_KANJI_MOJI_SU ||'''||ULT_COMMON.DELIMITER||'''||
          B.SHIKU_NM_KANJI_MOJI_SU ||'''||ULT_COMMON.DELIMITER||'''||
          B.OAZA_NM_KANJI_MOJI_SU ||'''||ULT_COMMON.DELIMITER||'''||
          B.AZA_NM_KANJI_MOJI_SU ||'''||ULT_COMMON.DELIMITER||'''||
          B.KEN_NM_KANA_MOJI_SU ||'''||ULT_COMMON.DELIMITER||'''||
          B.SHIKU_NM_KANA_MOJI_SU ||'''||ULT_COMMON.DELIMITER||'''||
          B.OAZA_NM_KANA_MOJI_SU ||'''||ULT_COMMON.DELIMITER||'''||
          B.AZA_NM_KANA_MOJI_SU ||'''||ULT_COMMON.DELIMITER||'''||
          B.TEL ||'''||ULT_COMMON.DELIMITER||'''||
          B.RIYOTEISHI_KBN_CD ||'''||ULT_COMMON.DELIMITER||'''||
          B.RIYOTEISHI_RIYU_CD ||'''||ULT_COMMON.DELIMITER||'''||
          B.RIYOTEISHI_TRK_YMD ||'''||ULT_COMMON.DELIMITER||'''||
          B.RIYOTEISHI_KAIJO_YMD ||'''||ULT_COMMON.DELIMITER||'''||
          B.KAIKIN_KBN ||'''||ULT_COMMON.DELIMITER||'''||
          B.KAIGYONEN_GENGO_CD ||'''||ULT_COMMON.DELIMITER||'''||
          B.KAIGYONEN_WY ||'''||ULT_COMMON.DELIMITER||'''||
          B.IKKATSU_TRK_FLG ||'''||ULT_COMMON.DELIMITER||'''||
          B.DEL_FLG
          AS FIELD2,
          A.DEL_FLG AS DEL_FLG,';
        vWhereSQL:='WHERE A.REC_ID = ''01''
          AND A.UPD_EIGY_YMD >= '''||NVL(iShimeFrom,ULT_COMMON.ORIGINAL_YMD)||'''
          AND A.UPD_EIGY_YMD <= '''||iShimeTo||'''
          AND (A.DEL_FLG IS NULL OR B.DEL_FLG IS NULL)';

        editInfo1:=EditInfoArray(6,7,8,13,14,48,51);  --��W���A�����l�Ȃ�
        editInfo2:=EditInfoArray(43,44,45,46,47);  --��W���A�����l����
        editInfoArray1:=EditInfoArrayArray(  --�W���A�����l�Ȃ�
                          EditInfoArray(17,18),
                          EditInfoArray(27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42)
                          );
        editInfoArray2:=EditInfoArrayArray(  --�W���A�����l����
                          EditInfoArray(9,10,11,12),
                          EditInfoArray(15,16),
                          EditInfoArray(19,20),
                          EditInfoArray(21,22,23,24,25),
                          EditInfoArray(49,50)
                          );
      END IF;

      -- ���ߓ��敪��"1"(������) �܂��́A"2"(�T����) ���� �����D���C�A�E�g�敪��"1"(�V���C�A�E�g) �̏ꍇ�A
      IF (iShimeKind = ULT_COMMON.SHIME_SBT_CD_HISHIME OR iShimeKind = ULT_COMMON.SHIME_SBT_CD_SHUSHIME) AND
        iLayoutKind = ULT_COMMON.LAYOUT_SBT_CD_SHIN   THEN

        IF iShimeKind = ULT_COMMON.SHIME_SBT_CD_HISHIME THEN
          --�V_������_DCF��t�e�[�u���̃f�[�^���N���A����B
          EXECUTE_SQL := 'TRUNCATE TABLE ' || vSchemaNm || '.' || 'TD_ND_DCF_KJN';
          vTABLE1:='TT_Z_D_KJN';
        ELSE
          --�V_�T����_DCF��t�e�[�u���̃f�[�^���N���A����B
          EXECUTE_SQL := 'TRUNCATE TABLE ' || vSchemaNm || '.' || 'TD_NW_DCF_KJN';
          vTABLE1:='TT_Z_W_KJN';
        END IF;
        EXECUTE IMMEDIATE EXECUTE_SQL;
        ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);
        vSelectSQL := vSelectSQL||'A.UPD_EIGY_YMD AS UPD_EIGY_YMD ';
        vFromSQL :='FROM TT_TIKY_KJN A
         LEFT OUTER JOIN '||vTABLE1||' B
           ON A.REC_ID = B.REC_ID
           AND A.KJN_CD = B.KJN_CD
         ';
        ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',vSelectSQL||vFromSQL||vWhereSQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);
        OPEN cur FOR vSelectSQL||vFromSQL||vWhereSQL;
        LOOP
          FETCH cur INTO vVAN_SHIN_RECORD;
          EXIT WHEN cur%NOTFOUND;
          oROW_COUNT:=oROW_COUNT+1;
          --��r����1�Ɣ�r����2����v���Ă��Ȃ��ꍇ
          IF vVAN_SHIN_RECORD.FIELD1 != vVAN_SHIN_RECORD.FIELD2 THEN


            --����f�[�^������A�O��f�[�^���Ȃ��ꍇ�A�ǉ��Ƃ��ēo�^����(��r����2�̐擪��TAB�̏ꍇ)
            IF SUBSTR(vVAN_SHIN_RECORD.FIELD2,1,1) = ULT_COMMON.DELIMITER THEN
              vMODKBN  := ULT_COMMON.MOD_KBN_ADD;
              vNowData := ULT_COMMON.StrSplit(vVAN_SHIN_RECORD.FIELD1, ULT_COMMON.DELIMITER);

            --����f�[�^���폜���ꂽ�ꍇ�A�폜�Ƃ��ēo�^����(��r�p�f�[�^�̍폜�t���O = "1"�̏ꍇ)
            ELSIF NVL(vVAN_SHIN_RECORD.DEL_FLG,'0') = '1' THEN
              vMODKBN := ULT_COMMON.MOD_KBN_DEL;
              IF iShimeKind = ULT_COMMON.SHIME_SBT_CD_HISHIME THEN
                --�V_������_DCF��t�e�[�u���ɓo�^����B
                INSERT INTO TD_ND_DCF_KJN(LAYOUT_KBN,KJNREC_ID,KJN_CD,MOD_KBN,MENTE_YMD,TENSO_YMD,TRK_OPE_CD,TRK_DATE,TRK_PGM_ID,UPD_OPE_CD,UPD_DATE,UPD_PGM_ID)
                VALUES(vLAYOUT_KBN,SUBSTR(vVAN_SHIN_RECORD.FIELD1,1,2),SUBSTR(vVAN_SHIN_RECORD.FIELD1,4,6),vMODKBN,vVAN_SHIN_RECORD.UPD_EIGY_YMD,iTensoYMD,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);
                EXECUTE_SQL := 'INSERT INTO TD_ND_DCF_KJN(LAYOUT_KBN,KJNREC_ID,KJN_CD,MOD_KBN,MENTE_YMD,TENSO_YMD,TRK_OPE_CD,TRK_DATE,TRK_PGM_ID,UPD_OPE_CD,UPD_DATE,UPD_PGM_ID)
                  VALUES('''||vLAYOUT_KBN||''','''||SUBSTR(vVAN_SHIN_RECORD.FIELD1,1,2)||''','''||SUBSTR(vVAN_SHIN_RECORD.FIELD1,4,6)||''','''||vMODKBN||''','''||
                  vVAN_SHIN_RECORD.UPD_EIGY_YMD||''','''||iTensoYMD||''','''||iOPE_CD||''','''||iDATE||''','''||iPGM_ID||''','''||iOPE_CD||''','''||iDATE||''','''||iPGM_ID||''')';
              ELSE
                --�V_�T����_DCF��t�e�[�u���ɓo�^����B
                INSERT INTO TD_NW_DCF_KJN(LAYOUT_KBN,KJNREC_ID,KJN_CD,MOD_KBN,MENTE_YMD,TENSO_YMD,TRK_OPE_CD,TRK_DATE,TRK_PGM_ID,UPD_OPE_CD,UPD_DATE,UPD_PGM_ID)
                VALUES(vLAYOUT_KBN,SUBSTR(vVAN_SHIN_RECORD.FIELD1,1,2),SUBSTR(vVAN_SHIN_RECORD.FIELD1,4,6),vMODKBN,vVAN_SHIN_RECORD.UPD_EIGY_YMD,iTensoYMD,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);
                EXECUTE_SQL := 'INSERT INTO TD_NW_DCF_KJN(LAYOUT_KBN,KJNREC_ID,KJN_CD,MOD_KBN,MENTE_YMD,TENSO_YMD,TRK_OPE_CD,TRK_DATE,TRK_PGM_ID,UPD_OPE_CD,UPD_DATE,UPD_PGM_ID)
                  VALUES('''||vLAYOUT_KBN||''','''||SUBSTR(vVAN_SHIN_RECORD.FIELD1,1,2)||''','''||SUBSTR(vVAN_SHIN_RECORD.FIELD1,4,6)||''','''||vMODKBN||''','''||
                  vVAN_SHIN_RECORD.UPD_EIGY_YMD||''','''||iTensoYMD||''','''||iOPE_CD||''','''||iDATE||''','''||iPGM_ID||''','''||iOPE_CD||''','''||iDATE||''','''||iPGM_ID||''')';
              END IF;
              ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

            -- ����ƑO��ŕω��̂���f�[�^�͕ύX�Ƃ��ēo�^����(��r����1�Ɣ�r����2����v���Ă��Ȃ��ꍇ)
            ELSE
              vMODKBN := ULT_COMMON.MOD_KBN_YES;
              vNowData := ULT_COMMON.StrSplit(vVAN_SHIN_RECORD.FIELD1, ULT_COMMON.DELIMITER);
              vLastData:= ULT_COMMON.StrSplit(vVAN_SHIN_RECORD.FIELD2, ULT_COMMON.DELIMITER);

              --�폜�\�藝�R�R�[�h�A�d�������R�[�h�̂����ꂩ�ɕύX���������ꍇ�A
              IF NVL(vNowData(3),0) != NVL(vLastData(3),0) OR NVL(vNowData(4),0) != NVL(vLastData(4),0) OR NVL(vNowData(5),0) != NVL(vLastData(5),0) THEN
                IF vNowData(3) IS NULL AND vLastData(3) IS NOT NULL THEN
                   vNowData(3):= ULT_COMMON.INSERT_HALF_DEFAULT;
                END IF;
                IF vNowData(4) IS NULL AND vLastData(4) IS NOT NULL AND vNowData(5) IS NULL AND vLastData(5) IS NOT NULL THEN
                   vNowData(4):= ULT_COMMON.INSERT_HALF_DEFAULT;
                END IF;
                IF vNowData(26) IS NULL AND vLastData(26) IS NOT NULL THEN
                   vNowData(26):= ULT_COMMON.INSERT_HALF_DEFAULT;
                END IF;
              ELSE
                vNowData(3):=NULL;
                vNowData(4):=NULL;
                vNowData(5):=NULL;
                IF vNowData(26) IS NULL AND vLastData(26) IS NOT NULL THEN
                   vNowData(26):= ULT_COMMON.INSERT_HALF_DEFAULT;
                ELSIF '1'||vNowData(26) = '1'||vLastData(26) THEN
                   vNowData(26):= NULL;
                END IF;
              END IF;

              --NULL�ݒ�(��W���A�����l�Ȃ�)
              ChangeToNull(vNowData,vLastData,editInfo1);
              --�����l�ݒ�(��W���A�����l����)
              ChangeToDefault(vNowData,vLastData,editInfo2);
              --NULL�ݒ�(�W���A�����l�Ȃ�)
              ChangeToNullForArray(vNowData,vLastData,editInfoArray1);
              --�����l�ݒ�(�W���A�����l����)
              ChangeToDefaultForArray(vNowData,vLastData,editInfoArray2);

            END IF;

            --�o�^����
            IF vMODKBN != ULT_COMMON.MOD_KBN_DEL THEN
              IF iShimeKind = ULT_COMMON.SHIME_SBT_CD_HISHIME THEN
                INSERT INTO TD_ND_DCF_KJN(
                    LAYOUT_KBN,
                    KJNREC_ID,
                    KJN_CD,
                    MOD_KBN,
                    MENTE_YMD,
                    TENSO_YMD,
                    DEL_YOTEI_RIYU,
                    AITSK_CD_KJNREC_ID,
                    AITSK_CD_KJN_CD,
                    ISHI_NM_KANJI,
                    ISHI_NM_KANA,
                    SEIBETSU,
                    BIRTH_GENGO,
                    BIRTH_Y,
                    BIRTH_M,
                    BIRTH_D,
                    SHUSSHIN_KEN_CD,
                    ISHIKAI_CD,
                    STNEN_GENGO,
                    STNEN_Y,
                    SHUSSHINKO_SHUSSHINKO_CD,
                    SHUSSHINKO_GAKUBU_SKBT_CD,
                    TRKNEN_GENGO,
                    TRKNEN_Y,
                    SNRYKMK_1,
                    SNRYKMK_2,
                    SNRYKMK_3,
                    SNRYKMK_4,
                    SNRYKMK_5,
                    JUSHOFUMEI,
                    JUSHO_CD_KEN_CD,
                    JUSHO_CD_SHIKU_CD,
                    JUSHO_CD_OAZA_CD,
                    JUSHO_CD_AZA_CD,
                    ZIP,
                    JITAKU_JUSHO_KANJI,
                    JITAKU_JUSHO_KANA,
                    JUSHO_HYOJI_NO,
                    JUSHO_COUNT_KANJI_KEN,
                    JUSHO_COUNT_KANJI_SHIKU,
                    JUSHO_COUNT_KANJI_OAZA,
                    JUSHO_COUNT_KANJI_AZA,
                    JUSHO_COUNT_KANA_KEN,
                    JUSHO_COUNT_KANA_SHIKU,
                    JUSHO_COUNT_KANA_OAZA,
                    JUSHO_COUNT_KANA_AZA,
                    JITAKU_TEL,
                    RIYOTEISHI_RIYOTEISHI_KBN,
                    RIYOTEISHI_RIYOTEISHI_RIYU,
                    RIYOTEISHI_TRK_YMD,
                    RIYOTEISHI_KAIJO_YMD,
                    KAIKIN_KBN,
                    KAIGYONEN_GENGO,
                    KAIGYONEN_Y,
                    IKKATSU_TRK_FLG,
                    Trk_Ope_Cd,
                    Trk_Date,
                    Trk_Pgm_Id,
                    Upd_Ope_Cd,
                    Upd_Date,
                    Upd_Pgm_Id
                    )
                  VALUES(
                    vLAYOUT_KBN,
                    vNowData(1),
                    vNowData(2),
                    vMODKBN,
                    vVAN_SHIN_RECORD.UPD_EIGY_YMD,
                    iTensoYMD,
                    TRIM(vNowData(3)),
                    TRIM(vNowData(4)),
                    TRIM(vNowData(5)),
                    TRIM(vNowData(6)),
                    TRIM(vNowData(7)),
                    TRIM(vNowData(8)),
                    TRIM(vNowData(9)),
                    TRIM(vNowData(10)),
                    TRIM(vNowData(11)),
                    TRIM(vNowData(12)),
                    TRIM(vNowData(13)),
                    TRIM(vNowData(14)),
                    TRIM(vNowData(15)),
                    TRIM(vNowData(16)),
                    TRIM(vNowData(17)),
                    TRIM(vNowData(18)),
                    TRIM(vNowData(19)),
                    TRIM(vNowData(20)),
                    TRIM(vNowData(21)),
                    TRIM(vNowData(22)),
                    TRIM(vNowData(23)),
                    TRIM(vNowData(24)),
                    TRIM(vNowData(25)),
                    TRIM(vNowData(26)),
                    TRIM(vNowData(27)),
                    TRIM(vNowData(28)),
                    TRIM(vNowData(29)),
                    TRIM(vNowData(30)),
                    NVL2(vNowData(31),SUBSTR(vNowData(31),1,3)||'-'||SUBSTR(vNowData(31),4),NULL),
                    TRIM(vNowData(32)),
                    TRIM(vNowData(33)),
                    TRIM(vNowData(34)),
                    TRIM(vNowData(35)),
                    TRIM(vNowData(36)),
                    TRIM(vNowData(37)),
                    TRIM(vNowData(38)),
                    TRIM(vNowData(39)),
                    TRIM(vNowData(40)),
                    TRIM(vNowData(41)),
                    TRIM(vNowData(42)),
                    TRIM(vNowData(43)),
                    TRIM(vNowData(44)),
                    TRIM(vNowData(45)),
                    TRIM(vNowData(46)),
                    TRIM(vNowData(47)),
                    TRIM(vNowData(48)),
                    TRIM(vNowData(49)),
                    TRIM(vNowData(50)),
                    TRIM(vNowData(51)),
                    iOPE_CD,
                    iDATE,
                    iPGM_ID,
                    iOPE_CD,
                    iDATE,
                    iPGM_ID
                  );
                EXECUTE_SQL := 'INSERT INTO TD_ND_DCF_KJN(';
              ELSE
                INSERT INTO TD_NW_DCF_KJN(
                    LAYOUT_KBN,
                    KJNREC_ID,
                    KJN_CD,
                    MOD_KBN,
                    MENTE_YMD,
                    TENSO_YMD,
                    DEL_YOTEI_RIYU,
                    AITSK_CD_KJNREC_ID,
                    AITSK_CD_KJN_CD,
                    ISHI_NM_KANJI,
                    ISHI_NM_KANA,
                    SEIBETSU,
                    BIRTH_GENGO,
                    BIRTH_Y,
                    BIRTH_M,
                    BIRTH_D,
                    SHUSSHIN_KEN_CD,
                    ISHIKAI_CD,
                    STNEN_GENGO,
                    STNEN_Y,
                    SHUSSHINKO_SHUSSHINKO_CD,
                    SHUSSHINKO_GAKUBU_SKBT_CD,
                    TRKNEN_GENGO,
                    TRKNEN_Y,
                    SNRYKMK_1,
                    SNRYKMK_2,
                    SNRYKMK_3,
                    SNRYKMK_4,
                    SNRYKMK_5,
                    JUSHOFUMEI,
                    JUSHO_CD_KEN_CD,
                    JUSHO_CD_SHIKU_CD,
                    JUSHO_CD_OAZA_CD,
                    JUSHO_CD_AZA_CD,
                    ZIP,
                    JITAKU_JUSHO_KANJI,
                    JITAKU_JUSHO_KANA,
                    JUSHO_HYOJI_NO,
                    JUSHO_COUNT_KANJI_KEN,
                    JUSHO_COUNT_KANJI_SHIKU,
                    JUSHO_COUNT_KANJI_OAZA,
                    JUSHO_COUNT_KANJI_AZA,
                    JUSHO_COUNT_KANA_KEN,
                    JUSHO_COUNT_KANA_SHIKU,
                    JUSHO_COUNT_KANA_OAZA,
                    JUSHO_COUNT_KANA_AZA,
                    JITAKU_TEL,
                    RIYOTEISHI_RIYOTEISHI_KBN,
                    RIYOTEISHI_RIYOTEISHI_RIYU,
                    RIYOTEISHI_TRK_YMD,
                    RIYOTEISHI_KAIJO_YMD,
                    KAIKIN_KBN,
                    KAIGYONEN_GENGO,
                    KAIGYONEN_Y,
                    IKKATSU_TRK_FLG,
                    Trk_Ope_Cd,
                    Trk_Date,
                    Trk_Pgm_Id,
                    Upd_Ope_Cd,
                    Upd_Date,
                    Upd_Pgm_Id
                    )
                  VALUES(
                    vLAYOUT_KBN,
                    vNowData(1),
                    vNowData(2),
                    vMODKBN,
                    vVAN_SHIN_RECORD.UPD_EIGY_YMD,
                    iTensoYMD,
                    TRIM(vNowData(3)),
                    TRIM(vNowData(4)),
                    TRIM(vNowData(5)),
                    TRIM(vNowData(6)),
                    TRIM(vNowData(7)),
                    TRIM(vNowData(8)),
                    TRIM(vNowData(9)),
                    TRIM(vNowData(10)),
                    TRIM(vNowData(11)),
                    TRIM(vNowData(12)),
                    TRIM(vNowData(13)),
                    TRIM(vNowData(14)),
                    TRIM(vNowData(15)),
                    TRIM(vNowData(16)),
                    TRIM(vNowData(17)),
                    TRIM(vNowData(18)),
                    TRIM(vNowData(19)),
                    TRIM(vNowData(20)),
                    TRIM(vNowData(21)),
                    TRIM(vNowData(22)),
                    TRIM(vNowData(23)),
                    TRIM(vNowData(24)),
                    TRIM(vNowData(25)),
                    TRIM(vNowData(26)),
                    TRIM(vNowData(27)),
                    TRIM(vNowData(28)),
                    TRIM(vNowData(29)),
                    TRIM(vNowData(30)),
                    NVL2(vNowData(31),SUBSTR(vNowData(31),1,3)||'-'||SUBSTR(vNowData(31),4),NULL),
                    TRIM(vNowData(32)),
                    TRIM(vNowData(33)),
                    TRIM(vNowData(34)),
                    TRIM(vNowData(35)),
                    TRIM(vNowData(36)),
                    TRIM(vNowData(37)),
                    TRIM(vNowData(38)),
                    TRIM(vNowData(39)),
                    TRIM(vNowData(40)),
                    TRIM(vNowData(41)),
                    TRIM(vNowData(42)),
                    TRIM(vNowData(43)),
                    TRIM(vNowData(44)),
                    TRIM(vNowData(45)),
                    TRIM(vNowData(46)),
                    TRIM(vNowData(47)),
                    TRIM(vNowData(48)),
                    TRIM(vNowData(49)),
                    TRIM(vNowData(50)),
                    TRIM(vNowData(51)),
                    iOPE_CD,
                    iDATE,
                    iPGM_ID,
                    iOPE_CD,
                    iDATE,
                    iPGM_ID
                  );
                EXECUTE_SQL := 'INSERT INTO TD_NW_DCF_KJN(';
              END IF;
              EXECUTE_SQL := EXECUTE_SQL||'
                    LAYOUT_KBN,
                    KJNREC_ID,
                    KJN_CD,
                    MOD_KBN,
                    MENTE_YMD,
                    TENSO_YMD,
                    DEL_YOTEI_RIYU,
                    AITSK_CD_KJNREC_ID,
                    AITSK_CD_KJN_CD,
                    ISHI_NM_KANJI,
                    ISHI_NM_KANA,
                    SEIBETSU,
                    BIRTH_GENGO,
                    BIRTH_Y,
                    BIRTH_M,
                    BIRTH_D,
                    SHUSSHIN_KEN_CD,
                    ISHIKAI_CD,
                    STNEN_GENGO,
                    STNEN_Y,
                    SHUSSHINKO_SHUSSHINKO_CD,
                    SHUSSHINKO_GAKUBU_SKBT_CD,
                    TRKNEN_GENGO,
                    TRKNEN_Y,
                    SNRYKMK_1,
                    SNRYKMK_2,
                    SNRYKMK_3,
                    SNRYKMK_4,
                    SNRYKMK_5,
                    JUSHOFUMEI,
                    JUSHO_CD_KEN_CD,
                    JUSHO_CD_SHIKU_CD,
                    JUSHO_CD_OAZA_CD,
                    JUSHO_CD_AZA_CD,
                    ZIP,
                    JITAKU_JUSHO_KANJI,
                    JITAKU_JUSHO_KANA,
                    JUSHO_HYOJI_NO,
                    JUSHO_COUNT_KANJI_KEN,
                    JUSHO_COUNT_KANJI_SHIKU,
                    JUSHO_COUNT_KANJI_OAZA,
                    JUSHO_COUNT_KANJI_AZA,
                    JUSHO_COUNT_KANA_KEN,
                    JUSHO_COUNT_KANA_SHIKU,
                    JUSHO_COUNT_KANA_OAZA,
                    JUSHO_COUNT_KANA_AZA,
                    JITAKU_TEL,
                    RIYOTEISHI_RIYOTEISHI_KBN,
                    RIYOTEISHI_RIYOTEISHI_RIYU,
                    RIYOTEISHI_TRK_YMD,
                    RIYOTEISHI_KAIJO_YMD,
                    KAIKIN_KBN,
                    KAIGYONEN_GENGO,
                    KAIGYONEN_Y,
                    IKKATSU_TRK_FLG,
                    Trk_Ope_Cd,
                    Trk_Date,
                    Trk_Pgm_Id,
                    Upd_Ope_Cd,
                    Upd_Date,
                    Upd_Pgm_Id
                    )
                  VALUES(
                    '''||vLAYOUT_KBN||''',
                    '''||vNowData(1)||''',
                    '''||vNowData(2)||''',
                    '''||vMODKBN||''',
                    '''||vVAN_SHIN_RECORD.UPD_EIGY_YMD||''',
                    '''||iTensoYMD||''',
                    '''||vNowData(3)||''',
                    '''||vNowData(4)||''',
                    '''||vNowData(5)||''',
                    '''||vNowData(6)||''',
                    '''||vNowData(7)||''',
                    '''||vNowData(8)||''',
                    '''||vNowData(9)||''',
                    '''||vNowData(10)||''',
                    '''||vNowData(11)||''',
                    '''||vNowData(12)||''',
                    '''||vNowData(13)||''',
                    '''||vNowData(14)||''',
                    '''||vNowData(15)||''',
                    '''||vNowData(16)||''',
                    '''||vNowData(17)||''',
                    '''||vNowData(18)||''',
                    '''||vNowData(19)||''',
                    '''||vNowData(20)||''',
                    '''||vNowData(21)||''',
                    '''||vNowData(22)||''',
                    '''||vNowData(23)||''',
                    '''||vNowData(24)||''',
                    '''||vNowData(25)||''',
                    '''||vNowData(26)||''',
                    '''||vNowData(27)||''',
                    '''||vNowData(28)||''',
                    '''||vNowData(29)||''',
                    '''||vNowData(30)||''',
                    '''||CASE WHEN vNowData(31) IS NOT NULL THEN SUBSTR(vNowData(31),1,3)||'-'||SUBSTR(vNowData(31),4) ELSE NULL END ||''',
                    '''||vNowData(32)||''',
                    '''||vNowData(33)||''',
                    '''||vNowData(34)||''',
                    '''||vNowData(35)||''',
                    '''||vNowData(36)||''',
                    '''||vNowData(37)||''',
                    '''||vNowData(38)||''',
                    '''||vNowData(39)||''',
                    '''||vNowData(40)||''',
                    '''||vNowData(41)||''',
                    '''||vNowData(42)||''',
                    '''||vNowData(43)||''',
                    '''||TRIM(vNowData(44))||''',
                    '''||TRIM(vNowData(45))||''',
                    '''||TRIM(vNowData(46))||''',
                    '''||TRIM(vNowData(47))||''',
                    '''||vNowData(48)||''',
                    '''||vNowData(49)||''',
                    '''||vNowData(50)||''',
                    '''||vNowData(51)||''',
                    '''||iOPE_CD||''',
                    '''||iDATE||''',
                    '''||iPGM_ID||''',
                    '''||iOPE_CD||''',
                    '''||iDATE||''',
                    '''||iPGM_ID||''')';
              ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);
            END IF;
          END IF;
        END LOOP;
        CLOSE cur;

      -- ���ߓ��敪��"4"(������)�A�܂��́A"5"(������)�A���� �����D���C�A�E�g�敪��"1"(�V���C�A�E�g) �̏ꍇ�A
      ELSIF (iShimeKind = ULT_COMMON.SHIME_SBT_CD_NAKASHIME OR iShimeKind = ULT_COMMON.SHIME_SBT_CD_MATSUSHIME) AND
        iLayoutKind = ULT_COMMON.LAYOUT_SBT_CD_SHIN   THEN

		-- ������2012/10/26 CP000182�̑Ή�
        IF iM2Flg = ULT_COMMON.FLG_NO THEN
        	--�V_��1����_DCF��t�e�[�u���̃f�[�^���N���A����B
          	EXECUTE_SQL := 'TRUNCATE TABLE ' || vSchemaNm || '.' || 'TD_NM_DCF_KJN';
          	
          	IF iShimeKind = ULT_COMMON.SHIME_SBT_CD_NAKASHIME THEN
	          vTABLE1:='TT_Z_MM_KJN';
	          vTABLE2:='TT_Z_MM_KJN_KINMUSAKI';
	        ELSE
	          vTABLE1:='TT_Z_ME_KJN';
	          vTABLE2:='TT_Z_ME_KJN_KINMUSAKI';
	        END IF;
        ELSE 
        	 --�V_��2����_DCF��t�e�[�u���̃f�[�^���N���A����B
          	EXECUTE_SQL := 'TRUNCATE TABLE ' || vSchemaNm || '.' || 'TD_N2_DCF_KJN';
          	
          	IF iShimeKind = ULT_COMMON.SHIME_SBT_CD_NAKASHIME THEN
          	  vTABLE1:='TT_Z_ME_KJN';
	          vTABLE2:='TT_Z_ME_KJN_KINMUSAKI';
	        ELSE
	          vTABLE1:='TT_Z_MM_KJN';
	          vTABLE2:='TT_Z_MM_KJN_KINMUSAKI';
	        END IF;
        END IF;
        
        -- ������2012/10/26 CP000182�̑Ή�
        EXECUTE IMMEDIATE EXECUTE_SQL;
        ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

        vFromSQL :='
        FROM TT_TIKY_KJN A
            LEFT OUTER JOIN '||vTABLE1||' B
              ON A.REC_ID = B.REC_ID
              AND A.KJN_CD = B.KJN_CD
            LEFT OUTER JOIN
		         (  SELECT
		              KJN_CD,
		              SUM(TAISHOKU_FLG_1) COUNT1,
		              SUM(TAISHOKU_FLG_2) COUNT2,
		              COUNT(1) INFO_COUNT,
		              MAX(UPD_EIGY_YMD) UPD_EIGY_YMD
		            FROM
			            ( SELECT
			                TTK.KJN_CD,
			                DECODE(M.TAISHOKU_FLG,''1'',1,0) TAISHOKU_FLG_1,
			                CASE WHEN N.REC_ID IS NOT NULL AND NVL(N.TAISHOKU_FLG, ''0'') = ''0'' THEN
			                	1
			               	ELSE 0 END AS TAISHOKU_FLG_2,
			                CASE WHEN TTK.UPD_EIGY_YMD||''1''>=M.UPD_EIGY_YMD||''1'' THEN TTK.UPD_EIGY_YMD ELSE M.UPD_EIGY_YMD END AS UPD_EIGY_YMD
			              FROM TT_TIKY_KJN TTK
			              LEFT OUTER JOIN TT_TIKY_KJN_KINMUSAKI M
			              	ON TTK.REC_ID = M.REC_ID
							AND TTK.KJN_CD = M.KJN_CD
			              LEFT OUTER JOIN '||vTABLE2||' N
			                ON M.REC_ID = M.REC_ID
			                AND M.KJN_CD = N.KJN_CD
			                AND M.KINMUSAKI_REC_ID = N.KINMUSAKI_REC_ID
			                AND M.KINMUSAKI_SHI_CD = N.KINMUSAKI_SHI_CD
			              WHERE TTK.REC_ID = ''01''
			                AND (
				                	(M.UPD_EIGY_YMD >= '''||NVL(iShimeFrom,ULT_COMMON.ORIGINAL_YMD)||'''
				                		AND M.UPD_EIGY_YMD <= '''||NVL(iShimeTo,ULT_COMMON.ORIGINAL_YMD)||'''
				                	)
				                	OR
				                	(TTK.UPD_EIGY_YMD >= '''||NVL(iShimeFrom,ULT_COMMON.ORIGINAL_YMD)||'''
	          							AND TTK.UPD_EIGY_YMD <= '''||iShimeTo||'''
	          						)
          						)
		              	) 
		            GROUP BY
		              KJN_CD
	             ) C
	            ON  A.KJN_CD = C.KJN_CD
			LEFT OUTER JOIN
				(SELECT
					DISTINCT
					X.KJN_CD
				 FROM
					(SELECT
						TTK.KJN_CD AS KJN_CD,
						NULLIF(''1''||M.KINMUSAKI_REC_ID,''1''||N.KINMUSAKI_REC_ID) AS KINMUSAKI_REC_ID,	
						NULLIF(''1''||M.KINMUSAKI_SHI_CD,''1''||N.KINMUSAKI_SHI_CD) AS KINMUSAKI_SHI_CD,	
						NULLIF(''1''||M.YAKUSHOKU_CD,''1''||N.YAKUSHOKU_CD) AS YAKUSHOKU_CD,	
						NULLIF(''1''||M.SHOKUI_CD,''1''||N.SHOKUI_CD) AS SHOKUI_CD,	
						NULLIF(''1''||M.SZKBUKA_CD,''1''||N.SZKBUKA_CD) AS SZKBUKA_CD,	
						NULLIF(''1''||DECODE(M.SZKBUKA_CD, ''9999'',M.NYURYOKU_SZKBUKA_NM, NULL),
								''1''||DECODE(N.SZKBUKA_CD, ''9999'', N.NYURYOKU_SZKBUKA_NM, NULL)) AS SZKBUKA_NM,	
						NULLIF(''1''||DECODE(M.SZKBUKA_CD, ''9999'', M.NYURYOKU_SZKBUKA_NM_KANA, NULL),
								''1''||DECODE(N.SZKBUKA_CD, ''9999'', N.NYURYOKU_SZKBUKA_NM_KANA, NULL)) AS SZKBUKA_NM_KANA,	
						NULLIF(''1''||M.KINMUSAKI_DM_FUKA_FLG,''1''||N.KINMUSAKI_DM_FUKA_FLG) AS KINMUSAKI_DM_FUKA_FLG,	
						NULLIF(''1''||M.TAISHOKU_FLG,''1''||N.TAISHOKU_FLG) AS TAISHOKU_FLG	
					FROM TT_TIKY_KJN TTK
					INNER JOIN TT_TIKY_KJN_KINMUSAKI M
						ON TTK.REC_ID = M.REC_ID
						AND TTK.KJN_CD = M.KJN_CD
					LEFT OUTER JOIN '||vTABLE2||' N
						ON M.REC_ID = N.REC_ID
						AND M.KJN_CD = N.KJN_CD
						AND M.KINMUSAKI_REC_ID = N.KINMUSAKI_REC_ID
						AND M.KINMUSAKI_SHI_CD = N.KINMUSAKI_SHI_CD
					WHERE TTK.REC_ID = ''01''
						AND (	(M.UPD_EIGY_YMD >= '''||NVL(iShimeFrom, ULT_COMMON.ORIGINAL_YMD)||'''
									AND M.UPD_EIGY_YMD <= '''||iShimeTo||'''
								)
							OR
								(TTK.UPD_EIGY_YMD >= '''||NVL(iShimeFrom,ULT_COMMON.ORIGINAL_YMD)||'''
          							AND TTK.UPD_EIGY_YMD <= '''||iShimeTo||'''
          						)
          					)
          				AND (M.TAISHOKU_FLG IS NULL OR (N.TAISHOKU_FLG IS NULL AND N.REC_ID IS NOT NULL))
					) X
				WHERE (X.KINMUSAKI_REC_ID IS NOT NULL
					OR X.KINMUSAKI_SHI_CD IS NOT NULL
					OR X.YAKUSHOKU_CD IS NOT NULL
					OR X.SHOKUI_CD IS NOT NULL
					OR X.SZKBUKA_CD IS NOT NULL
					OR X.SZKBUKA_NM IS NOT NULL
					OR X.SZKBUKA_NM_KANA IS NOT NULL
					OR X.KINMUSAKI_DM_FUKA_FLG IS NOT NULL
					OR X.TAISHOKU_FLG IS NOT NULL)
				GROUP BY
					 X.KJN_CD) MM
				ON A.KJN_CD = MM.KJN_CD';
				-- ������2012/10/03 �d�l�ύX�ɂ��Ώۍ��ځi�Ζ���f�[�^�̕ύX���o�͑ΏۂƂ���j
				
        vWhereSQL:='  WHERE A.REC_ID = ''01''
          AND ((A.UPD_EIGY_YMD >= '''||NVL(iShimeFrom,ULT_COMMON.ORIGINAL_YMD)||'''
          			AND A.UPD_EIGY_YMD <= '''||iShimeTo||''')
		        OR 
		        	EXISTS (
				            SELECT G.KJN_CD
				            FROM  (
						              SELECT REC_ID, KJN_CD 
						              FROM TT_TIKY_KJN_KINMUSAKI
						              WHERE REC_ID�@= ''01''
						              AND UPD_EIGY_YMD >= '''||NVL(iShimeFrom,ULT_COMMON.ORIGINAL_YMD)||'''
						              AND UPD_EIGY_YMD <= '''||iShimeTo||'''
					              ) G
				            WHERE G.KJN_CD�@= A.KJN_CD  
				          )
			  )
          AND (A.DEL_FLG IS NULL OR B.DEL_FLG IS NULL)';

         vSelectSQL := vSelectSQL||'CASE WHEN NVL(C.UPD_EIGY_YMD,''19700101'')>NVL(A.UPD_EIGY_YMD,''19700101'') THEN C.UPD_EIGY_YMD ELSE A.UPD_EIGY_YMD END AS UPD_EIGY_YMD,
           B.DEL_FLG AS zDEL_FLG,
           CASE WHEN C.COUNT1 = C.INFO_COUNT AND C.COUNT2 != 0 THEN C.KJN_CD ELSE NULL END AS ALL_TAISHOKU_KJN_CD,
           MM.KJN_CD AS KIMUSAKI_HENKO_KJN_CD'||vFromSQL||vWhereSQL;
           -- ������2012/10/03 CP000182�̑Ή��@�d�l�ύX�ɂ��Ώۍ��ځi�Ζ���f�[�^�̕ύX���o�͑ΏۂƂ���j
        
        ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',vSelectSQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);
        OPEN cur FOR vSelectSQL;
        LOOP
          FETCH cur INTO vBAITAI_SHIN_RECORD;
          EXIT WHEN cur%NOTFOUND;
          oROW_COUNT:=oROW_COUNT+1;
          --��r����1�Ɣ�r����2����v���Ă��Ȃ��ꍇ
          IF (vBAITAI_SHIN_RECORD.FIELD1 != vBAITAI_SHIN_RECORD.FIELD2)
            OR vBAITAI_SHIN_RECORD.ALL_TAISHOKU_KJN_CD IS NOT NULL
            OR vBAITAI_SHIN_RECORD.KIMUSAKI_HENKO_KJN_CD IS NOT NULL
            OR (vBAITAI_SHIN_RECORD.DEL_FLG = '1' AND vBAITAI_SHIN_RECORD.zDEL_FLG IS NULL) THEN
            -- ������2012/10/03 �d�l�ύX�ɂ��Ώۍ��ځi�Ζ���f�[�^�̕ύX���o�͑ΏۂƂ���j

            --����f�[�^������A�O��f�[�^���Ȃ��ꍇ�A�ǉ��Ƃ��ēo�^����(��r����2�̐擪��TAB�̏ꍇ)
            IF SUBSTR(vBAITAI_SHIN_RECORD.FIELD2,1,1) = ULT_COMMON.DELIMITER THEN
              vMODKBN  := ULT_COMMON.MOD_KBN_ADD;
            --����f�[�^���폜���ꂽ�ꍇ�A�폜�Ƃ��ēo�^����(��r�p�f�[�^�̍폜�t���O = "1"�̏ꍇ)
            ELSIF vBAITAI_SHIN_RECORD.DEL_FLG = '1' AND vBAITAI_SHIN_RECORD.zDEL_FLG IS NULL THEN
              vMODKBN := ULT_COMMON.MOD_KBN_DEL;
            --�Ζ���S�đގЁA���邢�͍���ƑO��ŕω��̂���f�[�^�͕ύX�Ƃ��ēo�^����
            ELSE
              vMODKBN := ULT_COMMON.MOD_KBN_YES;
            END IF;

            --��r����1���獡��f�[�^�̔z����擾����
            vNowData := ULT_COMMON.StrSplit(vBAITAI_SHIN_RECORD.FIELD1, ULT_COMMON.DELIMITER);

            --�o�^����
            IF iM2Flg = ULT_COMMON.FLG_NO THEN
              --�V_��1����_DCF��t�e�[�u���ɓo�^����B
              INSERT INTO TD_NM_DCF_KJN(
                    LAYOUT_KBN,
                    KJNREC_ID,
                    KJN_CD,
                    MOD_KBN,
                    MENTE_YMD,
                    DEL_YOTEI_RIYU,
                    AITSK_CD_KJNREC_ID,
                    AITSK_CD_KJN_CD,
                    ISHI_NM_KANJI,
                    ISHI_NM_KANA,
                    SEIBETSU,
                    BIRTH_GENGO,
                    BIRTH_Y,
                    BIRTH_M,
                    BIRTH_D,
                    SHUSSHIN_KEN_CD,
                    ISHIKAI_CD,
                    STNEN_GENGO,
                    STNEN_Y,
                    SHUSSHINKO_SHUSSHINKO_CD,
                    SHUSSHINKO_GAKUBU_SKBT_CD,
                    TRKNEN_GENGO,
                    TRKNEN_Y,
                    SNRYKMK_1,
                    SNRYKMK_2,
                    SNRYKMK_3,
                    SNRYKMK_4,
                    SNRYKMK_5,
                    JUSHOFUMEI,
                    JUSHO_CD_KEN_CD,
                    JUSHO_CD_SHIKU_CD,
                    JUSHO_CD_OAZA_CD,
                    JUSHO_CD_AZA_CD,
                    ZIP,
                    JITAKU_JUSHO_KANJI,
                    JITAKU_JUSHO_KANA,
                    JUSHO_HYOJI_NO,
                    JUSHO_COUNT_KANJI_KEN,
                    JUSHO_COUNT_KANJI_SHIKU,
                    JUSHO_COUNT_KANJI_OAZA,
                    JUSHO_COUNT_KANJI_AZA,
                    JUSHO_COUNT_KANA_KEN,
                    JUSHO_COUNT_KANA_SHIKU,
                    JUSHO_COUNT_KANA_OAZA,
                    JUSHO_COUNT_KANA_AZA,
                    JITAKU_TEL,
                    RIYOTEISHI_RIYOTEISHI_KBN,
                    RIYOTEISHI_RIYOTEISHI_RIYU,
                    RIYOTEISHI_TRK_YMD,
                    RIYOTEISHI_KAIJO_YMD,
                    KAIKIN_KBN,
                    KAIGYONEN_GENGO,
                    KAIGYONEN_Y,
                    IKKATSU_TRK_FLG,
                    Trk_Ope_Cd,
                    Trk_Date,
                    Trk_Pgm_Id,
                    Upd_Ope_Cd,
                    Upd_Date,
                    Upd_Pgm_Id
                    )
                  VALUES(
                    vLAYOUT_KBN,
                    vNowData(1),
                    vNowData(2),
                    vMODKBN,
                    vBAITAI_SHIN_RECORD.UPD_EIGY_YMD,
                    vNowData(3),
                    vNowData(4),
                    vNowData(5),
                    vNowData(6),
                    vNowData(7),
                    vNowData(8),
                    vNowData(9),
                    vNowData(10),
                    vNowData(11),
                    vNowData(12),
                    vNowData(13),
                    vNowData(14),
                    vNowData(15),
                    vNowData(16),
                    vNowData(17),
                    vNowData(18),
                    vNowData(19),
                    vNowData(20),
                    vNowData(21),
                    vNowData(22),
                    vNowData(23),
                    vNowData(24),
                    vNowData(25),
                    vNowData(26),
                    vNowData(27),
                    vNowData(28),
                    vNowData(29),
                    vNowData(30),
                    NVL2(vNowData(31),SUBSTR(vNowData(31),1,3)||'-'||SUBSTR(vNowData(31),4),NULL),
                    vNowData(32),
                    vNowData(33),
                    vNowData(34),
                    vNowData(35),--TO_CHAR(vNowData(35),'FM00'),
                    vNowData(36),--TO_CHAR(vNowData(36),'FM00'),
                    vNowData(37),--TO_CHAR(vNowData(37),'FM00'),
                    vNowData(38),--TO_CHAR(vNowData(38),'FM00'),
                    vNowData(39),--TO_CHAR(vNowData(39),'FM00'),
                    vNowData(40),--TO_CHAR(vNowData(40),'FM00'),
                    vNowData(41),--TO_CHAR(vNowData(41),'FM00'),
                    vNowData(42),--TO_CHAR(vNowData(42),'FM00'),
                    vNowData(43),
                    vNowData(44),
                    vNowData(45),
                    vNowData(46),
                    vNowData(47),
                    vNowData(48),
                    vNowData(49),
                    vNowData(50),
                    vNowData(51),
                    iOPE_CD,
                    iDATE,
                    iPGM_ID,
                    iOPE_CD,
                    iDATE,
                    iPGM_ID
                  );
              EXECUTE_SQL := 'INSERT INTO TD_NM_DCF_KJN(';
            ELSE
              --�V_��2����_DCF��t�e�[�u���ɓo�^����B
              INSERT INTO TD_N2_DCF_KJN(
                    LAYOUT_KBN,
                    KJNREC_ID,
                    KJN_CD,
                    MOD_KBN,
                    MENTE_YMD,
                    DEL_YOTEI_RIYU,
                    AITSK_CD_KJNREC_ID,
                    AITSK_CD_KJN_CD,
                    ISHI_NM_KANJI,
                    ISHI_NM_KANA,
                    SEIBETSU,
                    BIRTH_GENGO,
                    BIRTH_Y,
                    BIRTH_M,
                    BIRTH_D,
                    SHUSSHIN_KEN_CD,
                    ISHIKAI_CD,
                    STNEN_GENGO,
                    STNEN_Y,
                    SHUSSHINKO_SHUSSHINKO_CD,
                    SHUSSHINKO_GAKUBU_SKBT_CD,
                    TRKNEN_GENGO,
                    TRKNEN_Y,
                    SNRYKMK_1,
                    SNRYKMK_2,
                    SNRYKMK_3,
                    SNRYKMK_4,
                    SNRYKMK_5,
                    JUSHOFUMEI,
                    JUSHO_CD_KEN_CD,
                    JUSHO_CD_SHIKU_CD,
                    JUSHO_CD_OAZA_CD,
                    JUSHO_CD_AZA_CD,
                    ZIP,
                    JITAKU_JUSHO_KANJI,
                    JITAKU_JUSHO_KANA,
                    JUSHO_HYOJI_NO,
                    JUSHO_COUNT_KANJI_KEN,
                    JUSHO_COUNT_KANJI_SHIKU,
                    JUSHO_COUNT_KANJI_OAZA,
                    JUSHO_COUNT_KANJI_AZA,
                    JUSHO_COUNT_KANA_KEN,
                    JUSHO_COUNT_KANA_SHIKU,
                    JUSHO_COUNT_KANA_OAZA,
                    JUSHO_COUNT_KANA_AZA,
                    JITAKU_TEL,
                    RIYOTEISHI_RIYOTEISHI_KBN,
                    RIYOTEISHI_RIYOTEISHI_RIYU,
                    RIYOTEISHI_TRK_YMD,
                    RIYOTEISHI_KAIJO_YMD,
                    KAIKIN_KBN,
                    KAIGYONEN_GENGO,
                    KAIGYONEN_Y,
                    IKKATSU_TRK_FLG,
                    Trk_Ope_Cd,
                    Trk_Date,
                    Trk_Pgm_Id,
                    Upd_Ope_Cd,
                    Upd_Date,
                    Upd_Pgm_Id
                    )
                  VALUES(
                    vLAYOUT_KBN,
                    vNowData(1),
                    vNowData(2),
                    vMODKBN,
                    vBAITAI_SHIN_RECORD.UPD_EIGY_YMD,
                    vNowData(3),
                    vNowData(4),
                    vNowData(5),
                    vNowData(6),
                    vNowData(7),
                    vNowData(8),
                    vNowData(9),
                    vNowData(10),
                    vNowData(11),
                    vNowData(12),
                    vNowData(13),
                    vNowData(14),
                    vNowData(15),
                    vNowData(16),
                    vNowData(17),
                    vNowData(18),
                    vNowData(19),
                    vNowData(20),
                    vNowData(21),
                    vNowData(22),
                    vNowData(23),
                    vNowData(24),
                    vNowData(25),
                    vNowData(26),
                    vNowData(27),
                    vNowData(28),
                    vNowData(29),
                    vNowData(30),
                    NVL2(vNowData(31),SUBSTR(vNowData(31),1,3)||'-'||SUBSTR(vNowData(31),4),NULL),
                    vNowData(32),
                    vNowData(33),
                    vNowData(34),
                    vNowData(35),--TO_CHAR(vNowData(35),'FM00'),
                    vNowData(36),--TO_CHAR(vNowData(36),'FM00'),
                    vNowData(37),--TO_CHAR(vNowData(37),'FM00'),
                    vNowData(38),--TO_CHAR(vNowData(38),'FM00'),
                    vNowData(39),--TO_CHAR(vNowData(39),'FM00'),
                    vNowData(40),--TO_CHAR(vNowData(40),'FM00'),
                    vNowData(41),--TO_CHAR(vNowData(41),'FM00'),
                    vNowData(42),--TO_CHAR(vNowData(42),'FM00'),
                    vNowData(43),
                    vNowData(44),
                    vNowData(45),
                    vNowData(46),
                    vNowData(47),
                    vNowData(48),
                    vNowData(49),
                    vNowData(50),
                    vNowData(51),
                    iOPE_CD,
                    iDATE,
                    iPGM_ID,
                    iOPE_CD,
                    iDATE,
                    iPGM_ID
                  );
              EXECUTE_SQL := 'INSERT INTO TD_N2_DCF_KJN(';
            END IF;
            EXECUTE_SQL := EXECUTE_SQL||'
                    LAYOUT_KBN,
                    KJNREC_ID,
                    KJN_CD,
                    MOD_KBN,
                    MENTE_YMD,
                    DEL_YOTEI_RIYU,
                    AITSK_CD_KJNREC_ID,
                    AITSK_CD_KJN_CD,
                    ISHI_NM_KANJI,
                    ISHI_NM_KANA,
                    SEIBETSU,
                    BIRTH_GENGO,
                    BIRTH_Y,
                    BIRTH_M,
                    BIRTH_D,
                    SHUSSHIN_KEN_CD,
                    ISHIKAI_CD,
                    STNEN_GENGO,
                    STNEN_Y,
                    SHUSSHINKO_SHUSSHINKO_CD,
                    SHUSSHINKO_GAKUBU_SKBT_CD,
                    TRKNEN_GENGO,
                    TRKNEN_Y,
                    SNRYKMK_1,
                    SNRYKMK_2,
                    SNRYKMK_3,
                    SNRYKMK_4,
                    SNRYKMK_5,
                    JUSHOFUMEI,
                    JUSHO_CD_KEN_CD,
                    JUSHO_CD_SHIKU_CD,
                    JUSHO_CD_OAZA_CD,
                    JUSHO_CD_AZA_CD,
                    ZIP,
                    JITAKU_JUSHO_KANJI,
                    JITAKU_JUSHO_KANA,
                    JUSHO_HYOJI_NO,
                    JUSHO_COUNT_KANJI_KEN,
                    JUSHO_COUNT_KANJI_SHIKU,
                    JUSHO_COUNT_KANJI_OAZA,
                    JUSHO_COUNT_KANJI_AZA,
                    JUSHO_COUNT_KANA_KEN,
                    JUSHO_COUNT_KANA_SHIKU,
                    JUSHO_COUNT_KANA_OAZA,
                    JUSHO_COUNT_KANA_AZA,
                    JITAKU_TEL,
                    RIYOTEISHI_RIYOTEISHI_KBN,
                    RIYOTEISHI_RIYOTEISHI_RIYU,
                    RIYOTEISHI_TRK_YMD,
                    RIYOTEISHI_KAIJO_YMD,
                    KAIKIN_KBN,
                    KAIGYONEN_GENGO,
                    KAIGYONEN_Y,
                    IKKATSU_TRK_FLG,
                    Trk_Ope_Cd,
                    Trk_Date,
                    Trk_Pgm_Id,
                    Upd_Ope_Cd,
                    Upd_Date,
                    Upd_Pgm_Id)
                  VALUES(
                    '''||vLAYOUT_KBN||''',
                    '''||vNowData(1)||''',
                    '''||vNowData(2)||''',
                    '''||vMODKBN||''',
                    '''||vBAITAI_SHIN_RECORD.UPD_EIGY_YMD||''',
                    '''||vNowData(3)||''',
                    '''||vNowData(4)||''',
                    '''||vNowData(5)||''',
                    '''||vNowData(6)||''',
                    '''||vNowData(7)||''',
                    '''||vNowData(8)||''',
                    '''||vNowData(9)||''',
                    '''||vNowData(10)||''',
                    '''||vNowData(11)||''',
                    '''||vNowData(12)||''',
                    '''||vNowData(13)||''',
                    '''||vNowData(14)||''',
                    '''||vNowData(15)||''',
                    '''||vNowData(16)||''',
                    '''||vNowData(17)||''',
                    '''||vNowData(18)||''',
                    '''||vNowData(19)||''',
                    '''||vNowData(20)||''',
                    '''||vNowData(21)||''',
                    '''||vNowData(22)||''',
                    '''||vNowData(23)||''',
                    '''||vNowData(24)||''',
                    '''||vNowData(25)||''',
                    '''||vNowData(26)||''',
                    '''||vNowData(27)||''',
                    '''||vNowData(28)||''',
                    '''||vNowData(29)||''',
                    '''||vNowData(30)||''',
                    '''||CASE WHEN vNowData(31) IS NOT NULL THEN SUBSTR(vNowData(31),1,3)||'-'||SUBSTR(vNowData(31),4) ELSE NULL END ||''',
                    '''||vNowData(32)||''',
                    '''||vNowData(33)||''',
                    '''||vNowData(34)||''',
                    '''||TO_CHAR(vNowData(35),'FM00')||''',
                    '''||TO_CHAR(vNowData(36),'FM00')||''',
                    '''||TO_CHAR(vNowData(37),'FM00')||''',
                    '''||TO_CHAR(vNowData(38),'FM00')||''',
                    '''||TO_CHAR(vNowData(39),'FM00')||''',
                    '''||TO_CHAR(vNowData(40),'FM00')||''',
                    '''||TO_CHAR(vNowData(41),'FM00')||''',
                    '''||TO_CHAR(vNowData(42),'FM00')||''',
                    '''||vNowData(43)||''',
                    '''||vNowData(44)||''',
                    '''||vNowData(45)||''',
                    '''||vNowData(46)||''',
                    '''||vNowData(47)||''',
                    '''||vNowData(48)||''',
                    '''||vNowData(49)||''',
                    '''||vNowData(50)||''',
                    '''||vNowData(51)||''',
                    '''||iOPE_CD||''',
                    '''||iDATE||''',
                    '''||iPGM_ID||''',
                    '''||iOPE_CD||''',
                    '''||iDATE||''',
                    '''||iPGM_ID||''')';
            ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);
          END IF;

        END LOOP;
        CLOSE cur;

     ELSIF iShimeKind = ULT_COMMON.SHIME_SBT_CD_SHUSHIME AND iLayoutKind = ULT_COMMON.LAYOUT_SBT_CD_ZANTEI THEN
        --�b��_�T����_DCF��t�e�[�u���̃f�[�^���N���A����B
        EXECUTE_SQL := 'TRUNCATE TABLE ' || vSchemaNm || '.' || 'TD_PW_DCF_KJN';
        EXECUTE IMMEDIATE EXECUTE_SQL;
        ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

        -- �b��_�T����_���p��~(DCF��t)�e�[�u���̃f�[�^���N���A����B
        EXECUTE_SQL := 'TRUNCATE TABLE ' || vSchemaNm || '.' || 'TD_PW_DCF_KJN_TIS';
        EXECUTE IMMEDIATE EXECUTE_SQL;
        ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

        --�b��_�T����_�w�����e�[�u���̃f�[�^���N���A����B
        EXECUTE_SQL := 'TRUNCATE TABLE ' || vSchemaNm || '.' || 'TD_PW_DCF_KJN_SENMONI';
        EXECUTE IMMEDIATE EXECUTE_SQL;
        ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

        EXECUTE_SQL := 'SELECT
          A.REC_ID||ULT_COMMON.DELIMITER||
          A.KJN_CD||ULT_COMMON.DELIMITER||
          A.KJN_NM_KANA||ULT_COMMON.DELIMITER||
          A.KJN_NM||ULT_COMMON.DELIMITER||
          A.SEIBETSU_KBN||ULT_COMMON.DELIMITER||
          A.BIRTH_GENGO_CD||ULT_COMMON.DELIMITER||
          A.BIRTH_WY||ULT_COMMON.DELIMITER||
          A.BIRTH_M||ULT_COMMON.DELIMITER||
          A.BIRTH_D||ULT_COMMON.DELIMITER||
          A.SHUSSHINCHI_RIDAI_CD||ULT_COMMON.DELIMITER||
          A.KANYU_ISHIKAI_RIDAI_CD||ULT_COMMON.DELIMITER||
          A.STNEN_GENGO_CD||ULT_COMMON.DELIMITER||
          A.STNEN_WY||ULT_COMMON.DELIMITER||
          A.SHUSSHINKO_CD||ULT_COMMON.DELIMITER||
          A.GAKUBU_SHIKIBETSU_KBN||ULT_COMMON.DELIMITER||
          A.KAIKIN_KBN||ULT_COMMON.DELIMITER||
          A.KAIGYONEN_GENGO_CD||ULT_COMMON.DELIMITER||
          A.KAIGYONEN_WY||ULT_COMMON.DELIMITER||
          A.SNRYKMK_CD_1||ULT_COMMON.DELIMITER||
          A.SNRYKMK_CD_2||ULT_COMMON.DELIMITER||
          A.SNRYKMK_CD_3||ULT_COMMON.DELIMITER||
          A.SNRYKMK_CD_4||ULT_COMMON.DELIMITER||
          A.SNRYKMK_CD_5||ULT_COMMON.DELIMITER||
          A.TEL||ULT_COMMON.DELIMITER||
          A.JUSHOFUMEI_CD||ULT_COMMON.DELIMITER||
          A.DEL_YOTEI_RIYU_CD||ULT_COMMON.DELIMITER||
          A.IKKATSU_TRK_FLG||ULT_COMMON.DELIMITER||
          A.CHOFUKU_AITSK_REC_ID||ULT_COMMON.DELIMITER||
          A.CHOFUKU_AITSK_KJN_CD||ULT_COMMON.DELIMITER||
          A.TRKNEN_GENGO_CD||ULT_COMMON.DELIMITER||
          A.TRKNEN_WY||ULT_COMMON.DELIMITER||
          A.JUSHO_KANA_RENKETSU||ULT_COMMON.DELIMITER||
          A.JUSHO_KANJI_RENKETSU||ULT_COMMON.DELIMITER||
          A.KEN_CD||ULT_COMMON.DELIMITER||
          A.SHIKU_CD||ULT_COMMON.DELIMITER||
          A.OAZA_CD||ULT_COMMON.DELIMITER||
          A.AZA_CD||ULT_COMMON.DELIMITER||
          A.ZIP||ULT_COMMON.DELIMITER||
          A.JUSHO_HYOJI_NO||ULT_COMMON.DELIMITER||
          A.KEN_NM_KANA_MOJI_SU||ULT_COMMON.DELIMITER||
          A.SHIKU_NM_KANA_MOJI_SU||ULT_COMMON.DELIMITER||
          A.OAZA_NM_KANA_MOJI_SU||ULT_COMMON.DELIMITER||
          A.KEN_NM_KANJI_MOJI_SU||ULT_COMMON.DELIMITER||
          A.SHIKU_NM_KANJI_MOJI_SU||ULT_COMMON.DELIMITER||
          A.OAZA_NM_KANJI_MOJI_SU||ULT_COMMON.DELIMITER||
          A.AZA_NM_KANA_MOJI_SU||ULT_COMMON.DELIMITER||
          A.AZA_NM_KANJI_MOJI_SU||ULT_COMMON.DELIMITER||
          B.KINMUSAKI_REC_ID||ULT_COMMON.DELIMITER||
          B.KINMUSAKI_SHI_CD||ULT_COMMON.DELIMITER||
          B.YAKUSHOKU_CD||ULT_COMMON.DELIMITER||
          B.SHOKUI_CD||ULT_COMMON.DELIMITER||
          B.KINMUSAKI_DM_FUKA_FLG||ULT_COMMON.DELIMITER||
          B.TAISHOKU_FLG AS FIELD1,
          E.REC_ID||ULT_COMMON.DELIMITER||
          E.KJN_CD||ULT_COMMON.DELIMITER||
          E.KJN_NM_KANA||ULT_COMMON.DELIMITER||
          E.KJN_NM||ULT_COMMON.DELIMITER||
          E.SEIBETSU_KBN||ULT_COMMON.DELIMITER||
          E.BIRTH_GENGO_CD||ULT_COMMON.DELIMITER||
          E.BIRTH_WY||ULT_COMMON.DELIMITER||
          E.BIRTH_M||ULT_COMMON.DELIMITER||
          E.BIRTH_D||ULT_COMMON.DELIMITER||
          E.SHUSSHINCHI_RIDAI_CD||ULT_COMMON.DELIMITER||
          E.KANYU_ISHIKAI_RIDAI_CD||ULT_COMMON.DELIMITER||
          E.STNEN_GENGO_CD||ULT_COMMON.DELIMITER||
          E.STNEN_WY||ULT_COMMON.DELIMITER||
          E.SHUSSHINKO_CD||ULT_COMMON.DELIMITER||
          E.GAKUBU_SHIKIBETSU_KBN||ULT_COMMON.DELIMITER||
          E.KAIKIN_KBN||ULT_COMMON.DELIMITER||
          E.KAIGYONEN_GENGO_CD||ULT_COMMON.DELIMITER||
          E.KAIGYONEN_WY||ULT_COMMON.DELIMITER||
          E.SNRYKMK_CD_1||ULT_COMMON.DELIMITER||
          E.SNRYKMK_CD_2||ULT_COMMON.DELIMITER||
          E.SNRYKMK_CD_3||ULT_COMMON.DELIMITER||
          E.SNRYKMK_CD_4||ULT_COMMON.DELIMITER||
          E.SNRYKMK_CD_5||ULT_COMMON.DELIMITER||
          E.TEL||ULT_COMMON.DELIMITER||
          E.JUSHOFUMEI_CD||ULT_COMMON.DELIMITER||
          E.DEL_YOTEI_RIYU_CD||ULT_COMMON.DELIMITER||
          E.IKKATSU_TRK_FLG||ULT_COMMON.DELIMITER||
          E.CHOFUKU_AITSK_REC_ID||ULT_COMMON.DELIMITER||
          E.CHOFUKU_AITSK_KJN_CD||ULT_COMMON.DELIMITER||
          E.TRKNEN_GENGO_CD||ULT_COMMON.DELIMITER||
          E.TRKNEN_WY||ULT_COMMON.DELIMITER||
          E.JUSHO_KANA_RENKETSU||ULT_COMMON.DELIMITER||
          E.JUSHO_KANJI_RENKETSU||ULT_COMMON.DELIMITER||
          E.KEN_CD||ULT_COMMON.DELIMITER||
          E.SHIKU_CD||ULT_COMMON.DELIMITER||
          E.OAZA_CD||ULT_COMMON.DELIMITER||
          E.AZA_CD||ULT_COMMON.DELIMITER||
          E.ZIP||ULT_COMMON.DELIMITER||
          E.JUSHO_HYOJI_NO||ULT_COMMON.DELIMITER||
          E.KEN_NM_KANA_MOJI_SU||ULT_COMMON.DELIMITER||
          E.SHIKU_NM_KANA_MOJI_SU||ULT_COMMON.DELIMITER||
          E.OAZA_NM_KANA_MOJI_SU||ULT_COMMON.DELIMITER||
          E.KEN_NM_KANJI_MOJI_SU||ULT_COMMON.DELIMITER||
          E.SHIKU_NM_KANJI_MOJI_SU||ULT_COMMON.DELIMITER||
          E.OAZA_NM_KANJI_MOJI_SU||ULT_COMMON.DELIMITER||
          E.AZA_NM_KANA_MOJI_SU||ULT_COMMON.DELIMITER||
          E.AZA_NM_KANJI_MOJI_SU||ULT_COMMON.DELIMITER||
          F.KINMUSAKI_REC_ID||ULT_COMMON.DELIMITER||
          F.KINMUSAKI_SHI_CD||ULT_COMMON.DELIMITER||
          F.YAKUSHOKU_CD||ULT_COMMON.DELIMITER||
          F.SHOKUI_CD||ULT_COMMON.DELIMITER||
          F.KINMUSAKI_DM_FUKA_FLG||ULT_COMMON.DELIMITER||
          F.TAISHOKU_FLG AS FIELD2,
          A.DEL_FLG AS DEL_FLG,
          B.SZKBUKA_CD AS SZKBUKA_CD1,
          DECODE(B.SZKBUKA_CD, ''9999'', B.NYURYOKU_SZKBUKA_NM_KANA, D.SZKBUKA_NM_KANA) AS SZKBUKA_NM_KANA1,
          DECODE(B.SZKBUKA_CD, ''9999'', B.NYURYOKU_SZKBUKA_NM, D.SZKBUKA_NM) AS SZKBUKA_NM1,
          F.SZKBUKA_CD AS SZKBUKA_CD2,
          DECODE(F.SZKBUKA_CD, ''9999'', F.NYURYOKU_SZKBUKA_NM_KANA, H.SZKBUKA_NM_KANA) AS SZKBUKA_NM_KANA2,
          DECODE(F.SZKBUKA_CD, ''9999'', F.NYURYOKU_SZKBUKA_NM, H.SZKBUKA_NM) AS SZKBUKA_NM2,
          X.MAX_UPD_EIGY_YMD AS UPD_EIGY_YMD
        FROM TT_TIKY_KJN A
        LEFT OUTER JOIN TT_TIKY_KJN_KINMUSAKI B
          ON A.REC_ID = B.REC_ID
          AND A.KJN_CD = B.KJN_CD
        LEFT OUTER JOIN TM_TIKY_HIFG_SSY_SZKBUKA D
          ON B.SZKBUKA_CD = D.SZKBUKA_CD
        LEFT OUTER JOIN TT_Z_W_KJN E
          ON A.REC_ID = E.REC_ID
          AND A.KJN_CD = E.KJN_CD
        LEFT OUTER JOIN TT_Z_W_KJN_KINMUSAKI F
          ON A.REC_ID = F.REC_ID
          AND A.KJN_CD = F.KJN_CD
          AND B.KINMUSAKI_REC_ID = F.KINMUSAKI_REC_ID
          AND B.KINMUSAKI_SHI_CD = F.KINMUSAKI_SHI_CD
        LEFT OUTER JOIN TM_Z_W_HIFG_SSY_SZKBUKA H
          ON F.SZKBUKA_CD = H.SZKBUKA_CD
        LEFT OUTER JOIN (
          SELECT Y.KJN_CD,
            MAX(CASE WHEN Y.UPD_EIGY_YMD||''1''>Z.UPD_EIGY_YMD||''1'' THEN Y.UPD_EIGY_YMD ELSE Z.UPD_EIGY_YMD END) AS MAX_UPD_EIGY_YMD
          FROM TT_TIKY_KJN Y
          LEFT OUTER JOIN TT_TIKY_KJN_KINMUSAKI Z
            ON Y.REC_ID = Z.REC_ID
           AND Y.KJN_CD = Z.KJN_CD
          WHERE Y.REC_ID = ''01''
            AND ((Y.UPD_EIGY_YMD >= '''||NVL(iShimeFrom,ULT_COMMON.ORIGINAL_YMD)||''' AND Y.UPD_EIGY_YMD <= '''||iShimeTo||''')
             OR (Z.UPD_EIGY_YMD >= '''||NVL(iShimeFrom,ULT_COMMON.ORIGINAL_YMD)||''' AND Z.UPD_EIGY_YMD <=  '''||iShimeTo||'''))
          GROUP BY Y.KJN_CD) X
        ON A.KJN_CD = X.KJN_CD
      WHERE A.REC_ID = ''01''
        AND ((A.UPD_EIGY_YMD >= '''||NVL(iShimeFrom,ULT_COMMON.ORIGINAL_YMD)||''' AND A.UPD_EIGY_YMD <= '''||iShimeTo||''')
          OR (B.UPD_EIGY_YMD >= '''||NVL(iShimeFrom,ULT_COMMON.ORIGINAL_YMD)||''' AND B.UPD_EIGY_YMD <= '''||iShimeTo||'''))
        AND (A.DEL_FLG IS NULL OR (E.REC_ID IS NOT NULL AND E.DEL_FLG IS NULL))
        AND ((E.REC_ID IS NULL AND B.Taishoku_Flg IS NULL) OR (E.REC_ID IS NOT NULL))';
      ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

        -- �擾�����b��_�T����_DCF��t�̔�r�p�f�[�^���������J��Ԃ�
        OPEN weekDcfCSR ;
        LOOP
          FETCH weekDcfCSR INTO weekDcfRow;
          EXIT WHEN weekDcfCSR%NOTFOUND;
          oROW_COUNT:=oROW_COUNT+1;
          vTAISHOKU_FLG:=ULT_COMMON.TAISHOKU_FLG_HENKOU;
          
          --����ƑO��ŕω��̂Ȃ��f�[�^�͓o�^���Ȃ�
          IF NVL(weekDcfRow.DEL_FLG,'0') = '1' OR
            weekDcfRow.Field1 != weekDcfRow.Field2 OR
            (NVL(weekDcfRow.Szkbuka_Cd1,0)!=NVL(weekDcfRow.Szkbuka_Cd2,0)) OR
            (NVL(weekDcfRow.Szkbuka_Cd1,0) = NVL(weekDcfRow.Szkbuka_Cd2,0) AND NVL(weekDcfRow.Szkbuka_Cd1,'0') = '9999' AND
             (NVL(weekDcfRow.Szkbuka_Nm_Kana1,0) !=NVL(weekDcfRow.Szkbuka_Nm_Kana2,0) OR NVL(weekDcfRow.Szkbuka_Nm1,0) != NVL(weekDcfRow.Szkbuka_Nm2,0)))
          THEN
            --����f�[�^������A�O��f�[�^���Ȃ��ꍇ�A�ǉ��Ƃ��ēo�^����(��r����2�̐擪��TAB�̏ꍇ)
            IF SUBSTR(weekDcfRow.FIELD2,1,1) = ULT_COMMON.DELIMITER THEN
              
              --��r����1���獡��f�[�^�̔z����擾����
              vNowData := ULT_COMMON.StrSplit(weekDcfRow.FIELD1, ULT_COMMON.DELIMITER);
              vLastData:= ULT_COMMON.StrSplit(weekDcfRow.FIELD2, ULT_COMMON.DELIMITER);
              
              -- ����ǉ����ꂽ�Ζ���f�[�^���ސE�ςł���ꍇ�́A�����ΏۂƂ��Ȃ�
              IF vLastData(48) IS NULL
                AND vNowData(53) IS NOT NULL THEN
                
                -- �����̋Ζ��悪���݂��邩���m�F����
                SELECT
                    COUNT(REC_ID)
                INTO
                    nKINMUSAKI_REC_CNT
                FROM
                    TT_TIKY_KJN_KINMUSAKI
                WHERE
                    REC_ID = vNowData(1)
                AND KJN_CD = vNowData(2)
                AND TAISHOKU_FLG IS NULL
                ;

                -- �����̋Ζ��悪���݂���ꍇ�́A�Y���̋Ζ���������ΏۂƂ��Ȃ�
                IF nKINMUSAKI_REC_CNT > 0 THEN
                    -- ���̃��R�[�h����������
                    CONTINUE;
                ELSE
                  -- ����ǉ����ꂽ�ސE�ς݂̋Ζ�������N���A���ď������s��
                  -- �i�V�K�ǉ��ȂǁA�l���̕ω��ɂ��č��������쐬����K�v������j
                  FOR i IN 48..56 LOOP
                    vNowData(i):=NULL;
                  END LOOP;
                END IF;
              END IF;
              
              -- �Ζ��悪���݂��Ȃ��ꍇ�́A�_�~�[���R�[�h��ݒ�
              IF vNowData(48) IS NULL THEN
                  vNowData(48):='00';
                  vNowData(49):='9999999';
              END IF;
              
              -- �C���敪�i�`�j�ƑސE�ړ��t���O�i�Q�F�ٓ��j��ݒ�
              vMODKBN  := ULT_COMMON.MOD_KBN_ADD;
              vTAISHOKU_FLG :=ULT_COMMON.TAISHOKU_FLG_IDOU;

              --�������ȃR�[�h�A�������ȁi�J�i�j�A�������ȁi�����j��z��ɂ����
              vNowData(54):=weekDcfRow.Szkbuka_Cd1;
              vNowData(55):=weekDcfRow.Szkbuka_Nm_Kana1;
              vNowData(56):=weekDcfRow.Szkbuka_Nm1;
              
              -- �X�֔ԍ��ҏW
              IF vNowData(38) IS NULL THEN
              	NULL;
              ELSIF vNowData(38) != ULT_COMMON.INSERT_HALF_DEFAULT THEN
                vNowData(38):=SUBSTR(vNowData(38),1,3)||'-'||SUBSTR(vNowData(38),4);
              END IF;
              
            --����f�[�^���폜���ꂽ�ꍇ�A�ސE�Ƃ��ēo�^����i��r�p�f�[�^�̍폜�t���O = "1"�̏ꍇ�j
            ELSIF NVL(weekDcfRow.DEL_FLG,'0') = '1' THEN
              vMODKBN := ULT_COMMON.MOD_KBN_DEL;

              IF SUBSTR(weekDcfRow.FIELD1,1,9) != vLastRecord THEN

                --�b��_�T����_DCF��t�e�[�u���ɓo�^����B
                INSERT INTO TD_PW_DCF_KJN(KJNREC_ID,KJN_CD,MOD_KBN,KINMUSAKI_SHIREC_ID,KINMUSAKI_SHI_CD,MOD_SHORI_YMD_Y,MOD_SHORI_YMD_M,MOD_SHORI_YMD_D,TENSO_Y,TENSO_M,TENSO_D,TRK_OPE_CD,TRK_DATE,TRK_PGM_ID,UPD_OPE_CD,UPD_DATE,UPD_PGM_ID)
                VALUES(SUBSTR(weekDcfRow.FIELD1,1,2),SUBSTR(weekDcfRow.FIELD1,4,6),vMODKBN,'00','9999999',SUBSTR(weekDcfRow.UPD_EIGY_YMD,1,4),SUBSTR(weekDcfRow.UPD_EIGY_YMD,5,2),SUBSTR(weekDcfRow.UPD_EIGY_YMD,7,2),SUBSTR(iTensoYMD,1,4),SUBSTR(iTensoYMD,5,2),SUBSTR(iTensoYMD,7,2),iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

                EXECUTE_SQL := 'INSERT INTO TD_PW_DCF_KJN(KJNREC_ID,KJN_CD,MOD_KBN,KINMUSAKI_SHIREC_ID,KINMUSAKI_SHI_CD,MOD_SHORI_YMD_Y,MOD_SHORI_YMD_M,MOD_SHORI_YMD_D,TENSO_Y,TENSO_M,TENSO_D,TRK_OPE_CD,TRK_DATE,TRK_PGM_ID,UPD_OPE_CD,UPD_DATE,UPD_PGM_ID)
                VALUES('''||SUBSTR(weekDcfRow.FIELD1,1,2)||''','''||SUBSTR(weekDcfRow.FIELD1,4,6)||''','''||vMODKBN||''','''||'00'||''','''||'9999999'||''','''||
                SUBSTR(weekDcfRow.UPD_EIGY_YMD,1,4)||''','''||SUBSTR(weekDcfRow.UPD_EIGY_YMD,5,2)||''','''||SUBSTR(weekDcfRow.UPD_EIGY_YMD,7,2)||''','''||
                SUBSTR(iTensoYMD,1,4)||''','''||SUBSTR(iTensoYMD,5,2)||''','''||SUBSTR(iTensoYMD,7,2)||''','''||iOPE_CD||''','''||iDATE||''','''||iPGM_ID||''','''||iOPE_CD||''','''||iDATE||''','''||iPGM_ID||''')';
                ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);
              END IF;

              vLastRecord:=SUBSTR(weekDcfRow.FIELD1,1,9);

            --����ƑO��ŕω��̂���f�[�^�͕ύX�Ƃ��ēo�^����i��r����1�Ɣ�r����2����v���Ă��Ȃ��ꍇ�j
            ELSE
              
              vMODKBN := ULT_COMMON.MOD_KBN_YES;
              
              --��r���ڂ��獡��f�[�^�̔z��ƑO��f�[�^�̔z����擾����
              vNowData := ULT_COMMON.StrSplit(weekDcfRow.FIELD1, ULT_COMMON.DELIMITER);
              vLastData:= ULT_COMMON.StrSplit(weekDcfRow.FIELD2, ULT_COMMON.DELIMITER);
              --�������ȃR�[�h�A�������ȁi�J�i�j�A�������ȁi�����j��z��ɂ����
              vNowData(54):=weekDcfRow.Szkbuka_Cd1;
              vLastData(54):=weekDcfRow.Szkbuka_Cd2;
              vNowData(55):=weekDcfRow.Szkbuka_Nm_Kana1;
              vLastData(55):=weekDcfRow.Szkbuka_Nm_Kana2;
              vNowData(56):=weekDcfRow.Szkbuka_Nm1;
              vLastData(56):=weekDcfRow.Szkbuka_Nm2;
              
              --�폜�\�藝�R�R�[�h�A�d�������R�[�h�̂����ꂩ�ɕύX���������ꍇ�A
              IF NVL(vNowData(26),0) != NVL(vLastData(26),0) OR NVL(vNowData(28),0) != NVL(vLastData(28),0) OR NVL(vNowData(29),0) != NVL(vLastData(29),0) THEN
                IF vNowData(26) IS NULL AND vLastData(26) IS NOT NULL THEN
                   vNowData(26):= ULT_COMMON.INSERT_HALF_DEFAULT;
                END IF;
                IF vNowData(28) IS NULL AND vLastData(28) IS NOT NULL AND vNowData(29) IS NULL AND vLastData(29) IS NOT NULL THEN
                   vNowData(28):= ULT_COMMON.INSERT_HALF_DEFAULT;
                END IF;
                IF vNowData(25) IS NULL AND vLastData(25) IS NOT NULL THEN
                   vNowData(25):= ULT_COMMON.INSERT_HALF_DEFAULT;
                END IF;
              ELSE
                vNowData(26):=NULL;
                vNowData(28):=NULL;
                vNowData(29):=NULL;
                --�Z���s���R�[�h
                IF NVL(vNowData(25),0) != NVL(vLastData(25),0) THEN
                  IF vNowData(25) IS NULL AND vLastData(25) IS NOT NULL THEN
                    vNowData(25):= ULT_COMMON.INSERT_HALF_DEFAULT;
                  END IF;
                ELSE
                  vNowData(25) := NULL;
                END IF;
              END IF;

              --����f�[�^�̏Z���R�[�h�i���R�[�h�A�s�����R�[�h�A�厚�E�ʏ̃R�[�h�A�����ڃR�[�h�j�A�Z���i�����A�J�i�j�A�X�֔ԍ��A�Z���\���ԍ��A
              --�Z���J�E���g�i�����A�J�i�j�̂����ꂩ�ɕύX���������ꍇ�́A�Z���f�[�^(TAGNO.02)�̑S���ڂ��o��
              vRet:=0;
              FOR i IN 32..47 LOOP
                IF NVL(vNowData(i),0)!=NVL(vLastData(i),0) THEN
                  vRet:=1;
                  EXIT;
                END IF;
              END LOOP;
              IF vRet = 0 THEN
                FOR i IN 32..47 LOOP
                  vNowData(i):=NULL;
                END LOOP;
              ELSE
                --�����l����
                IF vNowData(32) IS NULL AND vLastData(32) IS NOT NULL THEN
                  vNowData(32):=ULT_COMMON.INSERT_HALF_DEFAULT;
                END IF;
                IF vNowData(33) IS NULL AND vLastData(33) IS NOT NULL THEN
                  vNowData(33):=ULT_COMMON.INSERT_FULL_DEFAULT;
                END IF;
                IF vNowData(38) IS NULL AND vLastData(38) IS NOT NULL THEN
                  vNowData(38):=ULT_COMMON.INSERT_HALF_DEFAULT;
                END IF;
                IF vNowData(39) IS NULL AND vLastData(39) IS NOT NULL THEN
                  vNowData(39):=ULT_COMMON.INSERT_HALF_DEFAULT;
                END IF;
              END IF;

              -- �X�֔ԍ��ҏW
              IF vNowData(38) IS NULL THEN
              	NULL;
              ELSIF vNowData(38) != ULT_COMMON.INSERT_HALF_DEFAULT THEN
                vNowData(38):=SUBSTR(vNowData(38),1,3)||'-'||SUBSTR(vNowData(38),4);
              END IF;

              --����f�[�^�̋Ζ���f�[�^�iTAGNO.03�j�̍��ڂ̈ꕔ�ɕύX���������ꍇ�́A�Ζ���f�[�^�iTAGNO.03�j�̑S���ڂ��o��
              vRet:=0;
              FOR i IN 50..54 LOOP
                IF NVL(vNowData(i),0)!=NVL(vLastData(i),0) THEN
                  vRet:=1;
                  EXIT;
                END IF;
              END LOOP;
              IF vRet = 0 THEN
                IF vNowData(54) = '9999'
                AND ((NVL(vNowData(55),'0') != NVL(vLastData(55),'0') OR NVL(vNowData(56),'0') != NVL(vLastData(56),'0'))) THEN
                  vRet:=1;
                END IF;
              END IF;
              
              -- ������2012/10/26 CP000169�̑Ή�
              -- 2012/10/05 �ސE�t���O�̔��f��ǉ�����
              IF vNowData(48) IS NULL AND vLastData(48) IS NULL THEN
                  vNowData(48):='00';
                  vNowData(49):='9999999';
                  vRet:=0;
              ELSIF vNowData(48) IS NOT NULL AND vLastData(48) IS NULL THEN
              	IF NVL(vNowData(53), '0')='1'THEN
              		vRet:=0;
              	ELSE
              		vTAISHOKU_FLG :=ULT_COMMON.TAISHOKU_FLG_IDOU;
              		vRet:=1;
              	END IF;
              ELSIF vNowData(48) IS NOT NULL AND vLastData(48) IS NOT NULL THEN
                IF NVL(vNowData(53), '0')='1' AND NVL(vLastData(53), '0')='1'THEN
                   vRet:=0;
                ELSIF NVL(vNowData(53), '0')='1' AND NVL(vLastData(53), '0')='0' THEN
                   vTAISHOKU_FLG :=ULT_COMMON.TAISHOKU_FLG_TAISHOKU;
                   vRet:=0;
                ELSIF NVL(vNowData(53), '0')='0' AND NVL(vLastData(53), '0')='1' THEN
                   vTAISHOKU_FLG :=ULT_COMMON.TAISHOKU_FLG_IDOU;
                   vRet:=1;
            	END IF;
              END IF;
              -- 2012/10/05 �ސE�t���O�̔��f��ǉ�����
              -- ������2012/10/26 CP000169�̑Ή�
          
              IF vRet = 0 THEN
                FOR i IN 50..56 LOOP
                  vNowData(i):=NULL;
                END LOOP;
              ELSE
              	-- ������2012/10/26 CP000169�̑Ή�
              	IF NVL(vTAISHOKU_FLG, ULT_COMMON.TAISHOKU_FLG_HENKOU) != ULT_COMMON.TAISHOKU_FLG_IDOU THEN
              		--�����l����
	                IF vNowData(50) IS NULL AND vLastData(50) IS NOT NULL THEN
	                  vNowData(50):=ULT_COMMON.INSERT_HALF_DEFAULT;
	                END IF;
	                IF vNowData(51) IS NULL AND vLastData(51) IS NOT NULL THEN
	                  vNowData(51):=ULT_COMMON.INSERT_HALF_DEFAULT;
	                END IF;
	                IF vNowData(52) IS NULL AND vLastData(52) IS NOT NULL THEN
	                  vNowData(52):=ULT_COMMON.INSERT_HALF_DEFAULT;
	                END IF;
	                IF NVL(vNowData(54),'0')='9999' AND NVL(vLastData(54),'0')!='9999' THEN
	                  vNowData(54):=ULT_COMMON.INSERT_HALF_DEFAULT;
	                END IF;
	                IF vNowData(55) IS NULL AND vLastData(55) IS NOT NULL THEN
	                  vNowData(55):=ULT_COMMON.INSERT_HALF_DEFAULT;
	                END IF;
	                IF vNowData(56) IS NULL AND vLastData(56) IS NOT NULL THEN
	                  vNowData(56):=ULT_COMMON.INSERT_FULL_DEFAULT;
	                END IF;
              	END IF;
              	-- ������2012/10/26 CP000169�̑Ή� 
              END IF;

              --NULL�ݒ�(��W���A�����l�Ȃ�)
              editInfo1:=EditInfoArray(3,4,5,10,11,16,27);
              ChangeToNull(vNowData,vLastData,editInfo1);
              --�����l�ݒ�(��W���A�����l����)
              editInfo2:=EditInfoArray(24);
              ChangeToDefault(vNowData,vLastData,editInfo2);
              --NULL�ݒ�(�W���A�����l�Ȃ�)
              editInfoArray1:=EditInfoArrayArray(
                              EditInfoArray(14,15)
              );
              ChangeToNullForArray(vNowData,vLastData,editInfoArray1);
              --�����l�ݒ�(�W���A�����l����)
              editInfoArray2:=EditInfoArrayArray(
                              EditInfoArray(6,7,8,9),
                              EditInfoArray(12,13),
                              EditInfoArray(17,18),
                              EditInfoArray(19,20,21,22,23),
                              EditInfoArray(30,31)
              );
              ChangeToDefaultForArray(vNowData,vLastData,editInfoArray2);

            END IF;

            --�o�^����
            IF vMODKBN != ULT_COMMON.MOD_KBN_DEL 
              AND ((vLastDcfKey != vNowData(1)||vNowData(2)||vNowData(48)||vNowData(49)
              AND nvl(vNowData(48)||vNowData(49),'0') != '009999999')
              OR (vLastRecord != SUBSTR(weekDcfRow.FIELD1,1,9) AND nvl(vNowData(48)||vNowData(49),'0') = '009999999'))
            THEN
              INSERT INTO TD_PW_DCF_KJN(
                KJNREC_ID,
                KJN_CD,
                ISHI_NM_KANA,
                ISHI_NM_KANJI,
                SEIBETSU,
                BIRTH_GENGO,
                BIRTH_Y,
                BIRTH_M,
                BIRTH_D,
                SHUSSHIN_KEN_CD,
                ISHIKAI_CD,
                STNEN_GENGO,
                STNEN_Y,
                SHUSSHINKO_SHUSSHINKO_CD,
                SHUSSHINKO_GAKUBU_SKBT_CD,
                KAIKIN_KBN,
                KAIGYONEN_GENGO,
                KAIGYONEN_Y,
                SNRYKMK_1,
                SNRYKMK_2,
                SNRYKMK_3,
                SNRYKMK_4,
                SNRYKMK_5,
                JITAKU_TEL,
                STATUS_JUSHOFUMEI,
                STATUS_DEL_YOTEI_RIYU,
                STATUS_IKKATSU_TRK_FLG,
                AITSK_CD_KJNREC_ID,
                AITSK_CD_KJN_CD,
                TRKNEN_GENGO,
                TRKNEN_Y,
                JITAKU_JUSHO_KANA,
                JITAKU_JUSHO_KANJI,
                JUSHO_CD_KEN_CD,
                JUSHO_CD_SHIKU_CD,
                JUSHO_CD_OAZA_CD,
                JUSHO_CD_AZA_CD,
                ZIP,
                JUSHO_HYOJI_NO,
                JUSHO_COUNT_KANA_KEN,
                JUSHO_COUNT_KANA_SHIKU,
                JUSHO_COUNT_KANA_OAZA,
                JUSHO_COUNT_KANJI_KEN,
                JUSHO_COUNT_KANJI_SHIKU,
                JUSHO_COUNT_KANJI_OAZA,
                JUSHO_COUNT_KANA_AZA,
                JUSHO_COUNT_KANJI_AZA,
                KINMUSAKI_SHIREC_ID,
                KINMUSAKI_SHI_CD,
                KINMUSAKI_YAKUSHOKU_CD,
                KINMUSAKI_SHOKUI,
                DM_FUKA_FLG,
                KINMUSAKI_SZKBUKA_CD,
                SZKBUKA_KANA,
                SZKBUKA_KANJI,
                TAISHOKU_IDO_FLG,
                TENSO_Y,
                TENSO_M,
                TENSO_D,
                MOD_SHORI_YMD_Y,
                MOD_SHORI_YMD_M,
                MOD_SHORI_YMD_D,
                MOD_KBN,
                TRK_OPE_CD,
                TRK_DATE,
                TRK_PGM_ID,
                UPD_OPE_CD,
                UPD_DATE,
                UPD_PGM_ID
              )
              VALUES(
                vNowData(1),
                vNowData(2),
                vNowData(3),
                vNowData(4),
                vNowData(5),
                vNowData(6),
                vNowData(7),
                vNowData(8),
                vNowData(9),
                vNowData(10),
                vNowData(11),
                vNowData(12),
                vNowData(13),
                vNowData(14),
                vNowData(15),
                vNowData(16),
                vNowData(17),
                vNowData(18),
                vNowData(19),
                vNowData(20),
                vNowData(21),
                vNowData(22),
                vNowData(23),
                vNowData(24),
                vNowData(25),
                vNowData(26),
                vNowData(27),
                vNowData(28),
                vNowData(29),
                vNowData(30),
                vNowData(31),
                vNowData(32),
                vNowData(33),
                vNowData(34),
                vNowData(35),
                vNowData(36),
                vNowData(37),
                vNowData(38),
                vNowData(39),
                TO_CHAR(vNowData(40),'FM00'),
                TO_CHAR(vNowData(41),'FM00'),
                TO_CHAR(vNowData(42),'FM00'),
                TO_CHAR(vNowData(43),'FM00'),
                TO_CHAR(vNowData(44),'FM00'),
                TO_CHAR(vNowData(45),'FM00'),
                TO_CHAR(vNowData(46),'FM00'),
                TO_CHAR(vNowData(47),'FM00'),
                vNowData(48),
                vNowData(49),
                vNowData(50),
                vNowData(51),
                vNowData(52),
                vNowData(54),
                vNowData(55),
                vNowData(56),
                vTAISHOKU_FLG,
                SUBSTR(iTensoYMD,1,4),
                SUBSTR(iTensoYMD,5,2),
                SUBSTR(iTensoYMD,7,2),
                SUBSTR(weekDcfRow.Upd_Eigy_Ymd,1,4),
                SUBSTR(weekDcfRow.Upd_Eigy_Ymd,5,2),
                SUBSTR(weekDcfRow.Upd_Eigy_Ymd,7,2),
                vMODKBN,
                iOPE_CD,
                iDATE,
                iPGM_ID,
                iOPE_CD,
                iDATE,
                iPGM_ID
              );
              EXECUTE_SQL := 'INSERT INTO TD_PW_DCF_KJN(
                KJNREC_ID,
                KJN_CD,
                ISHI_NM_KANA,
                ISHI_NM_KANJI,
                SEIBETSU,
                BIRTH_GENGO,
                BIRTH_Y,
                BIRTH_M,
                BIRTH_D,
                SHUSSHIN_KEN_CD,
                ISHIKAI_CD,
                STNEN_GENGO,
                STNEN_Y,
                SHUSSHINKO_SHUSSHINKO_CD,
                SHUSSHINKO_GAKUBU_SKBT_CD,
                KAIKIN_KBN,
                KAIGYONEN_GENGO,
                KAIGYONEN_Y,
                SNRYKMK_1,
                SNRYKMK_2,
                SNRYKMK_3,
                SNRYKMK_4,
                SNRYKMK_5,
                JITAKU_TEL,
                STATUS_JUSHOFUMEI,
                STATUS_DEL_YOTEI_RIYU,
                STATUS_IKKATSU_TRK_FLG,
                AITSK_CD_KJNREC_ID,
                AITSK_CD_KJN_CD,
                TRKNEN_GENGO,
                TRKNEN_Y,
                JITAKU_JUSHO_KANA,
                JITAKU_JUSHO_KANJI,
                JUSHO_CD_KEN_CD,
                JUSHO_CD_SHIKU_CD,
                JUSHO_CD_OAZA_CD,
                JUSHO_CD_AZA_CD,
                ZIP,
                JUSHO_HYOJI_NO,
                JUSHO_COUNT_KANA_KEN,
                JUSHO_COUNT_KANA_SHIKU,
                JUSHO_COUNT_KANA_OAZA,
                JUSHO_COUNT_KANJI_KEN,
                JUSHO_COUNT_KANJI_SHIKU,
                JUSHO_COUNT_KANJI_OAZA,
                JUSHO_COUNT_KANA_AZA,
                JUSHO_COUNT_KANJI_AZA,
                KINMUSAKI_SHIREC_ID,
                KINMUSAKI_SHI_CD,
                KINMUSAKI_YAKUSHOKU_CD,
                KINMUSAKI_SHOKUI,
                DM_FUKA_FLG,
                KINMUSAKI_SZKBUKA_CD,
                SZKBUKA_KANA,
                SZKBUKA_KANJI,
                TAISHOKU_IDO_FLG,
                TENSO_Y,
                TENSO_M,
                TENSO_D,
                MOD_SHORI_YMD_Y,
                MOD_SHORI_YMD_M,
                MOD_SHORI_YMD_D,
                MOD_KBN,
                TRK_OPE_CD,
                TRK_DATE,
                TRK_PGM_ID,
                UPD_OPE_CD,
                UPD_DATE,
                UPD_PGM_ID
              )
              VALUES(
                '''||vNowData(1)||''',
                '''||vNowData(2)||''',
                '''||vNowData(3)||''',
                '''||vNowData(4)||''',
                '''||vNowData(5)||''',
                '''||vNowData(6)||''',
                '''||vNowData(7)||''',
                '''||vNowData(8)||''',
                '''||vNowData(9)||''',
                '''||vNowData(10)||''',
                '''||vNowData(11)||''',
                '''||vNowData(12)||''',
                '''||vNowData(13)||''',
                '''||vNowData(14)||''',
                '''||vNowData(15)||''',
                '''||vNowData(16)||''',
                '''||vNowData(17)||''',
                '''||vNowData(18)||''',
                '''||vNowData(19)||''',
                '''||vNowData(20)||''',
                '''||vNowData(21)||''',
                '''||vNowData(22)||''',
                '''||vNowData(23)||''',
                '''||vNowData(24)||''',
                '''||vNowData(25)||''',
                '''||vNowData(26)||''',
                '''||vNowData(27)||''',
                '''||vNowData(28)||''',
                '''||vNowData(29)||''',
                '''||vNowData(30)||''',
                '''||vNowData(31)||''',
                '''||vNowData(32)||''',
                '''||vNowData(33)||''',
                '''||vNowData(34)||''',
                '''||vNowData(35)||''',
                '''||vNowData(36)||''',
                '''||vNowData(37)||''',
                '''||vNowData(38)||''',
                '''||vNowData(39)||''',
                '''||TO_CHAR(vNowData(40),'FM00')||''',
                '''||TO_CHAR(vNowData(41),'FM00')||''',
                '''||TO_CHAR(vNowData(42),'FM00')||''',
                '''||TO_CHAR(vNowData(43),'FM00')||''',
                '''||TO_CHAR(vNowData(44),'FM00')||''',
                '''||TO_CHAR(vNowData(45),'FM00')||''',
                '''||TO_CHAR(vNowData(46),'FM00')||''',
                '''||TO_CHAR(vNowData(47),'FM00')||''',
                '''||vNowData(48)||''',
                '''||vNowData(49)||''',
                '''||vNowData(50)||''',
                '''||vNowData(51)||''',
                '''||vNowData(52)||''',
                '''||vNowData(54)||''',
                '''||vNowData(55)||''',
                '''||vNowData(56)||''',
                '''||vTAISHOKU_FLG||''',
                '''||SUBSTR(iTensoYMD,1,4)||''',
                '''||SUBSTR(iTensoYMD,5,2)||''',
                '''||SUBSTR(iTensoYMD,7,2)||''',
                '''||SUBSTR(weekDcfRow.Upd_Eigy_Ymd,1,4)||''',
                '''||SUBSTR(weekDcfRow.Upd_Eigy_Ymd,5,2)||''',
                '''||SUBSTR(weekDcfRow.Upd_Eigy_Ymd,7,2)||''',
                '''||vMODKBN||''',
                '''||iOPE_CD||''',
                '''||iDATE||''',
                '''||iPGM_ID||''',
                '''||iOPE_CD||''',
                '''||iDATE||''',
                '''||iPGM_ID||''')';
              ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);
              vLastDcfKey := vNowData(1)||vNowData(2)||vNowData(48)||vNowData(49);
              IF nvl(vNowData(48)||vNowData(49),'0') = '009999999' THEN
                vLastRecord := SUBSTR(weekDcfRow.FIELD1,1,9);
              END IF;
            END IF;
          END IF;

        END LOOP;
        CLOSE weekDcfCSR;

        EXECUTE_SQL := 'SELECT
          A.REC_ID||ULT_COMMON.DELIMITER||
          A.KJN_CD||ULT_COMMON.DELIMITER||
          A.RIYOTEISHI_KBN_CD||ULT_COMMON.DELIMITER||
          A.RIYOTEISHI_RIYU_CD||ULT_COMMON.DELIMITER||
          A.RIYOTEISHI_TRK_YMD||ULT_COMMON.DELIMITER||
          A.RIYOTEISHI_KAIJO_YMD
          AS FIELD1,
          B.REC_ID||ULT_COMMON.DELIMITER||
          B.KJN_CD||ULT_COMMON.DELIMITER||
          B.RIYOTEISHI_KBN_CD||ULT_COMMON.DELIMITER||
          B.RIYOTEISHI_RIYU_CD||ULT_COMMON.DELIMITER||
          B.RIYOTEISHI_TRK_YMD||ULT_COMMON.DELIMITER||
          B.RIYOTEISHI_KAIJO_YMD
          AS FIELD2,
          A.UPD_EIGY_YMD AS UPD_EIGY_YMD
        FROM TT_TIKY_KJN A
        LEFT OUTER JOIN TT_Z_W_KJN B
        ON A.REC_ID = B.REC_ID
        AND A.KJN_CD = B.KJN_CD
        WHERE A.REC_ID = ''01''
          AND A.UPD_EIGY_YMD >= '''||NVL(iShimeFrom,ULT_COMMON.ORIGINAL_YMD)||''' AND A.UPD_EIGY_YMD <= '''||iShimeTo||'''
          AND A.DEL_FLG IS NULL';
        ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);
        --�b��_�T����_���p��~�iDCF��t�j�̔�r�p�f�[�^���������J��Ԃ�
        OPEN weekTisCSR ;
        LOOP
          FETCH weekTisCSR INTO weekTisRow;
          EXIT WHEN weekTisCSR%NOTFOUND;
          oROW_COUNT:=oROW_COUNT+1;

          --����ƑO��ŕω��̂Ȃ��f�[�^�͓o�^���Ȃ��i��r����1�Ɣ�r����2����v���Ă���ꍇ�j
          IF weekTisRow.Field1 != weekTisRow.Field2 THEN
            --����f�[�^������A�O��f�[�^���Ȃ��ꍇ�A�ǉ��Ƃ��ēo�^����(��r����2�̐擪��TAB�̏ꍇ)
            IF SUBSTR(weekTisRow.FIELD2,1,1) = ULT_COMMON.DELIMITER THEN
              vMODKBN  := ULT_COMMON.MOD_KBN_ADD;
              vNowData := ULT_COMMON.StrSplit(weekTisRow.FIELD1, ULT_COMMON.DELIMITER);
            ELSE
              vMODKBN  := ULT_COMMON.MOD_KBN_YES;
              --��r���ڂ��獡��f�[�^�̔z��ƑO��f�[�^�̔z����擾����
              vNowData := ULT_COMMON.StrSplit(weekTisRow.FIELD1, ULT_COMMON.DELIMITER);
              vLastData:= ULT_COMMON.StrSplit(weekTisRow.FIELD2, ULT_COMMON.DELIMITER);
               --�����l�ݒ�(��W���A�����l����)
              editInfo2:=EditInfoArray(3,4,5,6);
              ChangeToDefault(vNowData,vLastData,editInfo2);
            END IF;

            --�o�^����
            INSERT INTO TD_PW_DCF_KJN_TIS(KJNREC_ID,KJN_CD,RIYOTEISHI_KBN,RIYOTEISHI_RIYU,TRK_YMD,KAIJO_YMD,TENSO_Y,
              TENSO_M,TENSO_D,MENTE_Y,MENTE_M,MENTE_D,MOD_KBN,TRK_OPE_CD,TRK_DATE,TRK_PGM_ID,UPD_OPE_CD,UPD_DATE,UPD_PGM_ID)
            VALUES(vNowData(1),vNowData(2),vNowData(3),vNowData(4),vNowData(5),vNowData(6),SUBSTR(iTensoYMD,1,4),
              SUBSTR(iTensoYMD,5,2),SUBSTR(iTensoYMD,7,2),SUBSTR(weekTisRow.Upd_Eigy_Ymd,1,4),SUBSTR(weekTisRow.Upd_Eigy_Ymd,5,2),
              SUBSTR(weekTisRow.Upd_Eigy_Ymd,7,2),vMODKBN,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);
            EXECUTE_SQL := 'INSERT INTO TD_PW_DCF_KJN_TIS(KJNREC_ID,KJN_CD,RIYOTEISHI_KBN,RIYOTEISHI_RIYU,TRK_YMD,KAIJO_YMD,TENSO_Y,
              TENSO_M,TENSO_D,MENTE_Y,MENTE_M,MENTE_D,MOD_KBN,TRK_OPE_CD,TRK_DATE,TRK_PGM_ID,UPD_OPE_CD,UPD_DATE,UPD_PGM_ID)
              VALUES('''||vNowData(1)||''','''||vNowData(2)||''','''||vNowData(3)||''','''||vNowData(4)||''','''||vNowData(5)||''','''||vNowData(6)||''','''||
              SUBSTR(iTensoYMD,1,4)||''','''||SUBSTR(iTensoYMD,5,2)||''','''||SUBSTR(iTensoYMD,7,2)||''','''||SUBSTR(weekTisRow.Upd_Eigy_Ymd,1,4)||''','''||
              SUBSTR(weekTisRow.Upd_Eigy_Ymd,5,2)||''','''||SUBSTR(weekTisRow.Upd_Eigy_Ymd,7,2)||''','''||vMODKBN||''','''||iOPE_CD||''','''||iDATE||''','''||
              iPGM_ID||''','''||iOPE_CD||''','''||iDATE||''','''||iPGM_ID||''')';
            ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);
          END IF;
        END LOOP;
        CLOSE weekTisCSR;

        EXECUTE_SQL := 'SELECT
          A.REC_ID||ULT_COMMON.DELIMITER||
          A.KJN_CD||ULT_COMMON.DELIMITER||
          B.SENMONI_CD||ULT_COMMON.DELIMITER||
          B.SENMONI_FLG||ULT_COMMON.DELIMITER||
          B.SENMONI_KEISAI_YMD||ULT_COMMON.DELIMITER||
          B.NINTEII_FLG||ULT_COMMON.DELIMITER||
          B.NINTEII_KEISAI_YMD||ULT_COMMON.DELIMITER||
          B.SHIDOI_FLG||ULT_COMMON.DELIMITER||
          B.SHIDOI_KEISAI_YMD||ULT_COMMON.DELIMITER||
          B.SOSHITSU_FLG
          AS FIELD1,
          D.REC_ID||ULT_COMMON.DELIMITER||
          D.KJN_CD||ULT_COMMON.DELIMITER||
          C.SENMONI_CD||ULT_COMMON.DELIMITER||
          C.SENMONI_FLG||ULT_COMMON.DELIMITER||
          C.SENMONI_KEISAI_YMD||ULT_COMMON.DELIMITER||
          C.NINTEII_FLG||ULT_COMMON.DELIMITER||
          C.NINTEII_KEISAI_YMD||ULT_COMMON.DELIMITER||
          C.SHIDOI_FLG||ULT_COMMON.DELIMITER||
          C.SHIDOI_KEISAI_YMD||ULT_COMMON.DELIMITER||
          C.SOSHITSU_FLG
          AS FIELD2,
          X.MAX_UPD_EIGY_YMD AS UPD_EIGY_YMD
        FROM TT_TIKY_KJN A
        LEFT OUTER JOIN TT_TIKY_KJN_SENMONI B
          ON A.REC_ID = B.REC_ID
          AND A.KJN_CD = B.KJN_CD
        LEFT OUTER JOIN TT_Z_W_KJN_SENMONI C
          ON A.REC_ID = C.REC_ID
          AND A.KJN_CD = C.KJN_CD
          AND B.SENMONI_CD = C.SENMONI_CD
        LEFT OUTER JOIN TT_Z_W_KJN D
        ON A.REC_ID = D.REC_ID
        AND A.KJN_CD = D.KJN_CD
        LEFT OUTER JOIN (
          SELECT Y.KJN_CD,
          MAX(CASE WHEN Y.UPD_EIGY_YMD||''1''>Z.UPD_EIGY_YMD||''1'' THEN Y.UPD_EIGY_YMD ELSE Z.UPD_EIGY_YMD END) AS MAX_UPD_EIGY_YMD
          FROM TT_TIKY_KJN Y
          LEFT OUTER JOIN TT_TIKY_KJN_KINMUSAKI Z
          ON Y.REC_ID = Z.REC_ID
          AND Y.KJN_CD = Z.KJN_CD
          WHERE Y.REC_ID = ''01''
              AND ((Y.UPD_EIGY_YMD >= '''||NVL(iShimeFrom,ULT_COMMON.ORIGINAL_YMD)||''' AND Y.UPD_EIGY_YMD <= '''||iShimeTo||''')
               OR (Z.UPD_EIGY_YMD >= '''||NVL(iShimeFrom,ULT_COMMON.ORIGINAL_YMD)||''' AND Z.UPD_EIGY_YMD <= '''||iShimeTo||'''))
          GROUP BY Y.KJN_CD  ) X
        ON A.KJN_CD = X.KJN_CD
        WHERE A.REC_ID = ''01''
        AND ((A.UPD_EIGY_YMD >= '''||NVL(iShimeFrom,ULT_COMMON.ORIGINAL_YMD)||''' AND A.UPD_EIGY_YMD <= '''||iShimeTo||''')
              OR (B.UPD_EIGY_YMD >= '''||NVL(iShimeFrom,ULT_COMMON.ORIGINAL_YMD)||''' AND B.UPD_EIGY_YMD <= '''||iShimeTo||'''))
        AND A.DEL_FLG IS NULL
        AND (B.SOSHITSU_FLG IS NULL OR C.SOSHITSU_FLG IS NULL)' ;
        ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);
        --�b��_�T����_�w�����̔�r�p�f�[�^���������J��Ԃ�
        OPEN weekSenmoniCSR ;
        LOOP
          FETCH weekSenmoniCSR INTO weekSenmoniRow;
          EXIT WHEN weekSenmoniCSR%NOTFOUND;
          oROW_COUNT:=oROW_COUNT+1;

          --����ƑO��ŕω��̂Ȃ��f�[�^�͓o�^���Ȃ��i��r����1�Ɣ�r����2����v���Ă���ꍇ�j
          IF weekSenmoniRow.Field1 != weekSenmoniRow.Field2 THEN
            --����f�[�^������A�O��f�[�^���Ȃ��ꍇ�A�ǉ��Ƃ��ēo�^����(��r����2�̐擪��TAB�̏ꍇ)
            IF SUBSTR(weekSenmoniRow.FIELD2,1,1) = ULT_COMMON.DELIMITER THEN
              vMODKBN := ULT_COMMON.MOD_KBN_ADD;
              vSENMONI_MENTE:=ULT_COMMON.SENMONI_MENTE_ADD;
              --��r���ڂ��獡��f�[�^�̔z��ƑO��f�[�^�̔z����擾����
              vNowData := ULT_COMMON.StrSplit(weekSenmoniRow.FIELD1, ULT_COMMON.DELIMITER);

            --����ƑO��ŕω��̂���f�[�^�͕ύX�Ƃ��ēo�^����i��r����1�Ɣ�r����2����v���Ă��Ȃ��ꍇ�j
            ELSE
              vMODKBN := ULT_COMMON.MOD_KBN_YES;
              --��r���ڂ��獡��f�[�^�̔z��ƑO��f�[�^�̔z����擾����
              vNowData := ULT_COMMON.StrSplit(weekSenmoniRow.FIELD1, ULT_COMMON.DELIMITER);
              vLastData:= ULT_COMMON.StrSplit(weekSenmoniRow.FIELD2, ULT_COMMON.DELIMITER);

              --���チ���e�敪
              IF vLastData(1) IS NOT NULL AND NVL(vNowData(10),'0') = '1' THEN
                --�O��f�[�^������A����f�[�^�̑r���t���O��"1"�̏ꍇ�A���チ���e�敪��"1"�ɐݒ肷��
                vSENMONI_MENTE := ULT_COMMON.SENMONI_MENTE_DEL;
                FOR i IN 4..9 LOOP
                  vNowData(i):=NULL;
                END LOOP;

              ELSIF vLastData(3) IS NULL AND NVL(vNowData(10),'0')!='1' THEN
                --�O��f�[�^�̐���R�[�h��NULL�A���A����f�[�^�̑r���t���O��"1"�ł͂Ȃ��ꍇ�A���チ���e�敪��"2"�ɐݒ肷��
                vSENMONI_MENTE := ULT_COMMON.SENMONI_MENTE_ADD;
              ELSE
                vSENMONI_MENTE := ULT_COMMON.SENMONI_MENTE_HENKOU;
              END IF;

              --����f�[�^�̑r���t���O��"1"�ł͂Ȃ��ꍇ�A
              IF NVL(vLastData(10),'0')='1' AND NVL(vNowData(10),'0')!='1' THEN
                vSENMONI_MENTE := ULT_COMMON.SENMONI_MENTE_ADD;
              ELSIF vSENMONI_MENTE != ULT_COMMON.SENMONI_MENTE_DEL OR vSENMONI_MENTE IS NULL THEN
                --����f�[�^�̐��㎑�i�f�[�^�iTAGNO.94�j�̍��ڂ̈ꕔ�ɕύX���������ꍇ�́ATAGNO.94�̑S���ڂ��o��
                vRet:=0;
                FOR i IN 3..9 LOOP
                  IF NVL(vNowData(i),0)!=NVL(vLastData(i),0) THEN
                    vRet:=1;
                    EXIT;
                  END IF;
                END LOOP;
                IF  vRet=0 THEN
                  FOR i IN 4..9 LOOP
                    vNowData(i):=NULL;
                  END LOOP;
                END IF;

                --�����l�ݒ�
                editInfoArray2:=EditInfoArrayArray(
                   EditInfoArray(4,5),EditInfoArray(6,7),EditInfoArray(8,9)
                );
                
                ChangeToDefaultForArray(vNowData,vLastData,editInfoArray2);
                
              END IF;
            END IF;

            --�o�^����
              INSERT INTO TD_PW_DCF_KJN_SENMONI(
                DCF_CD_REC_ID,
                DCF_CD_KJN_CD,
                SENMONI_CD,
                SENMONI_FLG,
                SENMONI_KEISAI_D_Y,
                SENMONI_KEISAI_D_M,
                SENMONI_KEISAI_D_D,
                NINTEII_FLG,
                NINTEII_KEISAI_D_Y,
                NINTEII_KEISAI_D_M,
                NINTEII_KEISAI_D_D,
                SHIDOI_FLG,
                SHIDOI_KEISAI_D_Y,
                SHIDOI_KEISAI_D_M,
                SHIDOI_KEISAI_D_D,
                SENMONI_MENTE_KBN,
                TENSO_Y,
                TENSO_M,
                TENSO_D,
                MENTE_Y,
                MENTE_M,
                MENTE_D,
                MOD_KBN,
                TRK_OPE_CD,
                TRK_DATE,
                TRK_PGM_ID,
                UPD_OPE_CD,
                UPD_DATE,
                UPD_PGM_ID
              ) VALUES(
                vNowData(1),
                vNowData(2),
                NVL(vNowData(3),'9999'),
                vNowData(4),
                SUBSTR(vNowData(5),1,4),
                SUBSTR(vNowData(5),5,2),
                SUBSTR(vNowData(5),7,2),
                vNowData(6),
                SUBSTR(vNowData(7),1,4),
                SUBSTR(vNowData(7),5,2),
                SUBSTR(vNowData(7),7,2),
                vNowData(8),
                SUBSTR(vNowData(9),1,4),
                SUBSTR(vNowData(9),5,2),
                SUBSTR(vNowData(9),7,2),
                TRIM(vSENMONI_MENTE),
                SUBSTR(iTensoYMD,1,4),
                SUBSTR(iTensoYMD,5,2),
                SUBSTR(iTensoYMD,7,2),
                SUBSTR(weekSenmoniRow.UPD_EIGY_YMD,1,4),
                SUBSTR(weekSenmoniRow.UPD_EIGY_YMD,5,2),
                SUBSTR(weekSenmoniRow.UPD_EIGY_YMD,7,2),
                vMODKBN,
                iOPE_CD,
                iDATE,
                iPGM_ID,
                iOPE_CD,
                iDATE,
                iPGM_ID
              );
              EXECUTE_SQL := 'INSERT INTO TD_PW_DCF_KJN_SENMONI(
                DCF_CD_REC_ID,
                DCF_CD_KJN_CD,
                SENMONI_CD,
                SENMONI_FLG,
                SENMONI_KEISAI_D_Y,
                SENMONI_KEISAI_D_M,
                SENMONI_KEISAI_D_D,
                NINTEII_FLG,
                NINTEII_KEISAI_D_Y,
                NINTEII_KEISAI_D_M,
                NINTEII_KEISAI_D_D,
                SHIDOI_FLG,
                SHIDOI_KEISAI_D_Y,
                SHIDOI_KEISAI_D_M,
                SHIDOI_KEISAI_D_D,
                SENMONI_MENTE_KBN,
                TENSO_Y,
                TENSO_M,
                TENSO_D,
                MENTE_Y,
                MENTE_M,
                MENTE_D,
                MOD_KBN,
                TRK_OPE_CD,
                TRK_DATE,
                TRK_PGM_ID,
                UPD_OPE_CD,
                UPD_DATE,
                UPD_PGM_ID
              ) VALUES(
                '''||vNowData(1)||''',
                '''||vNowData(2)||''',
                '''||NVL(vNowData(3),'9999')||''',
                '''||vNowData(4)||''',
                '''||SUBSTR(vNowData(5),1,4)||''',
                '''||SUBSTR(vNowData(5),5,2)||''',
                '''||SUBSTR(vNowData(5),7,2)||''',
                '''||vNowData(6)||''',
                '''||SUBSTR(vNowData(7),1,4)||''',
                '''||SUBSTR(vNowData(7),5,2)||''',
                '''||SUBSTR(vNowData(7),7,2)||''',
                '''||vNowData(8)||''',
                '''||SUBSTR(vNowData(9),1,4)||''',
                '''||SUBSTR(vNowData(9),5,2)||''',
                '''||SUBSTR(vNowData(9),7,2)||''',
                '''||vSENMONI_MENTE||''',
                '''||SUBSTR(iTensoYMD,1,4)||''',
                '''||SUBSTR(iTensoYMD,5,2)||''',
                '''||SUBSTR(iTensoYMD,7,2)||''',
                '''||SUBSTR(weekSenmoniRow.UPD_EIGY_YMD,1,4)||''',
                '''||SUBSTR(weekSenmoniRow.UPD_EIGY_YMD,5,2)||''',
                '''||SUBSTR(weekSenmoniRow.UPD_EIGY_YMD,7,2)||''',
                '''||vMODKBN||''',
                '''||iOPE_CD||''',
                '''||iDATE||''',
                '''||iPGM_ID||''',
                '''||iOPE_CD||''',
                '''||iDATE||''',
                '''||iPGM_ID||''')';
            ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);
          END IF;

        END LOOP;
        CLOSE weekSenmoniCSR;


     -- ���ߓ��敪��"4"(������) �܂��́A"5"(������) �̏ꍇ
     ELSIF iShimeKind = ULT_COMMON.SHIME_SBT_CD_NAKASHIME OR iShimeKind = ULT_COMMON.SHIME_SBT_CD_MATSUSHIME THEN

		-- ������2012/10/26 CP000182�̑Ή�
        IF iLayoutKind = ULT_COMMON.LAYOUT_SBT_CD_ZANTEI THEN
          IF iM2Flg = ULT_COMMON.FLG_NO THEN
          	--�b��_��1����_DCF��t�e�[�u���̃f�[�^���N���A����B
            EXECUTE_SQL := 'TRUNCATE TABLE ' || vSchemaNm || '.' || 'TD_PM_DCF_KJN';
            
            IF iShimeKind = ULT_COMMON.SHIME_SBT_CD_NAKASHIME THEN
	            vTABLE1:= 'TT_Z_MM_KJN';
	            vTABLE2:= 'TT_Z_MM_KJN_KINMUSAKI';
	            vTABLE3:= 'TT_Z_MM_SHI';
	            vTABLE4:= 'TM_Z_MM_HIFG_SSY_SZKBUKA';
          	ELSE
	            vTABLE1:= 'TT_Z_ME_KJN';
	            vTABLE2:= 'TT_Z_ME_KJN_KINMUSAKI';
	            vTABLE3:= 'TT_Z_ME_SHI';
	            vTABLE4:= 'TM_Z_ME_HIFG_SSY_SZKBUKA';
          	END IF;
          ELSE
          	 --�b��_��2����_DCF��t�e�[�u���̃f�[�^���N���A����B
            EXECUTE_SQL := 'TRUNCATE TABLE ' || vSchemaNm || '.' || 'TD_P2_DCF_KJN';
            
            IF iShimeKind = ULT_COMMON.SHIME_SBT_CD_NAKASHIME THEN
            	vTABLE1:= 'TT_Z_ME_KJN';
	            vTABLE2:= 'TT_Z_ME_KJN_KINMUSAKI';
	            vTABLE3:= 'TT_Z_ME_SHI';
	            vTABLE4:= 'TM_Z_ME_HIFG_SSY_SZKBUKA';
          	ELSE
	            vTABLE1:= 'TT_Z_MM_KJN';
	            vTABLE2:= 'TT_Z_MM_KJN_KINMUSAKI';
	            vTABLE3:= 'TT_Z_MM_SHI';
	            vTABLE4:= 'TM_Z_MM_HIFG_SSY_SZKBUKA';
          	END IF;
          END IF;
          
        ELSIF iLayoutKind = ULT_COMMON.LAYOUT_SBT_CD_2SEDAIMAE THEN
        
            --�b��_��1����_2����O_DCF��t�e�[�u���̃f�[�^���N���A����B
            EXECUTE_SQL := 'TRUNCATE TABLE ' || vSchemaNm || '.' || 'TD_PM_GEN_DCF_KJN';
            
            IF iShimeKind = ULT_COMMON.SHIME_SBT_CD_NAKASHIME THEN
	            vTABLE1:= 'TT_Z_MM_KJN';
	            vTABLE2:= 'TT_Z_MM_KJN_KINMUSAKI';
	            vTABLE3:= 'TT_Z_MM_SHI';
	            vTABLE4:= 'TM_Z_MM_HIFG_SSY_SZKBUKA';
          	ELSE
	            vTABLE1:= 'TT_Z_ME_KJN';
	            vTABLE2:= 'TT_Z_ME_KJN_KINMUSAKI';
	            vTABLE3:= 'TT_Z_ME_SHI';
	            vTABLE4:= 'TM_Z_ME_HIFG_SSY_SZKBUKA';
          	END IF;
        END IF;
        -- ������2012/10/26 CP000182�̑Ή�
        EXECUTE IMMEDIATE EXECUTE_SQL;
        ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

        vSelectSQL:=
          'SELECT A.REC_ID||'''||ULT_COMMON.DELIMITER||'''||
              A.KJN_CD||'''||ULT_COMMON.DELIMITER||'''||
              A.KJN_NM_KANA||'''||ULT_COMMON.DELIMITER||'''||
              A.SEIBETSU_KBN||'''||ULT_COMMON.DELIMITER||'''||
              A.BIRTH_GENGO_CD||'''||ULT_COMMON.DELIMITER||'''||
              A.BIRTH_WY||'''||ULT_COMMON.DELIMITER||'''||
              A.BIRTH_M||'''||ULT_COMMON.DELIMITER||'''||
              A.BIRTH_D||'''||ULT_COMMON.DELIMITER||'''||
              A.SHUSSHINCHI_RIDAI_CD||'''||ULT_COMMON.DELIMITER||'''||
              A.KANYU_ISHIKAI_RIDAI_CD||'''||ULT_COMMON.DELIMITER||'''||
              A.STNEN_GENGO_CD||'''||ULT_COMMON.DELIMITER||'''||
              A.STNEN_WY||'''||ULT_COMMON.DELIMITER||'''||
              A.SHUSSHINKO_CD||'''||ULT_COMMON.DELIMITER||'''||
              A.GAKUBU_SHIKIBETSU_KBN||'''||ULT_COMMON.DELIMITER||'''||
              A.KAIKIN_KBN||'''||ULT_COMMON.DELIMITER||'''||
              A.KAIGYONEN_GENGO_CD||'''||ULT_COMMON.DELIMITER||'''||
              A.KAIGYONEN_WY||'''||ULT_COMMON.DELIMITER||'''||
              A.SNRYKMK_CD_1||'''||ULT_COMMON.DELIMITER||'''||
              A.SNRYKMK_CD_2||'''||ULT_COMMON.DELIMITER||'''||
              A.SNRYKMK_CD_3||'''||ULT_COMMON.DELIMITER||'''||
              A.SNRYKMK_CD_4||'''||ULT_COMMON.DELIMITER||'''||
              A.SNRYKMK_CD_5||'''||ULT_COMMON.DELIMITER||'''||
              A.KEN_CD||'''||ULT_COMMON.DELIMITER||'''||
              A.SHIKU_CD||'''||ULT_COMMON.DELIMITER||'''||
              A.OAZA_CD||'''||ULT_COMMON.DELIMITER||'''||
              A.AZA_CD||'''||ULT_COMMON.DELIMITER||'''||
              A.ZIP||'''||ULT_COMMON.DELIMITER||'''||
              A.JUSHO_HYOJI_NO||'''||ULT_COMMON.DELIMITER||'''||
              A.JUSHO_KANA_RENKETSU||'''||ULT_COMMON.DELIMITER||'''||
              A.KEN_NM_KANA_MOJI_SU||'''||ULT_COMMON.DELIMITER||'''||
              A.SHIKU_NM_KANA_MOJI_SU||'''||ULT_COMMON.DELIMITER||'''||
              A.OAZA_NM_KANA_MOJI_SU||'''||ULT_COMMON.DELIMITER||'''||
              A.KEN_NM_KANJI_MOJI_SU||'''||ULT_COMMON.DELIMITER||'''||
              A.SHIKU_NM_KANJI_MOJI_SU||'''||ULT_COMMON.DELIMITER||'''||
              A.OAZA_NM_KANJI_MOJI_SU||'''||ULT_COMMON.DELIMITER||'''||
              A.TEL||'''||ULT_COMMON.DELIMITER||'''||
              A.JUSHOFUMEI_CD||'''||ULT_COMMON.DELIMITER||'''||
              A.DEL_YOTEI_RIYU_CD||'''||ULT_COMMON.DELIMITER||'''||
              A.IKKATSU_TRK_FLG||'''||ULT_COMMON.DELIMITER||'''||
              A.TRKNEN_GENGO_CD||'''||ULT_COMMON.DELIMITER||'''||
              A.TRKNEN_WY||'''||ULT_COMMON.DELIMITER||'''||
              A.KJN_NM||'''||ULT_COMMON.DELIMITER||'''||
              A.JUSHO_KANJI_RENKETSU||'''||ULT_COMMON.DELIMITER||'''||
              B.KINMUSAKI_REC_ID||'''||ULT_COMMON.DELIMITER||'''||
              B.KINMUSAKI_SHI_CD||'''||ULT_COMMON.DELIMITER||'''||
              B.YAKUSHOKU_CD||'''||ULT_COMMON.DELIMITER||'''||
              B.SHOKUI_CD||'''||ULT_COMMON.DELIMITER||'''||
              B.SZKBUKA_CD||'''||ULT_COMMON.DELIMITER||'''||
              C.SHI_RN_KANA ||'''||ULT_COMMON.DELIMITER||'''||
              C.SHI_RN ||'''||ULT_COMMON.DELIMITER||'''||
              A.CHOFUKU_AITSK_REC_ID||'''||ULT_COMMON.DELIMITER||'''||
              A.CHOFUKU_AITSK_KJN_CD||'''||ULT_COMMON.DELIMITER||'''||
              B.TAISHOKU_FLG AS FIELD1,
              E.REC_ID||'''||ULT_COMMON.DELIMITER||'''||
              E.KJN_CD||'''||ULT_COMMON.DELIMITER||'''||
              E.KJN_NM_KANA||'''||ULT_COMMON.DELIMITER||'''||
              E.SEIBETSU_KBN||'''||ULT_COMMON.DELIMITER||'''||
              E.BIRTH_GENGO_CD||'''||ULT_COMMON.DELIMITER||'''||
              E.BIRTH_WY||'''||ULT_COMMON.DELIMITER||'''||
              E.BIRTH_M||'''||ULT_COMMON.DELIMITER||'''||
              E.BIRTH_D||'''||ULT_COMMON.DELIMITER||'''||
              E.SHUSSHINCHI_RIDAI_CD||'''||ULT_COMMON.DELIMITER||'''||
              E.KANYU_ISHIKAI_RIDAI_CD||'''||ULT_COMMON.DELIMITER||'''||
              E.STNEN_GENGO_CD||'''||ULT_COMMON.DELIMITER||'''||
              E.STNEN_WY||'''||ULT_COMMON.DELIMITER||'''||
              E.SHUSSHINKO_CD||'''||ULT_COMMON.DELIMITER||'''||
              E.GAKUBU_SHIKIBETSU_KBN||'''||ULT_COMMON.DELIMITER||'''||
              E.KAIKIN_KBN||'''||ULT_COMMON.DELIMITER||'''||
              E.KAIGYONEN_GENGO_CD||'''||ULT_COMMON.DELIMITER||'''||
              E.KAIGYONEN_WY||'''||ULT_COMMON.DELIMITER||'''||
              E.SNRYKMK_CD_1||'''||ULT_COMMON.DELIMITER||'''||
              E.SNRYKMK_CD_2||'''||ULT_COMMON.DELIMITER||'''||
              E.SNRYKMK_CD_3||'''||ULT_COMMON.DELIMITER||'''||
              E.SNRYKMK_CD_4||'''||ULT_COMMON.DELIMITER||'''||
              E.SNRYKMK_CD_5||'''||ULT_COMMON.DELIMITER||'''||
              E.KEN_CD||'''||ULT_COMMON.DELIMITER||'''||
              E.SHIKU_CD||'''||ULT_COMMON.DELIMITER||'''||
              E.OAZA_CD||'''||ULT_COMMON.DELIMITER||'''||
              E.AZA_CD||'''||ULT_COMMON.DELIMITER||'''||
              E.ZIP||'''||ULT_COMMON.DELIMITER||'''||
              E.JUSHO_HYOJI_NO||'''||ULT_COMMON.DELIMITER||'''||
              E.JUSHO_KANA_RENKETSU||'''||ULT_COMMON.DELIMITER||'''||
              E.KEN_NM_KANA_MOJI_SU||'''||ULT_COMMON.DELIMITER||'''||
              E.SHIKU_NM_KANA_MOJI_SU||'''||ULT_COMMON.DELIMITER||'''||
              E.OAZA_NM_KANA_MOJI_SU||'''||ULT_COMMON.DELIMITER||'''||
              E.KEN_NM_KANJI_MOJI_SU||'''||ULT_COMMON.DELIMITER||'''||
              E.SHIKU_NM_KANJI_MOJI_SU||'''||ULT_COMMON.DELIMITER||'''||
              E.OAZA_NM_KANJI_MOJI_SU||'''||ULT_COMMON.DELIMITER||'''||
              E.TEL||'''||ULT_COMMON.DELIMITER||'''||
              E.JUSHOFUMEI_CD||'''||ULT_COMMON.DELIMITER||'''||
              E.DEL_YOTEI_RIYU_CD||'''||ULT_COMMON.DELIMITER||'''||
              E.IKKATSU_TRK_FLG||'''||ULT_COMMON.DELIMITER||'''||
              E.TRKNEN_GENGO_CD||'''||ULT_COMMON.DELIMITER||'''||
              E.TRKNEN_WY||'''||ULT_COMMON.DELIMITER||'''||
              E.KJN_NM||'''||ULT_COMMON.DELIMITER||'''||
              E.JUSHO_KANJI_RENKETSU||'''||ULT_COMMON.DELIMITER||'''||
              F.KINMUSAKI_REC_ID||'''||ULT_COMMON.DELIMITER||'''||
              F.KINMUSAKI_SHI_CD||'''||ULT_COMMON.DELIMITER||'''||
              F.YAKUSHOKU_CD||'''||ULT_COMMON.DELIMITER||'''||
              F.SHOKUI_CD||'''||ULT_COMMON.DELIMITER||'''||
              F.SZKBUKA_CD||'''||ULT_COMMON.DELIMITER||'''||
              G.SHI_RN_KANA ||'''||ULT_COMMON.DELIMITER||'''||
              G.SHI_RN ||'''||ULT_COMMON.DELIMITER||'''||
              E.CHOFUKU_AITSK_REC_ID||'''||ULT_COMMON.DELIMITER||'''||
              E.CHOFUKU_AITSK_KJN_CD||'''||ULT_COMMON.DELIMITER||'''||
              F.TAISHOKU_FLG AS FIELD2,
              A.DEL_FLG AS DEL_FLG,
              B.TAISHOKU_FLG AS TAISHOKU_FLG,
              F.TAISHOKU_FLG AS ZEN_TAISHOKU_FLG,
              A.KJN_CD AS KJN_CD,
              B.SZKBUKA_CD AS SZKBUKA_CD1 ,
              F.SZKBUKA_CD AS SZKBUKA_CD2 ,
              DECODE(B.SZKBUKA_CD, ''9999'', B.NYURYOKU_SZKBUKA_NM_KANA, SUBSTR(D.SZKBUKA_NM_KANA, 1, 20)) AS SZKBUKA_NM_KANA1,
              DECODE(B.SZKBUKA_CD, ''9999'', B.NYURYOKU_SZKBUKA_NM, SUBSTR(D.SZKBUKA_NM, 1, 15)) AS SZKBUKA_NM1,
              DECODE(F.SZKBUKA_CD, ''9999'', F.NYURYOKU_SZKBUKA_NM_KANA, SUBSTR(H.SZKBUKA_NM_KANA, 1, 20)) AS SZKBUKA_NM_KANA2,
              DECODE(F.SZKBUKA_CD, ''9999'', F.NYURYOKU_SZKBUKA_NM, SUBSTR(H.SZKBUKA_NM, 1, 15)) AS SZKBUKA_NM2,
              T.MAX_UPD_EIGY_YMD AS UPD_EIGY_YMD,
              CASE WHEN TT.COUNT1 = TT.INFO_COUNT AND TT.INFO_COUNT != 0 THEN ''1'' ELSE NULL END AS ALL_TAISHOKU_KJN_CD
        FROM TT_TIKY_KJN A
          LEFT OUTER JOIN TT_TIKY_KJN_KINMUSAKI B
            ON A.REC_ID = B.REC_ID
            AND A.KJN_CD = B.KJN_CD
          LEFT JOIN TT_TIKY_SHI C
            ON B.KINMUSAKI_REC_ID = C.REC_ID
            AND B.KINMUSAKI_SHI_CD = C.SHI_CD
          LEFT OUTER JOIN TM_TIKY_HIFG_SSY_SZKBUKA D
            ON B.SZKBUKA_CD = D.SZKBUKA_CD
          LEFT OUTER JOIN '||vTABLE1||' E
            ON A.REC_ID = E.REC_ID
            AND A.KJN_CD = E.KJN_CD
          LEFT OUTER JOIN '||vTABLE2||' F
            ON A.REC_ID = F.REC_ID
            AND A.KJN_CD = F.KJN_CD
            AND B.KINMUSAKI_REC_ID = F.KINMUSAKI_REC_ID
            AND B.KINMUSAKI_SHI_CD = F.KINMUSAKI_SHI_CD
          LEFT OUTER JOIN '||vTABLE3||' G
            ON F.KINMUSAKI_REC_ID = G.REC_ID
            AND F.KINMUSAKI_SHI_CD = G.SHI_CD
          LEFT OUTER JOIN  '||vTABLE4||' H
            ON F.SZKBUKA_CD = H.SZKBUKA_CD
          LEFT OUTER JOIN (SELECT
          					  REC_ID,
				              KJN_CD,
				              MAX(UPD_EIGY_YMD) AS MAX_UPD_EIGY_YMD
				            FROM
					            ( SELECT
					            	TTK.REC_ID,
					                TTK.KJN_CD,
					                CASE WHEN TTK.UPD_EIGY_YMD||''1''>=M.UPD_EIGY_YMD||''1'' THEN TTK.UPD_EIGY_YMD ELSE M.UPD_EIGY_YMD END AS UPD_EIGY_YMD
					              FROM TT_TIKY_KJN TTK
					              LEFT OUTER JOIN TT_TIKY_KJN_KINMUSAKI M
					              	ON TTK.REC_ID = M.REC_ID
									AND TTK.KJN_CD = M.KJN_CD
					              WHERE TTK.REC_ID = ''01''
					                AND (
						                	(M.UPD_EIGY_YMD >= '''||NVL(iShimeFrom,ULT_COMMON.ORIGINAL_YMD)||'''
						                		AND M.UPD_EIGY_YMD <= '''||NVL(iShimeTo,ULT_COMMON.ORIGINAL_YMD)||'''
						                	)
						                	OR
						                	(TTK.UPD_EIGY_YMD >= '''||NVL(iShimeFrom,ULT_COMMON.ORIGINAL_YMD)||'''
			          							AND TTK.UPD_EIGY_YMD <= '''||iShimeTo||'''
			          						)
		          						)
				              	) 
				            GROUP BY
				              REC_ID,
				              KJN_CD
					       ) T
           ON A.KJN_CD = T.KJN_CD
           AND A.REC_ID = T.REC_ID
		  LEFT OUTER JOIN (SELECT
		  					  REC_ID,
				              KJN_CD,
				              SUM(TAISHOKU_FLG_1) COUNT1,
				              COUNT(1) INFO_COUNT
				            FROM
					            ( SELECT
					            	TTK.REC_ID,
					                TTK.KJN_CD,
					                DECODE(M.TAISHOKU_FLG,''1'',1,0) TAISHOKU_FLG_1
					              FROM TT_TIKY_KJN TTK
					              LEFT OUTER JOIN TT_TIKY_KJN_KINMUSAKI M
					              	ON TTK.REC_ID = M.REC_ID
									AND TTK.KJN_CD = M.KJN_CD
					              WHERE TTK.REC_ID = ''01''
				              	) 
				            GROUP BY
				              REC_ID,
				              KJN_CD
					       ) TT
           ON A.KJN_CD = TT.KJN_CD
           AND A.REC_ID = TT.REC_ID           
          WHERE A.REC_ID = ''01''
            AND ((A.UPD_EIGY_YMD >= '''||NVL(iShimeFrom,ULT_COMMON.ORIGINAL_YMD)||'''
              AND A.UPD_EIGY_YMD <= '''||iShimeTo||''')
              OR (B.UPD_EIGY_YMD >= '''||NVL(iShimeFrom,ULT_COMMON.ORIGINAL_YMD)||'''
              AND B.UPD_EIGY_YMD <= '''||iShimeTo||''')
              OR (C.UPD_EIGY_YMD >= '''||NVL(iShimeFrom,ULT_COMMON.ORIGINAL_YMD)||'''
              AND C.UPD_EIGY_YMD <='''||iShimeTo||'''))
            AND (A.DEL_FLG IS NULL OR E.DEL_FLG IS NULL)
		  ORDER BY
		    	A.REC_ID,
		    	A.KJN_CD';

       vMODKBN:=ULT_COMMON.MOD_KBN_NO;

       ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',vSelectSQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);
       --�������ʌ������J��Ԃ�
       OPEN cur FOR vSelectSQL;
       LOOP
          FETCH cur INTO vBAITAI_ZANTEI_RECORD;
          --����l�P�ʂ̃f�[�^�ƑO��ŕω�������f�[�^�͓o�^����
          IF tempTABLE.COUNT>0 AND
            (SUBSTR(vBAITAI_ZANTEI_RECORD.FIELD1,1,vLen) !=  SUBSTR(tempTABLE(tempTABLE.COUNT).FIELD1,1,vLen) OR cur%NOTFOUND)
          THEN
            IF vMODKBN != ULT_COMMON.MOD_KBN_NO THEN
              FOR i IN 1..tempTABLE.COUNT LOOP
              	
              	-- �C���敪(�ꎞ�p)�̍Đݒ���s��
              	vTempModKbn := NULL;
              	vTempModKbn := vMODKBN;
              	
                tempRecord := tempTABLE(i);
                
                vIsTaiShoku := ULT_COMMON.FLG_NO;

                --��r���ڂ��獡��f�[�^�̔z��ƑO��f�[�^�̔z����擾����
                vNowData := ULT_COMMON.StrSplit(tempRecord.FIELD1, ULT_COMMON.DELIMITER);
                vLastData := ULT_COMMON.StrSplit(tempRecord.FIELD2, ULT_COMMON.DELIMITER);
                
                -- ������ 2012/10/12 CP000112�̑Ή� 
                --�C���敪��"B"�̏ꍇ�A
                IF vMODKBN=ULT_COMMON.MOD_KBN_YES THEN
                
                  -- ������2012/11/30 NH000007�̑Ή�
	              -- �l��񂪕ς�邩�ǂ������f���s���B
	              vIsKojinChangedFlg := NULL; 
	              FOR j IN 1..52 LOOP
                	IF j = 44 OR j = 45 OR j = 46 OR j = 47 OR 
                	   j = 48 OR j = 49 OR j = 50 THEN
                	   -- �������Ȃ�
                	   NULL;
                	ELSE
                	  IF '1' || vNowData(j) != '1' || vLastData(j) THEN
                	  	--  �l��񂪕ς�邩�ǂ������f�t���O�̐ݒ�
                	  	vIsKojinChangedFlg := '1';
                	  	EXIT;
                	  END IF;
                	END IF;   
	              END LOOP;
	              -- ������2012/11/30 NH000007�̑Ή�

				  IF vLastData(44) IS NULL THEN
				  	IF vNowData(44) IS NULL THEN
				  		vNowData(44):='00';
                    	vNowData(45):='9999999';
				  	ELSE
				  		IF vNowData(53) IS NOT NULL THEN
				  			IF  tempRecord.ALL_TAISHOKU_KJN_CD IS NOT NULL AND vIsKojinChangedFlg IS NOT NULL THEN
		                  		vNowData(44):='00';
		                    	vNowData(45):='9999999';
	                    	ELSE
	                    		IF vIsKojinChangedFlg IS NOT NULL THEN
	                    		    -- �l��񂾂����ς��A���o�����Ζ����񂪂��ׂđސE���邵�A�ł��A�S�̐E�ł͂Ȃ��Ƃ��A
	                    			vTempModKbn := 'D';
	                    		ELSE
	                    			vIsTaiShoku := ULT_COMMON.FLG_YES;
	                    		END IF;
	                    	END IF;
                  		END IF;
				  	END IF;
				  ELSE
				  	IF vNowData(53) IS NOT NULL THEN
				  		IF vLastData(53) IS NOT NULL THEN
				  			IF  tempRecord.ALL_TAISHOKU_KJN_CD IS NOT NULL AND vIsKojinChangedFlg IS NOT NULL THEN
		                  		vNowData(44):='00';
		                    	vNowData(45):='9999999';
	                    	ELSE
	                    		IF vIsKojinChangedFlg IS NOT NULL THEN
	                    		    -- �l��񂾂����ς��A���o�����Ζ����񂪂��ׂđސE���邵�A�ł��A�S�̐E�ł͂Ȃ��Ƃ��A
	                    			vTempModKbn := 'D';
	                    		ELSE
	                    			vIsTaiShoku := ULT_COMMON.FLG_YES;
	                    		END IF;
	                    	END IF;
				  		ELSE
				  			IF  tempRecord.ALL_TAISHOKU_KJN_CD IS NOT NULL THEN
		                  		vNowData(44):='00';
		                    	vNowData(45):='9999999';
	                    	ELSE
	                    		-- ���o�����Ζ����񂪂��ׂđސE���邵�A�ł��A�S�̐E�ł͂Ȃ��Ƃ��A���̌l���o�͂���͂��ł�
	                    		vTempModKbn := 'D';
	                    	END IF;
				  		END IF;
                  	END IF;
				  END IF;

                -- �C���敪��"A"�̏ꍇ�A
                ELSIF vMODKBN=ULT_COMMON.MOD_KBN_ADD THEN
                  --�Ζ��悪�Ȃ��ꍇ�A����l�P�ʋΖ�����i�Ζ��惌�R�[�hID�j��"00"�ݒ肵�A����l�P�ʋΖ�����i�Ζ���{�݃R�[�h�j��"9999999"�ݒ肷��
                  IF vNowData(44) IS NULL THEN
                    vNowData(44):='00';
                    vNowData(45):='9999999';
                  ELSE
                  	IF vNowData(53) IS NOT NULL THEN
                  		IF  tempRecord.ALL_TAISHOKU_KJN_CD IS NOT NULL THEN
	                  		vNowData(44):='00';
	                    	vNowData(45):='9999999';
                    	ELSE
                    		vIsTaiShoku := ULT_COMMON.FLG_YES;
                    	END IF;
                  	END IF;
                  END IF;
                -- �C���敪��"C"�̏ꍇ�A
                ELSIF vMODKBN=ULT_COMMON.MOD_KBN_DEL THEN
                   vNowData(44):='00';
                   vNowData(45):='9999999';
                END IF;
                
                -- �Ζ��摊�֏��̃N���A
                IF NVL(vNowData(44),'0') ='00' AND NVL(vNowData(45),'0') ='9999999' THEN
                    -- �Ζ��摊�֏����N���A����
                	FOR j IN 46..50 LOOP
                      vNowData(j):=NULL;
                   	END LOOP;
                   	
                   	-- �������ȁi�J�i�j�̃N���A
                   	tempRecord.SZKBUKA_NM_KANA1 := NULL;
                   	
                   	-- �������ȁi�����j�̃N���A
                   	tempRecord.SZKBUKA_NM1 := NULL;
                END IF;
                
                -- ������ 2012/10/12 CP000112�̑Ή� 
                
                -- �ޔ��lDUMMY�������v�Z����
                IF NVL(vNowData(45),'0') ='9999999' THEN
                	vKojinCount := vKojinCount + 1;
                END IF; 

                --�o�^����
                IF vIsTaiShoku != ULT_COMMON.FLG_YES AND 
                   (
                   	(vKojinCount = 1 AND NVL(vNowData(45),'0') ='9999999') OR 
                   	(NVL(vNowData(45),'0') !='9999999')
                   ) THEN
                  IF iLayoutKind = ULT_COMMON.LAYOUT_SBT_CD_2SEDAIMAE THEN
                    INSERT INTO TD_PM_GEN_DCF_KJN(
                      KJNREC_ID,
                      KJN_CD,
                      ISHI_NM_KANA,
                      SEIBETSU,
                      BIRTH_GENGO,
                      BIRTH_Y,
                      BIRTH_M,
                      BIRTH_D,
                      SHUSSHIN_KEN_CD,
                      ISHIKAI_CD,
                      STNEN_GENGO,
                      STNEN_Y,
                      SHUSSHINKO_SHUSSHINKO_CD,
                      SHUSSHINKO_GAKUBU_SKBT_CD,
                      KAIKIN_KBN,
                      KAIGYONEN_GENGO,
                      KAIGYONEN_Y,
                      SNRYKMK_1,
                      SNRYKMK_2,
                      SNRYKMK_3,
                      SNRYKMK_4,
                      SNRYKMK_5,
                      JUSHO_CD_KEN_CD,
                      JUSHO_CD_SHIKU_CD,
                      JUSHO_CD_OAZA_CD,
                      JUSHO_CD_AZA_CD,
                      ZIP,
                      JUSHO_HYOJI_NO,
                      JITAKU_JUSHO_KANA,
                      JUSHO_COUNT_KANA_KEN,
                      JUSHO_COUNT_KANA_SHIKU,
                      JUSHO_COUNT_KANA_OAZA,
                      JUSHO_COUNT_KANJI_KEN,
                      JUSHO_COUNT_KANJI_SHIKU,
                      JUSHO_COUNT_KANJI_OAZA,
                      JITAKU_TEL,
                      STATUS_JUSHOFUMEI,
                      STATUS_DEL_YOTEI_RIYU,
                      STATUS_YOBI,
                      KOTEI_KOMOKU_YOBI_AREA,
                      ISHI_NM_KANJI,
                      JITAKU_JUSHO_KANJI,
                      KINMUSAKI_SHIREC_ID,
                      KINMUSAKI_SHI_CD,
                      KINMUSAKI_YAKUSHOKU_CD,
                      KINMUSAKI_SHOKUI,
                      KINMUSAKI_SZKBUKA_CD,
                      RYKSK_SHI_NM_KANA,
                      RYKSK_SHI_NM_KANJI,
                      SZKBUKA_KANA,
                      SZKBUKA_KANJI,
                      AITSK_CD_KJNREC_ID,
                      AITSK_CD_KJN_CD,
                      MOD_SHORI_YMD_Y,
                      MOD_SHORI_YMD_M,
                      MOD_SHORI_YMD_D,
                      MOD_KBN,
                      TRK_OPE_CD,
                      TRK_DATE,
                      TRK_PGM_ID,
                      UPD_OPE_CD,
                      UPD_DATE,
                      UPD_PGM_ID
                    ) VALUES (
                      vNowData(1),
                      vNowData(2),
                      vNowData(3),
                      vNowData(4),
                      vNowData(5),
                      vNowData(6),
                      vNowData(7),
                      vNowData(8),
                      vNowData(9),
                      vNowData(10),
                      vNowData(11),
                      vNowData(12),
                      vNowData(13),
                      vNowData(14),
                      vNowData(15),
                      vNowData(16),
                      vNowData(17),
                      vNowData(18),
                      vNowData(19),
                      vNowData(20),
                      vNowData(21),
                      vNowData(22),
                      vNowData(23),
                      vNowData(24),
                      vNowData(25),
                      vNowData(26),
                      NVL2(vNowData(27),SUBSTR(vNowData(27),1,3)||'-'||SUBSTR(vNowData(27),4),NULL),
                      vNowData(28),
                      vNowData(29),
                      TO_CHAR(vNowData(30),'FM09'),
                      TO_CHAR(vNowData(31),'FM09'),
                      TO_CHAR(vNowData(32),'FM09'),
                      TO_CHAR(vNowData(33),'FM09'),
                      TO_CHAR(vNowData(34),'FM09'),
                      TO_CHAR(vNowData(35),'FM09'),
                      vNowData(36),
                      vNowData(37),
                      vNowData(38),
                      vNowData(39),
                      vNowData(40)||vNowData(41),
                      vNowData(42),
                      vNowData(43),
                      vNowData(44),
                      vNowData(45),
                      vNowData(46),
                      vNowData(47),
                      vNowData(48),
                      vNowData(49),
                      vNowData(50),
                      tempRecord.SZKBUKA_NM_KANA1,
                      tempRecord.SZKBUKA_NM1,
                      vNowData(51),
                      vNowData(52),
                      SUBSTR(tempRecord.UPD_EIGY_YMD,1,4),
                      SUBSTR(tempRecord.UPD_EIGY_YMD,5,2),
                      SUBSTR(tempRecord.UPD_EIGY_YMD,7,2),
                      vTempModKbn,
                      iOPE_CD,
                      iDATE,
                      iPGM_ID,
                      iOPE_CD,
                      iDATE,
                      iPGM_ID);
                    EXECUTE_SQL := 'INSERT INTO TD_PM_GEN_DCF_KJN(
                      KJNREC_ID,
                      KJN_CD,
                      ISHI_NM_KANA,
                      SEIBETSU,
                      BIRTH_GENGO,
                      BIRTH_Y,
                      BIRTH_M,
                      BIRTH_D,
                      SHUSSHIN_KEN_CD,
                      ISHIKAI_CD,
                      STNEN_GENGO,
                      STNEN_Y,
                      SHUSSHINKO_SHUSSHINKO_CD,
                      SHUSSHINKO_GAKUBU_SKBT_CD,
                      KAIKIN_KBN,
                      KAIGYONEN_GENGO,
                      KAIGYONEN_Y,
                      SNRYKMK_1,
                      SNRYKMK_2,
                      SNRYKMK_3,
                      SNRYKMK_4,
                      SNRYKMK_5,
                      JUSHO_CD_KEN_CD,
                      JUSHO_CD_SHIKU_CD,
                      JUSHO_CD_OAZA_CD,
                      JUSHO_CD_AZA_CD,
                      ZIP,
                      JUSHO_HYOJI_NO,
                      JITAKU_JUSHO_KANA,
                      JUSHO_COUNT_KANA_KEN,
                      JUSHO_COUNT_KANA_SHIKU,
                      JUSHO_COUNT_KANA_OAZA,
                      JUSHO_COUNT_KANJI_KEN,
                      JUSHO_COUNT_KANJI_SHIKU,
                      JUSHO_COUNT_KANJI_OAZA,
                      JITAKU_TEL,
                      STATUS_JUSHOFUMEI,
                      STATUS_DEL_YOTEI_RIYU,
                      STATUS_YOBI,
                      KOTEI_KOMOKU_YOBI_AREA,
                      ISHI_NM_KANJI,
                      JITAKU_JUSHO_KANJI,
                      KINMUSAKI_SHIREC_ID,
                      KINMUSAKI_SHI_CD,
                      KINMUSAKI_YAKUSHOKU_CD,
                      KINMUSAKI_SHOKUI,
                      KINMUSAKI_SZKBUKA_CD,
                      RYKSK_SHI_NM_KANA,
                      RYKSK_SHI_NM_KANJI,
                      SZKBUKA_KANA,
                      SZKBUKA_KANJI,
                      AITSK_CD_KJNREC_ID,
                      AITSK_CD_KJN_CD,
                      MOD_SHORI_YMD_Y,
                      MOD_SHORI_YMD_M,
                      MOD_SHORI_YMD_D,
                      MOD_KBN,
                      TRK_OPE_CD,
                      TRK_DATE,
                      TRK_PGM_ID,
                      UPD_OPE_CD,
                      UPD_DATE,
                      UPD_PGM_ID
                    ) VALUES (
                      '''||vNowData(1)||''',
                      '''||vNowData(2)||''',
                      '''||vNowData(3)||''',
                      '''||vNowData(4)||''',
                      '''||vNowData(5)||''',
                      '''||vNowData(6)||''',
                      '''||vNowData(7)||''',
                      '''||vNowData(8)||''',
                      '''||vNowData(9)||''',
                      '''||vNowData(10)||''',
                      '''||vNowData(11)||''',
                      '''||vNowData(12)||''',
                      '''||vNowData(13)||''',
                      '''||vNowData(14)||''',
                      '''||vNowData(15)||''',
                      '''||vNowData(16)||''',
                      '''||vNowData(17)||''',
                      '''||vNowData(18)||''',
                      '''||vNowData(19)||''',
                      '''||vNowData(20)||''',
                      '''||vNowData(21)||''',
                      '''||vNowData(22)||''',
                      '''||vNowData(23)||''',
                      '''||vNowData(24)||''',
                      '''||vNowData(25)||''',
                      '''||vNowData(26)||''',
                      '''||CASE WHEN vNowData(27) IS NOT NULL THEN SUBSTR(vNowData(27),1,3)||'-'||SUBSTR(vNowData(27),4) ELSE NULL END ||''',
                      '''||vNowData(28)||''',
                      '''||vNowData(29)||''',
                      '''||TO_CHAR(vNowData(30),'FM09')||''',
                      '''||TO_CHAR(vNowData(31),'FM09')||''',
                      '''||TO_CHAR(vNowData(32),'FM09')||''',
                      '''||TO_CHAR(vNowData(33),'FM09')||''',
                      '''||TO_CHAR(vNowData(34),'FM09')||''',
                      '''||TO_CHAR(vNowData(35),'FM09')||''',
                      '''||vNowData(36)||''',
                      '''||vNowData(37)||''',
                      '''||vNowData(38)||''',
                      '''||vNowData(39)||''',
                      '''||vNowData(40)||vNowData(41)||''',
                      '''||vNowData(42)||''',
                      '''||vNowData(43)||''',
                      '''||NVL(vNowData(44),'00')||''',
                      '''||NVL(vNowData(45),'9999999')||''',
                      '''||vNowData(46)||''',
                      '''||vNowData(47)||''',
                      '''||vNowData(48)||''',
                      '''||vNowData(49)||''',
                      '''||vNowData(50)||''',
                      '''||tempRecord.SZKBUKA_NM_KANA1||''',
                      '''||tempRecord.SZKBUKA_NM1||''',
                      '''||vNowData(51)||''',
                      '''||vNowData(52)||''',
                      '''||SUBSTR(tempRecord.UPD_EIGY_YMD,1,4)||''',
                      '''||SUBSTR(tempRecord.UPD_EIGY_YMD,5,2)||''',
                      '''||SUBSTR(tempRecord.UPD_EIGY_YMD,7,2)||''',
                      '''||vMODKBN||''',
                      '''||iOPE_CD||''',
                      '''||iDATE||''',
                      '''||iPGM_ID||''',
                      '''||iOPE_CD||''',
                      '''||iDATE||''',
                      '''||iPGM_ID||''')';
                  ELSIF iM2Flg = ULT_COMMON.FLG_NO THEN
                    INSERT INTO TD_PM_DCF_KJN(
                      KJNREC_ID,
                      KJN_CD,
                      ISHI_NM_KANA,
                      SEIBETSU,
                      BIRTH_GENGO,
                      BIRTH_Y,
                      BIRTH_M,
                      BIRTH_D,
                      SHUSSHIN_KEN_CD,
                      ISHIKAI_CD,
                      STNEN_GENGO,
                      STNEN_Y,
                      SHUSSHINKO_SHUSSHINKO_CD,
                      SHUSSHINKO_GAKUBU_SKBT_CD,
                      KAIKIN_KBN,
                      KAIGYONEN_GENGO,
                      KAIGYONEN_Y,
                      SNRYKMK_1,
                      SNRYKMK_2,
                      SNRYKMK_3,
                      SNRYKMK_4,
                      SNRYKMK_5,
                      JUSHO_CD_KEN_CD,
                      JUSHO_CD_SHIKU_CD,
                      JUSHO_CD_OAZA_CD,
                      JUSHO_CD_AZA_CD,
                      ZIP,
                      JUSHO_HYOJI_NO,
                      JITAKU_JUSHO_KANA,
                      JUSHO_COUNT_KANA_KEN,
                      JUSHO_COUNT_KANA_SHIKU,
                      JUSHO_COUNT_KANA_OAZA,
                      JUSHO_COUNT_KANJI_KEN,
                      JUSHO_COUNT_KANJI_SHIKU,
                      JUSHO_COUNT_KANJI_OAZA,
                      JITAKU_TEL,
                      STATUS_JUSHOFUMEI,
                      STATUS_DEL_YOTEI_RIYU,
                      STATUS_IKKATSU_TRK_FLG,
                      TRKNEN_GENGO,
                      TRKNEN_Y,
                      ISHI_NM_KANJI,
                      JITAKU_JUSHO_KANJI,
                      KINMUSAKI_SHIREC_ID,
                      KINMUSAKI_SHI_CD,
                      KINMUSAKI_YAKUSHOKU_CD,
                      KINMUSAKI_SHOKUI,
                      KINMUSAKI_SZKBUKA_CD,
                      RYKSK_SHI_NM_KANA,
                      RYKSK_SHI_NM_KANJI,
                      SZKBUKA_KANA,
                      SZKBUKA_KANJI,
                      AITSK_CD_KJNREC_ID,
                      AITSK_CD_KJN_CD,
                      MOD_SHORI_YMD_Y,
                      MOD_SHORI_YMD_M,
                      MOD_SHORI_YMD_D,
                      MOD_KBN,
                      TRK_OPE_CD,
                      TRK_DATE,
                      TRK_PGM_ID,
                      UPD_OPE_CD,
                      UPD_DATE,
                      UPD_PGM_ID
                    ) VALUES (
                      vNowData(1),
                      vNowData(2),
                      vNowData(3),
                      vNowData(4),
                      vNowData(5),
                      vNowData(6),
                      vNowData(7),
                      vNowData(8),
                      vNowData(9),
                      vNowData(10),
                      vNowData(11),
                      vNowData(12),
                      vNowData(13),
                      vNowData(14),
                      vNowData(15),
                      vNowData(16),
                      vNowData(17),
                      vNowData(18),
                      vNowData(19),
                      vNowData(20),
                      vNowData(21),
                      vNowData(22),
                      vNowData(23),
                      vNowData(24),
                      vNowData(25),
                      vNowData(26),
                      NVL2(vNowData(27),SUBSTR(vNowData(27),1,3)||'-'||SUBSTR(vNowData(27),4),NULL),
                      vNowData(28),
                      vNowData(29),
                      TO_CHAR(vNowData(30),'FM09'),
                      TO_CHAR(vNowData(31),'FM09'),
                      TO_CHAR(vNowData(32),'FM09'),
                      TO_CHAR(vNowData(33),'FM09'),
                      TO_CHAR(vNowData(34),'FM09'),
                      TO_CHAR(vNowData(35),'FM09'),
                      vNowData(36),
                      vNowData(37),
                      vNowData(38),
                      vNowData(39),
                      vNowData(40),
                      vNowData(41),
                      vNowData(42),
                      vNowData(43),
                      vNowData(44),
                      vNowData(45),
                      vNowData(46),
                      vNowData(47),
                      vNowData(48),
                      vNowData(49),
                      vNowData(50),
                      tempRecord.SZKBUKA_NM_KANA1,
                      tempRecord.SZKBUKA_NM1,
                      vNowData(51),
                      vNowData(52),
                      SUBSTR(tempRecord.UPD_EIGY_YMD,1,4),
                      SUBSTR(tempRecord.UPD_EIGY_YMD,5,2),
                      SUBSTR(tempRecord.UPD_EIGY_YMD,7,2),
                      vTempModKbn,
                      iOPE_CD,
                      iDATE,
                      iPGM_ID,
                      iOPE_CD,
                      iDATE,
                      iPGM_ID);
                    EXECUTE_SQL := 'INSERT INTO TD_PM_DCF_KJN(
                      KJNREC_ID,
                      KJN_CD,
                      ISHI_NM_KANA,
                      SEIBETSU,
                      BIRTH_GENGO,
                      BIRTH_Y,
                      BIRTH_M,
                      BIRTH_D,
                      SHUSSHIN_KEN_CD,
                      ISHIKAI_CD,
                      STNEN_GENGO,
                      STNEN_Y,
                      SHUSSHINKO_SHUSSHINKO_CD,
                      SHUSSHINKO_GAKUBU_SKBT_CD,
                      KAIKIN_KBN,
                      KAIGYONEN_GENGO,
                      KAIGYONEN_Y,
                      SNRYKMK_1,
                      SNRYKMK_2,
                      SNRYKMK_3,
                      SNRYKMK_4,
                      SNRYKMK_5,
                      JUSHO_CD_KEN_CD,
                      JUSHO_CD_SHIKU_CD,
                      JUSHO_CD_OAZA_CD,
                      JUSHO_CD_AZA_CD,
                      ZIP,
                      JUSHO_HYOJI_NO,
                      JITAKU_JUSHO_KANA,
                      JUSHO_COUNT_KANA_KEN,
                      JUSHO_COUNT_KANA_SHIKU,
                      JUSHO_COUNT_KANA_OAZA,
                      JUSHO_COUNT_KANJI_KEN,
                      JUSHO_COUNT_KANJI_SHIKU,
                      JUSHO_COUNT_KANJI_OAZA,
                      JITAKU_TEL,
                      STATUS_JUSHOFUMEI,
                      STATUS_DEL_YOTEI_RIYU,
                      STATUS_IKKATSU_TRK_FLG,
                      TRKNEN_GENGO,
                      TRKNEN_Y,
                      ISHI_NM_KANJI,
                      JITAKU_JUSHO_KANJI,
                      KINMUSAKI_SHIREC_ID,
                      KINMUSAKI_SHI_CD,
                      KINMUSAKI_YAKUSHOKU_CD,
                      KINMUSAKI_SHOKUI,
                      KINMUSAKI_SZKBUKA_CD,
                      RYKSK_SHI_NM_KANA,
                      RYKSK_SHI_NM_KANJI,
                      SZKBUKA_KANA,
                      SZKBUKA_KANJI,
                      AITSK_CD_KJNREC_ID,
                      AITSK_CD_KJN_CD,
                      MOD_SHORI_YMD_Y,
                      MOD_SHORI_YMD_M,
                      MOD_SHORI_YMD_D,
                      MOD_KBN,
                      TRK_OPE_CD,
                      TRK_DATE,
                      TRK_PGM_ID,
                      UPD_OPE_CD,
                      UPD_DATE,
                      UPD_PGM_ID
                    ) VALUES (
                      '''||vNowData(1)||''',
                      '''||vNowData(2)||''',
                      '''||vNowData(3)||''',
                      '''||vNowData(4)||''',
                      '''||vNowData(5)||''',
                      '''||vNowData(6)||''',
                      '''||vNowData(7)||''',
                      '''||vNowData(8)||''',
                      '''||vNowData(9)||''',
                      '''||vNowData(10)||''',
                      '''||vNowData(11)||''',
                      '''||vNowData(12)||''',
                      '''||vNowData(13)||''',
                      '''||vNowData(14)||''',
                      '''||vNowData(15)||''',
                      '''||vNowData(16)||''',
                      '''||vNowData(17)||''',
                      '''||vNowData(18)||''',
                      '''||vNowData(19)||''',
                      '''||vNowData(20)||''',
                      '''||vNowData(21)||''',
                      '''||vNowData(22)||''',
                      '''||vNowData(23)||''',
                      '''||vNowData(24)||''',
                      '''||vNowData(25)||''',
                      '''||vNowData(26)||''',
                      '''||CASE WHEN vNowData(27) IS NOT NULL THEN SUBSTR(vNowData(27),1,3)||'-'||SUBSTR(vNowData(27),4) ELSE NULL END ||''',
                      '''||vNowData(28)||''',
                      '''||vNowData(29)||''',
                      '''||TO_CHAR(vNowData(30),'FM09')||''',
                      '''||TO_CHAR(vNowData(31),'FM09')||''',
                      '''||TO_CHAR(vNowData(32),'FM09')||''',
                      '''||TO_CHAR(vNowData(33),'FM09')||''',
                      '''||TO_CHAR(vNowData(34),'FM09')||''',
                      '''||TO_CHAR(vNowData(35),'FM09')||''',
                      '''||vNowData(36)||''',
                      '''||vNowData(37)||''',
                      '''||vNowData(38)||''',
                      '''||vNowData(39)||''',
                      '''||vNowData(40)||''',
                      '''||vNowData(41)||''',
                      '''||vNowData(42)||''',
                      '''||vNowData(43)||''',
                      '''||NVL(vNowData(44),'00')||''',
                      '''||NVL(vNowData(45),'9999999')||''',
                      '''||vNowData(46)||''',
                      '''||vNowData(47)||''',
                      '''||vNowData(48)||''',
                      '''||vNowData(49)||''',
                      '''||vNowData(50)||''',
                      '''||tempRecord.SZKBUKA_NM_KANA1||''',
                      '''||tempRecord.SZKBUKA_NM1||''',
                      '''||vNowData(51)||''',
                      '''||vNowData(52)||''',
                      '''||SUBSTR(tempRecord.UPD_EIGY_YMD,1,4)||''',
                      '''||SUBSTR(tempRecord.UPD_EIGY_YMD,5,2)||''',
                      '''||SUBSTR(tempRecord.UPD_EIGY_YMD,7,2)||''',
                      '''||vMODKBN||''',
                      '''||iOPE_CD||''',
                      '''||iDATE||''',
                      '''||iPGM_ID||''',
                      '''||iOPE_CD||''',
                      '''||iDATE||''',
                      '''||iPGM_ID||''')';
                  ELSE
                    INSERT INTO TD_P2_DCF_KJN(
                      KJNREC_ID,
                      KJN_CD,
                      ISHI_NM_KANA,
                      SEIBETSU,
                      BIRTH_GENGO,
                      BIRTH_Y,
                      BIRTH_M,
                      BIRTH_D,
                      SHUSSHIN_KEN_CD,
                      ISHIKAI_CD,
                      STNEN_GENGO,
                      STNEN_Y,
                      SHUSSHINKO_SHUSSHINKO_CD,
                      SHUSSHINKO_GAKUBU_SKBT_CD,
                      KAIKIN_KBN,
                      KAIGYONEN_GENGO,
                      KAIGYONEN_Y,
                      SNRYKMK_1,
                      SNRYKMK_2,
                      SNRYKMK_3,
                      SNRYKMK_4,
                      SNRYKMK_5,
                      JUSHO_CD_KEN_CD,
                      JUSHO_CD_SHIKU_CD,
                      JUSHO_CD_OAZA_CD,
                      JUSHO_CD_AZA_CD,
                      ZIP,
                      JUSHO_HYOJI_NO,
                      JITAKU_JUSHO_KANA,
                      JUSHO_COUNT_KANA_KEN,
                      JUSHO_COUNT_KANA_SHIKU,
                      JUSHO_COUNT_KANA_OAZA,
                      JUSHO_COUNT_KANJI_KEN,
                      JUSHO_COUNT_KANJI_SHIKU,
                      JUSHO_COUNT_KANJI_OAZA,
                      JITAKU_TEL,
                      STATUS_JUSHOFUMEI,
                      STATUS_DEL_YOTEI_RIYU,
                      STATUS_IKKATSU_TRK_FLG,
                      TRKNEN_GENGO,
                      TRKNEN_Y,
                      ISHI_NM_KANJI,
                      JITAKU_JUSHO_KANJI,
                      KINMUSAKI_SHIREC_ID,
                      KINMUSAKI_SHI_CD,
                      KINMUSAKI_YAKUSHOKU_CD,
                      KINMUSAKI_SHOKUI,
                      KINMUSAKI_SZKBUKA_CD,
                      RYKSK_SHI_NM_KANA,
                      RYKSK_SHI_NM_KANJI,
                      SZKBUKA_KANA,
                      SZKBUKA_KANJI,
                      AITSK_CD_KJNREC_ID,
                      AITSK_CD_KJN_CD,
                      MOD_SHORI_YMD_Y,
                      MOD_SHORI_YMD_M,
                      MOD_SHORI_YMD_D,
                      MOD_KBN,
                      TRK_OPE_CD,
                      TRK_DATE,
                      TRK_PGM_ID,
                      UPD_OPE_CD,
                      UPD_DATE,
                      UPD_PGM_ID
                    ) VALUES (
                      vNowData(1),
                      vNowData(2),
                      vNowData(3),
                      vNowData(4),
                      vNowData(5),
                      vNowData(6),
                      vNowData(7),
                      vNowData(8),
                      vNowData(9),
                      vNowData(10),
                      vNowData(11),
                      vNowData(12),
                      vNowData(13),
                      vNowData(14),
                      vNowData(15),
                      vNowData(16),
                      vNowData(17),
                      vNowData(18),
                      vNowData(19),
                      vNowData(20),
                      vNowData(21),
                      vNowData(22),
                      vNowData(23),
                      vNowData(24),
                      vNowData(25),
                      vNowData(26),
                      NVL2(vNowData(27),SUBSTR(vNowData(27),1,3)||'-'||SUBSTR(vNowData(27),4),NULL),
                      vNowData(28),
                      vNowData(29),
                      TO_CHAR(vNowData(30),'FM09'),
                      TO_CHAR(vNowData(31),'FM09'),
                      TO_CHAR(vNowData(32),'FM09'),
                      TO_CHAR(vNowData(33),'FM09'),
                      TO_CHAR(vNowData(34),'FM09'),
                      TO_CHAR(vNowData(35),'FM09'),
                      vNowData(36),
                      vNowData(37),
                      vNowData(38),
                      vNowData(39),
                      vNowData(40),
                      vNowData(41),
                      vNowData(42),
                      vNowData(43),
                      vNowData(44),
                      vNowData(45),
                      vNowData(46),
                      vNowData(47),
                      vNowData(48),
                      vNowData(49),
                      vNowData(50),
                      tempRecord.SZKBUKA_NM_KANA1,
                      tempRecord.SZKBUKA_NM1,
                      vNowData(51),
                      vNowData(52),
                      SUBSTR(tempRecord.UPD_EIGY_YMD,1,4),
                      SUBSTR(tempRecord.UPD_EIGY_YMD,5,2),
                      SUBSTR(tempRecord.UPD_EIGY_YMD,7,2),
                      vTempModKbn,
                      iOPE_CD,
                      iDATE,
                      iPGM_ID,
                      iOPE_CD,
                      iDATE,
                      iPGM_ID);
                    EXECUTE_SQL := 'INSERT INTO TD_P2_DCF_KJN(
                      KJNREC_ID,
                      KJN_CD,
                      ISHI_NM_KANA,
                      SEIBETSU,
                      BIRTH_GENGO,
                      BIRTH_Y,
                      BIRTH_M,
                      BIRTH_D,
                      SHUSSHIN_KEN_CD,
                      ISHIKAI_CD,
                      STNEN_GENGO,
                      STNEN_Y,
                      SHUSSHINKO_SHUSSHINKO_CD,
                      SHUSSHINKO_GAKUBU_SKBT_CD,
                      KAIKIN_KBN,
                      KAIGYONEN_GENGO,
                      KAIGYONEN_Y,
                      SNRYKMK_1,
                      SNRYKMK_2,
                      SNRYKMK_3,
                      SNRYKMK_4,
                      SNRYKMK_5,
                      JUSHO_CD_KEN_CD,
                      JUSHO_CD_SHIKU_CD,
                      JUSHO_CD_OAZA_CD,
                      JUSHO_CD_AZA_CD,
                      ZIP,
                      JUSHO_HYOJI_NO,
                      JITAKU_JUSHO_KANA,
                      JUSHO_COUNT_KANA_KEN,
                      JUSHO_COUNT_KANA_SHIKU,
                      JUSHO_COUNT_KANA_OAZA,
                      JUSHO_COUNT_KANJI_KEN,
                      JUSHO_COUNT_KANJI_SHIKU,
                      JUSHO_COUNT_KANJI_OAZA,
                      JITAKU_TEL,
                      STATUS_JUSHOFUMEI,
                      STATUS_DEL_YOTEI_RIYU,
                      STATUS_IKKATSU_TRK_FLG,
                      TRKNEN_GENGO,
                      TRKNEN_Y,
                      ISHI_NM_KANJI,
                      JITAKU_JUSHO_KANJI,
                      KINMUSAKI_SHIREC_ID,
                      KINMUSAKI_SHI_CD,
                      KINMUSAKI_YAKUSHOKU_CD,
                      KINMUSAKI_SHOKUI,
                      KINMUSAKI_SZKBUKA_CD,
                      RYKSK_SHI_NM_KANA,
                      RYKSK_SHI_NM_KANJI,
                      SZKBUKA_KANA,
                      SZKBUKA_KANJI,
                      AITSK_CD_KJNREC_ID,
                      AITSK_CD_KJN_CD,
                      MOD_SHORI_YMD_Y,
                      MOD_SHORI_YMD_M,
                      MOD_SHORI_YMD_D,
                      MOD_KBN,
                      TRK_OPE_CD,
                      TRK_DATE,
                      TRK_PGM_ID,
                      UPD_OPE_CD,
                      UPD_DATE,
                      UPD_PGM_ID
                    ) VALUES (
                      '''||vNowData(1)||''',
                      '''||vNowData(2)||''',
                      '''||vNowData(3)||''',
                      '''||vNowData(4)||''',
                      '''||vNowData(5)||''',
                      '''||vNowData(6)||''',
                      '''||vNowData(7)||''',
                      '''||vNowData(8)||''',
                      '''||vNowData(9)||''',
                      '''||vNowData(10)||''',
                      '''||vNowData(11)||''',
                      '''||vNowData(12)||''',
                      '''||vNowData(13)||''',
                      '''||vNowData(14)||''',
                      '''||vNowData(15)||''',
                      '''||vNowData(16)||''',
                      '''||vNowData(17)||''',
                      '''||vNowData(18)||''',
                      '''||vNowData(19)||''',
                      '''||vNowData(20)||''',
                      '''||vNowData(21)||''',
                      '''||vNowData(22)||''',
                      '''||vNowData(23)||''',
                      '''||vNowData(24)||''',
                      '''||vNowData(25)||''',
                      '''||vNowData(26)||''',
                      '''||CASE WHEN vNowData(27) IS NOT NULL THEN SUBSTR(vNowData(27),1,3)||'-'||SUBSTR(vNowData(27),4) ELSE NULL END ||''',
                      '''||vNowData(28)||''',
                      '''||vNowData(29)||''',
                      '''||TO_CHAR(vNowData(30),'FM09')||''',
                      '''||TO_CHAR(vNowData(31),'FM09')||''',
                      '''||TO_CHAR(vNowData(32),'FM09')||''',
                      '''||TO_CHAR(vNowData(33),'FM09')||''',
                      '''||TO_CHAR(vNowData(34),'FM09')||''',
                      '''||TO_CHAR(vNowData(35),'FM09')||''',
                      '''||vNowData(36)||''',
                      '''||vNowData(37)||''',
                      '''||vNowData(38)||''',
                      '''||vNowData(39)||''',
                      '''||vNowData(40)||''',
                      '''||vNowData(41)||''',
                      '''||vNowData(42)||''',
                      '''||vNowData(43)||''',
                      '''||NVL(vNowData(44),'00')||''',
                      '''||NVL(vNowData(45),'9999999')||''',
                      '''||vNowData(46)||''',
                      '''||vNowData(47)||''',
                      '''||vNowData(48)||''',
                      '''||vNowData(49)||''',
                      '''||vNowData(50)||''',
                      '''||tempRecord.SZKBUKA_NM_KANA1||''',
                      '''||tempRecord.SZKBUKA_NM1||''',
                      '''||vNowData(51)||''',
                      '''||vNowData(52)||''',
                      '''||SUBSTR(tempRecord.UPD_EIGY_YMD,1,4)||''',
                      '''||SUBSTR(tempRecord.UPD_EIGY_YMD,5,2)||''',
                      '''||SUBSTR(tempRecord.UPD_EIGY_YMD,7,2)||''',
                      '''||vMODKBN||''',
                      '''||iOPE_CD||''',
                      '''||iDATE||''',
                      '''||iPGM_ID||''',
                      '''||iOPE_CD||''',
                      '''||iDATE||''',
                      '''||iPGM_ID||''')';
                  END IF;
                  ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);
                END IF;
              END LOOP;
            END IF;
            vKojinCount := 0;
            vMODKBN:=ULT_COMMON.MOD_KBN_NO;
            tempTABLE.DELETE;
          END IF;
          EXIT WHEN cur%NOTFOUND;
          --���݂̃f�[�^���ꎞ�ϐ��ɂ����
          tempTABLE.EXTEND;
          tempTABLE(tempTABLE.COUNT):=vBAITAI_ZANTEI_RECORD;

          IF vMODKBN = ULT_COMMON.MOD_KBN_NO  THEN
            --����f�[�^������A�O��f�[�^���Ȃ��ꍇ�A�ǉ��Ƃ��ēo�^����i��r����2�̐擪��TAB�̏ꍇ�j
            IF SUBSTR(vBAITAI_ZANTEI_RECORD.FIELD2,1,1)=ULT_COMMON.DELIMITER THEN
              vMODKBN:=ULT_COMMON.MOD_KBN_ADD;

            --����f�[�^���폜���ꂽ�ꍇ�A�f�[�^�͓o�^���Ȃ��i��r�p�f�[�^�̍폜�t���O = "1"�̏ꍇ�j
            ELSIF NVL(vBAITAI_ZANTEI_RECORD.DEL_FLG,'0') = '1' THEN
              vMODKBN:=ULT_COMMON.MOD_KBN_DEL;

            --����ƑO��ŕω��̂���f�[�^�͕ύX�Ƃ��ēo�^����i��r����1�Ɣ�r����2����v���Ă��Ȃ��܂��́A����͂̏������ȂɕύX������ꍇ�j
            ELSIF vBAITAI_ZANTEI_RECORD.FIELD1 != vBAITAI_ZANTEI_RECORD.FIELD2 OR 
            	 -- ������ 2012/10/12 CP000112�̑Ή�
            	(NVL(vBAITAI_ZANTEI_RECORD.SZKBUKA_CD1,'0')!=NVL(vBAITAI_ZANTEI_RECORD.SZKBUKA_CD2,'0')) OR
            	(NVL(vBAITAI_ZANTEI_RECORD.SZKBUKA_CD1,'0') = NVL(vBAITAI_ZANTEI_RECORD.SZKBUKA_CD2,'0') AND NVL(vBAITAI_ZANTEI_RECORD.Szkbuka_Cd1,'0') = '9999' AND
             	(NVL(vBAITAI_ZANTEI_RECORD.SZKBUKA_NM_KANA1,'0') !=NVL(vBAITAI_ZANTEI_RECORD.SZKBUKA_NM_KANA2,'0') OR NVL(vBAITAI_ZANTEI_RECORD.SZKBUKA_NM1,'0') != NVL(vBAITAI_ZANTEI_RECORD.SZKBUKA_NM2,'0')))
                 -- ������ 2012/10/12 CP000112�̑Ή�
            THEN
            	--��r���ڂ��獡��f�[�^�̔z��ƑO��f�[�^�̔z����擾����
                vNowData := ULT_COMMON.StrSplit(vBAITAI_ZANTEI_RECORD.FIELD1, ULT_COMMON.DELIMITER);
                vLastData := ULT_COMMON.StrSplit(vBAITAI_ZANTEI_RECORD.FIELD2, ULT_COMMON.DELIMITER);
                
                -- �l��񂪕ς�邩�ǂ������f���s���B
	            vIsKojinChangedFlg := NULL; 
	            FOR j IN 1..52 LOOP
                	IF j = 44 OR j = 45 OR j = 46 OR j = 47 OR 
                	   j = 48 OR j = 49 OR j = 50 THEN
                	   -- �������Ȃ�
                	   NULL;
                	ELSE
                	  IF '1' || vNowData(j) != '1' || vLastData(j) THEN
                	  	--  �l��񂪕ς�邩�ǂ������f�t���O�̐ݒ�
                	  	vIsKojinChangedFlg := '1';
                	  	EXIT;
                	  END IF;
                	END IF;   
	             END LOOP;
	             
	            IF vLastData(44) IS NULL THEN
				  	IF vNowData(44) IS NOT NULL AND vNowData(53) IS NOT NULL THEN
			  			IF vIsKojinChangedFlg IS NULL THEN
	                  		NULL;
                    	ELSE
                    		vMODKBN:=ULT_COMMON.MOD_KBN_YES;
                    	END IF;
                    ELSE
                    	vMODKBN:=ULT_COMMON.MOD_KBN_YES;	
                    END IF;
			    ELSE
				  	IF vNowData(53) IS NOT NULL AND vLastData(53) IS NOT NULL THEN
				  		IF vIsKojinChangedFlg IS NULL THEN
	                  		NULL;
	                    ELSE
	                        vMODKBN:=ULT_COMMON.MOD_KBN_YES;
	                    END IF;
	                ELSE
	                	vMODKBN:=ULT_COMMON.MOD_KBN_YES;
	                END IF;
				END IF;
            END IF;
          END IF;
       END LOOP;
       
       -- �J�[�\�������
       CLOSE cur;
       
       vINSERT_SQL := NULL;
       -- �l�P�ʂŃf�[�^��o�^���鏈���i�l�ɕR�Â��S�f�[�^���o�^���ꂽ��Ԃɂ���j
	   -- �u�l�R�[�h_���R�[�hID�A�l�R�[�h_�l�R�[�h�v����v���A
	   -- �u�Ζ���_�{�݃R�[�h_���R�[�hID�A�Ζ���_�{�݃R�[�h_�{�݃R�[�h�v���s��v�̃f�[�^��o�^����΂悢
       IF iLayoutKind = ULT_COMMON.LAYOUT_SBT_CD_ZANTEI THEN
          IF iM2Flg = ULT_COMMON.FLG_NO THEN
          	vINSERT_TBL := ' TD_PM_DCF_KJN ';
          ELSE
          	vINSERT_TBL := ' TD_P2_DCF_KJN '; 
          END IF;
          
          vINSERT_SQL := 'INSERT INTO ' || vINSERT_TBL
       				  	|| ' SELECT'
						|| ' A.REC_ID'
						|| ',A.KJN_CD'
						|| ',NULL'
						|| ',A.KJN_NM_KANA'
						|| ',A.SEIBETSU_KBN'
						|| ',A.BIRTH_GENGO_CD'
						|| ',A.BIRTH_WY'
						|| ',A.BIRTH_M'
						|| ',A.BIRTH_D'
						|| ',NULL'
						|| ',A.SHUSSHINCHI_RIDAI_CD'
						|| ',A.KANYU_ISHIKAI_RIDAI_CD'
						|| ',A.STNEN_GENGO_CD'
						|| ',A.STNEN_WY'
						|| ',A.SHUSSHINKO_CD'
						|| ',A.GAKUBU_SHIKIBETSU_KBN'
						|| ',A.KAIKIN_KBN'
						|| ',A.KAIGYONEN_GENGO_CD'
						|| ',A.KAIGYONEN_WY'
						|| ',A.SNRYKMK_CD_1'
						|| ',A.SNRYKMK_CD_2'
						|| ',A.SNRYKMK_CD_3'
						|| ',A.SNRYKMK_CD_4'
						|| ',A.SNRYKMK_CD_5'
						|| ',A.KEN_CD'
						|| ',A.SHIKU_CD'
						|| ',A.OAZA_CD'
						|| ',A.AZA_CD'
						|| ',NVL2(A.ZIP,SUBSTR(A.ZIP,1,3) || ''-'' || SUBSTR(A.ZIP,4),NULL)'
						|| ',A.JUSHO_HYOJI_NO'
						|| ',NULL'
						|| ',A.JUSHO_KANA_RENKETSU'
						|| ',TO_CHAR(A.KEN_NM_KANA_MOJI_SU, ''FM09'')'
						|| ',TO_CHAR(A.SHIKU_NM_KANA_MOJI_SU, ''FM09'')'
						|| ',TO_CHAR(A.OAZA_NM_KANA_MOJI_SU, ''FM09'')'
						|| ',TO_CHAR(A.KEN_NM_KANJI_MOJI_SU, ''FM09'')'
						|| ',TO_CHAR(A.SHIKU_NM_KANJI_MOJI_SU, ''FM09'')'
						|| ',TO_CHAR(A.OAZA_NM_KANJI_MOJI_SU, ''FM09'')'
						|| ',A.TEL'
						|| ',A.JUSHOFUMEI_CD'
						|| ',A.DEL_YOTEI_RIYU_CD'
						|| ',A.IKKATSU_TRK_FLG'
						|| ',NULL'
						|| ',A.TRKNEN_GENGO_CD'
						|| ',A.TRKNEN_WY'
						|| ',NULL'
						|| ',A.KJN_NM'
						|| ',A.JUSHO_KANJI_RENKETSU'
						|| ',B.KINMUSAKI_REC_ID'
						|| ',B.KINMUSAKI_SHI_CD'
						|| ',NULL'
						|| ',B.YAKUSHOKU_CD'
						|| ',B.SHOKUI_CD'
						|| ',B.SZKBUKA_CD'
						|| ',NULL'
						|| ',C.SHI_RN_KANA'
						|| ',C.SHI_RN'
						|| ',DECODE(B.SZKBUKA_CD, ''9999'', B.NYURYOKU_SZKBUKA_NM_KANA, SUBSTR(D.SZKBUKA_NM_KANA, 1, 20))'
						|| ',DECODE(B.SZKBUKA_CD, ''9999'', B.NYURYOKU_SZKBUKA_NM, SUBSTR(D.SZKBUKA_NM, 1, 15))'
						|| ',NULL'
						|| ',A.CHOFUKU_AITSK_REC_ID'
						|| ',A.CHOFUKU_AITSK_KJN_CD'
						|| ',NULL'
						|| ',SUBSTR(M.MOD_SHORI_YMD, 1, 4) '
						|| ',SUBSTR(M.MOD_SHORI_YMD, 5, 2) '
						|| ',SUBSTR(M.MOD_SHORI_YMD, 7, 2) '
						|| ',''B'''
						|| ',''' || iOPE_CD || ''''
						|| ',TO_DATE(' || TO_CHAR(iDATE, 'YYYYMMDDHH24MISS') || ', ''YYYYMMDDHH24MISS'')'
						|| ',''' || iPGM_ID || ''''
						|| ',''' || iOPE_CD || ''''
						|| ',TO_DATE(' || TO_CHAR(iDATE, 'YYYYMMDDHH24MISS') || ', ''YYYYMMDDHH24MISS'')'
						|| ',''' || iPGM_ID || ''''
						|| ' FROM'
						|| ' TT_TIKY_KJN A'
						|| ' INNER JOIN '
						|| '              ( '
						|| '                 SELECT '
						|| '                       TBL.KJNREC_ID, '
						|| '                       TBL.KJN_CD, '
						|| '                       MAX(TBL.MOD_SHORI_YMD_Y || TBL.MOD_SHORI_YMD_M || TBL.MOD_SHORI_YMD_D) AS MOD_SHORI_YMD '
						|| '                 FROM  ' || vINSERT_TBL || ' TBL '
						|| '                 WHERE TBL.KINMUSAKI_SHIREC_ID = ''00'''
						|| '                   AND TBL.KINMUSAKI_SHI_CD != ''9999999'''
						|| '                 GROUP BY '
						|| '                       TBL.KJNREC_ID, '
						|| '                       TBL.KJN_CD '
						|| '               ) M '
						|| '     ON A.REC_ID = M.KJNREC_ID '
						|| '     AND A.KJN_CD = M.KJN_CD '
						|| ' INNER JOIN'
						|| '     TT_TIKY_KJN_KINMUSAKI B'
						|| '     ON A.REC_ID = B.REC_ID'
						|| '     AND A.KJN_CD = B.KJN_CD'
						|| '     AND B.TAISHOKU_FLG IS NULL'
						|| ' LEFT OUTER JOIN'
						|| '     TT_TIKY_SHI C'
						|| '     ON B.KINMUSAKI_REC_ID = C.REC_ID'
						|| '     AND B.KINMUSAKI_SHI_CD = C.SHI_CD'
						|| ' LEFT OUTER JOIN'
						|| '     TM_TIKY_HIFG_SSY_SZKBUKA D'
						|| '     ON B.SZKBUKA_CD = D.SZKBUKA_CD'
						|| ' WHERE A.DEL_FLG IS NULL '
						|| '     AND A.REC_ID = ''01'' '
						|| '     AND NOT EXISTS'
						|| '     				(SELECT S.KJNREC_ID '
						|| '                     FROM ' || vINSERT_TBL || ' S'
						|| '      				 WHERE A.REC_ID = S.KJNREC_ID'
						|| '      				   AND A.KJN_CD = S.KJN_CD'
						|| '                       AND B.KINMUSAKI_REC_ID = S.KINMUSAKI_SHIREC_ID '
						|| '                       AND B.KINMUSAKI_SHI_CD = S.KINMUSAKI_SHI_CD '
						|| '                    ) '
				;

			EXECUTE IMMEDIATE vINSERT_SQL;
       ELSIF iLayoutKind = ULT_COMMON.LAYOUT_SBT_CD_2SEDAIMAE THEN
          vINSERT_TBL := ' TD_PM_GEN_DCF_KJN '; 
          
          vINSERT_SQL := 'INSERT INTO ' || vINSERT_TBL
       				  	|| ' SELECT'
						|| ' A.REC_ID'
						|| ',A.KJN_CD'
						|| ',NULL'
						|| ',A.KJN_NM_KANA'
						|| ',A.SEIBETSU_KBN'
						|| ',A.BIRTH_GENGO_CD'
						|| ',A.BIRTH_WY'
						|| ',A.BIRTH_M'
						|| ',A.BIRTH_D'
						|| ',NULL'
						|| ',A.SHUSSHINCHI_RIDAI_CD'
						|| ',A.KANYU_ISHIKAI_RIDAI_CD'
						|| ',A.STNEN_GENGO_CD'
						|| ',A.STNEN_WY'
						|| ',A.SHUSSHINKO_CD'
						|| ',A.GAKUBU_SHIKIBETSU_KBN'
						|| ',A.KAIKIN_KBN'
						|| ',A.KAIGYONEN_GENGO_CD'
						|| ',A.KAIGYONEN_WY'
						|| ',A.SNRYKMK_CD_1'
						|| ',A.SNRYKMK_CD_2'
						|| ',A.SNRYKMK_CD_3'
						|| ',A.SNRYKMK_CD_4'
						|| ',A.SNRYKMK_CD_5'
						|| ',A.KEN_CD'
						|| ',A.SHIKU_CD'
						|| ',A.OAZA_CD'
						|| ',A.AZA_CD'
						|| ',NVL2(A.ZIP,SUBSTR(A.ZIP,1,3) || ''-'' || SUBSTR(A.ZIP,4),NULL)'
						|| ',A.JUSHO_HYOJI_NO'
						|| ',NULL'
						|| ',A.JUSHO_KANA_RENKETSU'
						|| ',TO_CHAR(A.KEN_NM_KANA_MOJI_SU, ''FM09'')'
						|| ',TO_CHAR(A.SHIKU_NM_KANA_MOJI_SU, ''FM09'')'
						|| ',TO_CHAR(A.OAZA_NM_KANA_MOJI_SU, ''FM09'')'
						|| ',TO_CHAR(A.KEN_NM_KANJI_MOJI_SU, ''FM09'')'
						|| ',TO_CHAR(A.SHIKU_NM_KANJI_MOJI_SU, ''FM09'')'
						|| ',TO_CHAR(A.OAZA_NM_KANJI_MOJI_SU, ''FM09'')'
						|| ',A.TEL'
						|| ',A.JUSHOFUMEI_CD'
						|| ',A.DEL_YOTEI_RIYU_CD'
						|| ',A.IKKATSU_TRK_FLG'
						|| ',A.TRKNEN_GENGO_CD || A.TRKNEN_WY'
						|| ',A.KJN_NM'
						|| ',A.JUSHO_KANJI_RENKETSU'
						|| ',B.KINMUSAKI_REC_ID'
						|| ',B.KINMUSAKI_SHI_CD'
						|| ',NULL'
						|| ',B.YAKUSHOKU_CD'
						|| ',B.SHOKUI_CD'
						|| ',B.SZKBUKA_CD'
						|| ',NULL'
						|| ',C.SHI_RN_KANA'
						|| ',C.SHI_RN'
						|| ',DECODE(B.SZKBUKA_CD, ''9999'', B.NYURYOKU_SZKBUKA_NM_KANA, SUBSTR(D.SZKBUKA_NM_KANA, 1, 20))'
						|| ',DECODE(B.SZKBUKA_CD, ''9999'', B.NYURYOKU_SZKBUKA_NM, SUBSTR(D.SZKBUKA_NM, 1, 15))'
						|| ',NULL'
						|| ',A.CHOFUKU_AITSK_REC_ID'
						|| ',A.CHOFUKU_AITSK_KJN_CD'
						|| ',NULL'
						|| ',SUBSTR(M.MOD_SHORI_YMD, 1, 4) '
						|| ',SUBSTR(M.MOD_SHORI_YMD, 5, 2) '
						|| ',SUBSTR(M.MOD_SHORI_YMD, 7, 2) '
						|| ',''B'''
						|| ',''' || iOPE_CD || ''''
						|| ',TO_DATE(' || TO_CHAR(iDATE, 'YYYYMMDDHH24MISS') || ', ''YYYYMMDDHH24MISS'')'
						|| ',''' || iPGM_ID || ''''
						|| ',''' || iOPE_CD || ''''
						|| ',TO_DATE(' || TO_CHAR(iDATE, 'YYYYMMDDHH24MISS') || ', ''YYYYMMDDHH24MISS'')'
						|| ',''' || iPGM_ID || ''''
						|| ' FROM'
						|| ' TT_TIKY_KJN A'
						|| ' INNER JOIN '
						|| '              ( '
						|| '                 SELECT '
						|| '                       DISTINCT '
						|| '                       TBL.KJNREC_ID, '
						|| '                       TBL.KJN_CD, '
						|| '                       MAX(TBL.MOD_SHORI_YMD_Y || TBL.MOD_SHORI_YMD_M || TBL.MOD_SHORI_YMD_D) AS MOD_SHORI_YMD '
						|| '                 FROM  ' || vINSERT_TBL || ' TBL '
						|| '                 WHERE TBL.KINMUSAKI_SHIREC_ID = ''00'''
						|| '                   AND TBL.KINMUSAKI_SHI_CD != ''9999999'''
						|| '                 GROUP BY '
						|| '                       TBL.KJNREC_ID, '
						|| '                       TBL.KJN_CD '
						|| '               ) M '
						|| '     ON A.REC_ID = M.KJNREC_ID '
						|| '     AND A.KJN_CD = M.KJN_CD '
						|| ' INNER JOIN'
						|| '     TT_TIKY_KJN_KINMUSAKI B'
						|| '     ON A.REC_ID = B.REC_ID'
						|| '     AND A.KJN_CD = B.KJN_CD'
						|| '     AND B.TAISHOKU_FLG IS NULL'
						|| ' LEFT OUTER JOIN'
						|| '     TT_TIKY_SHI C'
						|| '     ON B.KINMUSAKI_REC_ID = C.REC_ID'
						|| '     AND B.KINMUSAKI_SHI_CD = C.SHI_CD'
						|| ' LEFT OUTER JOIN'
						|| '     TM_TIKY_HIFG_SSY_SZKBUKA D'
						|| '     ON B.SZKBUKA_CD = D.SZKBUKA_CD'
						|| ' WHERE A.DEL_FLG IS NULL '
						|| '     AND A.REC_ID = ''01'' '
						|| '     AND NOT EXISTS'
						|| '     				(SELECT S.KJNREC_ID '
						|| '                     FROM ' || vINSERT_TBL || ' S'
						|| '      				 WHERE A.REC_ID = S.KJNREC_ID'
						|| '      				   AND A.KJN_CD = S.KJN_CD'
						|| '                       AND B.KINMUSAKI_REC_ID = S.KINMUSAKI_SHIREC_ID '
						|| '                       AND B.KINMUSAKI_SHI_CD = S.KINMUSAKI_SHI_CD '
						|| '                    ) '
				;
			EXECUTE IMMEDIATE vINSERT_SQL;
       END IF;
       
       -- �C���敪��"�c"�̃��R�[�h���폜����
	   vINSERT_SQL := 'DELETE FROM  ' || vINSERT_TBL || ' TBL '	|| ' WHERE TBL.MOD_KBN = ''D''';
		
	   EXECUTE IMMEDIATE vINSERT_SQL;

     END IF;

     commit;

     -- �I�����O�o��
     ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'PL/SQL End',PGM_ID || '�̏������I�����܂����B',iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

    -- ����I��
    oROW_COUNT := -1;
    RETURN 0;

    -- ��O����
  EXCEPTION
    -- ���̑��G���[
    WHEN OTHERS THEN
      W_ERR_INF_RCD.ERR_CD     := TO_CHAR(SQLCODE);
      W_ERR_INF_RCD.ERR_MSG     := SUBSTR(SQLERRM, 0, 500);
      W_ERR_INF_RCD.ERR_KEY_INF   := SUBSTR('iLayoutKind:' || iLayoutKind || ', iShimeKind:' || iShimeKind , 0,500);
      W_INDEX_N           := W_ERR_INF_TBL.COUNT + 1;
      W_ERR_INF_TBL.EXTEND;
      W_ERR_INF_TBL(W_INDEX_N)   := W_ERR_INF_RCD;

      OPEN oOUT_ERR_INF_CSR FOR
        SELECT * FROM TABLE(W_ERR_INF_TBL);
      ROLLBACK;
      
      --�G���[���O�̓o�^
      ULT_INSERT_LOG_TABLE('ERROR',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'ERROR_INFO',W_ERR_INF_RCD.ERR_MSG,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);
      
       -- �ُ�G���[�Ƃ��A
        RETURN ULT_COMMON.RESULT_ERROR;
END;

END;
/