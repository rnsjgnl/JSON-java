CREATE OR REPLACE PACKAGE ULT_KGF_LOT_KANLI
/* **********************************************************
 *  Copyright(c) 2011 beyond, INTEC Inc. All rights reserved.
 * **********************************************************/
AUTHID CURRENT_USER
IS
	/*** �J�[�\���^ ***************************************************************/
	-- �G���[���i�[�p�J�[�\���^
	TYPE ERR_INF_CSR			IS REF CURSOR;

	/*
	************************************************************************
	*  TT_SISN_KGF_LOT(�ŐVKGF���b�g�e�[�u��)
	*  TT_SISN_KGF_KNG(�ŐVKGF�Ō�e�[�u��)
	*  TRUNCATE��INSERT
	************************************************************************
	*/
	FUNCTION NEXT_LOT_CREATE(
		iMaxKfgLotNo			IN TT_SISN_KGF_LOT.KGF_LOT_NO%TYPE,		-- �ŐV�̃��b�g�ԍ�
		iTrkEigyYmd			IN TT_SISN_KGF_LOT.TRK_EIGY_YMD%TYPE,		-- �o�^�����c�ƔN����
		iTrkOpeCd			IN TT_SISN_KGF_LOT.TRK_OPE_CD%TYPE,		-- �o�^�I�y���[�^�R�[�h
		iTrkDate			IN TT_SISN_KGF_LOT.TRK_DATE%TYPE,		-- �o�^����
		iTrkPgmId			IN TT_SISN_KGF_LOT.TRK_PGM_ID%TYPE,		-- �o�^�v���O����ID
		iIP_ADDR			IN TL_STORED_SHORI.IP%TYPE,			-- ���s�[��IP�A�h���X
		iWINDOWS_LOGIN_USER		IN TL_STORED_SHORI.WINDOWS_LOGIN_USER%TYPE,	-- ���s�[��OS���[�U�[
		oROW_COUNT			OUT NUMBER,         				-- �쐬����
		oOUT_ERR_INF_CSR 		OUT ERR_INF_CSR    				-- �G���[���J�[�\��
	) RETURN NUMBER;

	/*
	************************************************************************
	*  �ŐVKGF���b�g�e�[�u���̃��b�N
	************************************************************************
	*/
	FUNCTION LOCK_KGF_LOT(
		iTrkOpeCd			IN TT_ROW_LOCK.TRK_OPE_CD%TYPE,			-- �o�^�I�y���[�^�R�[�h
		iTrkDate			IN TT_ROW_LOCK.TRK_DATE%TYPE,			-- �o�^����
		iTrkPgmId			IN TT_ROW_LOCK.TRK_PGM_ID%TYPE,			-- �o�^�v���O����ID
		iIP_ADDR			IN TL_STORED_SHORI.IP%TYPE,			-- ���s�[��IP�A�h���X
		iWINDOWS_LOGIN_USER		IN TL_STORED_SHORI.WINDOWS_LOGIN_USER%TYPE,	-- ���s�[��OS���[�U�[
		oROW_COUNT			OUT NUMBER,         				-- �쐬����
		oOUT_ERR_INF_CSR 		OUT ERR_INF_CSR,    				-- �G���[���J�[�\��
		iOPE_CD             IN  VARCHAR2,						-- �I�y���[�^�R�[�h
		iPGM_ID             IN  VARCHAR2,						-- �v���O����ID
		iDATE               IN  DATE							-- �V�X�e������
	) RETURN NUMBER;

	/*
	************************************************************************
	*  �ŐVKGF���b�g�e�[�u���̃��b�N����
	************************************************************************
	*/
	FUNCTION UNLOCK_KGF_LOT(
		iLockOpeCd			IN TT_ROW_LOCK.LOCK_OPE_CD%TYPE,		-- ���b�N�I�y���[�^�R�[�h
		iIP_ADDR			IN TL_STORED_SHORI.IP%TYPE,			-- ���s�[��IP�A�h���X
		iWINDOWS_LOGIN_USER		IN TL_STORED_SHORI.WINDOWS_LOGIN_USER%TYPE,	-- ���s�[��OS���[�U�[
		oROW_COUNT			OUT NUMBER,         				-- �쐬����
		oOUT_ERR_INF_CSR 		OUT ERR_INF_CSR,   				-- �G���[���J�[�\��
		iOPE_CD             IN  VARCHAR2,						-- �I�y���[�^�R�[�h
		iPGM_ID             IN  VARCHAR2,						-- �v���O����ID
		iDATE               IN  DATE							-- �V�X�e������

	) RETURN NUMBER;

END;
/

CREATE OR REPLACE PACKAGE BODY ULT_KGF_LOT_KANLI
/* **********************************************************
 *  Copyright(c) 2011 beyond, INTEC Inc. All rights reserved.
 * **********************************************************/
IS

/*
 ************************************************************************
 * Function ID  : NEXT_LOT_CREATE
 * Program Name : �����b�g�쐬
 * Parameter    : <I> iMaxKfgLotNo	�FKGF_LOT_NO
 *		  <I> iTrkEigyYmd	�FTRK_EIGY_YMD
 *		  <I> iTrkOpeCd	        �FTRK_OPE_CD
 *		  <I> iTrkDate	        �FTRK_DATE
 *		  <I> iTrkPgmId	        �FTRK_PGM_ID
 * Return       �F�������ʁi0:����I���A1:�ُ�I���j
 ************************************************************************
 */
	FUNCTION NEXT_LOT_CREATE(
		iMaxKfgLotNo			IN TT_SISN_KGF_LOT.KGF_LOT_NO%TYPE,		-- �ŐV�̃��b�g�ԍ�
		iTrkEigyYmd			IN TT_SISN_KGF_LOT.TRK_EIGY_YMD%TYPE,		-- �o�^�����c�ƔN����
		iTrkOpeCd			IN TT_SISN_KGF_LOT.TRK_OPE_CD%TYPE,		-- �o�^�I�y���[�^�R�[�h
		iTrkDate			IN TT_SISN_KGF_LOT.TRK_DATE%TYPE,		-- �o�^����
		iTrkPgmId			IN TT_SISN_KGF_LOT.TRK_PGM_ID%TYPE,		-- �o�^�v���O����ID
		iIP_ADDR			IN TL_STORED_SHORI.IP%TYPE,			-- ���s�[��IP�A�h���X
		iWINDOWS_LOGIN_USER		IN TL_STORED_SHORI.WINDOWS_LOGIN_USER%TYPE,	-- ���s�[��OS���[�U�[
		oROW_COUNT			OUT NUMBER,         				-- �쐬����
		oOUT_ERR_INF_CSR 		OUT ERR_INF_CSR    				-- �G���[���J�[�\��
	) RETURN NUMBER IS

	/************************************************************************/
	/*                              �G���[����                              */
	/************************************************************************/
	W_INDEX_N 				NUMBER(10) := 0;
	W_ERR_INF_TBL 				TYPE_ERR_INFO_TBL := TYPE_ERR_INFO_TBL();
	W_ERR_INF_RCD 				TYPE_ERR_INFO_RCD := TYPE_ERR_INFO_RCD(NULL,NULL,NULL,NULL);

	BEGIN

		-- �X�V�OKGF���b�g�����폜����
		DELETE FROM TT_SISN_KGF_LOT;

		-- ���b�g����KGF���b�g�e�[�u���ɍ쐬����
		INSERT INTO TT_SISN_KGF_LOT (
			KEN_CD,
			KGF_LOT_NO,
			LIST_CHAKU_YMD,
			ZENKAI_JOHO_YMD,
			ZENKAI_CHOSA_YMD,
			JOHO_YMD,
			CHOSA_YMD,
			KANRYO_YMD,
			CHK,
			COMMENTS,
			TRK_EIGY_YMD,
			UPD_EIGY_YMD,
			TRK_OPE_CD,
			TRK_DATE,
			TRK_PGM_ID,
			UPD_OPE_CD,
			UPD_DATE,
			UPD_PGM_ID )
		SELECT 	KEN_CD,
			TRIM(TO_CHAR(KGF_LOT_NO + 1,'00')),
			null,
			JOHO_YMD,
			CHOSA_YMD,
			null,
			null,
			null,
			null,
			null,
			iTrkEigyYmd,
			iTrkEigyYmd,
			iTrkOpeCd,
			iTrkDate,
			iTrkPgmId,
			iTrkOpeCd,
			iTrkDate,
			iTrkPgmId
		FROM TT_NSK_KGF_LOT
		WHERE KGF_LOT_NO = iMaxKfgLotNo
		ORDER BY KEN_CD;


		-- �X�V�OKGF�Ō�����폜����
		DELETE FROM TT_SISN_KGF_KNG;

		-- �Ō����KGF�Ō�e�[�u���ɍ쐬����
		INSERT INTO TT_SISN_KGF_KNG (
			KEN_CD,
			REC_ID,
			SHI_CD,
			KGF_LOT_NO,
			DEL_FLG,
			DEL_EIGY_YMD,
			COMMENTS,
			IPPAN_1_KNG_SBT_CD,
			IPPAN_1_BED_SU,
			IPPAN_1_KIFKK_IPPAN_RYOYO_KBN,
			IPPAN_1_SHONIN_YMD,
			IPPAN_1_MOD_EIGY_YMD,
			IPPAN_2_KNG_SBT_CD,
			IPPAN_2_BED_SU,
			IPPAN_2_KIFKK_IPPAN_RYOYO_KBN,
			IPPAN_2_SHONIN_YMD,
			IPPAN_2_MOD_EIGY_YMD,
			IPPAN_3_KNG_SBT_CD,
			IPPAN_3_BED_SU,
			IPPAN_3_KIFKK_IPPAN_RYOYO_KBN,
			IPPAN_3_SHONIN_YMD,
			IPPAN_3_MOD_EIGY_YMD,
			IPPAN_4_KNG_SBT_CD,
			IPPAN_4_BED_SU,
			IPPAN_4_KIFKK_IPPAN_RYOYO_KBN,
			IPPAN_4_SHONIN_YMD,
			IPPAN_4_MOD_EIGY_YMD,
			IPPAN_5_KNG_SBT_CD,
			IPPAN_5_BED_SU,
			IPPAN_5_KIFKK_IPPAN_RYOYO_KBN,
			IPPAN_5_SHONIN_YMD,
			IPPAN_5_MOD_EIGY_YMD,
			IPPAN_6_KNG_SBT_CD,
			IPPAN_6_BED_SU,
			IPPAN_6_KIFKK_IPPAN_RYOYO_KBN,
			IPPAN_6_SHONIN_YMD,
			IPPAN_6_MOD_EIGY_YMD,
			IPPANKEI_KNG_SBT_SU,
			IPPANKEI_BED_SU,
			SEISHIN_1_KNG_SBT_CD,
			SEISHIN_1_BED_SU,
			SEISHIN_1_SHONIN_YMD,
			SEISHIN_1_MOD_EIGY_YMD,
			SEISHIN_2_KNG_SBT_CD,
			SEISHIN_2_BED_SU,
			SEISHIN_2_SHONIN_YMD,
			SEISHIN_2_MOD_EIGY_YMD,
			SEISHIN_3_KNG_SBT_CD,
			SEISHIN_3_BED_SU,
			SEISHIN_3_SHONIN_YMD,
			SEISHIN_3_MOD_EIGY_YMD,
			SEISHIN_4_KNG_SBT_CD,
			SEISHIN_4_BED_SU,
			SEISHIN_4_SHONIN_YMD,
			SEISHIN_4_MOD_EIGY_YMD,
			SEISHIN_5_KNG_SBT_CD,
			SEISHIN_5_BED_SU,
			SEISHIN_5_SHONIN_YMD,
			SEISHIN_5_MOD_EIGY_YMD,
			SEISHIN_6_KNG_SBT_CD,
			SEISHIN_6_BED_SU,
			SEISHIN_6_SHONIN_YMD,
			SEISHIN_6_MOD_EIGY_YMD,
			SEISHINKEI_KNG_SBT_SU,
			SEISHINKEI_BED_SU,
			KEKKAKU_1_KNG_SBT_CD,
			KEKKAKU_1_BED_SU,
			KEKKAKU_1_SHONIN_YMD,
			KEKKAKU_1_MOD_EIGY_YMD,
			KEKKAKU_2_KNG_SBT_CD,
			KEKKAKU_2_BED_SU,
			KEKKAKU_2_SHONIN_YMD,
			KEKKAKU_2_MOD_EIGY_YMD,
			KEKKAKU_3_KNG_SBT_CD,
			KEKKAKU_3_BED_SU,
			KEKKAKU_3_SHONIN_YMD,
			KEKKAKU_3_MOD_EIGY_YMD,
			KEKKAKU_4_KNG_SBT_CD,
			KEKKAKU_4_BED_SU,
			KEKKAKU_4_SHONIN_YMD,
			KEKKAKU_4_MOD_EIGY_YMD,
			KEKKAKUKEI_KNG_SBT_SU,
			KEKKAKUKEI_BED_SU,
			SONOTA_1_KNG_SBT_CD,
			SONOTA_1_KBN_1,
			SONOTA_1_KBN_2,
			SONOTA_1_BED_SU,
			SONOTA_1_KIFKK_IPPAN_RYOYO_KBN,
			SONOTA_1_MOD_EIGY_YMD,
			SONOTA_2_KNG_SBT_CD,
			SONOTA_2_KBN_1,
			SONOTA_2_KBN_2,
			SONOTA_2_BED_SU,
			SONOTA_2_KIFKK_IPPAN_RYOYO_KBN,
			SONOTA_2_MOD_EIGY_YMD,
			SONOTA_3_KNG_SBT_CD,
			SONOTA_3_KBN_1,
			SONOTA_3_KBN_2,
			SONOTA_3_BED_SU,
			SONOTA_3_KIFKK_IPPAN_RYOYO_KBN,
			SONOTA_3_MOD_EIGY_YMD,
			SONOTA_4_KNG_SBT_CD,
			SONOTA_4_KBN_1,
			SONOTA_4_KBN_2,
			SONOTA_4_BED_SU,
			SONOTA_4_KIFKK_IPPAN_RYOYO_KBN,
			SONOTA_4_MOD_EIGY_YMD,
			SONOTA_5_KNG_SBT_CD,
			SONOTA_5_KBN_1,
			SONOTA_5_KBN_2,
			SONOTA_5_BED_SU,
			SONOTA_5_KIFKK_IPPAN_RYOYO_KBN,
			SONOTA_5_MOD_EIGY_YMD,
			SONOTA_6_KNG_SBT_CD,
			SONOTA_6_KBN_1,
			SONOTA_6_KBN_2,
			SONOTA_6_BED_SU,
			SONOTA_6_KIFKK_IPPAN_RYOYO_KBN,
			SONOTA_6_MOD_EIGY_YMD,
			SONOTA_7_KNG_SBT_CD,
			SONOTA_7_KBN_1,
			SONOTA_7_KBN_2,
			SONOTA_7_BED_SU,
			SONOTA_7_KIFKK_IPPAN_RYOYO_KBN,
			SONOTA_7_MOD_EIGY_YMD,
			SONOTA_8_KNG_SBT_CD,
			SONOTA_8_KBN_1,
			SONOTA_8_KBN_2,
			SONOTA_8_BED_SU,
			SONOTA_8_KIFKK_IPPAN_RYOYO_KBN,
			SONOTA_8_MOD_EIGY_YMD,
			RYOYO_BED_SU,
			RYOYO_MOD_EIGY_YMD,
			KANSEN_BED_SU,
			KANSEN_MOD_EIGY_YMD,
			HANSEN_BED_SU,
			HANSEN_MOD_EIGY_YMD,
			NOHIN_JOKYO_KBN,
			TRK_EIGY_YMD,
			UPD_EIGY_YMD,
			TRK_OPE_CD,
			TRK_DATE,
			TRK_PGM_ID,
			UPD_OPE_CD,
			UPD_DATE,
			UPD_PGM_ID )
		SELECT 	A.KEN_CD,
			A.REC_ID,
			A.SHI_CD,
			TRIM(TO_CHAR(A.KGF_LOT_NO + 1,'00')),
			A.DEL_FLG,
			A.DEL_EIGY_YMD,
			A.COMMENTS,
			A.IPPAN_1_KNG_SBT_CD,
			A.IPPAN_1_BED_SU,
			A.IPPAN_1_KIFKK_IPPAN_RYOYO_KBN,
			A.IPPAN_1_SHONIN_YMD,
			A.IPPAN_1_MOD_EIGY_YMD,
			A.IPPAN_2_KNG_SBT_CD,
			A.IPPAN_2_BED_SU,
			A.IPPAN_2_KIFKK_IPPAN_RYOYO_KBN,
			A.IPPAN_2_SHONIN_YMD,
			A.IPPAN_2_MOD_EIGY_YMD,
			A.IPPAN_3_KNG_SBT_CD,
			A.IPPAN_3_BED_SU,
			A.IPPAN_3_KIFKK_IPPAN_RYOYO_KBN,
			A.IPPAN_3_SHONIN_YMD,
			A.IPPAN_3_MOD_EIGY_YMD,
			A.IPPAN_4_KNG_SBT_CD,
			A.IPPAN_4_BED_SU,
			A.IPPAN_4_KIFKK_IPPAN_RYOYO_KBN,
			A.IPPAN_4_SHONIN_YMD,
			A.IPPAN_4_MOD_EIGY_YMD,
			A.IPPAN_5_KNG_SBT_CD,
			A.IPPAN_5_BED_SU,
			A.IPPAN_5_KIFKK_IPPAN_RYOYO_KBN,
			A.IPPAN_5_SHONIN_YMD,
			A.IPPAN_5_MOD_EIGY_YMD,
			A.IPPAN_6_KNG_SBT_CD,
			A.IPPAN_6_BED_SU,
			A.IPPAN_6_KIFKK_IPPAN_RYOYO_KBN,
			A.IPPAN_6_SHONIN_YMD,
			A.IPPAN_6_MOD_EIGY_YMD,
			A.IPPANKEI_KNG_SBT_SU,
			A.IPPANKEI_BED_SU,
			A.SEISHIN_1_KNG_SBT_CD,
			A.SEISHIN_1_BED_SU,
			A.SEISHIN_1_SHONIN_YMD,
			A.SEISHIN_1_MOD_EIGY_YMD,
			A.SEISHIN_2_KNG_SBT_CD,
			A.SEISHIN_2_BED_SU,
			A.SEISHIN_2_SHONIN_YMD,
			A.SEISHIN_2_MOD_EIGY_YMD,
			A.SEISHIN_3_KNG_SBT_CD,
			A.SEISHIN_3_BED_SU,
			A.SEISHIN_3_SHONIN_YMD,
			A.SEISHIN_3_MOD_EIGY_YMD,
			A.SEISHIN_4_KNG_SBT_CD,
			A.SEISHIN_4_BED_SU,
			A.SEISHIN_4_SHONIN_YMD,
			A.SEISHIN_4_MOD_EIGY_YMD,
			A.SEISHIN_5_KNG_SBT_CD,
			A.SEISHIN_5_BED_SU,
			A.SEISHIN_5_SHONIN_YMD,
			A.SEISHIN_5_MOD_EIGY_YMD,
			A.SEISHIN_6_KNG_SBT_CD,
			A.SEISHIN_6_BED_SU,
			A.SEISHIN_6_SHONIN_YMD,
			A.SEISHIN_6_MOD_EIGY_YMD,
			A.SEISHINKEI_KNG_SBT_SU,
			A.SEISHINKEI_BED_SU,
			A.KEKKAKU_1_KNG_SBT_CD,
			A.KEKKAKU_1_BED_SU,
			A.KEKKAKU_1_SHONIN_YMD,
			A.KEKKAKU_1_MOD_EIGY_YMD,
			A.KEKKAKU_2_KNG_SBT_CD,
			A.KEKKAKU_2_BED_SU,
			A.KEKKAKU_2_SHONIN_YMD,
			A.KEKKAKU_2_MOD_EIGY_YMD,
			A.KEKKAKU_3_KNG_SBT_CD,
			A.KEKKAKU_3_BED_SU,
			A.KEKKAKU_3_SHONIN_YMD,
			A.KEKKAKU_3_MOD_EIGY_YMD,
			A.KEKKAKU_4_KNG_SBT_CD,
			A.KEKKAKU_4_BED_SU,
			A.KEKKAKU_4_SHONIN_YMD,
			A.KEKKAKU_4_MOD_EIGY_YMD,
			A.KEKKAKUKEI_KNG_SBT_SU,
			A.KEKKAKUKEI_BED_SU,
			A.SONOTA_1_KNG_SBT_CD,
			A.SONOTA_1_KBN_1,
			A.SONOTA_1_KBN_2,
			A.SONOTA_1_BED_SU,
			A.SONOTA_1_KIFKK_IPPAN_RYOYO_KBN,
			A.SONOTA_1_MOD_EIGY_YMD,
			A.SONOTA_2_KNG_SBT_CD,
			A.SONOTA_2_KBN_1,
			A.SONOTA_2_KBN_2,
			A.SONOTA_2_BED_SU,
			A.SONOTA_2_KIFKK_IPPAN_RYOYO_KBN,
			A.SONOTA_2_MOD_EIGY_YMD,
			A.SONOTA_3_KNG_SBT_CD,
			A.SONOTA_3_KBN_1,
			A.SONOTA_3_KBN_2,
			A.SONOTA_3_BED_SU,
			A.SONOTA_3_KIFKK_IPPAN_RYOYO_KBN,
			A.SONOTA_3_MOD_EIGY_YMD,
			A.SONOTA_4_KNG_SBT_CD,
			A.SONOTA_4_KBN_1,
			A.SONOTA_4_KBN_2,
			A.SONOTA_4_BED_SU,
			A.SONOTA_4_KIFKK_IPPAN_RYOYO_KBN,
			A.SONOTA_4_MOD_EIGY_YMD,
			A.SONOTA_5_KNG_SBT_CD,
			A.SONOTA_5_KBN_1,
			A.SONOTA_5_KBN_2,
			A.SONOTA_5_BED_SU,
			A.SONOTA_5_KIFKK_IPPAN_RYOYO_KBN,
			A.SONOTA_5_MOD_EIGY_YMD,
			A.SONOTA_6_KNG_SBT_CD,
			A.SONOTA_6_KBN_1,
			A.SONOTA_6_KBN_2,
			A.SONOTA_6_BED_SU,
			A.SONOTA_6_KIFKK_IPPAN_RYOYO_KBN,
			A.SONOTA_6_MOD_EIGY_YMD,
			A.SONOTA_7_KNG_SBT_CD,
			A.SONOTA_7_KBN_1,
			A.SONOTA_7_KBN_2,
			A.SONOTA_7_BED_SU,
			A.SONOTA_7_KIFKK_IPPAN_RYOYO_KBN,
			A.SONOTA_7_MOD_EIGY_YMD,
			A.SONOTA_8_KNG_SBT_CD,
			A.SONOTA_8_KBN_1,
			A.SONOTA_8_KBN_2,
			A.SONOTA_8_BED_SU,
			A.SONOTA_8_KIFKK_IPPAN_RYOYO_KBN,
			A.SONOTA_8_MOD_EIGY_YMD,
			A.RYOYO_BED_SU,
			A.RYOYO_MOD_EIGY_YMD,
			A.KANSEN_BED_SU,
			A.KANSEN_MOD_EIGY_YMD,
			A.HANSEN_BED_SU,
			A.HANSEN_MOD_EIGY_YMD,
			'0',
			iTrkEigyYmd,
			iTrkEigyYmd,
			iTrkOpeCd,
			iTrkDate,
			iTrkPgmId,
			iTrkOpeCd,
			iTrkDate,
			iTrkPgmId
		FROM TT_NSK_KGF_KNG A
			INNER JOIN TT_SISN_SHI B
				ON A.REC_ID= B.REC_ID
				AND A.SHI_CD= B.SHI_CD
				AND B.DEL_FLG IS NULL
		WHERE A.KGF_LOT_NO = iMaxKfgLotNo
			AND A.DEL_FLG IS NULL
		ORDER BY A.KEN_CD,
			 A.REC_ID,
			 A.SHI_CD;

		oROW_COUNT := SQL%ROWCOUNT;

		-- ����I��
		RETURN 0;

	-- ��O����
	EXCEPTION
		-- ���̑��G���[
		WHEN OTHERS THEN
			W_ERR_INF_RCD.ERR_CD 		:= TO_CHAR(SQLCODE);
			W_ERR_INF_RCD.ERR_MSG 		:= SUBSTR(SQLERRM, 0, 2000);
			W_ERR_INF_RCD.ERR_KEY_INF 	:= SUBSTR('iMaxKfgLotNo:' || iMaxKfgLotNo || ', iTrkEigyYmd:' || iTrkEigyYmd || ', iTrkOpeCd:' || iTrkOpeCd
 									|| ', iTrkDate:' || iTrkDate || ', iTrkPgmId:' || iTrkPgmId, 0, 2000);
			W_INDEX_N 			:= W_ERR_INF_TBL.COUNT + 1;
			W_ERR_INF_TBL.EXTEND;
			W_ERR_INF_TBL(W_INDEX_N) 	:= W_ERR_INF_RCD;

			OPEN oOUT_ERR_INF_CSR FOR
				SELECT * FROM TABLE(W_ERR_INF_TBL);
			ULT_INSERT_LOG_TABLE('ERROR',iIP_ADDR,iWINDOWS_LOGIN_USER,iTrkOpeCd,'ERROR_INFO',W_ERR_INF_RCD.ERR_MSG,iTrkOpeCd,iTrkDate,iTrkPgmId,iTrkOpeCd,iTrkDate,iTrkPgmId);
			RAISE;
		END;

/*
 ************************************************************************
 * Function ID  : LOCK_KGF_LOT
 * Program Name : �ŐVKGF���b�g�e�[�u���̃��b�N
 * Parameter    : <I> iTrkOpeCd	�FTRK_OPE_CD
 * 		: <I> iTrkDate	�FTRK_DATE
 * 		: <I> iTrkPgmId	�FTRK_PGM_ID
 * Return       �F�������ʁi0:����I���A1:�ُ�I���j
 ************************************************************************
 */
	FUNCTION LOCK_KGF_LOT(
		iTrkOpeCd			IN TT_ROW_LOCK.TRK_OPE_CD%TYPE,			-- �o�^�I�y���[�^�R�[�h
		iTrkDate			IN TT_ROW_LOCK.TRK_DATE%TYPE,			-- �o�^����
		iTrkPgmId			IN TT_ROW_LOCK.TRK_PGM_ID%TYPE,			-- �o�^�v���O����ID
		iIP_ADDR			IN TL_STORED_SHORI.IP%TYPE,			-- ���s�[��IP�A�h���X
		iWINDOWS_LOGIN_USER		IN TL_STORED_SHORI.WINDOWS_LOGIN_USER%TYPE,	-- ���s�[��OS���[�U�[
		oROW_COUNT			OUT NUMBER,         				-- �쐬����
		oOUT_ERR_INF_CSR 		OUT ERR_INF_CSR,   				-- �G���[���J�[�\��
		iOPE_CD             IN  VARCHAR2,						-- �I�y���[�^�R�[�h
		iPGM_ID             IN  VARCHAR2,						-- �v���O����ID
		iDATE               IN  DATE							-- �V�X�e������
	) RETURN NUMBER IS

	/************************************************************************/
	/*                              �G���[����                              */
	/************************************************************************/
	W_INDEX_N 				NUMBER(10) := 0;
	W_ERR_INF_TBL 				TYPE_ERR_INFO_TBL := TYPE_ERR_INFO_TBL();
	W_ERR_INF_RCD 				TYPE_ERR_INFO_RCD := TYPE_ERR_INFO_RCD(NULL,NULL,NULL,NULL);

	cnt NUMBER;

	BEGIN

		-- ���݃`�F�b�N
		SELECT COUNT(*)
		INTO cnt
		FROM TT_ROW_LOCK
		WHERE TBL_NM = 'TT_SISN_KGF_LOT'
		AND LOCK_OPE_CD <> iTrkOpeCd;

		-- �قȂ����I�y���[�^�ł���ꍇ
		IF cnt > 0 THEN
		    oROW_COUNT := 0;
		    RETURN 0;
		END IF;

		-- ����I�y���[�^�����b�N���Ă��邱�Ƃ��폜
		DELETE FROM TT_ROW_LOCK
		WHERE TBL_NM = 'TT_SISN_KGF_LOT'
		AND LOCK_OPE_CD = iTrkOpeCd;

		-- ���b�N�e�[�u�����X�V����
		INSERT INTO TT_ROW_LOCK(
			TBL_NM,
	    		HANYO_KEY_1,
	    		HANYO_KEY_2,
	    		HANYO_KEY_3,
	    		HANYO_KEY_4,
	    		HANYO_KEY_5,
	    		LOCK_OPE_CD,
	    		TRK_OPE_CD,
	    		TRK_DATE,
	    		TRK_PGM_ID,
	    		UPD_OPE_CD,
	    		UPD_DATE,
	    		UPD_PGM_ID)
		SELECT
			'TT_SISN_KGF_LOT',
			KEN_CD,
			'999',
			'999',
			'999',
			'999',
			iTrkOpeCd,
			iTrkOpeCd,
			iTrkDate,
			iTrkPgmId,
			iTrkOpeCd,
			iTrkDate,
			iTrkPgmId
		FROM TT_SISN_KGF_LOT;

		oROW_COUNT := SQL%ROWCOUNT;

		-- ����I��
		RETURN 0;

	-- ��O����
	EXCEPTION
		-- ���̑��G���[
		WHEN OTHERS THEN
			W_ERR_INF_RCD.ERR_CD 		:= TO_CHAR(SQLCODE);
			W_ERR_INF_RCD.ERR_MSG 		:= SUBSTR(SQLERRM, 0, 2000);
			W_ERR_INF_RCD.ERR_KEY_INF 	:= SUBSTR('iTrkOpeCd:' || iTrkOpeCd || ', iTrkDate:' || iTrkDate || ', iTrkPgmId:' || iTrkPgmId, 0, 2000);
			W_INDEX_N 			:= W_ERR_INF_TBL.COUNT + 1;
			W_ERR_INF_TBL.EXTEND;
			W_ERR_INF_TBL(W_INDEX_N) 	:= W_ERR_INF_RCD;

			OPEN oOUT_ERR_INF_CSR FOR
				SELECT * FROM TABLE(W_ERR_INF_TBL);
			ULT_INSERT_LOG_TABLE('ERROR',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'ERROR_INFO',W_ERR_INF_RCD.ERR_MSG,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);
			RAISE;
		END;

/*
 ************************************************************************
 * Function ID  : UNLOCK_KGF_LOT
 * Program Name : �ŐVKGF���b�g�e�[�u���̃��b�N����
 * Parameter    : <I> iLockOpeCd	�FLOCK_OPE_CD
 * Return       �F�������ʁi0:����I���A1:�ُ�I���j
 ************************************************************************
 */
	FUNCTION UNLOCK_KGF_LOT(
		iLockOpeCd			IN TT_ROW_LOCK.LOCK_OPE_CD%TYPE,		-- ���b�N�I�y���[�^�R�[�h
		iIP_ADDR			IN TL_STORED_SHORI.IP%TYPE,			-- ���s�[��IP�A�h���X
		iWINDOWS_LOGIN_USER		IN TL_STORED_SHORI.WINDOWS_LOGIN_USER%TYPE,	-- ���s�[��OS���[�U�[
		oROW_COUNT			OUT NUMBER,         				-- �쐬����
		oOUT_ERR_INF_CSR 		OUT ERR_INF_CSR,   				-- �G���[���J�[�\��
		iOPE_CD             IN  VARCHAR2,						-- �I�y���[�^�R�[�h
		iPGM_ID             IN  VARCHAR2,						-- �v���O����ID
		iDATE               IN  DATE							-- �V�X�e������
	) RETURN NUMBER IS

	/************************************************************************/
	/*                              �G���[����                              */
	/************************************************************************/
	W_INDEX_N 				NUMBER(10) := 0;
	W_ERR_INF_TBL 				TYPE_ERR_INFO_TBL := TYPE_ERR_INFO_TBL();
	W_ERR_INF_RCD 				TYPE_ERR_INFO_RCD := TYPE_ERR_INFO_RCD(NULL,NULL,NULL,NULL);

	BEGIN

		-- ����I�y���[�^�����b�N���Ă��邱�Ƃ��폜
		DELETE FROM TT_ROW_LOCK
		WHERE TBL_NM = 'TT_SISN_KGF_LOT'
		AND LOCK_OPE_CD = iLockOpeCd;

		oROW_COUNT := SQL%ROWCOUNT;

		-- ����I��
		RETURN 0;

	-- ��O����
	EXCEPTION
		-- ���̑��G���[
		WHEN OTHERS THEN
			W_ERR_INF_RCD.ERR_CD 		:= TO_CHAR(SQLCODE);
			W_ERR_INF_RCD.ERR_MSG 		:= SUBSTR(SQLERRM, 0, 2000);
			W_ERR_INF_RCD.ERR_KEY_INF 	:= SUBSTR('iLockOpeCd:' || iLockOpeCd, 0, 2000);
			W_INDEX_N 			:= W_ERR_INF_TBL.COUNT + 1;
			W_ERR_INF_TBL.EXTEND;
			W_ERR_INF_TBL(W_INDEX_N) 	:= W_ERR_INF_RCD;

			OPEN oOUT_ERR_INF_CSR FOR
				SELECT * FROM TABLE(W_ERR_INF_TBL);
				ROLLBACK;
		
		--�G���[���O�̓o�^
  		    ULT_INSERT_LOG_TABLE('ERROR',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'ERROR_INFO',W_ERR_INF_RCD.ERR_MSG,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

			RAISE;
		END;

END;
/
