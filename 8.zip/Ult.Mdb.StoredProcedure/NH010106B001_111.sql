CREATE OR REPLACE PACKAGE NH010106B001_111
/* **********************************************************
 *  Copyright(c) 2011 beyond, INTEC Inc. All rights reserved.
 * **********************************************************/
AUTHID CURRENT_USER
IS
	/*** �J�[�\���^ ***************************************************************/
	-- �G���[���i�[�p�J�[�\���^
	TYPE ERR_INF_CSR		IS REF CURSOR;

  /*
  ************************************************************************
  *  �V_�S��_�ǉ��A�C�e���e�[�u���̍쐬
  *  CREATE_TSUIKAITEM
  ************************************************************************
  */
  FUNCTION CREATE_TSUIKAITEM(
  iShimeKind  IN  INTEGER,                    -- ���ߓ��敪
  iTensoYMD	IN	VARCHAR2,                     -- �]���N����
  iOPE_CD IN Varchar2,                      -- �I�y���[�^�R�[�h
  iPGM_ID IN Varchar2,                      -- �v���O����ID
  iDATE DATE,                               -- �V�X�e������
  iIP_ADDR  IN TL_STORED_SHORI.IP%TYPE,              -- ���s�[��IP�A�h���X (FW�Őݒ�)
  iWINDOWS_LOGIN_USER  IN TL_STORED_SHORI.WINDOWS_LOGIN_USER%TYPE, -- ���s�[��OS���[�U�[ (FW�Őݒ�)
  oROW_COUNT  OUT NUMBER,         -- �o�^����
  oOUT_ERR_INF_CSR   OUT ERR_INF_CSR    -- �G���[���J�[�\��
  ) RETURN NUMBER; 

END;
/
CREATE OR REPLACE PACKAGE BODY NH010106B001_111
/* **********************************************************
 *  Copyright(c) 2011 beyond, INTEC Inc. All rights reserved.
 * **********************************************************/
IS
  /*
   ************************************************************************
   * Function ID  : CREATE_TSUIKAITEM
   * Program Name : �V_�S��_�ǉ��A�C�e���e�[�u���̍쐬
   * Parameter    :  <I> iShimeKind    �F���ߓ��敪
   *                 <I> iTensoYMD    �F�]���N����
   *                 <I> iOPE_CD    �F�I�y���[�^�R�[�h
   *                 <I> iPGM_ID    �F�v���O����ID
   *                 <I> iDATE    �F�V�X�e������ 
   *                 <I> iIP_ADDR    �F���s�[��IP�A�h���X
   *                 <I> iWINDOWS_LOGIN_USER  �F���s�[��IP�A�h���X
   *                <O> oROW_COUNT        �F�X�V����
   *                <O> oOUT_ERR_INF_CSR  �F�G���[���J�[�\��
   * Return       �F�������ʁi0:����I���A1:�ُ�I���j
   ************************************************************************
   */
  FUNCTION CREATE_TSUIKAITEM(
  iShimeKind  IN  INTEGER,                    -- ���ߓ��敪
  iTensoYMD	IN	VARCHAR2,                     -- �]���N����
  iOPE_CD IN Varchar2,                      -- �I�y���[�^�R�[�h
  iPGM_ID IN Varchar2,                      -- �v���O����ID
  iDATE DATE,                               -- �V�X�e������  
  iIP_ADDR  IN TL_STORED_SHORI.IP%TYPE,              -- ���s�[��IP�A�h���X (FW�Őݒ�)
  iWINDOWS_LOGIN_USER  IN TL_STORED_SHORI.WINDOWS_LOGIN_USER%TYPE, -- ���s�[��OS���[�U�[ (FW�Őݒ�)
  oROW_COUNT  OUT NUMBER,         -- �o�^����
  oOUT_ERR_INF_CSR   OUT ERR_INF_CSR    -- �G���[���J�[�\��
  )RETURN NUMBER IS
PRAGMA AUTONOMOUS_TRANSACTION;
  /************************************************************************/
  /*                              �G���[����                              */
  /************************************************************************/
  W_INDEX_N           NUMBER(10) := 0;
  W_ERR_INF_TBL         TYPE_ERR_INFO_TBL := TYPE_ERR_INFO_TBL();
  W_ERR_INF_RCD         TYPE_ERR_INFO_RCD := TYPE_ERR_INFO_RCD(NULL,NULL,NULL,NULL);
  vSchemaNm           TM_JOSU.HANYO_KOMOKU%TYPE := NULL; -- �X�L�[�}����  
  PGM_ID        VARCHAR2(50) := 'NH010106B001_111.CREATE_TSUIKAITEM';
  EXECUTE_SQL   VARCHAR2(32767) := NULL;
  
  BEGIN
         
    -- �J�n���O�o��
    ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'PL/SQL Start',PGM_ID || '�̏������J�n���܂��B',iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);
             
    -- �����D���ߋ敪��"1"(������)��
    IF iShimeKind = ULT_COMMON.SHIME_SBT_CD_HISHIME THEN

          -- �[�i�p�X�L�[�}�̎擾���s���B
          vSchemaNm := ULT_COMMON.GET_SCHEMA_NAME(ULT_COMMON.SYS_ENV_JOSU_DAI_CD, ULT_COMMON.NOHIN_SHEMA_JOSU_SHO_CD);

          --�V_�S��_�ǉ��A�C�e���e�[�u���̃f�[�^���N���A����
          EXECUTE_SQL := 'TRUNCATE TABLE ' || vSchemaNm || '.' || 'TD_NA_TSUIKAITEM';
          EXECUTE IMMEDIATE EXECUTE_SQL;
          ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);
                       
            --�V_�S��_�ǉ��A�C�e���e�[�u���̃f�[�^��o�^����
            INSERT INTO TD_NA_TSUIKAITEM(
                LAYOUT_KBN                     ,
                SHIREC_ID                      ,
                SHI_CD                         ,
                SHI_CD_YOBI                    ,
                MOD_KBN                        ,
                YOBI1                          ,
                MENTE_YMD                      ,
                YOBI2                          ,
                DPC_TAISHO_BYOIN_FLG           ,
                DPC_TAISHO_BYOIN_SHITEI_D      ,
                DPC_TAISHO_BYOIN_CANCEL_D      ,
                DPCJUNBI_BYOIN_FLG             ,
                DPCJUNBI_BYOIN_SHONIN_Y        ,
                DPCJUNBI_BYOIN_CANCEL_D        ,
                GANKYOTEN_FLG                  ,
                GANKYOTEN_SHITEI_D             ,
                GANKYOTEN_CANCEL_D             ,
                TOKUTEIKINO_BYOIN_FLG          ,
                TOKUTEIKINO_BYOIN_SHONIN_YMD   ,
                TOKUTEIKINO_BYOIN_CANCEL_YMD   ,
                CHIKIRY_FLG                    ,
                CHIKIRY_SHOKAIRITSU            ,
                CHIKIRY_SHONIN_YMD             ,
                CHIKIRY_CANCEL_YMD             ,
                CHOKYUNOSOCCHU_FLG             ,
                CHOKYUNOSOCCHU_SHONIN_D        ,
                CHOKYUNOSOCCHU_CANCEL_D        ,
                SOGONYUIN_FLG                  ,
                SOGONYUIN_SHONIN_D             ,
                SOGONYUIN_CANCEL_D             ,
                ISHIHOJO_FLG                   ,
                ISHIHOJO_SHONIN_D              ,
                ISHIHOJO_CANCEL_D              ,
                KARTEKANRI_FLG                 ,
                KARTEKANRI_SHONIN_D            ,
                KARTEKANRI_CANCEL_D            ,
                ANZENTAISAKU_FLG               ,
                ANZENTAISAKU_SHONIN_D          ,
                ANZENTAISAKU_CANCEL_D          ,
                JOKUSOCARE_FLG                 ,
                JOKUSOCARE_SHONIN_D            ,
                JOKUSOCARE_CANCEL_D            ,
                SHONIYAKAN_FLG                 ,
                SHONIYAKAN_SHONIN_D            ,
                SHONIYAKAN_CANCEL_D            ,
                KAIBYO_FLG                     ,
                KAIBYO_SHONIN_YMD              ,
                KAIBYO_CANCEL_YMD              ,
                CHIKRENKEIPATH_FLG             ,
                CHIKRENKEIPATH_CD_1            ,
                CHIKRENKEIPATH_CD_2            ,
                CHIKRENKEIPATH_CD_3            ,
                CHIKRENKEIPATH_CD_4            ,
                CHIKRENKEIPATH_CD_5            ,
                CHIKRENKEIPATH_CD_6            ,
                CHIKRENKEIPATH_CD_7            ,
                CHIKRENKEIPATH_CD_8            ,
                CHIKRENKEIPATH_CD_9            ,
                CHIKRENKEIPATH_CD_10           ,
                CHIKRENKEIPATH_CD_11           ,
                CHIKRENKEIPATH_CD_12           ,
                CHIKRENKEIPATH_CD_13           ,
                CHIKRENKEIPATH_CD_14           ,
                CHIKRENKEIPATH_CD_15           ,
                CHIKRENKEIPATH_CD_16           ,
                CHIKRENKEIPATH_CD_17           ,
                CHIKRENKEIPATH_CD_18           ,
                CHIKRENKEIPATH_CD_19           ,
                CHIKRENKEIPATH_CD_20           ,
                YAKUZAIKANRI_FLG               ,
                YAKUZAIKANRI_SHONIN_YMD        ,
                YAKUZAIKANRI_CANCEL_YMD        ,
                GAZOSHINDAN_FLG                ,
                GAZOSHINDAN_SHONIN_D           ,
                GAZOSHINDAN_CANCEL_D           ,
                GIRIKGK_FLG                    ,
                GIRIKGK_SHONIN_D               ,
                GIRIKGK_CANCEL_D               ,
                SHIKKANBETSUREHA_FLG           ,
                SHIKKANBETSUREHA_CD_1          ,
                SHIKKANBETSUREHA_CD_2          ,
                SHIKKANBETSUREHA_CD_3          ,
                SHIKKANBETSUREHA_CD_4          ,
                SHIKKANBETSUREHA_CD_5          ,
                SHIKKANBETSUREHA_CD_6          ,
                SHIKKANBETSUREHA_CD_7          ,
                SHIKKANBETSUREHA_CD_8          ,
                SHIKKANBETSUREHA_CD_9          ,
                SHIKKANBETSUREHA_CD_10         ,
                MASUIKANRI_FLG                 ,
                MASUIKANRI_SHONIN_D            ,
                MASUIKANRI_CANCEL_D            ,
                ZAITAKUSHIEN_FLG               ,
                ZAITAKUSHIEN_SHONIN_D          ,
                ZAITAKUSHIEN_CANCEL_D          ,
                ZAIISOKAN_FLG                  ,
                ZAIISOKAN_SHONIN_D             ,
                ZAIISOKAN_CANCEL_D             ,
                ZAITAKUMAKKI_FLG               ,
                ZAITAKUMAKKI_SHONIN_D          ,
                ZAITAKUMAKKI_CANCEL_D          ,
                CAREMIX_KBN                    ,
                KANZEN_IKO_KBN                 ,
                RYOYO_FLG                      ,
                RYOYO_IRY_KNG_SBT              ,
                RYOYO_IRY_BED_SU               ,
                RYOYO_IRY_SHONIN_YMD           ,
                RYOYO_IRY_CANCEL_YMD           ,
                RYOYO_KIG_KNG_SBT              ,
                RYOYO_KIG_BED_SU               ,
                RYOYO_KIG_SHONIN_YMD           ,
                RYOYO_KIG_CANCEL_YMD           ,
                RYOYO_KADO_SU_GOKEI_BED_SU     ,
                IPPAN_FLG                      ,
                IPPAN_KNG_SBT                  ,
                IPPAN_BED_SU                   ,
                SEISHIN_FLG                    ,
                SEISHIN_KNG_SBT                ,
                SEISHIN_BED_SU                 ,
                KEKKAKU_FLG                    ,
                KEKKAKU_KNG_SBT                ,
                KEKKAKU_BED_SU                 ,
                KANSEN_TOKUTEI                 ,
                KANSEN_1SHU                    ,
                KANSEN_2SHU                    ,
                KANSEN_FLG                     ,
                KANSEN_BED_SU                  ,
                KANWACARE_FLG                  ,
                KANWACARE_BED_SU               ,
                KANWACARE_SHONIN_YMD           ,
                KANWACARE_CANCEL_YMD           ,
                IRYHYOKA_FLG                   ,
                IRYHYOKA_SBT                   ,
                IRYHYOKA_NINTEI_YMD            ,
                IRYHYOKA_JITAI_YMD             ,
                RNSKNS_KKN1_FLG                ,
                RNSKNS_KKN1_SHONIN_YMD         ,
                RNSKNS_KKN1_CANCEL_YMD         ,
                RNSKNS_KKN2_FLG                ,
                RNSKNS_KKN2_SHONIN_YMD         ,
                RNSKNS_KKN2_CANCEL_YMD         ,
                RNSKNS_KYRYK_FLG               ,
                RNSKNS_KYRYK_SHONIN_YMD        ,
                RNSKNS_KYRYK_CANCEL_YMD        ,
                SAIGAIKYOTEN_BYOIN             ,
                KYUKYU_IRY_KYUKYUKOKUJI        ,
                KYUKYU_IRY_2JI_KYUKYU          ,
                KYUKYU_IRY_3JI_KYUKYU          ,
                KYUKYU_KOKUJISNRYJ             ,
                CHIKENCHUKAKU_FLG              ,
                CHIKENCHUKAKU_KBN              ,
                CHIKENCHUKAKU_SHONIN_D         ,
                CHIKENCHUKAKU_CANCEL_D         ,
                NINCHISHOIRY_FLG               ,
                NINCHISHOIRY_SHONIN_D          ,
                NINCHISHOIRY_CANCEL_D          ,
                TOKUTEIKENSHIN                 ,
                TOKUTEISHIDO                   ,
                SENSHIN_FLG                    ,
                SENSHIN_1_CD                   ,
                SENSHIN_1_KBN                  ,
                SENSHIN_2_CD                   ,
                SENSHIN_2_KBN                  ,
                SENSHIN_3_CD                   ,
                SENSHIN_3_KBN                  ,
                SENSHIN_4_CD                   ,
                SENSHIN_4_KBN                  ,
                SENSHIN_5_CD                   ,
                SENSHIN_5_KBN                  ,
                SENSHIN_6_CD                   ,
                SENSHIN_6_KBN                  ,
                SENSHIN_7_CD                   ,
                SENSHIN_7_KBN                  ,
                SENSHIN_8_CD                   ,
                SENSHIN_8_KBN                  ,
                SENSHIN_9_CD                   ,
                SENSHIN_9_KBN                  ,
                SENSHIN_10_CD                  ,
                SENSHIN_10_KBN                 ,
                SENSHIN_11_CD                  ,
                SENSHIN_11_KBN                 ,
                SENSHIN_12_CD                  ,
                SENSHIN_12_KBN                 ,
                SENSHIN_13_CD                  ,
                SENSHIN_13_KBN                 ,
                SENSHIN_14_CD                  ,
                SENSHIN_14_KBN                 ,
                SENSHIN_15_CD                  ,
                SENSHIN_15_KBN                 ,
                SENSHIN_16_CD                  ,
                SENSHIN_16_KBN                 ,
                SENSHIN_17_CD                  ,
                SENSHIN_17_KBN                 ,
                SENSHIN_18_CD                  ,
                SENSHIN_18_KBN                 ,
                SENSHIN_19_CD                  ,
                SENSHIN_19_KBN                 ,
                SENSHIN_20_CD                  ,
                SENSHIN_20_KBN                 ,
                SENSHIN_21_CD                  ,
                SENSHIN_21_KBN                 ,
                SENSHIN_22_CD                  ,
                SENSHIN_22_KBN                 ,
                SENSHIN_23_CD                  ,
                SENSHIN_23_KBN                 ,
                SENSHIN_24_CD                  ,
                SENSHIN_24_KBN                 ,
                SENSHIN_25_CD                  ,
                SENSHIN_25_KBN                 ,
                SENSHIN_26_CD                  ,
                SENSHIN_26_KBN                 ,
                SENSHIN_27_CD                  ,
                SENSHIN_27_KBN                 ,
                SENSHIN_28_CD                  ,
                SENSHIN_28_KBN                 ,
                SENSHIN_29_CD                  ,
                SENSHIN_29_KBN                 ,
                SENSHIN_30_CD                  ,
                SENSHIN_30_KBN                 ,
                SENSHIN_31_CD                  ,
                SENSHIN_31_KBN                 ,
                SENSHIN_32_CD                  ,
                SENSHIN_32_KBN                 ,
                SENSHIN_33_CD                  ,
                SENSHIN_33_KBN                 ,
                SENSHIN_34_CD                  ,
                SENSHIN_34_KBN                 ,
                SENSHIN_35_CD                  ,
                SENSHIN_35_KBN                 ,
                SENSHIN_36_CD                  ,
                SENSHIN_36_KBN                 ,
                SENSHIN_37_CD                  ,
                SENSHIN_37_KBN                 ,
                SENSHIN_38_CD                  ,
                SENSHIN_38_KBN                 ,
                SENSHIN_39_CD                  ,
                SENSHIN_39_KBN                 ,
                SENSHIN_40_CD                  ,
                SENSHIN_40_KBN                 ,
                SNTNIRY_FLG                    ,
                SNTNIRY_1                      ,
                SNTNIRY_2                      ,
                SNTNIRY_3                      ,
                SNTNIRY_4                      ,
                SNTNIRY_5                      ,
                SNTNIRY_6                      ,
                SNTNIRY_7                      ,
                SNTNIRY_8                      ,
                SNTNIRY_9                      ,
                SNTNIRY_10                     ,
                SNTNIRY_11                     ,
                SNTNIRY_12                     ,
                SNTNIRY_13                     ,
                SNTNIRY_14                     ,
                SNTNIRY_15                     ,
                SNTNIRY_16                     ,
                SNTNIRY_17                     ,
                SNTNIRY_18                     ,
                SNTNIRY_19                     ,
                SNTNIRY_20                     ,
                SEISAKUIRY_FLG                 ,
                SEISAKUIRY_1_CD                ,
                SEISAKUIRY_1_KBN               ,
                SEISAKUIRY_2_CD                ,
                SEISAKUIRY_2_KBN               ,
                SEISAKUIRY_3_CD                ,
                SEISAKUIRY_3_KBN               ,
                SEISAKUIRY_4_CD                ,
                SEISAKUIRY_4_KBN               ,
                SEISAKUIRY_5_CD                ,
                SEISAKUIRY_5_KBN               ,
                SEISAKUIRY_6_CD                ,
                SEISAKUIRY_6_KBN               ,
                SEISAKUIRY_7_CD                ,
                SEISAKUIRY_7_KBN               ,
                SEISAKUIRY_8_CD                ,
                SEISAKUIRY_8_KBN               ,
                SEISAKUIRY_9_CD                ,
                SEISAKUIRY_9_KBN               ,
                SEISAKUIRY_10_CD               ,
                SEISAKUIRY_10_KBN              ,
                SEISAKUIRY_11_CD               ,
                SEISAKUIRY_11_KBN              ,
                SEISAKUIRY_12_CD               ,
                SEISAKUIRY_12_KBN              ,
                SEISAKUIRY_13_CD               ,
                SEISAKUIRY_13_KBN              ,
                SEISAKUIRY_14_CD               ,
                SEISAKUIRY_14_KBN              ,
                SEISAKUIRY_15_CD               ,
                SEISAKUIRY_15_KBN              ,
                SEISAKUIRY_16_CD               ,
                SEISAKUIRY_16_KBN              ,
                SEISAKUIRY_17_CD               ,
                SEISAKUIRY_17_KBN              ,
                SEISAKUIRY_18_CD               ,
                SEISAKUIRY_18_KBN              ,
                SEISAKUIRY_19_CD               ,
                SEISAKUIRY_19_KBN              ,
                SEISAKUIRY_20_CD               ,
                SEISAKUIRY_20_KBN              ,
                HMNKNG_FLG                     ,
                HMNKNG_SHI_CD_KBN              ,
                HMNKNG_SHI_CD                  ,
                HMNKNG_SHI_CD_YOBI             ,
                KAISETSU_YM                    ,
                TSUIKA_DEL_KBN                 ,
                TENSO_YMD                      ,
                TRK_OPE_CD                     ,
                TRK_DATE                       ,
                TRK_PGM_ID                     ,
                UPD_OPE_CD                     ,
                UPD_DATE                       ,
                UPD_PGM_ID)  
            SELECT
                '111',
                TTT.REC_ID,
                TTT.SHI_CD,
                NULL,
                NULL,
                NULL,
                TTT.UPD_EIGY_YMD,
                NULL,  
                TTT.DPC_FLG                       ,
                TTT.DPC_SHITEI_YMD                ,
                TTT.DPC_CANCEL_YMD                ,
                TTT.DPCJUNBI_FLG                  ,
                TTT.DPCJUNBI_SHONIN_Y             ,
                TTT.DPCJUNBI_CANCEL_YMD           ,
                TTT.GANKYOTEN_FLG                 ,
                TTT.GANKYOTEN_SHITEI_YMD          ,
                TTT.GANKYOTEN_CANCEL_YMD          ,
                TTT.TOKUTEIKINO_FLG               ,
                TTT.TOKUTEIKINO_SHONIN_YMD        ,
                TTT.TOKUTEIKINO_CANCEL_YMD        ,
                TTT.CHIKIRY_FLG                   ,
                --TTT.CHIKIRY_SHOKAIRITSU           ,
                TRIM(TO_CHAR(TO_NUMBER(TRIM(TTT.CHIKIRY_SHOKAIRITSU))/10, '990.9')) AS CHIKIRY_SHOKAIRITSU,
                TTT.CHIKIRY_SHONIN_YMD            ,
                TTT.CHIKIRY_CANCEL_YMD            ,
                TTT.CHOKYUNOSOCCHU_FLG            ,
                TTT.CHOKYUNOSOCCHU_SHONIN_YMD     ,
                TTT.CHOKYUNOSOCCHU_CANCEL_YMD     ,
                TTT.SOGONYUIN_FLG                 ,
                TTT.SOGONYUIN_SHONIN_YMD          ,
                TTT.SOGONYUIN_CANCEL_YMD          ,
                TTT.ISHIHOJO_FLG                  ,
                TTT.ISHIHOJO_SHONIN_YMD           ,
                TTT.ISHIHOJO_CANCEL_YMD           ,
                TTT.KARTE_FLG                     ,
                TTT.KARTE_SHONIN_YMD              ,
                TTT.KARTE_CANCEL_YMD              ,
                TTT.IRYANZEN_FLG                  ,
                TTT.IRYANZEN_SHONIN_YMD           ,
                TTT.IRYANZEN_CANCEL_YMD           ,
                TTT.JOKUSOCARE_FLG                ,
                TTT.JOKUSOCARE_SHONIN_YMD         ,
                TTT.JOKUSOCARE_CANCEL_YMD         ,
                TTT.SHONIYAKAN_FLG                ,
                TTT.SHONIYAKAN_SHONIN_YMD         ,
                TTT.SHONIYAKAN_CANCEL_YMD         ,
                TTT.KAIHOGATA_FLG                 ,
                TTT.KAIHOGATA_SHONIN_YMD          ,
                TTT.KAIHOGATA_CANCEL_YMD          ,
                TTT.CHIKRENKEIPATH_FLG            ,
                TTT.CHIKRENKEIPATH_CD_01          , 
                TTT.CHIKRENKEIPATH_CD_02          , 
                TTT.CHIKRENKEIPATH_CD_03          , 
                TTT.CHIKRENKEIPATH_CD_04          , 
                TTT.CHIKRENKEIPATH_CD_05          , 
                TTT.CHIKRENKEIPATH_CD_06          , 
                TTT.CHIKRENKEIPATH_CD_07          , 
                TTT.CHIKRENKEIPATH_CD_08          , 
                TTT.CHIKRENKEIPATH_CD_09          , 
                TTT.CHIKRENKEIPATH_CD_10          , 
                TTT.CHIKRENKEIPATH_CD_11          , 
                TTT.CHIKRENKEIPATH_CD_12          , 
                TTT.CHIKRENKEIPATH_CD_13          , 
                TTT.CHIKRENKEIPATH_CD_14          , 
                TTT.CHIKRENKEIPATH_CD_15          , 
                TTT.CHIKRENKEIPATH_CD_16          , 
                TTT.CHIKRENKEIPATH_CD_17          , 
                TTT.CHIKRENKEIPATH_CD_18          , 
                TTT.CHIKRENKEIPATH_CD_19          , 
                TTT.CHIKRENKEIPATH_CD_20          , 
                TTT.YAKUZAIKANRI_FLG              , 
                TTT.YAKUZAIKANRI_SHONIN_YMD       , 
                TTT.YAKUZAIKANRI_CANCEL_YMD       , 
                TTT.GAZOSHINDAN_FLG               , 
                TTT.GAZOSHINDAN_SHONIN_YMD        , 
                TTT.GAZOSHINDAN_CANCEL_YMD        , 
                TTT.GIRIKGK_FLG                   , 
                TTT.GIRIKGK_SHONIN_YMD            , 
                TTT.GIRIKGK_CANCEL_YMD            , 
                TTT.SHIKKANBETSUREHA_FLG          ,
                TTT.SHIKKANBETSUREHA_CD_01        ,
                TTT.SHIKKANBETSUREHA_CD_02        ,
                TTT.SHIKKANBETSUREHA_CD_03        ,
                TTT.SHIKKANBETSUREHA_CD_04        ,                
                TTT.SHIKKANBETSUREHA_CD_05        ,
                TTT.SHIKKANBETSUREHA_CD_06        ,                
                TTT.SHIKKANBETSUREHA_CD_07        ,
                TTT.SHIKKANBETSUREHA_CD_08        ,                
                TTT.SHIKKANBETSUREHA_CD_09        ,
                TTT.SHIKKANBETSUREHA_CD_10        ,                
                TTT.MASUIKANRI_FLG                ,
                TTT.MASUIKANRI_SHONIN_YMD         ,                
                TTT.MASUIKANRI_CANCEL_YMD         ,
                TTT.ZAITAKUSHIEN_FLG              ,                
                TTT.ZAITAKUSHIEN_SHONIN_YMD       ,
                TTT.ZAITAKUSHIEN_CANCEL_YMD       ,                
                TTT.ZAIISOKAN_FLG                 ,
                TTT.ZAIISOKAN_SHONIN_YMD          ,                
                TTT.ZAIISOKAN_CANCEL_YMD          ,
                TTT.ZAITAKUMAKKI_FLG              ,               
                TTT.ZAITAKUMAKKI_SHONIN_YMD       ,
                TTT.ZAITAKUMAKKI_CANCEL_YMD       ,
                TTT.CAREMIXTO_KBN_CD              ,
                TTT.RYOYO_KANI_KBN_CD             ,                
                TTT.RYOYO_FLG                     ,
                TTT.RYOYO_IRY_KNG_SBT_CD          ,                
                TTT.RYOYO_IRY_BED_SU              ,
                TTT.RYOYO_IRY_SHONIN_YMD          ,                
                TTT.RYOYO_IRY_CANCEL_YMD          ,
                TTT.RYOYO_KIG_KNG_SBT_CD          ,                
                TTT.RYOYO_KIG_BED_SU              ,
                TTT.RYOYO_KIG_SHONIN_YMD          ,                
                TTT.RYOYO_KIG_CANCEL_YMD          ,
                TTT.RYOYO_GOKEI_BED_SU            ,                
                TTT.IPPAN_FLG                     ,
                TTT.IPPAN_KNG_SBT_CD              ,                
                TTT.IPPAN_BED_SU                  ,
                TTT.SEISHIN_FLG                   ,                
                TTT.SEISHIN_KNG_SBT_CD            ,
                TTT.SEISHIN_BED_SU                ,                
                TTT.KEKKAKU_FLG                   ,
                TTT.KEKKAKU_KNG_SBT_CD            ,
                TTT.KEKKAKU_BED_SU                ,
                TTT.KANSEN_TOKUTEI_FLG            ,                
                TTT.KANSEN_1SHU_FLG               ,
                TTT.KANSEN_2SHU_FLG               ,                
                TTT.KANSEN_FLG                    ,
                TTT.KANSEN_BED_SU                 ,                
                TTT.KANWACARE_FLG                 ,
                TTT.KANWACARE_BED_SU              ,                
                TTT.KANWACARE_SHONIN_YMD          ,
                TTT.KANWACARE_CANCEL_YMD          ,                
                TTT.IRYHYOKA_FLG                  ,
                TTT.IRYHYOKA_CD                   ,                
                TTT.IRYHYOKA_SHONIN_YMD           ,
                TTT.IRYHYOKA_CANCEL_YMD           ,                
                TTT.RNSKNS_KKN1_FLG               ,
                TTT.RNSKNS_KKN1_SHONIN_YMD        ,                
                TTT.RNSKNS_KKN1_CANCEL_YMD        ,
                TTT.RNSKNS_KKN2_FLG               ,                
                TTT.RNSKNS_KKN2_SHONIN_YMD        ,
                TTT.RNSKNS_KKN2_CANCEL_YMD        ,
                TTT.RNSKNS_KYRYK_FLG              ,
                TTT.RNSKNS_KYRYK_SHONIN_YMD       ,
                TTT.RNSKNS_KYRYK_CANCEL_YMD       ,
                TTT.SAIGAIKYOTEN_FLG              ,
                TTT.KYUKYU_IRY_KKJ_FLG            ,
                TTT.KYUKYU_IRY_2JI_FLG            ,
                TTT.KYUKYU_IRY_3JI_FLG            ,
                TTT.KYUKYUKOKUJI_FLG              ,
                TTT.CHIKENCHUKAKU_FLG             ,
                TTT.CHIKENCHUKAKU_KBN             ,
                TTT.CHIKENCHUKAKU_SHONIN_YMD      ,
                TTT.CHIKENCHUKAKU_CANCEL_YMD      ,
                TTT.NINCHISHOIRY_FLG              ,
                TTT.NINCHISHOIRY_SHONIN_YMD       ,
                TTT.NINCHISHOIRY_CANCEL_YMD       ,
                TTT.TOKUTEIKENSHIN_FLG            ,
                TTT.TOKUTEISHIDO_FLG              ,
                TTT.SENSHIN_1_40_FLG              ,
                NVL2(TTT.SENSHIN_CD_01,SUBSTR(TTT.SENSHIN_CD_01,1,3),NULL),
                DECODE(SUBSTR(TTT.SENSHIN_CD_01,4,1),'0',NULL,SUBSTR(TTT.SENSHIN_CD_01,4,1)),
                NVL2(TTT.SENSHIN_CD_02,SUBSTR(TTT.SENSHIN_CD_02,1,3),NULL),
                DECODE(SUBSTR(TTT.SENSHIN_CD_02,4,1),'0',NULL,SUBSTR(TTT.SENSHIN_CD_02,4,1)),                            
                NVL2(TTT.SENSHIN_CD_03,SUBSTR(TTT.SENSHIN_CD_03,1,3),NULL),
                DECODE(SUBSTR(TTT.SENSHIN_CD_03,4,1),'0',NULL,SUBSTR(TTT.SENSHIN_CD_03,4,1)),
                NVL2(TTT.SENSHIN_CD_04,SUBSTR(TTT.SENSHIN_CD_04,1,3),NULL),
                DECODE(SUBSTR(TTT.SENSHIN_CD_04,4,1),'0',NULL,SUBSTR(TTT.SENSHIN_CD_04,4,1)),                
                NVL2(TTT.SENSHIN_CD_05,SUBSTR(TTT.SENSHIN_CD_05,1,3),NULL),
                DECODE(SUBSTR(TTT.SENSHIN_CD_05,4,1),'0',NULL,SUBSTR(TTT.SENSHIN_CD_05,4,1)),              
                NVL2(TTT.SENSHIN_CD_06,SUBSTR(TTT.SENSHIN_CD_06,1,3),NULL),
                DECODE(SUBSTR(TTT.SENSHIN_CD_06,4,1),'0',NULL,SUBSTR(TTT.SENSHIN_CD_06,4,1)),                 
                NVL2(TTT.SENSHIN_CD_07,SUBSTR(TTT.SENSHIN_CD_07,1,3),NULL),
                DECODE(SUBSTR(TTT.SENSHIN_CD_07,4,1),'0',NULL,SUBSTR(TTT.SENSHIN_CD_07,4,1)),                
                NVL2(TTT.SENSHIN_CD_08,SUBSTR(TTT.SENSHIN_CD_08,1,3),NULL),
                DECODE(SUBSTR(TTT.SENSHIN_CD_08,4,1),'0',NULL,SUBSTR(TTT.SENSHIN_CD_08,4,1)),                
                NVL2(TTT.SENSHIN_CD_09,SUBSTR(TTT.SENSHIN_CD_09,1,3),NULL),
                DECODE(SUBSTR(TTT.SENSHIN_CD_09,4,1),'0',NULL,SUBSTR(TTT.SENSHIN_CD_09,4,1)),                
                NVL2(TTT.SENSHIN_CD_10,SUBSTR(TTT.SENSHIN_CD_10,1,3),NULL),
                DECODE(SUBSTR(TTT.SENSHIN_CD_10,4,1),'0',NULL,SUBSTR(TTT.SENSHIN_CD_10,4,1)),  
                NVL2(TTT.SENSHIN_CD_11,SUBSTR(TTT.SENSHIN_CD_11,1,3),NULL),
                DECODE(SUBSTR(TTT.SENSHIN_CD_11,4,1),'0',NULL,SUBSTR(TTT.SENSHIN_CD_11,4,1)),
                NVL2(TTT.SENSHIN_CD_12,SUBSTR(TTT.SENSHIN_CD_12,1,3),NULL),
                DECODE(SUBSTR(TTT.SENSHIN_CD_12,4,1),'0',NULL,SUBSTR(TTT.SENSHIN_CD_12,4,1)),                            
                NVL2(TTT.SENSHIN_CD_13,SUBSTR(TTT.SENSHIN_CD_13,1,3),NULL),
                DECODE(SUBSTR(TTT.SENSHIN_CD_13,4,1),'0',NULL,SUBSTR(TTT.SENSHIN_CD_13,4,1)),
                NVL2(TTT.SENSHIN_CD_14,SUBSTR(TTT.SENSHIN_CD_14,1,3),NULL),
                DECODE(SUBSTR(TTT.SENSHIN_CD_14,4,1),'0',NULL,SUBSTR(TTT.SENSHIN_CD_14,4,1)),                
                NVL2(TTT.SENSHIN_CD_15,SUBSTR(TTT.SENSHIN_CD_15,1,3),NULL),
                DECODE(SUBSTR(TTT.SENSHIN_CD_15,4,1),'0',NULL,SUBSTR(TTT.SENSHIN_CD_15,4,1)),              
                NVL2(TTT.SENSHIN_CD_16,SUBSTR(TTT.SENSHIN_CD_16,1,3),NULL),
                DECODE(SUBSTR(TTT.SENSHIN_CD_16,4,1),'0',NULL,SUBSTR(TTT.SENSHIN_CD_16,4,1)),                 
                NVL2(TTT.SENSHIN_CD_17,SUBSTR(TTT.SENSHIN_CD_17,1,3),NULL),
                DECODE(SUBSTR(TTT.SENSHIN_CD_17,4,1),'0',NULL,SUBSTR(TTT.SENSHIN_CD_17,4,1)),                
                NVL2(TTT.SENSHIN_CD_18,SUBSTR(TTT.SENSHIN_CD_18,1,3),NULL),
                DECODE(SUBSTR(TTT.SENSHIN_CD_18,4,1),'0',NULL,SUBSTR(TTT.SENSHIN_CD_18,4,1)),                
                NVL2(TTT.SENSHIN_CD_19,SUBSTR(TTT.SENSHIN_CD_19,1,3),NULL),
                DECODE(SUBSTR(TTT.SENSHIN_CD_19,4,1),'0',NULL,SUBSTR(TTT.SENSHIN_CD_19,4,1)),                
                NVL2(TTT.SENSHIN_CD_20,SUBSTR(TTT.SENSHIN_CD_20,1,3),NULL),
                DECODE(SUBSTR(TTT.SENSHIN_CD_20,4,1),'0',NULL,SUBSTR(TTT.SENSHIN_CD_20,4,1)),  
                NVL2(TTT.SENSHIN_CD_21,SUBSTR(TTT.SENSHIN_CD_21,1,3),NULL),
                DECODE(SUBSTR(TTT.SENSHIN_CD_21,4,1),'0',NULL,SUBSTR(TTT.SENSHIN_CD_21,4,1)),
                NVL2(TTT.SENSHIN_CD_22,SUBSTR(TTT.SENSHIN_CD_22,1,3),NULL),
                DECODE(SUBSTR(TTT.SENSHIN_CD_22,4,1),'0',NULL,SUBSTR(TTT.SENSHIN_CD_22,4,1)),                            
                NVL2(TTT.SENSHIN_CD_23,SUBSTR(TTT.SENSHIN_CD_23,1,3),NULL),
                DECODE(SUBSTR(TTT.SENSHIN_CD_23,4,1),'0',NULL,SUBSTR(TTT.SENSHIN_CD_23,4,1)),
                NVL2(TTT.SENSHIN_CD_24,SUBSTR(TTT.SENSHIN_CD_24,1,3),NULL),
                DECODE(SUBSTR(TTT.SENSHIN_CD_24,4,1),'0',NULL,SUBSTR(TTT.SENSHIN_CD_24,4,1)),                
                NVL2(TTT.SENSHIN_CD_25,SUBSTR(TTT.SENSHIN_CD_25,1,3),NULL),
                DECODE(SUBSTR(TTT.SENSHIN_CD_25,4,1),'0',NULL,SUBSTR(TTT.SENSHIN_CD_25,4,1)),              
                NVL2(TTT.SENSHIN_CD_26,SUBSTR(TTT.SENSHIN_CD_26,1,3),NULL),
                DECODE(SUBSTR(TTT.SENSHIN_CD_26,4,1),'0',NULL,SUBSTR(TTT.SENSHIN_CD_26,4,1)),                 
                NVL2(TTT.SENSHIN_CD_27,SUBSTR(TTT.SENSHIN_CD_27,1,3),NULL),
                DECODE(SUBSTR(TTT.SENSHIN_CD_27,4,1),'0',NULL,SUBSTR(TTT.SENSHIN_CD_27,4,1)),                
                NVL2(TTT.SENSHIN_CD_28,SUBSTR(TTT.SENSHIN_CD_28,1,3),NULL),
                DECODE(SUBSTR(TTT.SENSHIN_CD_28,4,1),'0',NULL,SUBSTR(TTT.SENSHIN_CD_28,4,1)),                
                NVL2(TTT.SENSHIN_CD_29,SUBSTR(TTT.SENSHIN_CD_29,1,3),NULL),
                DECODE(SUBSTR(TTT.SENSHIN_CD_29,4,1),'0',NULL,SUBSTR(TTT.SENSHIN_CD_29,4,1)),                
                NVL2(TTT.SENSHIN_CD_30,SUBSTR(TTT.SENSHIN_CD_30,1,3),NULL),
                DECODE(SUBSTR(TTT.SENSHIN_CD_30,4,1),'0',NULL,SUBSTR(TTT.SENSHIN_CD_30,4,1)),                            
                NVL2(TTT.SENSHIN_CD_31,SUBSTR(TTT.SENSHIN_CD_31,1,3),NULL),
                DECODE(SUBSTR(TTT.SENSHIN_CD_31,4,1),'0',NULL,SUBSTR(TTT.SENSHIN_CD_31,4,1)),
                NVL2(TTT.SENSHIN_CD_32,SUBSTR(TTT.SENSHIN_CD_32,1,3),NULL),
                DECODE(SUBSTR(TTT.SENSHIN_CD_32,4,1),'0',NULL,SUBSTR(TTT.SENSHIN_CD_32,4,1)),                            
                NVL2(TTT.SENSHIN_CD_33,SUBSTR(TTT.SENSHIN_CD_33,1,3),NULL),
                DECODE(SUBSTR(TTT.SENSHIN_CD_33,4,1),'0',NULL,SUBSTR(TTT.SENSHIN_CD_33,4,1)),
                NVL2(TTT.SENSHIN_CD_34,SUBSTR(TTT.SENSHIN_CD_34,1,3),NULL),
                DECODE(SUBSTR(TTT.SENSHIN_CD_34,4,1),'0',NULL,SUBSTR(TTT.SENSHIN_CD_34,4,1)),                
                NVL2(TTT.SENSHIN_CD_35,SUBSTR(TTT.SENSHIN_CD_35,1,3),NULL),
                DECODE(SUBSTR(TTT.SENSHIN_CD_35,4,1),'0',NULL,SUBSTR(TTT.SENSHIN_CD_35,4,1)),              
                NVL2(TTT.SENSHIN_CD_36,SUBSTR(TTT.SENSHIN_CD_36,1,3),NULL),
                DECODE(SUBSTR(TTT.SENSHIN_CD_36,4,1),'0',NULL,SUBSTR(TTT.SENSHIN_CD_36,4,1)),                 
                NVL2(TTT.SENSHIN_CD_37,SUBSTR(TTT.SENSHIN_CD_37,1,3),NULL),
                DECODE(SUBSTR(TTT.SENSHIN_CD_37,4,1),'0',NULL,SUBSTR(TTT.SENSHIN_CD_37,4,1)),                
                NVL2(TTT.SENSHIN_CD_38,SUBSTR(TTT.SENSHIN_CD_38,1,3),NULL),
                DECODE(SUBSTR(TTT.SENSHIN_CD_38,4,1),'0',NULL,SUBSTR(TTT.SENSHIN_CD_38,4,1)),                
                NVL2(TTT.SENSHIN_CD_39,SUBSTR(TTT.SENSHIN_CD_39,1,3),NULL),
                DECODE(SUBSTR(TTT.SENSHIN_CD_39,4,1),'0',NULL,SUBSTR(TTT.SENSHIN_CD_39,4,1)),                
                NVL2(TTT.SENSHIN_CD_40,SUBSTR(TTT.SENSHIN_CD_40,1,3),NULL),
                DECODE(SUBSTR(TTT.SENSHIN_CD_40,4,1),'0',NULL,SUBSTR(TTT.SENSHIN_CD_40,4,1)),                     
                TTT.SNTNIRY_FLG                   ,
                TTT.SNTNIRY_CD_01                 ,
                TTT.SNTNIRY_CD_02                 ,
                TTT.SNTNIRY_CD_03                 ,
                TTT.SNTNIRY_CD_04                 ,
                TTT.SNTNIRY_CD_05                 ,
                TTT.SNTNIRY_CD_06                 ,
                TTT.SNTNIRY_CD_07                 ,
                TTT.SNTNIRY_CD_08                 ,
                TTT.SNTNIRY_CD_09                 ,
                TTT.SNTNIRY_CD_10                 ,
                TTT.SNTNIRY_CD_11                 ,
                TTT.SNTNIRY_CD_12                 ,
                TTT.SNTNIRY_CD_13                 ,
                TTT.SNTNIRY_CD_14                 ,
                TTT.SNTNIRY_CD_15                 ,
                TTT.SNTNIRY_CD_16                 ,
                TTT.SNTNIRY_CD_17                 ,
                TTT.SNTNIRY_CD_18                 ,
                TTT.SNTNIRY_CD_19                 ,
                TTT.SNTNIRY_CD_20                 ,
                TTT.SEISAKUIRY_FLG                ,
                TTT.SEISAKUIRY_BNY_CD_01          ,
                TTT.SEISAKUIRY_KBN_CD_01          ,
                TTT.SEISAKUIRY_BNY_CD_02          ,
                TTT.SEISAKUIRY_KBN_CD_02          ,
                TTT.SEISAKUIRY_BNY_CD_03          ,
                TTT.SEISAKUIRY_KBN_CD_03          ,
                TTT.SEISAKUIRY_BNY_CD_04          ,
                TTT.SEISAKUIRY_KBN_CD_04          ,
                TTT.SEISAKUIRY_BNY_CD_05          ,
                TTT.SEISAKUIRY_KBN_CD_05          ,
                TTT.SEISAKUIRY_BNY_CD_06          ,
                TTT.SEISAKUIRY_KBN_CD_06          ,
                TTT.SEISAKUIRY_BNY_CD_07          ,
                TTT.SEISAKUIRY_KBN_CD_07          ,
                TTT.SEISAKUIRY_BNY_CD_08          ,
                TTT.SEISAKUIRY_KBN_CD_08          ,
                TTT.SEISAKUIRY_BNY_CD_09          ,
                TTT.SEISAKUIRY_KBN_CD_09          ,
                TTT.SEISAKUIRY_BNY_CD_10          ,
                TTT.SEISAKUIRY_KBN_CD_10          ,
                TTT.SEISAKUIRY_BNY_CD_11          ,
                TTT.SEISAKUIRY_KBN_CD_11          ,
                TTT.SEISAKUIRY_BNY_CD_12          ,
                TTT.SEISAKUIRY_KBN_CD_12          ,
                TTT.SEISAKUIRY_BNY_CD_13          ,
                TTT.SEISAKUIRY_KBN_CD_13          ,
                TTT.SEISAKUIRY_BNY_CD_14          ,
                TTT.SEISAKUIRY_KBN_CD_14          ,
                TTT.SEISAKUIRY_BNY_CD_15          ,
                TTT.SEISAKUIRY_KBN_CD_15          ,
                TTT.SEISAKUIRY_BNY_CD_16          ,
                TTT.SEISAKUIRY_KBN_CD_16          ,
                TTT.SEISAKUIRY_BNY_CD_17          ,
                TTT.SEISAKUIRY_KBN_CD_17          ,
                TTT.SEISAKUIRY_BNY_CD_18          ,
                TTT.SEISAKUIRY_KBN_CD_18          ,
                TTT.SEISAKUIRY_BNY_CD_19          ,
                TTT.SEISAKUIRY_KBN_CD_19          ,
                TTT.SEISAKUIRY_BNY_CD_20          ,
                TTT.SEISAKUIRY_KBN_CD_20          ,
                TTT.HMNKNG_FLG                    , 
                TTT.HMNKNG_REC_ID                 , 
                TTT.HMNKNG_SHI_CD                 , 
                NULL,
                TTT.KAISETSU_YM                   , 
                NULL,
                iTensoYMD,
                iOPE_CD,
                iDATE,
                iPGM_ID,
                iOPE_CD,
                iDATE,
                iPGM_ID
          FROM TT_TIKY_SHI TTS
       	  INNER JOIN TT_TIKY_TSUIKAITEM TTT											
          ON TTS.REC_ID = TTT.REC_ID 
          AND TTS.SHI_CD = TTT.SHI_CD									                                                              
		  WHERE TTS.REC_ID = '00'                                   
		  AND TTS.DEL_FLG IS NULL                                 
		  AND TTT.DEL_FLG IS NULL;
		  
		  -- LOG�̓o�^
          EXECUTE_SQL := '  INSERT INTO TD_NA_TSUIKAITEM(          ' || 
						'  LAYOUT_KBN      , ' ||
						'  SHIREC_ID       , ' ||
						'  SHI_CD          , ' ||
						'  SHI_CD_YOBI     , ' ||
						'  MOD_KBN         , ' ||
						'  YOBI1           , ' ||
						'  MENTE_YMD       , ' ||
						'  YOBI2           , ' ||
						'  DPC_TAISHO_BYOIN_FLG           , ' ||
						'  DPC_TAISHO_BYOIN_SHITEI_D      , ' ||
						'  DPC_TAISHO_BYOIN_CANCEL_D      , ' ||
						'  DPCJUNBI_BYOIN_FLG             , ' ||
						'  DPCJUNBI_BYOIN_SHONIN_Y        , ' ||
						'  DPCJUNBI_BYOIN_CANCEL_D        , ' ||
						'  GANKYOTEN_FLG   , ' ||
						'  GANKYOTEN_SHITEI_D             , ' ||
						'  GANKYOTEN_CANCEL_D             , ' ||
						'  TOKUTEIKINO_BYOIN_FLG          , ' ||
						'  TOKUTEIKINO_BYOIN_SHONIN_YMD   , ' ||
						'  TOKUTEIKINO_BYOIN_CANCEL_YMD   , ' ||
						'  CHIKIRY_FLG     , ' ||
						'  CHIKIRY_SHOKAIRITSU            , ' ||
						'  CHIKIRY_SHONIN_YMD             , ' ||
						'  CHIKIRY_CANCEL_YMD             , ' ||
						'  CHOKYUNOSOCCHU_FLG             , ' ||
						'  CHOKYUNOSOCCHU_SHONIN_D        , ' ||
						'  CHOKYUNOSOCCHU_CANCEL_D        , ' ||
						'  SOGONYUIN_FLG   , ' ||
						'  SOGONYUIN_SHONIN_D             , ' ||
						'  SOGONYUIN_CANCEL_D             , ' ||
						'  ISHIHOJO_FLG    , ' ||
						'  ISHIHOJO_SHONIN_D              , ' ||
						'  ISHIHOJO_CANCEL_D              , ' ||
						'  KARTEKANRI_FLG  , ' ||
						'  KARTEKANRI_SHONIN_D            , ' ||
						'  KARTEKANRI_CANCEL_D            , ' ||
						'  ANZENTAISAKU_FLG, ' ||
						'  ANZENTAISAKU_SHONIN_D          , ' ||
						'  ANZENTAISAKU_CANCEL_D          , ' ||
						'  JOKUSOCARE_FLG  , ' ||
						'  JOKUSOCARE_SHONIN_D            , ' ||
						'  JOKUSOCARE_CANCEL_D            , ' ||
						'  SHONIYAKAN_FLG  , ' ||
						'  SHONIYAKAN_SHONIN_D            , ' ||
						'  SHONIYAKAN_CANCEL_D            , ' ||
						'  KAIBYO_FLG      , ' ||
						'  KAIBYO_SHONIN_YMD              , ' ||
						'  KAIBYO_CANCEL_YMD              , ' ||
						'  CHIKRENKEIPATH_FLG             , ' ||
						'  CHIKRENKEIPATH_CD_1            , ' ||
						'  CHIKRENKEIPATH_CD_2            , ' ||
						'  CHIKRENKEIPATH_CD_3            , ' ||
						'  CHIKRENKEIPATH_CD_4            , ' ||
						'  CHIKRENKEIPATH_CD_5            , ' ||
						'  CHIKRENKEIPATH_CD_6            , ' ||
						'  CHIKRENKEIPATH_CD_7            , ' ||
						'  CHIKRENKEIPATH_CD_8            , ' ||
						'  CHIKRENKEIPATH_CD_9            , ' ||
						'  CHIKRENKEIPATH_CD_10           , ' ||
						'  CHIKRENKEIPATH_CD_11           , ' ||
						'  CHIKRENKEIPATH_CD_12           , ' ||
						'  CHIKRENKEIPATH_CD_13           , ' ||
						'  CHIKRENKEIPATH_CD_14           , ' ||
						'  CHIKRENKEIPATH_CD_15           , ' ||
						'  CHIKRENKEIPATH_CD_16           , ' ||
						'  CHIKRENKEIPATH_CD_17           , ' ||
						'  CHIKRENKEIPATH_CD_18           , ' ||
						'  CHIKRENKEIPATH_CD_19           , ' ||
						'  CHIKRENKEIPATH_CD_20           , ' ||
						'  YAKUZAIKANRI_FLG, ' ||
						'  YAKUZAIKANRI_SHONIN_YMD        , ' ||
						'  YAKUZAIKANRI_CANCEL_YMD        , ' ||
						'  GAZOSHINDAN_FLG , ' ||
						'  GAZOSHINDAN_SHONIN_D           , ' ||
						'  GAZOSHINDAN_CANCEL_D           , ' ||
						'  GIRIKGK_FLG     , ' ||
						'  GIRIKGK_SHONIN_D, ' ||
						'  GIRIKGK_CANCEL_D, ' ||
						'  SHIKKANBETSUREHA_FLG           , ' ||
						'  SHIKKANBETSUREHA_CD_1          , ' ||
						'  SHIKKANBETSUREHA_CD_2          , ' ||
						'  SHIKKANBETSUREHA_CD_3          , ' ||
						'  SHIKKANBETSUREHA_CD_4          , ' ||
						'  SHIKKANBETSUREHA_CD_5          , ' ||
						'  SHIKKANBETSUREHA_CD_6          , ' ||
						'  SHIKKANBETSUREHA_CD_7          , ' ||
						'  SHIKKANBETSUREHA_CD_8          , ' ||
						'  SHIKKANBETSUREHA_CD_9          , ' ||
						'  SHIKKANBETSUREHA_CD_10         , ' ||
						'  MASUIKANRI_FLG  , ' ||
						'  MASUIKANRI_SHONIN_D            , ' ||
						'  MASUIKANRI_CANCEL_D            , ' ||
						'  ZAITAKUSHIEN_FLG, ' ||
						'  ZAITAKUSHIEN_SHONIN_D          , ' ||
						'  ZAITAKUSHIEN_CANCEL_D          , ' ||
						'  ZAIISOKAN_FLG   , ' ||
						'  ZAIISOKAN_SHONIN_D             , ' ||
						'  ZAIISOKAN_CANCEL_D             , ' ||
						'  ZAITAKUMAKKI_FLG, ' ||
						'  ZAITAKUMAKKI_SHONIN_D          , ' ||
						'  ZAITAKUMAKKI_CANCEL_D          , ' ||
						'  CAREMIX_KBN     , ' ||
						'  KANZEN_IKO_KBN  , ' ||
						'  RYOYO_FLG       , ' ||
						'  RYOYO_IRY_KNG_SBT              , ' ||
						'  RYOYO_IRY_BED_SU, ' ||
						'  RYOYO_IRY_SHONIN_YMD           , ' ||
						'  RYOYO_IRY_CANCEL_YMD           , ' ||
						'  RYOYO_KIG_KNG_SBT              , ' ||
						'  RYOYO_KIG_BED_SU, ' ||
						'  RYOYO_KIG_SHONIN_YMD           , ' ||
						'  RYOYO_KIG_CANCEL_YMD           , ' ||
						'  RYOYO_KADO_SU_GOKEI_BED_SU     , ' ||
						'  IPPAN_FLG       , ' ||
						'  IPPAN_KNG_SBT   , ' ||
						'  IPPAN_BED_SU    , ' ||
						'  SEISHIN_FLG     , ' ||
						'  SEISHIN_KNG_SBT , ' ||
						'  SEISHIN_BED_SU  , ' ||
						'  KEKKAKU_FLG     , ' ||
						'  KEKKAKU_KNG_SBT , ' ||
						'  KEKKAKU_BED_SU  , ' ||
						'  KANSEN_TOKUTEI  , ' ||
						'  KANSEN_1SHU     , ' ||
						'  KANSEN_2SHU     , ' ||
						'  KANSEN_FLG      , ' ||
						'  KANSEN_BED_SU   , ' ||
						'  KANWACARE_FLG   , ' ||
						'  KANWACARE_BED_SU, ' ||
						'  KANWACARE_SHONIN_YMD           , ' ||
						'  KANWACARE_CANCEL_YMD           , ' ||
						'  IRYHYOKA_FLG    , ' ||
						'  IRYHYOKA_SBT    , ' ||
						'  IRYHYOKA_NINTEI_YMD            , ' ||
						'  IRYHYOKA_JITAI_YMD             , ' ||
						'  RNSKNS_KKN1_FLG , ' ||
						'  RNSKNS_KKN1_SHONIN_YMD         , ' ||
						'  RNSKNS_KKN1_CANCEL_YMD         , ' ||
						'  RNSKNS_KKN2_FLG , ' ||
						'  RNSKNS_KKN2_SHONIN_YMD         , ' ||
						'  RNSKNS_KKN2_CANCEL_YMD         , ' ||
						'  RNSKNS_KYRYK_FLG, ' ||
						'  RNSKNS_KYRYK_SHONIN_YMD        , ' ||
						'  RNSKNS_KYRYK_CANCEL_YMD        , ' ||
						'  SAIGAIKYOTEN_BYOIN             , ' ||
						'  KYUKYU_IRY_KYUKYUKOKUJI        , ' ||
						'  KYUKYU_IRY_2JI_KYUKYU          , ' ||
						'  KYUKYU_IRY_3JI_KYUKYU          , ' ||
						'  KYUKYU_KOKUJISNRYJ             , ' ||
						'  CHIKENCHUKAKU_FLG              , ' ||
						'  CHIKENCHUKAKU_KBN              , ' ||
						'  CHIKENCHUKAKU_SHONIN_D         , ' ||
						'  CHIKENCHUKAKU_CANCEL_D         , ' ||
						'  NINCHISHOIRY_FLG, ' ||
						'  NINCHISHOIRY_SHONIN_D          , ' ||
						'  NINCHISHOIRY_CANCEL_D          , ' ||
						'  TOKUTEIKENSHIN  , ' ||
						'  TOKUTEISHIDO    , ' ||
						'  SENSHIN_FLG     , ' ||
						'  SENSHIN_1_CD    , ' ||
						'  SENSHIN_1_KBN   , ' ||
						'  SENSHIN_2_CD    , ' ||
						'  SENSHIN_2_KBN   , ' ||
						'  SENSHIN_3_CD    , ' ||
						'  SENSHIN_3_KBN   , ' ||
						'  SENSHIN_4_CD    , ' ||
						'  SENSHIN_4_KBN   , ' ||
						'  SENSHIN_5_CD    , ' ||
						'  SENSHIN_5_KBN   , ' ||
						'  SENSHIN_6_CD    , ' ||
						'  SENSHIN_6_KBN   , ' ||
						'  SENSHIN_7_CD    , ' ||
						'  SENSHIN_7_KBN   , ' ||
						'  SENSHIN_8_CD    , ' ||
						'  SENSHIN_8_KBN   , ' ||
						'  SENSHIN_9_CD    , ' ||
						'  SENSHIN_9_KBN   , ' ||
						'  SENSHIN_10_CD   , ' ||
						'  SENSHIN_10_KBN  , ' ||
						'  SENSHIN_11_CD   , ' ||
						'  SENSHIN_11_KBN  , ' ||
						'  SENSHIN_12_CD   , ' ||
						'  SENSHIN_12_KBN  , ' ||
						'  SENSHIN_13_CD   , ' ||
						'  SENSHIN_13_KBN  , ' ||
						'  SENSHIN_14_CD   , ' ||
						'  SENSHIN_14_KBN  , ' ||
						'  SENSHIN_15_CD   , ' ||
						'  SENSHIN_15_KBN  , ' ||
						'  SENSHIN_16_CD   , ' ||
						'  SENSHIN_16_KBN  , ' ||
						'  SENSHIN_17_CD   , ' ||
						'  SENSHIN_17_KBN  , ' ||
						'  SENSHIN_18_CD   , ' ||
						'  SENSHIN_18_KBN  , ' ||
						'  SENSHIN_19_CD   , ' ||
						'  SENSHIN_19_KBN  , ' ||
						'  SENSHIN_20_CD   , ' ||
						'  SENSHIN_20_KBN  , ' ||
						'  SENSHIN_21_CD   , ' ||
						'  SENSHIN_21_KBN  , ' ||
						'  SENSHIN_22_CD   , ' ||
						'  SENSHIN_22_KBN  , ' ||
						'  SENSHIN_23_CD   , ' ||
						'  SENSHIN_23_KBN  , ' ||
						'  SENSHIN_24_CD   , ' ||
						'  SENSHIN_24_KBN  , ' ||
						'  SENSHIN_25_CD   , ' ||
						'  SENSHIN_25_KBN  , ' ||
						'  SENSHIN_26_CD   , ' ||
						'  SENSHIN_26_KBN  , ' ||
						'  SENSHIN_27_CD   , ' ||
						'  SENSHIN_27_KBN  , ' ||
						'  SENSHIN_28_CD   , ' ||
						'  SENSHIN_28_KBN  , ' ||
						'  SENSHIN_29_CD   , ' ||
						'  SENSHIN_29_KBN  , ' ||
						'  SENSHIN_30_CD   , ' ||
						'  SENSHIN_30_KBN  , ' ||
						'  SENSHIN_31_CD   , ' ||
						'  SENSHIN_31_KBN  , ' ||
						'  SENSHIN_32_CD   , ' ||
						'  SENSHIN_32_KBN  , ' ||
						'  SENSHIN_33_CD   , ' ||
						'  SENSHIN_33_KBN  , ' ||
						'  SENSHIN_34_CD   , ' ||
						'  SENSHIN_34_KBN  , ' ||
						'  SENSHIN_35_CD   , ' ||
						'  SENSHIN_35_KBN  , ' ||
						'  SENSHIN_36_CD   , ' ||
						'  SENSHIN_36_KBN  , ' ||
						'  SENSHIN_37_CD   , ' ||
						'  SENSHIN_37_KBN  , ' ||
						'  SENSHIN_38_CD   , ' ||
						'  SENSHIN_38_KBN  , ' ||
						'  SENSHIN_39_CD   , ' ||
						'  SENSHIN_39_KBN  , ' ||
						'  SENSHIN_40_CD   , ' ||
						'  SENSHIN_40_KBN  , ' ||
						'  SNTNIRY_FLG     , ' ||
						'  SNTNIRY_1       , ' ||
						'  SNTNIRY_2       , ' ||
						'  SNTNIRY_3       , ' ||
						'  SNTNIRY_4       , ' ||
						'  SNTNIRY_5       , ' ||
						'  SNTNIRY_6       , ' ||
						'  SNTNIRY_7       , ' ||
						'  SNTNIRY_8       , ' ||
						'  SNTNIRY_9       , ' ||
						'  SNTNIRY_10      , ' ||
						'  SNTNIRY_11      , ' ||
						'  SNTNIRY_12      , ' ||
						'  SNTNIRY_13      , ' ||
						'  SNTNIRY_14      , ' ||
						'  SNTNIRY_15      , ' ||
						'  SNTNIRY_16      , ' ||
						'  SNTNIRY_17      , ' ||
						'  SNTNIRY_18      , ' ||
						'  SNTNIRY_19      , ' ||
						'  SNTNIRY_20      , ' ||
						'  SEISAKUIRY_FLG  , ' ||
						'  SEISAKUIRY_1_CD , ' ||
						'  SEISAKUIRY_1_KBN, ' ||
						'  SEISAKUIRY_2_CD , ' ||
						'  SEISAKUIRY_2_KBN, ' ||
						'  SEISAKUIRY_3_CD , ' ||
						'  SEISAKUIRY_3_KBN, ' ||
						'  SEISAKUIRY_4_CD , ' ||
						'  SEISAKUIRY_4_KBN, ' ||
						'  SEISAKUIRY_5_CD , ' ||
						'  SEISAKUIRY_5_KBN, ' ||
						'  SEISAKUIRY_6_CD , ' ||
						'  SEISAKUIRY_6_KBN, ' ||
						'  SEISAKUIRY_7_CD , ' ||
						'  SEISAKUIRY_7_KBN, ' ||
						'  SEISAKUIRY_8_CD , ' ||
						'  SEISAKUIRY_8_KBN, ' ||
						'  SEISAKUIRY_9_CD , ' ||
						'  SEISAKUIRY_9_KBN, ' ||
						'  SEISAKUIRY_10_CD, ' ||
						'  SEISAKUIRY_10_KBN              , ' ||
						'  SEISAKUIRY_11_CD, ' ||
						'  SEISAKUIRY_11_KBN              , ' ||
						'  SEISAKUIRY_12_CD, ' ||
						'  SEISAKUIRY_12_KBN              , ' ||
						'  SEISAKUIRY_13_CD, ' ||
						'  SEISAKUIRY_13_KBN              , ' ||
						'  SEISAKUIRY_14_CD, ' ||
						'  SEISAKUIRY_14_KBN              , ' ||
						'  SEISAKUIRY_15_CD, ' ||
						'  SEISAKUIRY_15_KBN              , ' ||
						'  SEISAKUIRY_16_CD, ' ||
						'  SEISAKUIRY_16_KBN              , ' ||
						'  SEISAKUIRY_17_CD, ' ||
						'  SEISAKUIRY_17_KBN              , ' ||
						'  SEISAKUIRY_18_CD, ' ||
						'  SEISAKUIRY_18_KBN              , ' ||
						'  SEISAKUIRY_19_CD, ' ||
						'  SEISAKUIRY_19_KBN              , ' ||
						'  SEISAKUIRY_20_CD, ' ||
						'  SEISAKUIRY_20_KBN              , ' ||
						'  HMNKNG_FLG      , ' ||
						'  HMNKNG_SHI_CD_KBN              , ' ||
						'  HMNKNG_SHI_CD   , ' ||
						'  HMNKNG_SHI_CD_YOBI             , ' ||
						'  KAISETSU_YM     , ' ||
						'  TSUIKA_DEL_KBN  , ' ||
						'  TENSO_YMD       , ' ||
						'  TRK_OPE_CD      , ' ||
						'  TRK_DATE        , ' ||
						'  TRK_PGM_ID      , ' ||
						'  UPD_OPE_CD      , ' ||
						'  UPD_DATE        , ' ||
						'  UPD_PGM_ID)             ' ||
						'             SELECT       ' ||
						'  ''111'', ' ||
						'  TTT.REC_ID,             ' ||
						'  TTT.SHI_CD,             ' ||
						'  NULL,    ' ||
						'  NULL,    ' ||
						'  NULL,    ' ||
						'  TTT.UPD_EIGY_YMD,       ' ||
						'  NULL,    ' ||
						'  TTT.DPC_FLG        , ' ||
						'  TTT.DPC_SHITEI_YMD , ' ||
						'  TTT.DPC_CANCEL_YMD , ' ||
						'  TTT.DPCJUNBI_FLG   , ' ||
						'  TTT.DPCJUNBI_SHONIN_Y             , ' ||
						'  TTT.DPCJUNBI_CANCEL_YMD           , ' ||
						'  TTT.GANKYOTEN_FLG  , ' ||
						'  TTT.GANKYOTEN_SHITEI_YMD          , ' ||
						'  TTT.GANKYOTEN_CANCEL_YMD          , ' ||
						'  TTT.TOKUTEIKINO_FLG, ' ||
						'  TTT.TOKUTEIKINO_SHONIN_YMD        , ' ||
						'  TTT.TOKUTEIKINO_CANCEL_YMD        , ' ||
						'  TTT.CHIKIRY_FLG    , ' ||
						'  TTT.CHIKIRY_SHOKAIRITSU           , ' ||
						'  TTT.CHIKIRY_SHONIN_YMD            , ' ||
						'  TTT.CHIKIRY_CANCEL_YMD            , ' ||
						'  TTT.CHOKYUNOSOCCHU_FLG            , ' ||
						'  TTT.CHOKYUNOSOCCHU_SHONIN_YMD     , ' ||
						'  TTT.CHOKYUNOSOCCHU_CANCEL_YMD     , ' ||
						'  TTT.SOGONYUIN_FLG  , ' ||
						'  TTT.SOGONYUIN_SHONIN_YMD          , ' ||
						'  TTT.SOGONYUIN_CANCEL_YMD          , ' ||
						'  TTT.ISHIHOJO_FLG   , ' ||
						'  TTT.ISHIHOJO_SHONIN_YMD           , ' ||
						'  TTT.ISHIHOJO_CANCEL_YMD           , ' ||
						'  TTT.KARTE_FLG      , ' ||
						'  TTT.KARTE_SHONIN_YMD              , ' ||
						'  TTT.KARTE_CANCEL_YMD              , ' ||
						'  TTT.IRYANZEN_FLG   , ' ||
						'  TTT.IRYANZEN_SHONIN_YMD           , ' ||
						'  TTT.IRYANZEN_CANCEL_YMD           , ' ||
						'  TTT.JOKUSOCARE_FLG , ' ||
						'  TTT.JOKUSOCARE_SHONIN_YMD         , ' ||
						'  TTT.JOKUSOCARE_CANCEL_YMD         , ' ||
						'  TTT.SHONIYAKAN_FLG , ' ||
						'  TTT.SHONIYAKAN_SHONIN_YMD         , ' ||
						'  TTT.SHONIYAKAN_CANCEL_YMD         , ' ||
						'  TTT.KAIHOGATA_FLG  , ' ||
						'  TTT.KAIHOGATA_SHONIN_YMD          , ' ||
						'  TTT.KAIHOGATA_CANCEL_YMD          , ' ||
						'  TTT.CHIKRENKEIPATH_FLG            , ' ||
						'  TTT.CHIKRENKEIPATH_CD_01          , ' ||
						'  TTT.CHIKRENKEIPATH_CD_02          , ' ||
						'  TTT.CHIKRENKEIPATH_CD_03          , ' ||
						'  TTT.CHIKRENKEIPATH_CD_04          , ' ||
						'  TTT.CHIKRENKEIPATH_CD_05          , ' ||
						'  TTT.CHIKRENKEIPATH_CD_06          , ' ||
						'  TTT.CHIKRENKEIPATH_CD_07          , ' ||
						'  TTT.CHIKRENKEIPATH_CD_08          , ' ||
						'  TTT.CHIKRENKEIPATH_CD_09          , ' ||
						'  TTT.CHIKRENKEIPATH_CD_10          , ' ||
						'  TTT.CHIKRENKEIPATH_CD_11          , ' ||
						'  TTT.CHIKRENKEIPATH_CD_12          , ' ||
						'  TTT.CHIKRENKEIPATH_CD_13          , ' ||
						'  TTT.CHIKRENKEIPATH_CD_14          , ' ||
						'  TTT.CHIKRENKEIPATH_CD_15          , ' ||
						'  TTT.CHIKRENKEIPATH_CD_16          , ' ||
						'  TTT.CHIKRENKEIPATH_CD_17          , ' ||
						'  TTT.CHIKRENKEIPATH_CD_18          , ' ||
						'  TTT.CHIKRENKEIPATH_CD_19          , ' ||
						'  TTT.CHIKRENKEIPATH_CD_20          , ' ||
						'  TTT.YAKUZAIKANRI_FLG              , ' ||
						'  TTT.YAKUZAIKANRI_SHONIN_YMD       , ' ||
						'  TTT.YAKUZAIKANRI_CANCEL_YMD       , ' ||
						'  TTT.GAZOSHINDAN_FLG, ' ||
						'  TTT.GAZOSHINDAN_SHONIN_YMD        , ' ||
						'  TTT.GAZOSHINDAN_CANCEL_YMD        , ' ||
						'  TTT.GIRIKGK_FLG    , ' ||
						'  TTT.GIRIKGK_SHONIN_YMD            , ' ||
						'  TTT.GIRIKGK_CANCEL_YMD            , ' ||
						'  TTT.SHIKKANBETSUREHA_FLG          , ' ||
						'  TTT.SHIKKANBETSUREHA_CD_01        , ' ||
						'  TTT.SHIKKANBETSUREHA_CD_02        , ' ||
						'  TTT.SHIKKANBETSUREHA_CD_03        , ' ||
						'  TTT.SHIKKANBETSUREHA_CD_04        , ' ||
						'  TTT.SHIKKANBETSUREHA_CD_05        , ' ||
						'  TTT.SHIKKANBETSUREHA_CD_06        , ' ||
						'  TTT.SHIKKANBETSUREHA_CD_07        , ' ||
						'  TTT.SHIKKANBETSUREHA_CD_08        , ' ||
						'  TTT.SHIKKANBETSUREHA_CD_09        , ' ||
						'  TTT.SHIKKANBETSUREHA_CD_10        , ' ||
						'  TTT.MASUIKANRI_FLG , ' ||
						'  TTT.MASUIKANRI_SHONIN_YMD         , ' ||
						'  TTT.MASUIKANRI_CANCEL_YMD         , ' ||
						'  TTT.ZAITAKUSHIEN_FLG              , ' ||
						'  TTT.ZAITAKUSHIEN_SHONIN_YMD       , ' ||
						'  TTT.ZAITAKUSHIEN_CANCEL_YMD       , ' ||
						'  TTT.ZAIISOKAN_FLG  , ' ||
						'  TTT.ZAIISOKAN_SHONIN_YMD          , ' ||
						'  TTT.ZAIISOKAN_CANCEL_YMD          , ' ||
						'  TTT.ZAITAKUMAKKI_FLG              , ' ||
						'  TTT.ZAITAKUMAKKI_SHONIN_YMD       , ' ||
						'  TTT.ZAITAKUMAKKI_CANCEL_YMD       , ' ||
						'  TTT.CAREMIXTO_KBN_CD              , ' ||
						'  TTT.RYOYO_KANI_KBN_CD             , ' ||
						'  TTT.RYOYO_FLG      , ' ||
						'  TTT.RYOYO_IRY_KNG_SBT_CD          , ' ||
						'  TTT.RYOYO_IRY_BED_SU              , ' ||
						'  TTT.RYOYO_IRY_SHONIN_YMD          , ' ||
						'  TTT.RYOYO_IRY_CANCEL_YMD          , ' ||
						'  TTT.RYOYO_KIG_KNG_SBT_CD          , ' ||
						'  TTT.RYOYO_KIG_BED_SU              , ' ||
						'  TTT.RYOYO_KIG_SHONIN_YMD          , ' ||
						'  TTT.RYOYO_KIG_CANCEL_YMD          , ' ||
						'  TTT.RYOYO_GOKEI_BED_SU            , ' ||
						'  TTT.IPPAN_FLG      , ' ||
						'  TTT.IPPAN_KNG_SBT_CD              , ' ||
						'  TTT.IPPAN_BED_SU   , ' ||
						'  TTT.SEISHIN_FLG    , ' ||
						'  TTT.SEISHIN_KNG_SBT_CD            , ' ||
						'  TTT.SEISHIN_BED_SU , ' ||
						'  TTT.KEKKAKU_FLG    , ' ||
						'  TTT.KEKKAKU_KNG_SBT_CD            , ' ||
						'  TTT.KEKKAKU_BED_SU , ' ||
						'  TTT.KANSEN_TOKUTEI_FLG            , ' ||
						'  TTT.KANSEN_1SHU_FLG, ' ||
						'  TTT.KANSEN_2SHU_FLG, ' ||
						'  TTT.KANSEN_FLG     , ' ||
						'  TTT.KANSEN_BED_SU  , ' ||
						'  TTT.KANWACARE_FLG  , ' ||
						'  TTT.KANWACARE_BED_SU              , ' ||
						'  TTT.KANWACARE_SHONIN_YMD          , ' ||
						'  TTT.KANWACARE_CANCEL_YMD          , ' ||
						'  TTT.IRYHYOKA_FLG   , ' ||
						'  TTT.IRYHYOKA_CD    , ' ||
						'  TTT.IRYHYOKA_SHONIN_YMD           , ' ||
						'  TTT.IRYHYOKA_CANCEL_YMD           , ' ||
						'  TTT.RNSKNS_KKN1_FLG, ' ||
						'  TTT.RNSKNS_KKN1_SHONIN_YMD        , ' ||
						'  TTT.RNSKNS_KKN1_CANCEL_YMD        , ' ||
						'  TTT.RNSKNS_KKN2_FLG, ' ||
						'  TTT.RNSKNS_KKN2_SHONIN_YMD        , ' ||
						'  TTT.RNSKNS_KKN2_CANCEL_YMD        , ' ||
						'  TTT.RNSKNS_KYRYK_FLG              , ' ||
						'  TTT.RNSKNS_KYRYK_SHONIN_YMD       , ' ||
						'  TTT.RNSKNS_KYRYK_CANCEL_YMD       , ' ||
						'  TTT.SAIGAIKYOTEN_FLG              , ' ||
						'  TTT.KYUKYU_IRY_KKJ_FLG            , ' ||
						'  TTT.KYUKYU_IRY_2JI_FLG            , ' ||
						'  TTT.KYUKYU_IRY_3JI_FLG            , ' ||
						'  TTT.KYUKYUKOKUJI_FLG              , ' ||
						'  TTT.CHIKENCHUKAKU_FLG             , ' ||
						'  TTT.CHIKENCHUKAKU_KBN             , ' ||
						'  TTT.CHIKENCHUKAKU_SHONIN_YMD      , ' ||
						'  TTT.CHIKENCHUKAKU_CANCEL_YMD      , ' ||
						'  TTT.NINCHISHOIRY_FLG              , ' ||
						'  TTT.NINCHISHOIRY_SHONIN_YMD       , ' ||
						'  TTT.NINCHISHOIRY_CANCEL_YMD       , ' ||
						'  TTT.TOKUTEIKENSHIN_FLG            , ' ||
						'  TTT.TOKUTEISHIDO_FLG              , ' ||
						'  TTT.SENSHIN_1_40_FLG              , ' ||
						'  NVL2(TTT.SENSHIN_CD_01,SUBSTR(TTT.SENSHIN_CD_01,1,3),NULL),   ' ||
			            '  DECODE(SUBSTR(TTT.SENSHIN_CD_01,4,1),''0'',NULL,SUBSTR(TTT.SENSHIN_CD_01,4,1)),' ||
			            '  NVL2(TTT.SENSHIN_CD_02,SUBSTR(TTT.SENSHIN_CD_02,1,3),NULL),   ' ||
			            '  DECODE(SUBSTR(TTT.SENSHIN_CD_02,4,1),''0'',NULL,SUBSTR(TTT.SENSHIN_CD_02,4,1)),' ||
			            '  NVL2(TTT.SENSHIN_CD_03,SUBSTR(TTT.SENSHIN_CD_03,1,3),NULL),   ' ||
			            '  DECODE(SUBSTR(TTT.SENSHIN_CD_03,4,1),''0'',NULL,SUBSTR(TTT.SENSHIN_CD_03,4,1)),' ||
			            '  NVL2(TTT.SENSHIN_CD_04,SUBSTR(TTT.SENSHIN_CD_04,1,3),NULL),   ' ||
			            '  DECODE(SUBSTR(TTT.SENSHIN_CD_04,4,1),''0'',NULL,SUBSTR(TTT.SENSHIN_CD_04,4,1)),' ||
			            '  NVL2(TTT.SENSHIN_CD_05,SUBSTR(TTT.SENSHIN_CD_05,1,3),NULL),   ' ||
			            '  DECODE(SUBSTR(TTT.SENSHIN_CD_05,4,1),''0'',NULL,SUBSTR(TTT.SENSHIN_CD_05,4,1)),' ||
			            '  NVL2(TTT.SENSHIN_CD_06,SUBSTR(TTT.SENSHIN_CD_06,1,3),NULL),   ' ||
			            '  DECODE(SUBSTR(TTT.SENSHIN_CD_06,4,1),''0'',NULL,SUBSTR(TTT.SENSHIN_CD_06,4,1)),' ||
			            '  NVL2(TTT.SENSHIN_CD_07,SUBSTR(TTT.SENSHIN_CD_07,1,3),NULL),   ' ||
			            '  DECODE(SUBSTR(TTT.SENSHIN_CD_07,4,1),''0'',NULL,SUBSTR(TTT.SENSHIN_CD_07,4,1)),' ||
			            '  NVL2(TTT.SENSHIN_CD_08,SUBSTR(TTT.SENSHIN_CD_08,1,3),NULL),   ' ||
			            '  DECODE(SUBSTR(TTT.SENSHIN_CD_08,4,1),''0'',NULL,SUBSTR(TTT.SENSHIN_CD_08,4,1)),' ||
			            '  NVL2(TTT.SENSHIN_CD_09,SUBSTR(TTT.SENSHIN_CD_09,1,3),NULL),   ' ||
			            '  DECODE(SUBSTR(TTT.SENSHIN_CD_09,4,1),''0'',NULL,SUBSTR(TTT.SENSHIN_CD_09,4,1)),' ||
			            '  NVL2(TTT.SENSHIN_CD_10,SUBSTR(TTT.SENSHIN_CD_10,1,3),NULL),   ' ||
			            '  DECODE(SUBSTR(TTT.SENSHIN_CD_10,4,1),''0'',NULL,SUBSTR(TTT.SENSHIN_CD_10,4,1)),' ||
			            '  NVL2(TTT.SENSHIN_CD_11,SUBSTR(TTT.SENSHIN_CD_11,1,3),NULL),   ' ||
			            '  DECODE(SUBSTR(TTT.SENSHIN_CD_11,4,1),''0'',NULL,SUBSTR(TTT.SENSHIN_CD_11,4,1)),' ||
			            '  NVL2(TTT.SENSHIN_CD_12,SUBSTR(TTT.SENSHIN_CD_12,1,3),NULL),   ' ||
			            '  DECODE(SUBSTR(TTT.SENSHIN_CD_12,4,1),''0'',NULL,SUBSTR(TTT.SENSHIN_CD_12,4,1)),' ||
			            '  NVL2(TTT.SENSHIN_CD_13,SUBSTR(TTT.SENSHIN_CD_13,1,3),NULL),   ' ||
			            '  DECODE(SUBSTR(TTT.SENSHIN_CD_13,4,1),''0'',NULL,SUBSTR(TTT.SENSHIN_CD_13,4,1)),' ||
			            '  NVL2(TTT.SENSHIN_CD_14,SUBSTR(TTT.SENSHIN_CD_14,1,3),NULL),   ' ||
			            '  DECODE(SUBSTR(TTT.SENSHIN_CD_14,4,1),''0'',NULL,SUBSTR(TTT.SENSHIN_CD_14,4,1)),' ||
			            '  NVL2(TTT.SENSHIN_CD_15,SUBSTR(TTT.SENSHIN_CD_15,1,3),NULL),   ' ||
			            '  DECODE(SUBSTR(TTT.SENSHIN_CD_15,4,1),''0'',NULL,SUBSTR(TTT.SENSHIN_CD_15,4,1)),' ||
			            '  NVL2(TTT.SENSHIN_CD_16,SUBSTR(TTT.SENSHIN_CD_16,1,3),NULL),   ' ||
			            '  DECODE(SUBSTR(TTT.SENSHIN_CD_16,4,1),''0'',NULL,SUBSTR(TTT.SENSHIN_CD_16,4,1)),' ||
			            '  NVL2(TTT.SENSHIN_CD_17,SUBSTR(TTT.SENSHIN_CD_17,1,3),NULL),   ' ||
			            '  DECODE(SUBSTR(TTT.SENSHIN_CD_17,4,1),''0'',NULL,SUBSTR(TTT.SENSHIN_CD_17,4,1)),' ||
			            '  NVL2(TTT.SENSHIN_CD_18,SUBSTR(TTT.SENSHIN_CD_18,1,3),NULL),   ' ||
			            '  DECODE(SUBSTR(TTT.SENSHIN_CD_18,4,1),''0'',NULL,SUBSTR(TTT.SENSHIN_CD_18,4,1)),' ||
			            '  NVL2(TTT.SENSHIN_CD_19,SUBSTR(TTT.SENSHIN_CD_19,1,3),NULL),   ' ||
			            '  DECODE(SUBSTR(TTT.SENSHIN_CD_19,4,1),''0'',NULL,SUBSTR(TTT.SENSHIN_CD_19,4,1)),' ||
			            '  NVL2(TTT.SENSHIN_CD_20,SUBSTR(TTT.SENSHIN_CD_20,1,3),NULL),   ' ||
			            '  DECODE(SUBSTR(TTT.SENSHIN_CD_20,4,1),''0'',NULL,SUBSTR(TTT.SENSHIN_CD_20,4,1)),' ||
			            '  NVL2(TTT.SENSHIN_CD_21,SUBSTR(TTT.SENSHIN_CD_21,1,3),NULL),   ' ||
			            '  DECODE(SUBSTR(TTT.SENSHIN_CD_21,4,1),''0'',NULL,SUBSTR(TTT.SENSHIN_CD_21,4,1)),' ||
			            '  NVL2(TTT.SENSHIN_CD_22,SUBSTR(TTT.SENSHIN_CD_22,1,3),NULL),   ' ||
			            '  DECODE(SUBSTR(TTT.SENSHIN_CD_22,4,1),''0'',NULL,SUBSTR(TTT.SENSHIN_CD_22,4,1)),' ||
			            '  NVL2(TTT.SENSHIN_CD_23,SUBSTR(TTT.SENSHIN_CD_23,1,3),NULL),   ' ||
			            '  DECODE(SUBSTR(TTT.SENSHIN_CD_23,4,1),''0'',NULL,SUBSTR(TTT.SENSHIN_CD_23,4,1)),' ||
			            '  NVL2(TTT.SENSHIN_CD_24,SUBSTR(TTT.SENSHIN_CD_24,1,3),NULL),   ' ||
			            '  DECODE(SUBSTR(TTT.SENSHIN_CD_24,4,1),''0'',NULL,SUBSTR(TTT.SENSHIN_CD_24,4,1)),' ||
			            '  NVL2(TTT.SENSHIN_CD_25,SUBSTR(TTT.SENSHIN_CD_25,1,3),NULL),   ' ||
			            '  DECODE(SUBSTR(TTT.SENSHIN_CD_25,4,1),''0'',NULL,SUBSTR(TTT.SENSHIN_CD_25,4,1)),' ||
			            '  NVL2(TTT.SENSHIN_CD_26,SUBSTR(TTT.SENSHIN_CD_26,1,3),NULL),   ' ||
			            '  DECODE(SUBSTR(TTT.SENSHIN_CD_26,4,1),''0'',NULL,SUBSTR(TTT.SENSHIN_CD_26,4,1)),' ||
			            '  NVL2(TTT.SENSHIN_CD_27,SUBSTR(TTT.SENSHIN_CD_27,1,3),NULL),   ' ||
			            '  DECODE(SUBSTR(TTT.SENSHIN_CD_27,4,1),''0'',NULL,SUBSTR(TTT.SENSHIN_CD_27,4,1)),' ||
			            '  NVL2(TTT.SENSHIN_CD_28,SUBSTR(TTT.SENSHIN_CD_28,1,3),NULL),   ' ||
			            '  DECODE(SUBSTR(TTT.SENSHIN_CD_28,4,1),''0'',NULL,SUBSTR(TTT.SENSHIN_CD_28,4,1)),' ||
			            '  NVL2(TTT.SENSHIN_CD_29,SUBSTR(TTT.SENSHIN_CD_29,1,3),NULL),   ' ||
			            '  DECODE(SUBSTR(TTT.SENSHIN_CD_29,4,1),''0'',NULL,SUBSTR(TTT.SENSHIN_CD_29,4,1)),' ||
			            '  NVL2(TTT.SENSHIN_CD_30,SUBSTR(TTT.SENSHIN_CD_30,1,3),NULL),   ' ||
			            '  DECODE(SUBSTR(TTT.SENSHIN_CD_30,4,1),''0'',NULL,SUBSTR(TTT.SENSHIN_CD_30,4,1)),' ||
			            '  NVL2(TTT.SENSHIN_CD_31,SUBSTR(TTT.SENSHIN_CD_31,1,3),NULL),   ' ||
			            '  DECODE(SUBSTR(TTT.SENSHIN_CD_31,4,1),''0'',NULL,SUBSTR(TTT.SENSHIN_CD_31,4,1)),' ||
			            '  NVL2(TTT.SENSHIN_CD_32,SUBSTR(TTT.SENSHIN_CD_32,1,3),NULL),   ' ||
			            '  DECODE(SUBSTR(TTT.SENSHIN_CD_32,4,1),''0'',NULL,SUBSTR(TTT.SENSHIN_CD_32,4,1)),' ||
			            '  NVL2(TTT.SENSHIN_CD_33,SUBSTR(TTT.SENSHIN_CD_33,1,3),NULL),   ' ||
			            '  DECODE(SUBSTR(TTT.SENSHIN_CD_33,4,1),''0'',NULL,SUBSTR(TTT.SENSHIN_CD_33,4,1)),' ||
			            '  NVL2(TTT.SENSHIN_CD_34,SUBSTR(TTT.SENSHIN_CD_34,1,3),NULL),   ' ||
			            '  DECODE(SUBSTR(TTT.SENSHIN_CD_34,4,1),''0'',NULL,SUBSTR(TTT.SENSHIN_CD_34,4,1)),' ||
			            '  NVL2(TTT.SENSHIN_CD_35,SUBSTR(TTT.SENSHIN_CD_35,1,3),NULL),   ' ||
			            '  DECODE(SUBSTR(TTT.SENSHIN_CD_35,4,1),''0'',NULL,SUBSTR(TTT.SENSHIN_CD_35,4,1)),' ||
			            '  NVL2(TTT.SENSHIN_CD_36,SUBSTR(TTT.SENSHIN_CD_36,1,3),NULL),   ' ||
			            '  DECODE(SUBSTR(TTT.SENSHIN_CD_36,4,1),''0'',NULL,SUBSTR(TTT.SENSHIN_CD_36,4,1)),' ||
			            '  NVL2(TTT.SENSHIN_CD_37,SUBSTR(TTT.SENSHIN_CD_37,1,3),NULL),   ' ||
			            '  DECODE(SUBSTR(TTT.SENSHIN_CD_37,4,1),''0'',NULL,SUBSTR(TTT.SENSHIN_CD_37,4,1)),' ||
			            '  NVL2(TTT.SENSHIN_CD_38,SUBSTR(TTT.SENSHIN_CD_38,1,3),NULL),   ' ||
			            '  DECODE(SUBSTR(TTT.SENSHIN_CD_38,4,1),''0'',NULL,SUBSTR(TTT.SENSHIN_CD_38,4,1)),' ||
			            '  NVL2(TTT.SENSHIN_CD_39,SUBSTR(TTT.SENSHIN_CD_39,1,3),NULL),   ' ||
			            '  DECODE(SUBSTR(TTT.SENSHIN_CD_39,4,1),''0'',NULL,SUBSTR(TTT.SENSHIN_CD_39,4,1)),' ||
			            '  NVL2(TTT.SENSHIN_CD_40,SUBSTR(TTT.SENSHIN_CD_40,1,3),NULL),   ' ||
			            '  DECODE(SUBSTR(TTT.SENSHIN_CD_40,4,1),''0'',NULL,SUBSTR(TTT.SENSHIN_CD_40,4,1)),' ||      
						'  TTT.SNTNIRY_FLG    , ' ||
						'  TTT.SNTNIRY_CD_01  , ' ||
						'  TTT.SNTNIRY_CD_02  , ' ||
						'  TTT.SNTNIRY_CD_03  , ' ||
						'  TTT.SNTNIRY_CD_04  , ' ||
						'  TTT.SNTNIRY_CD_05  , ' ||
						'  TTT.SNTNIRY_CD_06  , ' ||
						'  TTT.SNTNIRY_CD_07  , ' ||
						'  TTT.SNTNIRY_CD_08  , ' ||
						'  TTT.SNTNIRY_CD_09  , ' ||
						'  TTT.SNTNIRY_CD_10  , ' ||
						'  TTT.SNTNIRY_CD_11  , ' ||
						'  TTT.SNTNIRY_CD_12  , ' ||
						'  TTT.SNTNIRY_CD_13  , ' ||
						'  TTT.SNTNIRY_CD_14  , ' ||
						'  TTT.SNTNIRY_CD_15  , ' ||
						'  TTT.SNTNIRY_CD_16  , ' ||
						'  TTT.SNTNIRY_CD_17  , ' ||
						'  TTT.SNTNIRY_CD_18  , ' ||
						'  TTT.SNTNIRY_CD_19  , ' ||
						'  TTT.SNTNIRY_CD_20  , ' ||
						'  TTT.SEISAKUIRY_FLG , ' ||
						'  TTT.SEISAKUIRY_BNY_CD_01          , ' ||
						'  TTT.SEISAKUIRY_KBN_CD_01          , ' ||
						'  TTT.SEISAKUIRY_BNY_CD_02          , ' ||
						'  TTT.SEISAKUIRY_KBN_CD_02          , ' ||
						'  TTT.SEISAKUIRY_BNY_CD_03          , ' ||
						'  TTT.SEISAKUIRY_KBN_CD_03          , ' ||
						'  TTT.SEISAKUIRY_BNY_CD_04          , ' ||
						'  TTT.SEISAKUIRY_KBN_CD_04          , ' ||
						'  TTT.SEISAKUIRY_BNY_CD_05          , ' ||
						'  TTT.SEISAKUIRY_KBN_CD_05          , ' ||
						'  TTT.SEISAKUIRY_BNY_CD_06          , ' ||
						'  TTT.SEISAKUIRY_KBN_CD_06          , ' ||
						'  TTT.SEISAKUIRY_BNY_CD_07          , ' ||
						'  TTT.SEISAKUIRY_KBN_CD_07          , ' ||
						'  TTT.SEISAKUIRY_BNY_CD_08          , ' ||
						'  TTT.SEISAKUIRY_KBN_CD_08          , ' ||
						'  TTT.SEISAKUIRY_BNY_CD_09          , ' ||
						'  TTT.SEISAKUIRY_KBN_CD_09          , ' ||
						'  TTT.SEISAKUIRY_BNY_CD_10          , ' ||
						'  TTT.SEISAKUIRY_KBN_CD_10          , ' ||
						'  TTT.SEISAKUIRY_BNY_CD_11          , ' ||
						'  TTT.SEISAKUIRY_KBN_CD_11          , ' ||
						'  TTT.SEISAKUIRY_BNY_CD_12          , ' ||
						'  TTT.SEISAKUIRY_KBN_CD_12          , ' ||
						'  TTT.SEISAKUIRY_BNY_CD_13          , ' ||
						'  TTT.SEISAKUIRY_KBN_CD_13          , ' ||
						'  TTT.SEISAKUIRY_BNY_CD_14          , ' ||
						'  TTT.SEISAKUIRY_KBN_CD_14          , ' ||
						'  TTT.SEISAKUIRY_BNY_CD_15          , ' ||
						'  TTT.SEISAKUIRY_KBN_CD_15          , ' ||
						'  TTT.SEISAKUIRY_BNY_CD_16          , ' ||
						'  TTT.SEISAKUIRY_KBN_CD_16          , ' ||
						'  TTT.SEISAKUIRY_BNY_CD_17          , ' ||
						'  TTT.SEISAKUIRY_KBN_CD_17          , ' ||
						'  TTT.SEISAKUIRY_BNY_CD_18          , ' ||
						'  TTT.SEISAKUIRY_KBN_CD_18          , ' ||
						'  TTT.SEISAKUIRY_BNY_CD_19          , ' ||
						'  TTT.SEISAKUIRY_KBN_CD_19          , ' ||
						'  TTT.SEISAKUIRY_BNY_CD_20          , ' ||
						'  TTT.SEISAKUIRY_KBN_CD_20          , ' ||
						'  TTT.HMNKNG_FLG     , ' ||
						'  TTT.HMNKNG_REC_ID  , ' ||
						'  TTT.HMNKNG_SHI_CD  , ' ||
						'  NULL,    ' ||
						'  TTT.KAISETSU_YM    , ' ||
						'  NULL,    ' ||
						  iTensoYMD      || ','      ||
						  iOPE_CD        || ','      ||
						  iDATE          || ','      ||
						  iPGM_ID        || ','      ||
						  iOPE_CD        || ','      ||
						  iDATE          || ','      ||
						  iPGM_ID     ||
						'           FROM TT_TIKY_SHI TTS          ' ||
						'        	  INNER JOIN TT_TIKY_TSUIKAITEM TTT	' ||
						'           ON TTS.REC_ID = TTT.REC_ID    ' ||
						'           AND TTS.SHI_CD = TTT.SHI_CD		' ||         
						' 		  WHERE TTS.REC_ID =' || '''00'''   ||
						' 		  AND TTS.DEL_FLG IS NULL         ' ||
						' 		  AND TTT.DEL_FLG IS NULL         ' ;

          ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);
    END IF;
    COMMIT;

    oROW_COUNT := -1;
	
	-- �I�����O�o��
    ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'PL/SQL End',PGM_ID || '�̏������I�����܂����B',iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);
      return 0;
    -- ��O����
  EXCEPTION
    -- ���̑��G���[
    WHEN OTHERS THEN
      W_ERR_INF_RCD.ERR_CD     := TO_CHAR(SQLCODE);
      W_ERR_INF_RCD.ERR_MSG     := SUBSTR(SQLERRM, 0, 500);
      W_ERR_INF_RCD.ERR_KEY_INF   := SUBSTR('iShimeKind:' || iShimeKind , 0,500);
      W_INDEX_N           := W_ERR_INF_TBL.COUNT + 1;
      W_ERR_INF_TBL.EXTEND;
      W_ERR_INF_TBL(W_INDEX_N)   := W_ERR_INF_RCD;

      OPEN oOUT_ERR_INF_CSR FOR
        SELECT * FROM TABLE(W_ERR_INF_TBL);

        ROLLBACK;
        
      --�G���[���O�̓o�^
      ULT_INSERT_LOG_TABLE('ERROR',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'ERROR_INFO',W_ERR_INF_RCD.ERR_MSG,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);   

  return 1;
END;

END;
/
