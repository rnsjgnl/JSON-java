CREATE OR REPLACE PACKAGE    PKG_TT_SISN_SHI_FAX_GU
/* **********************************************************
 *  Copyright(c) 2011 beyond, INTEC Inc. All rights reserved.
 * **********************************************************/
IS
	-- TT_SISN_SHI_FAX%ROWTYPE��TABLE�^���`
	TYPE TT_SISN_SHI_FAX_ROWS IS TABLE OF TT_SISN_SHI_FAX%ROWTYPE;

	/*** �J�[�\���^ ***************************************************************/
	-- �G���[���i�[�p�J�[�\���^
	TYPE ERR_INF_CSR					IS REF CURSOR;

	/*
	************************************************************************
	*  TT_SISN_SHI_FAX
	*  DELETE_TOUJITSU
	************************************************************************
	*/
	FUNCTION DELETE_TOUJITSU(
		iREC_ID	IN	TT_SISN_SHI_FAX.REC_ID%TYPE,
		iSHI_CD	IN	TT_SISN_SHI_FAX.SHI_CD%TYPE,
		iFAX	IN	TT_SISN_SHI_FAX.FAX%TYPE,
		iTRK_EIGY_YMD			IN VARCHAR2,
		iIP_ADDR				IN TL_STORED_SHORI.IP%TYPE,					-- ���s�[��IP�A�h���X
		iWINDOWS_LOGIN_USER		IN TL_STORED_SHORI.WINDOWS_LOGIN_USER%TYPE, -- ���s�[��OS���[�U�[
		oROW_COUNT				OUT NUMBER,									-- �X�V����
		oOUT_ERR_INF_CSR 		OUT ERR_INF_CSR								-- �G���[���J�[�\��
	) RETURN NUMBER;

	/*
	************************************************************************
	*  TT_SISN_SHI_FAX
	*  INSERT_TOUJITSU
	************************************************************************
	*/
	FUNCTION INSERT_TOUJITSU(
		iREC_ID	IN	TT_SISN_SHI_FAX.REC_ID%TYPE,
		iSHI_CD	IN	TT_SISN_SHI_FAX.SHI_CD%TYPE,
		iFAX	IN	TT_SISN_SHI_FAX.FAX%TYPE,
		iTRK_EIGY_YMD			IN VARCHAR2,
		iIP_ADDR				IN TL_STORED_SHORI.IP%TYPE,					-- ���s�[��IP�A�h���X
		iWINDOWS_LOGIN_USER		IN TL_STORED_SHORI.WINDOWS_LOGIN_USER%TYPE, -- ���s�[��OS���[�U�[
		oROW_COUNT				OUT NUMBER,									-- �X�V����
		oOUT_ERR_INF_CSR 		OUT ERR_INF_CSR								-- �G���[���J�[�\��
	) RETURN NUMBER;

	/*
	************************************************************************
	*  TT_SISN_SHI_FAX
	*  UPDATE_TOUJITSU
	************************************************************************
	*/
	FUNCTION UPDATE_TOUJITSU(
		iREC_ID	IN	TT_SISN_SHI_FAX.REC_ID%TYPE,
		iSHI_CD	IN	TT_SISN_SHI_FAX.SHI_CD%TYPE,
		iFAX	IN	TT_SISN_SHI_FAX.FAX%TYPE,
		iTRK_EIGY_YMD			IN VARCHAR2,
		iIP_ADDR				IN TL_STORED_SHORI.IP%TYPE,					-- ���s�[��IP�A�h���X
		iWINDOWS_LOGIN_USER		IN TL_STORED_SHORI.WINDOWS_LOGIN_USER%TYPE, -- ���s�[��OS���[�U�[
		iKENSAKU_KMK			IN VARCHAR2,								-- �����p����
		oROW_COUNT				OUT NUMBER,									-- �X�V����
		oOUT_ERR_INF_CSR 		OUT ERR_INF_CSR								-- �G���[���J�[�\��
	) RETURN NUMBER;

END;
/

CREATE OR REPLACE PACKAGE BODY    PKG_TT_SISN_SHI_FAX_GU
/* **********************************************************
 *  Copyright(c) 2011 beyond, INTEC Inc. All rights reserved.
 * **********************************************************/
IS
/*
 ************************************************************************
 * Function ID  : DELETE_TOUJITSU
 * Program Name : �����i�c�Ɠ��j�o�^���ꂽ�f�[�^�𕨗��폜����
 * Parameter    : <I> iREC_ID	�FREC_ID%TYPE
 *                <I> iSHI_CD	�FSHI_CD%TYPE
 *                <I> iFAX	�FFAX%TYPE
 *                <I> iTRK_EIGY_YMD		:TRK_EIGY_YMD
 * Return       �F�������ʁi0:����I���A1:�ُ�I���j
 ************************************************************************
 */
	FUNCTION DELETE_TOUJITSU(
		iREC_ID	IN	TT_SISN_SHI_FAX.REC_ID%TYPE,
		iSHI_CD	IN	TT_SISN_SHI_FAX.SHI_CD%TYPE,
		iFAX	IN	TT_SISN_SHI_FAX.FAX%TYPE,
		iTRK_EIGY_YMD			IN VARCHAR2,
		iIP_ADDR				IN TL_STORED_SHORI.IP%TYPE,					-- ���s�[��IP�A�h���X
		iWINDOWS_LOGIN_USER		IN TL_STORED_SHORI.WINDOWS_LOGIN_USER%TYPE, -- ���s�[��OS���[�U�[
		oROW_COUNT				OUT NUMBER,									-- �X�V����
		oOUT_ERR_INF_CSR 		OUT ERR_INF_CSR								-- �G���[���J�[�\��
	) RETURN NUMBER IS

	/************************************************************************/
	/*                              �G���[����                              */
	/************************************************************************/
	W_INDEX_N 					NUMBER(10) := 0;
	W_ERR_INF_TBL 				TYPE_ERR_INFO_TBL := TYPE_ERR_INFO_TBL();
	W_ERR_INF_RCD 				TYPE_ERR_INFO_RCD := TYPE_ERR_INFO_RCD(NULL,NULL,NULL,NULL);

	BEGIN

		-- DELETE ���s
		DELETE TT_SISN_SHI_FAX
		WHERE REC_ID = iREC_ID
		AND SHI_CD = iSHI_CD
		AND FAX = iFAX
		AND TRK_FKT_EIGY_YMD = iTRK_EIGY_YMD;
		oROW_COUNT := SQL%ROWCOUNT;

		-- ����I��
		RETURN 0;

	-- ��O����
	EXCEPTION
		-- ���̑��G���[
		WHEN OTHERS THEN
			W_ERR_INF_RCD.ERR_CD 		:= TO_CHAR(SQLCODE);
			W_ERR_INF_RCD.ERR_MSG 		:= SUBSTR(SQLERRM, 0, 2000);
			W_ERR_INF_RCD.ERR_KEY_INF 	:= SUBSTR('REC_ID:' || iREC_ID || ', SHI_CD:' || iSHI_CD || ', FAX:' || iFAX, 0, 2000);
			W_INDEX_N 					:= W_ERR_INF_TBL.COUNT + 1;
			W_ERR_INF_TBL.EXTEND;
			W_ERR_INF_TBL(W_INDEX_N) 	:= W_ERR_INF_RCD;

			OPEN oOUT_ERR_INF_CSR FOR
				SELECT * FROM TABLE(W_ERR_INF_TBL);

			RETURN 1;
		END;

/*
 ************************************************************************
 * Function ID  : INSERT_TOUJITSU
 * Program Name : �����폜�̍ۂɗ������R�[�h������΍ŐV�e�[�u���ɔ��f����
 * Parameter    : <I> iREC_ID	�FREC_ID%TYPE
 *                <I> iSHI_CD	�FSHI_CD%TYPE
 *                <I> iFAX	�FFAX%TYPE
 *                <I> iTRK_EIGY_YMD		:TRK_EIGY_YMD
 * Return       �F�������ʁi0:����I���A1:�ُ�I���j
 ************************************************************************
 */
	FUNCTION INSERT_TOUJITSU(
		iREC_ID	IN	TT_SISN_SHI_FAX.REC_ID%TYPE,
		iSHI_CD	IN	TT_SISN_SHI_FAX.SHI_CD%TYPE,
		iFAX	IN	TT_SISN_SHI_FAX.FAX%TYPE,
		iTRK_EIGY_YMD			IN VARCHAR2,
		iIP_ADDR				IN TL_STORED_SHORI.IP%TYPE,					-- ���s�[��IP�A�h���X
		iWINDOWS_LOGIN_USER		IN TL_STORED_SHORI.WINDOWS_LOGIN_USER%TYPE, -- ���s�[��OS���[�U�[
		oROW_COUNT				OUT NUMBER,									-- �X�V����
		oOUT_ERR_INF_CSR 		OUT ERR_INF_CSR								-- �G���[���J�[�\��
	) RETURN NUMBER IS

	/************************************************************************/
	/*                              �G���[����                              */
	/************************************************************************/
	W_INDEX_N 					NUMBER(10) := 0;
	W_ERR_INF_TBL 				TYPE_ERR_INFO_TBL := TYPE_ERR_INFO_TBL();
	W_ERR_INF_RCD 				TYPE_ERR_INFO_RCD := TYPE_ERR_INFO_RCD(NULL,NULL,NULL,NULL);

	BEGIN

		-- INSERT ���s
		INSERT INTO TT_SISN_SHI_FAX
		SELECT 
			REC_ID,
			SHI_CD,
			FAX,
			DEL_FLG,
			DAIHYO_FAX_FLG,
			UKETORI_KYH_KBN,
			TEL_KENYO_FLG,
			BIKO,
			'',
			FAX_ATESAKI_CD,
			TRK_FKT_EIGY_YMD,
			TRK_USER_CD,
			TRK_EIGY_YMD,
			UPD_USER_CD,
			UPD_EIGY_YMD,
			TRK_OPE_CD,
			TRK_DATE,
			TRK_PGM_ID,
			UPD_OPE_CD,
			UPD_DATE,
			UPD_PGM_ID
		FROM TT_RRK_SHI_FAX
		WHERE SEQ = 
		(SELECT MAX(SEQ) 
		FROM TT_RRK_SHI_FAX 
		WHERE REC_ID = iREC_ID
		AND SHI_CD = iSHI_CD
		AND FAX = iFAX);
		oROW_COUNT := SQL%ROWCOUNT;

		-- ����I��
		RETURN 0;

	-- ��O����
	EXCEPTION
		-- ���̑��G���[
		WHEN OTHERS THEN
			W_ERR_INF_RCD.ERR_CD 		:= TO_CHAR(SQLCODE);
			W_ERR_INF_RCD.ERR_MSG 		:= SUBSTR(SQLERRM, 0, 2000);
			W_ERR_INF_RCD.ERR_KEY_INF 	:= SUBSTR('REC_ID:' || iREC_ID || ', SHI_CD:' || iSHI_CD || ', FAX:' || iFAX, 0, 2000);
			W_INDEX_N 					:= W_ERR_INF_TBL.COUNT + 1;
			W_ERR_INF_TBL.EXTEND;
			W_ERR_INF_TBL(W_INDEX_N) 	:= W_ERR_INF_RCD;

			OPEN oOUT_ERR_INF_CSR FOR
				SELECT * FROM TABLE(W_ERR_INF_TBL);

			RETURN 1;
		END;

/*
 ************************************************************************
 * Function ID  : UPDATE_TOUJITSU
 * Program Name : �����폜�̍ۂɗ������R�[�h������΍ŐV�e�[�u���ɔ��f����(�������ځA�o�^�����̍X�V�j
 * Parameter    : <I> iREC_ID	�FREC_ID%TYPE
 *                <I> iSHI_CD	�FSHI_CD%TYPE
 *                <I> iFAX	�FFAX%TYPE
 *                <I> iTRK_EIGY_YMD		:TRK_EIGY_YMD
 * Return       �F�������ʁi0:����I���A1:�ُ�I���j
 ************************************************************************
 */
	FUNCTION UPDATE_TOUJITSU(
		iREC_ID	IN	TT_SISN_SHI_FAX.REC_ID%TYPE,
		iSHI_CD	IN	TT_SISN_SHI_FAX.SHI_CD%TYPE,
		iFAX	IN	TT_SISN_SHI_FAX.FAX%TYPE,
		iTRK_EIGY_YMD			IN VARCHAR2,
		iIP_ADDR				IN TL_STORED_SHORI.IP%TYPE,					-- ���s�[��IP�A�h���X
		iWINDOWS_LOGIN_USER		IN TL_STORED_SHORI.WINDOWS_LOGIN_USER%TYPE, -- ���s�[��OS���[�U�[
		iKENSAKU_KMK			IN VARCHAR2,								-- �����p���� 
		oROW_COUNT				OUT NUMBER,									-- �X�V����
		oOUT_ERR_INF_CSR 		OUT ERR_INF_CSR								-- �G���[���J�[�\��
	) RETURN NUMBER IS

	/************************************************************************/
	/*                              �G���[����                              */
	/************************************************************************/
	W_INDEX_N 					NUMBER(10) := 0;
	W_ERR_INF_TBL 				TYPE_ERR_INFO_TBL := TYPE_ERR_INFO_TBL();
	W_ERR_INF_RCD 				TYPE_ERR_INFO_RCD := TYPE_ERR_INFO_RCD(NULL,NULL,NULL,NULL);
	W_TRK_USER_CD				VARCHAR(3) := NULL;
	W_TRK_EIGY_YMD				VARCHAR(8) := NULL;
	W_TRK_OPE_CD				VARCHAR(10) := NULL;
	W_TRK_DATE					DATE := NULL;
	W_TRK_PGM_ID				VARCHAR(12) := NULL;

	BEGIN

		-- ���ʑ����i�o�^���j��SELECT ���s
		SELECT 
		    TRK_USER_CD,
			TRK_EIGY_YMD,
			TRK_OPE_CD,
			TRK_DATE,
			TRK_PGM_ID
		INTO
		    W_TRK_USER_CD,
			W_TRK_EIGY_YMD,
			W_TRK_OPE_CD,
			W_TRK_DATE,
			W_TRK_PGM_ID
		FROM TT_RRK_SHI_FAX
		WHERE SEQ = 
		(SELECT MIN(SEQ) 
		FROM TT_RRK_SHI_FAX 
		WHERE REC_ID = iREC_ID
		AND SHI_CD = iSHI_CD
		AND FAX = iFAX);

		-- ���ʑ����i�o�^���j��UPDATE ���s
		UPDATE TT_SISN_SHI_FAX
		SET 
		    TRK_USER_CD = W_TRK_USER_CD,
			TRK_EIGY_YMD = W_TRK_EIGY_YMD,
			TRK_OPE_CD = W_TRK_OPE_CD,
			TRK_DATE = W_TRK_DATE,
			TRK_PGM_ID = W_TRK_PGM_ID
			,KENSAKU_FAX = iKENSAKU_KMK
		WHERE REC_ID = iREC_ID
		AND SHI_CD = iSHI_CD
		AND FAX = iFAX;
		oROW_COUNT := SQL%ROWCOUNT;

		-- ����I��
		RETURN 0;

	-- ��O����
	EXCEPTION
		-- ���̑��G���[
		WHEN OTHERS THEN
			W_ERR_INF_RCD.ERR_CD 		:= TO_CHAR(SQLCODE);
			W_ERR_INF_RCD.ERR_MSG 		:= SUBSTR(SQLERRM, 0, 2000);
			W_ERR_INF_RCD.ERR_KEY_INF 	:= SUBSTR('REC_ID:' || iREC_ID || ', SHI_CD:' || iSHI_CD || ', FAX:' || iFAX, 0, 2000);
			W_INDEX_N 					:= W_ERR_INF_TBL.COUNT + 1;
			W_ERR_INF_TBL.EXTEND;
			W_ERR_INF_TBL(W_INDEX_N) 	:= W_ERR_INF_RCD;

			OPEN oOUT_ERR_INF_CSR FOR
				SELECT * FROM TABLE(W_ERR_INF_TBL);

			RETURN 1;
		END;


END;
/
CREATE OR REPLACE PACKAGE    PKG_TT_RRK_SHI_FAX_GU
/* **********************************************************
 *  Copyright(c) 2011 beyond, INTEC Inc. All rights reserved.
 * **********************************************************/
IS
	-- TT_RRK_SHI_FAX%ROWTYPE��TABLE�^���`
	TYPE TT_RRK_SHI_FAX_ROWS IS TABLE OF TT_RRK_SHI_FAX%ROWTYPE;

	/*** �J�[�\���^ ***************************************************************/
	-- �G���[���i�[�p�J�[�\���^
	TYPE ERR_INF_CSR					IS REF CURSOR;

	/*
	************************************************************************
	*  TT_RRK_SHI_FAX
	*  DELETE_TOUJITSU
	************************************************************************
	*/
	FUNCTION DELETE_TOUJITSU(
		iREC_ID	IN	TT_RRK_SHI_FAX.REC_ID%TYPE,
		iSHI_CD	IN	TT_RRK_SHI_FAX.SHI_CD%TYPE,
		iFAX	IN	TT_RRK_SHI_FAX.FAX%TYPE,
		iTRK_EIGY_YMD			IN VARCHAR2,
		iIP_ADDR				IN TL_STORED_SHORI.IP%TYPE,					-- ���s�[��IP�A�h���X
		iWINDOWS_LOGIN_USER		IN TL_STORED_SHORI.WINDOWS_LOGIN_USER%TYPE, -- ���s�[��OS���[�U�[
		oROW_COUNT				OUT NUMBER,									-- �X�V����
		oOUT_ERR_INF_CSR 		OUT ERR_INF_CSR								-- �G���[���J�[�\��
	) RETURN NUMBER;

END;
/

CREATE OR REPLACE PACKAGE BODY    PKG_TT_RRK_SHI_FAX_GU
/* **********************************************************
 *  Copyright(c) 2011 beyond, INTEC Inc. All rights reserved.
 * **********************************************************/
IS
/*
 ************************************************************************
 * Function ID  : DELETE_TOUJITSU
 * Program Name : �����i�c�Ɠ��j�o�^���ꂽ�f�[�^�𕨗��폜����
 * Parameter    : <I> iREC_ID	�FREC_ID%TYPE
 *                <I> iSHI_CD	�FSHI_CD%TYPE
 *                <I> iFAX	�FFAX%TYPE
 *                <I> iTRK_EIGY_YMD		:TRK_EIGY_YMD
 * Return       �F�������ʁi0:����I���A1:�ُ�I���j
 ************************************************************************
 */
	FUNCTION DELETE_TOUJITSU(
		iREC_ID	IN	TT_RRK_SHI_FAX.REC_ID%TYPE,
		iSHI_CD	IN	TT_RRK_SHI_FAX.SHI_CD%TYPE,
		iFAX	IN	TT_RRK_SHI_FAX.FAX%TYPE,
		iTRK_EIGY_YMD			IN VARCHAR2,
		iIP_ADDR				IN TL_STORED_SHORI.IP%TYPE,					-- ���s�[��IP�A�h���X
		iWINDOWS_LOGIN_USER		IN TL_STORED_SHORI.WINDOWS_LOGIN_USER%TYPE, -- ���s�[��OS���[�U�[
		oROW_COUNT				OUT NUMBER,									-- �X�V����
		oOUT_ERR_INF_CSR 		OUT ERR_INF_CSR								-- �G���[���J�[�\��
	) RETURN NUMBER IS

	/************************************************************************/
	/*                              �G���[����                              */
	/************************************************************************/
	W_INDEX_N 					NUMBER(10) := 0;
	W_ERR_INF_TBL 				TYPE_ERR_INFO_TBL := TYPE_ERR_INFO_TBL();
	W_ERR_INF_RCD 				TYPE_ERR_INFO_RCD := TYPE_ERR_INFO_RCD(NULL,NULL,NULL,NULL);

	BEGIN

		-- DELETE ���s
		DELETE TT_RRK_SHI_FAX
		WHERE REC_ID = iREC_ID
		AND SHI_CD = iSHI_CD
		AND FAX = iFAX
		AND TRK_FKT_EIGY_YMD = iTRK_EIGY_YMD;
		oROW_COUNT := SQL%ROWCOUNT;

		-- ����I��
		RETURN 0;

	-- ��O����
	EXCEPTION
		-- ���̑��G���[
		WHEN OTHERS THEN
			W_ERR_INF_RCD.ERR_CD 		:= TO_CHAR(SQLCODE);
			W_ERR_INF_RCD.ERR_MSG 		:= SUBSTR(SQLERRM, 0, 2000);
			W_ERR_INF_RCD.ERR_KEY_INF 	:= SUBSTR('REC_ID:' || iREC_ID || ', SHI_CD:' || iSHI_CD || ', FAX:' || iFAX, 0, 2000);
			W_INDEX_N 					:= W_ERR_INF_TBL.COUNT + 1;
			W_ERR_INF_TBL.EXTEND;
			W_ERR_INF_TBL(W_INDEX_N) 	:= W_ERR_INF_RCD;

			OPEN oOUT_ERR_INF_CSR FOR
				SELECT * FROM TABLE(W_ERR_INF_TBL);

			RETURN 1;
		END;

END;
/
CREATE OR REPLACE PACKAGE    PKG_TT_SISN_SHI_HOMEPAGE_GU
/* **********************************************************
 *  Copyright(c) 2011 beyond, INTEC Inc. All rights reserved.
 * **********************************************************/
IS
	-- TT_SISN_SHI_HOMEPAGE%ROWTYPE��TABLE�^���`
	TYPE TT_SISN_SHI_HOMEPAGE_ROWS IS TABLE OF TT_SISN_SHI_HOMEPAGE%ROWTYPE;

	/*** �J�[�\���^ ***************************************************************/
	-- �G���[���i�[�p�J�[�\���^
	TYPE ERR_INF_CSR					IS REF CURSOR;

	/*
	************************************************************************
	*  TT_SISN_SHI_HOMEPAGE
	*  DELETE_TOUJITSU
	************************************************************************
	*/
	FUNCTION DELETE_TOUJITSU(
		iREC_ID	IN	TT_SISN_SHI_HOMEPAGE.REC_ID%TYPE,
		iSHI_CD	IN	TT_SISN_SHI_HOMEPAGE.SHI_CD%TYPE,
		iHOMEPAGE_URL	IN	TT_SISN_SHI_HOMEPAGE.HOMEPAGE_URL%TYPE,
		iTRK_EIGY_YMD			IN VARCHAR2,
		iIP_ADDR				IN TL_STORED_SHORI.IP%TYPE,					-- ���s�[��IP�A�h���X
		iWINDOWS_LOGIN_USER		IN TL_STORED_SHORI.WINDOWS_LOGIN_USER%TYPE, -- ���s�[��OS���[�U�[
		oROW_COUNT				OUT NUMBER,									-- �X�V����
		oOUT_ERR_INF_CSR 		OUT ERR_INF_CSR								-- �G���[���J�[�\��
	) RETURN NUMBER;

	/*
	************************************************************************
	*  TT_SISN_SHI_HOMEPAGE
	*  INSERT_TOUJITSU
	************************************************************************
	*/
	FUNCTION INSERT_TOUJITSU(
		iREC_ID	IN	TT_SISN_SHI_HOMEPAGE.REC_ID%TYPE,
		iSHI_CD	IN	TT_SISN_SHI_HOMEPAGE.SHI_CD%TYPE,
		iHOMEPAGE_URL	IN	TT_SISN_SHI_HOMEPAGE.HOMEPAGE_URL%TYPE,
		iTRK_EIGY_YMD			IN VARCHAR2,
		iIP_ADDR				IN TL_STORED_SHORI.IP%TYPE,					-- ���s�[��IP�A�h���X
		iWINDOWS_LOGIN_USER		IN TL_STORED_SHORI.WINDOWS_LOGIN_USER%TYPE, -- ���s�[��OS���[�U�[
		oROW_COUNT				OUT NUMBER,									-- �X�V����
		oOUT_ERR_INF_CSR 		OUT ERR_INF_CSR								-- �G���[���J�[�\��
	) RETURN NUMBER;

END;
/

CREATE OR REPLACE PACKAGE BODY    PKG_TT_SISN_SHI_HOMEPAGE_GU
/* **********************************************************
 *  Copyright(c) 2011 beyond, INTEC Inc. All rights reserved.
 * **********************************************************/
IS
/*
 ************************************************************************
 * Function ID  : DELETE_TOUJITSU
 * Program Name : �����i�c�Ɠ��j�o�^���ꂽ�f�[�^�𕨗��폜����
 * Parameter    : <I> iREC_ID	�FREC_ID%TYPE
 *                <I> iSHI_CD	�FSHI_CD%TYPE
 *                <I> iHOMEPAGE_URL	�FHOMEPAGE_URL%TYPE
 *                <I> iTRK_EIGY_YMD		:TRK_EIGY_YMD
 * Return       �F�������ʁi0:����I���A1:�ُ�I���j
 ************************************************************************
 */
	FUNCTION DELETE_TOUJITSU(
		iREC_ID	IN	TT_SISN_SHI_HOMEPAGE.REC_ID%TYPE,
		iSHI_CD	IN	TT_SISN_SHI_HOMEPAGE.SHI_CD%TYPE,
		iHOMEPAGE_URL	IN	TT_SISN_SHI_HOMEPAGE.HOMEPAGE_URL%TYPE,
		iTRK_EIGY_YMD			IN VARCHAR2,
		iIP_ADDR				IN TL_STORED_SHORI.IP%TYPE,					-- ���s�[��IP�A�h���X
		iWINDOWS_LOGIN_USER		IN TL_STORED_SHORI.WINDOWS_LOGIN_USER%TYPE, -- ���s�[��OS���[�U�[
		oROW_COUNT				OUT NUMBER,									-- �X�V����
		oOUT_ERR_INF_CSR 		OUT ERR_INF_CSR								-- �G���[���J�[�\��
	) RETURN NUMBER IS

	/************************************************************************/
	/*                              �G���[����                              */
	/************************************************************************/
	W_INDEX_N 					NUMBER(10) := 0;
	W_ERR_INF_TBL 				TYPE_ERR_INFO_TBL := TYPE_ERR_INFO_TBL();
	W_ERR_INF_RCD 				TYPE_ERR_INFO_RCD := TYPE_ERR_INFO_RCD(NULL,NULL,NULL,NULL);

	BEGIN

		-- DELETE ���s
		DELETE TT_SISN_SHI_HOMEPAGE
		WHERE REC_ID = iREC_ID
		AND SHI_CD = iSHI_CD
		AND HOMEPAGE_URL = iHOMEPAGE_URL
		AND TRK_FKT_EIGY_YMD = iTRK_EIGY_YMD;
		oROW_COUNT := SQL%ROWCOUNT;

		-- ����I��
		RETURN 0;

	-- ��O����
	EXCEPTION
		-- ���̑��G���[
		WHEN OTHERS THEN
			W_ERR_INF_RCD.ERR_CD 		:= TO_CHAR(SQLCODE);
			W_ERR_INF_RCD.ERR_MSG 		:= SUBSTR(SQLERRM, 0, 2000);
			W_ERR_INF_RCD.ERR_KEY_INF 	:= SUBSTR('REC_ID:' || iREC_ID || ', SHI_CD:' || iSHI_CD || ', HOMEPAGE_URL:' || iHOMEPAGE_URL, 0, 2000);
			W_INDEX_N 					:= W_ERR_INF_TBL.COUNT + 1;
			W_ERR_INF_TBL.EXTEND;
			W_ERR_INF_TBL(W_INDEX_N) 	:= W_ERR_INF_RCD;

			OPEN oOUT_ERR_INF_CSR FOR
				SELECT * FROM TABLE(W_ERR_INF_TBL);

			RETURN 1;
		END;

/*
 ************************************************************************
 * Function ID  : INSERT_TOUJITSU
 * Program Name : �����폜�̍ۂɗ������R�[�h������΍ŐV�e�[�u���ɔ��f����
 * Parameter    : <I> iREC_ID	�FREC_ID%TYPE
 *                <I> iSHI_CD	�FSHI_CD%TYPE
 *                <I> iHOMEPAGE_URL	�FHOMEPAGE_URL%TYPE
 *                <I> iTRK_EIGY_YMD		:TRK_EIGY_YMD
 * Return       �F�������ʁi0:����I���A1:�ُ�I���j
 ************************************************************************
 */
	FUNCTION INSERT_TOUJITSU(
		iREC_ID	IN	TT_SISN_SHI_HOMEPAGE.REC_ID%TYPE,
		iSHI_CD	IN	TT_SISN_SHI_HOMEPAGE.SHI_CD%TYPE,
		iHOMEPAGE_URL	IN	TT_SISN_SHI_HOMEPAGE.HOMEPAGE_URL%TYPE,
		iTRK_EIGY_YMD			IN VARCHAR2,
		iIP_ADDR				IN TL_STORED_SHORI.IP%TYPE,					-- ���s�[��IP�A�h���X
		iWINDOWS_LOGIN_USER		IN TL_STORED_SHORI.WINDOWS_LOGIN_USER%TYPE, -- ���s�[��OS���[�U�[
		oROW_COUNT				OUT NUMBER,									-- �X�V����
		oOUT_ERR_INF_CSR 		OUT ERR_INF_CSR								-- �G���[���J�[�\��
	) RETURN NUMBER IS

	/************************************************************************/
	/*                              �G���[����                              */
	/************************************************************************/
	W_INDEX_N 					NUMBER(10) := 0;
	W_ERR_INF_TBL 				TYPE_ERR_INFO_TBL := TYPE_ERR_INFO_TBL();
	W_ERR_INF_RCD 				TYPE_ERR_INFO_RCD := TYPE_ERR_INFO_RCD(NULL,NULL,NULL,NULL);
	W_TRK_USER_CD				VARCHAR(3) := NULL;
	W_TRK_EIGY_YMD				VARCHAR(8) := NULL;
	W_TRK_OPE_CD				VARCHAR(10) := NULL;
	W_TRK_DATE					DATE := NULL;
	W_TRK_PGM_ID				VARCHAR(12) := NULL;

	BEGIN

		-- INSERT ���s
		INSERT INTO TT_SISN_SHI_HOMEPAGE
		SELECT 
			REC_ID,
			SHI_CD,
			HOMEPAGE_URL,
			DEL_FLG,
			HOMEPAGE_NM,
			TRK_FKT_EIGY_YMD,
			TRK_USER_CD,
			TRK_EIGY_YMD,
			UPD_USER_CD,
			UPD_EIGY_YMD,
			TRK_OPE_CD,
			TRK_DATE,
			TRK_PGM_ID,
			UPD_OPE_CD,
			UPD_DATE,
			UPD_PGM_ID
		FROM TT_RRK_SHI_HOMEPAGE
		WHERE SEQ = 
		(SELECT MAX(SEQ) 
		FROM TT_RRK_SHI_HOMEPAGE 
		WHERE REC_ID = iREC_ID
		AND SHI_CD = iSHI_CD
		AND HOMEPAGE_URL = iHOMEPAGE_URL);
		oROW_COUNT := SQL%ROWCOUNT;

		-- ���ʑ����i�o�^���j��SELECT ���s
		SELECT 
		    TRK_USER_CD,
			TRK_EIGY_YMD,
			TRK_OPE_CD,
			TRK_DATE,
			TRK_PGM_ID
		INTO
		    W_TRK_USER_CD,
			W_TRK_EIGY_YMD,
			W_TRK_OPE_CD,
			W_TRK_DATE,
			W_TRK_PGM_ID
		FROM TT_RRK_SHI_HOMEPAGE
		WHERE SEQ = 
		(SELECT MIN(SEQ) 
		FROM TT_RRK_SHI_HOMEPAGE 
		WHERE REC_ID = iREC_ID
		AND SHI_CD = iSHI_CD
		AND HOMEPAGE_URL = iHOMEPAGE_URL);

		-- ���ʑ����i�o�^���j��UPDATE ���s
		UPDATE TT_SISN_SHI_HOMEPAGE
		SET 
		    TRK_USER_CD = W_TRK_USER_CD,
			TRK_EIGY_YMD = W_TRK_EIGY_YMD,
			TRK_OPE_CD = W_TRK_OPE_CD,
			TRK_DATE = W_TRK_DATE,
			TRK_PGM_ID = W_TRK_PGM_ID
		WHERE REC_ID = iREC_ID
		AND SHI_CD = iSHI_CD
		AND HOMEPAGE_URL = iHOMEPAGE_URL;
		oROW_COUNT := SQL%ROWCOUNT;

		-- ����I��
		RETURN 0;

	-- ��O����
	EXCEPTION
		-- ���̑��G���[
		WHEN OTHERS THEN
			W_ERR_INF_RCD.ERR_CD 		:= TO_CHAR(SQLCODE);
			W_ERR_INF_RCD.ERR_MSG 		:= SUBSTR(SQLERRM, 0, 2000);
			W_ERR_INF_RCD.ERR_KEY_INF 	:= SUBSTR('REC_ID:' || iREC_ID || ', SHI_CD:' || iSHI_CD || ', HOMEPAGE_URL:' || iHOMEPAGE_URL, 0, 2000);
			W_INDEX_N 					:= W_ERR_INF_TBL.COUNT + 1;
			W_ERR_INF_TBL.EXTEND;
			W_ERR_INF_TBL(W_INDEX_N) 	:= W_ERR_INF_RCD;

			OPEN oOUT_ERR_INF_CSR FOR
				SELECT * FROM TABLE(W_ERR_INF_TBL);

			RETURN 1;
		END;

END;
/
CREATE OR REPLACE PACKAGE    PKG_TT_RRK_SHI_HOMEPAGE_GU
/* **********************************************************
 *  Copyright(c) 2011 beyond, INTEC Inc. All rights reserved.
 * **********************************************************/
IS
	-- TT_RRK_SHI_HOMEPAGE%ROWTYPE��TABLE�^���`
	TYPE TT_RRK_SHI_HOMEPAGE_ROWS IS TABLE OF TT_RRK_SHI_HOMEPAGE%ROWTYPE;

	/*** �J�[�\���^ ***************************************************************/
	-- �G���[���i�[�p�J�[�\���^
	TYPE ERR_INF_CSR					IS REF CURSOR;

	/*
	************************************************************************
	*  TT_RRK_SHI_HOMEPAGE
	*  DELETE_TOUJITSU
	************************************************************************
	*/
	FUNCTION DELETE_TOUJITSU(
		iREC_ID	IN	TT_RRK_SHI_HOMEPAGE.REC_ID%TYPE,
		iSHI_CD	IN	TT_RRK_SHI_HOMEPAGE.SHI_CD%TYPE,
		iHOMEPAGE_URL	IN	TT_RRK_SHI_HOMEPAGE.HOMEPAGE_URL%TYPE,
		iTRK_EIGY_YMD			IN VARCHAR2,
		iIP_ADDR				IN TL_STORED_SHORI.IP%TYPE,					-- ���s�[��IP�A�h���X
		iWINDOWS_LOGIN_USER		IN TL_STORED_SHORI.WINDOWS_LOGIN_USER%TYPE, -- ���s�[��OS���[�U�[
		oROW_COUNT				OUT NUMBER,									-- �X�V����
		oOUT_ERR_INF_CSR 		OUT ERR_INF_CSR								-- �G���[���J�[�\��
	) RETURN NUMBER;

END;
/

CREATE OR REPLACE PACKAGE BODY    PKG_TT_RRK_SHI_HOMEPAGE_GU
/* **********************************************************
 *  Copyright(c) 2011 beyond, INTEC Inc. All rights reserved.
 * **********************************************************/
IS
/*
 ************************************************************************
 * Function ID  : DELETE_TOUJITSU
 * Program Name : �����i�c�Ɠ��j�o�^���ꂽ�f�[�^�𕨗��폜����
 * Parameter    : <I> iREC_ID	�FREC_ID%TYPE
 *                <I> iSHI_CD	�FSHI_CD%TYPE
 *                <I> iHOMEPAGE_URL	�FHOMEPAGE_URL%TYPE
 *                <I> iTRK_EIGY_YMD		:TRK_EIGY_YMD
 * Return       �F�������ʁi0:����I���A1:�ُ�I���j
 ************************************************************************
 */
	FUNCTION DELETE_TOUJITSU(
		iREC_ID	IN	TT_RRK_SHI_HOMEPAGE.REC_ID%TYPE,
		iSHI_CD	IN	TT_RRK_SHI_HOMEPAGE.SHI_CD%TYPE,
		iHOMEPAGE_URL	IN	TT_RRK_SHI_HOMEPAGE.HOMEPAGE_URL%TYPE,
		iTRK_EIGY_YMD			IN VARCHAR2,
		iIP_ADDR				IN TL_STORED_SHORI.IP%TYPE,					-- ���s�[��IP�A�h���X
		iWINDOWS_LOGIN_USER		IN TL_STORED_SHORI.WINDOWS_LOGIN_USER%TYPE, -- ���s�[��OS���[�U�[
		oROW_COUNT				OUT NUMBER,									-- �X�V����
		oOUT_ERR_INF_CSR 		OUT ERR_INF_CSR								-- �G���[���J�[�\��
	) RETURN NUMBER IS

	/************************************************************************/
	/*                              �G���[����                              */
	/************************************************************************/
	W_INDEX_N 					NUMBER(10) := 0;
	W_ERR_INF_TBL 				TYPE_ERR_INFO_TBL := TYPE_ERR_INFO_TBL();
	W_ERR_INF_RCD 				TYPE_ERR_INFO_RCD := TYPE_ERR_INFO_RCD(NULL,NULL,NULL,NULL);

	BEGIN

		-- DELETE ���s
		DELETE TT_RRK_SHI_HOMEPAGE
		WHERE REC_ID = iREC_ID
		AND SHI_CD = iSHI_CD
		AND HOMEPAGE_URL = iHOMEPAGE_URL
		AND TRK_FKT_EIGY_YMD = iTRK_EIGY_YMD;
		oROW_COUNT := SQL%ROWCOUNT;

		-- ����I��
		RETURN 0;

	-- ��O����
	EXCEPTION
		-- ���̑��G���[
		WHEN OTHERS THEN
			W_ERR_INF_RCD.ERR_CD 		:= TO_CHAR(SQLCODE);
			W_ERR_INF_RCD.ERR_MSG 		:= SUBSTR(SQLERRM, 0, 2000);
			W_ERR_INF_RCD.ERR_KEY_INF 	:= SUBSTR('REC_ID:' || iREC_ID || ', SHI_CD:' || iSHI_CD || ', HOMEPAGE_URL:' || iHOMEPAGE_URL, 0, 2000);
			W_INDEX_N 					:= W_ERR_INF_TBL.COUNT + 1;
			W_ERR_INF_TBL.EXTEND;
			W_ERR_INF_TBL(W_INDEX_N) 	:= W_ERR_INF_RCD;

			OPEN oOUT_ERR_INF_CSR FOR
				SELECT * FROM TABLE(W_ERR_INF_TBL);

			RETURN 1;
		END;

END;
/
CREATE OR REPLACE PACKAGE    PKG_TT_SISN_KJN_GAKKAI_GU
/* **********************************************************
 *  Copyright(c) 2011 beyond, INTEC Inc. All rights reserved.
 * **********************************************************/
IS
	-- TT_SISN_KJN_GAKKAI%ROWTYPE��TABLE�^���`
	TYPE TT_SISN_KJN_GAKKAI_ROWS IS TABLE OF TT_SISN_KJN_GAKKAI%ROWTYPE;

	/*** �J�[�\���^ ***************************************************************/
	-- �G���[���i�[�p�J�[�\���^
	TYPE ERR_INF_CSR					IS REF CURSOR;

	/*
	************************************************************************
	*  TT_SISN_KJN_GAKKAI
	*  DELETE_TOUJITSU
	************************************************************************
	*/
	FUNCTION DELETE_TOUJITSU(
		iREC_ID	IN	TT_SISN_KJN_GAKKAI.REC_ID%TYPE,
		iKJN_CD	IN	TT_SISN_KJN_GAKKAI.KJN_CD%TYPE,
		iGAKKAI_CD	IN	TT_SISN_KJN_GAKKAI.GAKKAI_CD%TYPE,
		iGAKKAI_NENDO	IN	TT_SISN_KJN_GAKKAI.GAKKAI_NENDO%TYPE,
		iTRK_EIGY_YMD			IN VARCHAR2,
		iIP_ADDR				IN TL_STORED_SHORI.IP%TYPE,					-- ���s�[��IP�A�h���X
		iWINDOWS_LOGIN_USER		IN TL_STORED_SHORI.WINDOWS_LOGIN_USER%TYPE, -- ���s�[��OS���[�U�[
		oROW_COUNT				OUT NUMBER,									-- �X�V����
		oOUT_ERR_INF_CSR 		OUT ERR_INF_CSR								-- �G���[���J�[�\��
	) RETURN NUMBER;

	/*
	************************************************************************
	*  TT_SISN_KJN_GAKKAI
	*  INSERT_TOUJITSU
	************************************************************************
	*/
	FUNCTION INSERT_TOUJITSU(
		iREC_ID	IN	TT_SISN_KJN_GAKKAI.REC_ID%TYPE,
		iKJN_CD	IN	TT_SISN_KJN_GAKKAI.KJN_CD%TYPE,
		iGAKKAI_CD	IN	TT_SISN_KJN_GAKKAI.GAKKAI_CD%TYPE,
		iGAKKAI_NENDO	IN	TT_SISN_KJN_GAKKAI.GAKKAI_NENDO%TYPE,
		iTRK_EIGY_YMD			IN VARCHAR2,
		iIP_ADDR				IN TL_STORED_SHORI.IP%TYPE,					-- ���s�[��IP�A�h���X
		iWINDOWS_LOGIN_USER		IN TL_STORED_SHORI.WINDOWS_LOGIN_USER%TYPE, -- ���s�[��OS���[�U�[
		oROW_COUNT				OUT NUMBER,									-- �X�V����
		oOUT_ERR_INF_CSR 		OUT ERR_INF_CSR								-- �G���[���J�[�\��
	) RETURN NUMBER;

END;
/

CREATE OR REPLACE PACKAGE BODY    PKG_TT_SISN_KJN_GAKKAI_GU
/* **********************************************************
 *  Copyright(c) 2011 beyond, INTEC Inc. All rights reserved.
 * **********************************************************/
IS
/*
 ************************************************************************
 * Function ID  : DELETE_TOUJITSU
 * Program Name : �����i�c�Ɠ��j�o�^���ꂽ�f�[�^�𕨗��폜����
 * Parameter    : <I> iREC_ID	�FREC_ID%TYPE
 *                <I> iKJN_CD	�FKJN_CD%TYPE
 *                <I> iGAKKAI_CD	�FGAKKAI_CD%TYPE
 *                <I> iGAKKAI_NENDO	�FGAKKAI_NENDO%TYPE
 *                <I> iTRK_EIGY_YMD		:TRK_EIGY_YMD
 * Return       �F�������ʁi0:����I���A1:�ُ�I���j
 ************************************************************************
 */
	FUNCTION DELETE_TOUJITSU(
		iREC_ID	IN	TT_SISN_KJN_GAKKAI.REC_ID%TYPE,
		iKJN_CD	IN	TT_SISN_KJN_GAKKAI.KJN_CD%TYPE,
		iGAKKAI_CD	IN	TT_SISN_KJN_GAKKAI.GAKKAI_CD%TYPE,
		iGAKKAI_NENDO	IN	TT_SISN_KJN_GAKKAI.GAKKAI_NENDO%TYPE,
		iTRK_EIGY_YMD			IN VARCHAR2,
		iIP_ADDR				IN TL_STORED_SHORI.IP%TYPE,					-- ���s�[��IP�A�h���X
		iWINDOWS_LOGIN_USER		IN TL_STORED_SHORI.WINDOWS_LOGIN_USER%TYPE, -- ���s�[��OS���[�U�[
		oROW_COUNT				OUT NUMBER,									-- �X�V����
		oOUT_ERR_INF_CSR 		OUT ERR_INF_CSR								-- �G���[���J�[�\��
	) RETURN NUMBER IS

	/************************************************************************/
	/*                              �G���[����                              */
	/************************************************************************/
	W_INDEX_N 					NUMBER(10) := 0;
	W_ERR_INF_TBL 				TYPE_ERR_INFO_TBL := TYPE_ERR_INFO_TBL();
	W_ERR_INF_RCD 				TYPE_ERR_INFO_RCD := TYPE_ERR_INFO_RCD(NULL,NULL,NULL,NULL);

	BEGIN

		-- DELETE ���s
		DELETE TT_SISN_KJN_GAKKAI
		WHERE REC_ID = iREC_ID
		AND KJN_CD = iKJN_CD
		AND GAKKAI_CD = iGAKKAI_CD
		AND GAKKAI_NENDO = iGAKKAI_NENDO
		AND TRK_FKT_EIGY_YMD = iTRK_EIGY_YMD;
		oROW_COUNT := SQL%ROWCOUNT;

		-- ����I��
		RETURN 0;

	-- ��O����
	EXCEPTION
		-- ���̑��G���[
		WHEN OTHERS THEN
			W_ERR_INF_RCD.ERR_CD 		:= TO_CHAR(SQLCODE);
			W_ERR_INF_RCD.ERR_MSG 		:= SUBSTR(SQLERRM, 0, 2000);
			W_ERR_INF_RCD.ERR_KEY_INF 	:= SUBSTR('REC_ID:' || iREC_ID || ', KJN_CD:' || iKJN_CD || ', GAKKAI_CD:' || iGAKKAI_CD || ', GAKKAI_NENDO:' || iGAKKAI_NENDO, 0, 2000);
			W_INDEX_N 					:= W_ERR_INF_TBL.COUNT + 1;
			W_ERR_INF_TBL.EXTEND;
			W_ERR_INF_TBL(W_INDEX_N) 	:= W_ERR_INF_RCD;

			OPEN oOUT_ERR_INF_CSR FOR
				SELECT * FROM TABLE(W_ERR_INF_TBL);

			RETURN 1;
		END;

/*
 ************************************************************************
 * Function ID  : INSERT_TOUJITSU
 * Program Name : �����폜�̍ۂɗ������R�[�h������΍ŐV�e�[�u���ɔ��f����
 * Parameter    : <I> iREC_ID	�FREC_ID%TYPE
 *                <I> iKJN_CD	�FKJN_CD%TYPE
 *                <I> iGAKKAI_CD	�FGAKKAI_CD%TYPE
 *                <I> iGAKKAI_NENDO	�FGAKKAI_NENDO%TYPE
 *                <I> iTRK_EIGY_YMD		:TRK_EIGY_YMD
 * Return       �F�������ʁi0:����I���A1:�ُ�I���j
 ************************************************************************
 */
	FUNCTION INSERT_TOUJITSU(
		iREC_ID	IN	TT_SISN_KJN_GAKKAI.REC_ID%TYPE,
		iKJN_CD	IN	TT_SISN_KJN_GAKKAI.KJN_CD%TYPE,
		iGAKKAI_CD	IN	TT_SISN_KJN_GAKKAI.GAKKAI_CD%TYPE,
		iGAKKAI_NENDO	IN	TT_SISN_KJN_GAKKAI.GAKKAI_NENDO%TYPE,
		iTRK_EIGY_YMD			IN VARCHAR2,
		iIP_ADDR				IN TL_STORED_SHORI.IP%TYPE,					-- ���s�[��IP�A�h���X
		iWINDOWS_LOGIN_USER		IN TL_STORED_SHORI.WINDOWS_LOGIN_USER%TYPE, -- ���s�[��OS���[�U�[
		oROW_COUNT				OUT NUMBER,									-- �X�V����
		oOUT_ERR_INF_CSR 		OUT ERR_INF_CSR								-- �G���[���J�[�\��
	) RETURN NUMBER IS

	/************************************************************************/
	/*                              �G���[����                              */
	/************************************************************************/
	W_INDEX_N 					NUMBER(10) := 0;
	W_ERR_INF_TBL 				TYPE_ERR_INFO_TBL := TYPE_ERR_INFO_TBL();
	W_ERR_INF_RCD 				TYPE_ERR_INFO_RCD := TYPE_ERR_INFO_RCD(NULL,NULL,NULL,NULL);
	W_TRK_USER_CD				VARCHAR(3) := NULL;
	W_TRK_EIGY_YMD				VARCHAR(8) := NULL;
	W_TRK_OPE_CD				VARCHAR(10) := NULL;
	W_TRK_DATE					DATE := NULL;
	W_TRK_PGM_ID				VARCHAR(12) := NULL;

	BEGIN

		-- INSERT ���s
		INSERT INTO TT_SISN_KJN_GAKKAI
		SELECT 
			REC_ID,
			KJN_CD,
			GAKKAI_CD,
			GAKKAI_NENDO,
			DEL_FLG,
			DEL_EIGY_YMD,
			TRK_YM,
			TRK_FKT_EIGY_YMD,
			TRK_USER_CD,
			TRK_EIGY_YMD,
			UPD_USER_CD,
			UPD_EIGY_YMD,
			TRK_OPE_CD,
			TRK_DATE,
			TRK_PGM_ID,
			UPD_OPE_CD,
			UPD_DATE,
			UPD_PGM_ID
		FROM TT_RRK_KJN_GAKKAI
		WHERE SEQ = 
		(SELECT MAX(SEQ) 
		FROM TT_RRK_KJN_GAKKAI 
		WHERE REC_ID = iREC_ID
		AND KJN_CD = iKJN_CD
		AND GAKKAI_CD = iGAKKAI_CD
		AND GAKKAI_NENDO = iGAKKAI_NENDO);
		oROW_COUNT := SQL%ROWCOUNT;

		-- ���ʑ����i�o�^���j��SELECT ���s
		SELECT 
		    TRK_USER_CD,
			TRK_EIGY_YMD,
			TRK_OPE_CD,
			TRK_DATE,
			TRK_PGM_ID
		INTO
		    W_TRK_USER_CD,
			W_TRK_EIGY_YMD,
			W_TRK_OPE_CD,
			W_TRK_DATE,
			W_TRK_PGM_ID
		FROM TT_RRK_KJN_GAKKAI
		WHERE SEQ = 
		(SELECT MIN(SEQ) 
		FROM TT_RRK_KJN_GAKKAI 
		WHERE REC_ID = iREC_ID
		AND KJN_CD = iKJN_CD
		AND GAKKAI_CD = iGAKKAI_CD
		AND GAKKAI_NENDO = iGAKKAI_NENDO);

		-- ���ʑ����i�o�^���j��UPDATE ���s
		UPDATE TT_SISN_KJN_GAKKAI
		SET 
		    TRK_USER_CD = W_TRK_USER_CD,
			TRK_EIGY_YMD = W_TRK_EIGY_YMD,
			TRK_OPE_CD = W_TRK_OPE_CD,
			TRK_DATE = W_TRK_DATE,
			TRK_PGM_ID = W_TRK_PGM_ID
		WHERE REC_ID = iREC_ID
		AND KJN_CD = iKJN_CD
		AND GAKKAI_CD = iGAKKAI_CD
		AND GAKKAI_NENDO = iGAKKAI_NENDO;
		oROW_COUNT := SQL%ROWCOUNT;

		-- ����I��
		RETURN 0;

	-- ��O����
	EXCEPTION
		-- ���̑��G���[
		WHEN OTHERS THEN
			W_ERR_INF_RCD.ERR_CD 		:= TO_CHAR(SQLCODE);
			W_ERR_INF_RCD.ERR_MSG 		:= SUBSTR(SQLERRM, 0, 2000);
			W_ERR_INF_RCD.ERR_KEY_INF 	:= SUBSTR('REC_ID:' || iREC_ID || ', KJN_CD:' || iKJN_CD || ', GAKKAI_CD:' || iGAKKAI_CD || ', GAKKAI_NENDO:' || iGAKKAI_NENDO, 0, 2000);
			W_INDEX_N 					:= W_ERR_INF_TBL.COUNT + 1;
			W_ERR_INF_TBL.EXTEND;
			W_ERR_INF_TBL(W_INDEX_N) 	:= W_ERR_INF_RCD;

			OPEN oOUT_ERR_INF_CSR FOR
				SELECT * FROM TABLE(W_ERR_INF_TBL);

			RETURN 1;
		END;

END;
/
CREATE OR REPLACE PACKAGE    PKG_TT_RRK_KJN_GAKKAI_GU
/* **********************************************************
 *  Copyright(c) 2011 beyond, INTEC Inc. All rights reserved.
 * **********************************************************/
IS
	-- TT_RRK_KJN_GAKKAI%ROWTYPE��TABLE�^���`
	TYPE TT_RRK_KJN_GAKKAI_ROWS IS TABLE OF TT_RRK_KJN_GAKKAI%ROWTYPE;

	/*** �J�[�\���^ ***************************************************************/
	-- �G���[���i�[�p�J�[�\���^
	TYPE ERR_INF_CSR					IS REF CURSOR;

	/*
	************************************************************************
	*  TT_RRK_KJN_GAKKAI
	*  DELETE_TOUJITSU
	************************************************************************
	*/
	FUNCTION DELETE_TOUJITSU(
		iREC_ID	IN	TT_RRK_KJN_GAKKAI.REC_ID%TYPE,
		iKJN_CD	IN	TT_RRK_KJN_GAKKAI.KJN_CD%TYPE,
		iGAKKAI_CD	IN	TT_RRK_KJN_GAKKAI.GAKKAI_CD%TYPE,
		iGAKKAI_NENDO	IN	TT_RRK_KJN_GAKKAI.GAKKAI_NENDO%TYPE,
		iTRK_EIGY_YMD			IN VARCHAR2,
		iIP_ADDR				IN TL_STORED_SHORI.IP%TYPE,					-- ���s�[��IP�A�h���X
		iWINDOWS_LOGIN_USER		IN TL_STORED_SHORI.WINDOWS_LOGIN_USER%TYPE, -- ���s�[��OS���[�U�[
		oROW_COUNT				OUT NUMBER,									-- �X�V����
		oOUT_ERR_INF_CSR 		OUT ERR_INF_CSR								-- �G���[���J�[�\��
	) RETURN NUMBER;

END;
/

CREATE OR REPLACE PACKAGE BODY    PKG_TT_RRK_KJN_GAKKAI_GU
/* **********************************************************
 *  Copyright(c) 2011 beyond, INTEC Inc. All rights reserved.
 * **********************************************************/
IS
/*
 ************************************************************************
 * Function ID  : DELETE_TOUJITSU
 * Program Name : �����i�c�Ɠ��j�o�^���ꂽ�f�[�^�𕨗��폜����
 * Parameter    : <I> iREC_ID	�FREC_ID%TYPE
 *                <I> iKJN_CD	�FKJN_CD%TYPE
 *                <I> iGAKKAI_CD	�FGAKKAI_CD%TYPE
 *                <I> iGAKKAI_NENDO	�FGAKKAI_NENDO%TYPE
 *                <I> iTRK_EIGY_YMD		:TRK_EIGY_YMD
 * Return       �F�������ʁi0:����I���A1:�ُ�I���j
 ************************************************************************
 */
	FUNCTION DELETE_TOUJITSU(
		iREC_ID	IN	TT_RRK_KJN_GAKKAI.REC_ID%TYPE,
		iKJN_CD	IN	TT_RRK_KJN_GAKKAI.KJN_CD%TYPE,
		iGAKKAI_CD	IN	TT_RRK_KJN_GAKKAI.GAKKAI_CD%TYPE,
		iGAKKAI_NENDO	IN	TT_RRK_KJN_GAKKAI.GAKKAI_NENDO%TYPE,
		iTRK_EIGY_YMD			IN VARCHAR2,
		iIP_ADDR				IN TL_STORED_SHORI.IP%TYPE,					-- ���s�[��IP�A�h���X
		iWINDOWS_LOGIN_USER		IN TL_STORED_SHORI.WINDOWS_LOGIN_USER%TYPE, -- ���s�[��OS���[�U�[
		oROW_COUNT				OUT NUMBER,									-- �X�V����
		oOUT_ERR_INF_CSR 		OUT ERR_INF_CSR								-- �G���[���J�[�\��
	) RETURN NUMBER IS

	/************************************************************************/
	/*                              �G���[����                              */
	/************************************************************************/
	W_INDEX_N 					NUMBER(10) := 0;
	W_ERR_INF_TBL 				TYPE_ERR_INFO_TBL := TYPE_ERR_INFO_TBL();
	W_ERR_INF_RCD 				TYPE_ERR_INFO_RCD := TYPE_ERR_INFO_RCD(NULL,NULL,NULL,NULL);

	BEGIN

		-- DELETE ���s
		DELETE TT_RRK_KJN_GAKKAI
		WHERE REC_ID = iREC_ID
		AND KJN_CD = iKJN_CD
		AND GAKKAI_CD = iGAKKAI_CD
		AND GAKKAI_NENDO = iGAKKAI_NENDO
		AND TRK_FKT_EIGY_YMD = iTRK_EIGY_YMD;
		oROW_COUNT := SQL%ROWCOUNT;

		-- ����I��
		RETURN 0;

	-- ��O����
	EXCEPTION
		-- ���̑��G���[
		WHEN OTHERS THEN
			W_ERR_INF_RCD.ERR_CD 		:= TO_CHAR(SQLCODE);
			W_ERR_INF_RCD.ERR_MSG 		:= SUBSTR(SQLERRM, 0, 2000);
			W_ERR_INF_RCD.ERR_KEY_INF 	:= SUBSTR('REC_ID:' || iREC_ID || ', KJN_CD:' || iKJN_CD || ', GAKKAI_CD:' || iGAKKAI_CD || ', GAKKAI_NENDO:' || iGAKKAI_NENDO, 0, 2000);
			W_INDEX_N 					:= W_ERR_INF_TBL.COUNT + 1;
			W_ERR_INF_TBL.EXTEND;
			W_ERR_INF_TBL(W_INDEX_N) 	:= W_ERR_INF_RCD;

			OPEN oOUT_ERR_INF_CSR FOR
				SELECT * FROM TABLE(W_ERR_INF_TBL);

			RETURN 1;
		END;

END;
/
CREATE OR REPLACE PACKAGE    PKG_TT_SISN_KJN_KINMUSAKI_GU
/* **********************************************************
 *  Copyright(c) 2011 beyond, INTEC Inc. All rights reserved.
 * **********************************************************/
IS
	-- TT_SISN_KJN_KINMUSAKI%ROWTYPE��TABLE�^���`
	TYPE TT_SISN_KJN_KINMUSAKI_ROWS IS TABLE OF TT_SISN_KJN_KINMUSAKI%ROWTYPE;

	/*** �J�[�\���^ ***************************************************************/
	-- �G���[���i�[�p�J�[�\���^
	TYPE ERR_INF_CSR					IS REF CURSOR;

	/*
	************************************************************************
	*  TT_SISN_KJN_KINMUSAKI
	*  DELETE_TOUJITSU
	************************************************************************
	*/
	FUNCTION DELETE_TOUJITSU(
		iREC_ID	IN	TT_SISN_KJN_KINMUSAKI.REC_ID%TYPE,
		iKJN_CD	IN	TT_SISN_KJN_KINMUSAKI.KJN_CD%TYPE,
		iKINMUSAKI_REC_ID	IN	TT_SISN_KJN_KINMUSAKI.KINMUSAKI_REC_ID%TYPE,
		iKINMUSAKI_SHI_CD	IN	TT_SISN_KJN_KINMUSAKI.KINMUSAKI_SHI_CD%TYPE,
		iTRK_EIGY_YMD			IN VARCHAR2,
		iIP_ADDR				IN TL_STORED_SHORI.IP%TYPE,					-- ���s�[��IP�A�h���X
		iWINDOWS_LOGIN_USER		IN TL_STORED_SHORI.WINDOWS_LOGIN_USER%TYPE, -- ���s�[��OS���[�U�[
		oROW_COUNT				OUT NUMBER,									-- �X�V����
		oOUT_ERR_INF_CSR 		OUT ERR_INF_CSR								-- �G���[���J�[�\��
	) RETURN NUMBER;

	/*
	************************************************************************
	*  TT_SISN_KJN_KINMUSAKI
	*  INSERT_TOUJITSU
	************************************************************************
	*/
	FUNCTION INSERT_TOUJITSU(
		iREC_ID	IN	TT_SISN_KJN_KINMUSAKI.REC_ID%TYPE,
		iKJN_CD	IN	TT_SISN_KJN_KINMUSAKI.KJN_CD%TYPE,
		iKINMUSAKI_REC_ID	IN	TT_SISN_KJN_KINMUSAKI.KINMUSAKI_REC_ID%TYPE,
		iKINMUSAKI_SHI_CD	IN	TT_SISN_KJN_KINMUSAKI.KINMUSAKI_SHI_CD%TYPE,
		iTRK_EIGY_YMD			IN VARCHAR2,
		iIP_ADDR				IN TL_STORED_SHORI.IP%TYPE,					-- ���s�[��IP�A�h���X
		iWINDOWS_LOGIN_USER		IN TL_STORED_SHORI.WINDOWS_LOGIN_USER%TYPE, -- ���s�[��OS���[�U�[
		oROW_COUNT				OUT NUMBER,									-- �X�V����
		oOUT_ERR_INF_CSR 		OUT ERR_INF_CSR								-- �G���[���J�[�\��
	) RETURN NUMBER;

	/*
	************************************************************************
	*  TT_SISN_KJN_KINMUSAKI
	*  UPDATE_TOUJITSU
	************************************************************************
	*/
	FUNCTION UPDATE_TOUJITSU(
		iREC_ID	IN	TT_SISN_KJN_KINMUSAKI.REC_ID%TYPE,
		iKJN_CD	IN	TT_SISN_KJN_KINMUSAKI.KJN_CD%TYPE,
		iKINMUSAKI_REC_ID	IN	TT_SISN_KJN_KINMUSAKI.KINMUSAKI_REC_ID%TYPE,
		iKINMUSAKI_SHI_CD	IN	TT_SISN_KJN_KINMUSAKI.KINMUSAKI_SHI_CD%TYPE,
		iTRK_EIGY_YMD			IN VARCHAR2,
		iIP_ADDR				IN TL_STORED_SHORI.IP%TYPE,					-- ���s�[��IP�A�h���X
		iWINDOWS_LOGIN_USER		IN TL_STORED_SHORI.WINDOWS_LOGIN_USER%TYPE, -- ���s�[��OS���[�U�[
		iKENSAKU_KMK			IN VARCHAR2,								-- �����p����
		oROW_COUNT				OUT NUMBER,									-- �X�V����
		oOUT_ERR_INF_CSR 		OUT ERR_INF_CSR								-- �G���[���J�[�\��
	) RETURN NUMBER;

END;
/

CREATE OR REPLACE PACKAGE BODY    PKG_TT_SISN_KJN_KINMUSAKI_GU
/* **********************************************************
 *  Copyright(c) 2011 beyond, INTEC Inc. All rights reserved.
 * **********************************************************/
IS
/*
 ************************************************************************
 * Function ID  : DELETE_TOUJITSU
 * Program Name : �����i�c�Ɠ��j�o�^���ꂽ�f�[�^�𕨗��폜����
 * Parameter    : <I> iREC_ID	�FREC_ID%TYPE
 *                <I> iKJN_CD	�FKJN_CD%TYPE
 *                <I> iKINMUSAKI_REC_ID	�FKINMUSAKI_REC_ID%TYPE
 *                <I> iKINMUSAKI_SHI_CD	�FKINMUSAKI_SHI_CD%TYPE
 *                <I> iTRK_EIGY_YMD		:TRK_EIGY_YMD
 * Return       �F�������ʁi0:����I���A1:�ُ�I���j
 ************************************************************************
 */
	FUNCTION DELETE_TOUJITSU(
		iREC_ID	IN	TT_SISN_KJN_KINMUSAKI.REC_ID%TYPE,
		iKJN_CD	IN	TT_SISN_KJN_KINMUSAKI.KJN_CD%TYPE,
		iKINMUSAKI_REC_ID	IN	TT_SISN_KJN_KINMUSAKI.KINMUSAKI_REC_ID%TYPE,
		iKINMUSAKI_SHI_CD	IN	TT_SISN_KJN_KINMUSAKI.KINMUSAKI_SHI_CD%TYPE,
		iTRK_EIGY_YMD			IN VARCHAR2,
		iIP_ADDR				IN TL_STORED_SHORI.IP%TYPE,					-- ���s�[��IP�A�h���X
		iWINDOWS_LOGIN_USER		IN TL_STORED_SHORI.WINDOWS_LOGIN_USER%TYPE, -- ���s�[��OS���[�U�[
		oROW_COUNT				OUT NUMBER,									-- �X�V����
		oOUT_ERR_INF_CSR 		OUT ERR_INF_CSR								-- �G���[���J�[�\��
	) RETURN NUMBER IS

	/************************************************************************/
	/*                              �G���[����                              */
	/************************************************************************/
	W_INDEX_N 					NUMBER(10) := 0;
	W_ERR_INF_TBL 				TYPE_ERR_INFO_TBL := TYPE_ERR_INFO_TBL();
	W_ERR_INF_RCD 				TYPE_ERR_INFO_RCD := TYPE_ERR_INFO_RCD(NULL,NULL,NULL,NULL);

	BEGIN

		-- DELETE ���s
		DELETE TT_SISN_KJN_KINMUSAKI
		WHERE REC_ID = iREC_ID
		AND KJN_CD = iKJN_CD
		AND KINMUSAKI_REC_ID = iKINMUSAKI_REC_ID
		AND KINMUSAKI_SHI_CD = iKINMUSAKI_SHI_CD
		AND TRK_FKT_EIGY_YMD = iTRK_EIGY_YMD;
		oROW_COUNT := SQL%ROWCOUNT;

		-- ����I��
		RETURN 0;

	-- ��O����
	EXCEPTION
		-- ���̑��G���[
		WHEN OTHERS THEN
			W_ERR_INF_RCD.ERR_CD 		:= TO_CHAR(SQLCODE);
			W_ERR_INF_RCD.ERR_MSG 		:= SUBSTR(SQLERRM, 0, 2000);
			W_ERR_INF_RCD.ERR_KEY_INF 	:= SUBSTR('REC_ID:' || iREC_ID || ', KJN_CD:' || iKJN_CD || ', KINMUSAKI_REC_ID:' || iKINMUSAKI_REC_ID || ', KINMUSAKI_SHI_CD:' || iKINMUSAKI_SHI_CD, 0, 2000);
			W_INDEX_N 					:= W_ERR_INF_TBL.COUNT + 1;
			W_ERR_INF_TBL.EXTEND;
			W_ERR_INF_TBL(W_INDEX_N) 	:= W_ERR_INF_RCD;

			OPEN oOUT_ERR_INF_CSR FOR
				SELECT * FROM TABLE(W_ERR_INF_TBL);

			RETURN 1;
		END;

/*
 ************************************************************************
 * Function ID  : INSERT_TOUJITSU
 * Program Name : �����폜�̍ۂɗ������R�[�h������΍ŐV�e�[�u���ɔ��f����
 * Parameter    : <I> iREC_ID	�FREC_ID%TYPE
 *                <I> iKJN_CD	�FKJN_CD%TYPE
 *                <I> iKINMUSAKI_REC_ID	�FKINMUSAKI_REC_ID%TYPE
 *                <I> iKINMUSAKI_SHI_CD	�FKINMUSAKI_SHI_CD%TYPE
 *                <I> iTRK_EIGY_YMD		:TRK_EIGY_YMD
 * Return       �F�������ʁi0:����I���A1:�ُ�I���j
 ************************************************************************
 */
	FUNCTION INSERT_TOUJITSU(
		iREC_ID	IN	TT_SISN_KJN_KINMUSAKI.REC_ID%TYPE,
		iKJN_CD	IN	TT_SISN_KJN_KINMUSAKI.KJN_CD%TYPE,
		iKINMUSAKI_REC_ID	IN	TT_SISN_KJN_KINMUSAKI.KINMUSAKI_REC_ID%TYPE,
		iKINMUSAKI_SHI_CD	IN	TT_SISN_KJN_KINMUSAKI.KINMUSAKI_SHI_CD%TYPE,
		iTRK_EIGY_YMD			IN VARCHAR2,
		iIP_ADDR				IN TL_STORED_SHORI.IP%TYPE,					-- ���s�[��IP�A�h���X
		iWINDOWS_LOGIN_USER		IN TL_STORED_SHORI.WINDOWS_LOGIN_USER%TYPE, -- ���s�[��OS���[�U�[
		oROW_COUNT				OUT NUMBER,									-- �X�V����
		oOUT_ERR_INF_CSR 		OUT ERR_INF_CSR								-- �G���[���J�[�\��
	) RETURN NUMBER IS

	/************************************************************************/
	/*                              �G���[����                              */
	/************************************************************************/
	W_INDEX_N 					NUMBER(10) := 0;
	W_ERR_INF_TBL 				TYPE_ERR_INFO_TBL := TYPE_ERR_INFO_TBL();
	W_ERR_INF_RCD 				TYPE_ERR_INFO_RCD := TYPE_ERR_INFO_RCD(NULL,NULL,NULL,NULL);

	BEGIN

		-- INSERT ���s
		INSERT INTO TT_SISN_KJN_KINMUSAKI
		SELECT 
			REC_ID,
			KJN_CD,
			KINMUSAKI_REC_ID,
			KINMUSAKI_SHI_CD,
			TAISHOKU_FLG,
			TAISHOKU_EIGY_YMD,
			DAIHYO_FLG,
			SZKBUKA_CD,
			'',
			NYURYOKU_SZKBUKA_NM,
			NYURYOKU_SZKBUKA_NM_KANA,
			YAKUSHOKU_CD,
			SHOKUI_CD,
			KINMUSAKI_DM_FUKA_FLG,
			KINMUSAKI_KKNN_YMD,
			KINMUSAKI_KKNN_USER_CD,
			KINMUSAKI_KKNN_OPE_CD,
			JOHO_YMD,
			TRK_FKT_EIGY_YMD,
			TRK_USER_CD,
			TRK_EIGY_YMD,
			UPD_USER_CD,
			UPD_EIGY_YMD,
			TRK_OPE_CD,
			TRK_DATE,
			TRK_PGM_ID,
			UPD_OPE_CD,
			UPD_DATE,
			UPD_PGM_ID
		FROM TT_RRK_KJN_KINMUSAKI
		WHERE SEQ = 
		(SELECT MAX(SEQ) 
		FROM TT_RRK_KJN_KINMUSAKI 
		WHERE REC_ID = iREC_ID
		AND KJN_CD = iKJN_CD
		AND KINMUSAKI_REC_ID = iKINMUSAKI_REC_ID
		AND KINMUSAKI_SHI_CD = iKINMUSAKI_SHI_CD);
		oROW_COUNT := SQL%ROWCOUNT;

		-- ����I��
		RETURN 0;

	-- ��O����
	EXCEPTION
		-- ���̑��G���[
		WHEN OTHERS THEN
			W_ERR_INF_RCD.ERR_CD 		:= TO_CHAR(SQLCODE);
			W_ERR_INF_RCD.ERR_MSG 		:= SUBSTR(SQLERRM, 0, 2000);
			W_ERR_INF_RCD.ERR_KEY_INF 	:= SUBSTR('REC_ID:' || iREC_ID || ', KJN_CD:' || iKJN_CD || ', KINMUSAKI_REC_ID:' || iKINMUSAKI_REC_ID || ', KINMUSAKI_SHI_CD:' || iKINMUSAKI_SHI_CD, 0, 2000);
			W_INDEX_N 					:= W_ERR_INF_TBL.COUNT + 1;
			W_ERR_INF_TBL.EXTEND;
			W_ERR_INF_TBL(W_INDEX_N) 	:= W_ERR_INF_RCD;

			OPEN oOUT_ERR_INF_CSR FOR
				SELECT * FROM TABLE(W_ERR_INF_TBL);

			RETURN 1;
		END;

/*
 ************************************************************************
 * Function ID  : UPDATE_TOUJITSU
 * Program Name : �����폜�̍ۂɗ������R�[�h������΍ŐV�e�[�u���ɔ��f����(�������ځA�o�^�����̍X�V�j
 * Parameter    : <I> iREC_ID	�FREC_ID%TYPE
 *                <I> iKJN_CD	�FKJN_CD%TYPE
 *                <I> iKINMUSAKI_REC_ID	�FKINMUSAKI_REC_ID%TYPE
 *                <I> iKINMUSAKI_SHI_CD	�FKINMUSAKI_SHI_CD%TYPE
 *                <I> iTRK_EIGY_YMD		:TRK_EIGY_YMD
 * Return       �F�������ʁi0:����I���A1:�ُ�I���j
 ************************************************************************
 */
	FUNCTION UPDATE_TOUJITSU(
		iREC_ID	IN	TT_SISN_KJN_KINMUSAKI.REC_ID%TYPE,
		iKJN_CD	IN	TT_SISN_KJN_KINMUSAKI.KJN_CD%TYPE,
		iKINMUSAKI_REC_ID	IN	TT_SISN_KJN_KINMUSAKI.KINMUSAKI_REC_ID%TYPE,
		iKINMUSAKI_SHI_CD	IN	TT_SISN_KJN_KINMUSAKI.KINMUSAKI_SHI_CD%TYPE,
		iTRK_EIGY_YMD			IN VARCHAR2,
		iIP_ADDR				IN TL_STORED_SHORI.IP%TYPE,					-- ���s�[��IP�A�h���X
		iWINDOWS_LOGIN_USER		IN TL_STORED_SHORI.WINDOWS_LOGIN_USER%TYPE, -- ���s�[��OS���[�U�[
		iKENSAKU_KMK			IN VARCHAR2,								-- �����p���� 
		oROW_COUNT				OUT NUMBER,									-- �X�V����
		oOUT_ERR_INF_CSR 		OUT ERR_INF_CSR								-- �G���[���J�[�\��
	) RETURN NUMBER IS

	/************************************************************************/
	/*                              �G���[����                              */
	/************************************************************************/
	W_INDEX_N 					NUMBER(10) := 0;
	W_ERR_INF_TBL 				TYPE_ERR_INFO_TBL := TYPE_ERR_INFO_TBL();
	W_ERR_INF_RCD 				TYPE_ERR_INFO_RCD := TYPE_ERR_INFO_RCD(NULL,NULL,NULL,NULL);
	W_TRK_USER_CD				VARCHAR(3) := NULL;
	W_TRK_EIGY_YMD				VARCHAR(8) := NULL;
	W_TRK_OPE_CD				VARCHAR(10) := NULL;
	W_TRK_DATE					DATE := NULL;
	W_TRK_PGM_ID				VARCHAR(12) := NULL;

	BEGIN

		-- ���ʑ����i�o�^���j��SELECT ���s
		SELECT 
		    TRK_USER_CD,
			TRK_EIGY_YMD,
			TRK_OPE_CD,
			TRK_DATE,
			TRK_PGM_ID
		INTO
		    W_TRK_USER_CD,
			W_TRK_EIGY_YMD,
			W_TRK_OPE_CD,
			W_TRK_DATE,
			W_TRK_PGM_ID
		FROM TT_RRK_KJN_KINMUSAKI
		WHERE SEQ = 
		(SELECT MIN(SEQ) 
		FROM TT_RRK_KJN_KINMUSAKI 
		WHERE REC_ID = iREC_ID
		AND KJN_CD = iKJN_CD
		AND KINMUSAKI_REC_ID = iKINMUSAKI_REC_ID
		AND KINMUSAKI_SHI_CD = iKINMUSAKI_SHI_CD);

		-- ���ʑ����i�o�^���j��UPDATE ���s
		UPDATE TT_SISN_KJN_KINMUSAKI
		SET 
		    TRK_USER_CD = W_TRK_USER_CD,
			TRK_EIGY_YMD = W_TRK_EIGY_YMD,
			TRK_OPE_CD = W_TRK_OPE_CD,
			TRK_DATE = W_TRK_DATE,
			TRK_PGM_ID = W_TRK_PGM_ID
			,KENSAKU_SZKBUKA_BNRI_CD = iKENSAKU_KMK
		WHERE REC_ID = iREC_ID
		AND KJN_CD = iKJN_CD
		AND KINMUSAKI_REC_ID = iKINMUSAKI_REC_ID
		AND KINMUSAKI_SHI_CD = iKINMUSAKI_SHI_CD;
		oROW_COUNT := SQL%ROWCOUNT;

		-- ����I��
		RETURN 0;

	-- ��O����
	EXCEPTION
		-- ���̑��G���[
		WHEN OTHERS THEN
			W_ERR_INF_RCD.ERR_CD 		:= TO_CHAR(SQLCODE);
			W_ERR_INF_RCD.ERR_MSG 		:= SUBSTR(SQLERRM, 0, 2000);
			W_ERR_INF_RCD.ERR_KEY_INF 	:= SUBSTR('REC_ID:' || iREC_ID || ', KJN_CD:' || iKJN_CD || ', KINMUSAKI_REC_ID:' || iKINMUSAKI_REC_ID || ', KINMUSAKI_SHI_CD:' || iKINMUSAKI_SHI_CD, 0, 2000);
			W_INDEX_N 					:= W_ERR_INF_TBL.COUNT + 1;
			W_ERR_INF_TBL.EXTEND;
			W_ERR_INF_TBL(W_INDEX_N) 	:= W_ERR_INF_RCD;

			OPEN oOUT_ERR_INF_CSR FOR
				SELECT * FROM TABLE(W_ERR_INF_TBL);

			RETURN 1;
		END;


END;
/
CREATE OR REPLACE PACKAGE    PKG_TT_RRK_KJN_KINMUSAKI_GU
/* **********************************************************
 *  Copyright(c) 2011 beyond, INTEC Inc. All rights reserved.
 * **********************************************************/
IS
	-- TT_RRK_KJN_KINMUSAKI%ROWTYPE��TABLE�^���`
	TYPE TT_RRK_KJN_KINMUSAKI_ROWS IS TABLE OF TT_RRK_KJN_KINMUSAKI%ROWTYPE;

	/*** �J�[�\���^ ***************************************************************/
	-- �G���[���i�[�p�J�[�\���^
	TYPE ERR_INF_CSR					IS REF CURSOR;

	/*
	************************************************************************
	*  TT_RRK_KJN_KINMUSAKI
	*  DELETE_TOUJITSU
	************************************************************************
	*/
	FUNCTION DELETE_TOUJITSU(
		iREC_ID	IN	TT_RRK_KJN_KINMUSAKI.REC_ID%TYPE,
		iKJN_CD	IN	TT_RRK_KJN_KINMUSAKI.KJN_CD%TYPE,
		iKINMUSAKI_REC_ID	IN	TT_RRK_KJN_KINMUSAKI.KINMUSAKI_REC_ID%TYPE,
		iKINMUSAKI_SHI_CD	IN	TT_RRK_KJN_KINMUSAKI.KINMUSAKI_SHI_CD%TYPE,
		iTRK_EIGY_YMD			IN VARCHAR2,
		iIP_ADDR				IN TL_STORED_SHORI.IP%TYPE,					-- ���s�[��IP�A�h���X
		iWINDOWS_LOGIN_USER		IN TL_STORED_SHORI.WINDOWS_LOGIN_USER%TYPE, -- ���s�[��OS���[�U�[
		oROW_COUNT				OUT NUMBER,									-- �X�V����
		oOUT_ERR_INF_CSR 		OUT ERR_INF_CSR								-- �G���[���J�[�\��
	) RETURN NUMBER;

END;
/

CREATE OR REPLACE PACKAGE BODY    PKG_TT_RRK_KJN_KINMUSAKI_GU
/* **********************************************************
 *  Copyright(c) 2011 beyond, INTEC Inc. All rights reserved.
 * **********************************************************/
IS
/*
 ************************************************************************
 * Function ID  : DELETE_TOUJITSU
 * Program Name : �����i�c�Ɠ��j�o�^���ꂽ�f�[�^�𕨗��폜����
 * Parameter    : <I> iREC_ID	�FREC_ID%TYPE
 *                <I> iKJN_CD	�FKJN_CD%TYPE
 *                <I> iKINMUSAKI_REC_ID	�FKINMUSAKI_REC_ID%TYPE
 *                <I> iKINMUSAKI_SHI_CD	�FKINMUSAKI_SHI_CD%TYPE
 *                <I> iTRK_EIGY_YMD		:TRK_EIGY_YMD
 * Return       �F�������ʁi0:����I���A1:�ُ�I���j
 ************************************************************************
 */
	FUNCTION DELETE_TOUJITSU(
		iREC_ID	IN	TT_RRK_KJN_KINMUSAKI.REC_ID%TYPE,
		iKJN_CD	IN	TT_RRK_KJN_KINMUSAKI.KJN_CD%TYPE,
		iKINMUSAKI_REC_ID	IN	TT_RRK_KJN_KINMUSAKI.KINMUSAKI_REC_ID%TYPE,
		iKINMUSAKI_SHI_CD	IN	TT_RRK_KJN_KINMUSAKI.KINMUSAKI_SHI_CD%TYPE,
		iTRK_EIGY_YMD			IN VARCHAR2,
		iIP_ADDR				IN TL_STORED_SHORI.IP%TYPE,					-- ���s�[��IP�A�h���X
		iWINDOWS_LOGIN_USER		IN TL_STORED_SHORI.WINDOWS_LOGIN_USER%TYPE, -- ���s�[��OS���[�U�[
		oROW_COUNT				OUT NUMBER,									-- �X�V����
		oOUT_ERR_INF_CSR 		OUT ERR_INF_CSR								-- �G���[���J�[�\��
	) RETURN NUMBER IS

	/************************************************************************/
	/*                              �G���[����                              */
	/************************************************************************/
	W_INDEX_N 					NUMBER(10) := 0;
	W_ERR_INF_TBL 				TYPE_ERR_INFO_TBL := TYPE_ERR_INFO_TBL();
	W_ERR_INF_RCD 				TYPE_ERR_INFO_RCD := TYPE_ERR_INFO_RCD(NULL,NULL,NULL,NULL);

	BEGIN

		-- DELETE ���s
		DELETE TT_RRK_KJN_KINMUSAKI
		WHERE REC_ID = iREC_ID
		AND KJN_CD = iKJN_CD
		AND KINMUSAKI_REC_ID = iKINMUSAKI_REC_ID
		AND KINMUSAKI_SHI_CD = iKINMUSAKI_SHI_CD
		AND TRK_FKT_EIGY_YMD = iTRK_EIGY_YMD;
		oROW_COUNT := SQL%ROWCOUNT;

		-- ����I��
		RETURN 0;

	-- ��O����
	EXCEPTION
		-- ���̑��G���[
		WHEN OTHERS THEN
			W_ERR_INF_RCD.ERR_CD 		:= TO_CHAR(SQLCODE);
			W_ERR_INF_RCD.ERR_MSG 		:= SUBSTR(SQLERRM, 0, 2000);
			W_ERR_INF_RCD.ERR_KEY_INF 	:= SUBSTR('REC_ID:' || iREC_ID || ', KJN_CD:' || iKJN_CD || ', KINMUSAKI_REC_ID:' || iKINMUSAKI_REC_ID || ', KINMUSAKI_SHI_CD:' || iKINMUSAKI_SHI_CD, 0, 2000);
			W_INDEX_N 					:= W_ERR_INF_TBL.COUNT + 1;
			W_ERR_INF_TBL.EXTEND;
			W_ERR_INF_TBL(W_INDEX_N) 	:= W_ERR_INF_RCD;

			OPEN oOUT_ERR_INF_CSR FOR
				SELECT * FROM TABLE(W_ERR_INF_TBL);

			RETURN 1;
		END;

END;
/
CREATE OR REPLACE PACKAGE    PKG_TT_SISN_KJN_SENMONI_GU
/* **********************************************************
 *  Copyright(c) 2011 beyond, INTEC Inc. All rights reserved.
 * **********************************************************/
IS
	-- TT_SISN_KJN_SENMONI%ROWTYPE��TABLE�^���`
	TYPE TT_SISN_KJN_SENMONI_ROWS IS TABLE OF TT_SISN_KJN_SENMONI%ROWTYPE;

	/*** �J�[�\���^ ***************************************************************/
	-- �G���[���i�[�p�J�[�\���^
	TYPE ERR_INF_CSR					IS REF CURSOR;

	/*
	************************************************************************
	*  TT_SISN_KJN_SENMONI
	*  DELETE_TOUJITSU
	************************************************************************
	*/
	FUNCTION DELETE_TOUJITSU(
		iREC_ID	IN	TT_SISN_KJN_SENMONI.REC_ID%TYPE,
		iKJN_CD	IN	TT_SISN_KJN_SENMONI.KJN_CD%TYPE,
		iSENMONI_CD	IN	TT_SISN_KJN_SENMONI.SENMONI_CD%TYPE,
		iTRK_EIGY_YMD			IN VARCHAR2,
		iIP_ADDR				IN TL_STORED_SHORI.IP%TYPE,					-- ���s�[��IP�A�h���X
		iWINDOWS_LOGIN_USER		IN TL_STORED_SHORI.WINDOWS_LOGIN_USER%TYPE, -- ���s�[��OS���[�U�[
		oROW_COUNT				OUT NUMBER,									-- �X�V����
		oOUT_ERR_INF_CSR 		OUT ERR_INF_CSR								-- �G���[���J�[�\��
	) RETURN NUMBER;

	/*
	************************************************************************
	*  TT_SISN_KJN_SENMONI
	*  INSERT_TOUJITSU
	************************************************************************
	*/
	FUNCTION INSERT_TOUJITSU(
		iREC_ID	IN	TT_SISN_KJN_SENMONI.REC_ID%TYPE,
		iKJN_CD	IN	TT_SISN_KJN_SENMONI.KJN_CD%TYPE,
		iSENMONI_CD	IN	TT_SISN_KJN_SENMONI.SENMONI_CD%TYPE,
		iTRK_EIGY_YMD			IN VARCHAR2,
		iIP_ADDR				IN TL_STORED_SHORI.IP%TYPE,					-- ���s�[��IP�A�h���X
		iWINDOWS_LOGIN_USER		IN TL_STORED_SHORI.WINDOWS_LOGIN_USER%TYPE, -- ���s�[��OS���[�U�[
		oROW_COUNT				OUT NUMBER,									-- �X�V����
		oOUT_ERR_INF_CSR 		OUT ERR_INF_CSR								-- �G���[���J�[�\��
	) RETURN NUMBER;

END;
/

CREATE OR REPLACE PACKAGE BODY    PKG_TT_SISN_KJN_SENMONI_GU
/* **********************************************************
 *  Copyright(c) 2011 beyond, INTEC Inc. All rights reserved.
 * **********************************************************/
IS
/*
 ************************************************************************
 * Function ID  : DELETE_TOUJITSU
 * Program Name : �����i�c�Ɠ��j�o�^���ꂽ�f�[�^�𕨗��폜����
 * Parameter    : <I> iREC_ID	�FREC_ID%TYPE
 *                <I> iKJN_CD	�FKJN_CD%TYPE
 *                <I> iSENMONI_CD	�FSENMONI_CD%TYPE
 *                <I> iTRK_EIGY_YMD		:TRK_EIGY_YMD
 * Return       �F�������ʁi0:����I���A1:�ُ�I���j
 ************************************************************************
 */
	FUNCTION DELETE_TOUJITSU(
		iREC_ID	IN	TT_SISN_KJN_SENMONI.REC_ID%TYPE,
		iKJN_CD	IN	TT_SISN_KJN_SENMONI.KJN_CD%TYPE,
		iSENMONI_CD	IN	TT_SISN_KJN_SENMONI.SENMONI_CD%TYPE,
		iTRK_EIGY_YMD			IN VARCHAR2,
		iIP_ADDR				IN TL_STORED_SHORI.IP%TYPE,					-- ���s�[��IP�A�h���X
		iWINDOWS_LOGIN_USER		IN TL_STORED_SHORI.WINDOWS_LOGIN_USER%TYPE, -- ���s�[��OS���[�U�[
		oROW_COUNT				OUT NUMBER,									-- �X�V����
		oOUT_ERR_INF_CSR 		OUT ERR_INF_CSR								-- �G���[���J�[�\��
	) RETURN NUMBER IS

	/************************************************************************/
	/*                              �G���[����                              */
	/************************************************************************/
	W_INDEX_N 					NUMBER(10) := 0;
	W_ERR_INF_TBL 				TYPE_ERR_INFO_TBL := TYPE_ERR_INFO_TBL();
	W_ERR_INF_RCD 				TYPE_ERR_INFO_RCD := TYPE_ERR_INFO_RCD(NULL,NULL,NULL,NULL);

	BEGIN

		-- DELETE ���s
		DELETE TT_SISN_KJN_SENMONI
		WHERE REC_ID = iREC_ID
		AND KJN_CD = iKJN_CD
		AND SENMONI_CD = iSENMONI_CD
		AND TRK_FKT_EIGY_YMD = iTRK_EIGY_YMD;
		oROW_COUNT := SQL%ROWCOUNT;

		-- ����I��
		RETURN 0;

	-- ��O����
	EXCEPTION
		-- ���̑��G���[
		WHEN OTHERS THEN
			W_ERR_INF_RCD.ERR_CD 		:= TO_CHAR(SQLCODE);
			W_ERR_INF_RCD.ERR_MSG 		:= SUBSTR(SQLERRM, 0, 2000);
			W_ERR_INF_RCD.ERR_KEY_INF 	:= SUBSTR('REC_ID:' || iREC_ID || ', KJN_CD:' || iKJN_CD || ', SENMONI_CD:' || iSENMONI_CD, 0, 2000);
			W_INDEX_N 					:= W_ERR_INF_TBL.COUNT + 1;
			W_ERR_INF_TBL.EXTEND;
			W_ERR_INF_TBL(W_INDEX_N) 	:= W_ERR_INF_RCD;

			OPEN oOUT_ERR_INF_CSR FOR
				SELECT * FROM TABLE(W_ERR_INF_TBL);

			RETURN 1;
		END;

/*
 ************************************************************************
 * Function ID  : INSERT_TOUJITSU
 * Program Name : �����폜�̍ۂɗ������R�[�h������΍ŐV�e�[�u���ɔ��f����
 * Parameter    : <I> iREC_ID	�FREC_ID%TYPE
 *                <I> iKJN_CD	�FKJN_CD%TYPE
 *                <I> iSENMONI_CD	�FSENMONI_CD%TYPE
 *                <I> iTRK_EIGY_YMD		:TRK_EIGY_YMD
 * Return       �F�������ʁi0:����I���A1:�ُ�I���j
 ************************************************************************
 */
	FUNCTION INSERT_TOUJITSU(
		iREC_ID	IN	TT_SISN_KJN_SENMONI.REC_ID%TYPE,
		iKJN_CD	IN	TT_SISN_KJN_SENMONI.KJN_CD%TYPE,
		iSENMONI_CD	IN	TT_SISN_KJN_SENMONI.SENMONI_CD%TYPE,
		iTRK_EIGY_YMD			IN VARCHAR2,
		iIP_ADDR				IN TL_STORED_SHORI.IP%TYPE,					-- ���s�[��IP�A�h���X
		iWINDOWS_LOGIN_USER		IN TL_STORED_SHORI.WINDOWS_LOGIN_USER%TYPE, -- ���s�[��OS���[�U�[
		oROW_COUNT				OUT NUMBER,									-- �X�V����
		oOUT_ERR_INF_CSR 		OUT ERR_INF_CSR								-- �G���[���J�[�\��
	) RETURN NUMBER IS

	/************************************************************************/
	/*                              �G���[����                              */
	/************************************************************************/
	W_INDEX_N 					NUMBER(10) := 0;
	W_ERR_INF_TBL 				TYPE_ERR_INFO_TBL := TYPE_ERR_INFO_TBL();
	W_ERR_INF_RCD 				TYPE_ERR_INFO_RCD := TYPE_ERR_INFO_RCD(NULL,NULL,NULL,NULL);
	W_TRK_USER_CD				VARCHAR(3) := NULL;
	W_TRK_EIGY_YMD				VARCHAR(8) := NULL;
	W_TRK_OPE_CD				VARCHAR(10) := NULL;
	W_TRK_DATE					DATE := NULL;
	W_TRK_PGM_ID				VARCHAR(12) := NULL;

	BEGIN

		-- INSERT ���s
		INSERT INTO TT_SISN_KJN_SENMONI
		SELECT 
			REC_ID,
			KJN_CD,
			SENMONI_CD,
			SENMONI_FLG,
			SENMONI_KEISAI_YMD,
			NINTEII_FLG,
			NINTEII_KEISAI_YMD,
			SHIDOI_FLG,
			SHIDOI_KEISAI_YMD,
			SOSHITSU_FLG,
			SOSHITSU_YMD,
			TRK_FKT_EIGY_YMD,
			TRK_USER_CD,
			TRK_EIGY_YMD,
			UPD_USER_CD,
			UPD_EIGY_YMD,
			TRK_OPE_CD,
			TRK_DATE,
			TRK_PGM_ID,
			UPD_OPE_CD,
			UPD_DATE,
			UPD_PGM_ID
		FROM TT_RRK_KJN_SENMONI
		WHERE SEQ = 
		(SELECT MAX(SEQ) 
		FROM TT_RRK_KJN_SENMONI 
		WHERE REC_ID = iREC_ID
		AND KJN_CD = iKJN_CD
		AND SENMONI_CD = iSENMONI_CD);
		oROW_COUNT := SQL%ROWCOUNT;

		-- ���ʑ����i�o�^���j��SELECT ���s
		SELECT 
		    TRK_USER_CD,
			TRK_EIGY_YMD,
			TRK_OPE_CD,
			TRK_DATE,
			TRK_PGM_ID
		INTO
		    W_TRK_USER_CD,
			W_TRK_EIGY_YMD,
			W_TRK_OPE_CD,
			W_TRK_DATE,
			W_TRK_PGM_ID
		FROM TT_RRK_KJN_SENMONI
		WHERE SEQ = 
		(SELECT MIN(SEQ) 
		FROM TT_RRK_KJN_SENMONI 
		WHERE REC_ID = iREC_ID
		AND KJN_CD = iKJN_CD
		AND SENMONI_CD = iSENMONI_CD);

		-- ���ʑ����i�o�^���j��UPDATE ���s
		UPDATE TT_SISN_KJN_SENMONI
		SET 
		    TRK_USER_CD = W_TRK_USER_CD,
			TRK_EIGY_YMD = W_TRK_EIGY_YMD,
			TRK_OPE_CD = W_TRK_OPE_CD,
			TRK_DATE = W_TRK_DATE,
			TRK_PGM_ID = W_TRK_PGM_ID
		WHERE REC_ID = iREC_ID
		AND KJN_CD = iKJN_CD
		AND SENMONI_CD = iSENMONI_CD;
		oROW_COUNT := SQL%ROWCOUNT;

		-- ����I��
		RETURN 0;

	-- ��O����
	EXCEPTION
		-- ���̑��G���[
		WHEN OTHERS THEN
			W_ERR_INF_RCD.ERR_CD 		:= TO_CHAR(SQLCODE);
			W_ERR_INF_RCD.ERR_MSG 		:= SUBSTR(SQLERRM, 0, 2000);
			W_ERR_INF_RCD.ERR_KEY_INF 	:= SUBSTR('REC_ID:' || iREC_ID || ', KJN_CD:' || iKJN_CD || ', SENMONI_CD:' || iSENMONI_CD, 0, 2000);
			W_INDEX_N 					:= W_ERR_INF_TBL.COUNT + 1;
			W_ERR_INF_TBL.EXTEND;
			W_ERR_INF_TBL(W_INDEX_N) 	:= W_ERR_INF_RCD;

			OPEN oOUT_ERR_INF_CSR FOR
				SELECT * FROM TABLE(W_ERR_INF_TBL);

			RETURN 1;
		END;

END;
/
CREATE OR REPLACE PACKAGE    PKG_TT_RRK_KJN_SENMONI_GU
/* **********************************************************
 *  Copyright(c) 2011 beyond, INTEC Inc. All rights reserved.
 * **********************************************************/
IS
	-- TT_RRK_KJN_SENMONI%ROWTYPE��TABLE�^���`
	TYPE TT_RRK_KJN_SENMONI_ROWS IS TABLE OF TT_RRK_KJN_SENMONI%ROWTYPE;

	/*** �J�[�\���^ ***************************************************************/
	-- �G���[���i�[�p�J�[�\���^
	TYPE ERR_INF_CSR					IS REF CURSOR;

	/*
	************************************************************************
	*  TT_RRK_KJN_SENMONI
	*  DELETE_TOUJITSU
	************************************************************************
	*/
	FUNCTION DELETE_TOUJITSU(
		iREC_ID	IN	TT_RRK_KJN_SENMONI.REC_ID%TYPE,
		iKJN_CD	IN	TT_RRK_KJN_SENMONI.KJN_CD%TYPE,
		iSENMONI_CD	IN	TT_RRK_KJN_SENMONI.SENMONI_CD%TYPE,
		iTRK_EIGY_YMD			IN VARCHAR2,
		iIP_ADDR				IN TL_STORED_SHORI.IP%TYPE,					-- ���s�[��IP�A�h���X
		iWINDOWS_LOGIN_USER		IN TL_STORED_SHORI.WINDOWS_LOGIN_USER%TYPE, -- ���s�[��OS���[�U�[
		oROW_COUNT				OUT NUMBER,									-- �X�V����
		oOUT_ERR_INF_CSR 		OUT ERR_INF_CSR								-- �G���[���J�[�\��
	) RETURN NUMBER;

END;
/

CREATE OR REPLACE PACKAGE BODY    PKG_TT_RRK_KJN_SENMONI_GU
/* **********************************************************
 *  Copyright(c) 2011 beyond, INTEC Inc. All rights reserved.
 * **********************************************************/
IS
/*
 ************************************************************************
 * Function ID  : DELETE_TOUJITSU
 * Program Name : �����i�c�Ɠ��j�o�^���ꂽ�f�[�^�𕨗��폜����
 * Parameter    : <I> iREC_ID	�FREC_ID%TYPE
 *                <I> iKJN_CD	�FKJN_CD%TYPE
 *                <I> iSENMONI_CD	�FSENMONI_CD%TYPE
 *                <I> iTRK_EIGY_YMD		:TRK_EIGY_YMD
 * Return       �F�������ʁi0:����I���A1:�ُ�I���j
 ************************************************************************
 */
	FUNCTION DELETE_TOUJITSU(
		iREC_ID	IN	TT_RRK_KJN_SENMONI.REC_ID%TYPE,
		iKJN_CD	IN	TT_RRK_KJN_SENMONI.KJN_CD%TYPE,
		iSENMONI_CD	IN	TT_RRK_KJN_SENMONI.SENMONI_CD%TYPE,
		iTRK_EIGY_YMD			IN VARCHAR2,
		iIP_ADDR				IN TL_STORED_SHORI.IP%TYPE,					-- ���s�[��IP�A�h���X
		iWINDOWS_LOGIN_USER		IN TL_STORED_SHORI.WINDOWS_LOGIN_USER%TYPE, -- ���s�[��OS���[�U�[
		oROW_COUNT				OUT NUMBER,									-- �X�V����
		oOUT_ERR_INF_CSR 		OUT ERR_INF_CSR								-- �G���[���J�[�\��
	) RETURN NUMBER IS

	/************************************************************************/
	/*                              �G���[����                              */
	/************************************************************************/
	W_INDEX_N 					NUMBER(10) := 0;
	W_ERR_INF_TBL 				TYPE_ERR_INFO_TBL := TYPE_ERR_INFO_TBL();
	W_ERR_INF_RCD 				TYPE_ERR_INFO_RCD := TYPE_ERR_INFO_RCD(NULL,NULL,NULL,NULL);

	BEGIN

		-- DELETE ���s
		DELETE TT_RRK_KJN_SENMONI
		WHERE REC_ID = iREC_ID
		AND KJN_CD = iKJN_CD
		AND SENMONI_CD = iSENMONI_CD
		AND TRK_FKT_EIGY_YMD = iTRK_EIGY_YMD;
		oROW_COUNT := SQL%ROWCOUNT;

		-- ����I��
		RETURN 0;

	-- ��O����
	EXCEPTION
		-- ���̑��G���[
		WHEN OTHERS THEN
			W_ERR_INF_RCD.ERR_CD 		:= TO_CHAR(SQLCODE);
			W_ERR_INF_RCD.ERR_MSG 		:= SUBSTR(SQLERRM, 0, 2000);
			W_ERR_INF_RCD.ERR_KEY_INF 	:= SUBSTR('REC_ID:' || iREC_ID || ', KJN_CD:' || iKJN_CD || ', SENMONI_CD:' || iSENMONI_CD, 0, 2000);
			W_INDEX_N 					:= W_ERR_INF_TBL.COUNT + 1;
			W_ERR_INF_TBL.EXTEND;
			W_ERR_INF_TBL(W_INDEX_N) 	:= W_ERR_INF_RCD;

			OPEN oOUT_ERR_INF_CSR FOR
				SELECT * FROM TABLE(W_ERR_INF_TBL);

			RETURN 1;
		END;

END;
/
