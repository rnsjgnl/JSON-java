CREATE OR REPLACE PACKAGE BT010301B001_COMMON
/* **********************************************************
 *  Copyright(c) 2011 beyond, INTEC Inc. All rights reserved.
 * **********************************************************/
AUTHID CURRENT_USER
IS    

    /*** �萔 ***************************************************************/
    SZKBUKA_CD_MI CONSTANT varchar2(4):='9999'; --���������R�[�h��"9999"
    YAKUSHOKU_CD_MI CONSTANT varchar2(3):='501'; --��E�R�[�h��"501"

    /*
    ************************************************************************
    *  �J�΋敪�X�V����
    *  UPDATE_KAIKIN_KBN
    ************************************************************************
    */
    PROCEDURE UPDATE_KAIKIN_KBN(
        iRecId                    IN TT_SISN_KJN.REC_ID%TYPE,                  -- ���R�[�hID
        iKjnCd                    IN TT_SISN_KJN.KJN_CD%TYPE,                  -- �{�݃R�[�h
        iUserCd                    IN TT_SISN_KJN.UPD_USER_CD%TYPE,             -- ���[�U�R�[�h
        iShoriEigyoBi            IN TT_SISN_KJN.UPD_EIGY_YMD%TYPE,            -- �����c�Ɠ�
        iShitenEigyoshoNm        IN TT_RRK_KJN_KAIKIN.SHITEN_EIGYOSHO_NM%TYPE,-- �����쐬�p�@�x�X�c�Ə���
        iMrNm                    IN TT_RRK_KJN_KAIKIN.MR_NM%TYPE,             -- �����쐬�p�@MR��
        iChosaYmd                IN TT_RRK_KJN_KAIKIN.CHOSA_YMD%TYPE,         -- �����쐬�p�@�����N����
        iIP_ADDR                IN TL_STORED_SHORI.IP%TYPE,                  -- ���s�[��IP�A�h���X
        iWINDOWS_LOGIN_USER     IN TL_STORED_SHORI.WINDOWS_LOGIN_USER%TYPE,  -- ���s�[��OS���[�U�[
        iOPE_CD                    IN TT_SISN_KJN.UPD_OPE_CD%TYPE,                 -- �I�y���[�^�R�[�h
        iDATE                    IN TT_SISN_KJN.UPD_DATE%TYPE,                 -- ��������
        iPGM_ID                    IN TT_SISN_KJN.UPD_PGM_ID%TYPE                 -- �@�\ID
    ) ;

    /*
    ************************************************************************
    *  �ސE���̋Ζ��旚���ƃC���v�b�g�󋵂��쐬����
    *  CREATE_TAISHOKU_RRK
    ************************************************************************
    */
    PROCEDURE CREATE_TAISHOKU_RRK(
        iRecId                    IN TT_SISN_KJN.REC_ID%TYPE,                  -- ���R�[�hID
        iKjnCd                    IN TT_SISN_KJN.KJN_CD%TYPE,                  -- �l�R�[�h
        iKinmuRecId                IN TT_SISN_KJN_KINMUSAKI.KINMUSAKI_REC_ID%TYPE,                 -- �Ζ��惌�R�[�hID
        iKinmuShiCd                IN TT_SISN_KJN_KINMUSAKI.KINMUSAKI_SHI_CD%TYPE,                 -- �Ζ���{�݃R�[�h
        iUserCd                    IN TT_SISN_KJN.UPD_USER_CD%TYPE,             -- ���[�U�R�[�h
        iShoriEigyoBi            IN TT_SISN_KJN.UPD_EIGY_YMD%TYPE,            -- �����c�Ɠ�
        iShitenEigyoshoNm        IN TT_RRK_KJN_KAIKIN.SHITEN_EIGYOSHO_NM%TYPE,-- �����쐬�p�@�x�X�c�Ə���
        iMrNm                    IN TT_RRK_KJN_KAIKIN.MR_NM%TYPE,             -- �����쐬�p�@MR��
        iChosaYmd                IN TT_RRK_KJN_KAIKIN.CHOSA_YMD%TYPE,         -- �����쐬�p�@�����N����
        iIP_ADDR                IN TL_STORED_SHORI.IP%TYPE,                  -- ���s�[��IP�A�h���X
        iWINDOWS_LOGIN_USER     IN TL_STORED_SHORI.WINDOWS_LOGIN_USER%TYPE,  -- ���s�[��OS���[�U�[
        iOPE_CD                    IN TT_SISN_KJN.UPD_OPE_CD%TYPE,                 -- �I�y���[�^�R�[�h
        iDATE                    IN TT_SISN_KJN.UPD_DATE%TYPE,                 -- ��������
        iPGM_ID                    IN TT_SISN_KJN.UPD_PGM_ID%TYPE                 -- �@�\ID
    ) ;

    /*
    ************************************************************************
    *  �C���v�b�g�󋵎{�ݏo�͏���
    *  INSERT_INPUT_JOKYO_SHI
    ************************************************************************
    */
    PROCEDURE INSERT_INPUT_JOKYO_SHI(

        iShoriEigyoBi   IN TT_INPUT_JOKYO_SHI.SHORI_EIGY_YMD%TYPE,          -- �����c�Ɠ�
        iRecId          IN TT_INPUT_JOKYO_SHI.REC_ID%TYPE,                  -- ���R�[�hID
        iUserCd         IN TT_INPUT_JOKYO_SHI.USER_CD%TYPE,                 -- ���[�U�R�[�h
        iModKbn         IN TT_INPUT_JOKYO_SHI.MOD_KBN%TYPE,                 -- �C���敪
        iKomokuCd       IN TT_INPUT_JOKYO_SHI.KOMOKU_CD%TYPE,               -- ���ڃR�[�h
        iShiCd          IN TT_INPUT_JOKYO_SHI.SHI_CD%TYPE,                  -- �{�݃R�[�h
        iIP_ADDR    IN TL_STORED_SHORI.IP%TYPE,                                         -- ���s�[��IP�A�h���X
        iWINDOWS_LOGIN_USER    IN TL_STORED_SHORI.WINDOWS_LOGIN_USER%TYPE,              -- ���s�[��OS���[�U�[
        iOPE_CD         IN TT_INPUT_JOKYO_SHI.UPD_OPE_CD%TYPE,              -- �I�y���[�^�R�[�h
        iDATE           IN TT_INPUT_JOKYO_SHI.UPD_DATE%TYPE,                -- ��������
        iPGM_ID         IN TT_INPUT_JOKYO_SHI.UPD_PGM_ID%TYPE               -- �@�\ID
    
    ) ;

    /*
    ************************************************************************
    *  �C���v�b�g�󋵌l�o�͏���
    *  INSERT_INPUT_JOKYO_KJN
    ************************************************************************
    */
    PROCEDURE INSERT_INPUT_JOKYO_KJN(

        iShoriEigyoBi   IN TT_INPUT_JOKYO_KJN.SHORI_EIGY_YMD%TYPE,          -- �����c�Ɠ�
        iRecId          IN TT_INPUT_JOKYO_KJN.REC_ID%TYPE,                  -- ���R�[�hID
        iUserCd         IN TT_INPUT_JOKYO_KJN.USER_CD%TYPE,                 -- ���[�U�R�[�h
        iModKbn         IN TT_INPUT_JOKYO_KJN.MOD_KBN%TYPE,                 -- �C���敪
        iKomokuCd       IN TT_INPUT_JOKYO_KJN.KOMOKU_CD%TYPE,               -- ���ڃR�[�h
        iKjnCd          IN TT_INPUT_JOKYO_KJN.KJN_CD%TYPE,                  -- �l�R�[�h
        iIP_ADDR    IN TL_STORED_SHORI.IP%TYPE,                                         -- ���s�[��IP�A�h���X
        iWINDOWS_LOGIN_USER    IN TL_STORED_SHORI.WINDOWS_LOGIN_USER%TYPE,              -- ���s�[��OS���[�U�[
        iOPE_CD         IN TT_INPUT_JOKYO_KJN.UPD_OPE_CD%TYPE,              -- �I�y���[�^�R�[�h
        iDATE           IN TT_INPUT_JOKYO_KJN.UPD_DATE%TYPE,                -- ��������
        iPGM_ID         IN TT_INPUT_JOKYO_KJN.UPD_PGM_ID%TYPE               -- �@�\ID
    
    ) ;
END;
/

CREATE OR REPLACE PACKAGE BODY BT010301B001_COMMON
/* **********************************************************
 *  Copyright(c) 2011 beyond, INTEC Inc. All rights reserved.
 * **********************************************************/
IS


    /*
    ************************************************************************
    *  �C���v�b�g�󋵎{�ݏo�͏���
    *  INSERT_INPUT_JOKYO_SHI
    ************************************************************************
    */
    PROCEDURE INSERT_INPUT_JOKYO_SHI(
    
        iShoriEigyoBi   IN TT_INPUT_JOKYO_SHI.SHORI_EIGY_YMD%TYPE,          -- �����c�Ɠ�
        iRecId          IN TT_INPUT_JOKYO_SHI.REC_ID%TYPE,                  -- ���R�[�hID
        iUserCd         IN TT_INPUT_JOKYO_SHI.USER_CD%TYPE,                 -- ���[�U�R�[�h
        iModKbn         IN TT_INPUT_JOKYO_SHI.MOD_KBN%TYPE,                 -- �C���敪
        iKomokuCd       IN TT_INPUT_JOKYO_SHI.KOMOKU_CD%TYPE,               -- ���ڃR�[�h
        iShiCd          IN TT_INPUT_JOKYO_SHI.SHI_CD%TYPE,                  -- �{�݃R�[�h
        iIP_ADDR    IN TL_STORED_SHORI.IP%TYPE,                                         -- ���s�[��IP�A�h���X
        iWINDOWS_LOGIN_USER    IN TL_STORED_SHORI.WINDOWS_LOGIN_USER%TYPE,              -- ���s�[��OS���[�U�[
        iOPE_CD         IN TT_INPUT_JOKYO_SHI.UPD_OPE_CD%TYPE,              -- �I�y���[�^�R�[�h
        iDATE           IN TT_INPUT_JOKYO_SHI.UPD_DATE%TYPE,                -- ��������
        iPGM_ID         IN TT_INPUT_JOKYO_SHI.UPD_PGM_ID%TYPE               -- �@�\ID
    
    )  IS
    
    vInputJyokyoShiSql VARCHAR2(2000) := 'INSERT INTO TT_INPUT_JOKYO_SHI(SEQ, SHORI_EIGY_YMD, REC_ID, USER_CD, MOD_KBN, KOMOKU_CD, SHI_CD, OPE_CD, TRK_OPE_CD, TRK_DATE, TRK_PGM_ID, UPD_OPE_CD, UPD_DATE, UPD_PGM_ID) VALUES(:SEQ, :SHORI_EIGY_YMD, :REC_ID, :USER_CD, :MOD_KBN, :KOMOKU_CD, :SHI_CD, :OPE_CD, :TRK_OPE_CD, :TRK_DATE, :TRK_PGM_ID, :UPD_OPE_CD, :UPD_DATE, :UPD_PGM_ID)';

    BEGIN


        ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql [vInputJyokyoShiSql]',
            vInputJyokyoShiSql
            || ' :SHORI_EIGY_YMD = ''' || iShoriEigyoBi
            || ' '' :REC_ID = ''' || iRecId
            || ' '' :USER_CD = ''' || iUserCd
            || ' '' :MOD_KBN = ''' || iModKbn
            || ' '' :KOMOKU_CD = ''' || iKomokuCd
            || ' '' :SHI_CD = ''' || iShiCd
            || ' '' :OPE_CD = ''' || iOPE_CD
            || ' '' :TRK_OPE_CD = ''' || iOPE_CD
            || ' '' :TRK_DATE = ''' || iDATE
            || ' '' :TRK_PGM_ID = ''' || iPGM_ID
            || ' '' :UPD_OPE_CD = ''' || iOPE_CD
            || ' '' :UPD_DATE = ''' || iDATE
            || ' '' :UPD_PGM_ID = ''' || iPGM_ID
            ,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);
            
        EXECUTE IMMEDIATE vInputJyokyoShiSql
            USING SEQ_INPUT_PK.NEXTVAL,
                  iShoriEigyoBi,
                  iRecId,
                  iUserCd,
                  iModKbn,
                  iKomokuCd,
                  iShiCd,
                  iOPE_CD,
                  iOPE_CD,
                  iDATE,
                  iPGM_ID,
                  iOPE_CD,
                  iDATE,
                  iPGM_ID;
        
    -- ��O����
    EXCEPTION
        -- ���̑��G���[
        WHEN OTHERS THEN
            RAISE;
    END;

    /*
    ************************************************************************
    *  �C���v�b�g�󋵌l�o�͏���
    *  INSERT_INPUT_JOKYO_KJN
    ************************************************************************
    */
    PROCEDURE INSERT_INPUT_JOKYO_KJN(
    
        iShoriEigyoBi   IN TT_INPUT_JOKYO_KJN.SHORI_EIGY_YMD%TYPE,          -- �����c�Ɠ�
        iRecId          IN TT_INPUT_JOKYO_KJN.REC_ID%TYPE,                  -- ���R�[�hID
        iUserCd         IN TT_INPUT_JOKYO_KJN.USER_CD%TYPE,                 -- ���[�U�R�[�h
        iModKbn         IN TT_INPUT_JOKYO_KJN.MOD_KBN%TYPE,                 -- �C���敪
        iKomokuCd       IN TT_INPUT_JOKYO_KJN.KOMOKU_CD%TYPE,               -- ���ڃR�[�h
        iKjnCd          IN TT_INPUT_JOKYO_KJN.KJN_CD%TYPE,                  -- �l�R�[�h
        iIP_ADDR    IN TL_STORED_SHORI.IP%TYPE,                                         -- ���s�[��IP�A�h���X
        iWINDOWS_LOGIN_USER    IN TL_STORED_SHORI.WINDOWS_LOGIN_USER%TYPE,              -- ���s�[��OS���[�U�[
        iOPE_CD         IN TT_INPUT_JOKYO_KJN.UPD_OPE_CD%TYPE,              -- �I�y���[�^�R�[�h
        iDATE           IN TT_INPUT_JOKYO_KJN.UPD_DATE%TYPE,                -- ��������
        iPGM_ID         IN TT_INPUT_JOKYO_KJN.UPD_PGM_ID%TYPE               -- �@�\ID
    
    ) IS
    
    vInputJyokyoKjnSql VARCHAR2(2000) := 'INSERT INTO TT_INPUT_JOKYO_KJN(SEQ, SHORI_EIGY_YMD, REC_ID, USER_CD, MOD_KBN, KOMOKU_CD, KJN_CD, OPE_CD, TRK_OPE_CD, TRK_DATE, TRK_PGM_ID, UPD_OPE_CD, UPD_DATE, UPD_PGM_ID) VALUES(:SEQ,:SHORI_EIGY_YMD,:REC_ID,:USER_CD,:MOD_KBN,:KOMOKU_CD,:KJN_CD,:OPE_CD,:TRK_OPE_CD,:TRK_DATE,:TRK_PGM_ID,:UPD_OPE_CD,:UPD_DATE,:UPD_PGM_ID)';

    BEGIN

        ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql [vInputJyokyoKjnSql]',
            vInputJyokyoKjnSql
            || ' :SHORI_EIGY_YMD = ''' || iShoriEigyoBi
            || ' '' :REC_ID = ''' || iRecId
            || ' '' :USER_CD = ''' || iUserCd
            || ' '' :MOD_KBN = ''' || iModKbn
            || ' '' :KOMOKU_CD = ''' || iKomokuCd
            || ' '' :KJN_CD = ''' || iKjnCd
            || ' '' :OPE_CD = ''' || iOPE_CD
            || ' '' :TRK_OPE_CD = ''' || iOPE_CD
            || ' '' :TRK_DATE = ''' || iDATE
            || ' '' :TRK_PGM_ID = ''' || iPGM_ID
            || ' '' :UPD_OPE_CD = ''' || iOPE_CD
            || ' '' :UPD_DATE = ''' || iDATE
            || ' '' :UPD_PGM_ID = ''' || iPGM_ID
            ,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);
            
        EXECUTE IMMEDIATE vInputJyokyoKjnSql
            USING SEQ_INPUT_PK.NEXTVAL,
                  iShoriEigyoBi,
                  iRecId,
                  iUserCd,
                  iModKbn,
                  iKomokuCd,
                  iKjnCd,
                  iOPE_CD,
                  iOPE_CD,
                  iDATE,
                  iPGM_ID,
                  iOPE_CD,
                  iDATE,
                  iPGM_ID;


        
    -- ��O����
    EXCEPTION
        -- ���̑��G���[
        WHEN OTHERS THEN
            RAISE;
    END;


    /*
    ************************************************************************
    *  �J�΋敪�X�V����
    *  UPDATE_KAIKIN_KBN
    ************************************************************************
    */
    PROCEDURE UPDATE_KAIKIN_KBN(

        iRecId                    IN TT_SISN_KJN.REC_ID%TYPE,                  -- ���R�[�hID
        iKjnCd                    IN TT_SISN_KJN.KJN_CD%TYPE,                  -- �{�݃R�[�h
        iUserCd                    IN TT_SISN_KJN.UPD_USER_CD%TYPE,             -- ���[�U�R�[�h
        iShoriEigyoBi            IN TT_SISN_KJN.UPD_EIGY_YMD%TYPE,            -- �����c�Ɠ�

        iShitenEigyoshoNm        IN TT_RRK_KJN_KAIKIN.SHITEN_EIGYOSHO_NM%TYPE,-- �����쐬�p�@�x�X�c�Ə���
        iMrNm                    IN TT_RRK_KJN_KAIKIN.MR_NM%TYPE,             -- �����쐬�p�@MR��
        iChosaYmd                IN TT_RRK_KJN_KAIKIN.CHOSA_YMD%TYPE,         -- �����쐬�p�@�����N����

        iIP_ADDR                IN TL_STORED_SHORI.IP%TYPE,                  -- ���s�[��IP�A�h���X
        iWINDOWS_LOGIN_USER     IN TL_STORED_SHORI.WINDOWS_LOGIN_USER%TYPE,  -- ���s�[��OS���[�U�[
        iOPE_CD                    IN TT_SISN_KJN.UPD_OPE_CD%TYPE,                 -- �I�y���[�^�R�[�h
        iDATE                    IN TT_SISN_KJN.UPD_DATE%TYPE,                 -- ��������
        iPGM_ID                    IN TT_SISN_KJN.UPD_PGM_ID%TYPE                 -- �@�\ID    
    ) IS


        -- �J�΋敪�X�V
        vSQL_UPD_KAIKIN_1 VARCHAR2(2000) := 
                        ' UPDATE TT_SISN_KJN'
                        || '    SET KAIKIN_KBN = ''9'','
                        || '        UPD_USER_CD = :UserCd,'
                        || '        UPD_EIGY_YMD = :ShoriEigyoBi,'
                        || '        UPD_OPE_CD = :OPE_CD,'
                        || '        UPD_DATE = :UPD_DATE,'
                        || '        UPD_PGM_ID = :PGM_ID'
                        || '  WHERE REC_ID = :REC_ID'
                        || '    AND KJN_CD = :KJN_CD'
                        || '    AND KAIKIN_KBN IN (''1'', ''2'')'
                        || '    AND ('
                        || '     SELECT'
                        || '      COUNT(*) AS KINMUSAKI_CNT'
                        || '      FROM'
                        || '      TT_SISN_KJN_KINMUSAKI A'
                        || '      WHERE A.REC_ID = :REC_ID'
                        || '      AND A.KJN_CD = :KJN_CD'
                        || '      AND A.TAISHOKU_FLG IS NULL) = 0';

        vSQL_UPD_KAIKIN_2 VARCHAR2(2000) := 
                        ' UPDATE TT_SISN_KJN'
                        || '    SET KAIGYONEN_GENGO_CD = NULL,'
                        || '        KAIGYONEN_SY = NULL,'
                        || '        KAIGYONEN_WY = NULL,'
                        || '        UPD_USER_CD = :UserCd,'
                        || '        UPD_EIGY_YMD = :ShoriEigyoBi,'
                        || '        UPD_OPE_CD = :OPE_CD,'
                        || '        UPD_DATE = :UPD_DATE,'
                        || '        UPD_PGM_ID = :PGM_ID'
                        || '  WHERE REC_ID = :REC_ID'
                        || '    AND KJN_CD = :KJN_CD'
                        || '    AND (KAIGYONEN_GENGO_CD IS NOT NULL OR KAIGYONEN_SY IS NOT NULL OR KAIGYONEN_WY IS NOT NULL)';

        -- �J�Η���
        vSQL_KAIKIN_RRK VARCHAR2(2000) :=  
                        ' INSERT INTO TT_RRK_KJN_KAIKIN(SEQ,REC_ID,KJN_CD,SHITEN_EIGYOSHO_NM,MR_NM,CHOSA_YMD,KAIKIN_KBN,KAIGYONEN_GENGO_CD,KAIGYONEN_WY,KAIGYONEN_SY,GOMENTE_FLG,GOMENTE_CHK_OPE_CD,GOMENTE_CHK_USER_CD,GOMENTE_CHK_EIGY_YMD,TRK_USER_CD,TRK_EIGY_YMD,UPD_USER_CD,UPD_EIGY_YMD,TRK_OPE_CD,TRK_DATE,TRK_PGM_ID,UPD_OPE_CD,UPD_DATE,UPD_PGM_ID)'
                     || ' VALUES(SEQ_RIREKI_PK.NEXTVAL,:RecID,:KjnCd,:ShitenEigyoshoNm,:MrNm,:ChosaYmd,''9'',NULL,NULL,NULL,NULL,NULL,NULL,NULL,:UserCd,:ShoriEigyoBi,:UserCd,:ShoriEigyoBi,:OPE_CD,:UPD_DATE,:PGM_ID,:OPE_CD,:UPD_DAT,:PGM_ID)';

    BEGIN


        IF iRecId IN ('01', '05') THEN

            -- ���O�o��
            ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql [vSQL_UPD_KAIKIN_1]',
                vSQL_UPD_KAIKIN_1
                || ''' :ShoriEigyoBi = ''' || iShoriEigyoBi
                || ''' :RecId = ''' || iRecId
                || ''' :KjnCd = ''' || iKjnCd
                || ''' :UserCd = ''' || iUserCd
                || '''', iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

            -- �J�΋敪�̍X�V
            EXECUTE IMMEDIATE vSQL_UPD_KAIKIN_1
                USING
                    iUserCd,
                    iShoriEigyoBi,
                    iOPE_CD,
                    iDATE,
                    iPGM_ID,
                    iRecId,
                    iKjnCd,
                    iRecId,
                    iKjnCd;

            IF SQL%ROWCOUNT = 1 THEN
                -- �X�V����̏ꍇ�A�����쐬���s��
                -- ���O�o��
                ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql [vSQL_KAIKIN_RRK]',
                    vSQL_KAIKIN_RRK
                    || ' :RecId = ''' || iRecId
                    || ''' :KjnCd = ''' || iKjnCd
                    || ''' :ShitenEigyoshoNm = ''' || iShitenEigyoshoNm
                    || ''' :MrNm = ''' || iMrNm
                    || ''' :ChosaYmd = ''' || iChosaYmd
                    || ''' :UserCd = ''' || iUserCd
                    || ''' :ShoriEigyoBi = ''' || iShoriEigyoBi
                    || '''', iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

                EXECUTE IMMEDIATE vSQL_KAIKIN_RRK
                    USING
                        iRecId,
                        iKjnCd,
                        iShitenEigyoshoNm,
                        iMrNm,
                        iChosaYmd,
                        iUserCd,
                        iShoriEigyoBi,
                        iUserCd,
                        iShoriEigyoBi,
                        iOPE_CD,
                        iDATE,
                        iPGM_ID,
                        iOPE_CD,
                        iDATE,
                        iPGM_ID;

                -- �C���v�b�g�󋵃e�[�u���̓o�^
                -- �J�΋敪
                INSERT_INPUT_JOKYO_KJN(
                    iShoriEigyoBi
                    ,iRecId
                    ,iUserCd
                    ,'B'
                    ,'0011'
                    ,iKjnCd
                    ,iIP_ADDR
                    ,iWINDOWS_LOGIN_USER
                    ,iOPE_CD
                    ,iDATE
                    ,iPGM_ID);
                -- �J�ƔN�����R�[�h�A�a��N�A����N

                -- �J�ƔN�̍X�V
                -- ���O�o��
                ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql [vSQL_UPD_KAIKIN_2]',
                    vSQL_UPD_KAIKIN_2
                    || ''' :ShoriEigyoBi = ''' || iShoriEigyoBi
                    || ''' :RecId = ''' || iRecId
                    || ''' :KjnCd = ''' || iKjnCd
                    || ''' :UserCd = ''' || iUserCd
                    || '''', iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

                EXECUTE IMMEDIATE vSQL_UPD_KAIKIN_2
                    USING
                        iUserCd,
                        iShoriEigyoBi,
                        iOPE_CD,
                        iDATE,
                        iPGM_ID,
                        iRecId,
                        iKjnCd;
                IF SQL%ROWCOUNT = 1 THEN
                    -- �J�ƔN�A�J�ƌ����R�[�h�A�J�Ɛ���A�J�Ƙa��̕ύX���������̂ݓo�^���s���B
                    INSERT_INPUT_JOKYO_KJN(
                        iShoriEigyoBi
                        ,iRecId
                        ,iUserCd
                        ,'B'
                        ,'0012'
                        ,iKjnCd
                        ,iIP_ADDR
                        ,iWINDOWS_LOGIN_USER
                        ,iOPE_CD
                        ,iDATE
                        ,iPGM_ID);
                END IF;
            END IF;
        END IF;

    -- ��O����
    EXCEPTION
        -- ���̑��G���[
        WHEN OTHERS THEN
            RAISE;
    END;

    /*
    ************************************************************************
    *  �ސE���̋Ζ��旚���ƃC���v�b�g�󋵂��쐬����
    *  CREATE_TAISHOKU_RRK
    ************************************************************************
    */
    PROCEDURE CREATE_TAISHOKU_RRK(
        iRecId                    IN TT_SISN_KJN.REC_ID%TYPE,                                     -- ���R�[�hID
        iKjnCd                    IN TT_SISN_KJN.KJN_CD%TYPE,                                     -- �l�R�[�h
        iKinmuRecId                IN TT_SISN_KJN_KINMUSAKI.KINMUSAKI_REC_ID%TYPE,                 -- �Ζ��惌�R�[�hID
        iKinmuShiCd                IN TT_SISN_KJN_KINMUSAKI.KINMUSAKI_SHI_CD%TYPE,                 -- �Ζ���{�݃R�[�h
        iUserCd                    IN TT_SISN_KJN.UPD_USER_CD%TYPE,             -- ���[�U�R�[�h
        iShoriEigyoBi            IN TT_SISN_KJN.UPD_EIGY_YMD%TYPE,            -- �����c�Ɠ�
        iShitenEigyoshoNm        IN TT_RRK_KJN_KAIKIN.SHITEN_EIGYOSHO_NM%TYPE,-- �����쐬�p�@�x�X�c�Ə���
        iMrNm                    IN TT_RRK_KJN_KAIKIN.MR_NM%TYPE,             -- �����쐬�p�@MR��
        iChosaYmd                IN TT_RRK_KJN_KAIKIN.CHOSA_YMD%TYPE,         -- �����쐬�p�@�����N����
        iIP_ADDR                IN TL_STORED_SHORI.IP%TYPE,                  -- ���s�[��IP�A�h���X
        iWINDOWS_LOGIN_USER     IN TL_STORED_SHORI.WINDOWS_LOGIN_USER%TYPE,  -- ���s�[��OS���[�U�[
        iOPE_CD                    IN TT_SISN_KJN.UPD_OPE_CD%TYPE,                 -- �I�y���[�^�R�[�h
        iDATE                    IN TT_SISN_KJN.UPD_DATE%TYPE,                 -- ��������
        iPGM_ID                    IN TT_SISN_KJN.UPD_PGM_ID%TYPE                 -- �@�\ID
    ) IS


    vSQL_TAISHOKU_RRK VARCHAR2(2000) := 'INSERT INTO TT_RRK_KJN_KINMUSAKI(SEQ,REC_ID,KJN_CD,KINMUSAKI_REC_ID,KINMUSAKI_SHI_CD,TAISHOKU_FLG,TAISHOKU_EIGY_YMD,SHITEN_EIGYOSHO_NM,MR_NM,CHOSA_YMD,DAIHYO_FLG,SZKBUKA_CD,NYURYOKU_SZKBUKA_NM,NYURYOKU_SZKBUKA_NM_KANA,YAKUSHOKU_CD,SHOKUI_CD,KINMUSAKI_DM_FUKA_FLG,KINMUSAKI_KKNN_YMD,KINMUSAKI_KKNN_USER_CD,KINMUSAKI_KKNN_OPE_CD,JOHO_YMD,GOMENTE_FLG,GOMENTE_CHK_OPE_CD,GOMENTE_CHK_USER_CD,GOMENTE_CHK_EIGY_YMD,TRK_FKT_EIGY_YMD,TRK_USER_CD,TRK_EIGY_YMD,UPD_USER_CD,UPD_EIGY_YMD,TRK_OPE_CD,TRK_DATE,TRK_PGM_ID,UPD_OPE_CD,UPD_DATE,UPD_PGM_ID)'
                                     || 'SELECT SEQ_RIREKI_PK.NEXTVAL,REC_ID,KJN_CD,KINMUSAKI_REC_ID,KINMUSAKI_SHI_CD,TAISHOKU_FLG,TAISHOKU_EIGY_YMD,:ShitenEigyoshoNm,:MrNm,:ChosaYmd,DAIHYO_FLG,SZKBUKA_CD,NYURYOKU_SZKBUKA_NM,NYURYOKU_SZKBUKA_NM_KANA,YAKUSHOKU_CD,SHOKUI_CD,KINMUSAKI_DM_FUKA_FLG,KINMUSAKI_KKNN_YMD,KINMUSAKI_KKNN_USER_CD,KINMUSAKI_KKNN_OPE_CD,JOHO_YMD,NULL,NULL,NULL,NULL,TRK_FKT_EIGY_YMD,:UserCd,:ShoriEigyoBi,:UserCd,:ShoriEigyoBi,:OPE_CD,:TRK_DATE,:PGM_ID,:OPE_CD,:UPD_DATE,:PGM_ID FROM TT_SISN_KJN_KINMUSAKI WHERE REC_ID = :RecId AND KJN_CD = :KjnCd AND KINMUSAKI_REC_ID = :KinmusakiRecId AND KINMUSAKI_SHI_CD = :KinmusakiShiCd';

    BEGIN

        IF iRecId IN ('01', '02', '05') THEN
            -- �����쐬
            -- ���O�o��
            ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql [vSQL_TAISHOKU_RRK]',
                vSQL_TAISHOKU_RRK
                || ' :ShitenEigyoshoNm = ''' || iShitenEigyoshoNm
                || ''' :MrNm = ''' || iMrNm
                || ''' :ChosaYmd = ''' || iChosaYmd
                || ''' :ShoriEigyoBi = ''' || iShoriEigyoBi
                || ''' :RecId = ''' || iRecId
                || ''' :KjnCd = ''' || iKjnCd
                || ''' :KinmusakiRecId = ''' || iKinmuRecId
                || ''' :KinmusakiShiCd = ''' || iKinmuShiCd
                || ''' :UserCd = ''' || iUserCd
                || '''', iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

            EXECUTE IMMEDIATE vSQL_TAISHOKU_RRK
                USING
                    iShitenEigyoshoNm,
                    iMrNm,
                    iChosaYmd,
                    iUserCd,
                    iShoriEigyoBi,
                    iUserCd,
                    iShoriEigyoBi,
                    iOPE_CD,
                    iDATE,
                    iPGM_ID,
                    iOPE_CD,
                    iDATE,
                    iPGM_ID,
                    iRecId,
                    iKjnCd,
                    iKinmuRecId,
                    iKinmuShiCd;

            -- �C���v�b�g�󋵃e�[�u���̓o�^
            INSERT_INPUT_JOKYO_KJN(
                iShoriEigyoBi
                ,iRecId
                ,iUserCd
                ,'B'
                ,'0018'
                ,iKjnCd
                ,iIP_ADDR
                ,iWINDOWS_LOGIN_USER
                ,iOPE_CD
                ,iDATE
                ,iPGM_ID);
        END IF;

    -- ��O����
    EXCEPTION
        -- ���̑��G���[
        WHEN OTHERS THEN
            RAISE;
    END;

END;
/