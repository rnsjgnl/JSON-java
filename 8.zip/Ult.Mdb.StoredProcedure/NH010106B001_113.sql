CREATE OR REPLACE PACKAGE NH010106B001_113
/* **********************************************************
 *  Copyright(c) 2011 beyond, INTEC Inc. All rights reserved.
 * **********************************************************/
AUTHID CURRENT_USER
IS
	/*** �J�[�\���^ ***************************************************************/
	-- �G���[���i�[�p�J�[�\���^
	TYPE ERR_INF_CSR		IS REF CURSOR;

  /*
  ************************************************************************
  *  �b��_�S��_�ǉ��A�C�e��1�e�[�u���̍쐬
  *  CREATE_TSUIKAITEM1
  ************************************************************************
  */
  FUNCTION CREATE_TSUIKAITEM1(
  iShimeKind  IN  INTEGER,                    -- ���ߓ��敪
  iTensoYMD	IN	VARCHAR2,                     -- �]���N����
  iOPE_CD IN Varchar2,                      -- �I�y���[�^�R�[�h
  iPGM_ID IN Varchar2,                      -- �v���O����ID
  iDATE DATE,                               -- �V�X�e������
  iIP_ADDR  IN TL_STORED_SHORI.IP%TYPE,              -- ���s�[��IP�A�h���X (FW�Őݒ�)
  iWINDOWS_LOGIN_USER  IN TL_STORED_SHORI.WINDOWS_LOGIN_USER%TYPE, -- ���s�[��OS���[�U�[ (FW�Őݒ�)
  oROW_COUNT  OUT NUMBER,         -- �o�^����
  oOUT_ERR_INF_CSR   OUT ERR_INF_CSR    -- �G���[���J�[�\��
  ) RETURN NUMBER;

END;
/
CREATE OR REPLACE PACKAGE BODY NH010106B001_113
/* **********************************************************
 *  Copyright(c) 2011 beyond, INTEC Inc. All rights reserved.
 * **********************************************************/
IS
  /*
   ************************************************************************
   * Function ID  : CREATE_TSUIKAITEM1
   * Program Name : �b��_�S��_�ǉ��A�C�e��1�e�[�u���̍쐬
   * Parameter    :  <I> iShimeKind    �F���ߓ��敪
   *                 <I> iTensoYMD    �F�]���N����
   *                 <I> iOPE_CD    �F�I�y���[�^�R�[�h
   *                 <I> iPGM_ID    �F�v���O����ID
   *                 <I> iDATE    �F�V�X�e������
   *                 <I> iIP_ADDR    �F���s�[��IP�A�h���X
   *                 <I> iWINDOWS_LOGIN_USER  �F���s�[��IP�A�h���X
   *                <O> oROW_COUNT        �F�X�V����
   *                <O> oOUT_ERR_INF_CSR  �F�G���[���J�[�\��
   * Return       �F�������ʁi0:����I���A1:�ُ�I���j
   ************************************************************************
   */
  FUNCTION CREATE_TSUIKAITEM1(
  iShimeKind  IN  INTEGER,                    -- ���ߓ��敪
  iTensoYMD  IN  VARCHAR2,                     -- �]���N����
  iOPE_CD IN Varchar2,                      -- �I�y���[�^�R�[�h
  iPGM_ID IN Varchar2,                      -- �v���O����ID
  iDATE DATE,                               -- �V�X�e������
  iIP_ADDR  IN TL_STORED_SHORI.IP%TYPE,              -- ���s�[��IP�A�h���X (FW�Őݒ�)
  iWINDOWS_LOGIN_USER  IN TL_STORED_SHORI.WINDOWS_LOGIN_USER%TYPE, -- ���s�[��OS���[�U�[ (FW�Őݒ�)
  oROW_COUNT  OUT NUMBER,         -- �o�^����
  oOUT_ERR_INF_CSR   OUT ERR_INF_CSR    -- �G���[���J�[�\��
  )RETURN NUMBER IS
PRAGMA AUTONOMOUS_TRANSACTION;
  /************************************************************************/
  /*                              �G���[����                              */
  /************************************************************************/
  W_INDEX_N           NUMBER(10) := 0;
  W_ERR_INF_TBL         TYPE_ERR_INFO_TBL := TYPE_ERR_INFO_TBL();
  W_ERR_INF_RCD         TYPE_ERR_INFO_RCD := TYPE_ERR_INFO_RCD(NULL,NULL,NULL,NULL);
  vSchemaNm           TM_JOSU.HANYO_KOMOKU%TYPE := NULL; -- �X�L�[�}����
  PGM_ID        VARCHAR2(50) := 'NH010106B001_113.CREATE_TSUIKAITEM1';
  EXECUTE_SQL   VARCHAR2(32767) := NULL;

  -- �񋟗p�e�[�u������f�ނc�a�쐬�p�f�[�^���擾����J�[�\��
  CURSOR item1CSR IS
      SELECT
        TTT.REC_ID                       ,
        TTT.SHI_CD                       ,
        TTS.SHI_RN                       ,
        TTS.JUSHO_KANJI_RENKETSU         ,
        TTS.KEN_CD                       ,
        TTS.SHIKU_CD                     ,
        TTS.OAZA_CD                      ,
        TTS.AZA_CD                       ,
        TTS.KEIEITAI_CD                  ,
        TTT.SOGO_BYOIN_FLG               ,
        TTT.SHOKAIGAIRAI_KBN_CD          ,
        TTT.SAIGAIKYOTEN_FLG             ,
        TTT.KYUKYU_IRY_KKJ_FLG           ,
        TTT.KYUKYU_IRY_2JI_FLG           ,
        TTT.KYUKYU_IRY_3JI_FLG           ,
        TTT.KANSEN_TOKUTEI_FLG           ,
        TTT.KANSEN_1SHU_FLG              ,
        TTT.KANSEN_2SHU_FLG              ,
        TTT.IRYHYOKA_FLG                 ,
        TTT.IRYHYOKA_CD                  ,
        TTT.IRYHYOKA_SHONIN_YMD          ,
        TTT.IRYHYOKA_CANCEL_YMD          ,
        TTT.CHIKIRY_FLG                  ,
        TTT.CHIKIRY_SHOKAIRITSU          ,
        TTT.CHIKIRY_SHONIN_YMD           ,
        TTT.CHIKIRY_CANCEL_YMD           ,
        TTT.KYU_TOKUTEI_FLG              ,
        TTT.KYU_TOKUTEI_SHONIN_YMD       ,
        TTT.KYU_TOKUTEI_CANCEL_YMD       ,
        TTT.KYU_NYUIN_FLG                ,
        TTT.KYU_NYUIN_SHONIN_YMD         ,
        TTT.KYU_NYUIN_CANCEL_YMD         ,
        TTT.TOKUTEIKINO_FLG              ,
        TTT.TOKUTEIKINO_SHONIN_YMD       ,
        TTT.TOKUTEIKINO_CANCEL_YMD       ,
        TTT.KAIHOGATA_FLG                ,
        TTT.KAIHOGATA_SHONIN_YMD         ,
        TTT.KAIHOGATA_CANCEL_YMD         ,
        TTT.KANWACARE_FLG                ,
        TTT.KANWACARE_BED_SU             ,
        TTT.KANWACARE_SHONIN_YMD         ,
        TTT.KANWACARE_CANCEL_YMD         ,
        TTT.YAKUZAIKANRI_FLG             ,
        TTT.YAKUZAIKANRI_SHONIN_YMD      ,
        TTT.YAKUZAIKANRI_CANCEL_YMD      ,
        TTT.RNSKNS_KKN1_FLG              ,
        TTT.RNSKNS_KKN1_SHONIN_YMD       ,
        TTT.RNSKNS_KKN1_CANCEL_YMD       ,
        TTT.RNSKNS_KKN2_FLG              ,
        TTT.RNSKNS_KKN2_SHONIN_YMD       ,
        TTT.RNSKNS_KKN2_CANCEL_YMD       ,
        TTT.RNSKNS_KYRYK_FLG             ,
        TTT.RNSKNS_KYRYK_SHONIN_YMD      ,
        TTT.RNSKNS_KYRYK_CANCEL_YMD      ,
        TTT.SENSHIN_1_20_FLG             ,
        TTT.SENSHIN_CD_01                ,
        TTT.SENSHIN_CD_02                ,
        TTT.SENSHIN_CD_03                ,
        TTT.SENSHIN_CD_04                ,
        TTT.SENSHIN_CD_05                ,
        TTT.SENSHIN_CD_06                ,
        TTT.SENSHIN_CD_07                ,
        TTT.SENSHIN_CD_08                ,
        TTT.SENSHIN_CD_09                ,
        TTT.SENSHIN_CD_10                ,
        TTT.SENSHIN_CD_11                ,
        TTT.SENSHIN_CD_12                ,
        TTT.SENSHIN_CD_13                ,
        TTT.SENSHIN_CD_14                ,
        TTT.SENSHIN_CD_15                ,
        TTT.SENSHIN_CD_16                ,
        TTT.SENSHIN_CD_17                ,
        TTT.SENSHIN_CD_18                ,
        TTT.SENSHIN_CD_19                ,
        TTT.SENSHIN_CD_20                ,
        TTT.SNTNIRY_FLG                  ,
        TTT.SNTNIRY_CD_01                ,
        TTT.SNTNIRY_CD_02                ,
        TTT.SNTNIRY_CD_03                ,
        TTT.SNTNIRY_CD_04                ,
        TTT.SNTNIRY_CD_05                ,
        TTT.SNTNIRY_CD_06                ,
        TTT.SNTNIRY_CD_07                ,
        TTT.SNTNIRY_CD_08                ,
        TTT.SNTNIRY_CD_09                ,
        TTT.SNTNIRY_CD_10                ,
        TTT.SNTNIRY_CD_11                ,
        TTT.SNTNIRY_CD_12                ,
        TTT.SNTNIRY_CD_13                ,
        TTT.SNTNIRY_CD_14                ,
        TTT.SNTNIRY_CD_15                ,
        TTT.SNTNIRY_CD_16                ,
        TTT.SNTNIRY_CD_17                ,
        TTT.SNTNIRY_CD_18                ,
        TTT.SNTNIRY_CD_19                ,
        TTT.SNTNIRY_CD_20                ,
        TTT.HMNKNG_FLG                   ,
        TTT.HMNKNG_REC_ID                ,
        TTT.HMNKNG_SHI_CD                ,
        LTTS.SEISHIKI_SHI_NM30           ,
        TTT.IPPAN_FLG                    ,
        TTT.IPPAN_KNG_SBT_CD             ,
        TTT.IPPAN_BED_SU                 ,
        TTT.IPPAN_GOKEI_BED_SU           ,
        TTT.RYOYO_FLG                    ,
        TTT.RYOYO_IRY_KNG_SBT_CD         ,
        TTT.RYOYO_IRY_BED_SU             ,
        TTT.RYOYO_IRY_SHONIN_YMD         ,
        TTT.RYOYO_IRY_CANCEL_YMD         ,
        TTT.RYOYO_KIG_KNG_SBT_CD         ,
        TTT.RYOYO_KIG_BED_SU             ,
        TTT.RYOYO_KIG_SHONIN_YMD         ,
        TTT.RYOYO_KIG_CANCEL_YMD         ,
        TTT.RYOYO_GOKEI_BED_SU           ,
        TTT.RYOYO_KANI_KBN_CD            ,
        TTT.CAREMIXTO_KBN_CD             ,
        TTT.SEISHIN_FLG                  ,
        TTT.SEISHIN_KNG_SBT_CD           ,
        TTT.SEISHIN_BED_SU               ,
        TTT.SEISHIN_GOKEI_BED_SU         ,
        TTT.KEKKAKU_FLG                  ,
        TTT.KEKKAKU_KNG_SBT_CD           ,
        TTT.KEKKAKU_BED_SU               ,
        TTT.KANSEN_FLG                   ,
        TTT.KANSEN_BED_SU                ,
        TTT.KAISETSU_YM                  ,
        TTT.UPD_EIGY_YMD
      FROM TT_TIKY_TSUIKAITEM�@TTT
      INNER JOIN TT_TIKY_SHI�@TTS
        ON TTS.REC_ID = TTT.REC_ID
        AND  TTS.SHI_CD = TTT.SHI_CD
      LEFT OUTER JOIN TT_TIKY_SHI�@LTTS
        ON LTTS.REC_ID = TTT.HMNKNG_REC_ID
        AND  LTTS.SHI_CD = TTT.HMNKNG_SHI_CD
      WHERE�@TTS.REC_ID�@= '00'
      AND�@TTS.DEL_FLG IS NULL
      AND�@TTT.ITEM_1_MOD_EIGY_YMD IS NOT NULL
      AND�@TTT.DEL_FLG IS NULL
  UNION
      SELECT
        TTT.REC_ID                           ,
        TTT.SHI_CD                           ,
        NULL AS SHI_RN                       ,
        NULL AS JUSHO_KANJI_RENKETSU         ,
        NULL AS KEN_CD                       ,
        NULL AS SHIKU_CD                     ,
        NULL AS OAZA_CD                      ,
        NULL AS AZA_CD                       ,
        NULL AS KEIEITAI_CD                  ,
        NULL AS SOGO_BYOIN_FLG               ,
        NULL AS SHOKAIGAIRAI_KBN_CD          ,
        NULL AS SAIGAIKYOTEN_FLG             ,
        NULL AS KYUKYU_IRY_KKJ_FLG           ,
        NULL AS KYUKYU_IRY_2JI_FLG           ,
        NULL AS KYUKYU_IRY_3JI_FLG           ,
        NULL AS KANSEN_TOKUTEI_FLG           ,
        NULL AS KANSEN_1SHU_FLG              ,
        NULL AS KANSEN_2SHU_FLG              ,
        NULL AS IRYHYOKA_FLG                 ,
        NULL AS IRYHYOKA_CD                  ,
        NULL AS IRYHYOKA_SHONIN_YMD          ,
        NULL AS IRYHYOKA_CANCEL_YMD          ,
        NULL AS CHIKIRY_FLG                  ,
        NULL AS CHIKIRY_SHOKAIRITSU          ,
        NULL AS CHIKIRY_SHONIN_YMD           ,
        NULL AS CHIKIRY_CANCEL_YMD           ,
        NULL AS KYU_TOKUTEI_FLG              ,
        NULL AS KYU_TOKUTEI_SHONIN_YMD       ,
        NULL AS KYU_TOKUTEI_CANCEL_YMD       ,
        NULL AS KYU_NYUIN_FLG                ,
        NULL AS KYU_NYUIN_SHONIN_YMD         ,
        NULL AS KYU_NYUIN_CANCEL_YMD         ,
        NULL AS TOKUTEIKINO_FLG              ,
        NULL AS TOKUTEIKINO_SHONIN_YMD       ,
        NULL AS TOKUTEIKINO_CANCEL_YMD       ,
        NULL AS KAIHOGATA_FLG                ,
        NULL AS KAIHOGATA_SHONIN_YMD         ,
        NULL AS KAIHOGATA_CANCEL_YMD         ,
        NULL AS KANWACARE_FLG                ,
        NULL AS KANWACARE_BED_SU             ,
        NULL AS KANWACARE_SHONIN_YMD         ,
        NULL AS KANWACARE_CANCEL_YMD         ,
        NULL AS YAKUZAIKANRI_FLG             ,
        NULL AS YAKUZAIKANRI_SHONIN_YMD      ,
        NULL AS YAKUZAIKANRI_CANCEL_YMD      ,
        NULL AS RNSKNS_KKN1_FLG              ,
        NULL AS RNSKNS_KKN1_SHONIN_YMD       ,
        NULL AS RNSKNS_KKN1_CANCEL_YMD       ,
        NULL AS RNSKNS_KKN2_FLG              ,
        NULL AS RNSKNS_KKN2_SHONIN_YMD       ,
        NULL AS RNSKNS_KKN2_CANCEL_YMD       ,
        NULL AS RNSKNS_KYRYK_FLG             ,
        NULL AS RNSKNS_KYRYK_SHONIN_YMD      ,
        NULL AS RNSKNS_KYRYK_CANCEL_YMD      ,
        NULL AS SENSHIN_1_20_FLG             ,
        NULL AS SENSHIN_CD_01                ,
        NULL AS SENSHIN_CD_02                ,
        NULL AS SENSHIN_CD_03                ,
        NULL AS SENSHIN_CD_04                ,
        NULL AS SENSHIN_CD_05                ,
        NULL AS SENSHIN_CD_06                ,
        NULL AS SENSHIN_CD_07                ,
        NULL AS SENSHIN_CD_08                ,
        NULL AS SENSHIN_CD_09                ,
        NULL AS SENSHIN_CD_10                ,
        NULL AS SENSHIN_CD_11                ,
        NULL AS SENSHIN_CD_12                ,
        NULL AS SENSHIN_CD_13                ,
        NULL AS SENSHIN_CD_14                ,
        NULL AS SENSHIN_CD_15                ,
        NULL AS SENSHIN_CD_16                ,
        NULL AS SENSHIN_CD_17                ,
        NULL AS SENSHIN_CD_18                ,
        NULL AS SENSHIN_CD_19                ,
        NULL AS SENSHIN_CD_20                ,
        NULL AS SNTNIRY_FLG                  ,
        NULL AS SNTNIRY_CD_01                ,
        NULL AS SNTNIRY_CD_02                ,
        NULL AS SNTNIRY_CD_03                ,
        NULL AS SNTNIRY_CD_04                ,
        NULL AS SNTNIRY_CD_05                ,
        NULL AS SNTNIRY_CD_06                ,
        NULL AS SNTNIRY_CD_07                ,
        NULL AS SNTNIRY_CD_08                ,
        NULL AS SNTNIRY_CD_09                ,
        NULL AS SNTNIRY_CD_10                ,
        NULL AS SNTNIRY_CD_11                ,
        NULL AS SNTNIRY_CD_12                ,
        NULL AS SNTNIRY_CD_13                ,
        NULL AS SNTNIRY_CD_14                ,
        NULL AS SNTNIRY_CD_15                ,
        NULL AS SNTNIRY_CD_16                ,
        NULL AS SNTNIRY_CD_17                ,
        NULL AS SNTNIRY_CD_18                ,
        NULL AS SNTNIRY_CD_19                ,
        NULL AS SNTNIRY_CD_20                ,
        NULL AS HMNKNG_FLG                   ,
        NULL AS HMNKNG_REC_ID                ,
        NULL AS HMNKNG_SHI_CD                ,
        NULL AS SEISHIKI_SHI_NM30            ,
        NULL AS IPPAN_FLG                    ,
        NULL AS IPPAN_KNG_SBT_CD             ,
        NULL AS IPPAN_BED_SU                 ,
        NULL AS IPPAN_GOKEI_BED_SU           ,
        NULL AS RYOYO_FLG                    ,
        NULL AS RYOYO_IRY_KNG_SBT_CD         ,
        NULL AS RYOYO_IRY_BED_SU             ,
        NULL AS RYOYO_IRY_SHONIN_YMD         ,
        NULL AS RYOYO_IRY_CANCEL_YMD         ,
        NULL AS RYOYO_KIG_KNG_SBT_CD         ,
        NULL AS RYOYO_KIG_BED_SU             ,
        NULL AS RYOYO_KIG_SHONIN_YMD         ,
        NULL AS RYOYO_KIG_CANCEL_YMD         ,
        NULL AS RYOYO_GOKEI_BED_SU           ,
        NULL AS RYOYO_KANI_KBN_CD            ,
        NULL AS CAREMIXTO_KBN_CD             ,
        NULL AS SEISHIN_FLG                  ,
        NULL AS SEISHIN_KNG_SBT_CD           ,
        NULL AS SEISHIN_BED_SU               ,
        NULL AS SEISHIN_GOKEI_BED_SU         ,
        NULL AS KEKKAKU_FLG                  ,
        NULL AS KEKKAKU_KNG_SBT_CD           ,
        NULL AS KEKKAKU_BED_SU               ,
        NULL AS KANSEN_FLG                   ,
        NULL AS KANSEN_BED_SU                ,
        NULL AS KAISETSU_YM                  ,
        TTT.UPD_EIGY_YMD
      FROM      �@TT_TIKY_SHI�@TTS
      INNER JOIN TT_TIKY_TSUIKAITEM�@TTT  
      ON TTS.REC_ID = TTT.REC_ID  
      AND  TTS.SHI_CD = TTT.SHI_CD
      WHERE�@TTS.REC_ID�@= '00'
      AND�@TTS.DEL_FLG IS NULL
      AND�@TTT.ITEM_1_MOD_EIGY_YMD IS NOT NULL
      AND�@TTT.DEL_FLG = '1';

   item1Row item1CSR%ROWTYPE;

   -- �񋟗p�ǉ��A�C�e���t���Տ����C�a�@�e�[�u������f�ނc�a�쐬�p�f�[�^���擾����
   CURSOR rnsknsCSR(recId IN VARCHAR2, shiCd IN VARCHAR2) IS
    SELECT
      TTTR.KYRYK_REC_ID,
      TTTR.KYRYK_SHI_CD
    FROM TT_TIKY_TSUIKAITEM_RNSKNS TTTR
    LEFT OUTER JOIN TT_EIGY_YMD_KANRI TEYK
      ON 1 = 1
    WHERE TTTR.REC_ID = recId
      AND TTTR.SHI_CD = shiCd
      AND TTTR.SHI_CD != TTTR.KYRYK_SHI_CD
      AND TEYK.PK = '1'
      AND TTTR.S_NENDO BETWEEN TEYK.EIGY_NENDO - 1 AND TEYK.EIGY_NENDO
    ORDER BY TTTR.S_NENDO,TTTR.SORTKEY_NOHIN;

   rnsknsRow rnsknsCSR%ROWTYPE;

   vKyryk1ShirecId TT_TIKY_TSUIKAITEM_RNSKNS.KYRYK_REC_ID%TYPE; -- ���͌^�a�@1�{�݃R�[�h_���R�[�hID
   vKyryk1ShiCd TT_TIKY_TSUIKAITEM_RNSKNS.KYRYK_SHI_CD%TYPE;    -- ���͌^�a�@1�{�݃R�[�h_�{�݃R�[�h
   vKyryk2ShirecId TT_TIKY_TSUIKAITEM_RNSKNS.KYRYK_REC_ID%TYPE; -- ���͌^�a�@2�{�݃R�[�h_���R�[�hID
   vKyryk2ShiCd TT_TIKY_TSUIKAITEM_RNSKNS.KYRYK_SHI_CD%TYPE;    -- ���͌^�a�@2�{�݃R�[�h_�{�݃R�[�h
   vCount   NUMBER(10);                    -- �擾���悤���R�[�h���� 
  BEGIN

    -- �J�n���O�o��
  	ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'PL/SQL Start',PGM_ID || '�̏������J�n���܂��B',iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

    -- �����D���ߋ敪��"1"(������)��
    IF iShimeKind = ULT_COMMON.SHIME_SBT_CD_HISHIME THEN

          -- �[�i�p�X�L�[�}�̎擾���s���B
          vSchemaNm := ULT_COMMON.GET_SCHEMA_NAME(ULT_COMMON.SYS_ENV_JOSU_DAI_CD, ULT_COMMON.NOHIN_SHEMA_JOSU_SHO_CD);

          --�b��_�S��_�ǉ��A�C�e��1�e�[�u���̃f�[�^���N���A����
          EXECUTE_SQL := 'TRUNCATE TABLE ' || vSchemaNm || '.' || 'TD_PA_TSUIKAITEM1';
          EXECUTE IMMEDIATE EXECUTE_SQL;
          ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

		 -- �񋟗p�ǉ��A�C�e���t���Տ����C�a�@�e�[�u������f�ނc�a�쐬�p�f�[�^����������
	   	 EXECUTE_SQL:='  SELECT                                         ' ||
					'          TTT.REC_ID                       ,     ' ||
					'          TTT.SHI_CD                       ,     ' ||
					'          TTS.SHI_RN                       ,     ' ||
					'          TTS.JUSHO_KANJI_RENKETSU         ,     ' ||
					'          TTS.KEN_CD                       ,     ' ||
					'          TTS.SHIKU_CD                     ,     ' ||
					'          TTS.OAZA_CD                      ,     ' ||
					'          TTS.AZA_CD                       ,     ' ||
					'          TTS.KEIEITAI_CD                  ,     ' ||
					'          TTT.SOGO_BYOIN_FLG               ,     ' ||
					'          TTT.SHOKAIGAIRAI_KBN_CD          ,     ' ||
					'          TTT.SAIGAIKYOTEN_FLG             ,     ' ||
					'          TTT.KYUKYU_IRY_KKJ_FLG           ,     ' ||
					'          TTT.KYUKYU_IRY_2JI_FLG           ,     ' ||
					'          TTT.KYUKYU_IRY_3JI_FLG           ,     ' ||
					'          TTT.KANSEN_TOKUTEI_FLG           ,     ' ||
					'          TTT.KANSEN_1SHU_FLG              ,     ' ||
					'          TTT.KANSEN_2SHU_FLG              ,     ' ||
					'          TTT.IRYHYOKA_FLG                 ,     ' ||
					'          TTT.IRYHYOKA_CD                  ,     ' ||
					'          TTT.IRYHYOKA_SHONIN_YMD          ,     ' ||
					'          TTT.IRYHYOKA_CANCEL_YMD          ,     ' ||
					'          TTT.CHIKIRY_FLG                  ,     ' ||
					'          TTT.CHIKIRY_SHOKAIRITSU          ,     ' ||
					'          TTT.CHIKIRY_SHONIN_YMD           ,     ' ||
					'          TTT.CHIKIRY_CANCEL_YMD           ,     ' ||
					'          TTT.KYU_TOKUTEI_FLG              ,     ' ||
					'          TTT.KYU_TOKUTEI_SHONIN_YMD       ,     ' ||
					'          TTT.KYU_TOKUTEI_CANCEL_YMD       ,     ' ||
					'          TTT.KYU_NYUIN_FLG                ,     ' ||
					'          TTT.KYU_NYUIN_SHONIN_YMD         ,     ' ||
					'          TTT.KYU_NYUIN_CANCEL_YMD         ,     ' ||
					'          TTT.TOKUTEIKINO_FLG              ,     ' ||
					'          TTT.TOKUTEIKINO_SHONIN_YMD       ,     ' ||
					'          TTT.TOKUTEIKINO_CANCEL_YMD       ,     ' ||
					'          TTT.KAIHOGATA_FLG                ,     ' ||
					'          TTT.KAIHOGATA_SHONIN_YMD         ,     ' ||
					'          TTT.KAIHOGATA_CANCEL_YMD         ,     ' ||
					'          TTT.KANWACARE_FLG                ,     ' ||
					'          TTT.KANWACARE_BED_SU             ,     ' ||
					'          TTT.KANWACARE_SHONIN_YMD         ,     ' ||
					'          TTT.KANWACARE_CANCEL_YMD         ,     ' ||
					'          TTT.YAKUZAIKANRI_FLG             ,     ' ||
					'          TTT.YAKUZAIKANRI_SHONIN_YMD      ,     ' ||
					'          TTT.YAKUZAIKANRI_CANCEL_YMD      ,     ' ||
					'          TTT.RNSKNS_KKN1_FLG              ,     ' ||
					'          TTT.RNSKNS_KKN1_SHONIN_YMD       ,     ' ||
					'          TTT.RNSKNS_KKN1_CANCEL_YMD       ,     ' ||
					'          TTT.RNSKNS_KKN2_FLG              ,     ' ||
					'          TTT.RNSKNS_KKN2_SHONIN_YMD       ,     ' ||
					'          TTT.RNSKNS_KKN2_CANCEL_YMD       ,     ' ||
					'          TTT.RNSKNS_KYRYK_FLG             ,     ' ||
					'          TTT.RNSKNS_KYRYK_SHONIN_YMD      ,     ' ||
					'          TTT.RNSKNS_KYRYK_CANCEL_YMD      ,     ' ||
					'          TTT.SENSHIN_1_20_FLG             ,     ' ||
					'          TTT.SENSHIN_CD_01                ,     ' ||
					'          TTT.SENSHIN_CD_02                ,     ' ||
					'          TTT.SENSHIN_CD_03                ,     ' ||
					'          TTT.SENSHIN_CD_04                ,     ' ||
					'          TTT.SENSHIN_CD_05                ,     ' ||
					'          TTT.SENSHIN_CD_06                ,     ' ||
					'          TTT.SENSHIN_CD_07                ,     ' ||
					'          TTT.SENSHIN_CD_08                ,     ' ||
					'          TTT.SENSHIN_CD_09                ,     ' ||
					'          TTT.SENSHIN_CD_10                ,     ' ||
					'          TTT.SENSHIN_CD_11                ,     ' ||
					'          TTT.SENSHIN_CD_12                ,     ' ||
					'          TTT.SENSHIN_CD_13                ,     ' ||
					'          TTT.SENSHIN_CD_14                ,     ' ||
					'          TTT.SENSHIN_CD_15                ,     ' ||
					'          TTT.SENSHIN_CD_16                ,     ' ||
					'          TTT.SENSHIN_CD_17                ,     ' ||
					'          TTT.SENSHIN_CD_18                ,     ' ||
					'          TTT.SENSHIN_CD_19                ,     ' ||
					'          TTT.SENSHIN_CD_20                ,     ' ||
					'          TTT.SNTNIRY_FLG                  ,     ' ||
					'          TTT.SNTNIRY_CD_01                ,     ' ||
					'          TTT.SNTNIRY_CD_02                ,     ' ||
					'          TTT.SNTNIRY_CD_03                ,     ' ||
					'          TTT.SNTNIRY_CD_04                ,     ' ||
					'          TTT.SNTNIRY_CD_05                ,     ' ||
					'          TTT.SNTNIRY_CD_06                ,     ' ||
					'          TTT.SNTNIRY_CD_07                ,     ' ||
					'          TTT.SNTNIRY_CD_08                ,     ' ||
					'          TTT.SNTNIRY_CD_09                ,     ' ||
					'          TTT.SNTNIRY_CD_10                ,     ' ||
					'          TTT.SNTNIRY_CD_11                ,     ' ||
					'          TTT.SNTNIRY_CD_12                ,     ' ||
					'          TTT.SNTNIRY_CD_13                ,     ' ||
					'          TTT.SNTNIRY_CD_14                ,     ' ||
					'          TTT.SNTNIRY_CD_15                ,     ' ||
					'          TTT.SNTNIRY_CD_16                ,     ' ||
					'          TTT.SNTNIRY_CD_17                ,     ' ||
					'          TTT.SNTNIRY_CD_18                ,     ' ||
					'          TTT.SNTNIRY_CD_19                ,     ' ||
					'          TTT.SNTNIRY_CD_20                ,     ' ||
					'          TTT.HMNKNG_FLG                   ,     ' ||
					'          TTT.HMNKNG_REC_ID                ,     ' ||
					'          TTT.HMNKNG_SHI_CD                ,     ' ||
					'          LTTS.SEISHIKI_SHI_NM30           ,     ' ||
					'          TTT.IPPAN_FLG                    ,     ' ||
					'          TTT.IPPAN_KNG_SBT_CD             ,     ' ||
					'          TTT.IPPAN_BED_SU                 ,     ' ||
					'          TTT.IPPAN_GOKEI_BED_SU           ,     ' ||
					'          TTT.RYOYO_FLG                    ,     ' ||
					'          TTT.RYOYO_IRY_KNG_SBT_CD         ,     ' ||
					'          TTT.RYOYO_IRY_BED_SU             ,     ' ||
					'          TTT.RYOYO_IRY_SHONIN_YMD         ,     ' ||
					'          TTT.RYOYO_IRY_CANCEL_YMD         ,     ' ||
					'          TTT.RYOYO_KIG_KNG_SBT_CD         ,     ' ||
					'          TTT.RYOYO_KIG_BED_SU             ,     ' ||
					'          TTT.RYOYO_KIG_SHONIN_YMD         ,     ' ||
					'          TTT.RYOYO_KIG_CANCEL_YMD         ,     ' ||
					'          TTT.RYOYO_GOKEI_BED_SU           ,     ' ||
					'          TTT.RYOYO_KANI_KBN_CD            ,     ' ||
					'          TTT.CAREMIXTO_KBN_CD             ,     ' ||
					'          TTT.SEISHIN_FLG                  ,     ' ||
					'          TTT.SEISHIN_KNG_SBT_CD           ,     ' ||
					'          TTT.SEISHIN_BED_SU               ,     ' ||
					'          TTT.SEISHIN_GOKEI_BED_SU         ,     ' ||
					'          TTT.KEKKAKU_FLG                  ,     ' ||
					'          TTT.KEKKAKU_KNG_SBT_CD           ,     ' ||
					'          TTT.KEKKAKU_BED_SU               ,     ' ||
					'          TTT.KANSEN_FLG                   ,     ' ||
					'          TTT.KANSEN_BED_SU                ,     ' ||
					'          TTT.KAISETSU_YM                  ,     ' ||
					'          TTT.UPD_EIGY_YMD                       ' ||
					'        FROM TT_TIKY_TSUIKAITEM�@TTT             ' ||
					'        INNER JOIN TT_TIKY_SHI�@TTS              ' ||
					'          ON TTS.REC_ID = TTT.REC_ID             ' ||
					'          AND  TTS.SHI_CD = TTT.SHI_CD           ' ||
					'        LEFT OUTER JOIN TT_TIKY_SHI�@LTTS        ' ||
					'          ON LTTS.REC_ID = TTT.HMNKNG_REC_ID     ' ||
					'          AND  LTTS.SHI_CD = TTT.HMNKNG_SHI_CD   ' ||
					'        WHERE�@TTS.REC_ID�@= ''00''                ' ||
					'        AND�@TTS.DEL_FLG IS NULL                 ' ||
					'        AND�@TTT.ITEM_1_MOD_EIGY_YMD IS NOT NULL ' ||
					'        AND�@TTT.DEL_FLG IS NULL                 ' ||
					'    UNION                                        ' ||
					'        SELECT                                   ' ||
					'          TTT.REC_ID                           , ' ||
					'          TTT.SHI_CD                           , ' ||
					'          NULL AS SHI_RN                       , ' ||
					'          NULL AS JUSHO_KANJI_RENKETSU         , ' ||
					'          NULL AS KEN_CD                       , ' ||
					'          NULL AS SHIKU_CD                     , ' ||
					'          NULL AS OAZA_CD                      , ' ||
					'          NULL AS AZA_CD                       , ' ||
					'          NULL AS KEIEITAI_CD                  , ' ||
					'          NULL AS SOGO_BYOIN_FLG               , ' ||
					'          NULL AS SHOKAIGAIRAI_KBN_CD          , ' ||
					'          NULL AS SAIGAIKYOTEN_FLG             , ' ||
					'          NULL AS KYUKYU_IRY_KKJ_FLG           , ' ||
					'          NULL AS KYUKYU_IRY_2JI_FLG           , ' ||
					'          NULL AS KYUKYU_IRY_3JI_FLG           , ' ||
					'          NULL AS KANSEN_TOKUTEI_FLG           , ' ||
					'          NULL AS KANSEN_1SHU_FLG              , ' ||
					'          NULL AS KANSEN_2SHU_FLG              , ' ||
					'          NULL AS IRYHYOKA_FLG                 , ' ||
					'          NULL AS IRYHYOKA_CD                  , ' ||
					'          NULL AS IRYHYOKA_SHONIN_YMD          , ' ||
					'          NULL AS IRYHYOKA_CANCEL_YMD          , ' ||
					'          NULL AS CHIKIRY_FLG                  , ' ||
					'          NULL AS CHIKIRY_SHOKAIRITSU          , ' ||
					'          NULL AS CHIKIRY_SHONIN_YMD           , ' ||
					'          NULL AS CHIKIRY_CANCEL_YMD           , ' ||
					'          NULL AS KYU_TOKUTEI_FLG              , ' ||
					'          NULL AS KYU_TOKUTEI_SHONIN_YMD       , ' ||
					'          NULL AS KYU_TOKUTEI_CANCEL_YMD       , ' ||
					'          NULL AS KYU_NYUIN_FLG                , ' ||
					'          NULL AS KYU_NYUIN_SHONIN_YMD         , ' ||
					'          NULL AS KYU_NYUIN_CANCEL_YMD         , ' ||
					'          NULL AS TOKUTEIKINO_FLG              , ' ||
					'          NULL AS TOKUTEIKINO_SHONIN_YMD       , ' ||
					'          NULL AS TOKUTEIKINO_CANCEL_YMD       , ' ||
					'          NULL AS KAIHOGATA_FLG                , ' ||
					'          NULL AS KAIHOGATA_SHONIN_YMD         , ' ||
					'          NULL AS KAIHOGATA_CANCEL_YMD         , ' ||
					'          NULL AS KANWACARE_FLG                , ' ||
					'          NULL AS KANWACARE_BED_SU             , ' ||
					'          NULL AS KANWACARE_SHONIN_YMD         , ' ||
					'          NULL AS KANWACARE_CANCEL_YMD         , ' ||
					'          NULL AS YAKUZAIKANRI_FLG             , ' ||
					'          NULL AS YAKUZAIKANRI_SHONIN_YMD      , ' ||
					'          NULL AS YAKUZAIKANRI_CANCEL_YMD      , ' ||
					'          NULL AS RNSKNS_KKN1_FLG              , ' ||
					'          NULL AS RNSKNS_KKN1_SHONIN_YMD       , ' ||
					'          NULL AS RNSKNS_KKN1_CANCEL_YMD       , ' ||
					'          NULL AS RNSKNS_KKN2_FLG              , ' ||
					'          NULL AS RNSKNS_KKN2_SHONIN_YMD       , ' ||
					'          NULL AS RNSKNS_KKN2_CANCEL_YMD       , ' ||
					'          NULL AS RNSKNS_KYRYK_FLG             , ' ||
					'          NULL AS RNSKNS_KYRYK_SHONIN_YMD      , ' ||
					'          NULL AS RNSKNS_KYRYK_CANCEL_YMD      , ' ||
					'          NULL AS SENSHIN_1_20_FLG             , ' ||
					'          NULL AS SENSHIN_CD_01                , ' ||
					'          NULL AS SENSHIN_CD_02                , ' ||
					'          NULL AS SENSHIN_CD_03                , ' ||
					'          NULL AS SENSHIN_CD_04                , ' ||
					'          NULL AS SENSHIN_CD_05                , ' ||
					'          NULL AS SENSHIN_CD_06                , ' ||
					'          NULL AS SENSHIN_CD_07                , ' ||
					'          NULL AS SENSHIN_CD_08                , ' ||
					'          NULL AS SENSHIN_CD_09                , ' ||
					'          NULL AS SENSHIN_CD_10                , ' ||
					'          NULL AS SENSHIN_CD_11                , ' ||
					'          NULL AS SENSHIN_CD_12                , ' ||
					'          NULL AS SENSHIN_CD_13                , ' ||
					'          NULL AS SENSHIN_CD_14                , ' ||
					'          NULL AS SENSHIN_CD_15                , ' ||
					'          NULL AS SENSHIN_CD_16                , ' ||
					'          NULL AS SENSHIN_CD_17                , ' ||
					'          NULL AS SENSHIN_CD_18                , ' ||
					'          NULL AS SENSHIN_CD_19                , ' ||
					'          NULL AS SENSHIN_CD_20                , ' ||
					'          NULL AS SNTNIRY_FLG                  , ' ||
					'          NULL AS SNTNIRY_CD_01                , ' ||
					'          NULL AS SNTNIRY_CD_02                , ' ||
					'          NULL AS SNTNIRY_CD_03                , ' ||
					'          NULL AS SNTNIRY_CD_04                , ' ||
					'          NULL AS SNTNIRY_CD_05                , ' ||
					'          NULL AS SNTNIRY_CD_06                , ' ||
					'          NULL AS SNTNIRY_CD_07                , ' ||
					'          NULL AS SNTNIRY_CD_08                , ' ||
					'          NULL AS SNTNIRY_CD_09                , ' ||
					'          NULL AS SNTNIRY_CD_10                , ' ||
					'          NULL AS SNTNIRY_CD_11                , ' ||
					'          NULL AS SNTNIRY_CD_12                , ' ||
					'          NULL AS SNTNIRY_CD_13                , ' ||
					'          NULL AS SNTNIRY_CD_14                , ' ||
					'          NULL AS SNTNIRY_CD_15                , ' ||
					'          NULL AS SNTNIRY_CD_16                , ' ||
					'          NULL AS SNTNIRY_CD_17                , ' ||
					'          NULL AS SNTNIRY_CD_18                , ' ||
					'          NULL AS SNTNIRY_CD_19                , ' ||
					'          NULL AS SNTNIRY_CD_20                , ' ||
					'          NULL AS HMNKNG_FLG                   , ' ||
					'          NULL AS HMNKNG_REC_ID                , ' ||
					'          NULL AS HMNKNG_SHI_CD                , ' ||
					'          NULL AS SEISHIKI_SHI_NM30            , ' ||
					'          NULL AS IPPAN_FLG                    , ' ||
					'          NULL AS IPPAN_KNG_SBT_CD             , ' ||
					'          NULL AS IPPAN_BED_SU                 , ' ||
					'          NULL AS IPPAN_GOKEI_BED_SU           , ' ||
					'          NULL AS RYOYO_FLG                    , ' ||
					'          NULL AS RYOYO_IRY_KNG_SBT_CD         , ' ||
					'          NULL AS RYOYO_IRY_BED_SU             , ' ||
					'          NULL AS RYOYO_IRY_SHONIN_YMD         , ' ||
					'          NULL AS RYOYO_IRY_CANCEL_YMD         , ' ||
					'          NULL AS RYOYO_KIG_KNG_SBT_CD         , ' ||
					'          NULL AS RYOYO_KIG_BED_SU             , ' ||
					'          NULL AS RYOYO_KIG_SHONIN_YMD         , ' ||
					'          NULL AS RYOYO_KIG_CANCEL_YMD         , ' ||
					'          NULL AS RYOYO_GOKEI_BED_SU           , ' ||
					'          NULL AS RYOYO_KANI_KBN_CD            , ' ||
					'          NULL AS CAREMIXTO_KBN_CD             , ' ||
					'          NULL AS SEISHIN_FLG                  , ' ||
					'          NULL AS SEISHIN_KNG_SBT_CD           , ' ||
					'          NULL AS SEISHIN_BED_SU               , ' ||
					'          NULL AS SEISHIN_GOKEI_BED_SU         , ' ||
					'          NULL AS KEKKAKU_FLG                  , ' ||
					'          NULL AS KEKKAKU_KNG_SBT_CD           , ' ||
					'          NULL AS KEKKAKU_BED_SU               , ' ||
					'          NULL AS KANSEN_FLG                   , ' ||
					'          NULL AS KANSEN_BED_SU                , ' ||
					'          NULL AS KAISETSU_YM                  , ' ||
					'          TTT.UPD_EIGY_YMD                       ' ||
					'        FROM      �@TT_TIKY_SHI�@TTS             ' ||
					'        INNER JOIN TT_TIKY_TSUIKAITEM�@TTT       ' ||
					'        ON TTS.REC_ID = TTT.REC_ID               ' ||
					'        AND  TTS.SHI_CD = TTT.SHI_CD             ' ||
					'        WHERE�@TTS.REC_ID�@= ''00''                ' ||
					'        AND�@TTS.DEL_FLG IS NULL                 ' ||
					'        AND�@TTT.ITEM_1_MOD_EIGY_YMD IS NOT NULL ' ||
					'        AND�@TTT.DEL_FLG = ''1''                   ' ;
	   	 ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);
	   
          -- ��L�Ŏ擾�����f�[�^������@���@��L�Ŏ擾�����f�[�^�̒񋟗p�ǉ��A�C�e���e�[�u���D�폜�t���O=NULL�̏ꍇ�A���[�v���J�n
          OPEN item1CSR;
          LOOP
            FETCH item1CSR INTO item1Row;
            EXIT WHEN item1CSR%NOTFOUND;
            oROW_COUNT:=oROW_COUNT+1;

		      -- �ϐ��̏�����
		      vCount := 0;
		      vKyryk1ShirecId:=NULL;
		      vKyryk1ShiCd:=NULL;
		      vKyryk2ShirecId:=NULL;
		      vKyryk2ShiCd:=NULL;
		      
		      -- �{�݃R�[�g�Ƌ��͎{�݃R�[�h�̎擾
		      EXECUTE_SQL:='   SELECT                                                                ' ||
							'        TTTR.KYRYK_REC_ID,                                               ' ||
							'        TTTR.KYRYK_SHI_CD                                                ' ||
							'      FROM TT_TIKY_TSUIKAITEM_RNSKNS TTTR                                ' ||
							'      LEFT OUTER JOIN TT_EIGY_YMD_KANRI TEYK                             ' ||
							'        ON 1 = 1                                                         ' ||
							'      WHERE TTTR.REC_ID = recId                                          ' ||
							'        AND TTTR.SHI_CD = shiCd                                          ' ||
							'        AND TTTR.SHI_CD != TTTR.KYRYK_SHI_CD                             ' ||
							'        AND TEYK.PK = ''1''                                                ' ||
							'        AND TTTR.S_NENDO BETWEEN TEYK.EIGY_NENDO - 1 AND TEYK.EIGY_NENDO ' ||
							'      ORDER BY TTTR.S_NENDO,TTTR.SORTKEY_NOHIN                           ' ;
		      ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

		      --�񋟗p�ǉ��A�C�e���t���Տ����C�a�@�e�[�u������f�ނc�a�쐬�p�f�[�^���擾����
		      FOR rnsknsRow IN rnsknsCSR(item1Row.REC_ID, item1Row.SHI_CD) LOOP

		        IF NVL(vKyryk1ShirecId, ' ') != rnsknsRow.KYRYK_REC_ID OR NVL(vKyryk1ShiCd, ' ') != rnsknsRow.KYRYK_SHI_CD THEN
		          vCount := vCount + 1;

		          -- ��Ԗڃ��R�[�h�̐ݒ�
		          IF vCount = 1 THEN
		            vKyryk1ShirecId := rnsknsRow.KYRYK_REC_ID;
		            vKyryk1ShiCd := rnsknsRow.KYRYK_SHI_CD;
		          -- ��Ԗڃ��R�[�h�̐ݒ�
		          ELSIF vCount = 2 THEN
		            vKyryk2ShirecId := rnsknsRow.KYRYK_REC_ID;
		            vKyryk2ShiCd := rnsknsRow.KYRYK_SHI_CD;
		            EXIT;
		          ELSE
		            EXIT;
		          END IF;
		        END IF;
		      END LOOP;

                  -- �b��_�S��_�ǉ��A�C�e��1�e�[�u���ɓo�^����
                  INSERT INTO TD_PA_TSUIKAITEM1(
                        SHIREC_ID                      ,
                        SHI_CD                         ,
                        SHI_CD_YOBI                    ,
                        RYKSK_SHI_NM_KANJI             ,
                        SHI_JUSHO_KANJI                ,
                        SHI_JUSHO_CD_MACHIAZA_FILE     ,
                        KEIEITAI                       ,
                        SOGO_BYOIN                     ,
                        SHOKAIGAIRAI_KASAN             ,
                        SAIGAIKYOTEN_BYOIN             ,
                        KYUKYU_IRY_KYUKYUKOKUJI        ,
                        KYUKYU_IRY_2JI_KYUKYU          ,
                        KYUKYU_IRY_3JI_KYUKYU          ,
                        KANSEN_TOKUTEI                 ,
                        KANSEN_1SHU                    ,
                        KANSEN_2SHU                    ,
                        IRYHYOKA_FLG                   ,
                        IRYHYOKA_SBT                   ,
                        IRYHYOKA_NINTEI_YMD_Y          ,
                        IRYHYOKA_NINTEI_YMD_M          ,
                        IRYHYOKA_NINTEI_YMD_D          ,
                        IRYHYOKA_JITAI_YMD_Y           ,
                        IRYHYOKA_JITAI_YMD_M           ,
                        IRYHYOKA_JITAI_YMD_D           ,
                        CHIKIRY_FLG                    ,
                        CHIKIRY_SHOKAIRITSU            ,
                        CHIKIRY_SHONIN_YMD_Y           ,
                        CHIKIRY_SHONIN_YMD_M           ,
                        CHIKIRY_SHONIN_YMD_D           ,
                        CHIKIRY_CANCEL_YMD_Y           ,
                        CHIKIRY_CANCEL_YMD_M           ,
                        CHIKIRY_CANCEL_YMD_D           ,
                        KYU_TOKUTEI_FLG                ,
                        KYU_TOKUTEI_SHONIN_YMD_Y       ,
                        KYU_TOKUTEI_SHONIN_YMD_M       ,
                        KYU_TOKUTEI_SHONIN_YMD_D       ,
                        KYU_TOKUTEI_CANCEL_YMD_Y       ,
                        KYU_TOKUTEI_CANCEL_YMD_M       ,
                        KYU_TOKUTEI_CANCEL_YMD_D       ,
                        KYU_NYUIN_FLG                  ,
                        KYU_NYUIN_SHONIN_YMD_Y         ,
                        KYU_NYUIN_SHONIN_YMD_M         ,
                        KYU_NYUIN_SHONIN_YMD_D         ,
                        KYU_NYUIN_CANCEL_YMD_Y         ,
                        KYU_NYUIN_CANCEL_YMD_M         ,
                        KYU_NYUIN_CANCEL_YMD_D         ,
                        TOKUTEIKINO_BYOIN_FLG          ,
                        TOKUTEIKINO_BYOIN_SHONIN_YMD_Y ,
                        TOKUTEIKINO_BYOIN_SHONIN_YMD_M ,
                        TOKUTEIKINO_BYOIN_SHONIN_YMD_D ,
                        TOKUTEIKINO_BYOIN_CANCEL_YMD_Y ,
                        TOKUTEIKINO_BYOIN_CANCEL_YMD_M ,
                        TOKUTEIKINO_BYOIN_CANCEL_YMD_D ,
                        KAIBYO_FLG                     ,
                        KAIBYO_SHONIN_YMD_Y            ,
                        KAIBYO_SHONIN_YMD_M            ,
                        KAIBYO_SHONIN_YMD_D            ,
                        KAIBYO_CANCEL_YMD_Y            ,
                        KAIBYO_CANCEL_YMD_M            ,
                        KAIBYO_CANCEL_YMD_D            ,
                        KANWACARE_FLG                  ,
                        KANWACARE_BED_SU               ,
                        KANWACARE_SHONIN_YMD_Y         ,
                        KANWACARE_SHONIN_YMD_M         ,
                        KANWACARE_SHONIN_YMD_D         ,
                        KANWACARE_CANCEL_YMD_Y         ,
                        KANWACARE_CANCEL_YMD_M         ,
                        KANWACARE_CANCEL_YMD_D         ,
                        YAKUZAIKANRI_FLG               ,
                        YAKUZAIKANRI_SHONIN_YMD_Y      ,
                        YAKUZAIKANRI_SHONIN_YMD_M      ,
                        YAKUZAIKANRI_SHONIN_YMD_D      ,
                        YAKUZAIKANRI_CANCEL_YMD_Y      ,
                        YAKUZAIKANRI_CANCEL_YMD_M      ,
                        YAKUZAIKANRI_CANCEL_YMD_D      ,
                        RNSKNS_KKN1_FLG                ,
                        RNSKNS_KKN1_SHONIN_YMD_Y       ,
                        RNSKNS_KKN1_SHONIN_YMD_M       ,
                        RNSKNS_KKN1_SHONIN_YMD_D       ,
                        RNSKNS_KKN1_CANCEL_YMD_Y       ,
                        RNSKNS_KKN1_CANCEL_YMD_M       ,
                        RNSKNS_KKN1_CANCEL_YMD_D       ,
                        RNSKNS_KKN2_FLG                ,
                        RNSKNS_KKN2_KYRYK1_SHIREC_ID   ,
                        RNSKNS_KKN2_KYRYK1_SHI_CD      ,
                        RNSKNS_KKN2_KYRYK1_SHI_CD_YOBI ,
                        RNSKNS_KKN2_KYRYK2_SHIREC_ID   ,
                        RNSKNS_KKN2_KYRYK2_SHI_CD      ,
                        RNSKNS_KKN2_KYRYK2_SHI_CD_YOBI ,
                        RNSKNS_KKN2_SHONIN_YMD_Y       ,
                        RNSKNS_KKN2_SHONIN_YMD_M       ,
                        RNSKNS_KKN2_SHONIN_YMD_D       ,
                        RNSKNS_KKN2_CANCEL_YMD_Y       ,
                        RNSKNS_KKN2_CANCEL_YMD_M       ,
                        RNSKNS_KKN2_CANCEL_YMD_D       ,
                        RNSKNS_KYRYK_FLG               ,
                        RNSKNS_KYRYK_SHONIN_YMD_Y      ,
                        RNSKNS_KYRYK_SHONIN_YMD_M      ,
                        RNSKNS_KYRYK_SHONIN_YMD_D      ,
                        RNSKNS_KYRYK_CANCEL_YMD_Y      ,
                        RNSKNS_KYRYK_CANCEL_YMD_M      ,
                        RNSKNS_KYRYK_CANCEL_YMD_D      ,
                        SENSHIN_FLG                    ,
                        SENSHIN_1_CD                   ,
                        SENSHIN_2_CD                   ,
                        SENSHIN_3_CD                   ,
                        SENSHIN_4_CD                   ,
                        SENSHIN_5_CD                   ,
                        SENSHIN_6_CD                   ,
                        SENSHIN_7_CD                   ,
                        SENSHIN_8_CD                   ,
                        SENSHIN_9_CD                   ,
                        SENSHIN_10_CD                  ,
                        SENSHIN_11_CD                  ,
                        SENSHIN_12_CD                  ,
                        SENSHIN_13_CD                  ,
                        SENSHIN_14_CD                  ,
                        SENSHIN_15_CD                  ,
                        SENSHIN_16_CD                  ,
                        SENSHIN_17_CD                  ,
                        SENSHIN_18_CD                  ,
                        SENSHIN_19_CD                  ,
                        SENSHIN_20_CD                  ,
                        SNTNIRY_FLG                    ,
                        SNTNIRY_1                      ,
                        SNTNIRY_2                      ,
                        SNTNIRY_3                      ,
                        SNTNIRY_4                      ,
                        SNTNIRY_5                      ,
                        SNTNIRY_6                      ,
                        SNTNIRY_7                      ,
                        SNTNIRY_8                      ,
                        SNTNIRY_9                      ,
                        SNTNIRY_10                     ,
                        SNTNIRY_11                     ,
                        SNTNIRY_12                     ,
                        SNTNIRY_13                     ,
                        SNTNIRY_14                     ,
                        SNTNIRY_15                     ,
                        SNTNIRY_16                     ,
                        SNTNIRY_17                     ,
                        SNTNIRY_18                     ,
                        SNTNIRY_19                     ,
                        SNTNIRY_20                     ,
                        HMNKNG_FLG                     ,
                        HMNKNG_SHIREC_ID               ,
                        HMNKNG_SHI_CD                  ,
                        HMNKNG_SHI_CD_YOBI             ,
                        HMNKNG_SEISHIKI_MEISYO_KANJI   ,
                        IPPAN_FLG                      ,
                        IPPAN_UCHI_1_KNG_SBT           ,
                        IPPAN_UCHI_1_BYOTO_SU          ,
                        IPPAN_UCHI_1_BED_SU            ,
                        IPPAN_UCHI_2_KNG_SBT           ,
                        IPPAN_UCHI_2_BYOTO_SU          ,
                        IPPAN_UCHI_2_BED_SU            ,
                        IPPAN_GOKEI_BYOTO_SU           ,
                        IPPAN_GOKEI_BED_SU             ,
                        RYOYO_KADO_SU_FLG              ,
                        RYOYO_KADO_SU_IRY_KNG_SBT      ,
                        RYOYO_KADO_SU_IRY_BYOTO_SU     ,
                        RYOYO_KADO_SU_IRY_BED_SU       ,
                        RYOYO_KADO_SU_IRY_SHONIN_YMD_Y ,
                        RYOYO_KADO_SU_IRY_SHONIN_YMD_M ,
                        RYOYO_KADO_SU_IRY_SHONIN_YMD_D ,
                        RYOYO_KADO_SU_IRY_CANCEL_YMD_Y ,
                        RYOYO_KADO_SU_IRY_CANCEL_YMD_M ,
                        RYOYO_KADO_SU_IRY_CANCEL_YMD_D ,
                        RYOYO_KADO_SU_KIG_KNG_SBT      ,
                        RYOYO_KADO_SU_KIG_BYOTO_SU     ,
                        RYOYO_KADO_SU_KIG_BED_SU       ,
                        RYOYO_KADO_SU_KIG_SHONIN_YMD_Y ,
                        RYOYO_KADO_SU_KIG_SHONIN_YMD_M ,
                        RYOYO_KADO_SU_KIG_SHONIN_YMD_D ,
                        RYOYO_KADO_SU_KIG_CANCEL_YMD_Y ,
                        RYOYO_KADO_SU_KIG_CANCEL_YMD_M ,
                        RYOYO_KADO_SU_KIG_CANCEL_YMD_D ,
                        RYOYO_KADO_SU_GOKEI_BYOTO_SU   ,
                        RYOYO_KADO_SU_GOKEI_BED_SU     ,
                        RYOYO_MIKADO_SU_FLG            ,
                        RYOYO_MIKADO_SU_BYOTO_SU       ,
                        RYOYO_MIKADO_SU_BED_SU         ,
                        RYOYO_KANZEN_IKO_KBN           ,
                        ROJIN_FLG                      ,
                        ROJIN_IRY_KNG_SBT              ,
                        ROJIN_IRY_BYOTO_SU             ,
                        ROJIN_IRY_BED_SU               ,
                        ROJIN_IRY_SHONIN_YMD_Y         ,
                        ROJIN_IRY_SHONIN_YMD_M         ,
                        ROJIN_IRY_SHONIN_YMD_D         ,
                        ROJIN_IRY_CANCEL_YMD_Y         ,
                        ROJIN_IRY_CANCEL_YMD_M         ,
                        ROJIN_IRY_CANCEL_YMD_D         ,
                        ROJIN_KIG_KNG_SBT              ,
                        ROJIN_KIG_BYOTO_SU             ,
                        ROJIN_KIG_BED_SU               ,
                        ROJIN_KIG_SHONIN_YMD_Y         ,
                        ROJIN_KIG_SHONIN_YMD_M         ,
                        ROJIN_KIG_SHONIN_YMD_D         ,
                        ROJIN_KIG_CANCEL_YMD_Y         ,
                        ROJIN_KIG_CANCEL_YMD_M         ,
                        ROJIN_KIG_CANCEL_YMD_D         ,
                        ROJIN_GOKEI_BYOTO_SU           ,
                        ROJIN_GOKEI_BED_SU             ,
                        CAREMIX_KBN                    ,
                        SEISHIN_FLG                    ,
                        SEISHIN_UCHI_1_KNG_SBT         ,
                        SEISHIN_UCHI_1_BYOTO_SU        ,
                        SEISHIN_UCHI_1_BED_SU          ,
                        SEISHIN_UCHI_2_KNG_SBT         ,
                        SEISHIN_UCHI_2_BYOTO_SU        ,
                        SEISHIN_UCHI_2_BED_SU          ,
                        SEISHIN_GOKEI_BYOTO_SU         ,
                        SEISHIN_GOKEI_BED_SU           ,
                        KEKKAKU_FLG                    ,
                        KEKKAKU_KNG_SBT                ,
                        KEKKAKU_BYOTO_SU               ,
                        KEKKAKU_BED_SU                 ,
                        KANSEN_FLG                     ,
                        KANSEN_BYOTO_SU                ,
                        KANSEN_BED_SU                  ,
                        KAISETSU_YM_YM_Y               ,
                        KAISETSU_YM_YM_M               ,
                        YOBI                           ,
                        TENSO_Y                        ,
                        TENSO_M                        ,
                        TENSO_D                        ,
                        MENTE_Y                        ,
                        MENTE_M                        ,
                        MENTE_D                        ,
                        MOD_KBN                        ,
                        TRK_OPE_CD                     ,
                        TRK_DATE                       ,
                        TRK_PGM_ID                     ,
                        UPD_OPE_CD                     ,
                        UPD_DATE                       ,
                        UPD_PGM_ID)
                    VALUES(
                        item1Row.REC_ID,
                        item1Row.SHI_CD,
                        NULL,
                        item1Row.SHI_RN,
                        item1Row.JUSHO_KANJI_RENKETSU,
                        item1Row.KEN_CD || item1Row.SHIKU_CD || item1Row.OAZA_CD || item1Row.AZA_CD,

                        item1Row.KEIEITAI_CD                  ,
                        item1Row.SOGO_BYOIN_FLG               ,
                        item1Row.SHOKAIGAIRAI_KBN_CD          ,
                        item1Row.SAIGAIKYOTEN_FLG             ,
                        item1Row.KYUKYU_IRY_KKJ_FLG           ,
                        item1Row.KYUKYU_IRY_2JI_FLG           ,
                        item1Row.KYUKYU_IRY_3JI_FLG           ,
                        item1Row.KANSEN_TOKUTEI_FLG           ,
                        item1Row.KANSEN_1SHU_FLG              ,
                        item1Row.KANSEN_2SHU_FLG              ,
                        item1Row.IRYHYOKA_FLG                 ,
                        item1Row.IRYHYOKA_CD                  ,

                        NVL2(item1Row.IRYHYOKA_SHONIN_YMD,SUBSTR(item1Row.IRYHYOKA_SHONIN_YMD,1,4),NULL),
                        NVL2(item1Row.IRYHYOKA_SHONIN_YMD,SUBSTR(item1Row.IRYHYOKA_SHONIN_YMD,5,2),NULL),
                        NVL2(item1Row.IRYHYOKA_SHONIN_YMD,SUBSTR(item1Row.IRYHYOKA_SHONIN_YMD,7,2),NULL),
                        NVL2(item1Row.IRYHYOKA_CANCEL_YMD,SUBSTR(item1Row.IRYHYOKA_CANCEL_YMD,1,4),NULL),
                        NVL2(item1Row.IRYHYOKA_CANCEL_YMD,SUBSTR(item1Row.IRYHYOKA_CANCEL_YMD,5,2),NULL),
                        NVL2(item1Row.IRYHYOKA_CANCEL_YMD,SUBSTR(item1Row.IRYHYOKA_CANCEL_YMD,7,2),NULL),

                        item1Row.CHIKIRY_FLG                  ,
                        item1Row.CHIKIRY_SHOKAIRITSU          ,

                        NVL2(item1Row.CHIKIRY_SHONIN_YMD,SUBSTR(item1Row.CHIKIRY_SHONIN_YMD,1,4),NULL),
                        NVL2(item1Row.CHIKIRY_SHONIN_YMD,SUBSTR(item1Row.CHIKIRY_SHONIN_YMD,5,2),NULL),
                        NVL2(item1Row.CHIKIRY_SHONIN_YMD,SUBSTR(item1Row.CHIKIRY_SHONIN_YMD,7,2),NULL),
                        NVL2(item1Row.CHIKIRY_CANCEL_YMD,SUBSTR(item1Row.CHIKIRY_CANCEL_YMD,1,4),NULL),
                        NVL2(item1Row.CHIKIRY_CANCEL_YMD,SUBSTR(item1Row.CHIKIRY_CANCEL_YMD,5,2),NULL),
                        NVL2(item1Row.CHIKIRY_CANCEL_YMD,SUBSTR(item1Row.CHIKIRY_CANCEL_YMD,7,2),NULL),


                        item1Row.KYU_TOKUTEI_FLG              ,

                        NVL2(item1Row.KYU_TOKUTEI_SHONIN_YMD,SUBSTR(item1Row.KYU_TOKUTEI_SHONIN_YMD,1,4),NULL),
                        NVL2(item1Row.KYU_TOKUTEI_SHONIN_YMD,SUBSTR(item1Row.KYU_TOKUTEI_SHONIN_YMD,5,2),NULL),
                        NVL2(item1Row.KYU_TOKUTEI_SHONIN_YMD,SUBSTR(item1Row.KYU_TOKUTEI_SHONIN_YMD,7,2),NULL),
                        NVL2(item1Row.KYU_TOKUTEI_CANCEL_YMD,SUBSTR(item1Row.KYU_TOKUTEI_CANCEL_YMD,1,4),NULL),
                        NVL2(item1Row.KYU_TOKUTEI_CANCEL_YMD,SUBSTR(item1Row.KYU_TOKUTEI_CANCEL_YMD,5,2),NULL),
                        NVL2(item1Row.KYU_TOKUTEI_CANCEL_YMD,SUBSTR(item1Row.KYU_TOKUTEI_CANCEL_YMD,7,2),NULL),

                        item1Row.KYU_NYUIN_FLG                ,

                        NVL2(item1Row.KYU_NYUIN_SHONIN_YMD,SUBSTR(item1Row.KYU_NYUIN_SHONIN_YMD,1,4),NULL),
                        NVL2(item1Row.KYU_NYUIN_SHONIN_YMD,SUBSTR(item1Row.KYU_NYUIN_SHONIN_YMD,5,2),NULL),
                        NVL2(item1Row.KYU_NYUIN_SHONIN_YMD,SUBSTR(item1Row.KYU_NYUIN_SHONIN_YMD,7,2),NULL),
                        NVL2(item1Row.KYU_NYUIN_CANCEL_YMD,SUBSTR(item1Row.KYU_NYUIN_CANCEL_YMD,1,4),NULL),
                        NVL2(item1Row.KYU_NYUIN_CANCEL_YMD,SUBSTR(item1Row.KYU_NYUIN_CANCEL_YMD,5,2),NULL),
                        NVL2(item1Row.KYU_NYUIN_CANCEL_YMD,SUBSTR(item1Row.KYU_NYUIN_CANCEL_YMD,7,2),NULL),

                        item1Row.TOKUTEIKINO_FLG              ,

                        NVL2(item1Row.TOKUTEIKINO_SHONIN_YMD,SUBSTR(item1Row.TOKUTEIKINO_SHONIN_YMD,1,4),NULL),
                        NVL2(item1Row.TOKUTEIKINO_SHONIN_YMD,SUBSTR(item1Row.TOKUTEIKINO_SHONIN_YMD,5,2),NULL),
                        NVL2(item1Row.TOKUTEIKINO_SHONIN_YMD,SUBSTR(item1Row.TOKUTEIKINO_SHONIN_YMD,7,2),NULL),
                        NVL2(item1Row.TOKUTEIKINO_CANCEL_YMD,SUBSTR(item1Row.TOKUTEIKINO_CANCEL_YMD,1,4),NULL),
                        NVL2(item1Row.TOKUTEIKINO_CANCEL_YMD,SUBSTR(item1Row.TOKUTEIKINO_CANCEL_YMD,5,2),NULL),
                        NVL2(item1Row.TOKUTEIKINO_CANCEL_YMD,SUBSTR(item1Row.TOKUTEIKINO_CANCEL_YMD,7,2),NULL),

                        item1Row.KAIHOGATA_FLG                ,

                        NVL2(item1Row.KAIHOGATA_SHONIN_YMD,SUBSTR(item1Row.KAIHOGATA_SHONIN_YMD,1,4),NULL),
                        NVL2(item1Row.KAIHOGATA_SHONIN_YMD,SUBSTR(item1Row.KAIHOGATA_SHONIN_YMD,5,2),NULL),
                        NVL2(item1Row.KAIHOGATA_SHONIN_YMD,SUBSTR(item1Row.KAIHOGATA_SHONIN_YMD,7,2),NULL),
                        NVL2(item1Row.KAIHOGATA_CANCEL_YMD,SUBSTR(item1Row.KAIHOGATA_CANCEL_YMD,1,4),NULL),
                        NVL2(item1Row.KAIHOGATA_CANCEL_YMD,SUBSTR(item1Row.KAIHOGATA_CANCEL_YMD,5,2),NULL),
                        NVL2(item1Row.KAIHOGATA_CANCEL_YMD,SUBSTR(item1Row.KAIHOGATA_CANCEL_YMD,7,2),NULL),

                        item1Row.KANWACARE_FLG                ,
                        --item1Row.KANWACARE_BED_SU             ,
                        TO_CHAR(item1Row.KANWACARE_BED_SU,'FM0009'),

                        NVL2(item1Row.KANWACARE_SHONIN_YMD,SUBSTR(item1Row.KANWACARE_SHONIN_YMD,1,4),NULL),
                        NVL2(item1Row.KANWACARE_SHONIN_YMD,SUBSTR(item1Row.KANWACARE_SHONIN_YMD,5,2),NULL),
                        NVL2(item1Row.KANWACARE_SHONIN_YMD,SUBSTR(item1Row.KANWACARE_SHONIN_YMD,7,2),NULL),
                        NVL2(item1Row.KANWACARE_CANCEL_YMD,SUBSTR(item1Row.KANWACARE_CANCEL_YMD,1,4),NULL),
                        NVL2(item1Row.KANWACARE_CANCEL_YMD,SUBSTR(item1Row.KANWACARE_CANCEL_YMD,5,2),NULL),
                        NVL2(item1Row.KANWACARE_CANCEL_YMD,SUBSTR(item1Row.KANWACARE_CANCEL_YMD,7,2),NULL),

                        item1Row.YAKUZAIKANRI_FLG             ,

                        NVL2(item1Row.YAKUZAIKANRI_SHONIN_YMD,SUBSTR(item1Row.YAKUZAIKANRI_SHONIN_YMD,1,4),NULL),
                        NVL2(item1Row.YAKUZAIKANRI_SHONIN_YMD,SUBSTR(item1Row.YAKUZAIKANRI_SHONIN_YMD,5,2),NULL),
                        NVL2(item1Row.YAKUZAIKANRI_SHONIN_YMD,SUBSTR(item1Row.YAKUZAIKANRI_SHONIN_YMD,7,2),NULL),
                        NVL2(item1Row.YAKUZAIKANRI_CANCEL_YMD,SUBSTR(item1Row.YAKUZAIKANRI_CANCEL_YMD,1,4),NULL),
                        NVL2(item1Row.YAKUZAIKANRI_CANCEL_YMD,SUBSTR(item1Row.YAKUZAIKANRI_CANCEL_YMD,5,2),NULL),
                        NVL2(item1Row.YAKUZAIKANRI_CANCEL_YMD,SUBSTR(item1Row.YAKUZAIKANRI_CANCEL_YMD,7,2),NULL),

                        item1Row.RNSKNS_KKN1_FLG              ,

                        NVL2(item1Row.RNSKNS_KKN1_SHONIN_YMD,SUBSTR(item1Row.RNSKNS_KKN1_SHONIN_YMD,1,4),NULL),
                        NVL2(item1Row.RNSKNS_KKN1_SHONIN_YMD,SUBSTR(item1Row.RNSKNS_KKN1_SHONIN_YMD,5,2),NULL),
                        NVL2(item1Row.RNSKNS_KKN1_SHONIN_YMD,SUBSTR(item1Row.RNSKNS_KKN1_SHONIN_YMD,7,2),NULL),
                        NVL2(item1Row.RNSKNS_KKN1_CANCEL_YMD,SUBSTR(item1Row.RNSKNS_KKN1_CANCEL_YMD,1,4),NULL),
                        NVL2(item1Row.RNSKNS_KKN1_CANCEL_YMD,SUBSTR(item1Row.RNSKNS_KKN1_CANCEL_YMD,5,2),NULL),
                        NVL2(item1Row.RNSKNS_KKN1_CANCEL_YMD,SUBSTR(item1Row.RNSKNS_KKN1_CANCEL_YMD,7,2),NULL),

                        item1Row.RNSKNS_KKN2_FLG              ,
                        vKyryk1ShirecId,
                        vKyryk1ShiCd,
                        NULL,
                        vKyryk2ShirecId,
                        vKyryk2ShiCd,
                        NULL,

                        NVL2(item1Row.RNSKNS_KKN2_SHONIN_YMD,SUBSTR(item1Row.RNSKNS_KKN2_SHONIN_YMD,1,4),NULL),
                        NVL2(item1Row.RNSKNS_KKN2_SHONIN_YMD,SUBSTR(item1Row.RNSKNS_KKN2_SHONIN_YMD,5,2),NULL),
                        NVL2(item1Row.RNSKNS_KKN2_SHONIN_YMD,SUBSTR(item1Row.RNSKNS_KKN2_SHONIN_YMD,7,2),NULL),
                        NVL2(item1Row.RNSKNS_KKN2_CANCEL_YMD,SUBSTR(item1Row.RNSKNS_KKN2_CANCEL_YMD,1,4),NULL),
                        NVL2(item1Row.RNSKNS_KKN2_CANCEL_YMD,SUBSTR(item1Row.RNSKNS_KKN2_CANCEL_YMD,5,2),NULL),
                        NVL2(item1Row.RNSKNS_KKN2_CANCEL_YMD,SUBSTR(item1Row.RNSKNS_KKN2_CANCEL_YMD,7,2),NULL),

                        item1Row.RNSKNS_KYRYK_FLG             ,

                        NVL2(item1Row.RNSKNS_KYRYK_SHONIN_YMD,SUBSTR(item1Row.RNSKNS_KYRYK_SHONIN_YMD,1,4),NULL),
                        NVL2(item1Row.RNSKNS_KYRYK_SHONIN_YMD,SUBSTR(item1Row.RNSKNS_KYRYK_SHONIN_YMD,5,2),NULL),
                        NVL2(item1Row.RNSKNS_KYRYK_SHONIN_YMD,SUBSTR(item1Row.RNSKNS_KYRYK_SHONIN_YMD,7,2),NULL),
                        NVL2(item1Row.RNSKNS_KYRYK_CANCEL_YMD,SUBSTR(item1Row.RNSKNS_KYRYK_CANCEL_YMD,1,4),NULL),
                        NVL2(item1Row.RNSKNS_KYRYK_CANCEL_YMD,SUBSTR(item1Row.RNSKNS_KYRYK_CANCEL_YMD,5,2),NULL),
                        NVL2(item1Row.RNSKNS_KYRYK_CANCEL_YMD,SUBSTR(item1Row.RNSKNS_KYRYK_CANCEL_YMD,7,2),NULL),

                        item1Row.SENSHIN_1_20_FLG             ,
                        
                        --������2012/10/12 CP000126�̑Ή�
                        DECODE(SUBSTR(item1Row.SENSHIN_CD_01, 4, 1), '0', SUBSTR(item1Row.SENSHIN_CD_01, 1, 3), item1Row.SENSHIN_CD_01),
                        DECODE(SUBSTR(item1Row.SENSHIN_CD_02, 4, 1), '0', SUBSTR(item1Row.SENSHIN_CD_02, 1, 3), item1Row.SENSHIN_CD_02),
                        DECODE(SUBSTR(item1Row.SENSHIN_CD_03, 4, 1), '0', SUBSTR(item1Row.SENSHIN_CD_03, 1, 3), item1Row.SENSHIN_CD_03),
                        DECODE(SUBSTR(item1Row.SENSHIN_CD_04, 4, 1), '0', SUBSTR(item1Row.SENSHIN_CD_04, 1, 3), item1Row.SENSHIN_CD_04),
                        DECODE(SUBSTR(item1Row.SENSHIN_CD_05, 4, 1), '0', SUBSTR(item1Row.SENSHIN_CD_05, 1, 3), item1Row.SENSHIN_CD_05),
                        DECODE(SUBSTR(item1Row.SENSHIN_CD_06, 4, 1), '0', SUBSTR(item1Row.SENSHIN_CD_06, 1, 3), item1Row.SENSHIN_CD_06),
                        DECODE(SUBSTR(item1Row.SENSHIN_CD_07, 4, 1), '0', SUBSTR(item1Row.SENSHIN_CD_07, 1, 3), item1Row.SENSHIN_CD_07),
                        DECODE(SUBSTR(item1Row.SENSHIN_CD_08, 4, 1), '0', SUBSTR(item1Row.SENSHIN_CD_08, 1, 3), item1Row.SENSHIN_CD_08),
                        DECODE(SUBSTR(item1Row.SENSHIN_CD_09, 4, 1), '0', SUBSTR(item1Row.SENSHIN_CD_09, 1, 3), item1Row.SENSHIN_CD_09),
                        DECODE(SUBSTR(item1Row.SENSHIN_CD_10, 4, 1), '0', SUBSTR(item1Row.SENSHIN_CD_10, 1, 3), item1Row.SENSHIN_CD_10),
                        DECODE(SUBSTR(item1Row.SENSHIN_CD_11, 4, 1), '0', SUBSTR(item1Row.SENSHIN_CD_11, 1, 3), item1Row.SENSHIN_CD_11),
                        DECODE(SUBSTR(item1Row.SENSHIN_CD_12, 4, 1), '0', SUBSTR(item1Row.SENSHIN_CD_12, 1, 3), item1Row.SENSHIN_CD_12),
                        DECODE(SUBSTR(item1Row.SENSHIN_CD_13, 4, 1), '0', SUBSTR(item1Row.SENSHIN_CD_13, 1, 3), item1Row.SENSHIN_CD_13),
                        DECODE(SUBSTR(item1Row.SENSHIN_CD_14, 4, 1), '0', SUBSTR(item1Row.SENSHIN_CD_14, 1, 3), item1Row.SENSHIN_CD_14),
                        DECODE(SUBSTR(item1Row.SENSHIN_CD_15, 4, 1), '0', SUBSTR(item1Row.SENSHIN_CD_15, 1, 3), item1Row.SENSHIN_CD_15),
                        DECODE(SUBSTR(item1Row.SENSHIN_CD_16, 4, 1), '0', SUBSTR(item1Row.SENSHIN_CD_16, 1, 3), item1Row.SENSHIN_CD_16),
                        DECODE(SUBSTR(item1Row.SENSHIN_CD_17, 4, 1), '0', SUBSTR(item1Row.SENSHIN_CD_17, 1, 3), item1Row.SENSHIN_CD_17),
                        DECODE(SUBSTR(item1Row.SENSHIN_CD_18, 4, 1), '0', SUBSTR(item1Row.SENSHIN_CD_18, 1, 3), item1Row.SENSHIN_CD_18),
                        DECODE(SUBSTR(item1Row.SENSHIN_CD_19, 4, 1), '0', SUBSTR(item1Row.SENSHIN_CD_19, 1, 3), item1Row.SENSHIN_CD_19),
                        DECODE(SUBSTR(item1Row.SENSHIN_CD_20, 4, 1), '0', SUBSTR(item1Row.SENSHIN_CD_20, 1, 3), item1Row.SENSHIN_CD_20),
                        --item1Row.SENSHIN_CD_01                ,
                        --item1Row.SENSHIN_CD_02                ,
                        --item1Row.SENSHIN_CD_03                ,
                        --item1Row.SENSHIN_CD_04                ,
                        --item1Row.SENSHIN_CD_05                ,
                        --item1Row.SENSHIN_CD_06                ,
                        --item1Row.SENSHIN_CD_07                ,
                        --item1Row.SENSHIN_CD_08                ,
                        --item1Row.SENSHIN_CD_09                ,
                        --item1Row.SENSHIN_CD_10                ,
                        --item1Row.SENSHIN_CD_11                ,
                        --item1Row.SENSHIN_CD_12                ,
                        --item1Row.SENSHIN_CD_13                ,
                        --item1Row.SENSHIN_CD_14                ,
                        --item1Row.SENSHIN_CD_15                ,
                        --item1Row.SENSHIN_CD_16                ,
                        --item1Row.SENSHIN_CD_17                ,
                        --item1Row.SENSHIN_CD_18                ,
                        --item1Row.SENSHIN_CD_19                ,
                        --item1Row.SENSHIN_CD_20                ,
                        --������2012/10/12 CP000126�̑Ή�
                        item1Row.SNTNIRY_FLG                  ,
                        item1Row.SNTNIRY_CD_01                ,
                        item1Row.SNTNIRY_CD_02                ,
                        item1Row.SNTNIRY_CD_03                ,
                        item1Row.SNTNIRY_CD_04                ,
                        item1Row.SNTNIRY_CD_05                ,
                        item1Row.SNTNIRY_CD_06                ,
                        item1Row.SNTNIRY_CD_07                ,
                        item1Row.SNTNIRY_CD_08                ,
                        item1Row.SNTNIRY_CD_09                ,
                        item1Row.SNTNIRY_CD_10                ,
                        item1Row.SNTNIRY_CD_11                ,
                        item1Row.SNTNIRY_CD_12                ,
                        item1Row.SNTNIRY_CD_13                ,
                        item1Row.SNTNIRY_CD_14                ,
                        item1Row.SNTNIRY_CD_15                ,
                        item1Row.SNTNIRY_CD_16                ,
                        item1Row.SNTNIRY_CD_17                ,
                        item1Row.SNTNIRY_CD_18                ,
                        item1Row.SNTNIRY_CD_19                ,
                        item1Row.SNTNIRY_CD_20                ,
                        item1Row.HMNKNG_FLG                   ,
                        item1Row.HMNKNG_REC_ID                ,
                        item1Row.HMNKNG_SHI_CD                ,
                        NULL,
                        item1Row.SEISHIKI_SHI_NM30            ,
                        item1Row.IPPAN_FLG                    ,
                        item1Row.IPPAN_KNG_SBT_CD             ,
                        NULL,
                        --item1Row.IPPAN_BED_SU                 ,
                        TO_CHAR(item1Row.IPPAN_BED_SU,'FM0009'),
                        NULL,
                        NULL,
                        NULL,
                        NULL,
                        --item1Row.IPPAN_GOKEI_BED_SU           ,
                        TO_CHAR(item1Row.IPPAN_GOKEI_BED_SU,'FM0009'),
                        item1Row.RYOYO_FLG                    ,
                        item1Row.RYOYO_IRY_KNG_SBT_CD         ,
                        NULL,
                        --item1Row.RYOYO_IRY_BED_SU             ,
                        TO_CHAR(item1Row.RYOYO_IRY_BED_SU,'FM0009'),

                        NVL2(item1Row.RYOYO_IRY_SHONIN_YMD,SUBSTR(item1Row.RYOYO_IRY_SHONIN_YMD,1,4),NULL),
                        NVL2(item1Row.RYOYO_IRY_SHONIN_YMD,SUBSTR(item1Row.RYOYO_IRY_SHONIN_YMD,5,2),NULL),
                        NVL2(item1Row.RYOYO_IRY_SHONIN_YMD,SUBSTR(item1Row.RYOYO_IRY_SHONIN_YMD,7,2),NULL),
                        NVL2(item1Row.RYOYO_IRY_CANCEL_YMD,SUBSTR(item1Row.RYOYO_IRY_CANCEL_YMD,1,4),NULL),
                        NVL2(item1Row.RYOYO_IRY_CANCEL_YMD,SUBSTR(item1Row.RYOYO_IRY_CANCEL_YMD,5,2),NULL),
                        NVL2(item1Row.RYOYO_IRY_CANCEL_YMD,SUBSTR(item1Row.RYOYO_IRY_CANCEL_YMD,7,2),NULL),

                        item1Row.RYOYO_KIG_KNG_SBT_CD         ,
                        NULL,
                        --item1Row.RYOYO_KIG_BED_SU             ,
                        TO_CHAR(item1Row.RYOYO_KIG_BED_SU,'FM0009'),

                        NVL2(item1Row.RYOYO_KIG_SHONIN_YMD,SUBSTR(item1Row.RYOYO_KIG_SHONIN_YMD,1,4),NULL),
                        NVL2(item1Row.RYOYO_KIG_SHONIN_YMD,SUBSTR(item1Row.RYOYO_KIG_SHONIN_YMD,5,2),NULL),
                        NVL2(item1Row.RYOYO_KIG_SHONIN_YMD,SUBSTR(item1Row.RYOYO_KIG_SHONIN_YMD,7,2),NULL),
                        NVL2(item1Row.RYOYO_KIG_CANCEL_YMD,SUBSTR(item1Row.RYOYO_KIG_CANCEL_YMD,1,4),NULL),
                        NVL2(item1Row.RYOYO_KIG_CANCEL_YMD,SUBSTR(item1Row.RYOYO_KIG_CANCEL_YMD,5,2),NULL),
                        NVL2(item1Row.RYOYO_KIG_CANCEL_YMD,SUBSTR(item1Row.RYOYO_KIG_CANCEL_YMD,7,2),NULL),
                        NULL,
                        --item1Row.RYOYO_GOKEI_BED_SU           ,
                        TO_CHAR(item1Row.RYOYO_GOKEI_BED_SU,'FM0009'),
                        NULL,
                        NULL,
                        NULL,
                        item1Row.RYOYO_KANI_KBN_CD            ,
                        NULL,
                        NULL,
                        NULL,
                        NULL,
                        NULL,
                        NULL,
                        NULL,
                        NULL,
                        NULL,
                        NULL,
                        NULL,
                        NULL,
                        NULL,
                        NULL,
                        NULL,
                        NULL,
                        NULL,
                        NULL,
                        NULL,
                        NULL,
                        NULL,
                        item1Row.CAREMIXTO_KBN_CD             ,
                        item1Row.SEISHIN_FLG                  ,
                        item1Row.SEISHIN_KNG_SBT_CD           ,
                        NULL,
                        --item1Row.SEISHIN_BED_SU               ,
                        TO_CHAR(item1Row.SEISHIN_BED_SU,'FM0009'),
                        NULL,
                        NULL,
                        NULL,
                        NULL,
                        --item1Row.SEISHIN_GOKEI_BED_SU         ,
                        TO_CHAR(item1Row.SEISHIN_GOKEI_BED_SU,'FM0009'),
                        item1Row.KEKKAKU_FLG                  ,
                        item1Row.KEKKAKU_KNG_SBT_CD           ,
                        NULL,
                        --item1Row.KEKKAKU_BED_SU               ,
                        TO_CHAR(item1Row.KEKKAKU_BED_SU,'FM0009'),
                        item1Row.KANSEN_FLG                   ,
                        NULL,
                        --item1Row.KANSEN_BED_SU                ,
                        TO_CHAR(item1Row.KANSEN_BED_SU,'FM0009'),
                        NVL2(item1Row.KAISETSU_YM,SUBSTR(item1Row.KAISETSU_YM,1,4),NULL),
                        NVL2(item1Row.KAISETSU_YM,SUBSTR(item1Row.KAISETSU_YM,5,2),NULL),
                        NULL,
                        NVL2(iTensoYMD,SUBSTR(iTensoYMD,1,4),NULL),
                        NVL2(iTensoYMD,SUBSTR(iTensoYMD,5,2),NULL),
                        NVL2(iTensoYMD,SUBSTR(iTensoYMD,7,2),NULL),
                        NVL2(item1Row.UPD_EIGY_YMD,SUBSTR(item1Row.UPD_EIGY_YMD,1,4),NULL),
                        NVL2(item1Row.UPD_EIGY_YMD,SUBSTR(item1Row.UPD_EIGY_YMD,5,2),NULL),
                        NVL2(item1Row.UPD_EIGY_YMD,SUBSTR(item1Row.UPD_EIGY_YMD,7,2),NULL),
                        NULL,
                        iOPE_CD,
                        iDATE,
                        iPGM_ID,
                        iOPE_CD,
                        iDATE,
                        iPGM_ID
                   );

          END LOOP;
          CLOSE item1CSR;
    END IF;
    COMMIT;

    -- �I�����O�o��
     ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'PL/SQL End',PGM_ID || '�̏������I�����܂����B',iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

    oROW_COUNT := -1;

    return 0;
    -- ��O����
  EXCEPTION

    -- ���̑��G���[
    WHEN OTHERS THEN

    IF item1CSR%ISOPEN THEN
      CLOSE item1CSR;
    END IF;

      W_ERR_INF_RCD.ERR_CD     := TO_CHAR(SQLCODE);
      W_ERR_INF_RCD.ERR_MSG     := SUBSTR(SQLERRM, 0, 500);
      W_ERR_INF_RCD.ERR_KEY_INF   := SUBSTR('iShimeKind:' || iShimeKind , 0,500);
      W_INDEX_N           := W_ERR_INF_TBL.COUNT + 1;
      W_ERR_INF_TBL.EXTEND;
      W_ERR_INF_TBL(W_INDEX_N)   := W_ERR_INF_RCD;

      OPEN oOUT_ERR_INF_CSR FOR
        SELECT * FROM TABLE(W_ERR_INF_TBL);

      ROLLBACK;

      --�G���[���O�̓o�^
      ULT_INSERT_LOG_TABLE('ERROR',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'ERROR_INFO',W_ERR_INF_RCD.ERR_MSG,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

      return 1;
END;

END;
/
