CREATE OR REPLACE PACKAGE BT010301B001_KJN
/* **********************************************************
 *  Copyright(c) 2011 beyond, INTEC Inc. All rights reserved.
 * **********************************************************/
AUTHID CURRENT_USER
IS
    /*** �J�[�\���^ ***************************************************************/
    -- �G���[���i�[�p�J�[�\���^
    TYPE ERR_INF_CSR        IS REF CURSOR;

    /*
    ************************************************************************
    *  �l�폜����
    *  DEL_SHI_DATA
    ************************************************************************
    */
    FUNCTION DEL_KJN_DATA(
    
        iShimeYm IN CHAR,
        iShoriEigyoBi IN CHAR,
        
        iShitenEigyoshoNm IN TT_RRK_KJN_KINMUSAKI.SHITEN_EIGYOSHO_NM%TYPE,              -- �����쐬�p�@�x�X�c�Ə���
        iMrNm IN TT_RRK_KJN_KINMUSAKI.MR_NM%TYPE,                                       -- �����쐬�p�@MR��
        iChosaYmd IN TT_RRK_KJN_KINMUSAKI.CHOSA_YMD%TYPE,                               -- �����쐬�p�@�����N����
        
        iIP_ADDR    IN TL_STORED_SHORI.IP%TYPE,                                         -- ���s�[��IP�A�h���X
        iWINDOWS_LOGIN_USER    IN TL_STORED_SHORI.WINDOWS_LOGIN_USER%TYPE,              -- ���s�[��OS���[�U�[
        oROW_COUNT            OUT NUMBER,                                               -- �X�V����
        oOUT_ERR_INF_CSR     OUT ERR_INF_CSR,                                           -- �G���[���J�[�\��
        iOPE_CD        IN TT_SISN_KJN.UPD_OPE_CD%TYPE,                                  -- �I�y���[�^�R�[�h
        iPGM_ID        IN TT_SISN_KJN.UPD_PGM_ID%TYPE,                                  -- �@�\ID
        iDATE        IN TT_SISN_KJN.UPD_DATE%TYPE                                       -- ��������
    
    ) RETURN NUMBER;

END;
/

CREATE OR REPLACE PACKAGE BODY BT010301B001_KJN
/* **********************************************************
 *  Copyright(c) 2011 beyond, INTEC Inc. All rights reserved.
 * **********************************************************/
IS


    /*
    ************************************************************************
    *  �l�폜����
    *  DEL_SHI_DATA
    ************************************************************************
    */
    FUNCTION DEL_KJN_DATA(
    
        iShimeYm IN CHAR,
        iShoriEigyoBi IN CHAR,

        iShitenEigyoshoNm IN TT_RRK_KJN_KINMUSAKI.SHITEN_EIGYOSHO_NM%TYPE,              -- �����쐬�p�@�x�X�c�Ə���
        iMrNm IN TT_RRK_KJN_KINMUSAKI.MR_NM%TYPE,                                       -- �����쐬�p�@MR��
        iChosaYmd IN TT_RRK_KJN_KINMUSAKI.CHOSA_YMD%TYPE,                               -- �����쐬�p�@�����N����
        
        iIP_ADDR    IN TL_STORED_SHORI.IP%TYPE,                     -- ���s�[��IP�A�h���X
        iWINDOWS_LOGIN_USER    IN TL_STORED_SHORI.WINDOWS_LOGIN_USER%TYPE, -- ���s�[��OS���[�U�[
        oROW_COUNT            OUT NUMBER,              -- �X�V����
        oOUT_ERR_INF_CSR     OUT ERR_INF_CSR,          -- �G���[���J�[�\��
        iOPE_CD        IN TT_SISN_KJN.UPD_OPE_CD%TYPE,             -- �I�y���[�^�R�[�h
        iPGM_ID        IN TT_SISN_KJN.UPD_PGM_ID%TYPE,             -- �@�\ID
        iDATE        IN TT_SISN_KJN.UPD_DATE%TYPE                -- ��������
    
    ) RETURN NUMBER IS

    /************************************************************************/
    /*                              �G���[����                              */
    /************************************************************************/
    PGM_ID  VARCHAR2(50) := 'BT010301B001.DEL_KJN_DATA';
    W_INDEX_N                     NUMBER(10) := 0;
    W_ERR_INF_TBL                 TYPE_ERR_INFO_TBL := TYPE_ERR_INFO_TBL();
    W_ERR_INF_RCD                 TYPE_ERR_INFO_RCD := TYPE_ERR_INFO_RCD(NULL,NULL,NULL,NULL);

    -- NULL ����p
    vNULL VARCHAR2(1) := NULL;

    -- �o���N�t�F�b�`�擾�T�C�Y
    BULK_SIZE CONSTANT PLS_INTEGER := 1000;

    TYPE t_RecID_Tbl IS TABLE OF TT_SISN_KJN.REC_ID%TYPE;
    TYPE t_KjnCD_Tbl IS TABLE OF TT_SISN_KJN.KJN_CD%TYPE;
    TYPE t_KinmusakiRecID_Tbl IS TABLE OF TT_SISN_KJN_KINMUSAKI.KINMUSAKI_REC_ID%TYPE;
    TYPE t_KinmusakiShiCD_Tbl IS TABLE OF TT_SISN_KJN_KINMUSAKI.KINMUSAKI_SHI_CD%TYPE;
    
    v_t_RecIdList t_RecID_Tbl;
    v_t_KjnCdList t_KjnCD_Tbl;
    v_t_kinmusakiRecIdList t_KinmusakiRecID_Tbl;
    v_t_kinmusakiShiCdList t_KinmusakiShiCD_Tbl;

    -- ���l�폜���X�g
    -- �����R�[�h��`
    CURSOR c_DelKjnRec IS
            SELECT
             A.REC_ID
             , A.KJN_CD
             , A.DEL_YOTEI_RIYU_CD
             , A.DEL_NYURYOKU_USER_CD
             , A.CHOFUKU_AITSK_REC_ID
             , A.CHOFUKU_AITSK_KJN_CD
             , A.KAIKIN_KBN
             FROM
             TT_SISN_KJN A;

    TYPE t_DelKjn IS TABLE OF c_DelKjnRec%ROWTYPE INDEX BY BINARY_INTEGER;
    -- �t�F�b�`����
    v_t_DelKjn t_DelKjn;

    -- �����ISQL�J�[�\����`
    TYPE c_DelKjn  IS REF CURSOR;
    v_c_DelKjn c_DelKjn;

    -- ���w��X�g
    -- �����R�[�h��`
    CURSOR c_GakkaiListRec IS
            SELECT
             A.REC_ID
             , A.KJN_CD
             , A.GAKKAI_CD
             , A.GAKKAI_NENDO
             , 'FALSE' AITE_GAKKAI
             , 'FALSE' AITE_GAKKAI_DEL
             FROM
             TT_SISN_KJN_GAKKAI A;

    TYPE t_GakkaiList IS TABLE OF c_GakkaiListRec%ROWTYPE INDEX BY BINARY_INTEGER;
    -- �t�F�b�`����
    v_t_GakkaiList t_GakkaiList;

    -- �����ISQL�J�[�\����`
    TYPE c_GakkaiList  IS REF CURSOR;
    v_c_GakkaiList c_GakkaiList;

    -- �����ナ�X�g
    -- �����R�[�h��`
    CURSOR c_SenmoniListRec IS
            SELECT
             A.REC_ID
             , A.KJN_CD
             , A.SENMONI_CD
             , A.SENMONI_FLG
             , A.SENMONI_KEISAI_YMD
             , A.NINTEII_FLG
             , A.NINTEII_KEISAI_YMD
             , A.SHIDOI_FLG
             , A.SHIDOI_KEISAI_YMD
             , 'FALSE' AITE_SENMONI
             , 'FALSE' AITE_SENMONI_SOSHITSU
             FROM
             TT_SISN_KJN_SENMONI A;

    TYPE t_SenmoniList IS TABLE OF c_SenmoniListRec%ROWTYPE INDEX BY BINARY_INTEGER;
    -- �t�F�b�`����
    v_t_SenmoniList t_SenmoniList;

    -- �����ISQL�J�[�\����`
    TYPE c_SenmoniList  IS REF CURSOR;
    v_c_SenmoniList c_SenmoniList;

    -- ��DCFDNF���X�g
    -- �����R�[�h��`
    CURSOR c_DcfDnfListRec IS
            SELECT
             A.REC_ID
             , A.KJN_CD
             , B.DEL_NYURYOKU_USER_CD
             FROM
             TT_SISN_KJN A
             INNER JOIN TT_SISN_KJN B
             ON A.DCFCHOFUKU_REC_ID = B.REC_ID
             AND A.DCFCHOFUKU_KJN_CD = B.KJN_CD
             WHERE A.DCFCHOFUKU_REC_ID IS NOT NULL
             AND A.DCFCHOFUKU_KJN_CD IS NOT NULL
             AND A.REC_ID = '05'
             AND A.DEL_FLG IS NULL
             AND A.DEL_YOTEI_RIYU_CD IS NULL;

    TYPE t_DcfDnfList IS TABLE OF c_DcfDnfListRec%ROWTYPE INDEX BY BINARY_INTEGER;
    -- �t�F�b�`����
    v_t_DcfDnfList t_DcfDnfList;

    -- �����ISQL�J�[�\����`
    TYPE c_DcfDnfList IS REF CURSOR;
    v_c_DcfDnfList c_DcfDnfList;


	-- �o�^�N���i�w����������쐬�p�j
	vTrkYm TT_RRK_KJN_GAKKAI.TRK_YM%TYPE;

    -- �����폜�l���X�g���擾����SQL
    vSQL_DEL_LIST VARCHAR2(2000);
    -- �폜�t���O�𗧂Ă�
    vSQL_UPD_DEL_FLG VARCHAR2(2000);
    -- ��\�җ����쐬
    vSQL_INSERT_RRK_DAIHYO VARCHAR2(2000);
    -- �w��ꗗ�擾
    vSQL_GAKKAI_LIST VARCHAR2(2000);
    -- �w��̈ړ�
    vSQL_INSERT_SISN_GAKKAI VARCHAR2(2000);
    -- �w��̗����쐬
    vSQL_INSERT_RRK_GAKKAI VARCHAR2(2000);
    -- �w��̕���
    vSQL_UPD_GAKKAI_FUKATSU VARCHAR2(2000);
    -- ���㗚���쐬
    vSQL_INSERT_RRK_SENMONI VARCHAR2(2000);
    -- ����ꗗ�擾
    vSQL_SENMONI_LIST VARCHAR2(2000);
    -- ����ړ����D��l�R�[�h���擾
    vSQL_YUSEN_KJN_CD VARCHAR2(2000);
    -- ����X�V
    vSQL_UPDATE_SISN_SENMONI VARCHAR2(2000);
    -- ����o�^
    vSQL_INSERT_SISN_SENMONI VARCHAR2(2000);
    -- �폜�l�Ζ���ސE
    vSQL_UPDATE_TAISHOKU VARCHAR2(2000);
    -- ��\�҂̃N���A
    vSQL_UPDATE_DAIHYO VARCHAR2(2000);
    -- �������X�g���O�{�݃e�[�u�������폜
    vSQL_DEL_GETSUJI_KJN VARCHAR2(2000);
    -- �D��l�R�[�h
    vYusenKjnCd TT_SISN_KJN.KJN_CD%TYPE;
    -- DCF�d�������i����l�j��DNF�l�i�폜�A�폜�\��ł��Ȃ��j��񃊃X�g���擾����
    vSQL_DCFDNF_LIST VARCHAR2(2000);
    vSQL_UPDATE_DCFCHOFUKU VARCHAR2(2000);
    vSQL_INSERT_RRK_DCFCHOFUKU VARCHAR2(2000);

    BEGIN
    
        -- �J�n���O�o��
        ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'PL/SQL Start',PGM_ID || '�̏������J�n���܂��B',iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);
        
        -- �����폜�l���X�g���擾����
        -- ���I�r�p�k�g�ݗ���
        vSQL_DEL_LIST := NULL;
        vSQL_DEL_LIST := vSQL_DEL_LIST || 'SELECT ';
        vSQL_DEL_LIST := vSQL_DEL_LIST || ' A.REC_ID';
        vSQL_DEL_LIST := vSQL_DEL_LIST || ' , A.KJN_CD';
        vSQL_DEL_LIST := vSQL_DEL_LIST || ' , A.DEL_YOTEI_RIYU_CD';
        vSQL_DEL_LIST := vSQL_DEL_LIST || ' , A.DEL_NYURYOKU_USER_CD';
        vSQL_DEL_LIST := vSQL_DEL_LIST || ' , A.CHOFUKU_AITSK_REC_ID';
        vSQL_DEL_LIST := vSQL_DEL_LIST || ' , A.CHOFUKU_AITSK_KJN_CD';
        vSQL_DEL_LIST := vSQL_DEL_LIST || ' , A.KAIKIN_KBN';
        vSQL_DEL_LIST := vSQL_DEL_LIST || ' FROM';
        vSQL_DEL_LIST := vSQL_DEL_LIST || ' TT_SISN_KJN A';
        vSQL_DEL_LIST := vSQL_DEL_LIST || ' WHERE A.DEL_YM = :shimeYM';
        vSQL_DEL_LIST := vSQL_DEL_LIST || ' ORDER BY A.KJN_CD';
        -- �폜�t���O�𗧂Ă�
        vSQL_UPD_DEL_FLG := NULL;
        vSQL_UPD_DEL_FLG := vSQL_UPD_DEL_FLG || '  UPDATE TT_SISN_KJN';
        vSQL_UPD_DEL_FLG := vSQL_UPD_DEL_FLG || '     SET DEL_EIGY_YMD         = :ShoriEigyoBi,';
        vSQL_UPD_DEL_FLG := vSQL_UPD_DEL_FLG || '         DEL_FLG              = 1,';
        vSQL_UPD_DEL_FLG := vSQL_UPD_DEL_FLG || '         UPD_USER_CD          = :UserCd,';
        vSQL_UPD_DEL_FLG := vSQL_UPD_DEL_FLG || '         UPD_EIGY_YMD         = :ShoriEigyoBi,';
        vSQL_UPD_DEL_FLG := vSQL_UPD_DEL_FLG || '         UPD_OPE_CD           = :OpeCd,';
        vSQL_UPD_DEL_FLG := vSQL_UPD_DEL_FLG || '         UPD_DATE             = :UpdDate,';
        vSQL_UPD_DEL_FLG := vSQL_UPD_DEL_FLG || '         UPD_PGM_ID           = :PgmId';
        vSQL_UPD_DEL_FLG := vSQL_UPD_DEL_FLG || '   WHERE REC_ID               = :RecId';
        vSQL_UPD_DEL_FLG := vSQL_UPD_DEL_FLG || '     AND KJN_CD               = :KjnCd';

        -- �w��ꗗ�擾
        vSQL_GAKKAI_LIST := NULL;
        vSQL_GAKKAI_LIST := vSQL_GAKKAI_LIST || ' SELECT';
        vSQL_GAKKAI_LIST := vSQL_GAKKAI_LIST || ' A.REC_ID';
        vSQL_GAKKAI_LIST := vSQL_GAKKAI_LIST || ' , A.KJN_CD';
        vSQL_GAKKAI_LIST := vSQL_GAKKAI_LIST || ' , A.GAKKAI_CD';
        vSQL_GAKKAI_LIST := vSQL_GAKKAI_LIST || ' , A.GAKKAI_NENDO';
        vSQL_GAKKAI_LIST := vSQL_GAKKAI_LIST || ' , CASE WHEN A1.REC_ID IS NULL THEN ''FALSE'' ELSE ''TRUE'' END AITE_GAKKAI';
        vSQL_GAKKAI_LIST := vSQL_GAKKAI_LIST || ' , CASE WHEN A1.DEL_FLG IS NOT NULL THEN ''TRUE'' ELSE ''FALSE'' END AITE_GAKKAI_DEL';
        vSQL_GAKKAI_LIST := vSQL_GAKKAI_LIST || ' FROM';
        vSQL_GAKKAI_LIST := vSQL_GAKKAI_LIST || ' TT_SISN_KJN_GAKKAI A';
        vSQL_GAKKAI_LIST := vSQL_GAKKAI_LIST || ' LEFT OUTER JOIN TT_SISN_KJN_GAKKAI A1';
        vSQL_GAKKAI_LIST := vSQL_GAKKAI_LIST || '   ON A1.REC_ID = :ChofukuAiteRecId';
        vSQL_GAKKAI_LIST := vSQL_GAKKAI_LIST || '  AND A1.KJN_CD = :ChofukuAiteKjnCd';
        vSQL_GAKKAI_LIST := vSQL_GAKKAI_LIST || '  AND A.GAKKAI_CD = A1.GAKKAI_CD';
        vSQL_GAKKAI_LIST := vSQL_GAKKAI_LIST || '  AND A.GAKKAI_NENDO = A1.GAKKAI_NENDO';
        vSQL_GAKKAI_LIST := vSQL_GAKKAI_LIST || ' WHERE A.REC_ID = :RecId';
        vSQL_GAKKAI_LIST := vSQL_GAKKAI_LIST || ' AND A.KJN_CD = :KjnCd';
        vSQL_GAKKAI_LIST := vSQL_GAKKAI_LIST || ' AND A.DEL_FLG IS NULL';
        -- �w��̈ړ�
        vSQL_INSERT_SISN_GAKKAI := NULL;
        vSQL_INSERT_SISN_GAKKAI := vSQL_INSERT_SISN_GAKKAI || '  INSERT INTO TT_SISN_KJN_GAKKAI';
        vSQL_INSERT_SISN_GAKKAI := vSQL_INSERT_SISN_GAKKAI || '      (REC_ID';
        vSQL_INSERT_SISN_GAKKAI := vSQL_INSERT_SISN_GAKKAI || '      ,KJN_CD';
        vSQL_INSERT_SISN_GAKKAI := vSQL_INSERT_SISN_GAKKAI || '      ,GAKKAI_CD';
        vSQL_INSERT_SISN_GAKKAI := vSQL_INSERT_SISN_GAKKAI || '      ,GAKKAI_NENDO';
        vSQL_INSERT_SISN_GAKKAI := vSQL_INSERT_SISN_GAKKAI || '      ,DEL_FLG';
        vSQL_INSERT_SISN_GAKKAI := vSQL_INSERT_SISN_GAKKAI || '      ,DEL_EIGY_YMD';
        vSQL_INSERT_SISN_GAKKAI := vSQL_INSERT_SISN_GAKKAI || '      ,TRK_YM';
        vSQL_INSERT_SISN_GAKKAI := vSQL_INSERT_SISN_GAKKAI || '      ,TRK_FKT_EIGY_YMD';
        vSQL_INSERT_SISN_GAKKAI := vSQL_INSERT_SISN_GAKKAI || '      ,TRK_USER_CD';
        vSQL_INSERT_SISN_GAKKAI := vSQL_INSERT_SISN_GAKKAI || '      ,TRK_EIGY_YMD';
        vSQL_INSERT_SISN_GAKKAI := vSQL_INSERT_SISN_GAKKAI || '      ,UPD_USER_CD';
        vSQL_INSERT_SISN_GAKKAI := vSQL_INSERT_SISN_GAKKAI || '      ,UPD_EIGY_YMD';
        vSQL_INSERT_SISN_GAKKAI := vSQL_INSERT_SISN_GAKKAI || '      ,TRK_OPE_CD';
        vSQL_INSERT_SISN_GAKKAI := vSQL_INSERT_SISN_GAKKAI || '      ,TRK_DATE';
        vSQL_INSERT_SISN_GAKKAI := vSQL_INSERT_SISN_GAKKAI || '      ,TRK_PGM_ID';
        vSQL_INSERT_SISN_GAKKAI := vSQL_INSERT_SISN_GAKKAI || '      ,UPD_OPE_CD';
        vSQL_INSERT_SISN_GAKKAI := vSQL_INSERT_SISN_GAKKAI || '      ,UPD_DATE';
        vSQL_INSERT_SISN_GAKKAI := vSQL_INSERT_SISN_GAKKAI || '      ,UPD_PGM_ID)';
        vSQL_INSERT_SISN_GAKKAI := vSQL_INSERT_SISN_GAKKAI || '  VALUES';
        vSQL_INSERT_SISN_GAKKAI := vSQL_INSERT_SISN_GAKKAI || '      (:RecId';
        vSQL_INSERT_SISN_GAKKAI := vSQL_INSERT_SISN_GAKKAI || '      ,:KjnCd';
        vSQL_INSERT_SISN_GAKKAI := vSQL_INSERT_SISN_GAKKAI || '      ,:GakkaiCd';
        vSQL_INSERT_SISN_GAKKAI := vSQL_INSERT_SISN_GAKKAI || '      ,:GakkaiNendo';
        vSQL_INSERT_SISN_GAKKAI := vSQL_INSERT_SISN_GAKKAI || '      ,NULL';
        vSQL_INSERT_SISN_GAKKAI := vSQL_INSERT_SISN_GAKKAI || '      ,NULL';
        vSQL_INSERT_SISN_GAKKAI := vSQL_INSERT_SISN_GAKKAI || '      ,:TrkYm';
        vSQL_INSERT_SISN_GAKKAI := vSQL_INSERT_SISN_GAKKAI || '      ,:ShoriEigyoBi';
        vSQL_INSERT_SISN_GAKKAI := vSQL_INSERT_SISN_GAKKAI || '      ,:UserCd';
        vSQL_INSERT_SISN_GAKKAI := vSQL_INSERT_SISN_GAKKAI || '      ,:ShoriEigyoBi';
        vSQL_INSERT_SISN_GAKKAI := vSQL_INSERT_SISN_GAKKAI || '      ,:UserCd';
        vSQL_INSERT_SISN_GAKKAI := vSQL_INSERT_SISN_GAKKAI || '      ,:ShoriEigyoBi';
        vSQL_INSERT_SISN_GAKKAI := vSQL_INSERT_SISN_GAKKAI || '      ,:OPE_CD';
        vSQL_INSERT_SISN_GAKKAI := vSQL_INSERT_SISN_GAKKAI || '      ,:TRK_DATE';
        vSQL_INSERT_SISN_GAKKAI := vSQL_INSERT_SISN_GAKKAI || '      ,:PGM_ID';
        vSQL_INSERT_SISN_GAKKAI := vSQL_INSERT_SISN_GAKKAI || '      ,:OPE_CD';
        vSQL_INSERT_SISN_GAKKAI := vSQL_INSERT_SISN_GAKKAI || '      ,:UPD_DATE';
        vSQL_INSERT_SISN_GAKKAI := vSQL_INSERT_SISN_GAKKAI || '      ,:PGM_ID)';
        -- �w����쐬
        vSQL_INSERT_RRK_GAKKAI := NULL;
        vSQL_INSERT_RRK_GAKKAI := vSQL_INSERT_RRK_GAKKAI || '  INSERT INTO TT_RRK_KJN_GAKKAI';
        vSQL_INSERT_RRK_GAKKAI := vSQL_INSERT_RRK_GAKKAI || '      (SEQ';
        vSQL_INSERT_RRK_GAKKAI := vSQL_INSERT_RRK_GAKKAI || '      ,REC_ID';
        vSQL_INSERT_RRK_GAKKAI := vSQL_INSERT_RRK_GAKKAI || '      ,KJN_CD';
        vSQL_INSERT_RRK_GAKKAI := vSQL_INSERT_RRK_GAKKAI || '      ,GAKKAI_CD';
        vSQL_INSERT_RRK_GAKKAI := vSQL_INSERT_RRK_GAKKAI || '      ,GAKKAI_NENDO';
        vSQL_INSERT_RRK_GAKKAI := vSQL_INSERT_RRK_GAKKAI || '      ,DEL_FLG';
        vSQL_INSERT_RRK_GAKKAI := vSQL_INSERT_RRK_GAKKAI || '      ,DEL_EIGY_YMD';
        vSQL_INSERT_RRK_GAKKAI := vSQL_INSERT_RRK_GAKKAI || '      ,SHITEN_EIGYOSHO_NM';
        vSQL_INSERT_RRK_GAKKAI := vSQL_INSERT_RRK_GAKKAI || '      ,MR_NM';
        vSQL_INSERT_RRK_GAKKAI := vSQL_INSERT_RRK_GAKKAI || '      ,CHOSA_YMD';
        vSQL_INSERT_RRK_GAKKAI := vSQL_INSERT_RRK_GAKKAI || '      ,TRK_YM';
        vSQL_INSERT_RRK_GAKKAI := vSQL_INSERT_RRK_GAKKAI || '      ,GOMENTE_FLG';
        vSQL_INSERT_RRK_GAKKAI := vSQL_INSERT_RRK_GAKKAI || '      ,GOMENTE_CHK_OPE_CD';
        vSQL_INSERT_RRK_GAKKAI := vSQL_INSERT_RRK_GAKKAI || '      ,GOMENTE_CHK_USER_CD';
        vSQL_INSERT_RRK_GAKKAI := vSQL_INSERT_RRK_GAKKAI || '      ,GOMENTE_CHK_EIGY_YMD';
        vSQL_INSERT_RRK_GAKKAI := vSQL_INSERT_RRK_GAKKAI || '      ,TRK_FKT_EIGY_YMD';
        vSQL_INSERT_RRK_GAKKAI := vSQL_INSERT_RRK_GAKKAI || '      ,TRK_USER_CD';
        vSQL_INSERT_RRK_GAKKAI := vSQL_INSERT_RRK_GAKKAI || '      ,TRK_EIGY_YMD';
        vSQL_INSERT_RRK_GAKKAI := vSQL_INSERT_RRK_GAKKAI || '      ,UPD_USER_CD';
        vSQL_INSERT_RRK_GAKKAI := vSQL_INSERT_RRK_GAKKAI || '      ,UPD_EIGY_YMD';
        vSQL_INSERT_RRK_GAKKAI := vSQL_INSERT_RRK_GAKKAI || '      ,TRK_OPE_CD';
        vSQL_INSERT_RRK_GAKKAI := vSQL_INSERT_RRK_GAKKAI || '      ,TRK_DATE';
        vSQL_INSERT_RRK_GAKKAI := vSQL_INSERT_RRK_GAKKAI || '      ,TRK_PGM_ID';
        vSQL_INSERT_RRK_GAKKAI := vSQL_INSERT_RRK_GAKKAI || '      ,UPD_OPE_CD';
        vSQL_INSERT_RRK_GAKKAI := vSQL_INSERT_RRK_GAKKAI || '      ,UPD_DATE';
        vSQL_INSERT_RRK_GAKKAI := vSQL_INSERT_RRK_GAKKAI || '      ,UPD_PGM_ID)';
        vSQL_INSERT_RRK_GAKKAI := vSQL_INSERT_RRK_GAKKAI || '  VALUES';
        vSQL_INSERT_RRK_GAKKAI := vSQL_INSERT_RRK_GAKKAI || '      (SEQ_RIREKI_PK.NEXTVAL';
        vSQL_INSERT_RRK_GAKKAI := vSQL_INSERT_RRK_GAKKAI || '      ,:RecId';
        vSQL_INSERT_RRK_GAKKAI := vSQL_INSERT_RRK_GAKKAI || '      ,:KjnCd';
        vSQL_INSERT_RRK_GAKKAI := vSQL_INSERT_RRK_GAKKAI || '      ,:GakkaiCd';
        vSQL_INSERT_RRK_GAKKAI := vSQL_INSERT_RRK_GAKKAI || '      ,:GakkaiNendo';
        vSQL_INSERT_RRK_GAKKAI := vSQL_INSERT_RRK_GAKKAI || '      ,NULL';
        vSQL_INSERT_RRK_GAKKAI := vSQL_INSERT_RRK_GAKKAI || '      ,NULL';
        vSQL_INSERT_RRK_GAKKAI := vSQL_INSERT_RRK_GAKKAI || '      ,:ShitenEigyoshoNm';
        vSQL_INSERT_RRK_GAKKAI := vSQL_INSERT_RRK_GAKKAI || '      ,:MrNm';
        vSQL_INSERT_RRK_GAKKAI := vSQL_INSERT_RRK_GAKKAI || '      ,:ChosaYmd';
        vSQL_INSERT_RRK_GAKKAI := vSQL_INSERT_RRK_GAKKAI || '      ,:TrkYm';
        vSQL_INSERT_RRK_GAKKAI := vSQL_INSERT_RRK_GAKKAI || '      ,NULL';
        vSQL_INSERT_RRK_GAKKAI := vSQL_INSERT_RRK_GAKKAI || '      ,NULL';
        vSQL_INSERT_RRK_GAKKAI := vSQL_INSERT_RRK_GAKKAI || '      ,NULL';
        vSQL_INSERT_RRK_GAKKAI := vSQL_INSERT_RRK_GAKKAI || '      ,NULL';
        vSQL_INSERT_RRK_GAKKAI := vSQL_INSERT_RRK_GAKKAI || '      ,:ShoriEigyoBi';
        vSQL_INSERT_RRK_GAKKAI := vSQL_INSERT_RRK_GAKKAI || '      ,:UserCd';
        vSQL_INSERT_RRK_GAKKAI := vSQL_INSERT_RRK_GAKKAI || '      ,:ShoriEigyoBi';
        vSQL_INSERT_RRK_GAKKAI := vSQL_INSERT_RRK_GAKKAI || '      ,:UserCd';
        vSQL_INSERT_RRK_GAKKAI := vSQL_INSERT_RRK_GAKKAI || '      ,:ShoriEigyoBi';
        vSQL_INSERT_RRK_GAKKAI := vSQL_INSERT_RRK_GAKKAI || '      ,:OPE_CD';
        vSQL_INSERT_RRK_GAKKAI := vSQL_INSERT_RRK_GAKKAI || '      ,:TRK_DATE';
        vSQL_INSERT_RRK_GAKKAI := vSQL_INSERT_RRK_GAKKAI || '      ,:PGM_ID';
        vSQL_INSERT_RRK_GAKKAI := vSQL_INSERT_RRK_GAKKAI || '      ,:OPE_CD';
        vSQL_INSERT_RRK_GAKKAI := vSQL_INSERT_RRK_GAKKAI || '      ,:UPD_DATE';
        vSQL_INSERT_RRK_GAKKAI := vSQL_INSERT_RRK_GAKKAI || '      ,:PGM_ID)';

        -- �w��̕���
        vSQL_UPD_GAKKAI_FUKATSU := NULL;
        vSQL_UPD_GAKKAI_FUKATSU := vSQL_UPD_GAKKAI_FUKATSU || '  UPDATE TT_SISN_KJN_GAKKAI';
        vSQL_UPD_GAKKAI_FUKATSU := vSQL_UPD_GAKKAI_FUKATSU || '     SET DEL_FLG = NULL,';
        vSQL_UPD_GAKKAI_FUKATSU := vSQL_UPD_GAKKAI_FUKATSU || '         DEL_EIGY_YMD = NULL,';
        vSQL_UPD_GAKKAI_FUKATSU := vSQL_UPD_GAKKAI_FUKATSU || '         TRK_FKT_EIGY_YMD = :ShoriEigyoBi,';
        vSQL_UPD_GAKKAI_FUKATSU := vSQL_UPD_GAKKAI_FUKATSU || '         UPD_USER_CD = :UserCd,';
        vSQL_UPD_GAKKAI_FUKATSU := vSQL_UPD_GAKKAI_FUKATSU || '         UPD_EIGY_YMD = :ShoriEigyoBi,';
        vSQL_UPD_GAKKAI_FUKATSU := vSQL_UPD_GAKKAI_FUKATSU || '         UPD_OPE_CD = :OPE_CD,';
        vSQL_UPD_GAKKAI_FUKATSU := vSQL_UPD_GAKKAI_FUKATSU || '         UPD_DATE = :UPD_DATE,';
        vSQL_UPD_GAKKAI_FUKATSU := vSQL_UPD_GAKKAI_FUKATSU || '         UPD_PGM_ID = :PGM_ID';
        vSQL_UPD_GAKKAI_FUKATSU := vSQL_UPD_GAKKAI_FUKATSU || '   WHERE REC_ID = :RecId';
        vSQL_UPD_GAKKAI_FUKATSU := vSQL_UPD_GAKKAI_FUKATSU || '     AND KJN_CD = :KjnCd';
        vSQL_UPD_GAKKAI_FUKATSU := vSQL_UPD_GAKKAI_FUKATSU || '     AND GAKKAI_CD = :GakkaiCd';
        vSQL_UPD_GAKKAI_FUKATSU := vSQL_UPD_GAKKAI_FUKATSU || '     AND GAKKAI_NENDO = :GakkaiNendo';
		vSQL_UPD_GAKKAI_FUKATSU := vSQL_UPD_GAKKAI_FUKATSU || '  RETURNING TRK_YM INTO :TrkYm';

        -- ����ꗗ�擾
        vSQL_SENMONI_LIST := NULL;
        vSQL_SENMONI_LIST := vSQL_SENMONI_LIST || 'SELECT';
        vSQL_SENMONI_LIST := vSQL_SENMONI_LIST || ' A.REC_ID';
        vSQL_SENMONI_LIST := vSQL_SENMONI_LIST || ' , A.KJN_CD';
        vSQL_SENMONI_LIST := vSQL_SENMONI_LIST || ' , A.SENMONI_CD';
        vSQL_SENMONI_LIST := vSQL_SENMONI_LIST || ' , A.SENMONI_FLG';
        vSQL_SENMONI_LIST := vSQL_SENMONI_LIST || ' , A.SENMONI_KEISAI_YMD';
        vSQL_SENMONI_LIST := vSQL_SENMONI_LIST || ' , A.NINTEII_FLG';
        vSQL_SENMONI_LIST := vSQL_SENMONI_LIST || ' , A.NINTEII_KEISAI_YMD';
        vSQL_SENMONI_LIST := vSQL_SENMONI_LIST || ' , A.SHIDOI_FLG';
        vSQL_SENMONI_LIST := vSQL_SENMONI_LIST || ' , A.SHIDOI_KEISAI_YMD';
        vSQL_SENMONI_LIST := vSQL_SENMONI_LIST || ' , CASE WHEN A1.REC_ID IS NULL THEN ''FALSE'' ELSE ''TRUE'' END AITE_SENMONI';
        vSQL_SENMONI_LIST := vSQL_SENMONI_LIST || ' , CASE WHEN A1.SOSHITSU_FLG IS NULL THEN ''FALSE'' ELSE ''TRUE'' END AITE_SENMONI_SOSHITSU';
        vSQL_SENMONI_LIST := vSQL_SENMONI_LIST || ' FROM';
        vSQL_SENMONI_LIST := vSQL_SENMONI_LIST || ' TT_SISN_KJN_SENMONI A';
        vSQL_SENMONI_LIST := vSQL_SENMONI_LIST || ' LEFT OUTER JOIN TT_SISN_KJN_SENMONI A1';
        vSQL_SENMONI_LIST := vSQL_SENMONI_LIST || '   ON A1.REC_ID = :ChofukuAiteRecId';
        vSQL_SENMONI_LIST := vSQL_SENMONI_LIST || '  AND A1.KJN_CD = :ChofukuAiteKjnCd';
        vSQL_SENMONI_LIST := vSQL_SENMONI_LIST || '  AND A.SENMONI_CD = A1.SENMONI_CD';
        vSQL_SENMONI_LIST := vSQL_SENMONI_LIST || ' WHERE A.REC_ID = :recId';
        vSQL_SENMONI_LIST := vSQL_SENMONI_LIST || ' AND A.KJN_CD = :kjnCd';
        vSQL_SENMONI_LIST := vSQL_SENMONI_LIST || ' AND A.SOSHITSU_FLG IS NULL';
        -- ����ړ����D��l�R�[�h���擾
        vSQL_YUSEN_KJN_CD := NULL;
        vSQL_YUSEN_KJN_CD := vSQL_YUSEN_KJN_CD || 'SELECT';
        vSQL_YUSEN_KJN_CD := vSQL_YUSEN_KJN_CD || ' MIN(A.KJN_CD) AS KJN_CD';
        vSQL_YUSEN_KJN_CD := vSQL_YUSEN_KJN_CD || ' FROM';
        vSQL_YUSEN_KJN_CD := vSQL_YUSEN_KJN_CD || ' TT_SISN_KJN A';
        vSQL_YUSEN_KJN_CD := vSQL_YUSEN_KJN_CD || ' INNER JOIN TT_SISN_KJN_SENMONI B ';
        vSQL_YUSEN_KJN_CD := vSQL_YUSEN_KJN_CD || ' ON A.REC_ID = B.REC_ID';
        vSQL_YUSEN_KJN_CD := vSQL_YUSEN_KJN_CD || ' AND A.KJN_CD = B.KJN_CD';
        vSQL_YUSEN_KJN_CD := vSQL_YUSEN_KJN_CD || ' WHERE A.DEL_YM = :shimeYM';
        vSQL_YUSEN_KJN_CD := vSQL_YUSEN_KJN_CD || ' AND A.DEL_YOTEI_RIYU_CD = ''5''';
        vSQL_YUSEN_KJN_CD := vSQL_YUSEN_KJN_CD || ' AND A.CHOFUKU_AITSK_REC_ID = :chofukuRecId';
        vSQL_YUSEN_KJN_CD := vSQL_YUSEN_KJN_CD || ' AND A.CHOFUKU_AITSK_KJN_CD = :chofukuKjnCd';
        vSQL_YUSEN_KJN_CD := vSQL_YUSEN_KJN_CD || ' AND B.SENMONI_CD = :SenmoniCd';
        vSQL_YUSEN_KJN_CD := vSQL_YUSEN_KJN_CD || ' AND B.SOSHITSU_FLG IS NULL';
        -- ����X�V
        vSQL_UPDATE_SISN_SENMONI := NULL;
        vSQL_UPDATE_SISN_SENMONI := vSQL_UPDATE_SISN_SENMONI || '  UPDATE TT_SISN_KJN_SENMONI';
        vSQL_UPDATE_SISN_SENMONI := vSQL_UPDATE_SISN_SENMONI || '     SET SENMONI_FLG = :SENMONI_FLG,';
        vSQL_UPDATE_SISN_SENMONI := vSQL_UPDATE_SISN_SENMONI || '         SENMONI_KEISAI_YMD = :SENMONI_KEISAI_YMD,';
        vSQL_UPDATE_SISN_SENMONI := vSQL_UPDATE_SISN_SENMONI || '         NINTEII_FLG = :NINTEII_FLG,';
        vSQL_UPDATE_SISN_SENMONI := vSQL_UPDATE_SISN_SENMONI || '         NINTEII_KEISAI_YMD = :NINTEII_KEISAI_YMD,';
        vSQL_UPDATE_SISN_SENMONI := vSQL_UPDATE_SISN_SENMONI || '         SHIDOI_FLG = :SHIDOI_FLG,';
        vSQL_UPDATE_SISN_SENMONI := vSQL_UPDATE_SISN_SENMONI || '         SHIDOI_KEISAI_YMD = :SHIDOI_KEISAI_YMD,';
        vSQL_UPDATE_SISN_SENMONI := vSQL_UPDATE_SISN_SENMONI || '         SOSHITSU_FLG = NULL,';
        vSQL_UPDATE_SISN_SENMONI := vSQL_UPDATE_SISN_SENMONI || '         SOSHITSU_YMD = NULL,';
        vSQL_UPDATE_SISN_SENMONI := vSQL_UPDATE_SISN_SENMONI || '         TRK_FKT_EIGY_YMD =:UPD_EIGY_YMD,';
        vSQL_UPDATE_SISN_SENMONI := vSQL_UPDATE_SISN_SENMONI || '         UPD_USER_CD = :UPD_USER_CD,';
        vSQL_UPDATE_SISN_SENMONI := vSQL_UPDATE_SISN_SENMONI || '         UPD_EIGY_YMD =:UPD_EIGY_YMD,';
        vSQL_UPDATE_SISN_SENMONI := vSQL_UPDATE_SISN_SENMONI || '         UPD_OPE_CD = :UPD_OPE_CD,';
        vSQL_UPDATE_SISN_SENMONI := vSQL_UPDATE_SISN_SENMONI || '         UPD_DATE = :UPD_DATE,';
        vSQL_UPDATE_SISN_SENMONI := vSQL_UPDATE_SISN_SENMONI || '         UPD_PGM_ID = :UPD_PGM_ID';
        vSQL_UPDATE_SISN_SENMONI := vSQL_UPDATE_SISN_SENMONI || '  WHERE REC_ID = : REC_ID';
        vSQL_UPDATE_SISN_SENMONI := vSQL_UPDATE_SISN_SENMONI || '    AND KJN_CD = : KJN_CD';
        vSQL_UPDATE_SISN_SENMONI := vSQL_UPDATE_SISN_SENMONI || '    AND SENMONI_CD = : SENMONI_CD';

        -- ����o�^
        vSQL_INSERT_SISN_SENMONI := NULL;
        vSQL_INSERT_SISN_SENMONI := vSQL_INSERT_SISN_SENMONI || '  INSERT INTO TT_SISN_KJN_SENMONI(REC_ID,KJN_CD,SENMONI_CD,SENMONI_FLG,SENMONI_KEISAI_YMD,NINTEII_FLG,NINTEII_KEISAI_YMD,SHIDOI_FLG,SHIDOI_KEISAI_YMD,SOSHITSU_FLG,SOSHITSU_YMD,TRK_FKT_EIGY_YMD,TRK_USER_CD,TRK_EIGY_YMD,UPD_USER_CD,UPD_EIGY_YMD,TRK_OPE_CD,TRK_DATE,TRK_PGM_ID,UPD_OPE_CD,UPD_DATE,UPD_PGM_ID)VALUES(:REC_ID,:KJN_CD,:SENMONI_CD,:SENMONI_FLG,:SENMONI_KEISAI_YMD,:NINTEII_FLG,:NINTEII_KEISAI_YMD,:SHIDOI_FLG,:SHIDOI_KEISAI_YMD,NULL,NULL,:UPD_EIGY_YMD,:TRK_USER_CD,:TRK_EIGY_YMD,:UPD_USER_CD,:UPD_EIGY_YMD,:TRK_OPE_CD,:TRK_DATE,:TRK_PGM_ID,:UPD_OPE_CD,:UPD_DATE,:UPD_PGM_ID)';

        -- ���㗚���쐬
        vSQL_INSERT_RRK_SENMONI := '  INSERT INTO TT_RRK_KJN_SENMONI(SEQ, REC_ID,KJN_CD,SENMONI_CD,SHITEN_EIGYOSHO_NM,MR_NM,CHOSA_YMD,SENMONI_FLG,SENMONI_KEISAI_YMD,NINTEII_FLG,NINTEII_KEISAI_YMD,SHIDOI_FLG,SHIDOI_KEISAI_YMD,SOSHITSU_FLG,SOSHITSU_YMD,GOMENTE_FLG,GOMENTE_CHK_OPE_CD,GOMENTE_CHK_USER_CD,GOMENTE_CHK_EIGY_YMD,TRK_FKT_EIGY_YMD,TRK_USER_CD,TRK_EIGY_YMD,UPD_USER_CD,UPD_EIGY_YMD,TRK_OPE_CD,TRK_DATE,TRK_PGM_ID,UPD_OPE_CD,UPD_DATE,UPD_PGM_ID)VALUES(SEQ_RIREKI_PK.NEXTVAL, :REC_ID,:KJN_CD,:SENMONI_CD,:SHITEN_EIGYOSHO_NM,:MR_NM,:CHOSA_YMD,:SENMONI_FLG,:SENMONI_KEISAI_YMD,:NINTEII_FLG,:NINTEII_KEISAI_YMD,:SHIDOI_FLG,:SHIDOI_KEISAI_YMD,NULL,NULL,NULL,NULL,NULL,NULL,:UPD_EIGY_YMD,:TRK_USER_CD,:TRK_EIGY_YMD,:UPD_USER_CD,:UPD_EIGY_YMD,:TRK_OPE_CD,:TRK_DATE,:TRK_PGM_ID,:UPD_OPE_CD,:UPD_DATE,:UPD_PGM_ID)';

        -- ��\�җ����쐬
        vSQL_INSERT_RRK_DAIHYO := 'INSERT INTO TT_RRK_SHI_DAIHYO(SEQ,REC_ID,SHI_CD,SHITEN_EIGYOSHO_NM,MR_NM,CHOSA_YMD,DAIHYO_REC_ID,DAIHYO_KJN_CD,DAIHYO_NM,DAIHYO_NM_KANA,DAIHYO_YAKUSHOKU_CD,DAIHYO_SHOKUI_CD,GOMENTE_FLG,GOMENTE_CHK_OPE_CD,GOMENTE_CHK_USER_CD,GOMENTE_CHK_EIGY_YMD,TRK_USER_CD,TRK_EIGY_YMD,UPD_USER_CD,UPD_EIGY_YMD,TRK_OPE_CD,TRK_DATE,TRK_PGM_ID,UPD_OPE_CD,UPD_DATE,UPD_PGM_ID)VALUES(SEQ_RIREKI_PK.NEXTVAL,:RecId,:ShiCd,:ShitenEigyoshoNm,:MrNm,:ChosaYmd,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,:TrkUserCd,:TrkEigyYmd,:UpdUserCd,:UpdEigyYmd,:TrkOpeCd,:TrkDate,:TrkPgmId,:UpdOpeCd,:UpdDate,:UpdPgmId)';

        -- �폜�l�Ζ���ސE
        vSQL_UPDATE_TAISHOKU := NULL;
        vSQL_UPDATE_TAISHOKU := vSQL_UPDATE_TAISHOKU || '  UPDATE TT_SISN_KJN_KINMUSAKI';
        vSQL_UPDATE_TAISHOKU := vSQL_UPDATE_TAISHOKU || '     SET TAISHOKU_FLG = ''1'',';
        vSQL_UPDATE_TAISHOKU := vSQL_UPDATE_TAISHOKU || '         TAISHOKU_EIGY_YMD = :ShoriEigyoBi,';
        vSQL_UPDATE_TAISHOKU := vSQL_UPDATE_TAISHOKU || '         UPD_USER_CD = :UserCd,';
        vSQL_UPDATE_TAISHOKU := vSQL_UPDATE_TAISHOKU || '         UPD_EIGY_YMD = :ShoriEigyoBi,';
        vSQL_UPDATE_TAISHOKU := vSQL_UPDATE_TAISHOKU || '         UPD_OPE_CD = :OpeCd,';
        vSQL_UPDATE_TAISHOKU := vSQL_UPDATE_TAISHOKU || '         UPD_DATE = :UpdDate,';
        vSQL_UPDATE_TAISHOKU := vSQL_UPDATE_TAISHOKU || '         UPD_PGM_ID = :PgmId';
        vSQL_UPDATE_TAISHOKU := vSQL_UPDATE_TAISHOKU || '   WHERE REC_ID = :RecId';
        vSQL_UPDATE_TAISHOKU := vSQL_UPDATE_TAISHOKU || '     AND KJN_CD = :KjnCd';
        vSQL_UPDATE_TAISHOKU := vSQL_UPDATE_TAISHOKU || '     AND TAISHOKU_FLG IS NULL';
        vSQL_UPDATE_TAISHOKU := vSQL_UPDATE_TAISHOKU || '     RETURNING REC_ID, KJN_CD, KINMUSAKI_REC_ID, KINMUSAKI_SHI_CD INTO :1, :2, :3, :4';

        -- ��\�҂̃N���A
        vSQL_UPDATE_DAIHYO := NULL;
        vSQL_UPDATE_DAIHYO := vSQL_UPDATE_DAIHYO || '  UPDATE TT_SISN_SHI';
        vSQL_UPDATE_DAIHYO := vSQL_UPDATE_DAIHYO || '     SET DAIHYO_REC_ID = NULL,';
        vSQL_UPDATE_DAIHYO := vSQL_UPDATE_DAIHYO || '         DAIHYO_KJN_CD = NULL,';
        vSQL_UPDATE_DAIHYO := vSQL_UPDATE_DAIHYO || '         DAIHYO_YAKUSHOKU_CD = NULL,';
        vSQL_UPDATE_DAIHYO := vSQL_UPDATE_DAIHYO || '         DAIHYO_SHOKUI_CD = NULL,';
        vSQL_UPDATE_DAIHYO := vSQL_UPDATE_DAIHYO || '         DAIHYO_NM = NULL,';
        vSQL_UPDATE_DAIHYO := vSQL_UPDATE_DAIHYO || '         KENSAKU_DAIHYO_NM = NULL,';
        vSQL_UPDATE_DAIHYO := vSQL_UPDATE_DAIHYO || '         DAIHYO_NM_KANA = NULL,';
        vSQL_UPDATE_DAIHYO := vSQL_UPDATE_DAIHYO || '         UPD_USER_CD = :UserCd,';
        vSQL_UPDATE_DAIHYO := vSQL_UPDATE_DAIHYO || '         UPD_EIGY_YMD = :ShoriEigyoBi,';
        vSQL_UPDATE_DAIHYO := vSQL_UPDATE_DAIHYO || '         UPD_OPE_CD = :OpeCd,';
        vSQL_UPDATE_DAIHYO := vSQL_UPDATE_DAIHYO || '         UPD_DATE = :UpdDate,';
        vSQL_UPDATE_DAIHYO := vSQL_UPDATE_DAIHYO || '         UPD_PGM_ID = :PgmId';
        vSQL_UPDATE_DAIHYO := vSQL_UPDATE_DAIHYO || '   WHERE DAIHYO_REC_ID = :RecId';
        vSQL_UPDATE_DAIHYO := vSQL_UPDATE_DAIHYO || '     AND DAIHYO_KJN_CD = :KjnCd';
        vSQL_UPDATE_DAIHYO := vSQL_UPDATE_DAIHYO || '     AND DEL_YOTEI_RIYU_CD IS NULL';
        vSQL_UPDATE_DAIHYO := vSQL_UPDATE_DAIHYO || '     RETURNING REC_ID, SHI_CD INTO :1, :2';

        -- �������X�g���O�{�݃e�[�u�������폜
        vSQL_DEL_GETSUJI_KJN := NULL;
        vSQL_DEL_GETSUJI_KJN := vSQL_DEL_GETSUJI_KJN || 'DELETE TT_GETSUJI_LIST_JOGAI_KJN ';
        vSQL_DEL_GETSUJI_KJN := vSQL_DEL_GETSUJI_KJN || 'WHERE REC_ID = :recId ';
        vSQL_DEL_GETSUJI_KJN := vSQL_DEL_GETSUJI_KJN || '  AND KJN_CD = :kjnCd ';

        -- ���I�r�p�k���s
        -- ���O�o��
        ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql [vSQL_DEL_LIST]',vSQL_DEL_LIST || ' :shimeYM = ''' || iShimeYm || '''',iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

        OPEN v_c_DelKjn FOR vSQL_DEL_LIST USING iShimeYm;
        LOOP
            v_t_DelKjn.DELETE;
            FETCH v_c_DelKjn BULK COLLECT INTO v_t_DelKjn LIMIT BULK_SIZE;
            EXIT WHEN v_t_DelKjn.COUNT = 0;
            FOR i IN 1 .. v_t_DelKjn.COUNT
            LOOP
                ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'BusinessLog Start [�l�폜�J�n]', 'REC_ID=''' || v_t_DelKjn(i).REC_ID || ''' KJN_CD=''' || v_t_DelKjn(i).KJN_CD || '''',iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);
                
                -- �폜�t���O�𓖂Ă�
                -- ���O�o��
                ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql [vSQL_UPD_DEL_FLG]',
                    vSQL_UPD_DEL_FLG
                    || ' :ShoriEigyoBi = ''' || iShoriEigyoBi
                    || ''' :UserCd = ''' || v_t_DelKjn(i).DEL_NYURYOKU_USER_CD
                    || ''' :OpeCd = ''' || iOPE_CD
                    || ''' :UpdDate = ''' || iDATE
                    || ''' :PgmId = ''' || iPGM_ID
                    || ''' :RecId = ''' || v_t_DelKjn(i).REC_ID
                    || ''' :KjnCd = ''' || v_t_DelKjn(i).KJN_CD
                    || '''',iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

                EXECUTE IMMEDIATE vSQL_UPD_DEL_FLG USING  iShoriEigyoBi, v_t_DelKjn(i).DEL_NYURYOKU_USER_CD, iShoriEigyoBi, iOPE_CD, iDATE, iPGM_ID, v_t_DelKjn(i).REC_ID, v_t_DelKjn(i).KJN_CD;
                -- �C���v�b�g�󋵃e�[�u���̓o�^
                BT010301B001_COMMON.INSERT_INPUT_JOKYO_KJN(
                          iShoriEigyoBi,
                          v_t_DelKjn(i).REC_ID,
                          v_t_DelKjn(i).DEL_NYURYOKU_USER_CD,
                          'C',
                          '0103',
                          v_t_DelKjn(i).KJN_CD,
                          iIP_ADDR,
                          iWINDOWS_LOGIN_USER,
                          iOPE_CD,
                          iDATE,
                          iPGM_ID);
                
                -- �i�Q�j�폜�l�ɓo�^����Ă���u�w��v�y�сu����v���d�������ɓo�^����
                -- �폜�\�藝�R�R�[�h���u5�F�d���폜�v�̏ꍇ
                -- �폜�l�ɓo�^����Ă���u�w��v�y�сu����v���d�������ɓo�^����
                IF v_t_DelKjn(i).DEL_YOTEI_RIYU_CD = '5' THEN

                    -- �@�w��̓o�^
                    -- ���O�o��
                    ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql [vSQL_GAKKAI_LIST]',
                        vSQL_GAKKAI_LIST
                        || ' :ChofukuAiteRecId = ''' || v_t_DelKjn(i).CHOFUKU_AITSK_REC_ID
                        || ''' :ChofukuAiteKjnCd = ''' || v_t_DelKjn(i).CHOFUKU_AITSK_KJN_CD
                        || ''' :RecId = ''' || v_t_DelKjn(i).REC_ID
                        || ''' :KjnCd = ''' || v_t_DelKjn(i).KJN_CD
                        ,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);
                    -- ���I�r�p�k���s
                    OPEN v_c_GakkaiList FOR vSQL_GAKKAI_LIST USING v_t_DelKjn(i).CHOFUKU_AITSK_REC_ID, v_t_DelKjn(i).CHOFUKU_AITSK_KJN_CD, v_t_DelKjn(i).REC_ID, v_t_DelKjn(i).KJN_CD;
                    LOOP
                        v_t_GakkaiList.DELETE;
                        FETCH v_c_GakkaiList BULK COLLECT INTO v_t_GakkaiList LIMIT BULK_SIZE;
                        EXIT WHEN v_t_GakkaiList.COUNT = 0;
                        FOR j IN 1 .. v_t_GakkaiList.COUNT
                        LOOP
                            IF v_t_GakkaiList(j).AITE_GAKKAI = 'FALSE' THEN
                                -- �ŏI����悪�����w�����o�^���Ă��Ȃ��ꍇ
                                -- �w��̓o�^���s��
                                -- ���O�o��
                                ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql [vSQL_INSERT_SISN_GAKKAI]',
                                    vSQL_INSERT_SISN_GAKKAI
                                    || ' :RecId = ''' || v_t_DelKjn(i).CHOFUKU_AITSK_REC_ID
                                    || ''' :KjnCd = ''' || v_t_DelKjn(i).CHOFUKU_AITSK_KJN_CD
                                    || ''' :GakkaiCd = ''' || v_t_GakkaiList(j).GAKKAI_CD
                                    || ''' :GakkaiNendo = ''' || v_t_GakkaiList(j).GAKKAI_NENDO
                                    || ''' :TrkYm = ''' || SUBSTR(iShoriEigyoBi, 0, 6)
                                    || ''' :UserCd = ''' || v_t_DelKjn(i).DEL_NYURYOKU_USER_CD
                                    || ''' :ShoriEigyoBi = ''' || iShoriEigyoBi
                                    ,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

                                EXECUTE IMMEDIATE vSQL_INSERT_SISN_GAKKAI
                                    USING
                                        v_t_DelKjn(i).CHOFUKU_AITSK_REC_ID
                                        ,v_t_DelKjn(i).CHOFUKU_AITSK_KJN_CD
                                        ,v_t_GakkaiList(j).GAKKAI_CD
                                        ,v_t_GakkaiList(j).GAKKAI_NENDO
                                        ,SUBSTR(iShoriEigyoBi, 0, 6)
                                        ,iShoriEigyoBi
                                        ,v_t_DelKjn(i).DEL_NYURYOKU_USER_CD
                                        ,iShoriEigyoBi
                                        ,v_t_DelKjn(i).DEL_NYURYOKU_USER_CD
                                        ,iShoriEigyoBi
                                        ,iOPE_CD
                                        ,iDATE
                                        ,iPGM_ID
                                        ,iOPE_CD
                                        ,iDATE
                                        ,iPGM_ID;

                                -- ����o�^
                                IF v_t_DelKjn(i).CHOFUKU_AITSK_REC_ID = '01' THEN
                                    -- ���O�o��
                                    ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql [vSQL_INSERT_RRK_GAKKAI]',
                                        vSQL_INSERT_RRK_GAKKAI
                                        || ' :RecId = ''' || v_t_DelKjn(i).CHOFUKU_AITSK_REC_ID
                                        || ''' :KjnCd = ''' || v_t_DelKjn(i).CHOFUKU_AITSK_KJN_CD
                                        || ''' :GakkaiCd = ''' || v_t_GakkaiList(j).GAKKAI_CD
                                        || ''' :GakkaiNendo = ''' || v_t_GakkaiList(j).GAKKAI_NENDO
                                        || ''' :ShitenEigyoshoNm = ''' || iShitenEigyoshoNm
                                        || ''' :MrNm = ''' || iMrNm
                                        || ''' :ChosaYmd = ''' || iChosaYmd
                                        || ''' :TrkYm = ''' || SUBSTR(iShoriEigyoBi, 0, 6)
                                        || ''' :UserCd = ''' || v_t_DelKjn(i).DEL_NYURYOKU_USER_CD
                                        || ''' :ShoriEigyoBi = ''' || iShoriEigyoBi
                                        ,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

                                    EXECUTE IMMEDIATE vSQL_INSERT_RRK_GAKKAI
                                        USING
                                            v_t_DelKjn(i).CHOFUKU_AITSK_REC_ID
                                            ,v_t_DelKjn(i).CHOFUKU_AITSK_KJN_CD
                                            ,v_t_GakkaiList(j).GAKKAI_CD
                                            ,v_t_GakkaiList(j).GAKKAI_NENDO
                                            ,iShitenEigyoshoNm
                                            ,iMrNm
                                            ,iChosaYmd
                                            ,SUBSTR(iShoriEigyoBi, 0, 6)
                                            ,iShoriEigyoBi
                                            ,v_t_DelKjn(i).DEL_NYURYOKU_USER_CD
                                            ,iShoriEigyoBi
                                            ,v_t_DelKjn(i).DEL_NYURYOKU_USER_CD
                                            ,iShoriEigyoBi
                                            ,iOPE_CD
                                            ,iDATE
                                            ,iPGM_ID
                                            ,iOPE_CD
                                            ,iDATE
                                            ,iPGM_ID;
                                END IF;

                            ELSE
                                IF v_t_GakkaiList(j).AITE_GAKKAI_DEL = 'TRUE' THEN
                                    -- �ŏI����悪�����w�����o�^���Ă���A����
                                    -- �폜�ς݂ƂȂ��Ă���i�폜�t���O��1�F�폜�j�ꍇ
                                    -- ���O�o��
                                    ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql [vSQL_UPD_GAKKAI_FUKATSU]',
                                        vSQL_UPD_GAKKAI_FUKATSU
                                        || ' :RecId = ''' || v_t_DelKjn(i).CHOFUKU_AITSK_REC_ID
                                        || ''' :KjnCd = ''' || v_t_DelKjn(i).CHOFUKU_AITSK_KJN_CD
                                        || ''' :GakkaiCd = ''' || v_t_GakkaiList(j).GAKKAI_CD
                                        || ''' :GakkaiNendo = ''' || v_t_GakkaiList(j).GAKKAI_NENDO
                                        || ''' :UserCd = ''' || v_t_DelKjn(i).DEL_NYURYOKU_USER_CD
                                        || ''' :ShoriEigyoBi = ''' || iShoriEigyoBi
                                        ,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

									vTrkYm := NULL;
                                    EXECUTE IMMEDIATE vSQL_UPD_GAKKAI_FUKATSU
                                        USING
                                            iShoriEigyoBi
                                            ,v_t_DelKjn(i).DEL_NYURYOKU_USER_CD
                                            ,iShoriEigyoBi
                                            ,iOPE_CD
                                            ,iDATE
                                            ,iPGM_ID
                                            ,v_t_DelKjn(i).CHOFUKU_AITSK_REC_ID
                                            ,v_t_DelKjn(i).CHOFUKU_AITSK_KJN_CD
                                            ,v_t_GakkaiList(j).GAKKAI_CD
                                            ,v_t_GakkaiList(j).GAKKAI_NENDO
										RETURNING INTO vTrkYm;

                                    -- ����o�^
                                    IF v_t_DelKjn(i).CHOFUKU_AITSK_REC_ID = '01' THEN
                                        -- ���O�o��
                                        ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql [vSQL_INSERT_RRK_GAKKAI]',
                                            vSQL_INSERT_RRK_GAKKAI
                                            || ' :RecId = ''' || v_t_DelKjn(i).CHOFUKU_AITSK_REC_ID
                                            || ''' :KjnCd = ''' || v_t_DelKjn(i).CHOFUKU_AITSK_KJN_CD
                                            || ''' :GakkaiCd = ''' || v_t_GakkaiList(j).GAKKAI_CD
                                            || ''' :GakkaiNendo = ''' || v_t_GakkaiList(j).GAKKAI_NENDO
                                            || ''' :ShitenEigyoshoNm = ''' || iShitenEigyoshoNm
                                            || ''' :MrNm = ''' || iMrNm
                                            || ''' :ChosaYmd = ''' || iChosaYmd
                                            || ''' :TrkYm = ''' || SUBSTR(iShoriEigyoBi, 0, 6)
                                            || ''' :UserCd = ''' || v_t_DelKjn(i).DEL_NYURYOKU_USER_CD
                                            || ''' :ShoriEigyoBi = ''' || iShoriEigyoBi
                                            ,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

                                        EXECUTE IMMEDIATE vSQL_INSERT_RRK_GAKKAI
                                            USING
                                                v_t_DelKjn(i).CHOFUKU_AITSK_REC_ID
                                                ,v_t_DelKjn(i).CHOFUKU_AITSK_KJN_CD
                                                ,v_t_GakkaiList(j).GAKKAI_CD
                                                ,v_t_GakkaiList(j).GAKKAI_NENDO
                                                ,iShitenEigyoshoNm
                                                ,iMrNm
                                                ,iChosaYmd
                                                ,vTrkYm
                                                ,iShoriEigyoBi
                                                ,v_t_DelKjn(i).DEL_NYURYOKU_USER_CD
                                                ,iShoriEigyoBi
                                                ,v_t_DelKjn(i).DEL_NYURYOKU_USER_CD
                                                ,iShoriEigyoBi
                                                ,iOPE_CD
                                                ,iDATE
                                                ,iPGM_ID
                                                ,iOPE_CD
                                                ,iDATE
                                                ,iPGM_ID;
                                    END IF; -- IF v_t_DelKjn(i).CHOFUKU_AITSK_REC_ID = '01'
                                END IF; -- IF AITE_GAKKAI_DEL = 'TRUE' THEN
                            END IF; -- IF v_t_GakkaiList(j).AITE_GAKKAI = 'FALSE' THEN
                        END LOOP; -- v_t_GakkaiList
                    END LOOP; -- �@�w��̓o�^
                    CLOSE v_c_GakkaiList;

                    -- �A����̓o�^
                    -- ���I�r�p�k���s
                    -- ���O�o��
                    ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql [vSQL_SENMONI_LIST]',
                        vSQL_SENMONI_LIST
                        || ' :RecId = ''' || v_t_DelKjn(i).REC_ID
                        || ''' :KjnCd = ''' || v_t_DelKjn(i).KJN_CD
                        || ''' :ChofukuAiteRecId = ''' || v_t_DelKjn(i).CHOFUKU_AITSK_REC_ID
                        || ''' :ChofukuAiteRecId = ''' || v_t_DelKjn(i).CHOFUKU_AITSK_KJN_CD
                        ,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

                    OPEN v_c_SenmoniList FOR vSQL_SENMONI_LIST USING v_t_DelKjn(i).CHOFUKU_AITSK_REC_ID, v_t_DelKjn(i).CHOFUKU_AITSK_KJN_CD, v_t_DelKjn(i).REC_ID, v_t_DelKjn(i).KJN_CD;
                    LOOP
                        FETCH v_c_SenmoniList BULK COLLECT INTO v_t_SenmoniList LIMIT BULK_SIZE;
                        EXIT WHEN v_t_SenmoniList.COUNT = 0;
                        FOR j IN 1 .. v_t_SenmoniList.COUNT
                        LOOP
                            -- ���O�o��
                            ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql [vSQL_YUSEN_KJN_CD]',
                                vSQL_YUSEN_KJN_CD
                                || ' :shimeYM = ''' || iShimeYm
                                || ''' :chofukuRecId = ''' || v_t_DelKjn(i).CHOFUKU_AITSK_REC_ID
                                || ''' :chofukuKjnCd = ''' || v_t_DelKjn(i).CHOFUKU_AITSK_KJN_CD
                                || ''' :SenmoniCd = ''' || v_t_SenmoniList(j).SENMONI_CD
                                || '''' , iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

                            vYusenKjnCd := NULL;
                            EXECUTE IMMEDIATE vSQL_YUSEN_KJN_CD INTO vYusenKjnCd USING iShimeYm, v_t_DelKjn(i).CHOFUKU_AITSK_REC_ID, v_t_DelKjn(i).CHOFUKU_AITSK_KJN_CD, v_t_SenmoniList(j).SENMONI_CD;

                            -- �擾���ꂽ�D��l�R�[�h�ƍ폜�Ώیl�R�[�h�͈�v�̏ꍇ
                            IF vYusenKjnCd = v_t_DelKjn(i).KJN_CD THEN
                                IF v_t_SenmoniList(j).AITE_SENMONI = 'FALSE' THEN

                                    -- ���O�o��
                                    ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql [vSQL_INSERT_SISN_SENMONI]',
                                        vSQL_INSERT_SISN_SENMONI
                                        || ' :REC_ID = ''' || v_t_DelKjn(i).CHOFUKU_AITSK_REC_ID
                                        || ''' :KJN_CD = ''' || v_t_DelKjn(i).CHOFUKU_AITSK_KJN_CD
                                        || ''' :SENMONI_CD = ''' || v_t_SenmoniList(j).SENMONI_CD
                                        || ''' :SENMONI_FLG = ''' || v_t_SenmoniList(j).SENMONI_FLG
                                        || ''' :SENMONI_KEISAI_YMD = ''' || v_t_SenmoniList(j).SENMONI_KEISAI_YMD
                                        || ''' :NINTEII_FLG = ''' || v_t_SenmoniList(j).NINTEII_FLG
                                        || ''' :NINTEII_KEISAI_YMD = ''' || v_t_SenmoniList(j).NINTEII_KEISAI_YMD
                                        || ''' :SHIDOI_FLG = ''' || v_t_SenmoniList(j).SHIDOI_FLG
                                        || ''' :SHIDOI_KEISAI_YMD = ''' || v_t_SenmoniList(j).SHIDOI_KEISAI_YMD
                                        || ''' :TRK_USER_CD = ''' || v_t_DelKjn(i).DEL_NYURYOKU_USER_CD
                                        || ''' :TRK_EIGY_YMD = ''' || iShoriEigyoBi
                                        || ''' :UPD_USER_CD = ''' || v_t_DelKjn(i).DEL_NYURYOKU_USER_CD
                                        || ''' :UPD_EIGY_YMD = ''' || iShoriEigyoBi
                                        || ''' :TRK_OPE_CD = ''' || iOPE_CD
                                        || ''' :TRK_DATE = ''' || iDATE
                                        || ''' :TRK_PGM_ID = ''' || iPGM_ID
                                        || ''' :UPD_OPE_CD = ''' || iOPE_CD
                                        || ''' :UPD_DATE = ''' || iDATE
                                        || ''' :UPD_PGM_ID = ''' || iPGM_ID
                                        || '''' , iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

                                    EXECUTE IMMEDIATE vSQL_INSERT_SISN_SENMONI USING
                                        v_t_DelKjn(i).CHOFUKU_AITSK_REC_ID,
                                        v_t_DelKjn(i).CHOFUKU_AITSK_KJN_CD,
                                        v_t_SenmoniList(j).SENMONI_CD,
                                        v_t_SenmoniList(j).SENMONI_FLG,
                                        v_t_SenmoniList(j).SENMONI_KEISAI_YMD,
                                        v_t_SenmoniList(j).NINTEII_FLG,
                                        v_t_SenmoniList(j).NINTEII_KEISAI_YMD,
                                        v_t_SenmoniList(j).SHIDOI_FLG,
                                        v_t_SenmoniList(j).SHIDOI_KEISAI_YMD,
                                        iShoriEigyoBi,
                                        v_t_DelKjn(i).DEL_NYURYOKU_USER_CD,
                                        iShoriEigyoBi,
                                        v_t_DelKjn(i).DEL_NYURYOKU_USER_CD,
                                        iShoriEigyoBi,
                                        iOPE_CD,
                                        iDATE,
                                        iPGM_ID,
                                        iOPE_CD,
                                        iDATE,
                                        iPGM_ID;

                                    -- ���O�o��
                                    ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql [vSQL_INSERT_RRK_SENMONI]',
                                        vSQL_INSERT_RRK_SENMONI
                                        || ' :REC_ID = ''' || v_t_DelKjn(i).CHOFUKU_AITSK_REC_ID
                                        || ''' :KJN_CD = ''' || v_t_DelKjn(i).CHOFUKU_AITSK_KJN_CD
                                        || ''' :SENMONI_CD = ''' || v_t_SenmoniList(j).SENMONI_CD
                                        || ''' :SHITEN_EIGYOSHO_NM = ''' || iShitenEigyoshoNm
                                        || ''' :MR_NM = ''' || iMrNm
                                        || ''' :CHOSA_YMD = ''' || iChosaYmd
                                        || ''' :SENMONI_FLG = ''' || v_t_SenmoniList(j).SENMONI_FLG
                                        || ''' :SENMONI_KEISAI_YMD = ''' || v_t_SenmoniList(j).SENMONI_KEISAI_YMD
                                        || ''' :NINTEII_FLG = ''' || v_t_SenmoniList(j).NINTEII_FLG
                                        || ''' :NINTEII_KEISAI_YMD = ''' || v_t_SenmoniList(j).NINTEII_KEISAI_YMD
                                        || ''' :SHIDOI_FLG = ''' || v_t_SenmoniList(j).SHIDOI_FLG
                                        || ''' :SHIDOI_KEISAI_YMD = ''' || v_t_SenmoniList(j).SHIDOI_KEISAI_YMD
                                        || ''' :TRK_USER_CD = ''' || v_t_DelKjn(i).DEL_NYURYOKU_USER_CD
                                        || ''' :TRK_EIGY_YMD = ''' || iShoriEigyoBi
                                        || ''' :UPD_USER_CD = ''' || v_t_DelKjn(i).DEL_NYURYOKU_USER_CD
                                        || ''' :UPD_EIGY_YMD = ''' || iShoriEigyoBi
                                        || ''' :TRK_OPE_CD = ''' || iOPE_CD
                                        || ''' :TRK_DATE = ''' || iDATE
                                        || ''' :TRK_PGM_ID = ''' || iPGM_ID
                                        || ''' :UPD_OPE_CD = ''' || iOPE_CD
                                        || ''' :UPD_DATE = ''' || iDATE
                                        || ''' :UPD_PGM_ID = ''' || iPGM_ID
                                        || '''' , iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

                                    EXECUTE IMMEDIATE vSQL_INSERT_RRK_SENMONI USING
                                        v_t_DelKjn(i).CHOFUKU_AITSK_REC_ID,
                                        v_t_DelKjn(i).CHOFUKU_AITSK_KJN_CD,
                                        v_t_SenmoniList(j).SENMONI_CD,
                                        iShitenEigyoshoNm,
                                        iMrNm,
                                        iChosaYmd,
                                        v_t_SenmoniList(j).SENMONI_FLG,
                                        v_t_SenmoniList(j).SENMONI_KEISAI_YMD,
                                        v_t_SenmoniList(j).NINTEII_FLG,
                                        v_t_SenmoniList(j).NINTEII_KEISAI_YMD,
                                        v_t_SenmoniList(j).SHIDOI_FLG,
                                        v_t_SenmoniList(j).SHIDOI_KEISAI_YMD,
                                        iShoriEigyoBi,
                                        v_t_DelKjn(i).DEL_NYURYOKU_USER_CD,
                                        iShoriEigyoBi,
                                        v_t_DelKjn(i).DEL_NYURYOKU_USER_CD,
                                        iShoriEigyoBi,
                                        iOPE_CD,
                                        iDATE,
                                        iPGM_ID,
                                        iOPE_CD,
                                        iDATE,
                                        iPGM_ID;

                                ELSE
                                    IF v_t_SenmoniList(j).AITE_SENMONI_SOSHITSU = 'TRUE' THEN

                                        -- ���O�o��
                                        ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql [vSQL_UPDATE_SISN_SENMONI]',
                                            vSQL_UPDATE_SISN_SENMONI
                                            || ' :REC_ID = ''' || v_t_DelKjn(i).CHOFUKU_AITSK_REC_ID
                                            || ''' :KJN_CD = ''' || v_t_DelKjn(i).CHOFUKU_AITSK_KJN_CD
                                            || ''' :SENMONI_CD = ''' || v_t_SenmoniList(j).SENMONI_CD
                                            || ''' :SENMONI_FLG = ''' || v_t_SenmoniList(j).SENMONI_FLG
                                            || ''' :SENMONI_KEISAI_YMD = ''' || v_t_SenmoniList(j).SENMONI_KEISAI_YMD
                                            || ''' :NINTEII_FLG = ''' || v_t_SenmoniList(j).NINTEII_FLG
                                            || ''' :NINTEII_KEISAI_YMD = ''' || v_t_SenmoniList(j).NINTEII_KEISAI_YMD
                                            || ''' :SHIDOI_FLG = ''' || v_t_SenmoniList(j).SHIDOI_FLG
                                            || ''' :SHIDOI_KEISAI_YMD = ''' || v_t_SenmoniList(j).SHIDOI_KEISAI_YMD
                                            || ''' :UPD_USER_CD = ''' || v_t_DelKjn(i).DEL_NYURYOKU_USER_CD
                                            || ''' :UPD_EIGY_YMD = ''' || iShoriEigyoBi
                                            || ''' :UPD_OPE_CD = ''' || iOPE_CD
                                            || ''' :UPD_DATE = ''' || iDATE
                                            || ''' :UPD_PGM_ID = ''' || iPGM_ID
                                            || '''' , iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

                                        EXECUTE IMMEDIATE vSQL_UPDATE_SISN_SENMONI USING
                                            v_t_SenmoniList(j).SENMONI_FLG,
                                            v_t_SenmoniList(j).SENMONI_KEISAI_YMD,
                                            v_t_SenmoniList(j).NINTEII_FLG,
                                            v_t_SenmoniList(j).NINTEII_KEISAI_YMD,
                                            v_t_SenmoniList(j).SHIDOI_FLG,
                                            v_t_SenmoniList(j).SHIDOI_KEISAI_YMD,
                                            iShoriEigyoBi,
                                            v_t_DelKjn(i).DEL_NYURYOKU_USER_CD,
                                            iShoriEigyoBi,
                                            iOPE_CD,
                                            iDATE,
                                            iPGM_ID,
                                            v_t_DelKjn(i).CHOFUKU_AITSK_REC_ID,
                                            v_t_DelKjn(i).CHOFUKU_AITSK_KJN_CD,
                                            v_t_SenmoniList(j).SENMONI_CD;

                                        -- ���O�o��
                                        ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql [vSQL_INSERT_RRK_SENMONI]',
                                            vSQL_INSERT_RRK_SENMONI
                                            || ' :REC_ID = ''' || v_t_DelKjn(i).CHOFUKU_AITSK_REC_ID
                                            || ''' :KJN_CD = ''' || v_t_DelKjn(i).CHOFUKU_AITSK_KJN_CD
                                            || ''' :SENMONI_CD = ''' || v_t_SenmoniList(j).SENMONI_CD
                                            || ''' :SHITEN_EIGYOSHO_NM = ''' || iShitenEigyoshoNm
                                            || ''' :MR_NM = ''' || iMrNm
                                            || ''' :CHOSA_YMD = ''' || iChosaYmd
                                            || ''' :SENMONI_FLG = ''' || v_t_SenmoniList(j).SENMONI_FLG
                                            || ''' :SENMONI_KEISAI_YMD = ''' || v_t_SenmoniList(j).SENMONI_KEISAI_YMD
                                            || ''' :NINTEII_FLG = ''' || v_t_SenmoniList(j).NINTEII_FLG
                                            || ''' :NINTEII_KEISAI_YMD = ''' || v_t_SenmoniList(j).NINTEII_KEISAI_YMD
                                            || ''' :SHIDOI_FLG = ''' || v_t_SenmoniList(j).SHIDOI_FLG
                                            || ''' :SHIDOI_KEISAI_YMD = ''' || v_t_SenmoniList(j).SHIDOI_KEISAI_YMD
                                            || ''' :TRK_USER_CD = ''' || v_t_DelKjn(i).DEL_NYURYOKU_USER_CD
                                            || ''' :TRK_EIGY_YMD = ''' || iShoriEigyoBi
                                            || ''' :UPD_USER_CD = ''' || v_t_DelKjn(i).DEL_NYURYOKU_USER_CD
                                            || ''' :UPD_EIGY_YMD = ''' || iShoriEigyoBi
                                            || ''' :TRK_OPE_CD = ''' || iOPE_CD
                                            || ''' :TRK_DATE = ''' || iDATE
                                            || ''' :TRK_PGM_ID = ''' || iPGM_ID
                                            || ''' :UPD_OPE_CD = ''' || iOPE_CD
                                            || ''' :UPD_DATE = ''' || iDATE
                                            || ''' :UPD_PGM_ID = ''' || iPGM_ID
                                            || '''' , iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

                                        EXECUTE IMMEDIATE vSQL_INSERT_RRK_SENMONI USING
                                            v_t_DelKjn(i).CHOFUKU_AITSK_REC_ID,
                                            v_t_DelKjn(i).CHOFUKU_AITSK_KJN_CD,
                                            v_t_SenmoniList(j).SENMONI_CD,
                                            iShitenEigyoshoNm,
                                            iMrNm,
                                            iChosaYmd,
                                            v_t_SenmoniList(j).SENMONI_FLG,
                                            v_t_SenmoniList(j).SENMONI_KEISAI_YMD,
                                            v_t_SenmoniList(j).NINTEII_FLG,
                                            v_t_SenmoniList(j).NINTEII_KEISAI_YMD,
                                            v_t_SenmoniList(j).SHIDOI_FLG,
                                            v_t_SenmoniList(j).SHIDOI_KEISAI_YMD,
                                            iShoriEigyoBi,
                                            v_t_DelKjn(i).DEL_NYURYOKU_USER_CD,
                                            iShoriEigyoBi,
                                            v_t_DelKjn(i).DEL_NYURYOKU_USER_CD,
                                            iShoriEigyoBi,
                                            iOPE_CD,
                                            iDATE,
                                            iPGM_ID,
                                            iOPE_CD,
                                            iDATE,
                                            iPGM_ID;
                                               
                                    END IF; -- IF v_t_SenmoniList(j).AITE_SENMONI_SOSHITSU = 'TRUE' THEN
                                END IF; -- IF v_t_SenmoniList(j).AITE_SENMONI = 'FALSE' THEN

                            END IF; -- IF vYusenKjnCd = v_t_DelKjn(i).KJN_CD THEN
                        END LOOP; -- v_t_SenmoniList
                    END LOOP; -- v_t_SenmoniList
                    CLOSE v_c_SenmoniList;
                END IF; -- �폜�\�藝�R�R�[�h���u5�F�d���폜�v�̏ꍇ

                -- �i�R�j�폜�l�̑ސE�������s��
                -- ���O�o��
                ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql [vSQL_UPDATE_TAISHOKU]',
                    vSQL_UPDATE_TAISHOKU
                    || ' :ShoriEigyoBi = ''' || iShoriEigyoBi
                    || ''' :UserCd = ''' || v_t_DelKjn(i).DEL_NYURYOKU_USER_CD
                    || ''' :RecId = ''' || v_t_DelKjn(i).REC_ID
                    || ''' :KjnCd = ''' || v_t_DelKjn(i).KJN_CD
                    || '''', iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

                v_t_RecIdList := t_RecID_Tbl(NULL);
                v_t_KjnCdList := t_KjnCD_Tbl(NULL);
                v_t_kinmusakiRecIdList := t_KinmusakiRecID_Tbl(NULL);
                v_t_kinmusakiShiCdList := t_KinmusakiShiCD_Tbl(NULL);

                EXECUTE IMMEDIATE vSQL_UPDATE_TAISHOKU USING
                    iShoriEigyoBi,
                    v_t_DelKjn(i).DEL_NYURYOKU_USER_CD,
                    iShoriEigyoBi,
                    iOPE_CD,
                    iDATE,
                    iPGM_ID,
                    v_t_DelKjn(i).REC_ID,
                    v_t_DelKjn(i).KJN_CD
                    RETURNING BULK COLLECT INTO v_t_RecIdList, v_t_KjnCdList, v_t_kinmusakiRecIdList, v_t_kinmusakiShiCdList;
                
                FOR k IN 1 .. v_t_RecIdList.COUNT
                LOOP
                    -- �ސE�����ƃC���v�b�g�󋵂��쐬����B
                    BT010301B001_COMMON.CREATE_TAISHOKU_RRK(
                            v_t_RecIdList(k),
                            v_t_KjnCdList(k),
                            v_t_kinmusakiRecIdList(k),
                            v_t_kinmusakiShiCdList(k),
                            v_t_DelKjn(i).DEL_NYURYOKU_USER_CD,
                            iShoriEigyoBi,
                            iShitenEigyoshoNm,
                            iMrNm,
                            iChosaYmd,
                            iIP_ADDR,
                            iWINDOWS_LOGIN_USER,
                            iOPE_CD,
                            iDATE,
                            iPGM_ID);
                END LOOP;

                
                -- ���R�[�hID��02�FPCF�l�ȊO�̏ꍇ
                -- ���J�΋敪���u1�F�J�ƈ�v���́u2�F�Ζ���v�̏ꍇ�A�J�΋敪�X�V���s��
                BT010301B001_COMMON.UPDATE_KAIKIN_KBN(
                        v_t_DelKjn(i).REC_ID,
                        v_t_DelKjn(i).KJN_CD,
                        v_t_DelKjn(i).DEL_NYURYOKU_USER_CD,
                        iShoriEigyoBi,
                        iShitenEigyoshoNm,
                        iMrNm,
                        iChosaYmd,
                        iIP_ADDR,
                        iWINDOWS_LOGIN_USER,
                        iOPE_CD,
                        iDATE,
                        iPGM_ID);
                    
                -- �i�S�j�폜�l�̋Ζ����\�҃N���A�������s��
                -- ���O�o��
                ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql [vSQL_UPDATE_DAIHYO]',
                    vSQL_UPDATE_TAISHOKU
                    || ' :ShoriEigyoBi = ''' || iShoriEigyoBi
                    || ''' :UserCd = ''' || v_t_DelKjn(i).DEL_NYURYOKU_USER_CD
                    || ''' :RecId = ''' || v_t_DelKjn(i).REC_ID
                    || ''' :KjnCd = ''' || v_t_DelKjn(i).KJN_CD
                    || '''', iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

                v_t_kinmusakiRecIdList := t_KinmusakiRecID_Tbl(NULL);
                v_t_kinmusakiShiCdList := t_KinmusakiShiCD_Tbl(NULL);
                EXECUTE IMMEDIATE vSQL_UPDATE_DAIHYO USING
                    v_t_DelKjn(i).DEL_NYURYOKU_USER_CD,
                    iShoriEigyoBi,
                    iOPE_CD,
                    iDATE,
                    iPGM_ID,
                    v_t_DelKjn(i).REC_ID,
                    v_t_DelKjn(i).KJN_CD
                    RETURNING BULK COLLECT INTO v_t_kinmusakiRecIdList, v_t_kinmusakiShiCdList;
                
                -- ��\�җ����ƃC���v�b�g�󋵂��쐬
                FOR k IN 1 .. v_t_kinmusakiRecIdList.COUNT
                LOOP
                    IF v_t_kinmusakiRecIdList(k) IN ('00', '04', '03', '06') THEN

                        -- ���O�o��
                        ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql [vSQL_INSERT_RRK_DAIHYO]',
                            vSQL_INSERT_RRK_DAIHYO
                            || ' :RecId = ''' || v_t_kinmusakiRecIdList(k)
                            || ''' :ShiCd = ''' || v_t_kinmusakiShiCdList(k)
                            || ''' :ShitenEigyoshoNm = ''' || iShitenEigyoshoNm
                            || ''' :MrNm = ''' || iMrNm
                            || ''' :ChosaYmd = ''' || iChosaYmd
                            || ''' :TrkUserCd = ''' || v_t_DelKjn(i).DEL_NYURYOKU_USER_CD
                            || ''' :TrkEigyYmd = ''' || iShoriEigyoBi
                            || ''' :UpdUserCd = ''' || v_t_DelKjn(i).DEL_NYURYOKU_USER_CD
                            || ''' :UpdEigyYmd = ''' || iShoriEigyoBi
                            || ''' :TrkOpeCd = ''' || iOPE_CD
                            || ''' :TrkDate = ''' || iDATE
                            || ''' :TrkPgmId = ''' || iPGM_ID
                            || ''' :UpdOpeCd = ''' || iOPE_CD
                            || ''' :UpdDate = ''' || iDATE
                            || ''' :UpdPgmId = ''' || iPGM_ID
                            || '''', iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

                        EXECUTE IMMEDIATE vSQL_INSERT_RRK_DAIHYO USING
                            v_t_kinmusakiRecIdList(k),
                            v_t_kinmusakiShiCdList(k),
                            iShitenEigyoshoNm,
                            iMrNm,
                            iChosaYmd,
                            v_t_DelKjn(i).DEL_NYURYOKU_USER_CD,
                            iShoriEigyoBi,
                            v_t_DelKjn(i).DEL_NYURYOKU_USER_CD,
                            iShoriEigyoBi,
                            iOPE_CD,
                            iDATE,
                            iPGM_ID,
                            iOPE_CD,
                            iDATE,
                            iPGM_ID;
                    END IF;
                END LOOP;

                -- �i�T�j�������X�g���O�l�e�[�u���폜���s��
                -- �������X�g���O�{�݃e�[�u�������폜
                -- ���I�r�p�k�g�ݗ���
                -- ���O�o��
                ULT_INSERT_LOG_TABLE('INFO', iIP_ADDR, iWINDOWS_LOGIN_USER, iOPE_CD, 'Execute Sql [vSQL_DEL_GETSUJI_KJN]', vSQL_DEL_GETSUJI_KJN || 
                        ' :recId = ' || v_t_DelKjn(i).REC_ID || ' :kjnCd = ' || v_t_DelKjn(i).KJN_CD, iOPE_CD, iDATE, iPGM_ID, iOPE_CD, iDATE, iPGM_ID);

                -- ���I�r�p�k���s
                EXECUTE IMMEDIATE vSQL_DEL_GETSUJI_KJN USING v_t_DelKjn(i).REC_ID, v_t_DelKjn(i).KJN_CD;


                ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'BusinessLog End [�l�폜�I��]', 'REC_ID=''' || v_t_DelKjn(i).REC_ID || ''' KJN_CD=''' || v_t_DelKjn(i).KJN_CD || '''',iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

            END LOOP;
        
        END LOOP;
        CLOSE v_c_DelKjn;

        -- DCF�l���폜�\��ɂȂ����ꍇ��
        -- DCF�d�������i����l�j��DNF�l�i�폜�A�폜�\��ł��Ȃ��j��񃊃X�g���擾����
        vSQL_DCFDNF_LIST := NULL;
        vSQL_DCFDNF_LIST := vSQL_DCFDNF_LIST || 'SELECT';
        vSQL_DCFDNF_LIST := vSQL_DCFDNF_LIST || ' A.REC_ID';
        vSQL_DCFDNF_LIST := vSQL_DCFDNF_LIST || ' , A.KJN_CD';
        vSQL_DCFDNF_LIST := vSQL_DCFDNF_LIST || ' , B.DEL_NYURYOKU_USER_CD';
        vSQL_DCFDNF_LIST := vSQL_DCFDNF_LIST || ' FROM';
        vSQL_DCFDNF_LIST := vSQL_DCFDNF_LIST || ' TT_SISN_KJN A';
        vSQL_DCFDNF_LIST := vSQL_DCFDNF_LIST || ' INNER JOIN TT_SISN_KJN B';
        vSQL_DCFDNF_LIST := vSQL_DCFDNF_LIST || ' ON A.DCFCHOFUKU_REC_ID = B.REC_ID';
        vSQL_DCFDNF_LIST := vSQL_DCFDNF_LIST || ' AND A.DCFCHOFUKU_KJN_CD = B.KJN_CD';
        vSQL_DCFDNF_LIST := vSQL_DCFDNF_LIST || ' WHERE A.DCFCHOFUKU_REC_ID IS NOT NULL';
        vSQL_DCFDNF_LIST := vSQL_DCFDNF_LIST || ' AND A.DCFCHOFUKU_KJN_CD IS NOT NULL';
        vSQL_DCFDNF_LIST := vSQL_DCFDNF_LIST || ' AND A.REC_ID = ''05''';
        vSQL_DCFDNF_LIST := vSQL_DCFDNF_LIST || ' AND A.DEL_FLG IS NULL';
        vSQL_DCFDNF_LIST := vSQL_DCFDNF_LIST || ' AND A.DEL_YOTEI_RIYU_CD IS NULL';
        vSQL_DCFDNF_LIST := vSQL_DCFDNF_LIST || ' AND B.REC_ID = ''01''';
        vSQL_DCFDNF_LIST := vSQL_DCFDNF_LIST || ' AND B.DEL_FLG IS NULL';
        vSQL_DCFDNF_LIST := vSQL_DCFDNF_LIST || ' AND B.DEL_NYURYOKU_YM = :ShimeYM';
        vSQL_DCFDNF_LIST := vSQL_DCFDNF_LIST || ' AND B.DEL_YOTEI_RIYU_CD IS NOT NULL';

        vSQL_UPDATE_DCFCHOFUKU := NULL;
        vSQL_UPDATE_DCFCHOFUKU := vSQL_UPDATE_DCFCHOFUKU || ' UPDATE TT_SISN_KJN';
        vSQL_UPDATE_DCFCHOFUKU := vSQL_UPDATE_DCFCHOFUKU || '    SET DCFCHOFUKU_REC_ID = NULL,';
        vSQL_UPDATE_DCFCHOFUKU := vSQL_UPDATE_DCFCHOFUKU || '        DCFCHOFUKU_KJN_CD = NULL,';
        vSQL_UPDATE_DCFCHOFUKU := vSQL_UPDATE_DCFCHOFUKU || '        UPD_USER_CD = :UserCd,';
        vSQL_UPDATE_DCFCHOFUKU := vSQL_UPDATE_DCFCHOFUKU || '        UPD_EIGY_YMD = :ShoriEigyoBi,';
        vSQL_UPDATE_DCFCHOFUKU := vSQL_UPDATE_DCFCHOFUKU || '        UPD_OPE_CD = :OpeCd,';
        vSQL_UPDATE_DCFCHOFUKU := vSQL_UPDATE_DCFCHOFUKU || '        UPD_DATE = :UpdDate,';
        vSQL_UPDATE_DCFCHOFUKU := vSQL_UPDATE_DCFCHOFUKU || '        UPD_PGM_ID = :PgmId';
        vSQL_UPDATE_DCFCHOFUKU := vSQL_UPDATE_DCFCHOFUKU || '  WHERE REC_ID = :RecId';
        vSQL_UPDATE_DCFCHOFUKU := vSQL_UPDATE_DCFCHOFUKU || '    AND KJN_CD = :KjnCd';

        vSQL_INSERT_RRK_DCFCHOFUKU := 'INSERT INTO TT_RRK_KJN_DCFCHOFUKU(SEQ,REC_ID,KJN_CD,SHITEN_EIGYOSHO_NM,MR_NM,CHOSA_YMD,DCFCHOFUKU_REC_ID,DCFCHOFUKU_KJN_CD,GOMENTE_FLG,GOMENTE_CHK_OPE_CD,GOMENTE_CHK_USER_CD,GOMENTE_CHK_EIGY_YMD,TRK_USER_CD,TRK_EIGY_YMD,UPD_USER_CD,UPD_EIGY_YMD,TRK_OPE_CD,TRK_DATE,TRK_PGM_ID,UPD_OPE_CD,UPD_DATE,UPD_PGM_ID)VALUES(SEQ_RIREKI_PK.NEXTVAL,:RecId,:KjnCd,:ShitenEigyoshoNm,:MrNm,:ChosaYmd,NULL,NULL,NULL,NULL,NULL,NULL,:TrkUserCd,:TrkEigyYmd,:UpdUserCd,:UpdEigyYmd,:TrkOpeCd,:TrkDate,:TrkPgmId,:UpdOpeCd,:UpdDate,:UpdPgmId)';

        -- ���O�o��
        ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql [vSQL_DCFDNF_LIST]',vSQL_DCFDNF_LIST || ' :shimeYM = ''' || iShimeYm || '''',iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

        -- ���I�r�p�k���s
        OPEN v_c_DcfDnfList FOR vSQL_DCFDNF_LIST USING iShimeYm;
        LOOP
            v_t_DcfDnfList.DELETE;
            FETCH v_c_DcfDnfList BULK COLLECT INTO v_t_DcfDnfList LIMIT BULK_SIZE;
            EXIT WHEN v_t_DcfDnfList.COUNT = 0;
            FOR i IN 1 .. v_t_DcfDnfList.COUNT
            LOOP
                ULT_INSERT_LOG_TABLE('INFO', iIP_ADDR, iWINDOWS_LOGIN_USER, iOPE_CD, 'Execute Sql [vSQL_UPDATE_DCFCHOFUKU]', 
                    vSQL_UPDATE_DCFCHOFUKU || 
                        ' :RecId = ''' || v_t_DcfDnfList(i).REC_ID 
                        || ''' :KjnCd = ''' || v_t_DcfDnfList(i).KJN_CD
                        || ''' :UserCd = ''' || v_t_DcfDnfList(i).DEL_NYURYOKU_USER_CD
                        || ''' :ShoriEigyoBi = ''' || iShoriEigyoBi
                        || '''', iOPE_CD, iDATE, iPGM_ID, iOPE_CD, iDATE, iPGM_ID);

                EXECUTE IMMEDIATE vSQL_UPDATE_DCFCHOFUKU USING v_t_DcfDnfList(i).DEL_NYURYOKU_USER_CD, iShoriEigyoBi, iOPE_CD, iDATE, iPGM_ID, v_t_DcfDnfList(i).REC_ID, v_t_DcfDnfList(i).KJN_CD;

                -- �����쐬
                -- ���O�o��
                ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql [vSQL_INSERT_RRK_DCFCHOFUKU]',
                    vSQL_INSERT_RRK_DCFCHOFUKU
                    || ' :RecId = ''' || v_t_DcfDnfList(i).REC_ID
                    || ''' :Kjn = ''' || v_t_DcfDnfList(i).KJN_CD
                    || ''' :ShitenEigyoshoNm = ''' || iShitenEigyoshoNm
                    || ''' :MrNm = ''' || iMrNm
                    || ''' :ChosaYmd = ''' || iChosaYmd
                    || ''' :TrkUserCd = ''' || v_t_DcfDnfList(i).DEL_NYURYOKU_USER_CD
                    || ''' :TrkEigyYmd = ''' || iShoriEigyoBi
                    || ''' :UpdUserCd = ''' || v_t_DcfDnfList(i).DEL_NYURYOKU_USER_CD
                    || ''' :UpdEigyYmd = ''' || iShoriEigyoBi
                    || ''' :TrkOpeCd = ''' || iOPE_CD
                    || ''' :TrkDate = ''' || iDATE
                    || ''' :TrkPgmId = ''' || iPGM_ID
                    || ''' :UpdOpeCd = ''' || iOPE_CD
                    || ''' :UpdDate = ''' || iDATE
                    || ''' :UpdPgmId = ''' || iPGM_ID
                    || '''', iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

                EXECUTE IMMEDIATE vSQL_INSERT_RRK_DCFCHOFUKU USING
                    v_t_DcfDnfList(i).REC_ID,
                    v_t_DcfDnfList(i).KJN_CD,
                    iShitenEigyoshoNm,
                    iMrNm,
                    iChosaYmd,
                    v_t_DcfDnfList(i).DEL_NYURYOKU_USER_CD,
                    iShoriEigyoBi,
                    v_t_DcfDnfList(i).DEL_NYURYOKU_USER_CD,
                    iShoriEigyoBi,
                    iOPE_CD,
                    iDATE,
                    iPGM_ID,
                    iOPE_CD,
                    iDATE,
                    iPGM_ID;

            END LOOP;
        END LOOP; -- v_c_DcfDnfList

        CLOSE v_c_DcfDnfList;

        -- �I�����O�o��
        ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'PL/SQL End',PGM_ID || '�̏������I�����܂����B',iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

        -- ����I��
        oROW_COUNT := 1;
        RETURN 0;
        
    -- ��O����
    EXCEPTION
        -- ���̑��G���[
        WHEN OTHERS THEN
            W_ERR_INF_RCD.ERR_CD         := TO_CHAR(SQLCODE);
            W_ERR_INF_RCD.ERR_MSG         := SUBSTR(SQLERRM, 0, 2000);
            W_INDEX_N             := W_ERR_INF_TBL.COUNT + 1;
            W_ERR_INF_TBL.EXTEND;
            W_ERR_INF_TBL(W_INDEX_N)     := W_ERR_INF_RCD;

            OPEN oOUT_ERR_INF_CSR FOR
                SELECT * FROM TABLE(W_ERR_INF_TBL);
            
      --�G���[���O�̓o�^
            ULT_INSERT_LOG_TABLE('ERROR',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'ERROR_INFO',W_ERR_INF_RCD.ERR_MSG,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

            RAISE;
    
    END;
END;
/