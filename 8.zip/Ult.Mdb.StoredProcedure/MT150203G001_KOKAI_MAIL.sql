CREATE OR REPLACE PACKAGE       MT150203G001_KOKAI_MAIL
/* **********************************************************
 *  Copyright(c) 2011 beyond, INTEC Inc. All rights reserved.
 * **********************************************************/
AUTHID CURRENT_USER
IS
	/*** �J�[�\���^ ***************************************************************/
	-- �G���[���i�[�p�J�[�\���^
	TYPE ERR_INF_CSR		IS REF CURSOR;
	
	TYPE SEQ_TBL IS TABLE OF TR_BT020502P001.SEQ%TYPE INDEX BY BINARY_INTEGER;
	TYPE RENBAN_TBL IS TABLE OF TR_BT020502P001.RENBAN%TYPE INDEX BY BINARY_INTEGER;
	TYPE SENDER_EMAIL_TBL IS TABLE OF TR_BT020502P001.SENDER_EMAIL%TYPE INDEX BY BINARY_INTEGER;
	TYPE EMAIL_TO_TBL IS TABLE OF TR_BT020502P001.EMAIL_TO%TYPE INDEX BY BINARY_INTEGER;
	TYPE EMAIL_CC_TBL IS TABLE OF TR_BT020502P001.EMAIL_CC%TYPE INDEX BY BINARY_INTEGER;
	TYPE FB_USER_CD_TBL IS TABLE OF TR_BT020502P001.FB_USER_CD%TYPE INDEX BY BINARY_INTEGER;
	TYPE FB_SHIKIBETSU_CD_TBL IS TABLE OF TR_BT020502P001.FB_SHIKIBETSU_CD%TYPE INDEX BY BINARY_INTEGER;
	TYPE FB_SHIKIBETSU_NM_TBL IS TABLE OF TR_BT020502P001.FB_SHIKIBETSU_NM%TYPE INDEX BY BINARY_INTEGER;
	TYPE FB_SHIKIBETSU_KAISHA_NM_TBL IS TABLE OF TR_BT020502P001.FB_SHIKIBETSU_KAISHA_NM%TYPE INDEX BY BINARY_INTEGER;
	TYPE FB_LOAD_EIGY_YMD_TBL IS TABLE OF TR_BT020502P001.FB_LOAD_EIGY_YMD%TYPE INDEX BY BINARY_INTEGER;
	TYPE MENTE_E_YOTEI_TBL IS TABLE OF TR_BT020502P001.MENTE_E_YOTEI%TYPE INDEX BY BINARY_INTEGER;
	TYPE SHI_KJN_KBN_TBL IS TABLE OF TR_BT020502P001.SHI_KJN_KBN%TYPE INDEX BY BINARY_INTEGER;
	TYPE FB_LOT_NO_TBL IS TABLE OF TR_BT020502P001.FB_LOT_NO%TYPE INDEX BY BINARY_INTEGER;
	TYPE SO_KENSU_TBL IS TABLE OF TR_BT020502P001.SO_KENSU%TYPE INDEX BY BINARY_INTEGER;
	TYPE SHORIZUMI_KENSU_TBL IS TABLE OF TR_BT020502P001.SHORIZUMI_KENSU%TYPE INDEX BY BINARY_INTEGER;
	TYPE NOKORI_KENSU_TBL IS TABLE OF TR_BT020502P001.NOKORI_KENSU%TYPE INDEX BY BINARY_INTEGER;
	TYPE KJN_TAISHOKU_MSG_TBL IS TABLE OF TR_BT020502P001.KJN_TAISHOKU_MSG%TYPE INDEX BY BINARY_INTEGER;
	TYPE DIR_TBL IS TABLE OF TR_BT020502P001.DIR%TYPE INDEX BY BINARY_INTEGER;
	TYPE SHORI_EIGYO_BI_TBL IS TABLE OF TR_BT020502P001.SHORI_EIGYO_BI%TYPE INDEX BY BINARY_INTEGER;
	TYPE TRK_OPE_CD_TBL IS TABLE OF TR_BT020502P001.TRK_OPE_CD%TYPE INDEX BY BINARY_INTEGER;
	TYPE TRK_DATE_TBL IS TABLE OF TR_BT020502P001.TRK_DATE%TYPE INDEX BY BINARY_INTEGER;
	TYPE TRK_PGM_ID_TBL IS TABLE OF TR_BT020502P001.TRK_PGM_ID%TYPE INDEX BY BINARY_INTEGER;
	TYPE UPD_OPE_CD_TBL IS TABLE OF TR_BT020502P001.UPD_OPE_CD%TYPE INDEX BY BINARY_INTEGER;
	TYPE UPD_DATE_TBL IS TABLE OF TR_BT020502P001.UPD_DATE%TYPE INDEX BY BINARY_INTEGER;
	TYPE UPD_PGM_ID_TBL IS TABLE OF TR_BT020502P001.UPD_PGM_ID%TYPE INDEX BY BINARY_INTEGER;

	/*
	************************************************************************
	*  FB���J�O�{�݃��b�g�e�[�u���̈ꊇ�X�V����
	************************************************************************
	*/
	FUNCTION INSERT_TR(
		iSEQ IN SEQ_TBL,
		iRENBAN IN RENBAN_TBL,
		iSENDER_EMAIL IN SENDER_EMAIL_TBL,
		iEMAIL_TO IN EMAIL_TO_TBL,
		iEMAIL_CC IN EMAIL_CC_TBL,
		iFB_USER_CD IN FB_USER_CD_TBL,
		iFB_SHIKIBETSU_CD IN FB_SHIKIBETSU_CD_TBL,
		iFB_SHIKIBETSU_NM IN FB_SHIKIBETSU_NM_TBL,
		iFB_SHIKIBETSU_KAISHA_NM IN FB_SHIKIBETSU_KAISHA_NM_TBL,
		iFB_LOAD_EIGY_YMD IN FB_LOAD_EIGY_YMD_TBL,
		iMENTE_E_YOTEI IN MENTE_E_YOTEI_TBL,
		iSHI_KJN_KBN IN SHI_KJN_KBN_TBL,
		iFB_LOT_NO IN FB_LOT_NO_TBL,
		iSO_KENSU IN SO_KENSU_TBL,
		iSHORIZUMI_KENSU IN SHORIZUMI_KENSU_TBL,
		iNOKORI_KENSU IN NOKORI_KENSU_TBL,
		iKJN_TAISHOKU_MSG IN KJN_TAISHOKU_MSG_TBL,
		iDIR IN DIR_TBL,
		iSHORI_EIGYO_BI IN SHORI_EIGYO_BI_TBL,

        iOPE_CD               IN VARCHAR2, -- �I�y���[�^�R�[�h
        iPGM_ID               IN VARCHAR2, -- �v���O����ID
        iDATE                 IN DATE,     -- ��������
        iIP_ADDR              IN TL_STORED_SHORI.IP%TYPE, -- ���s�[��IP�A�h���X
        iWINDOWS_LOGIN_USER   IN TL_STORED_SHORI.WINDOWS_LOGIN_USER%TYPE, -- ���s�[��OS���[�U�[
        oROW_COUNT            OUT NUMBER, -- �X�V����
        oOUT_ERR_INF_CSR      OUT ERR_INF_CSR -- �G���[���J�[�\��
	) RETURN NUMBER;
	
	FUNCTION UPDATE_TR(
		iSEQ IN SEQ_TBL,
		iRENBAN IN RENBAN_TBL,
		iSENDER_EMAIL IN SENDER_EMAIL_TBL,
		iEMAIL_TO IN EMAIL_TO_TBL,
		iEMAIL_CC IN EMAIL_CC_TBL,
		iFB_USER_CD IN FB_USER_CD_TBL,
		iFB_SHIKIBETSU_CD IN FB_SHIKIBETSU_CD_TBL,
		iFB_SHIKIBETSU_NM IN FB_SHIKIBETSU_NM_TBL,
		iFB_SHIKIBETSU_KAISHA_NM IN FB_SHIKIBETSU_KAISHA_NM_TBL,
		iFB_LOAD_EIGY_YMD IN FB_LOAD_EIGY_YMD_TBL,
		iMENTE_E_YOTEI IN MENTE_E_YOTEI_TBL,
		iSHI_KJN_KBN IN SHI_KJN_KBN_TBL,
		iFB_LOT_NO IN FB_LOT_NO_TBL,
		iSO_KENSU IN SO_KENSU_TBL,
		iSHORIZUMI_KENSU IN SHORIZUMI_KENSU_TBL,
		iNOKORI_KENSU IN NOKORI_KENSU_TBL,
		iKJN_TAISHOKU_MSG IN KJN_TAISHOKU_MSG_TBL,
		iDIR IN DIR_TBL,
		iSHORI_EIGYO_BI IN SHORI_EIGYO_BI_TBL,

        iOPE_CD               IN VARCHAR2, -- �I�y���[�^�R�[�h
        iPGM_ID               IN VARCHAR2, -- �v���O����ID
        iDATE                 IN DATE,     -- ��������
        iIP_ADDR              IN TL_STORED_SHORI.IP%TYPE, -- ���s�[��IP�A�h���X
        iWINDOWS_LOGIN_USER   IN TL_STORED_SHORI.WINDOWS_LOGIN_USER%TYPE, -- ���s�[��OS���[�U�[
        oROW_COUNT            OUT NUMBER, -- �X�V����
        oOUT_ERR_INF_CSR      OUT ERR_INF_CSR -- �G���[���J�[�\��
	) RETURN NUMBER;

END;
/

CREATE OR REPLACE PACKAGE BODY       MT150203G001_KOKAI_MAIL
/* **********************************************************
 *  Copyright(c) 2011 beyond, INTEC Inc. All rights reserved.
 * **********************************************************/
IS

	FUNCTION INSERT_TR(
		iSEQ IN SEQ_TBL,
		iRENBAN IN RENBAN_TBL,
		iSENDER_EMAIL IN SENDER_EMAIL_TBL,
		iEMAIL_TO IN EMAIL_TO_TBL,
		iEMAIL_CC IN EMAIL_CC_TBL,
		iFB_USER_CD IN FB_USER_CD_TBL,
		iFB_SHIKIBETSU_CD IN FB_SHIKIBETSU_CD_TBL,
		iFB_SHIKIBETSU_NM IN FB_SHIKIBETSU_NM_TBL,
		iFB_SHIKIBETSU_KAISHA_NM IN FB_SHIKIBETSU_KAISHA_NM_TBL,
		iFB_LOAD_EIGY_YMD IN FB_LOAD_EIGY_YMD_TBL,
		iMENTE_E_YOTEI IN MENTE_E_YOTEI_TBL,
		iSHI_KJN_KBN IN SHI_KJN_KBN_TBL,
		iFB_LOT_NO IN FB_LOT_NO_TBL,
		iSO_KENSU IN SO_KENSU_TBL,
		iSHORIZUMI_KENSU IN SHORIZUMI_KENSU_TBL,
		iNOKORI_KENSU IN NOKORI_KENSU_TBL,
		iKJN_TAISHOKU_MSG IN KJN_TAISHOKU_MSG_TBL,
		iDIR IN DIR_TBL,
		iSHORI_EIGYO_BI IN SHORI_EIGYO_BI_TBL,

        iOPE_CD               IN VARCHAR2, -- �I�y���[�^�R�[�h
        iPGM_ID               IN VARCHAR2, -- �v���O����ID
        iDATE                 IN DATE,     -- ��������
        iIP_ADDR              IN TL_STORED_SHORI.IP%TYPE, -- ���s�[��IP�A�h���X
        iWINDOWS_LOGIN_USER   IN TL_STORED_SHORI.WINDOWS_LOGIN_USER%TYPE, -- ���s�[��OS���[�U�[
        oROW_COUNT            OUT NUMBER, -- �X�V����
        oOUT_ERR_INF_CSR      OUT ERR_INF_CSR -- �G���[���J�[�\��
	) RETURN NUMBER IS
	/************************************************************************/
	/*                              �G���[����                              */
	/************************************************************************/
	W_INDEX_N 				NUMBER(10) := 0;
	W_ERR_INF_TBL 				TYPE_ERR_INFO_TBL := TYPE_ERR_INFO_TBL();
	W_ERR_INF_RCD 				TYPE_ERR_INFO_RCD := TYPE_ERR_INFO_RCD(NULL,NULL,NULL,NULL);
	vSQL VARCHAR2(2000);

	BEGIN

	        -- �J�n���O�o��
	        ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'PL/SQL Start',iPGM_ID || '�̏������J�n���܂��B',iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

		-- �o�^�������s
		-- ���I�r�p�k�g�ݗ���
	        vSQL := '';

		vSQL := vSQL || ' INSERT INTO TR_BT020502P001  ';

		vSQL := vSQL || ' 	VALUES ( 		        ';
		vSQL := vSQL || '     :iSEQ';
		vSQL := vSQL || '    , :iRENBAN';
		vSQL := vSQL || '    , :iSENDER_EMAIL';
		vSQL := vSQL || '    , :iEMAIL_TO';
		vSQL := vSQL || '    , :iEMAIL_CC';
		vSQL := vSQL || '    , :iFB_USER_CD';
		vSQL := vSQL || '    , :iFB_SHIKIBETSU_CD';
		vSQL := vSQL || '    , :iFB_SHIKIBETSU_NM';
		vSQL := vSQL || '    , :iFB_SHIKIBETSU_KAISHA_NM';
		vSQL := vSQL || '    , :iFB_LOAD_EIGY_YMD';
		vSQL := vSQL || '    , :iMENTE_E_YOTEI';
		vSQL := vSQL || '    , :iSHI_KJN_KBN';
		vSQL := vSQL || '    , :iFB_LOT_NO';
		vSQL := vSQL || '    , :iSO_KENSU';
		vSQL := vSQL || '    , :iSHORIZUMI_KENSU';
		vSQL := vSQL || '    , :iNOKORI_KENSU';
		vSQL := vSQL || '    , :iKJN_TAISHOKU_MSG';
		vSQL := vSQL || '    , :iDIR';
		vSQL := vSQL || '    , :iSHORI_EIGYO_BI';
		vSQL := vSQL || ' 	  , :iOPE_CD                    ';
		vSQL := vSQL || ' 	  , :iDATE                      ';
		vSQL := vSQL || ' 	  , :iPGM_ID                    ';
		vSQL := vSQL || ' 	  , :iOPE_CD                    ';
		vSQL := vSQL || ' 	  , :iDATE                      ';
		vSQL := vSQL || ' 	  , :iPGM_ID)                   ';

		FORALL i IN iFB_USER_CD.FIRST .. iFB_USER_CD.LAST
			-- ���I�r�p�k���s
	        	EXECUTE IMMEDIATE vSQL USING in 
					iSEQ(i),
					iRENBAN(i),
					iSENDER_EMAIL(i),
					iEMAIL_TO(i),
					iEMAIL_CC(i),
					iFB_USER_CD(i),
					iFB_SHIKIBETSU_CD(i),
					iFB_SHIKIBETSU_NM(i),
					iFB_SHIKIBETSU_KAISHA_NM(i),
					iFB_LOAD_EIGY_YMD(i),
					iMENTE_E_YOTEI(i),
					iSHI_KJN_KBN(i),
					iFB_LOT_NO(i),
					iSO_KENSU(i),
					iSHORIZUMI_KENSU(i),
					iNOKORI_KENSU(i),
					iKJN_TAISHOKU_MSG(i),
					iDIR(i),
					iSHORI_EIGYO_BI(i),
					iOPE_CD, 
					iDATE, 
					iPGM_ID, 
					iOPE_CD, 
					iDATE, 
					iPGM_ID;

		oROW_COUNT := iSEQ.COUNT;

		-- �I�����O�o��
	        ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'PL/SQL End',iPGM_ID || '�̏������I�����܂����B',iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

	        -- ����I��
	        RETURN 0;

	-- ��O����
	EXCEPTION
		-- ���̑��G���[
		WHEN OTHERS THEN
			W_ERR_INF_RCD.ERR_CD 		:= TO_CHAR(SQLCODE);
			W_ERR_INF_RCD.ERR_MSG 		:= SUBSTR(SQLERRM, 0, 2000);
			W_INDEX_N 			:= W_ERR_INF_TBL.COUNT + 1;
			W_ERR_INF_TBL.EXTEND;
			W_ERR_INF_TBL(W_INDEX_N) 	:= W_ERR_INF_RCD;

			OPEN oOUT_ERR_INF_CSR FOR
				SELECT * FROM TABLE(W_ERR_INF_TBL);
			oROW_COUNT := SQL%ROWCOUNT;
			--�G���[���O�̓o�^
			ULT_INSERT_LOG_TABLE('ERROR',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'ERROR_INFO',W_ERR_INF_RCD.ERR_MSG,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);
		RAISE;
	END;
	
	
	FUNCTION UPDATE_TR(
		iSEQ IN SEQ_TBL,
		iRENBAN IN RENBAN_TBL,
		iSENDER_EMAIL IN SENDER_EMAIL_TBL,
		iEMAIL_TO IN EMAIL_TO_TBL,
		iEMAIL_CC IN EMAIL_CC_TBL,
		iFB_USER_CD IN FB_USER_CD_TBL,
		iFB_SHIKIBETSU_CD IN FB_SHIKIBETSU_CD_TBL,
		iFB_SHIKIBETSU_NM IN FB_SHIKIBETSU_NM_TBL,
		iFB_SHIKIBETSU_KAISHA_NM IN FB_SHIKIBETSU_KAISHA_NM_TBL,
		iFB_LOAD_EIGY_YMD IN FB_LOAD_EIGY_YMD_TBL,
		iMENTE_E_YOTEI IN MENTE_E_YOTEI_TBL,
		iSHI_KJN_KBN IN SHI_KJN_KBN_TBL,
		iFB_LOT_NO IN FB_LOT_NO_TBL,
		iSO_KENSU IN SO_KENSU_TBL,
		iSHORIZUMI_KENSU IN SHORIZUMI_KENSU_TBL,
		iNOKORI_KENSU IN NOKORI_KENSU_TBL,
		iKJN_TAISHOKU_MSG IN KJN_TAISHOKU_MSG_TBL,
		iDIR IN DIR_TBL,
		iSHORI_EIGYO_BI IN SHORI_EIGYO_BI_TBL,

        iOPE_CD               IN VARCHAR2, -- �I�y���[�^�R�[�h
        iPGM_ID               IN VARCHAR2, -- �v���O����ID
        iDATE                 IN DATE,     -- ��������
        iIP_ADDR              IN TL_STORED_SHORI.IP%TYPE, -- ���s�[��IP�A�h���X
        iWINDOWS_LOGIN_USER   IN TL_STORED_SHORI.WINDOWS_LOGIN_USER%TYPE, -- ���s�[��OS���[�U�[
        oROW_COUNT            OUT NUMBER, -- �X�V����
        oOUT_ERR_INF_CSR      OUT ERR_INF_CSR -- �G���[���J�[�\��
	) RETURN NUMBER IS
	/************************************************************************/
	/*                              �G���[����                              */
	/************************************************************************/
	W_INDEX_N 				NUMBER(10) := 0;
	W_ERR_INF_TBL 				TYPE_ERR_INFO_TBL := TYPE_ERR_INFO_TBL();
	W_ERR_INF_RCD 				TYPE_ERR_INFO_RCD := TYPE_ERR_INFO_RCD(NULL,NULL,NULL,NULL);
	vSQL VARCHAR2(2000);

	BEGIN

	        -- �J�n���O�o��
	        ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'PL/SQL Start',iPGM_ID || '�̏������J�n���܂��B',iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);
	        
	        
				-- �X�V�������s
				-- ���I�r�p�k�g�ݗ���
        			vSQL := '';
        			
				vSQL := vSQL || ' UPDATE TR_BT020502P001  ';

				vSQL := vSQL || 'SET ';
				vSQL := vSQL || 'SEQ = :iSEQ,';
				vSQL := vSQL || 'RENBAN = :iRENBAN,';
				vSQL := vSQL || 'SENDER_EMAIL = :iSENDER_EMAIL,';
				vSQL := vSQL || 'EMAIL_TO = :iEMAIL_TO,';
				vSQL := vSQL || 'EMAIL_CC = :iEMAIL_CC,';
				vSQL := vSQL || 'FB_USER_CD = :iFB_USER_CD,';
				vSQL := vSQL || 'FB_SHIKIBETSU_CD = :iFB_SHIKIBETSU_CD,';
				vSQL := vSQL || 'FB_SHIKIBETSU_NM = :iFB_SHIKIBETSU_NM,';
				vSQL := vSQL || 'FB_SHIKIBETSU_KAISHA_NM = :iFB_SHIKIBETSU_KAISHA_NM,';
				vSQL := vSQL || 'FB_LOAD_EIGY_YMD = :iFB_LOAD_EIGY_YMD,';
				vSQL := vSQL || 'MENTE_E_YOTEI = :iMENTE_E_YOTEI,';
				vSQL := vSQL || 'SHI_KJN_KBN = :iSHI_KJN_KBN,';
				vSQL := vSQL || 'FB_LOT_NO = :iFB_LOT_NO,';
				vSQL := vSQL || 'SO_KENSU = :iSO_KENSU,';
				vSQL := vSQL || 'SHORIZUMI_KENSU = :iSHORIZUMI_KENSU,';
				vSQL := vSQL || 'NOKORI_KENSU = :iNOKORI_KENSU,';
				vSQL := vSQL || 'KJN_TAISHOKU_MSG = :iKJN_TAISHOKU_MSG,';
				vSQL := vSQL || 'DIR = :iDIR,';
				vSQL := vSQL || 'SHORI_EIGYO_BI = :iSHORI_EIGYO_BI,';
				vSQL := vSQL || 'UPD_OPE_CD = :iUPD_OPE_CD,';
				vSQL := vSQL || 'UPD_DATE = :iUPD_DATE,';
				vSQL := vSQL || 'UPD_PGM_ID = :iUPD_PGM_ID ';

				vSQL := vSQL || 'WHERE ';
				vSQL := vSQL || 'SEQ            = :iSEQ ';
				vSQL := vSQL || 'AND RENBAN  = :iRENBAN ';

				FORALL i IN iFB_USER_CD.FIRST .. iFB_USER_CD.LAST
	        			-- ���I�r�p�k���s
	        			EXECUTE IMMEDIATE vSQL USING in 
						iSEQ(i),
						iRENBAN(i),
						iSENDER_EMAIL(i),
						iEMAIL_TO(i),
						iEMAIL_CC(i),
						iFB_USER_CD(i),
						iFB_SHIKIBETSU_CD(i),
						iFB_SHIKIBETSU_NM(i),
						iFB_SHIKIBETSU_KAISHA_NM(i),
						iFB_LOAD_EIGY_YMD(i),
						iMENTE_E_YOTEI(i),
						iSHI_KJN_KBN(i),
						iFB_LOT_NO(i),
						iSO_KENSU(i),
						iSHORIZUMI_KENSU(i),
						iNOKORI_KENSU(i),
						iKJN_TAISHOKU_MSG(i),
						iDIR(i),
						iSHORI_EIGYO_BI(i),
						iOPE_CD,
						iDATE,
						iPGM_ID,
						iSEQ(i),
						iRENBAN(i);


		oROW_COUNT := iSEQ.COUNT;

        -- �I�����O�o��
        ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'PL/SQL End',iPGM_ID || '�̏������I�����܂����B',iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

        -- ����I��
        RETURN 0;

    -- ��O����
    EXCEPTION
        -- ���̑��G���[
        WHEN OTHERS THEN
            W_ERR_INF_RCD.ERR_CD         := TO_CHAR(SQLCODE);
            W_ERR_INF_RCD.ERR_MSG        := SUBSTR(SQLERRM, 0, 500);
            W_INDEX_N                    := W_ERR_INF_TBL.COUNT + 1;
            W_ERR_INF_TBL.EXTEND;
            W_ERR_INF_TBL(W_INDEX_N)     := W_ERR_INF_RCD;

            OPEN oOUT_ERR_INF_CSR FOR
                SELECT * FROM TABLE(W_ERR_INF_TBL);

            --�G���[���O�̓o�^
            ULT_INSERT_LOG_TABLE('ERROR',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'ERROR_INFO',W_ERR_INF_RCD.ERR_MSG,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

        RAISE;
    END;

END;
/

