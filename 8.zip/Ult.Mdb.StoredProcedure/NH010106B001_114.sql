CREATE OR REPLACE PACKAGE NH010106B001_114
/* **********************************************************
 *  Copyright(c) 2011 beyond, INTEC Inc. All rights reserved.
 * **********************************************************/
AUTHID CURRENT_USER
IS
	/*** �J�[�\���^ ***************************************************************/
	-- �G���[���i�[�p�J�[�\���^
	TYPE ERR_INF_CSR		IS REF CURSOR;

  /*
  ************************************************************************
  *  �b��_�S��_�ǉ��A�C�e���Q�e�[�u���̍쐬
  *  CREATE_TSUIKAITEM2
  ************************************************************************
  */
  FUNCTION CREATE_TSUIKAITEM2(
  iShimeKind  IN  INTEGER,                    -- ���ߓ��敪
  iTensoYMD	IN	VARCHAR2,                     -- �]���N����
  iOPE_CD IN Varchar2,                      -- �I�y���[�^�R�[�h
  iPGM_ID IN Varchar2,                      -- �v���O����ID
  iDATE DATE,                               -- �V�X�e������
  iIP_ADDR  IN TL_STORED_SHORI.IP%TYPE,              -- ���s�[��IP�A�h���X (FW�Őݒ�)
  iWINDOWS_LOGIN_USER  IN TL_STORED_SHORI.WINDOWS_LOGIN_USER%TYPE, -- ���s�[��OS���[�U�[ (FW�Őݒ�)
  oROW_COUNT  OUT NUMBER,         -- �o�^����
  oOUT_ERR_INF_CSR   OUT ERR_INF_CSR    -- �G���[���J�[�\��
  ) RETURN NUMBER;    

END;
/
CREATE OR REPLACE PACKAGE BODY NH010106B001_114
/* **********************************************************
 *  Copyright(c) 2011 beyond, INTEC Inc. All rights reserved.
 * **********************************************************/
IS
  /*
   ************************************************************************
   * Function ID  : CREATE_TSUIKAITEM2
   * Program Name : �b��_�S��_�ǉ��A�C�e���Q�e�[�u���̍쐬
   * Parameter    :  <I> iShimeKind    �F���ߓ��敪
   *                 <I> iTensoYMD    �F�]���N����
   *                 <I> iOPE_CD    �F�I�y���[�^�R�[�h
   *                 <I> iPGM_ID    �F�v���O����ID
   *                 <I> iDATE    �F�V�X�e������ 
   *                 <I> iIP_ADDR    �F���s�[��IP�A�h���X
   *                 <I> iWINDOWS_LOGIN_USER  �F���s�[��IP�A�h���X
   *                <O> oROW_COUNT        �F�X�V����
   *                <O> oOUT_ERR_INF_CSR  �F�G���[���J�[�\��
   * Return       �F�������ʁi0:����I���A1:�ُ�I���j
   ************************************************************************
   */
  FUNCTION CREATE_TSUIKAITEM2(
  iShimeKind  IN  INTEGER,                    -- ���ߓ��敪
  iTensoYMD	IN	VARCHAR2,                     -- �]���N����
  iOPE_CD IN Varchar2,                      -- �I�y���[�^�R�[�h
  iPGM_ID IN Varchar2,                      -- �v���O����ID
  iDATE DATE,                               -- �V�X�e������  
  iIP_ADDR  IN TL_STORED_SHORI.IP%TYPE,              -- ���s�[��IP�A�h���X (FW�Őݒ�)
  iWINDOWS_LOGIN_USER  IN TL_STORED_SHORI.WINDOWS_LOGIN_USER%TYPE, -- ���s�[��OS���[�U�[ (FW�Őݒ�)
  oROW_COUNT  OUT NUMBER,         -- �o�^����
  oOUT_ERR_INF_CSR   OUT ERR_INF_CSR    -- �G���[���J�[�\��
  )RETURN NUMBER IS
PRAGMA AUTONOMOUS_TRANSACTION;
  /************************************************************************/
  /*                              �G���[����                              */
  /************************************************************************/
  W_INDEX_N           NUMBER(10) := 0;
  W_ERR_INF_TBL         TYPE_ERR_INFO_TBL := TYPE_ERR_INFO_TBL();
  W_ERR_INF_RCD         TYPE_ERR_INFO_RCD := TYPE_ERR_INFO_RCD(NULL,NULL,NULL,NULL);
  vSchemaNm           TM_JOSU.HANYO_KOMOKU%TYPE := NULL; -- �X�L�[�}����
  PGM_ID        VARCHAR2(50) := 'NH010106B001_114.CREATE_TSUIKAITEM2';
  EXECUTE_SQL   VARCHAR2(32767) := NULL;
 
  BEGIN
    
    -- �J�n���O�o��
    ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'PL/SQL Start',PGM_ID || '�̏������J�n���܂��B',iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);
    
    -- �����D���ߋ敪��"1"(������)��
    IF iShimeKind = ULT_COMMON.SHIME_SBT_CD_HISHIME THEN
    
      -- �[�i�p�X�L�[�}�̎擾���s���B
      vSchemaNm := ULT_COMMON.GET_SCHEMA_NAME(ULT_COMMON.SYS_ENV_JOSU_DAI_CD, ULT_COMMON.NOHIN_SHEMA_JOSU_SHO_CD);

      --�b��_�S��_�ǉ��A�C�e���Q�e�[�u���̃f�[�^���N���A����
      EXECUTE_SQL := 'TRUNCATE TABLE ' || vSchemaNm || '.' || 'TD_PA_TSUIKAITEM2';
      EXECUTE IMMEDIATE EXECUTE_SQL;
      ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);
      
      -- �b��_�S��_�ǉ��A�C�e���Q�e�[�u���ɓo�^����
        INSERT INTO TD_PA_TSUIKAITEM2(
							            SHIREC_ID                      ,
							            SHI_CD                         ,
							            SHI_CD_YOBI                    ,
							            KYUKYU_KOKUJISNRYJ             ,
							            DPC_TAISHO_BYOIN_FLG           ,
							            DPC_TAISHO_BYOIN_SHITEI_D_Y    ,
							            DPC_TAISHO_BYOIN_SHITEI_D_M    ,
							            DPC_TAISHO_BYOIN_SHITEI_D_D    ,
							            DPC_TAISHO_BYOIN_CANCEL_D_Y    ,
							            DPC_TAISHO_BYOIN_CANCEL_D_M    ,
							            DPC_TAISHO_BYOIN_CANCEL_D_D    ,
							            GANKYOTEN_FLG                  ,
							            GANKYOTEN_SHITEI_D_Y           ,
							            GANKYOTEN_SHITEI_D_M           ,
							            GANKYOTEN_SHITEI_D_D           ,
							            GANKYOTEN_CANCEL_D_Y           ,
							            GANKYOTEN_CANCEL_D_M           ,
							            GANKYOTEN_CANCEL_D_D           ,
							            ANZENTAISAKU_FLG               ,
							            ANZENTAISAKU_SHONIN_D_Y        ,
							            ANZENTAISAKU_SHONIN_D_M        ,
							            ANZENTAISAKU_SHONIN_D_D        ,
							            ANZENTAISAKU_CANCEL_D_Y        ,
							            ANZENTAISAKU_CANCEL_D_M        ,
							            ANZENTAISAKU_CANCEL_D_D        ,
							            KARTEKANRI_FLG                 ,
							            KARTEKANRI_SHONIN_D_Y          ,
							            KARTEKANRI_SHONIN_D_M          ,
							            KARTEKANRI_SHONIN_D_D          ,
							            KARTEKANRI_CANCEL_D_Y          ,
							            KARTEKANRI_CANCEL_D_M          ,
							            KARTEKANRI_CANCEL_D_D          ,
							            GAZOSHINDAN_FLG                ,
							            GAZOSHINDAN_SHONIN_D_Y         ,
							            GAZOSHINDAN_SHONIN_D_M         ,
							            GAZOSHINDAN_SHONIN_D_D         ,
							            GAZOSHINDAN_CANCEL_D_Y         ,
							            GAZOSHINDAN_CANCEL_D_M         ,
							            GAZOSHINDAN_CANCEL_D_D         ,
							            MASUIKANRI_FLG                 ,
							            MASUIKANRI_SHONIN_D_Y          ,
							            MASUIKANRI_SHONIN_D_M          ,
							            MASUIKANRI_SHONIN_D_D          ,
							            MASUIKANRI_CANCEL_D_Y          ,
							            MASUIKANRI_CANCEL_D_M          ,
							            MASUIKANRI_CANCEL_D_D          ,
							            JOKUSOCARE_FLG                 ,
							            JOKUSOCARE_SHONIN_D_Y          ,
							            JOKUSOCARE_SHONIN_D_M          ,
							            JOKUSOCARE_SHONIN_D_D          ,
							            JOKUSOCARE_CANCEL_D_Y          ,
							            JOKUSOCARE_CANCEL_D_M          ,
							            JOKUSOCARE_CANCEL_D_D          ,
							            GIRIKGK_FLG                    ,
							            GIRIKGK_SHONIN_D_Y             ,
							            GIRIKGK_SHONIN_D_M             ,
							            GIRIKGK_SHONIN_D_D             ,
							            GIRIKGK_CANCEL_D_Y             ,
							            GIRIKGK_CANCEL_D_M             ,
							            GIRIKGK_CANCEL_D_D             ,
							            ZAITAKUSHIEN_FLG               ,
							            ZAITAKUSHIEN_SHONIN_D_Y        ,
							            ZAITAKUSHIEN_SHONIN_D_M        ,
							            ZAITAKUSHIEN_SHONIN_D_D        ,
							            ZAITAKUSHIEN_CANCEL_D_Y        ,
							            ZAITAKUSHIEN_CANCEL_D_M        ,
							            ZAITAKUSHIEN_CANCEL_D_D        ,
							            ZAIISOKAN_FLG                  ,
							            ZAIISOKAN_SHONIN_D_Y           ,
							            ZAIISOKAN_SHONIN_D_M           ,
							            ZAIISOKAN_SHONIN_D_D           ,
							            ZAIISOKAN_CANCEL_D_Y           ,
							            ZAIISOKAN_CANCEL_D_M           ,
							            ZAIISOKAN_CANCEL_D_D           ,
							            SHONIYAKAN_FLG                 ,
							            SHONIYAKAN_SHONIN_D_Y          ,
							            SHONIYAKAN_SHONIN_D_M          ,
							            SHONIYAKAN_SHONIN_D_D          ,
							            SHONIYAKAN_CANCEL_D_Y          ,
							            SHONIYAKAN_CANCEL_D_M          ,
							            SHONIYAKAN_CANCEL_D_D          ,
							            CHIKRENKEIPATH_FLG             ,
							            CHIKRENKEIPATH_CD_1            ,
							            CHIKRENKEIPATH_CD_2            ,
							            CHIKRENKEIPATH_CD_3            ,
							            CHIKRENKEIPATH_CD_4            ,
							            CHIKRENKEIPATH_CD_5            ,
							            CHIKRENKEIPATH_CD_6            ,
							            CHIKRENKEIPATH_CD_7            ,
							            CHIKRENKEIPATH_CD_8            ,
							            CHIKRENKEIPATH_CD_9            ,
							            CHIKRENKEIPATH_CD_10           ,
							            CHIKRENKEIPATH_CD_11           ,
							            CHIKRENKEIPATH_CD_12           ,
							            CHIKRENKEIPATH_CD_13           ,
							            CHIKRENKEIPATH_CD_14           ,
							            CHIKRENKEIPATH_CD_15           ,
							            CHIKRENKEIPATH_CD_16           ,
							            CHIKRENKEIPATH_CD_17           ,
							            CHIKRENKEIPATH_CD_18           ,
							            CHIKRENKEIPATH_CD_19           ,
							            CHIKRENKEIPATH_CD_20           ,
							            SHIKKANBETSUREHA_FLG           ,
							            SHIKKANBETSUREHA_CD_1          ,
							            SHIKKANBETSUREHA_CD_2          ,
							            SHIKKANBETSUREHA_CD_3          ,
							            SHIKKANBETSUREHA_CD_4          ,
							            SHIKKANBETSUREHA_CD_5          ,
							            SHIKKANBETSUREHA_CD_6          ,
							            SHIKKANBETSUREHA_CD_7          ,
							            SHIKKANBETSUREHA_CD_8          ,
							            SHIKKANBETSUREHA_CD_9          ,
							            SHIKKANBETSUREHA_CD_10         ,
							            SEISAKUIRY_FLG                 ,
							            SEISAKUIRY_1_CD                ,
							            SEISAKUIRY_1_KBN               ,
							            SEISAKUIRY_2_CD                ,
							            SEISAKUIRY_2_KBN               ,
							            SEISAKUIRY_3_CD                ,
							            SEISAKUIRY_3_KBN               ,
							            SEISAKUIRY_4_CD                ,
							            SEISAKUIRY_4_KBN               ,
							            SEISAKUIRY_5_CD                ,
							            SEISAKUIRY_5_KBN               ,
							            SEISAKUIRY_6_CD                ,
							            SEISAKUIRY_6_KBN               ,
							            SEISAKUIRY_7_CD                ,
							            SEISAKUIRY_7_KBN               ,
							            SEISAKUIRY_8_CD                ,
							            SEISAKUIRY_8_KBN               ,
							            SEISAKUIRY_9_CD                ,
							            SEISAKUIRY_9_KBN               ,
							            SEISAKUIRY_10_CD               ,
							            SEISAKUIRY_10_KBN              ,
							            SEISAKUIRY_11_CD               ,
							            SEISAKUIRY_11_KBN              ,
							            SEISAKUIRY_12_CD               ,
							            SEISAKUIRY_12_KBN              ,
							            SEISAKUIRY_13_CD               ,
							            SEISAKUIRY_13_KBN              ,
							            SEISAKUIRY_14_CD               ,
							            SEISAKUIRY_14_KBN              ,
							            SEISAKUIRY_15_CD               ,
							            SEISAKUIRY_15_KBN              ,
							            SEISAKUIRY_16_CD               ,
							            SEISAKUIRY_16_KBN              ,
							            SEISAKUIRY_17_CD               ,
							            SEISAKUIRY_17_KBN              ,
							            SEISAKUIRY_18_CD               ,
							            SEISAKUIRY_18_KBN              ,
							            SEISAKUIRY_19_CD               ,
							            SEISAKUIRY_19_KBN              ,
							            SEISAKUIRY_20_CD               ,
							            SEISAKUIRY_20_KBN              ,
							            TENSO_Y                        ,
							            TENSO_M                        ,
							            TENSO_D                        ,
							            MENTE_Y                        ,
							            MENTE_M                        ,
							            MENTE_D                        ,
							            MOD_KBN                        ,
							            TRK_OPE_CD                     ,
							            TRK_DATE                       ,
							            TRK_PGM_ID                     ,
							            UPD_OPE_CD                     ,
							            UPD_DATE                       ,                      
							            UPD_PGM_ID
							         )  
					        SELECT
					            TS.REC_ID,        
					            TS.SHI_CD, 
					            NULL,
					            TS.KYUKYUKOKUJI_FLG,
					            TS.DPC_FLG,                      
					            SUBSTR(TS.DPC_SHITEI_YMD,1,4),
					            SUBSTR(TS.DPC_SHITEI_YMD,5,2),
					            SUBSTR(TS.DPC_SHITEI_YMD,7,2),
					            SUBSTR(TS.DPC_CANCEL_YMD,1,4),
					            SUBSTR(TS.DPC_CANCEL_YMD,5,2),
					            SUBSTR(TS.DPC_CANCEL_YMD,7,2),
					                            
					            TS.GANKYOTEN_FLG,                      
					            SUBSTR(TS.GANKYOTEN_SHITEI_YMD,1,4),
					            SUBSTR(TS.GANKYOTEN_SHITEI_YMD,5,2),
					            SUBSTR(TS.GANKYOTEN_SHITEI_YMD,7,2),
					            SUBSTR(TS.GANKYOTEN_CANCEL_YMD,1,4),
					            SUBSTR(TS.GANKYOTEN_CANCEL_YMD,5,2),
					            SUBSTR(TS.GANKYOTEN_CANCEL_YMD,7,2),
					                                     
					            TS.IRYANZEN_FLG,                                  
					            SUBSTR(TS.IRYANZEN_SHONIN_YMD,1,4),
					            SUBSTR(TS.IRYANZEN_SHONIN_YMD,5,2),
					            SUBSTR(TS.IRYANZEN_SHONIN_YMD,7,2),
					            SUBSTR(TS.IRYANZEN_CANCEL_YMD,1,4),
					            SUBSTR(TS.IRYANZEN_CANCEL_YMD,5,2),
					            SUBSTR(TS.IRYANZEN_CANCEL_YMD,7,2),
					                              
					            TS.KARTE_FLG,                      
					            SUBSTR(TS.KARTE_SHONIN_YMD,1,4),
					            SUBSTR(TS.KARTE_SHONIN_YMD,5,2),
					            SUBSTR(TS.KARTE_SHONIN_YMD,7,2),
					            SUBSTR(TS.KARTE_CANCEL_YMD,1,4),
					            SUBSTR(TS.KARTE_CANCEL_YMD,5,2),
					            SUBSTR(TS.KARTE_CANCEL_YMD,7,2),
					            
					            TS.GAZOSHINDAN_FLG,                                                                  
					            SUBSTR(TS.GAZOSHINDAN_SHONIN_YMD,1,4),
					            SUBSTR(TS.GAZOSHINDAN_SHONIN_YMD,5,2),
					            SUBSTR(TS.GAZOSHINDAN_SHONIN_YMD,7,2),
					            SUBSTR(TS.GAZOSHINDAN_CANCEL_YMD,1,4),
					            SUBSTR(TS.GAZOSHINDAN_CANCEL_YMD,5,2),
					            SUBSTR(TS.GAZOSHINDAN_CANCEL_YMD,7,2),
					                 
					            TS.MASUIKANRI_FLG,                          
					            SUBSTR(TS.MASUIKANRI_SHONIN_YMD,1,4),
					            SUBSTR(TS.MASUIKANRI_SHONIN_YMD,5,2),
					            SUBSTR(TS.MASUIKANRI_SHONIN_YMD,7,2),
					            SUBSTR(TS.MASUIKANRI_CANCEL_YMD,1,4),
					            SUBSTR(TS.MASUIKANRI_CANCEL_YMD,5,2),
					            SUBSTR(TS.MASUIKANRI_CANCEL_YMD,7,2),
					                                     
					            TS.JOKUSOCARE_FLG,                      
					            SUBSTR(TS.JOKUSOCARE_SHONIN_YMD,1,4),
					            SUBSTR(TS.JOKUSOCARE_SHONIN_YMD,5,2),
					            SUBSTR(TS.JOKUSOCARE_SHONIN_YMD,7,2),
					            SUBSTR(TS.JOKUSOCARE_CANCEL_YMD,1,4),
					            SUBSTR(TS.JOKUSOCARE_CANCEL_YMD,5,2),
					            SUBSTR(TS.JOKUSOCARE_CANCEL_YMD,7,2),
					              
					            TS.GIRIKGK_FLG,                        
					            SUBSTR(TS.GIRIKGK_SHONIN_YMD,1,4),
					            SUBSTR(TS.GIRIKGK_SHONIN_YMD,5,2),
					            SUBSTR(TS.GIRIKGK_SHONIN_YMD,7,2),
					            SUBSTR(TS.GIRIKGK_CANCEL_YMD,1,4),
					            SUBSTR(TS.GIRIKGK_CANCEL_YMD,5,2),
					            SUBSTR(TS.GIRIKGK_CANCEL_YMD,7,2),
					            
					            TS.ZAITAKUSHIEN_FLG,                                  
					            SUBSTR(TS.ZAITAKUSHIEN_SHONIN_YMD,1,4),
					            SUBSTR(TS.ZAITAKUSHIEN_SHONIN_YMD,5,2),
					            SUBSTR(TS.ZAITAKUSHIEN_SHONIN_YMD,7,2),
					            SUBSTR(TS.ZAITAKUSHIEN_CANCEL_YMD,1,4),
					            SUBSTR(TS.ZAITAKUSHIEN_CANCEL_YMD,5,2),
					            SUBSTR(TS.ZAITAKUSHIEN_CANCEL_YMD,7,2),
					            
					            TS.ZAIISOKAN_FLG,                       
					            SUBSTR(TS.ZAIISOKAN_SHONIN_YMD,1,4),
					            SUBSTR(TS.ZAIISOKAN_SHONIN_YMD,5,2),
					            SUBSTR(TS.ZAIISOKAN_SHONIN_YMD,7,2),
					            SUBSTR(TS.ZAIISOKAN_CANCEL_YMD,1,4),
					            SUBSTR(TS.ZAIISOKAN_CANCEL_YMD,5,2),
					            SUBSTR(TS.ZAIISOKAN_CANCEL_YMD,7,2),
					                                                                               
					            TS.SHONIYAKAN_FLG,                      
					            SUBSTR(TS.SHONIYAKAN_SHONIN_YMD,1,4),
					            SUBSTR(TS.SHONIYAKAN_SHONIN_YMD,5,2),
					            SUBSTR(TS.SHONIYAKAN_SHONIN_YMD,7,2),
					            SUBSTR(TS.SHONIYAKAN_CANCEL_YMD,1,4),
					            SUBSTR(TS.SHONIYAKAN_CANCEL_YMD,5,2),
					            SUBSTR(TS.SHONIYAKAN_CANCEL_YMD,7,2),
					            TS.CHIKRENKEIPATH_FLG,                      
					            TS.CHIKRENKEIPATH_CD_01,                                  
					            TS.CHIKRENKEIPATH_CD_02,                      
					            TS.CHIKRENKEIPATH_CD_03,                      
					            TS.CHIKRENKEIPATH_CD_04,                      
					            TS.CHIKRENKEIPATH_CD_05,                      
					            TS.CHIKRENKEIPATH_CD_06,                      
					            TS.CHIKRENKEIPATH_CD_07,                      
					            TS.CHIKRENKEIPATH_CD_08,                      
					            TS.CHIKRENKEIPATH_CD_09,                      
					            TS.CHIKRENKEIPATH_CD_10,                      
					            TS.CHIKRENKEIPATH_CD_11,                                  
					            TS.CHIKRENKEIPATH_CD_12,                      
					            TS.CHIKRENKEIPATH_CD_13,                      
					            TS.CHIKRENKEIPATH_CD_14,                      
					            TS.CHIKRENKEIPATH_CD_15,                      
					            TS.CHIKRENKEIPATH_CD_16,                      
					            TS.CHIKRENKEIPATH_CD_17,                      
					            TS.CHIKRENKEIPATH_CD_18,                      
					            TS.CHIKRENKEIPATH_CD_19,                      
					            TS.CHIKRENKEIPATH_CD_20,                                                               
					            TS.SHIKKANBETSUREHA_FLG,                      
					            TS.SHIKKANBETSUREHA_CD_01,                      
					            TS.SHIKKANBETSUREHA_CD_02,                      
					            TS.SHIKKANBETSUREHA_CD_03,                      
					            TS.SHIKKANBETSUREHA_CD_04,                                  
					            TS.SHIKKANBETSUREHA_CD_05,                      
					            TS.SHIKKANBETSUREHA_CD_06,                      
					            TS.SHIKKANBETSUREHA_CD_07,                      
					            TS.SHIKKANBETSUREHA_CD_08,                      
					            TS.SHIKKANBETSUREHA_CD_09,                      
					            TS.SHIKKANBETSUREHA_CD_10,                      
					                                
					            TS.SEISAKUIRY_FLG,                      
					            TS.SEISAKUIRY_BNY_CD_01, 
					            TS.SEISAKUIRY_KBN_CD_01,                     
					            TS.SEISAKUIRY_BNY_CD_02,
					            TS.SEISAKUIRY_KBN_CD_02,                      
					            TS.SEISAKUIRY_BNY_CD_03,
					            TS.SEISAKUIRY_KBN_CD_03,                                   
					            TS.SEISAKUIRY_BNY_CD_04,
					            TS.SEISAKUIRY_KBN_CD_04,                      
					            TS.SEISAKUIRY_BNY_CD_05, 
					            TS.SEISAKUIRY_KBN_CD_05,                     
					            TS.SEISAKUIRY_BNY_CD_06,
					            TS.SEISAKUIRY_KBN_CD_06,                      
					            TS.SEISAKUIRY_BNY_CD_07,
					            TS.SEISAKUIRY_KBN_CD_07,                       
					            TS.SEISAKUIRY_BNY_CD_08,
					            TS.SEISAKUIRY_KBN_CD_08,                      
					            TS.SEISAKUIRY_BNY_CD_09,
					            TS.SEISAKUIRY_KBN_CD_09,                         
					            TS.SEISAKUIRY_BNY_CD_10,
					            TS.SEISAKUIRY_KBN_CD_10,                       
					            TS.SEISAKUIRY_BNY_CD_11,
					            TS.SEISAKUIRY_KBN_CD_11,                         
					            TS.SEISAKUIRY_BNY_CD_12,
					            TS.SEISAKUIRY_KBN_CD_12,                      
					            TS.SEISAKUIRY_BNY_CD_13, 
					            TS.SEISAKUIRY_KBN_CD_13,                                 
					            TS.SEISAKUIRY_BNY_CD_14, 
					            TS.SEISAKUIRY_KBN_CD_14,                     
					            TS.SEISAKUIRY_BNY_CD_15,
					            TS.SEISAKUIRY_KBN_CD_15,                       
					            TS.SEISAKUIRY_BNY_CD_16,
					            TS.SEISAKUIRY_KBN_CD_16,                      
					            TS.SEISAKUIRY_BNY_CD_17,
					            TS.SEISAKUIRY_KBN_CD_17,                        
					            TS.SEISAKUIRY_BNY_CD_18,
					            TS.SEISAKUIRY_KBN_CD_18,                       
					            TS.SEISAKUIRY_BNY_CD_19,
					            TS.SEISAKUIRY_KBN_CD_19,                       
					            TS.SEISAKUIRY_BNY_CD_20,                      
					            TS.SEISAKUIRY_KBN_CD_20,                                                         
					            SUBSTR(iTensoYMD,1,4),
					            SUBSTR(iTensoYMD,5,2),
					            SUBSTR(iTensoYMD,7,2),
					            SUBSTR(TS.UPD_EIGY_YMD,1,4),
					            SUBSTR(TS.UPD_EIGY_YMD,5,2),
					            SUBSTR(TS.UPD_EIGY_YMD,7,2),
					            NULL,                      
					            iOPE_CD,
					            iDATE,
					            iPGM_ID,
					            iOPE_CD,
					            iDATE,
					            iPGM_ID
					       FROM (
					       			SELECT	
								        TTT.REC_ID,                                          
								        TTT.SHI_CD,                                          
								        TTT.DPC_FLG,                                          
								        TTT.DPC_SHITEI_YMD,                                          
								        TTT.DPC_CANCEL_YMD,                                          
								        TTT.GANKYOTEN_FLG,                                          
								        TTT.GANKYOTEN_SHITEI_YMD,                                          
								        TTT.GANKYOTEN_CANCEL_YMD,                                          
								        TTT.KARTE_FLG,                                          
								        TTT.KARTE_SHONIN_YMD,                                          
								        TTT.KARTE_CANCEL_YMD,                                          
								        TTT.IRYANZEN_FLG,                                          
								        TTT.IRYANZEN_SHONIN_YMD,                                          
								        TTT.IRYANZEN_CANCEL_YMD,                                          
								        TTT.JOKUSOCARE_FLG,                                          
								        TTT.JOKUSOCARE_SHONIN_YMD,                                          
								        TTT.JOKUSOCARE_CANCEL_YMD,                                          
								        TTT.SHONIYAKAN_FLG,                                          
								        TTT.SHONIYAKAN_SHONIN_YMD,                                          
								        TTT.SHONIYAKAN_CANCEL_YMD,                                          
								        TTT.CHIKRENKEIPATH_FLG,                                          
								        TTT.CHIKRENKEIPATH_CD_01,                                          
								        TTT.CHIKRENKEIPATH_CD_02,                                          
								        TTT.CHIKRENKEIPATH_CD_03,                                          
								        TTT.CHIKRENKEIPATH_CD_04,                                          
								        TTT.CHIKRENKEIPATH_CD_05,                                          
								        TTT.CHIKRENKEIPATH_CD_06,                                          
								        TTT.CHIKRENKEIPATH_CD_07,                                          
								        TTT.CHIKRENKEIPATH_CD_08,                                          
								        TTT.CHIKRENKEIPATH_CD_09,                                          
								        TTT.CHIKRENKEIPATH_CD_10,                                          
								        TTT.CHIKRENKEIPATH_CD_11,                                          
								        TTT.CHIKRENKEIPATH_CD_12,                                          
								        TTT.CHIKRENKEIPATH_CD_13,                                          
								        TTT.CHIKRENKEIPATH_CD_14,                                          
								        TTT.CHIKRENKEIPATH_CD_15,                                          
								        TTT.CHIKRENKEIPATH_CD_16,                                          
								        TTT.CHIKRENKEIPATH_CD_17,                                          
								        TTT.CHIKRENKEIPATH_CD_18,                                          
								        TTT.CHIKRENKEIPATH_CD_19,                                          
								        TTT.CHIKRENKEIPATH_CD_20,                                          
								        TTT.GAZOSHINDAN_FLG,                                          
								        TTT.GAZOSHINDAN_SHONIN_YMD,                                          
								        TTT.GAZOSHINDAN_CANCEL_YMD,                                          
								        TTT.GIRIKGK_FLG,                                          
								        TTT.GIRIKGK_SHONIN_YMD,                                          
								        TTT.GIRIKGK_CANCEL_YMD,                                          
								        TTT.SHIKKANBETSUREHA_FLG,                                          
								        TTT.SHIKKANBETSUREHA_CD_01,                                          
								        TTT.SHIKKANBETSUREHA_CD_02,                                          
								        TTT.SHIKKANBETSUREHA_CD_03,                                          
								        TTT.SHIKKANBETSUREHA_CD_04,                                          
								        TTT.SHIKKANBETSUREHA_CD_05,                                          
								        TTT.SHIKKANBETSUREHA_CD_06,                                          
								        TTT.SHIKKANBETSUREHA_CD_07,                                          
								        TTT.SHIKKANBETSUREHA_CD_08,                                          
								        TTT.SHIKKANBETSUREHA_CD_09,                                          
								        TTT.SHIKKANBETSUREHA_CD_10,                                          
								        TTT.MASUIKANRI_FLG,                                          
								        TTT.MASUIKANRI_SHONIN_YMD,                                          
								        TTT.MASUIKANRI_CANCEL_YMD,                                          
								        TTT.ZAITAKUSHIEN_FLG,                                          
								        TTT.ZAITAKUSHIEN_SHONIN_YMD,                                          
								        TTT.ZAITAKUSHIEN_CANCEL_YMD,                                          
								        TTT.ZAIISOKAN_FLG,                                          
								        TTT.ZAIISOKAN_SHONIN_YMD,                                          
								        TTT.ZAIISOKAN_CANCEL_YMD,                                          
								        TTT.KYUKYUKOKUJI_FLG,                                          
								        TTT.SEISAKUIRY_FLG,                                          
								        TTT.SEISAKUIRY_BNY_CD_01,                                          
								        TTT.SEISAKUIRY_BNY_CD_02,                                          
								        TTT.SEISAKUIRY_BNY_CD_03,                                          
								        TTT.SEISAKUIRY_BNY_CD_04,                                          
								        TTT.SEISAKUIRY_BNY_CD_05,                                          
								        TTT.SEISAKUIRY_BNY_CD_06,                                          
								        TTT.SEISAKUIRY_BNY_CD_07,                                          
								        TTT.SEISAKUIRY_BNY_CD_08,                                          
								        TTT.SEISAKUIRY_BNY_CD_09,                                          
								        TTT.SEISAKUIRY_BNY_CD_10,                                          
								        TTT.SEISAKUIRY_BNY_CD_11,                                          
								        TTT.SEISAKUIRY_BNY_CD_12,                                          
								        TTT.SEISAKUIRY_BNY_CD_13,                                          
								        TTT.SEISAKUIRY_BNY_CD_14,                                          
								        TTT.SEISAKUIRY_BNY_CD_15,                                          
								        TTT.SEISAKUIRY_BNY_CD_16,                                          
								        TTT.SEISAKUIRY_BNY_CD_17,                                          
								        TTT.SEISAKUIRY_BNY_CD_18,                                          
								        TTT.SEISAKUIRY_BNY_CD_19,                                          
								        TTT.SEISAKUIRY_BNY_CD_20,                                          
								        TTT.SEISAKUIRY_KBN_CD_01,                                          
								        TTT.SEISAKUIRY_KBN_CD_02,                                          
								        TTT.SEISAKUIRY_KBN_CD_03,                                          
								        TTT.SEISAKUIRY_KBN_CD_04,                                          
								        TTT.SEISAKUIRY_KBN_CD_05,                                          
								        TTT.SEISAKUIRY_KBN_CD_06,                                          
								        TTT.SEISAKUIRY_KBN_CD_07,                                          
								        TTT.SEISAKUIRY_KBN_CD_08,                                          
								        TTT.SEISAKUIRY_KBN_CD_09,                                          
								        TTT.SEISAKUIRY_KBN_CD_10,                                          
								        TTT.SEISAKUIRY_KBN_CD_11,                                          
								        TTT.SEISAKUIRY_KBN_CD_12,                                          
								        TTT.SEISAKUIRY_KBN_CD_13,                                          
								        TTT.SEISAKUIRY_KBN_CD_14,                                          
								        TTT.SEISAKUIRY_KBN_CD_15,                                          
								        TTT.SEISAKUIRY_KBN_CD_16,                                          
								        TTT.SEISAKUIRY_KBN_CD_17,                                          
								        TTT.SEISAKUIRY_KBN_CD_18,                                          
								        TTT.SEISAKUIRY_KBN_CD_19,                                          
								        TTT.SEISAKUIRY_KBN_CD_20,                                          
								        TTT.UPD_EIGY_YMD                                          
								    FROM  TT_TIKY_SHI�@TTS                                      
								    INNER JOIN TT_TIKY_TSUIKAITEM�@TTT ON TTS�DREC_ID = TTT�DREC_ID AND  TTS�DSHI_CD = TTT�DSHI_CD                                          
								    WHERE�@TTS.REC_ID�@= '00'                                           
								          AND�@TTS.DEL_FLG IS NULL                                            
								          AND�@TTT�DITEM_2_MOD_EIGY_YMD IS NOT NULL                                            
								          AND�@TTT.DEL_FLG IS NULL    
								    UNION
									  SELECT																	
								        TTT.REC_ID,																
								        TTT.SHI_CD,																
								        NULL AS DPC_FLG,																
								        NULL AS DPC_SHITEI_YMD,																
								        NULL AS DPC_CANCEL_YMD,																
								        NULL AS GANKYOTEN_FLG,																
								        NULL AS GANKYOTEN_SHITEI_YMD,																
								        NULL AS GANKYOTEN_CANCEL_YMD,																
								        NULL AS KARTE_FLG,																
								        NULL AS KARTE_SHONIN_YMD,																
								        NULL AS KARTE_CANCEL_YMD,																
								        NULL AS IRYANZEN_FLG,																
								        NULL AS IRYANZEN_SHONIN_YMD,																
								        NULL AS IRYANZEN_CANCEL_YMD,																
								        NULL AS JOKUSOCARE_FLG,																
								        NULL AS JOKUSOCARE_SHONIN_YMD,																
								        NULL AS JOKUSOCARE_CANCEL_YMD,																
								        NULL AS SHONIYAKAN_FLG,																
								        NULL AS SHONIYAKAN_SHONIN_YMD,																
								        NULL AS SHONIYAKAN_CANCEL_YMD,																
								        NULL AS CHIKRENKEIPATH_FLG,																
								        NULL AS CHIKRENKEIPATH_CD_01,																
								        NULL AS CHIKRENKEIPATH_CD_02,																
								        NULL AS CHIKRENKEIPATH_CD_03,																
								        NULL AS CHIKRENKEIPATH_CD_04,																
								        NULL AS CHIKRENKEIPATH_CD_05,																
								        NULL AS CHIKRENKEIPATH_CD_06,																
								        NULL AS CHIKRENKEIPATH_CD_07,																
								        NULL AS CHIKRENKEIPATH_CD_08,																
								        NULL AS CHIKRENKEIPATH_CD_09,																
								        NULL AS CHIKRENKEIPATH_CD_10,																
								        NULL AS CHIKRENKEIPATH_CD_11,																
								        NULL AS CHIKRENKEIPATH_CD_12,																
								        NULL AS CHIKRENKEIPATH_CD_13,																
								        NULL AS CHIKRENKEIPATH_CD_14,																
								        NULL AS CHIKRENKEIPATH_CD_15,																
								        NULL AS CHIKRENKEIPATH_CD_16,																
								        NULL AS CHIKRENKEIPATH_CD_17,																
								        NULL AS CHIKRENKEIPATH_CD_18,																
								        NULL AS CHIKRENKEIPATH_CD_19,																
								        NULL AS CHIKRENKEIPATH_CD_20,																
								        NULL AS GAZOSHINDAN_FLG,																
								        NULL AS GAZOSHINDAN_SHONIN_YMD,																
								        NULL AS GAZOSHINDAN_CANCEL_YMD,																
								        NULL AS GIRIKGK_FLG,																
								        NULL AS GIRIKGK_SHONIN_YMD,																
								        NULL AS GIRIKGK_CANCEL_YMD,																
								        NULL AS SHIKKANBETSUREHA_FLG,																
								        NULL AS SHIKKANBETSUREHA_CD_01,																
								        NULL AS SHIKKANBETSUREHA_CD_02,																
								        NULL AS SHIKKANBETSUREHA_CD_03,																
								        NULL AS SHIKKANBETSUREHA_CD_04,																
								        NULL AS SHIKKANBETSUREHA_CD_05,																
								        NULL AS SHIKKANBETSUREHA_CD_06,																
								        NULL AS SHIKKANBETSUREHA_CD_07,																
								        NULL AS SHIKKANBETSUREHA_CD_08,																
								        NULL AS SHIKKANBETSUREHA_CD_09,																
								        NULL AS SHIKKANBETSUREHA_CD_10,																
								        NULL AS MASUIKANRI_FLG,																
								        NULL AS MASUIKANRI_SHONIN_YMD,																
								        NULL AS MASUIKANRI_CANCEL_YMD,																
								        NULL AS ZAITAKUSHIEN_FLG,																
								        NULL AS ZAITAKUSHIEN_SHONIN_YMD,																
								        NULL AS ZAITAKUSHIEN_CANCEL_YMD,																
								        NULL AS ZAIISOKAN_FLG,																
								        NULL AS ZAIISOKAN_SHONIN_YMD,																
								        NULL AS ZAIISOKAN_CANCEL_YMD,																
								        NULL AS KYUKYUKOKUJI_FLG,																
								        NULL AS SEISAKUIRY_FLG,																
								        NULL AS SEISAKUIRY_BNY_CD_01,																
								        NULL AS SEISAKUIRY_BNY_CD_02,																
								        NULL AS SEISAKUIRY_BNY_CD_03,																
								        NULL AS SEISAKUIRY_BNY_CD_04,																
								        NULL AS SEISAKUIRY_BNY_CD_05,																
								        NULL AS SEISAKUIRY_BNY_CD_06,																
								        NULL AS SEISAKUIRY_BNY_CD_07,																
								        NULL AS SEISAKUIRY_BNY_CD_08,																
								        NULL AS SEISAKUIRY_BNY_CD_09,																
								        NULL AS SEISAKUIRY_BNY_CD_10,																
								        NULL AS SEISAKUIRY_BNY_CD_11,																
								        NULL AS SEISAKUIRY_BNY_CD_12,																
								        NULL AS SEISAKUIRY_BNY_CD_13,																
								        NULL AS SEISAKUIRY_BNY_CD_14,																
								        NULL AS SEISAKUIRY_BNY_CD_15,																
								        NULL AS SEISAKUIRY_BNY_CD_16,																
								        NULL AS SEISAKUIRY_BNY_CD_17,																
								        NULL AS SEISAKUIRY_BNY_CD_18,																
								        NULL AS SEISAKUIRY_BNY_CD_19,																
								        NULL AS SEISAKUIRY_BNY_CD_20,																
								        NULL AS SEISAKUIRY_KBN_CD_01,																
								        NULL AS SEISAKUIRY_KBN_CD_02,																
								        NULL AS SEISAKUIRY_KBN_CD_03,																
								        NULL AS SEISAKUIRY_KBN_CD_04,																
								        NULL AS SEISAKUIRY_KBN_CD_05,																
								        NULL AS SEISAKUIRY_KBN_CD_06,																
								        NULL AS SEISAKUIRY_KBN_CD_07,																
								        NULL AS SEISAKUIRY_KBN_CD_08,																
								        NULL AS SEISAKUIRY_KBN_CD_09,																
								        NULL AS SEISAKUIRY_KBN_CD_10,																
								        NULL AS SEISAKUIRY_KBN_CD_11,																
								        NULL AS SEISAKUIRY_KBN_CD_12,																
								        NULL AS SEISAKUIRY_KBN_CD_13,																
								        NULL AS SEISAKUIRY_KBN_CD_14,																
								        NULL AS SEISAKUIRY_KBN_CD_15,																
								        NULL AS SEISAKUIRY_KBN_CD_16,																
								        NULL AS SEISAKUIRY_KBN_CD_17,																
								        NULL AS SEISAKUIRY_KBN_CD_18,																
								        NULL AS SEISAKUIRY_KBN_CD_19,																
								        NULL AS SEISAKUIRY_KBN_CD_20,																
								        TTT.UPD_EIGY_YMD																
									   FROM TT_TIKY_SHI�@TTS														
								     INNER JOIN TT_TIKY_TSUIKAITEM�@TTT ON TTS�DREC_ID = TTT�DREC_ID	AND TTS�DSHI_CD = TTT�DSHI_CD																
									   WHERE�@TTS.REC_ID�@= '00' 																
									         AND�@TTS.DEL_FLG IS NULL																	
									         AND�@TTT�DITEM_2_MOD_EIGY_YMD IS NOT NULL																	
									         AND�@TTT.DEL_FLG = '1'
					       		) TS; 
					       		
	 -- �b��_�S��_�ǉ��A�C�e���Q�e�[�u���̃��O��o�^����
	 EXECUTE_SQL:='  INSERT INTO TD_PA_TSUIKAITEM2(            ' ||
					'  SHIREC_ID                      ,          ' ||
					'  SHI_CD                         ,          ' ||
					'  SHI_CD_YOBI                    ,          ' ||
					'  KYUKYU_KOKUJISNRYJ             ,          ' ||
					'  DPC_TAISHO_BYOIN_FLG           ,          ' ||
					'  DPC_TAISHO_BYOIN_SHITEI_D_Y    ,          ' ||
					'  DPC_TAISHO_BYOIN_SHITEI_D_M    ,          ' ||
					'  DPC_TAISHO_BYOIN_SHITEI_D_D    ,          ' ||
					'  DPC_TAISHO_BYOIN_CANCEL_D_Y    ,          ' ||
					'  DPC_TAISHO_BYOIN_CANCEL_D_M    ,          ' ||
					'  DPC_TAISHO_BYOIN_CANCEL_D_D    ,          ' ||
					'  GANKYOTEN_FLG                  ,          ' ||
					'  GANKYOTEN_SHITEI_D_Y           ,          ' ||
					'  GANKYOTEN_SHITEI_D_M           ,          ' ||
					'  GANKYOTEN_SHITEI_D_D           ,          ' ||
					'  GANKYOTEN_CANCEL_D_Y           ,          ' ||
					'  GANKYOTEN_CANCEL_D_M           ,          ' ||
					'  GANKYOTEN_CANCEL_D_D           ,          ' ||
					'  ANZENTAISAKU_FLG               ,          ' ||
					'  ANZENTAISAKU_SHONIN_D_Y        ,          ' ||
					'  ANZENTAISAKU_SHONIN_D_M        ,          ' ||
					'  ANZENTAISAKU_SHONIN_D_D        ,          ' ||
					'  ANZENTAISAKU_CANCEL_D_Y        ,          ' ||
					'  ANZENTAISAKU_CANCEL_D_M        ,          ' ||
					'  ANZENTAISAKU_CANCEL_D_D        ,          ' ||
					'  KARTEKANRI_FLG                 ,          ' ||
					'  KARTEKANRI_SHONIN_D_Y          ,          ' ||
					'  KARTEKANRI_SHONIN_D_M          ,          ' ||
					'  KARTEKANRI_SHONIN_D_D          ,          ' ||
					'  KARTEKANRI_CANCEL_D_Y          ,          ' ||
					'  KARTEKANRI_CANCEL_D_M          ,          ' ||
					'  KARTEKANRI_CANCEL_D_D          ,          ' ||
					'  GAZOSHINDAN_FLG                ,          ' ||
					'  GAZOSHINDAN_SHONIN_D_Y         ,          ' ||
					'  GAZOSHINDAN_SHONIN_D_M         ,          ' ||
					'  GAZOSHINDAN_SHONIN_D_D         ,          ' ||
					'  GAZOSHINDAN_CANCEL_D_Y         ,          ' ||
					'  GAZOSHINDAN_CANCEL_D_M         ,          ' ||
					'  GAZOSHINDAN_CANCEL_D_D         ,          ' ||
					'  MASUIKANRI_FLG                 ,          ' ||
					'  MASUIKANRI_SHONIN_D_Y          ,          ' ||
					'  MASUIKANRI_SHONIN_D_M          ,          ' ||
					'  MASUIKANRI_SHONIN_D_D          ,          ' ||
					'  MASUIKANRI_CANCEL_D_Y          ,          ' ||
					'  MASUIKANRI_CANCEL_D_M          ,          ' ||
					'  MASUIKANRI_CANCEL_D_D          ,          ' ||
					'  JOKUSOCARE_FLG                 ,          ' ||
					'  JOKUSOCARE_SHONIN_D_Y          ,          ' ||
					'  JOKUSOCARE_SHONIN_D_M          ,          ' ||
					'  JOKUSOCARE_SHONIN_D_D          ,          ' ||
					'  JOKUSOCARE_CANCEL_D_Y          ,          ' ||
					'  JOKUSOCARE_CANCEL_D_M          ,          ' ||
					'  JOKUSOCARE_CANCEL_D_D          ,          ' ||
					'  GIRIKGK_FLG                    ,          ' ||
					'  GIRIKGK_SHONIN_D_Y             ,          ' ||
					'  GIRIKGK_SHONIN_D_M             ,          ' ||
					'  GIRIKGK_SHONIN_D_D             ,          ' ||
					'  GIRIKGK_CANCEL_D_Y             ,          ' ||
					'  GIRIKGK_CANCEL_D_M             ,          ' ||
					'  GIRIKGK_CANCEL_D_D             ,          ' ||
					'  ZAITAKUSHIEN_FLG               ,          ' ||
					'  ZAITAKUSHIEN_SHONIN_D_Y        ,          ' ||
					'  ZAITAKUSHIEN_SHONIN_D_M        ,          ' ||
					'  ZAITAKUSHIEN_SHONIN_D_D        ,          ' ||
					'  ZAITAKUSHIEN_CANCEL_D_Y        ,          ' ||
					'  ZAITAKUSHIEN_CANCEL_D_M        ,          ' ||
					'  ZAITAKUSHIEN_CANCEL_D_D        ,          ' ||
					'  ZAIISOKAN_FLG                  ,          ' ||
					'  ZAIISOKAN_SHONIN_D_Y           ,          ' ||
					'  ZAIISOKAN_SHONIN_D_M           ,          ' ||
					'  ZAIISOKAN_SHONIN_D_D           ,          ' ||
					'  ZAIISOKAN_CANCEL_D_Y           ,          ' ||
					'  ZAIISOKAN_CANCEL_D_M           ,          ' ||
					'  ZAIISOKAN_CANCEL_D_D           ,          ' ||
					'  SHONIYAKAN_FLG                 ,          ' ||
					'  SHONIYAKAN_SHONIN_D_Y          ,          ' ||
					'  SHONIYAKAN_SHONIN_D_M          ,          ' ||
					'  SHONIYAKAN_SHONIN_D_D          ,          ' ||
					'  SHONIYAKAN_CANCEL_D_Y          ,          ' ||
					'  SHONIYAKAN_CANCEL_D_M          ,          ' ||
					'  SHONIYAKAN_CANCEL_D_D          ,          ' ||
					'  CHIKRENKEIPATH_FLG             ,          ' ||
					'  CHIKRENKEIPATH_CD_1            ,          ' ||
					'  CHIKRENKEIPATH_CD_2            ,          ' ||
					'  CHIKRENKEIPATH_CD_3            ,          ' ||
					'  CHIKRENKEIPATH_CD_4            ,          ' ||
					'  CHIKRENKEIPATH_CD_5            ,          ' ||
					'  CHIKRENKEIPATH_CD_6            ,          ' ||
					'  CHIKRENKEIPATH_CD_7            ,          ' ||
					'  CHIKRENKEIPATH_CD_8            ,          ' ||
					'  CHIKRENKEIPATH_CD_9            ,          ' ||
					'  CHIKRENKEIPATH_CD_10           ,          ' ||
					'  CHIKRENKEIPATH_CD_11           ,          ' ||
					'  CHIKRENKEIPATH_CD_12           ,          ' ||
					'  CHIKRENKEIPATH_CD_13           ,          ' ||
					'  CHIKRENKEIPATH_CD_14           ,          ' ||
					'  CHIKRENKEIPATH_CD_15           ,          ' ||
					'  CHIKRENKEIPATH_CD_16           ,          ' ||
					'  CHIKRENKEIPATH_CD_17           ,          ' ||
					'  CHIKRENKEIPATH_CD_18           ,          ' ||
					'  CHIKRENKEIPATH_CD_19           ,          ' ||
					'  CHIKRENKEIPATH_CD_20           ,          ' ||
					'  SHIKKANBETSUREHA_FLG           ,          ' ||
					'  SHIKKANBETSUREHA_CD_1          ,          ' ||
					'  SHIKKANBETSUREHA_CD_2          ,          ' ||
					'  SHIKKANBETSUREHA_CD_3          ,          ' ||
					'  SHIKKANBETSUREHA_CD_4          ,          ' ||
					'  SHIKKANBETSUREHA_CD_5          ,          ' ||
					'  SHIKKANBETSUREHA_CD_6          ,          ' ||
					'  SHIKKANBETSUREHA_CD_7          ,          ' ||
					'  SHIKKANBETSUREHA_CD_8          ,          ' ||
					'  SHIKKANBETSUREHA_CD_9          ,          ' ||
					'  SHIKKANBETSUREHA_CD_10         ,          ' ||
					'  SEISAKUIRY_FLG                 ,          ' ||
					'  SEISAKUIRY_1_CD                ,          ' ||
					'  SEISAKUIRY_1_KBN               ,          ' ||
					'  SEISAKUIRY_2_CD                ,          ' ||
					'  SEISAKUIRY_2_KBN               ,          ' ||
					'  SEISAKUIRY_3_CD                ,          ' ||
					'  SEISAKUIRY_3_KBN               ,          ' ||
					'  SEISAKUIRY_4_CD                ,          ' ||
					'  SEISAKUIRY_4_KBN               ,          ' ||
					'  SEISAKUIRY_5_CD                ,          ' ||
					'  SEISAKUIRY_5_KBN               ,          ' ||
					'  SEISAKUIRY_6_CD                ,          ' ||
					'  SEISAKUIRY_6_KBN               ,          ' ||
					'  SEISAKUIRY_7_CD                ,          ' ||
					'  SEISAKUIRY_7_KBN               ,          ' ||
					'  SEISAKUIRY_8_CD                ,          ' ||
					'  SEISAKUIRY_8_KBN               ,          ' ||
					'  SEISAKUIRY_9_CD                ,          ' ||
					'  SEISAKUIRY_9_KBN               ,          ' ||
					'  SEISAKUIRY_10_CD               ,          ' ||
					'  SEISAKUIRY_10_KBN              ,          ' ||
					'  SEISAKUIRY_11_CD               ,          ' ||
					'  SEISAKUIRY_11_KBN              ,          ' ||
					'  SEISAKUIRY_12_CD               ,          ' ||
					'  SEISAKUIRY_12_KBN              ,          ' ||
					'  SEISAKUIRY_13_CD               ,          ' ||
					'  SEISAKUIRY_13_KBN              ,          ' ||
					'  SEISAKUIRY_14_CD               ,          ' ||
					'  SEISAKUIRY_14_KBN              ,          ' ||
					'  SEISAKUIRY_15_CD               ,          ' ||
					'  SEISAKUIRY_15_KBN              ,          ' ||
					'  SEISAKUIRY_16_CD               ,          ' ||
					'  SEISAKUIRY_16_KBN              ,          ' ||
					'  SEISAKUIRY_17_CD               ,          ' ||
					'  SEISAKUIRY_17_KBN              ,          ' ||
					'  SEISAKUIRY_18_CD               ,          ' ||
					'  SEISAKUIRY_18_KBN              ,          ' ||
					'  SEISAKUIRY_19_CD               ,          ' ||
					'  SEISAKUIRY_19_KBN              ,          ' ||
					'  SEISAKUIRY_20_CD               ,          ' ||
					'  SEISAKUIRY_20_KBN              ,          ' ||
					'  TENSO_Y                        ,          ' ||
					'  TENSO_M                        ,          ' ||
					'  TENSO_D                        ,          ' ||
					'  MENTE_Y                        ,          ' ||
					'  MENTE_M                        ,          ' ||
					'  MENTE_D                        ,          ' ||
					'  MOD_KBN                        ,          ' ||
					'  TRK_OPE_CD                     ,          ' ||
					'  TRK_DATE                       ,          ' ||
					'  TRK_PGM_ID                     ,          ' ||
					'  UPD_OPE_CD                     ,          ' ||
					'  UPD_DATE                       ,          ' ||
					'  UPD_PGM_ID                                ' ||
					'  )                                         ' ||
					'  SELECT                                    ' ||
					'  TS.REC_ID,                                ' ||
					'  TS.SHI_CD,                                ' ||
					'  NULL,                                     ' ||
					'  TS.KYUKYUKOKUJI_FLG,                      ' ||
					'  TS.DPC_FLG,                               ' ||
					'  SUBSTR(TS.DPC_SHITEI_YMD,1,4),            ' ||
					'  SUBSTR(TS.DPC_SHITEI_YMD,5,2),            ' ||
					'  SUBSTR(TS.DPC_SHITEI_YMD,7,2),            ' ||
					'  SUBSTR(TS.DPC_CANCEL_YMD,1,4),            ' ||
					'  SUBSTR(TS.DPC_CANCEL_YMD,5,2),            ' ||
					'  SUBSTR(TS.DPC_CANCEL_YMD,7,2),            ' ||
					'                                            ' ||
					'  TS.GANKYOTEN_FLG,                         ' ||
					'  SUBSTR(TS.GANKYOTEN_SHITEI_YMD,1,4),      ' ||
					'  SUBSTR(TS.GANKYOTEN_SHITEI_YMD,5,2),      ' ||
					'  SUBSTR(TS.GANKYOTEN_SHITEI_YMD,7,2),      ' ||
					'  SUBSTR(TS.GANKYOTEN_CANCEL_YMD,1,4),      ' ||
					'  SUBSTR(TS.GANKYOTEN_CANCEL_YMD,5,2),      ' ||
					'  SUBSTR(TS.GANKYOTEN_CANCEL_YMD,7,2),      ' ||
					'                                            ' ||
					'  TS.IRYANZEN_FLG,                          ' ||
					'  SUBSTR(TS.IRYANZEN_SHONIN_YMD,1,4),       ' ||
					'  SUBSTR(TS.IRYANZEN_SHONIN_YMD,5,2),       ' ||
					'  SUBSTR(TS.IRYANZEN_SHONIN_YMD,7,2),       ' ||
					'  SUBSTR(TS.IRYANZEN_CANCEL_YMD,1,4),       ' ||
					'  SUBSTR(TS.IRYANZEN_CANCEL_YMD,5,2),       ' ||
					'  SUBSTR(TS.IRYANZEN_CANCEL_YMD,7,2),       ' ||
					'                                            ' ||
					'  TS.KARTE_FLG,                             ' ||
					'  SUBSTR(TS.KARTE_SHONIN_YMD,1,4),          ' ||
					'  SUBSTR(TS.KARTE_SHONIN_YMD,5,2),          ' ||
					'  SUBSTR(TS.KARTE_SHONIN_YMD,7,2),          ' ||
					'  SUBSTR(TS.KARTE_CANCEL_YMD,1,4),          ' ||
					'  SUBSTR(TS.KARTE_CANCEL_YMD,5,2),          ' ||
					'  SUBSTR(TS.KARTE_CANCEL_YMD,7,2),          ' ||
					'                                            ' ||
					'  TS.GAZOSHINDAN_FLG,                       ' ||
					'  SUBSTR(TS.GAZOSHINDAN_SHONIN_YMD,1,4),    ' ||
					'  SUBSTR(TS.GAZOSHINDAN_SHONIN_YMD,5,2),    ' ||
					'  SUBSTR(TS.GAZOSHINDAN_SHONIN_YMD,7,2),    ' ||
					'  SUBSTR(TS.GAZOSHINDAN_CANCEL_YMD,1,4),    ' ||
					'  SUBSTR(TS.GAZOSHINDAN_CANCEL_YMD,5,2),    ' ||
					'  SUBSTR(TS.GAZOSHINDAN_CANCEL_YMD,7,2),    ' ||
					'                                            ' ||
					'  TS.MASUIKANRI_FLG,                        ' ||
					'  SUBSTR(TS.MASUIKANRI_SHONIN_YMD,1,4),     ' ||
					'  SUBSTR(TS.MASUIKANRI_SHONIN_YMD,5,2),     ' ||
					'  SUBSTR(TS.MASUIKANRI_SHONIN_YMD,7,2),     ' ||
					'  SUBSTR(TS.MASUIKANRI_CANCEL_YMD,1,4),     ' ||
					'  SUBSTR(TS.MASUIKANRI_CANCEL_YMD,5,2),     ' ||
					'  SUBSTR(TS.MASUIKANRI_CANCEL_YMD,7,2),     ' ||
					'                                            ' ||
					'  TS.JOKUSOCARE_FLG,                        ' ||
					'  SUBSTR(TS.JOKUSOCARE_SHONIN_YMD,1,4),     ' ||
					'  SUBSTR(TS.JOKUSOCARE_SHONIN_YMD,5,2),     ' ||
					'  SUBSTR(TS.JOKUSOCARE_SHONIN_YMD,7,2),     ' ||
					'  SUBSTR(TS.JOKUSOCARE_CANCEL_YMD,1,4),     ' ||
					'  SUBSTR(TS.JOKUSOCARE_CANCEL_YMD,5,2),     ' ||
					'  SUBSTR(TS.JOKUSOCARE_CANCEL_YMD,7,2),     ' ||
					'                                            ' ||
					'  TS.GIRIKGK_FLG,                           ' ||
					'  SUBSTR(TS.GIRIKGK_SHONIN_YMD,1,4),        ' ||
					'  SUBSTR(TS.GIRIKGK_SHONIN_YMD,5,2),        ' ||
					'  SUBSTR(TS.GIRIKGK_SHONIN_YMD,7,2),        ' ||
					'  SUBSTR(TS.GIRIKGK_CANCEL_YMD,1,4),        ' ||
					'  SUBSTR(TS.GIRIKGK_CANCEL_YMD,5,2),        ' ||
					'  SUBSTR(TS.GIRIKGK_CANCEL_YMD,7,2),        ' ||
					'                                            ' ||
					'  TS.ZAITAKUSHIEN_FLG,                      ' ||
					'  SUBSTR(TS.ZAITAKUSHIEN_SHONIN_YMD,1,4),   ' ||
					'  SUBSTR(TS.ZAITAKUSHIEN_SHONIN_YMD,5,2),   ' ||
					'  SUBSTR(TS.ZAITAKUSHIEN_SHONIN_YMD,7,2),   ' ||
					'  SUBSTR(TS.ZAITAKUSHIEN_CANCEL_YMD,1,4),   ' ||
					'  SUBSTR(TS.ZAITAKUSHIEN_CANCEL_YMD,5,2),   ' ||
					'  SUBSTR(TS.ZAITAKUSHIEN_CANCEL_YMD,7,2),   ' ||
					'                                            ' ||
					'  TS.ZAIISOKAN_FLG,                         ' ||
					'  SUBSTR(TS.ZAIISOKAN_SHONIN_YMD,1,4),      ' ||
					'  SUBSTR(TS.ZAIISOKAN_SHONIN_YMD,5,2),      ' ||
					'  SUBSTR(TS.ZAIISOKAN_SHONIN_YMD,7,2),      ' ||
					'  SUBSTR(TS.ZAIISOKAN_CANCEL_YMD,1,4),      ' ||
					'  SUBSTR(TS.ZAIISOKAN_CANCEL_YMD,5,2),      ' ||
					'  SUBSTR(TS.ZAIISOKAN_CANCEL_YMD,7,2),      ' ||
					'                                            ' ||
					'  TS.SHONIYAKAN_FLG,                        ' ||
					'  SUBSTR(TS.SHONIYAKAN_SHONIN_YMD,1,4),     ' ||
					'  SUBSTR(TS.SHONIYAKAN_SHONIN_YMD,5,2),     ' ||
					'  SUBSTR(TS.SHONIYAKAN_SHONIN_YMD,7,2),     ' ||
					'  SUBSTR(TS.SHONIYAKAN_CANCEL_YMD,1,4),     ' ||
					'  SUBSTR(TS.SHONIYAKAN_CANCEL_YMD,5,2),     ' ||
					'  SUBSTR(TS.SHONIYAKAN_CANCEL_YMD,7,2),     ' ||
					'  TS.CHIKRENKEIPATH_FLG,                    ' ||
					'  TS.CHIKRENKEIPATH_CD_01,                  ' ||
					'  TS.CHIKRENKEIPATH_CD_02,                  ' ||
					'  TS.CHIKRENKEIPATH_CD_03,                  ' ||
					'  TS.CHIKRENKEIPATH_CD_04,                  ' ||
					'  TS.CHIKRENKEIPATH_CD_05,                  ' ||
					'  TS.CHIKRENKEIPATH_CD_06,                  ' ||
					'  TS.CHIKRENKEIPATH_CD_07,                  ' ||
					'  TS.CHIKRENKEIPATH_CD_08,                  ' ||
					'  TS.CHIKRENKEIPATH_CD_09,                  ' ||
					'  TS.CHIKRENKEIPATH_CD_10,                  ' ||
					'  TS.CHIKRENKEIPATH_CD_11,                  ' ||
					'  TS.CHIKRENKEIPATH_CD_12,                  ' ||
					'  TS.CHIKRENKEIPATH_CD_13,                  ' ||
					'  TS.CHIKRENKEIPATH_CD_14,                  ' ||
					'  TS.CHIKRENKEIPATH_CD_15,                  ' ||
					'  TS.CHIKRENKEIPATH_CD_16,                  ' ||
					'  TS.CHIKRENKEIPATH_CD_17,                  ' ||
					'  TS.CHIKRENKEIPATH_CD_18,                  ' ||
					'  TS.CHIKRENKEIPATH_CD_19,                  ' ||
					'  TS.CHIKRENKEIPATH_CD_20,                  ' ||
					'  TS.SHIKKANBETSUREHA_FLG,                  ' ||
					'  TS.SHIKKANBETSUREHA_CD_01,                ' ||
					'  TS.SHIKKANBETSUREHA_CD_02,                ' ||
					'  TS.SHIKKANBETSUREHA_CD_03,                ' ||
					'  TS.SHIKKANBETSUREHA_CD_04,                ' ||
					'  TS.SHIKKANBETSUREHA_CD_05,                ' ||
					'  TS.SHIKKANBETSUREHA_CD_06,                ' ||
					'  TS.SHIKKANBETSUREHA_CD_07,                ' ||
					'  TS.SHIKKANBETSUREHA_CD_08,                ' ||
					'  TS.SHIKKANBETSUREHA_CD_09,                ' ||
					'  TS.SHIKKANBETSUREHA_CD_10,                ' ||
					'                                            ' ||
					'  TS.SEISAKUIRY_FLG,                        ' ||
					'  TS.SEISAKUIRY_BNY_CD_01,                  ' ||
					'  TS.SEISAKUIRY_KBN_CD_01,                  ' ||
					'  TS.SEISAKUIRY_BNY_CD_02,                  ' ||
					'  TS.SEISAKUIRY_KBN_CD_02,                  ' ||
					'  TS.SEISAKUIRY_BNY_CD_03,                  ' ||
					'  TS.SEISAKUIRY_KBN_CD_03,                  ' ||
					'  TS.SEISAKUIRY_BNY_CD_04,                  ' ||
					'  TS.SEISAKUIRY_KBN_CD_04,                  ' ||
					'  TS.SEISAKUIRY_BNY_CD_05,                  ' ||
					'  TS.SEISAKUIRY_KBN_CD_05,                  ' ||
					'  TS.SEISAKUIRY_BNY_CD_06,                  ' ||
					'  TS.SEISAKUIRY_KBN_CD_06,                  ' ||
					'  TS.SEISAKUIRY_BNY_CD_07,                  ' ||
					'  TS.SEISAKUIRY_KBN_CD_07,                  ' ||
					'  TS.SEISAKUIRY_BNY_CD_08,                  ' ||
					'  TS.SEISAKUIRY_KBN_CD_08,                  ' ||
					'  TS.SEISAKUIRY_BNY_CD_09,                  ' ||
					'  TS.SEISAKUIRY_KBN_CD_09,                  ' ||
					'  TS.SEISAKUIRY_BNY_CD_10,                  ' ||
					'  TS.SEISAKUIRY_KBN_CD_10,                  ' ||
					'  TS.SEISAKUIRY_BNY_CD_11,                  ' ||
					'  TS.SEISAKUIRY_KBN_CD_11,                  ' ||
					'  TS.SEISAKUIRY_BNY_CD_12,                  ' ||
					'  TS.SEISAKUIRY_KBN_CD_12,                  ' ||
					'  TS.SEISAKUIRY_BNY_CD_13,                  ' ||
					'  TS.SEISAKUIRY_KBN_CD_13,                  ' ||
					'  TS.SEISAKUIRY_BNY_CD_14,                  ' ||
					'  TS.SEISAKUIRY_KBN_CD_14,                  ' ||
					'  TS.SEISAKUIRY_BNY_CD_15,                  ' ||
					'  TS.SEISAKUIRY_KBN_CD_15,                  ' ||
					'  TS.SEISAKUIRY_BNY_CD_16,                  ' ||
					'  TS.SEISAKUIRY_KBN_CD_16,                  ' ||
					'  TS.SEISAKUIRY_BNY_CD_17,                  ' ||
					'  TS.SEISAKUIRY_KBN_CD_17,                  ' ||
					'  TS.SEISAKUIRY_BNY_CD_18,                  ' ||
					'  TS.SEISAKUIRY_KBN_CD_18,                  ' ||
					'  TS.SEISAKUIRY_BNY_CD_19,                  ' ||
					'  TS.SEISAKUIRY_KBN_CD_19,                  ' ||
					'  TS.SEISAKUIRY_BNY_CD_20,                  ' ||
					'  TS.SEISAKUIRY_KBN_CD_20,                  ' ||
					'  SUBSTR(iTensoYMD,1,4),                    ' ||
					'  SUBSTR(iTensoYMD,5,2),                    ' ||
					'  SUBSTR(iTensoYMD,7,2),                    ' ||
					'  SUBSTR(TS.UPD_EIGY_YMD,1,4),              ' ||
					'  SUBSTR(TS.UPD_EIGY_YMD,5,2),              ' ||
					'  SUBSTR(TS.UPD_EIGY_YMD,7,2),              ' ||
					'  NULL,                                     ' ||
					iOPE_CD   || ','           ||
		            iDATE     || ','           ||
		            iPGM_ID   || ','           ||
		            iOPE_CD   || ','           ||
		            iDATE     || ','           ||
		            iPGM_ID                    ||
					'  FROM (                                    ' ||
					'  SELECT                                    ' ||
					'  TTT.REC_ID,                               ' ||
					'  TTT.SHI_CD,                               ' ||
					'  TTT.DPC_FLG,                              ' ||
					'  TTT.DPC_SHITEI_YMD,                       ' ||
					'  TTT.DPC_CANCEL_YMD,                       ' ||
					'  TTT.GANKYOTEN_FLG,                        ' ||
					'  TTT.GANKYOTEN_SHITEI_YMD,                 ' ||
					'  TTT.GANKYOTEN_CANCEL_YMD,                 ' ||
					'  TTT.KARTE_FLG,                            ' ||
					'  TTT.KARTE_SHONIN_YMD,                     ' ||
					'  TTT.KARTE_CANCEL_YMD,                     ' ||
					'  TTT.IRYANZEN_FLG,                         ' ||
					'  TTT.IRYANZEN_SHONIN_YMD,                  ' ||
					'  TTT.IRYANZEN_CANCEL_YMD,                  ' ||
					'  TTT.JOKUSOCARE_FLG,                       ' ||
					'  TTT.JOKUSOCARE_SHONIN_YMD,                ' ||
					'  TTT.JOKUSOCARE_CANCEL_YMD,                ' ||
					'  TTT.SHONIYAKAN_FLG,                       ' ||
					'  TTT.SHONIYAKAN_SHONIN_YMD,                ' ||
					'  TTT.SHONIYAKAN_CANCEL_YMD,                ' ||
					'  TTT.CHIKRENKEIPATH_FLG,                   ' ||
					'  TTT.CHIKRENKEIPATH_CD_01,                 ' ||
					'  TTT.CHIKRENKEIPATH_CD_02,                 ' ||
					'  TTT.CHIKRENKEIPATH_CD_03,                 ' ||
					'  TTT.CHIKRENKEIPATH_CD_04,                 ' ||
					'  TTT.CHIKRENKEIPATH_CD_05,                 ' ||
					'  TTT.CHIKRENKEIPATH_CD_06,                 ' ||
					'  TTT.CHIKRENKEIPATH_CD_07,                 ' ||
					'  TTT.CHIKRENKEIPATH_CD_08,                 ' ||
					'  TTT.CHIKRENKEIPATH_CD_09,                 ' ||
					'  TTT.CHIKRENKEIPATH_CD_10,                 ' ||
					'  TTT.CHIKRENKEIPATH_CD_11,                 ' ||
					'  TTT.CHIKRENKEIPATH_CD_12,                 ' ||
					'  TTT.CHIKRENKEIPATH_CD_13,                 ' ||
					'  TTT.CHIKRENKEIPATH_CD_14,                 ' ||
					'  TTT.CHIKRENKEIPATH_CD_15,                 ' ||
					'  TTT.CHIKRENKEIPATH_CD_16,                 ' ||
					'  TTT.CHIKRENKEIPATH_CD_17,                 ' ||
					'  TTT.CHIKRENKEIPATH_CD_18,                 ' ||
					'  TTT.CHIKRENKEIPATH_CD_19,                 ' ||
					'  TTT.CHIKRENKEIPATH_CD_20,                 ' ||
					'  TTT.GAZOSHINDAN_FLG,                      ' ||
					'  TTT.GAZOSHINDAN_SHONIN_YMD,               ' ||
					'  TTT.GAZOSHINDAN_CANCEL_YMD,               ' ||
					'  TTT.GIRIKGK_FLG,                          ' ||
					'  TTT.GIRIKGK_SHONIN_YMD,                   ' ||
					'  TTT.GIRIKGK_CANCEL_YMD,                   ' ||
					'  TTT.SHIKKANBETSUREHA_FLG,                 ' ||
					'  TTT.SHIKKANBETSUREHA_CD_01,               ' ||
					'  TTT.SHIKKANBETSUREHA_CD_02,               ' ||
					'  TTT.SHIKKANBETSUREHA_CD_03,               ' ||
					'  TTT.SHIKKANBETSUREHA_CD_04,               ' ||
					'  TTT.SHIKKANBETSUREHA_CD_05,               ' ||
					'  TTT.SHIKKANBETSUREHA_CD_06,               ' ||
					'  TTT.SHIKKANBETSUREHA_CD_07,               ' ||
					'  TTT.SHIKKANBETSUREHA_CD_08,               ' ||
					'  TTT.SHIKKANBETSUREHA_CD_09,               ' ||
					'  TTT.SHIKKANBETSUREHA_CD_10,               ' ||
					'  TTT.MASUIKANRI_FLG,                       ' ||
					'  TTT.MASUIKANRI_SHONIN_YMD,                ' ||
					'  TTT.MASUIKANRI_CANCEL_YMD,                ' ||
					'  TTT.ZAITAKUSHIEN_FLG,                     ' ||
					'  TTT.ZAITAKUSHIEN_SHONIN_YMD,              ' ||
					'  TTT.ZAITAKUSHIEN_CANCEL_YMD,              ' ||
					'  TTT.ZAIISOKAN_FLG,                        ' ||
					'  TTT.ZAIISOKAN_SHONIN_YMD,                 ' ||
					'  TTT.ZAIISOKAN_CANCEL_YMD,                 ' ||
					'  TTT.KYUKYUKOKUJI_FLG,                     ' ||
					'  TTT.SEISAKUIRY_FLG,                       ' ||
					'  TTT.SEISAKUIRY_BNY_CD_01,                 ' ||
					'  TTT.SEISAKUIRY_BNY_CD_02,                 ' ||
					'  TTT.SEISAKUIRY_BNY_CD_03,                 ' ||
					'  TTT.SEISAKUIRY_BNY_CD_04,                 ' ||
					'  TTT.SEISAKUIRY_BNY_CD_05,                 ' ||
					'  TTT.SEISAKUIRY_BNY_CD_06,                 ' ||
					'  TTT.SEISAKUIRY_BNY_CD_07,                 ' ||
					'  TTT.SEISAKUIRY_BNY_CD_08,                 ' ||
					'  TTT.SEISAKUIRY_BNY_CD_09,                 ' ||
					'  TTT.SEISAKUIRY_BNY_CD_10,                 ' ||
					'  TTT.SEISAKUIRY_BNY_CD_11,                 ' ||
					'  TTT.SEISAKUIRY_BNY_CD_12,                 ' ||
					'  TTT.SEISAKUIRY_BNY_CD_13,                 ' ||
					'  TTT.SEISAKUIRY_BNY_CD_14,                 ' ||
					'  TTT.SEISAKUIRY_BNY_CD_15,                 ' ||
					'  TTT.SEISAKUIRY_BNY_CD_16,                 ' ||
					'  TTT.SEISAKUIRY_BNY_CD_17,                 ' ||
					'  TTT.SEISAKUIRY_BNY_CD_18,                 ' ||
					'  TTT.SEISAKUIRY_BNY_CD_19,                 ' ||
					'  TTT.SEISAKUIRY_BNY_CD_20,                 ' ||
					'  TTT.SEISAKUIRY_KBN_CD_01,                 ' ||
					'  TTT.SEISAKUIRY_KBN_CD_02,                 ' ||
					'  TTT.SEISAKUIRY_KBN_CD_03,                 ' ||
					'  TTT.SEISAKUIRY_KBN_CD_04,                 ' ||
					'  TTT.SEISAKUIRY_KBN_CD_05,                 ' ||
					'  TTT.SEISAKUIRY_KBN_CD_06,                 ' ||
					'  TTT.SEISAKUIRY_KBN_CD_07,                 ' ||
					'  TTT.SEISAKUIRY_KBN_CD_08,                 ' ||
					'  TTT.SEISAKUIRY_KBN_CD_09,                 ' ||
					'  TTT.SEISAKUIRY_KBN_CD_10,                 ' ||
					'  TTT.SEISAKUIRY_KBN_CD_11,                 ' ||
					'  TTT.SEISAKUIRY_KBN_CD_12,                 ' ||
					'  TTT.SEISAKUIRY_KBN_CD_13,                 ' ||
					'  TTT.SEISAKUIRY_KBN_CD_14,                 ' ||
					'  TTT.SEISAKUIRY_KBN_CD_15,                 ' ||
					'  TTT.SEISAKUIRY_KBN_CD_16,                 ' ||
					'  TTT.SEISAKUIRY_KBN_CD_17,                 ' ||
					'  TTT.SEISAKUIRY_KBN_CD_18,                 ' ||
					'  TTT.SEISAKUIRY_KBN_CD_19,                 ' ||
					'  TTT.SEISAKUIRY_KBN_CD_20,                 ' ||
					'  TTT.UPD_EIGY_YMD                          ' ||
					'  FROM  TT_TIKY_SHI�@TTS                    ' ||
					'  INNER JOIN TT_TIKY_TSUIKAITEM�@TTT        ' ||
					'ON TTS�DREC_ID = TTT�DREC_ID                ' ||
					'AND  TTS�DSHI_CD = TTT�DSHI_CD              ' ||
					'  WHERE�@TTS.REC_ID�@= ''00''                 ' ||
					'  AND�@TTS.DEL_FLG IS NULL                  ' ||
					'  AND�@TTT�DITEM_2_MOD_EIGY_YMD IS NOT NULL ' ||
					'  AND�@TTT.DEL_FLG IS NULL                  ' ||
					'  UNION                                     ' ||
					'  SELECT                                    ' ||
					'  TTT.REC_ID,                               ' ||
					'  TTT.SHI_CD,                               ' ||
					'  NULL AS DPC_FLG,                          ' ||
					'  NULL AS DPC_SHITEI_YMD,                   ' ||
					'  NULL AS DPC_CANCEL_YMD,                   ' ||
					'  NULL AS GANKYOTEN_FLG,                    ' ||
					'  NULL AS GANKYOTEN_SHITEI_YMD,             ' ||
					'  NULL AS GANKYOTEN_CANCEL_YMD,             ' ||
					'  NULL AS KARTE_FLG,                        ' ||
					'  NULL AS KARTE_SHONIN_YMD,                 ' ||
					'  NULL AS KARTE_CANCEL_YMD,                 ' ||
					'  NULL AS IRYANZEN_FLG,                     ' ||
					'  NULL AS IRYANZEN_SHONIN_YMD,              ' ||
					'  NULL AS IRYANZEN_CANCEL_YMD,              ' ||
					'  NULL AS JOKUSOCARE_FLG,                   ' ||
					'  NULL AS JOKUSOCARE_SHONIN_YMD,            ' ||
					'  NULL AS JOKUSOCARE_CANCEL_YMD,            ' ||
					'  NULL AS SHONIYAKAN_FLG,                   ' ||
					'  NULL AS SHONIYAKAN_SHONIN_YMD,            ' ||
					'  NULL AS SHONIYAKAN_CANCEL_YMD,            ' ||
					'  NULL AS CHIKRENKEIPATH_FLG,               ' ||
					'  NULL AS CHIKRENKEIPATH_CD_01,             ' ||
					'  NULL AS CHIKRENKEIPATH_CD_02,             ' ||
					'  NULL AS CHIKRENKEIPATH_CD_03,             ' ||
					'  NULL AS CHIKRENKEIPATH_CD_04,             ' ||
					'  NULL AS CHIKRENKEIPATH_CD_05,             ' ||
					'  NULL AS CHIKRENKEIPATH_CD_06,             ' ||
					'  NULL AS CHIKRENKEIPATH_CD_07,             ' ||
					'  NULL AS CHIKRENKEIPATH_CD_08,             ' ||
					'  NULL AS CHIKRENKEIPATH_CD_09,             ' ||
					'  NULL AS CHIKRENKEIPATH_CD_10,             ' ||
					'  NULL AS CHIKRENKEIPATH_CD_11,             ' ||
					'  NULL AS CHIKRENKEIPATH_CD_12,             ' ||
					'  NULL AS CHIKRENKEIPATH_CD_13,             ' ||
					'  NULL AS CHIKRENKEIPATH_CD_14,             ' ||
					'  NULL AS CHIKRENKEIPATH_CD_15,             ' ||
					'  NULL AS CHIKRENKEIPATH_CD_16,             ' ||
					'  NULL AS CHIKRENKEIPATH_CD_17,             ' ||
					'  NULL AS CHIKRENKEIPATH_CD_18,             ' ||
					'  NULL AS CHIKRENKEIPATH_CD_19,             ' ||
					'  NULL AS CHIKRENKEIPATH_CD_20,             ' ||
					'  NULL AS GAZOSHINDAN_FLG,                  ' ||
					'  NULL AS GAZOSHINDAN_SHONIN_YMD,           ' ||
					'  NULL AS GAZOSHINDAN_CANCEL_YMD,           ' ||
					'  NULL AS GIRIKGK_FLG,                      ' ||
					'  NULL AS GIRIKGK_SHONIN_YMD,               ' ||
					'  NULL AS GIRIKGK_CANCEL_YMD,               ' ||
					'  NULL AS SHIKKANBETSUREHA_FLG,             ' ||
					'  NULL AS SHIKKANBETSUREHA_CD_01,           ' ||
					'  NULL AS SHIKKANBETSUREHA_CD_02,           ' ||
					'  NULL AS SHIKKANBETSUREHA_CD_03,           ' ||
					'  NULL AS SHIKKANBETSUREHA_CD_04,           ' ||
					'  NULL AS SHIKKANBETSUREHA_CD_05,           ' ||
					'  NULL AS SHIKKANBETSUREHA_CD_06,           ' ||
					'  NULL AS SHIKKANBETSUREHA_CD_07,           ' ||
					'  NULL AS SHIKKANBETSUREHA_CD_08,           ' ||
					'  NULL AS SHIKKANBETSUREHA_CD_09,           ' ||
					'  NULL AS SHIKKANBETSUREHA_CD_10,           ' ||
					'  NULL AS MASUIKANRI_FLG,                   ' ||
					'  NULL AS MASUIKANRI_SHONIN_YMD,            ' ||
					'  NULL AS MASUIKANRI_CANCEL_YMD,            ' ||
					'  NULL AS ZAITAKUSHIEN_FLG,                 ' ||
					'  NULL AS ZAITAKUSHIEN_SHONIN_YMD,          ' ||
					'  NULL AS ZAITAKUSHIEN_CANCEL_YMD,          ' ||
					'  NULL AS ZAIISOKAN_FLG,                    ' ||
					'  NULL AS ZAIISOKAN_SHONIN_YMD,             ' ||
					'  NULL AS ZAIISOKAN_CANCEL_YMD,             ' ||
					'  NULL AS KYUKYUKOKUJI_FLG,                 ' ||
					'  NULL AS SEISAKUIRY_FLG,                   ' ||
					'  NULL AS SEISAKUIRY_BNY_CD_01,             ' ||
					'  NULL AS SEISAKUIRY_BNY_CD_02,             ' ||
					'  NULL AS SEISAKUIRY_BNY_CD_03,             ' ||
					'  NULL AS SEISAKUIRY_BNY_CD_04,             ' ||
					'  NULL AS SEISAKUIRY_BNY_CD_05,             ' ||
					'  NULL AS SEISAKUIRY_BNY_CD_06,             ' ||
					'  NULL AS SEISAKUIRY_BNY_CD_07,             ' ||
					'  NULL AS SEISAKUIRY_BNY_CD_08,             ' ||
					'  NULL AS SEISAKUIRY_BNY_CD_09,             ' ||
					'  NULL AS SEISAKUIRY_BNY_CD_10,             ' ||
					'  NULL AS SEISAKUIRY_BNY_CD_11,             ' ||
					'  NULL AS SEISAKUIRY_BNY_CD_12,             ' ||
					'  NULL AS SEISAKUIRY_BNY_CD_13,             ' ||
					'  NULL AS SEISAKUIRY_BNY_CD_14,             ' ||
					'  NULL AS SEISAKUIRY_BNY_CD_15,             ' ||
					'  NULL AS SEISAKUIRY_BNY_CD_16,             ' ||
					'  NULL AS SEISAKUIRY_BNY_CD_17,             ' ||
					'  NULL AS SEISAKUIRY_BNY_CD_18,             ' ||
					'  NULL AS SEISAKUIRY_BNY_CD_19,             ' ||
					'  NULL AS SEISAKUIRY_BNY_CD_20,             ' ||
					'  NULL AS SEISAKUIRY_KBN_CD_01,             ' ||
					'  NULL AS SEISAKUIRY_KBN_CD_02,             ' ||
					'  NULL AS SEISAKUIRY_KBN_CD_03,             ' ||
					'  NULL AS SEISAKUIRY_KBN_CD_04,             ' ||
					'  NULL AS SEISAKUIRY_KBN_CD_05,             ' ||
					'  NULL AS SEISAKUIRY_KBN_CD_06,             ' ||
					'  NULL AS SEISAKUIRY_KBN_CD_07,             ' ||
					'  NULL AS SEISAKUIRY_KBN_CD_08,             ' ||
					'  NULL AS SEISAKUIRY_KBN_CD_09,             ' ||
					'  NULL AS SEISAKUIRY_KBN_CD_10,             ' ||
					'  NULL AS SEISAKUIRY_KBN_CD_11,             ' ||
					'  NULL AS SEISAKUIRY_KBN_CD_12,             ' ||
					'  NULL AS SEISAKUIRY_KBN_CD_13,             ' ||
					'  NULL AS SEISAKUIRY_KBN_CD_14,             ' ||
					'  NULL AS SEISAKUIRY_KBN_CD_15,             ' ||
					'  NULL AS SEISAKUIRY_KBN_CD_16,             ' ||
					'  NULL AS SEISAKUIRY_KBN_CD_17,             ' ||
					'  NULL AS SEISAKUIRY_KBN_CD_18,             ' ||
					'  NULL AS SEISAKUIRY_KBN_CD_19,             ' ||
					'  NULL AS SEISAKUIRY_KBN_CD_20,             ' ||
					'  TTT.UPD_EIGY_YMD                          ' ||
					'  FROM TT_TIKY_SHI�@TTS                     ' ||
					'  INNER JOIN TT_TIKY_TSUIKAITEM�@TTT        ' ||
					'ON TTS�DREC_ID = TTT�DREC_ID	             ' ||
					'AND TTS�DSHI_CD = TTT�DSHI_CD               ' ||
					'  WHERE�@TTS.REC_ID�@= ''00''                 ' ||
					'  AND�@TTS.DEL_FLG IS NULL                  ' ||
					'  AND�@TTT�DITEM_2_MOD_EIGY_YMD IS NOT NULL ' ||
					'  AND�@TTT.DEL_FLG = ''1''                    ' ||
					'  ) TS                                      ' ;
	 ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);
	 
    END IF;
    COMMIT;
	
	-- �I�����O�o��
   ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'PL/SQL End',PGM_ID || '�̏������I�����܂����B',iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);
   
  oROW_COUNT := -1;
  return 0;
  -- ��O����
  EXCEPTION
    -- ���̑��G���[
    WHEN OTHERS THEN
      W_ERR_INF_RCD.ERR_CD     := TO_CHAR(SQLCODE);
      W_ERR_INF_RCD.ERR_MSG     := SUBSTR(SQLERRM, 0, 500);
      W_ERR_INF_RCD.ERR_KEY_INF   := SUBSTR('iShimeKind:' || iShimeKind , 0,500);
      W_INDEX_N           := W_ERR_INF_TBL.COUNT + 1;
      W_ERR_INF_TBL.EXTEND;
      W_ERR_INF_TBL(W_INDEX_N)   := W_ERR_INF_RCD;

      OPEN oOUT_ERR_INF_CSR FOR
        SELECT * FROM TABLE(W_ERR_INF_TBL);

        ROLLBACK;
        
      --�G���[���O�̓o�^
      ULT_INSERT_LOG_TABLE('ERROR',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'ERROR_INFO',W_ERR_INF_RCD.ERR_MSG,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

  return 1;
END;

END;
/
