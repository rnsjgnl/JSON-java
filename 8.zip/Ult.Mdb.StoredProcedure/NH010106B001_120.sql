CREATE OR REPLACE PACKAGE NH010106B001_120
/* **********************************************************
 *  Copyright(c) 2011 beyond, INTEC Inc. All rights reserved.
 * **********************************************************/
AUTHID CURRENT_USER
IS
	/*** �J�[�\���^ ***************************************************************/
	-- �G���[���i�[�p�J�[�\���^
	TYPE ERR_INF_CSR		IS REF CURSOR;

  /*
  ************************************************************************
  *  �b��_�S��_��Ì��^�C�v1�e�[�u���̍쐬
  *  CREATE_TD_PA_IRK
  ************************************************************************
  */
  FUNCTION CREATE_TD_PA_IRK(
  iLayoutKbn  IN  INTEGER,                    -- ���C�A�E�g�敪
  iShimeKind  IN  INTEGER,                    -- ���ߓ��敪
  iTensoYMD	IN	VARCHAR2,                     -- �]���N����
  iOPE_CD IN Varchar2,                      -- �I�y���[�^�R�[�h
  iPGM_ID IN Varchar2,                      -- �v���O����ID
  iDATE DATE,                               -- �V�X�e������
  iIP_ADDR  IN TL_STORED_SHORI.IP%TYPE,              -- ���s�[��IP�A�h���X (FW�Őݒ�)
  iWINDOWS_LOGIN_USER  IN TL_STORED_SHORI.WINDOWS_LOGIN_USER%TYPE, -- ���s�[��OS���[�U�[ (FW�Őݒ�)
  oROW_COUNT  OUT NUMBER,         -- �o�^����
  oOUT_ERR_INF_CSR   OUT ERR_INF_CSR    -- �G���[���J�[�\��
  ) RETURN NUMBER;

END;
/

CREATE OR REPLACE PACKAGE BODY NH010106B001_120
/* **********************************************************
 *  Copyright(c) 2011 beyond, INTEC Inc. All rights reserved.
 * **********************************************************/
IS
  /*
   ************************************************************************
   * Function ID  : CREATE_TD_PA_IRK
   * Program Name : �b��_�S��_��Ì��^�C�v1�e�[�u���̍쐬
   * Parameter    :  <I> iLayoutKbn    �F���C�A�E�g�敪
   *                 <I> iShimeKind    �F���ߓ��敪
   *                 <I> iTensoYMD    �F�]���N����
   *                 <I> iOPE_CD    �F�I�y���[�^�R�[�h
   *                 <I> iPGM_ID    �F�v���O����ID
   *                 <I> iDATE    �F�V�X�e������ 
   *                 <I> iIP_ADDR    �F���s�[��IP�A�h���X
   *                 <I> iWINDOWS_LOGIN_USER  �F���s�[��IP�A�h���X
   *                <O> oROW_COUNT        �F�X�V����
   *                <O> oOUT_ERR_INF_CSR  �F�G���[���J�[�\��
   * Return       �F�������ʁi0:����I���A1:�ُ�I���j
   ************************************************************************
   */
  FUNCTION CREATE_TD_PA_IRK(
  iLayoutKbn  IN  INTEGER,                    -- ���C�A�E�g�敪
  iShimeKind  IN  INTEGER,                    -- ���ߓ��敪
  iTensoYMD	IN	VARCHAR2,                     -- �]���N����
  iOPE_CD IN Varchar2,                      -- �I�y���[�^�R�[�h
  iPGM_ID IN Varchar2,                      -- �v���O����ID
  iDATE DATE,                               -- �V�X�e������  
  iIP_ADDR  IN TL_STORED_SHORI.IP%TYPE,              -- ���s�[��IP�A�h���X (FW�Őݒ�)
  iWINDOWS_LOGIN_USER  IN TL_STORED_SHORI.WINDOWS_LOGIN_USER%TYPE, -- ���s�[��OS���[�U�[ (FW�Őݒ�)
  oROW_COUNT  OUT NUMBER,         -- �o�^����
  oOUT_ERR_INF_CSR   OUT ERR_INF_CSR    -- �G���[���J�[�\��
  )RETURN NUMBER IS
PRAGMA AUTONOMOUS_TRANSACTION;

  /************************************************************************/
  /*                              �G���[����                              */
  /************************************************************************/
  W_INDEX_N           NUMBER(10) := 0;
  W_ERR_INF_TBL         TYPE_ERR_INFO_TBL := TYPE_ERR_INFO_TBL();
  W_ERR_INF_RCD         TYPE_ERR_INFO_RCD := TYPE_ERR_INFO_RCD(NULL,NULL,NULL,NULL);
  vSQL VARCHAR2(4000);
  oldKenCd VARCHAR2(10);
  vSchemaNm           TM_JOSU.HANYO_KOMOKU%TYPE := NULL; -- �X�L�[�}����
  PGM_ID        VARCHAR2(50) := 'NH010106B001_120.CREATE_TD_PA_IRK';
  EXECUTE_SQL   VARCHAR2(32767) := NULL;

  -- �b��_�S��_��Ì��^�C�v1_�敪1�̑f�ނc�a���쐬����
  CURSOR johoForIrk1CSR IS
    SELECT                                                       
        TI3JK.KEN_CD,															
        '00' AS IRK_CD,															
        TI3JK.IRK_3JI_CD,															
        TI3JK.IRK_3JI_NM,															
        TI3JK.UPD_EIGY_YMD AS UPD_EIGY_YMD,															
        TI3JK.UPD_EIGY_YMD AS JI2_UPD_EIGY_YMD,															
        TIK.MOD_YMD															
	    FROM TT_TIKY_IRK_3JI_KANRI TI3JK												
	    INNER JOIN TT_TIKY_IRK_KANRI TIK ON (TIK.KEN_CD = TI3JK.KEN_CD)												
	    --INNER JOIN TT_TIKY_IRK_3JI_KANRI TI3JK ON (TI3JK.KEN_CD = TI2JK.KEN_CD AND TI3JK.IRK_3JI_CD = TI2JK.IRK_3JI_CD)												
    UNION	
    SELECT													
        SUBSTR(TI2JK.IRK_2JI_CD, 1, 2) AS KEN_CD,												
        SUBSTR(TI2JK.IRK_2JI_CD, 3, 2) AS IRK_CD,												
        TI2JK.IRK_3JI_CD,												
        TI2JK.IRK_2JI_NM,												
        TI2JK.UPD_EIGY_YMD AS UPD_EIGY_YMD,												
        TI2JK.UPD_EIGY_YMD AS JI2_UPD_EIGY_YMD,												
        TIK.MOD_YMD												
    FROM TT_TIKY_IRK_2JI_KANRI TI2JK														
	  INNER JOIN TT_TIKY_IRK_KANRI TIK ON (TIK.KEN_CD = TI2JK.KEN_CD)														
	  --INNER JOIN TT_TIKY_IRK_3JI_KANRI TI3JK ON (TI3JK.KEN_CD = TI2JK.KEN_CD AND TI3JK.IRK_3JI_CD = TI2JK.IRK_3JI_CD)														
    ORDER BY KEN_CD ASC,IRK_CD ASC, IRK_3JI_CD ASC;					                                
 
  johoForIrk1Row johoForIrk1CSR%ROWTYPE;   
 
  -- �b��_�S��_��Ì��^�C�v1_�敪2�̑f�ނc�a���쐬����
  CURSOR johoForIrk2CSR IS
    SELECT           													
        TI2JK.IRK_2JI_CD,													
        TIK.KEN_CD,													
        TI2JK.IRK_3JI_CD,													
        TI2JK.IPPAN_KIJUN_BED_SU,													
        TIK.SEISHIN_KIJUN_BED_SU_GOKEI,													
        TIK.KEKKAKU_KIJUN_BED_SU_GOKEI,													
        TIK.KANSEN_KIJUN_BED_SU_GOKEI,													
        TI2JK.IPPAN_KIZON_BED_SU,													
        TIK.SEISHIN_KIZON_BED_SU_GOKEI,													
        TIK.KEKKAKU_KIZON_BED_SU_GOKEI,													
        TIK.KANSEN_KIZON_BED_SU_GOKEI,													
        TIK.IPPAN_KIZON_YMD,													
        TIK.SEISHIN_KIZON_YMD,													
        TIK.KEKKAKU_KIZON_YMD,													
        TIK.KANSEN_KIZON_YMD,													
        TI2JK.IPPAN_KAFUSOKU_BED_SU,													
        TIK.SEISHIN_KAFUSOKU_BED_SU_GOKEI,													
        TIK.KEKKAKU_KAFUSOKU_BED_SU_GOKEI,													
        TIK.KANSEN_KAFUSOKU_BED_SU_GOKEI,													
        TIK.KOJI_YMD,													
        TIK.MOD_YMD,													
        TI2JK.UPD_EIGY_YMD AS JI2_UPD_EIGY_YMD,													
        TIK.UPD_EIGY_YMD													
    FROM TT_TIKY_IRK_KANRI TIK														
	  INNER JOIN TT_TIKY_IRK_2JI_KANRI TI2JK ON (TIK.KEN_CD = TI2JK.KEN_CD)														
	  ORDER BY TI2JK.IRK_2JI_CD ASC,TIK.KEN_CD ASC,TI2JK.IRK_3JI_CD ASC;								
													
  johoForIrk2Row johoForIrk2CSR%ROWTYPE;   
  
  -- �b��_�S��_��Ì��^�C�v1_�敪3�̑f�ނc�a���쐬����
  CURSOR johoForIrk3CSR IS
    SELECT									
      TIKK.IRK_2JI_CD,								
      TI2JK.IRK_3JI_CD,								
      TIKK.KEN_CD,								
      TIKK.SHIKU_CD,								
      TIKR.MOD_YMD,								
      TIKK.UPD_EIGY_YMD								
    FROM TT_TIKY_IRK_KANRI TIKR														
	  INNER JOIN TT_TIKY_IRK_2JI_KANRI TI2JK ON (TI2JK.KEN_CD = TIKR.KEN_CD)														
	  INNER JOIN TT_TIKY_IRK_KANKATSU TIKK ON (TIKK.KEN_CD = TI2JK.KEN_CD	AND TIKK.IRK_2JI_CD = TI2JK.IRK_2JI_CD)														
	  ORDER BY TIKK.IRK_2JI_CD  ASC,TI2JK.IRK_3JI_CD  ASC,TIKK.KEN_CD  ASC,TIKK.SHIKU_CD ASC;						
		
  johoForIrk3Row johoForIrk3CSR%ROWTYPE;													

  BEGIN
     -- �J�n���O�o��
     ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'PL/SQL Start',PGM_ID || '�̏������J�n���܂��B',iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

     -- �[�i�p�X�L�[�}�̎擾���s���B
      vSchemaNm := ULT_COMMON.GET_SCHEMA_NAME(ULT_COMMON.SYS_ENV_JOSU_DAI_CD, ULT_COMMON.NOHIN_SHEMA_JOSU_SHO_CD);

      --�b�背�C�A�E
      IF iLayoutKbn = ULT_COMMON.LAYOUT_SBT_CD_ZANTEI THEN

      
         EXECUTE_SQL := 'SELECT 
							TI3JK.KEN_CD,
							''00'' AS IRK_CD,
							TI3JK.IRK_3JI_CD,
							TI3JK.IRK_3JI_NM,
							TI3JK.UPD_EIGY_YMD AS UPD_EIGY_YMD,
							TI3JK.UPD_EIGY_YMD AS JI2_UPD_EIGY_YMD,
							TIK.MOD_YMD 
						FROM TT_TIKY_IRK_3JI_KANRI TI3JK 
							INNER JOIN TT_TIKY_IRK_KANRI TIK ON (TIK.KEN_CD = TI3JK.KEN_CD) 
						UNION 
						SELECT 
							SUBSTR(TI2JK.IRK_2JI_CD, 1, 2) AS KEN_CD, 
							SUBSTR(TI2JK.IRK_2JI_CD, 3, 2) AS IRK_CD, 
							TI2JK.IRK_3JI_CD, 
							TI2JK.IRK_2JI_NM, 
							TI2JK.UPD_EIGY_YMD AS UPD_EIGY_YMD, 
							TI2JK.UPD_EIGY_YMD AS JI2_UPD_EIGY_YMD, 
							TIK.MOD_YMD 
						FROM TT_TIKY_IRK_2JI_KANRI TI2JK 
							INNER JOIN TT_TIKY_IRK_KANRI TIK ON (TIK.KEN_CD = TI2JK.KEN_CD) 
						ORDER BY KEN_CD ASC,IRK_CD ASC, IRK_3JI_CD ASC';

         ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);
      
         --�b��_�S��_��Ì��^�C�v1_�敪1�̃f�[�^���N���A����
         EXECUTE_SQL := 'TRUNCATE TABLE ' || vSchemaNm || '.' || 'TD_PA_IRK_KBN1';
         EXECUTE IMMEDIATE EXECUTE_SQL;
         ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

         -- �擾�����f��DB�f�[�^���������J��Ԃ�
         OPEN johoForIrk1CSR ;
         LOOP
            FETCH johoForIrk1CSR INTO johoForIrk1Row;
            EXIT WHEN johoForIrk1CSR%NOTFOUND; 
            oROW_COUNT:=oROW_COUNT+1;
            
            INSERT INTO TD_PA_IRK_KBN1(
                FILE_KBN                       ,
                REC_ID                         ,
                IRK_CD_2JI_KEN_CD              ,
                IRK_CD_2JI_IRK_CD              ,
                CD_3JI                         ,
                IRK_MEISYO_2JI_IRK_MEISYO_3JI  ,
                FILLER                         ,
                MOD_YMD_SY                     ,
                MOD_YMD_M                      ,
                MOD_YMD_D                      ,
                TENSO_Y                        ,
                TENSO_M                        ,
                TENSO_D                        ,
                MENTE_Y                        ,
                MENTE_M                        ,
                MENTE_D                        ,
                MOD_KBN                        ,
                TRK_OPE_CD                     ,
                TRK_DATE                       ,
                TRK_PGM_ID                     ,
                UPD_OPE_CD                     ,
                UPD_DATE                       ,    
                UPD_PGM_ID)  
            VALUES(
                '1',
                DECODE(iShimeKind,'1','11',NULL),
                johoForIrk1Row.KEN_CD,
                johoForIrk1Row.IRK_CD,
                DECODE(johoForIrk1Row.IRK_3JI_CD,NULL,' ',johoForIrk1Row.IRK_3JI_CD),
                johoForIrk1Row.IRK_3JI_NM,
                NULL,
                NVL2(johoForIrk1Row.MOD_YMD,SUBSTR(johoForIrk1Row.MOD_YMD,1,4),NULL),
                NVL2(johoForIrk1Row.MOD_YMD,SUBSTR(johoForIrk1Row.MOD_YMD,5,2),NULL),
                NVL2(johoForIrk1Row.MOD_YMD,SUBSTR(johoForIrk1Row.MOD_YMD,7,2),NULL), 
                DECODE(iShimeKind,'1',SUBSTR(iTensoYMD,1,4),NULL),
                DECODE(iShimeKind,'1',SUBSTR(iTensoYMD,5,2),NULL),
                DECODE(iShimeKind,'1',SUBSTR(iTensoYMD,7,2),NULL),
                DECODE(iShimeKind,'1',SUBSTR(johoForIrk1Row.JI2_UPD_EIGY_YMD,1,4),NULL),
                DECODE(iShimeKind,'1',SUBSTR(johoForIrk1Row.JI2_UPD_EIGY_YMD,5,2),NULL),
                DECODE(iShimeKind,'1',SUBSTR(johoForIrk1Row.JI2_UPD_EIGY_YMD,7,2),NULL),                
                NULL,                                         
                iOPE_CD,
                iDATE,
                iPGM_ID,
                iOPE_CD,
                iDATE,
                iPGM_ID
            );
            
            
            
            
            
            
            EXECUTE_SQL := 'INSERT INTO TD_PA_IRK_KBN1(
                FILE_KBN                       ,
                REC_ID                         ,
                IRK_CD_2JI_KEN_CD              ,
                IRK_CD_2JI_IRK_CD              ,
                CD_3JI                         ,
                IRK_MEISYO_2JI_IRK_MEISYO_3JI  ,
                FILLER                         ,
                MOD_YMD_SY                     ,
                MOD_YMD_M                      ,
                MOD_YMD_D                      ,
                TENSO_Y                        ,
                TENSO_M                        ,
                TENSO_D                        ,
                MENTE_Y                        ,
                MENTE_M                        ,
                MENTE_D                        ,
                MOD_KBN                        ,
                TRK_OPE_CD                     ,
                TRK_DATE                       ,
                TRK_PGM_ID                     ,
                UPD_OPE_CD                     ,
                UPD_DATE                       ,    
                UPD_PGM_ID)  
            VALUES(
                ''1'',
                DECODE( '|| iShimeKind ||' ,''1'',''11'',NULL), '||
                johoForIrk1Row.KEN_CD ||' , '||
                johoForIrk1Row.IRK_CD ||' , 
                DECODE( '|| johoForIrk1Row.IRK_3JI_CD ||' ,NULL,'' '', '|| johoForIrk1Row.IRK_3JI_CD ||' ), '||
                johoForIrk1Row.IRK_3JI_NM ||' ,
                NULL,
                NVL2( '|| johoForIrk1Row.MOD_YMD ||' ,SUBSTR( '|| johoForIrk1Row.MOD_YMD ||' ,1,4),NULL),
                NVL2( '|| johoForIrk1Row.MOD_YMD ||' ,SUBSTR( '|| johoForIrk1Row.MOD_YMD ||' ,5,2),NULL),
                NVL2( '|| johoForIrk1Row.MOD_YMD ||' ,SUBSTR( '|| johoForIrk1Row.MOD_YMD ||' ,7,2),NULL), 
                DECODE( '|| iShimeKind ||' ,''1'',SUBSTR( '|| iTensoYMD ||' ,1,4),NULL),
                DECODE( '|| iShimeKind ||' ,''1'',SUBSTR( '|| iTensoYMD ||' ,5,2),NULL),
                DECODE( '|| iShimeKind ||' ,''1'',SUBSTR( '|| iTensoYMD ||' ,7,2),NULL),
                DECODE( '|| iShimeKind ||' ,''1'',SUBSTR( '|| johoForIrk1Row.JI2_UPD_EIGY_YMD ||' ,1,4),NULL),
                DECODE( '|| iShimeKind ||' ,''1'',SUBSTR( '|| johoForIrk1Row.JI2_UPD_EIGY_YMD ||' ,5,2),NULL),
                DECODE( '|| iShimeKind ||' ,''1'',SUBSTR( '|| johoForIrk1Row.JI2_UPD_EIGY_YMD ||' ,7,2),NULL),                
                NULL,  '||                                        
                iOPE_CD ||' , '||
                iDATE ||' , '||
                iPGM_ID ||' , '||
                iOPE_CD ||' , '||
                iDATE ||' , '||
                iPGM_ID ||' ) ';
         ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

            
            
            
         END LOOP;
         CLOSE johoForIrk1CSR;
         
         --�b��_�S��_��Ì��^�C�v1_�敪2�̃f�[�^���N���A����
         EXECUTE_SQL := 'TRUNCATE TABLE ' || vSchemaNm || '.' || 'TD_PA_IRK_KBN2';
         EXECUTE IMMEDIATE EXECUTE_SQL;
         ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

	 oldKenCd := '999';
	 
         oROW_COUNT:=0;
         
         
         
         
         
         
            EXECUTE_SQL := 'SELECT 
								TI2JK.IRK_2JI_CD,
								TIK.KEN_CD,
								TI2JK.IRK_3JI_CD,
								TI2JK.IPPAN_KIJUN_BED_SU,
								TIK.SEISHIN_KIJUN_BED_SU_GOKEI,
								TIK.KEKKAKU_KIJUN_BED_SU_GOKEI,
								TIK.KANSEN_KIJUN_BED_SU_GOKEI,
								TI2JK.IPPAN_KIZON_BED_SU,
								TIK.SEISHIN_KIZON_BED_SU_GOKEI,
								TIK.KEKKAKU_KIZON_BED_SU_GOKEI,
								TIK.KANSEN_KIZON_BED_SU_GOKEI,
								TIK.IPPAN_KIZON_YMD,
								TIK.SEISHIN_KIZON_YMD,
								TIK.KEKKAKU_KIZON_YMD,
								TIK.KANSEN_KIZON_YMD,
								TI2JK.IPPAN_KAFUSOKU_BED_SU,
								TIK.SEISHIN_KAFUSOKU_BED_SU_GOKEI,
								TIK.KEKKAKU_KAFUSOKU_BED_SU_GOKEI,
								TIK.KANSEN_KAFUSOKU_BED_SU_GOKEI,
								TIK.KOJI_YMD,
								TIK.MOD_YMD,
								TI2JK.UPD_EIGY_YMD AS JI2_UPD_EIGY_YMD,
								TIK.UPD_EIGY_YMD 
							FROM TT_TIKY_IRK_KANRI TIK 
							INNER JOIN TT_TIKY_IRK_2JI_KANRI TI2JK ON (TIK.KEN_CD = TI2JK.KEN_CD) 
							ORDER BY TI2JK.IRK_2JI_CD ASC,TIK.KEN_CD ASC,TI2JK.IRK_3JI_CD ASC';
         ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);
         
         
         
         
         
         
         
         -- �擾�����f��DB�f�[�^���������J��Ԃ�
         OPEN johoForIrk2CSR ;
         LOOP
            FETCH johoForIrk2CSR INTO johoForIrk2Row;
            EXIT WHEN johoForIrk2CSR%NOTFOUND;
            oROW_COUNT:=oROW_COUNT+1;
            
            -- �a���敪��1�̏ꍇ
            INSERT INTO TD_PA_IRK_KBN2(         
                FILE_KBN                       ,
                REC_ID                         ,
                IRK_CD_2JI_KEN_CD              ,
                IRK_CD_2JI_IRK_CD              ,
                CD_3JI                         ,
                BED_KBN                        ,
                KIJUN_SU_OR_SEIBI_SU           ,
                KIZON_BED_SU_BED_SU            ,
                KIZON_BED_SU_YMD_SY            ,
                KIZON_BED_SU_YMD_M             ,
                KIZON_BED_SU_YMD_D             ,
                KAFUSOKU_BED_SU_SSHK           ,
                KAFUSOKU_BED_SU_SSHK_MINUS     ,
                KOJI_YMD_SY                    ,
                KOJI_YMD_M                     ,
                KOJI_YMD_D                     ,
                FILLER                         ,
                MOD_YMD_SY                     ,
                MOD_YMD_M                      ,
                MOD_YMD_D                      ,
                TENSO_Y                        ,
                TENSO_M                        ,
                TENSO_D                        ,
                MENTE_Y                        ,
                MENTE_M                        ,
                MENTE_D                        ,
                MOD_KBN                        ,
                SORT                           ,
                TRK_OPE_CD                     ,
                TRK_DATE                       ,
                TRK_PGM_ID                     ,
                UPD_OPE_CD                     ,
                UPD_DATE                       ,        
                UPD_PGM_ID)  
            VALUES(
                '2',
                DECODE(iShimeKind,'1','11',NULL),
                NVL2(johoForIrk2Row.IRK_2JI_CD,SUBSTR(johoForIrk2Row.IRK_2JI_CD,1,2),NULL),
                NVL2(johoForIrk2Row.IRK_2JI_CD,SUBSTR(johoForIrk2Row.IRK_2JI_CD,3,2),NULL),
                johoForIrk2Row.IRK_3JI_CD,
                '1',
                --johoForIrk2Row.IPPAN_KIJUN_BED_SU,
                --johoForIrk2Row.IPPAN_KIZON_BED_SU,
                TO_CHAR(johoForIrk2Row.IPPAN_KIJUN_BED_SU,'FM000009'),
                TO_CHAR(johoForIrk2Row.IPPAN_KIZON_BED_SU,'FM000009'),
                
                NVL2(johoForIrk2Row.IPPAN_KIZON_YMD,SUBSTR(johoForIrk2Row.IPPAN_KIZON_YMD,1,4),NULL),
                NVL2(johoForIrk2Row.IPPAN_KIZON_YMD,SUBSTR(johoForIrk2Row.IPPAN_KIZON_YMD,5,2),NULL),
                NVL2(johoForIrk2Row.IPPAN_KIZON_YMD,SUBSTR(johoForIrk2Row.IPPAN_KIZON_YMD,7,2),NULL),                               
                johoForIrk2Row.IPPAN_KAFUSOKU_BED_SU,
                --johoForIrk2Row.IPPAN_KAFUSOKU_BED_SU,
                DECODE(TRIM(johoForIrk2Row.IPPAN_KAFUSOKU_BED_SU),NULL,NULL,DECODE(SUBSTR(johoForIrk2Row.IPPAN_KAFUSOKU_BED_SU,1,1),'-',SUBSTR(johoForIrk2Row.IPPAN_KAFUSOKU_BED_SU,1,1)||LPAD(SUBSTR(johoForIrk2Row.IPPAN_KAFUSOKU_BED_SU,2),6,'0'), ' '||LPAD(johoForIrk2Row.IPPAN_KAFUSOKU_BED_SU,6,'0'))),
                NVL2(johoForIrk2Row.KOJI_YMD,SUBSTR(johoForIrk2Row.KOJI_YMD,1,4),NULL),
                NVL2(johoForIrk2Row.KOJI_YMD,SUBSTR(johoForIrk2Row.KOJI_YMD,5,2),NULL),
                NVL2(johoForIrk2Row.KOJI_YMD,SUBSTR(johoForIrk2Row.KOJI_YMD,7,2),NULL), 
                NULL,
                NVL2(johoForIrk2Row.MOD_YMD,SUBSTR(johoForIrk2Row.MOD_YMD,1,4),NULL),
                NVL2(johoForIrk2Row.MOD_YMD,SUBSTR(johoForIrk2Row.MOD_YMD,5,2),NULL),
                NVL2(johoForIrk2Row.MOD_YMD,SUBSTR(johoForIrk2Row.MOD_YMD,7,2),NULL),                                
                DECODE(iShimeKind,'1',SUBSTR(iTensoYMD,1,4),NULL),
                DECODE(iShimeKind,'1',SUBSTR(iTensoYMD,5,2),NULL),
                DECODE(iShimeKind,'1',SUBSTR(iTensoYMD,7,2),NULL),
                DECODE(iShimeKind,'1',SUBSTR(johoForIrk2Row.JI2_UPD_EIGY_YMD,1,4),NULL),
                DECODE(iShimeKind,'1',SUBSTR(johoForIrk2Row.JI2_UPD_EIGY_YMD,5,2),NULL),
                DECODE(iShimeKind,'1',SUBSTR(johoForIrk2Row.JI2_UPD_EIGY_YMD,7,2),NULL),                
                NULL,
                '4',                                         
                iOPE_CD,
                iDATE,
                iPGM_ID,
                iOPE_CD,
                iDATE,
                iPGM_ID
            );        

         
         
         
         
         EXECUTE_SQL := 'INSERT INTO TD_PA_IRK_KBN2(         
                FILE_KBN                       ,
                REC_ID                         ,
                IRK_CD_2JI_KEN_CD              ,
                IRK_CD_2JI_IRK_CD              ,
                CD_3JI                         ,
                BED_KBN                        ,
                KIJUN_SU_OR_SEIBI_SU           ,
                KIZON_BED_SU_BED_SU            ,
                KIZON_BED_SU_YMD_SY            ,
                KIZON_BED_SU_YMD_M             ,
                KIZON_BED_SU_YMD_D             ,
                KAFUSOKU_BED_SU_SSHK           ,
                KAFUSOKU_BED_SU_SSHK_MINUS     ,
                KOJI_YMD_SY                    ,
                KOJI_YMD_M                     ,
                KOJI_YMD_D                     ,
                FILLER                         ,
                MOD_YMD_SY                     ,
                MOD_YMD_M                      ,
                MOD_YMD_D                      ,
                TENSO_Y                        ,
                TENSO_M                        ,
                TENSO_D                        ,
                MENTE_Y                        ,
                MENTE_M                        ,
                MENTE_D                        ,
                MOD_KBN                        ,
                SORT                           ,
                TRK_OPE_CD                     ,
                TRK_DATE                       ,
                TRK_PGM_ID                     ,
                UPD_OPE_CD                     ,
                UPD_DATE                       ,        
                UPD_PGM_ID)  
            VALUES(
                ''2'',
                DECODE( '|| iShimeKind ||' ,''1'',''11'',NULL),
                NVL2( '|| johoForIrk2Row.IRK_2JI_CD ||' ,SUBSTR( '|| johoForIrk2Row.IRK_2JI_CD ||' ,1,2),NULL),
                NVL2( '|| johoForIrk2Row.IRK_2JI_CD ||' ,SUBSTR( '|| johoForIrk2Row.IRK_2JI_CD ||' ,3,2),NULL),
                '|| johoForIrk2Row.IRK_3JI_CD ||',
                ''1'',
                '|| johoForIrk2Row.IPPAN_KIJUN_BED_SU ||',
                '|| johoForIrk2Row.IPPAN_KIZON_BED_SU ||',
                NVL2( '|| johoForIrk2Row.IPPAN_KIZON_YMD ||' ,SUBSTR( '|| johoForIrk2Row.IPPAN_KIZON_YMD ||' ,1,4),NULL),
                NVL2( '|| johoForIrk2Row.IPPAN_KIZON_YMD ||' ,SUBSTR( '|| johoForIrk2Row.IPPAN_KIZON_YMD ||' ,5,2),NULL),
                NVL2( '|| johoForIrk2Row.IPPAN_KIZON_YMD ||' ,SUBSTR( '|| johoForIrk2Row.IPPAN_KIZON_YMD ||' ,7,2),NULL),                               
                '|| johoForIrk2Row.IPPAN_KAFUSOKU_BED_SU ||' ,
                '|| johoForIrk2Row.IPPAN_KAFUSOKU_BED_SU ||' ,
                NVL2( '|| johoForIrk2Row.KOJI_YMD ||' ,SUBSTR( '|| johoForIrk2Row.KOJI_YMD ||' ,1,4),NULL),
                NVL2( '|| johoForIrk2Row.KOJI_YMD ||' ,SUBSTR( '|| johoForIrk2Row.KOJI_YMD ||' ,5,2),NULL),
                NVL2( '|| johoForIrk2Row.KOJI_YMD ||' ,SUBSTR( '|| johoForIrk2Row.KOJI_YMD ||' ,7,2),NULL), 
                NULL,
                NVL2( '|| johoForIrk2Row.MOD_YMD ||' ,SUBSTR( '|| johoForIrk2Row.MOD_YMD ||' ,1,4),NULL),
                NVL2( '|| johoForIrk2Row.MOD_YMD ||' ,SUBSTR( '|| johoForIrk2Row.MOD_YMD ||' ,5,2),NULL),
                NVL2( '|| johoForIrk2Row.MOD_YMD ||' ,SUBSTR( '|| johoForIrk2Row.MOD_YMD ||' ,7,2),NULL),                                
                DECODE( '|| iShimeKind ||' ,''1'',SUBSTR( '|| iTensoYMD ||' ,1,4),NULL),
                DECODE( '|| iShimeKind ||' ,''1'',SUBSTR( '|| iTensoYMD ||' ,5,2),NULL),
                DECODE( '|| iShimeKind ||' ,''1'',SUBSTR( '|| iTensoYMD ||' ,7,2),NULL),
                DECODE( '|| iShimeKind ||' ,''1'',SUBSTR( '|| johoForIrk2Row.JI2_UPD_EIGY_YMD ||' ,1,4),NULL),
                DECODE( '|| iShimeKind ||' ,''1'',SUBSTR( '|| johoForIrk2Row.JI2_UPD_EIGY_YMD ||' ,5,2),NULL),
                DECODE( '|| iShimeKind ||' ,''1'',SUBSTR( '|| johoForIrk2Row.JI2_UPD_EIGY_YMD ||' ,7,2),NULL),                
                NULL,
                ''4'', '|| 
                iOPE_CD ||' ,
                '|| iDATE ||' ,
                '|| iPGM_ID ||' ,
                '|| iOPE_CD ||' ,
                '|| iDATE ||' ,
                '|| iPGM_ID ||' 
            )';        
         ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

         
         
         
         
         
         
         
         
            -- �a���敪��2�̏ꍇ
            INSERT INTO TD_PA_IRK_KBN2(         
                FILE_KBN                       ,
                REC_ID                         ,
                IRK_CD_2JI_KEN_CD              ,
                IRK_CD_2JI_IRK_CD              ,
                CD_3JI                         ,
                BED_KBN                        ,
                KIJUN_SU_OR_SEIBI_SU           ,
                KIZON_BED_SU_BED_SU            ,
                KIZON_BED_SU_YMD_SY            ,
                KIZON_BED_SU_YMD_M             ,
                KIZON_BED_SU_YMD_D             ,
                KAFUSOKU_BED_SU_SSHK           ,
                KAFUSOKU_BED_SU_SSHK_MINUS     ,
                KOJI_YMD_SY                    ,
                KOJI_YMD_M                     ,
                KOJI_YMD_D                     ,
                FILLER                         ,
                MOD_YMD_SY                     ,
                MOD_YMD_M                      ,
                MOD_YMD_D                      ,
                TENSO_Y                        ,
                TENSO_M                        ,
                TENSO_D                        ,
                MENTE_Y                        ,
                MENTE_M                        ,
                MENTE_D                        ,
                MOD_KBN                        ,
                SORT                           ,
                TRK_OPE_CD                     ,
                TRK_DATE                       ,
                TRK_PGM_ID                     ,
                UPD_OPE_CD                     ,
                UPD_DATE                       ,        
                UPD_PGM_ID)  
            VALUES(
                '2',
                DECODE(iShimeKind,'1','11',NULL),
                NVL2(johoForIrk2Row.IRK_2JI_CD,SUBSTR(johoForIrk2Row.IRK_2JI_CD,1,2),NULL),
                NVL2(johoForIrk2Row.IRK_2JI_CD,SUBSTR(johoForIrk2Row.IRK_2JI_CD,3,2),NULL),
                johoForIrk2Row.IRK_3JI_CD,
                '2',
                NULL,
                NULL,
                NULL,
                NULL,
                NULL,
                NULL,
                NULL,
                NULL,
                NULL,
                NULL,
                NULL,
                NULL,
                NULL,
                NULL,
                DECODE(iShimeKind,'1',SUBSTR(iTensoYMD,1,4),NULL),
                DECODE(iShimeKind,'1',SUBSTR(iTensoYMD,5,2),NULL),
                DECODE(iShimeKind,'1',SUBSTR(iTensoYMD,7,2),NULL),
                DECODE(iShimeKind,'1',SUBSTR(johoForIrk2Row.UPD_EIGY_YMD,1,4),NULL),
                DECODE(iShimeKind,'1',SUBSTR(johoForIrk2Row.UPD_EIGY_YMD,5,2),NULL),
                DECODE(iShimeKind,'1',SUBSTR(johoForIrk2Row.UPD_EIGY_YMD,7,2),NULL),                
                NULL,
                '4',                                         
                iOPE_CD,
                iDATE,
                iPGM_ID,
                iOPE_CD,
                iDATE,
                iPGM_ID
            );                 

         
         
         
         
         EXECUTE_SQL := 'INSERT INTO TD_PA_IRK_KBN2(         
                FILE_KBN                       ,
                REC_ID                         ,
                IRK_CD_2JI_KEN_CD              ,
                IRK_CD_2JI_IRK_CD              ,
                CD_3JI                         ,
                BED_KBN                        ,
                KIJUN_SU_OR_SEIBI_SU           ,
                KIZON_BED_SU_BED_SU            ,
                KIZON_BED_SU_YMD_SY            ,
                KIZON_BED_SU_YMD_M             ,
                KIZON_BED_SU_YMD_D             ,
                KAFUSOKU_BED_SU_SSHK           ,
                KAFUSOKU_BED_SU_SSHK_MINUS     ,
                KOJI_YMD_SY                    ,
                KOJI_YMD_M                     ,
                KOJI_YMD_D                     ,
                FILLER                         ,
                MOD_YMD_SY                     ,
                MOD_YMD_M                      ,
                MOD_YMD_D                      ,
                TENSO_Y                        ,
                TENSO_M                        ,
                TENSO_D                        ,
                MENTE_Y                        ,
                MENTE_M                        ,
                MENTE_D                        ,
                MOD_KBN                        ,
                SORT                           ,
                TRK_OPE_CD                     ,
                TRK_DATE                       ,
                TRK_PGM_ID                     ,
                UPD_OPE_CD                     ,
                UPD_DATE                       ,        
                UPD_PGM_ID)  
            VALUES(
                ''2'',
                DECODE( '|| iShimeKind ||' ,''1'',''11'',NULL),
                NVL2( '|| johoForIrk2Row.IRK_2JI_CD ||' ,SUBSTR( '|| johoForIrk2Row.IRK_2JI_CD ||' ,1,2),NULL),
                NVL2( '|| johoForIrk2Row.IRK_2JI_CD ||' ,SUBSTR( '|| johoForIrk2Row.IRK_2JI_CD ||' ,3,2),NULL),
                '|| johoForIrk2Row.IRK_3JI_CD ||' ,
                ''2'',
                NULL,
                NULL,
                NULL,
                NULL,
                NULL,
                NULL,
                NULL,
                NULL,
                NULL,
                NULL,
                NULL,
                NULL,
                NULL,
                NULL,
                DECODE( '|| iShimeKind ||' ,''1'',SUBSTR( '|| iTensoYMD ||' ,1,4),NULL),
                DECODE( '|| iShimeKind ||' ,''1'',SUBSTR( '|| iTensoYMD ||' ,5,2),NULL),
                DECODE( '|| iShimeKind ||' ,''1'',SUBSTR( '|| iTensoYMD ||' ,7,2),NULL),
                DECODE( '|| iShimeKind ||' ,''1'',SUBSTR( '|| johoForIrk2Row.UPD_EIGY_YMD ||' ,1,4),NULL),
                DECODE( '|| iShimeKind ||' ,''1'',SUBSTR( '|| johoForIrk2Row.UPD_EIGY_YMD ||' ,5,2),NULL),
                DECODE( '|| iShimeKind ||' ,''1'',SUBSTR( '|| johoForIrk2Row.UPD_EIGY_YMD ||' ,7,2),NULL),                
                NULL,
                ''4'', '||                                          
                iOPE_CD ||' ,
                '|| iDATE ||' ,
                '|| iPGM_ID ||' ,
                '|| iOPE_CD ||' ,
                '|| iDATE ||' ,
                '|| iPGM_ID ||' 
            )';                 
         ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

         
         
         
             -- �a���敪��3�̏ꍇ
	    IF oldKenCd <> johoForIrk2Row.KEN_CD THEN

            INSERT INTO TD_PA_IRK_KBN2(         
                FILE_KBN                       ,
                REC_ID                         ,
                IRK_CD_2JI_KEN_CD              ,
                IRK_CD_2JI_IRK_CD              ,
                CD_3JI                         ,
                BED_KBN                        ,
                KIJUN_SU_OR_SEIBI_SU           ,
                KIZON_BED_SU_BED_SU            ,
                KIZON_BED_SU_YMD_SY            ,
                KIZON_BED_SU_YMD_M             ,
                KIZON_BED_SU_YMD_D             ,
                KAFUSOKU_BED_SU_SSHK           ,
                KAFUSOKU_BED_SU_SSHK_MINUS     ,
                KOJI_YMD_SY                    ,
                KOJI_YMD_M                     ,
                KOJI_YMD_D                     ,
                FILLER                         ,
                MOD_YMD_SY                     ,
                MOD_YMD_M                      ,
                MOD_YMD_D                      ,
                TENSO_Y                        ,
                TENSO_M                        ,
                TENSO_D                        ,
                MENTE_Y                        ,
                MENTE_M                        ,
                MENTE_D                        ,
                MOD_KBN                        ,
                SORT                           ,
                TRK_OPE_CD                     ,
                TRK_DATE                       ,
                TRK_PGM_ID                     ,
                UPD_OPE_CD                     ,
                UPD_DATE                       ,        
                UPD_PGM_ID)  
            VALUES(
                '2',
                DECODE(iShimeKind,'1','11',NULL),
                johoForIrk2Row.KEN_CD,
                '  ',
                NULL,
                '3',
                --johoForIrk2Row.SEISHIN_KIJUN_BED_SU_GOKEI,
                --johoForIrk2Row.SEISHIN_KIZON_BED_SU_GOKEI,
                TO_CHAR(johoForIrk2Row.SEISHIN_KIJUN_BED_SU_GOKEI,'FM000009'),
                TO_CHAR(johoForIrk2Row.SEISHIN_KIZON_BED_SU_GOKEI,'FM000009'),

                NVL2(johoForIrk2Row.SEISHIN_KIZON_YMD,SUBSTR(johoForIrk2Row.SEISHIN_KIZON_YMD,1,4),NULL),
                NVL2(johoForIrk2Row.SEISHIN_KIZON_YMD,SUBSTR(johoForIrk2Row.SEISHIN_KIZON_YMD,5,2),NULL),
                NVL2(johoForIrk2Row.SEISHIN_KIZON_YMD,SUBSTR(johoForIrk2Row.SEISHIN_KIZON_YMD,7,2),NULL),                               
                johoForIrk2Row.SEISHIN_KAFUSOKU_BED_SU_GOKEI,
                --johoForIrk2Row.SEISHIN_KAFUSOKU_BED_SU_GOKEI,
                DECODE(TRIM(johoForIrk2Row.SEISHIN_KAFUSOKU_BED_SU_GOKEI),NULL,NULL,DECODE(SUBSTR(johoForIrk2Row.SEISHIN_KAFUSOKU_BED_SU_GOKEI,1,1),'-',SUBSTR(johoForIrk2Row.SEISHIN_KAFUSOKU_BED_SU_GOKEI,1,1)||LPAD(SUBSTR(johoForIrk2Row.SEISHIN_KAFUSOKU_BED_SU_GOKEI,2),6,'0'), ' '||LPAD(johoForIrk2Row.SEISHIN_KAFUSOKU_BED_SU_GOKEI,6,'0'))),
                NVL2(johoForIrk2Row.KOJI_YMD,SUBSTR(johoForIrk2Row.KOJI_YMD,1,4),NULL),
                NVL2(johoForIrk2Row.KOJI_YMD,SUBSTR(johoForIrk2Row.KOJI_YMD,5,2),NULL),
                NVL2(johoForIrk2Row.KOJI_YMD,SUBSTR(johoForIrk2Row.KOJI_YMD,7,2),NULL), 
                NULL,
                NVL2(johoForIrk2Row.MOD_YMD,SUBSTR(johoForIrk2Row.MOD_YMD,1,4),NULL),
                NVL2(johoForIrk2Row.MOD_YMD,SUBSTR(johoForIrk2Row.MOD_YMD,5,2),NULL),
                NVL2(johoForIrk2Row.MOD_YMD,SUBSTR(johoForIrk2Row.MOD_YMD,7,2),NULL),                                
                DECODE(iShimeKind,'1',SUBSTR(iTensoYMD,1,4),NULL),
                DECODE(iShimeKind,'1',SUBSTR(iTensoYMD,5,2),NULL),
                DECODE(iShimeKind,'1',SUBSTR(iTensoYMD,7,2),NULL),
                DECODE(iShimeKind,'1',SUBSTR(johoForIrk2Row.UPD_EIGY_YMD,1,4),NULL),
                DECODE(iShimeKind,'1',SUBSTR(johoForIrk2Row.UPD_EIGY_YMD,5,2),NULL),
                DECODE(iShimeKind,'1',SUBSTR(johoForIrk2Row.UPD_EIGY_YMD,7,2),NULL),                
                NULL,
                '1',                                         
                iOPE_CD,
                iDATE,
                iPGM_ID,
                iOPE_CD,
                iDATE,
                iPGM_ID
            );          

         
         
         
         
         EXECUTE_SQL := 'INSERT INTO TD_PA_IRK_KBN2(         
                FILE_KBN                       ,
                REC_ID                         ,
                IRK_CD_2JI_KEN_CD              ,
                IRK_CD_2JI_IRK_CD              ,
                CD_3JI                         ,
                BED_KBN                        ,
                KIJUN_SU_OR_SEIBI_SU           ,
                KIZON_BED_SU_BED_SU            ,
                KIZON_BED_SU_YMD_SY            ,
                KIZON_BED_SU_YMD_M             ,
                KIZON_BED_SU_YMD_D             ,
                KAFUSOKU_BED_SU_SSHK           ,
                KAFUSOKU_BED_SU_SSHK_MINUS     ,
                KOJI_YMD_SY                    ,
                KOJI_YMD_M                     ,
                KOJI_YMD_D                     ,
                FILLER                         ,
                MOD_YMD_SY                     ,
                MOD_YMD_M                      ,
                MOD_YMD_D                      ,
                TENSO_Y                        ,
                TENSO_M                        ,
                TENSO_D                        ,
                MENTE_Y                        ,
                MENTE_M                        ,
                MENTE_D                        ,
                MOD_KBN                        ,
                SORT                           ,
                TRK_OPE_CD                     ,
                TRK_DATE                       ,
                TRK_PGM_ID                     ,
                UPD_OPE_CD                     ,
                UPD_DATE                       ,        
                UPD_PGM_ID)  
            VALUES(
                ''2'',
                DECODE( '|| iShimeKind ||' ,''1'',''11'',NULL),
                '|| johoForIrk2Row.KEN_CD ||' ,
                ''  '',
                NULL,
                ''3'',
                '|| johoForIrk2Row.SEISHIN_KIJUN_BED_SU_GOKEI ||' ,
                '|| johoForIrk2Row.SEISHIN_KIZON_BED_SU_GOKEI ||' ,
                NVL2( '|| johoForIrk2Row.SEISHIN_KIZON_YMD ||' ,SUBSTR( '|| johoForIrk2Row.SEISHIN_KIZON_YMD ||' ,1,4),NULL),
                NVL2( '|| johoForIrk2Row.SEISHIN_KIZON_YMD ||' ,SUBSTR( '|| johoForIrk2Row.SEISHIN_KIZON_YMD ||' ,5,2),NULL),
                NVL2( '|| johoForIrk2Row.SEISHIN_KIZON_YMD ||' ,SUBSTR( '|| johoForIrk2Row.SEISHIN_KIZON_YMD ||' ,7,2),NULL),                               
                '|| johoForIrk2Row.SEISHIN_KAFUSOKU_BED_SU_GOKEI ||' ,
                '|| johoForIrk2Row.SEISHIN_KAFUSOKU_BED_SU_GOKEI ||' ,
                NVL2( '|| johoForIrk2Row.KOJI_YMD ||' ,SUBSTR( '|| johoForIrk2Row.KOJI_YMD ||' ,1,4),NULL),
                NVL2( '|| johoForIrk2Row.KOJI_YMD ||' ,SUBSTR( '|| johoForIrk2Row.KOJI_YMD ||' ,5,2),NULL),
                NVL2( '|| johoForIrk2Row.KOJI_YMD ||' ,SUBSTR( '|| johoForIrk2Row.KOJI_YMD ||' ,7,2),NULL), 
                NULL,
                NVL2( '|| johoForIrk2Row.MOD_YMD ||' ,SUBSTR( '|| johoForIrk2Row.MOD_YMD ||' ,1,4),NULL),
                NVL2( '|| johoForIrk2Row.MOD_YMD ||' ,SUBSTR( '|| johoForIrk2Row.MOD_YMD ||' ,5,2),NULL),
                NVL2( '|| johoForIrk2Row.MOD_YMD ||' ,SUBSTR( '|| johoForIrk2Row.MOD_YMD ||' ,7,2),NULL),                                
                DECODE( '|| iShimeKind ||' ,''1'',SUBSTR( '|| iTensoYMD ||' ,1,4),NULL),
                DECODE( '|| iShimeKind ||' ,''1'',SUBSTR( '|| iTensoYMD ||' ,5,2),NULL),
                DECODE( '|| iShimeKind ||' ,''1'',SUBSTR( '|| iTensoYMD ||' ,7,2),NULL),
                DECODE( '|| iShimeKind ||' ,''1'',SUBSTR( '|| johoForIrk2Row.UPD_EIGY_YMD ||' ,1,4),NULL),
                DECODE( '|| iShimeKind ||' ,''1'',SUBSTR( '|| johoForIrk2Row.UPD_EIGY_YMD ||' ,5,2),NULL),
                DECODE( '|| iShimeKind ||' ,''1'',SUBSTR( '|| johoForIrk2Row.UPD_EIGY_YMD ||' ,7,2),NULL),                
                NULL,
                ''1'', '||                                         
                iOPE_CD ||' ,
                 '|| iDATE ||' ,
                 '|| iPGM_ID ||' ,
                 '|| iOPE_CD ||' ,
                 '|| iDATE ||' ,
                 '|| iPGM_ID ||' 
            )';          
         ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);




             -- �a���敪��4�̏ꍇ
            INSERT INTO TD_PA_IRK_KBN2(         
                FILE_KBN                       ,
                REC_ID                         ,
                IRK_CD_2JI_KEN_CD              ,
                IRK_CD_2JI_IRK_CD              ,
                CD_3JI                         ,
                BED_KBN                        ,
                KIJUN_SU_OR_SEIBI_SU           ,
                KIZON_BED_SU_BED_SU            ,
                KIZON_BED_SU_YMD_SY            ,
                KIZON_BED_SU_YMD_M             ,
                KIZON_BED_SU_YMD_D             ,
                KAFUSOKU_BED_SU_SSHK           ,
                KAFUSOKU_BED_SU_SSHK_MINUS     ,
                KOJI_YMD_SY                    ,
                KOJI_YMD_M                     ,
                KOJI_YMD_D                     ,
                FILLER                         ,
                MOD_YMD_SY                     ,
                MOD_YMD_M                      ,
                MOD_YMD_D                      ,
                TENSO_Y                        ,
                TENSO_M                        ,
                TENSO_D                        ,
                MENTE_Y                        ,
                MENTE_M                        ,
                MENTE_D                        ,
                MOD_KBN                        ,
                SORT                           ,
                TRK_OPE_CD                     ,
                TRK_DATE                       ,
                TRK_PGM_ID                     ,
                UPD_OPE_CD                     ,
                UPD_DATE                       ,        
                UPD_PGM_ID)  
            VALUES(
                '2',
                DECODE(iShimeKind,'1','11',NULL),
                johoForIrk2Row.KEN_CD,
                '  ',
                NULL,
                '4',
                --johoForIrk2Row.KEKKAKU_KIJUN_BED_SU_GOKEI,
                --johoForIrk2Row.KEKKAKU_KIZON_BED_SU_GOKEI,
                TO_CHAR(johoForIrk2Row.KEKKAKU_KIJUN_BED_SU_GOKEI,'FM000009'),
                TO_CHAR(johoForIrk2Row.KEKKAKU_KIZON_BED_SU_GOKEI,'FM000009'),

                NVL2(johoForIrk2Row.KEKKAKU_KIZON_YMD,SUBSTR(johoForIrk2Row.KEKKAKU_KIZON_YMD,1,4),NULL),
                NVL2(johoForIrk2Row.KEKKAKU_KIZON_YMD,SUBSTR(johoForIrk2Row.KEKKAKU_KIZON_YMD,5,2),NULL),
                NVL2(johoForIrk2Row.KEKKAKU_KIZON_YMD,SUBSTR(johoForIrk2Row.KEKKAKU_KIZON_YMD,7,2),NULL),                               
                johoForIrk2Row.KEKKAKU_KAFUSOKU_BED_SU_GOKEI,
                --johoForIrk2Row.KEKKAKU_KAFUSOKU_BED_SU_GOKEI,
                DECODE(TRIM(johoForIrk2Row.KEKKAKU_KAFUSOKU_BED_SU_GOKEI),NULL,NULL,DECODE(SUBSTR(johoForIrk2Row.KEKKAKU_KAFUSOKU_BED_SU_GOKEI,1,1),'-',SUBSTR(johoForIrk2Row.KEKKAKU_KAFUSOKU_BED_SU_GOKEI,1,1)||LPAD(SUBSTR(johoForIrk2Row.KEKKAKU_KAFUSOKU_BED_SU_GOKEI,2),6,'0'), ' '||LPAD(johoForIrk2Row.KEKKAKU_KAFUSOKU_BED_SU_GOKEI,6,'0'))),
                NVL2(johoForIrk2Row.KOJI_YMD,SUBSTR(johoForIrk2Row.KOJI_YMD,1,4),NULL),
                NVL2(johoForIrk2Row.KOJI_YMD,SUBSTR(johoForIrk2Row.KOJI_YMD,5,2),NULL),
                NVL2(johoForIrk2Row.KOJI_YMD,SUBSTR(johoForIrk2Row.KOJI_YMD,7,2),NULL), 
                NULL,
                NVL2(johoForIrk2Row.MOD_YMD,SUBSTR(johoForIrk2Row.MOD_YMD,1,4),NULL),
                NVL2(johoForIrk2Row.MOD_YMD,SUBSTR(johoForIrk2Row.MOD_YMD,5,2),NULL),
                NVL2(johoForIrk2Row.MOD_YMD,SUBSTR(johoForIrk2Row.MOD_YMD,7,2),NULL),                                
                DECODE(iShimeKind,'1',SUBSTR(iTensoYMD,1,4),NULL),
                DECODE(iShimeKind,'1',SUBSTR(iTensoYMD,5,2),NULL),
                DECODE(iShimeKind,'1',SUBSTR(iTensoYMD,7,2),NULL),
                DECODE(iShimeKind,'1',SUBSTR(johoForIrk2Row.UPD_EIGY_YMD,1,4),NULL),
                DECODE(iShimeKind,'1',SUBSTR(johoForIrk2Row.UPD_EIGY_YMD,5,2),NULL),
                DECODE(iShimeKind,'1',SUBSTR(johoForIrk2Row.UPD_EIGY_YMD,7,2),NULL),                
                NULL,
                '2',                                         
                iOPE_CD,
                iDATE,
                iPGM_ID,
                iOPE_CD,
                iDATE,
                iPGM_ID
            );           




            EXECUTE_SQL := 'INSERT INTO TD_PA_IRK_KBN2(         
                FILE_KBN                       ,
                REC_ID                         ,
                IRK_CD_2JI_KEN_CD              ,
                IRK_CD_2JI_IRK_CD              ,
                CD_3JI                         ,
                BED_KBN                        ,
                KIJUN_SU_OR_SEIBI_SU           ,
                KIZON_BED_SU_BED_SU            ,
                KIZON_BED_SU_YMD_SY            ,
                KIZON_BED_SU_YMD_M             ,
                KIZON_BED_SU_YMD_D             ,
                KAFUSOKU_BED_SU_SSHK           ,
                KAFUSOKU_BED_SU_SSHK_MINUS     ,
                KOJI_YMD_SY                    ,
                KOJI_YMD_M                     ,
                KOJI_YMD_D                     ,
                FILLER                         ,
                MOD_YMD_SY                     ,
                MOD_YMD_M                      ,
                MOD_YMD_D                      ,
                TENSO_Y                        ,
                TENSO_M                        ,
                TENSO_D                        ,
                MENTE_Y                        ,
                MENTE_M                        ,
                MENTE_D                        ,
                MOD_KBN                        ,
                SORT                           ,
                TRK_OPE_CD                     ,
                TRK_DATE                       ,
                TRK_PGM_ID                     ,
                UPD_OPE_CD                     ,
                UPD_DATE                       ,        
                UPD_PGM_ID)  
            VALUES(
                ''2'',
                DECODE( '|| iShimeKind ||' ,''1'',''11'',NULL),
                '|| johoForIrk2Row.KEN_CD ||' ,
                ''  '',
                NULL,
                ''4'',
                '|| johoForIrk2Row.KEKKAKU_KIJUN_BED_SU_GOKEI ||' ,
                '|| johoForIrk2Row.KEKKAKU_KIZON_BED_SU_GOKEI ||' ,
                NVL2( '|| johoForIrk2Row.KEKKAKU_KIZON_YMD ||' ,SUBSTR( '|| johoForIrk2Row.KEKKAKU_KIZON_YMD ||' ,1,4),NULL),
                NVL2( '|| johoForIrk2Row.KEKKAKU_KIZON_YMD ||' ,SUBSTR( '|| johoForIrk2Row.KEKKAKU_KIZON_YMD ||' ,5,2),NULL),
                NVL2( '|| johoForIrk2Row.KEKKAKU_KIZON_YMD ||' ,SUBSTR( '|| johoForIrk2Row.KEKKAKU_KIZON_YMD ||' ,7,2),NULL),                               
                '|| johoForIrk2Row.KEKKAKU_KAFUSOKU_BED_SU_GOKEI ||' ,
                '|| johoForIrk2Row.KEKKAKU_KAFUSOKU_BED_SU_GOKEI ||' ,
                NVL2( '|| johoForIrk2Row.KOJI_YMD ||' ,SUBSTR( '|| johoForIrk2Row.KOJI_YMD ||' ,1,4),NULL),
                NVL2( '|| johoForIrk2Row.KOJI_YMD ||' ,SUBSTR( '|| johoForIrk2Row.KOJI_YMD ||' ,5,2),NULL),
                NVL2( '|| johoForIrk2Row.KOJI_YMD ||' ,SUBSTR( '|| johoForIrk2Row.KOJI_YMD ||' ,7,2),NULL), 
                NULL,
                NVL2( '|| johoForIrk2Row.MOD_YMD ||' ,SUBSTR( '|| johoForIrk2Row.MOD_YMD ||' ,1,4),NULL),
                NVL2( '|| johoForIrk2Row.MOD_YMD ||' ,SUBSTR( '|| johoForIrk2Row.MOD_YMD ||' ,5,2),NULL),
                NVL2( '|| johoForIrk2Row.MOD_YMD ||' ,SUBSTR( '|| johoForIrk2Row.MOD_YMD ||' ,7,2),NULL),
                DECODE( '|| iShimeKind ||' ,''1'',SUBSTR( '|| iTensoYMD ||' ,1,4),NULL),
                DECODE( '|| iShimeKind ||' ,''1'',SUBSTR( '|| iTensoYMD ||' ,5,2),NULL),
                DECODE( '|| iShimeKind ||' ,''1'',SUBSTR( '|| iTensoYMD ||' ,7,2),NULL),
                DECODE( '|| iShimeKind ||' ,''1'',SUBSTR( '|| johoForIrk2Row.UPD_EIGY_YMD ||' ,1,4),NULL),
                DECODE( '|| iShimeKind ||' ,''1'',SUBSTR( '|| johoForIrk2Row.UPD_EIGY_YMD ||' ,5,2),NULL),
                DECODE( '|| iShimeKind ||' ,''1'',SUBSTR( '|| johoForIrk2Row.UPD_EIGY_YMD ||' ,7,2),NULL),                
                NULL,
                ''2'', '||
                iOPE_CD ||' ,
                '|| iDATE ||' ,
                '|| iPGM_ID ||' ,
                '|| iOPE_CD ||' ,
                '|| iDATE ||' ,
                '|| iPGM_ID ||' 
            )';           
         ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);







            -- �a���敪��5�̏ꍇ
            INSERT INTO TD_PA_IRK_KBN2(         
                FILE_KBN                       ,
                REC_ID                         ,
                IRK_CD_2JI_KEN_CD              ,
                IRK_CD_2JI_IRK_CD              ,
                CD_3JI                         ,
                BED_KBN                        ,
                KIJUN_SU_OR_SEIBI_SU           ,
                KIZON_BED_SU_BED_SU            ,
                KIZON_BED_SU_YMD_SY            ,
                KIZON_BED_SU_YMD_M             ,
                KIZON_BED_SU_YMD_D             ,
                KAFUSOKU_BED_SU_SSHK           ,
                KAFUSOKU_BED_SU_SSHK_MINUS     ,
                KOJI_YMD_SY                    ,
                KOJI_YMD_M                     ,
                KOJI_YMD_D                     ,
                FILLER                         ,
                MOD_YMD_SY                     ,
                MOD_YMD_M                      ,
                MOD_YMD_D                      ,
                TENSO_Y                        ,
                TENSO_M                        ,
                TENSO_D                        ,
                MENTE_Y                        ,
                MENTE_M                        ,
                MENTE_D                        ,
                MOD_KBN                        ,
                SORT                           ,
                TRK_OPE_CD                     ,
                TRK_DATE                       ,
                TRK_PGM_ID                     ,
                UPD_OPE_CD                     ,
                UPD_DATE                       ,        
                UPD_PGM_ID)  
            VALUES(
                '2',
                DECODE(iShimeKind,'1','11',NULL),
                johoForIrk2Row.KEN_CD,
                '  ',
                NULL,
                '5',
                --johoForIrk2Row.KANSEN_KIJUN_BED_SU_GOKEI,
                --johoForIrk2Row.KANSEN_KIZON_BED_SU_GOKEI,
                TO_CHAR(johoForIrk2Row.KANSEN_KIJUN_BED_SU_GOKEI,'FM000009'),
                TO_CHAR(johoForIrk2Row.KANSEN_KIZON_BED_SU_GOKEI,'FM000009'),

                NVL2(johoForIrk2Row.KANSEN_KIZON_YMD,SUBSTR(johoForIrk2Row.KANSEN_KIZON_YMD,1,4),NULL),
                NVL2(johoForIrk2Row.KANSEN_KIZON_YMD,SUBSTR(johoForIrk2Row.KANSEN_KIZON_YMD,5,2),NULL),
                NVL2(johoForIrk2Row.KANSEN_KIZON_YMD,SUBSTR(johoForIrk2Row.KANSEN_KIZON_YMD,7,2),NULL),                               
                johoForIrk2Row.KANSEN_KAFUSOKU_BED_SU_GOKEI,
                --johoForIrk2Row.KANSEN_KAFUSOKU_BED_SU_GOKEI,
                DECODE(TRIM(johoForIrk2Row.KANSEN_KAFUSOKU_BED_SU_GOKEI),NULL,NULL,DECODE(SUBSTR(johoForIrk2Row.KANSEN_KAFUSOKU_BED_SU_GOKEI,1,1),'-',SUBSTR(johoForIrk2Row.KANSEN_KAFUSOKU_BED_SU_GOKEI,1,1)||LPAD(SUBSTR(johoForIrk2Row.KANSEN_KAFUSOKU_BED_SU_GOKEI,2),6,'0'), ' '||LPAD(johoForIrk2Row.KANSEN_KAFUSOKU_BED_SU_GOKEI,6,'0'))),
                NVL2(johoForIrk2Row.KOJI_YMD,SUBSTR(johoForIrk2Row.KOJI_YMD,1,4),NULL),
                NVL2(johoForIrk2Row.KOJI_YMD,SUBSTR(johoForIrk2Row.KOJI_YMD,5,2),NULL),
                NVL2(johoForIrk2Row.KOJI_YMD,SUBSTR(johoForIrk2Row.KOJI_YMD,7,2),NULL), 
                NULL,
                NVL2(johoForIrk2Row.MOD_YMD,SUBSTR(johoForIrk2Row.MOD_YMD,1,4),NULL),
                NVL2(johoForIrk2Row.MOD_YMD,SUBSTR(johoForIrk2Row.MOD_YMD,5,2),NULL),
                NVL2(johoForIrk2Row.MOD_YMD,SUBSTR(johoForIrk2Row.MOD_YMD,7,2),NULL),                                
                DECODE(iShimeKind,'1',SUBSTR(iTensoYMD,1,4),NULL),
                DECODE(iShimeKind,'1',SUBSTR(iTensoYMD,5,2),NULL),
                DECODE(iShimeKind,'1',SUBSTR(iTensoYMD,7,2),NULL),
                DECODE(iShimeKind,'1',SUBSTR(johoForIrk2Row.UPD_EIGY_YMD,1,4),NULL),
                DECODE(iShimeKind,'1',SUBSTR(johoForIrk2Row.UPD_EIGY_YMD,5,2),NULL),
                DECODE(iShimeKind,'1',SUBSTR(johoForIrk2Row.UPD_EIGY_YMD,7,2),NULL),                
                NULL,
                '3',                                         
                iOPE_CD,
                iDATE,
                iPGM_ID,
                iOPE_CD,
                iDATE,
                iPGM_ID
            );          




            EXECUTE_SQL := 'INSERT INTO TD_PA_IRK_KBN2(         
                FILE_KBN                       ,
                REC_ID                         ,
                IRK_CD_2JI_KEN_CD              ,
                IRK_CD_2JI_IRK_CD              ,
                CD_3JI                         ,
                BED_KBN                        ,
                KIJUN_SU_OR_SEIBI_SU           ,
                KIZON_BED_SU_BED_SU            ,
                KIZON_BED_SU_YMD_SY            ,
                KIZON_BED_SU_YMD_M             ,
                KIZON_BED_SU_YMD_D             ,
                KAFUSOKU_BED_SU_SSHK           ,
                KAFUSOKU_BED_SU_SSHK_MINUS     ,
                KOJI_YMD_SY                    ,
                KOJI_YMD_M                     ,
                KOJI_YMD_D                     ,
                FILLER                         ,
                MOD_YMD_SY                     ,
                MOD_YMD_M                      ,
                MOD_YMD_D                      ,
                TENSO_Y                        ,
                TENSO_M                        ,
                TENSO_D                        ,
                MENTE_Y                        ,
                MENTE_M                        ,
                MENTE_D                        ,
                MOD_KBN                        ,
                SORT                           ,
                TRK_OPE_CD                     ,
                TRK_DATE                       ,
                TRK_PGM_ID                     ,
                UPD_OPE_CD                     ,
                UPD_DATE                       ,        
                UPD_PGM_ID)  
            VALUES(
                ''2'',
                DECODE( '|| iShimeKind ||' ,''1'',''11'',NULL),
                '|| johoForIrk2Row.KEN_CD ||' ,
                ''  '',
                NULL,
                ''5'',
                '|| johoForIrk2Row.KANSEN_KIJUN_BED_SU_GOKEI ||' ,
                '|| johoForIrk2Row.KANSEN_KIZON_BED_SU_GOKEI ||' ,
                NVL2( '|| johoForIrk2Row.KANSEN_KIZON_YMD ||' ,SUBSTR( '|| johoForIrk2Row.KANSEN_KIZON_YMD ||' ,1,4),NULL),
                NVL2( '|| johoForIrk2Row.KANSEN_KIZON_YMD ||' ,SUBSTR( '|| johoForIrk2Row.KANSEN_KIZON_YMD ||' ,5,2),NULL),
                NVL2( '|| johoForIrk2Row.KANSEN_KIZON_YMD ||' ,SUBSTR( '|| johoForIrk2Row.KANSEN_KIZON_YMD ||' ,7,2),NULL),
                '|| johoForIrk2Row.KANSEN_KAFUSOKU_BED_SU_GOKEI ||' ,
                '|| johoForIrk2Row.KANSEN_KAFUSOKU_BED_SU_GOKEI ||' ,
                NVL2( '|| johoForIrk2Row.KOJI_YMD ||' ,SUBSTR( '|| johoForIrk2Row.KOJI_YMD ||' ,1,4),NULL),
                NVL2( '|| johoForIrk2Row.KOJI_YMD ||' ,SUBSTR( '|| johoForIrk2Row.KOJI_YMD ||' ,5,2),NULL),
                NVL2( '|| johoForIrk2Row.KOJI_YMD ||' ,SUBSTR( '|| johoForIrk2Row.KOJI_YMD ||' ,7,2),NULL), 
                NULL,
                NVL2( '|| johoForIrk2Row.MOD_YMD ||' ,SUBSTR( '|| johoForIrk2Row.MOD_YMD ||' ,1,4),NULL),
                NVL2( '|| johoForIrk2Row.MOD_YMD ||' ,SUBSTR( '|| johoForIrk2Row.MOD_YMD ||' ,5,2),NULL),
                NVL2( '|| johoForIrk2Row.MOD_YMD ||' ,SUBSTR( '|| johoForIrk2Row.MOD_YMD ||' ,7,2),NULL),                                
                DECODE( '|| iShimeKind ||' ,''1'',SUBSTR( '|| iTensoYMD ||' ,1,4),NULL),
                DECODE( '|| iShimeKind ||' ,''1'',SUBSTR( '|| iTensoYMD ||' ,5,2),NULL),
                DECODE( '|| iShimeKind ||' ,''1'',SUBSTR( '|| iTensoYMD ||' ,7,2),NULL),
                DECODE( '|| iShimeKind ||' ,''1'',SUBSTR( '|| johoForIrk2Row.UPD_EIGY_YMD ||' ,1,4),NULL),
                DECODE( '|| iShimeKind ||' ,''1'',SUBSTR( '|| johoForIrk2Row.UPD_EIGY_YMD ||' ,5,2),NULL),
                DECODE( '|| iShimeKind ||' ,''1'',SUBSTR( '|| johoForIrk2Row.UPD_EIGY_YMD ||' ,7,2),NULL),                
                NULL,
                ''3'','||
                iOPE_CD ||' ,
                '|| iDATE ||' ,
                '|| iPGM_ID ||' ,
                '|| iOPE_CD ||' ,
                '|| iDATE ||' ,
                '|| iPGM_ID ||' 
            )';          
         ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);






         END IF; 

         oldKenCd := johoForIrk2Row.KEN_CD;
   
         END LOOP;
         CLOSE johoForIrk2CSR;        

         --�b��_�S��_��Ì��^�C�v1_�敪3�̃f�[�^���N���A����
         EXECUTE_SQL := 'TRUNCATE TABLE ' || vSchemaNm || '.' || 'TD_PA_IRK_KBN3';
         EXECUTE IMMEDIATE EXECUTE_SQL;
         ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

oROW_COUNT:=0;
              
         -- �擾�����f��DB�f�[�^���������J��Ԃ�
         OPEN johoForIrk3CSR ;
         LOOP
            FETCH johoForIrk3CSR INTO johoForIrk3Row;
            EXIT WHEN johoForIrk3CSR%NOTFOUND;
            oROW_COUNT:=oROW_COUNT+1;
            
            INSERT INTO TD_PA_IRK_KBN3(         
                FILE_KBN             ,
                REC_ID               ,
                IRK_CD_KEN_CD_2JI    ,
                IRK_CD_IRK_CD_2JI    ,
                CD_3JI               ,
                JIS_JUSHO_CD_KEN     ,
                JIS_JUSHO_CD_SHIKU   ,
                FILLER               ,
                MOD_YMD_SY           ,
                MOD_YMD_M            ,
                MOD_YMD_D            ,
                TENSO_Y              ,
                TENSO_M              ,
                TENSO_D              ,
                MENTE_Y              ,
                MENTE_M              ,
                MENTE_D              ,
                MOD_KBN              ,
                TRK_OPE_CD           ,
                TRK_DATE             ,
                TRK_PGM_ID           ,
                UPD_OPE_CD           ,
                UPD_DATE             ,    
                UPD_PGM_ID)  
            VALUES(
                '3',
                DECODE(iShimeKind,'1','11',NULL),
                NVL2(johoForIrk3Row.IRK_2JI_CD,SUBSTR(johoForIrk3Row.IRK_2JI_CD,1,2),NULL),
                NVL2(johoForIrk3Row.IRK_2JI_CD,SUBSTR(johoForIrk3Row.IRK_2JI_CD,3,2),NULL),
                johoForIrk3Row.IRK_3JI_CD,
                johoForIrk3Row.KEN_CD,
                johoForIrk3Row.SHIKU_CD,
                NULL,
                NVL2(johoForIrk3Row.MOD_YMD,SUBSTR(johoForIrk3Row.MOD_YMD,1,4),NULL),
                NVL2(johoForIrk3Row.MOD_YMD,SUBSTR(johoForIrk3Row.MOD_YMD,5,2),NULL),
                NVL2(johoForIrk3Row.MOD_YMD,SUBSTR(johoForIrk3Row.MOD_YMD,7,2),NULL),                 
                DECODE(iShimeKind,'1',SUBSTR(iTensoYMD,1,4),NULL),
                DECODE(iShimeKind,'1',SUBSTR(iTensoYMD,5,2),NULL),
                DECODE(iShimeKind,'1',SUBSTR(iTensoYMD,7,2),NULL),
                DECODE(iShimeKind,'1',SUBSTR(johoForIrk3Row.UPD_EIGY_YMD,1,4),NULL),
                DECODE(iShimeKind,'1',SUBSTR(johoForIrk3Row.UPD_EIGY_YMD,5,2),NULL),
                DECODE(iShimeKind,'1',SUBSTR(johoForIrk3Row.UPD_EIGY_YMD,7,2),NULL),                
                NULL,                                         
                iOPE_CD,
                iDATE,
                iPGM_ID,
                iOPE_CD,
                iDATE,
                iPGM_ID
            );         

         
         
         
         EXECUTE_SQL := 'INSERT INTO TD_PA_IRK_KBN3(         
                FILE_KBN             ,
                REC_ID               ,
                IRK_CD_KEN_CD_2JI    ,
                IRK_CD_IRK_CD_2JI    ,
                CD_3JI               ,
                JIS_JUSHO_CD_KEN     ,
                JIS_JUSHO_CD_SHIKU   ,
                FILLER               ,
                MOD_YMD_SY           ,
                MOD_YMD_M            ,
                MOD_YMD_D            ,
                TENSO_Y              ,
                TENSO_M              ,
                TENSO_D              ,
                MENTE_Y              ,
                MENTE_M              ,
                MENTE_D              ,
                MOD_KBN              ,
                TRK_OPE_CD           ,
                TRK_DATE             ,
                TRK_PGM_ID           ,
                UPD_OPE_CD           ,
                UPD_DATE             ,    
                UPD_PGM_ID)  
            VALUES(
                ''3'',
                DECODE( '|| iShimeKind ||' ,''1'',''11'',NULL),
                NVL2( '|| johoForIrk3Row.IRK_2JI_CD ||' ,SUBSTR( '|| johoForIrk3Row.IRK_2JI_CD ||' ,1,2),NULL),
                NVL2( '|| johoForIrk3Row.IRK_2JI_CD ||' ,SUBSTR( '|| johoForIrk3Row.IRK_2JI_CD ||' ,3,2),NULL),
                '|| johoForIrk3Row.IRK_3JI_CD ||' ,
                '|| johoForIrk3Row.KEN_CD ||' ,
                '|| johoForIrk3Row.SHIKU_CD ||' ,
                NULL,
                NVL2( '|| johoForIrk3Row.MOD_YMD ||' ,SUBSTR( '|| johoForIrk3Row.MOD_YMD ||' ,1,4),NULL),
                NVL2( '|| johoForIrk3Row.MOD_YMD ||' ,SUBSTR( '|| johoForIrk3Row.MOD_YMD ||' ,5,2),NULL),
                NVL2( '|| johoForIrk3Row.MOD_YMD ||' ,SUBSTR( '|| johoForIrk3Row.MOD_YMD ||' ,7,2),NULL),                 
                DECODE( '|| iShimeKind ||' ,''1'',SUBSTR( '|| iTensoYMD ||' ,1,4),NULL),
                DECODE( '|| iShimeKind ||' ,''1'',SUBSTR( '|| iTensoYMD ||' ,5,2),NULL),
                DECODE( '|| iShimeKind ||' ,''1'',SUBSTR( '|| iTensoYMD ||' ,7,2),NULL),
                DECODE( '|| iShimeKind ||' ,''1'',SUBSTR( '|| johoForIrk3Row.UPD_EIGY_YMD ||' ,1,4),NULL),
                DECODE( '|| iShimeKind ||' ,''1'',SUBSTR( '|| johoForIrk3Row.UPD_EIGY_YMD ||' ,5,2),NULL),
                DECODE( '|| iShimeKind ||' ,''1'',SUBSTR( '|| johoForIrk3Row.UPD_EIGY_YMD ||' ,7,2),NULL),                
                NULL,'||                                          
                iOPE_CD ||' , '||
                iDATE ||' , '||
                iPGM_ID ||' , '||
                iOPE_CD ||' , '||
                iDATE ||' , '||
                iPGM_ID ||') ';         
         ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);




             
         END LOOP;
         CLOSE johoForIrk3CSR;            
         
      END IF; 

  COMMIT;

  oROW_COUNT := -1;

  -- �I�����O�o��
  ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'PL/SQL End',PGM_ID || '�̏������I�����܂����B',iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

  return 0;
  -- ��O����
  EXCEPTION
    -- ���̑��G���[
    WHEN OTHERS THEN
      W_ERR_INF_RCD.ERR_CD     := TO_CHAR(SQLCODE);
      W_ERR_INF_RCD.ERR_MSG     := SUBSTR(SQLERRM, 0, 500);
      W_ERR_INF_RCD.ERR_KEY_INF   := SUBSTR('iLayoutKbn:' || iLayoutKbn || ', iShimeKind:' || iShimeKind , 0,500);
      W_INDEX_N           := W_ERR_INF_TBL.COUNT + 1;
      W_ERR_INF_TBL.EXTEND;
      W_ERR_INF_TBL(W_INDEX_N)   := W_ERR_INF_RCD;

      OPEN oOUT_ERR_INF_CSR FOR
        SELECT * FROM TABLE(W_ERR_INF_TBL);

        ROLLBACK;

      --�G���[���O�̓o�^
      ULT_INSERT_LOG_TABLE('ERROR',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'ERROR_INFO',W_ERR_INF_RCD.ERR_MSG,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);  

  return 1;
END;

END;
/
