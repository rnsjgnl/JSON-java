CREATE OR REPLACE PACKAGE NH010106B001_112
/* **********************************************************
 *  Copyright(c) 2011 beyond, INTEC Inc. All rights reserved.
 * **********************************************************/
AUTHID CURRENT_USER
IS
	/*** �J�[�\���^ ***************************************************************/
	-- �G���[���i�[�p�J�[�\���^
	TYPE ERR_INF_CSR		IS REF CURSOR;

  /*
  ************************************************************************
  *  �V_�S��_�ǉ��A�C�e��_�Տ����C�e�[�u���̍쐬
  *  CREATE_TSUIKAITEM_RNSKNS
  ************************************************************************
  */
  FUNCTION CREATE_TSUIKAITEM_RNSKNS(
  iShimeKind  IN  INTEGER,                    -- ���ߓ��敪
  iTensoYMD	IN	VARCHAR2,                     -- �]���N����
  iOPE_CD IN Varchar2,                      -- �I�y���[�^�R�[�h
  iPGM_ID IN Varchar2,                      -- �v���O����ID
  iDATE DATE,                               -- �V�X�e������
  iIP_ADDR  IN TL_STORED_SHORI.IP%TYPE,              -- ���s�[��IP�A�h���X (FW�Őݒ�)
  iWINDOWS_LOGIN_USER  IN TL_STORED_SHORI.WINDOWS_LOGIN_USER%TYPE, -- ���s�[��OS���[�U�[ (FW�Őݒ�)
  oROW_COUNT  OUT NUMBER,         -- �o�^����
  oOUT_ERR_INF_CSR   OUT ERR_INF_CSR    -- �G���[���J�[�\��
  ) RETURN NUMBER; 

END;
/
CREATE OR REPLACE PACKAGE BODY NH010106B001_112
/* **********************************************************
 *  Copyright(c) 2011 beyond, INTEC Inc. All rights reserved.
 * **********************************************************/
IS
  /*
   ************************************************************************
   * Function ID  : CREATE_TSUIKAITEM_RNSKNS
   * Program Name : �V_�S��_�ǉ��A�C�e��_�Տ����C�e�[�u���̍쐬
   * Parameter    :  <I> iShimeKind    �F���ߓ��敪
   *                 <I> iTensoYMD    �F�]���N����
   *                 <I> iOPE_CD    �F�I�y���[�^�R�[�h
   *                 <I> iPGM_ID    �F�v���O����ID
   *                 <I> iDATE    �F�V�X�e������ 
   *                 <I> iIP_ADDR    �F���s�[��IP�A�h���X
   *                 <I> iWINDOWS_LOGIN_USER  �F���s�[��IP�A�h���X
   *                <O> oROW_COUNT        �F�X�V����
   *                <O> oOUT_ERR_INF_CSR  �F�G���[���J�[�\��
   * Return       �F�������ʁi0:����I���A1:�ُ�I���j
   ************************************************************************
   */
  FUNCTION CREATE_TSUIKAITEM_RNSKNS(
  iShimeKind  IN  INTEGER,                    -- ���ߓ��敪
  iTensoYMD	IN	VARCHAR2,                     -- �]���N����
  iOPE_CD IN Varchar2,                      -- �I�y���[�^�R�[�h
  iPGM_ID IN Varchar2,                      -- �v���O����ID
  iDATE DATE,                               -- �V�X�e������  
  iIP_ADDR  IN TL_STORED_SHORI.IP%TYPE,              -- ���s�[��IP�A�h���X (FW�Őݒ�)
  iWINDOWS_LOGIN_USER  IN TL_STORED_SHORI.WINDOWS_LOGIN_USER%TYPE, -- ���s�[��OS���[�U�[ (FW�Őݒ�)
  oROW_COUNT  OUT NUMBER,         -- �o�^����
  oOUT_ERR_INF_CSR   OUT ERR_INF_CSR    -- �G���[���J�[�\��
  )RETURN NUMBER IS
PRAGMA AUTONOMOUS_TRANSACTION;

  /************************************************************************/
  /*                              �G���[����                              */
  /************************************************************************/
  W_INDEX_N           NUMBER(10) := 0;
  W_ERR_INF_TBL         TYPE_ERR_INFO_TBL := TYPE_ERR_INFO_TBL();
  W_ERR_INF_RCD         TYPE_ERR_INFO_RCD := TYPE_ERR_INFO_RCD(NULL,NULL,NULL,NULL);
  vSQL VARCHAR2(200);
  vSchemaNm           TM_JOSU.HANYO_KOMOKU%TYPE := NULL; -- �X�L�[�}����
	PGM_ID        VARCHAR2(50) := 'NH010106B001_112.CREATE_TSUIKAITEM_RNSKNS';
	EXECUTE_SQL   VARCHAR2(32767) := NULL;  
 
  BEGIN

	-- �J�n���O�o��
        ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'PL/SQL Start',PGM_ID || '�̏������J�n���܂��B',iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

    -- �����D���ߋ敪��"1"(������)��
    IF iShimeKind = ULT_COMMON.SHIME_SBT_CD_HISHIME THEN

          -- �[�i�p�X�L�[�}�̎擾���s���B
          vSchemaNm := ULT_COMMON.GET_SCHEMA_NAME(ULT_COMMON.SYS_ENV_JOSU_DAI_CD, ULT_COMMON.NOHIN_SHEMA_JOSU_SHO_CD);

          --�V_�S��_�ǉ��A�C�e��_�Տ����C�e�[�u���̃f�[�^���N���A����
		EXECUTE_SQL := 'TRUNCATE TABLE ' || vSchemaNm || '.' || 'TD_NA_TSUIKAITEM_RNSKNS';
		EXECUTE IMMEDIATE EXECUTE_SQL;
		ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);
             
                
                INSERT INTO TD_NA_TSUIKAITEM_RNSKNS(
                    LAYOUT_KBN                     ,
                    DCF_CD_REC_ID                  ,
                    DCF_CD_SHI_CD                  ,
                    DCF_CD_YOBI                    ,
                    MOD_KBN                        ,
                    KYRYK_CD_REC_ID                ,
                    KYRYK_CD_SHI_CD                ,
                    KYRYK_CD_YOBI                  ,
                    S_NENDO                        ,
                    YOBI_1                         ,
                    MENTE_YMD                      ,
                    YOBI_2                         ,
                    SORTKEY                        ,
                    TSUIKA_DEL_KBN                 ,
                    TENSO_YMD                      ,
                    TRK_OPE_CD                     ,
                    TRK_DATE                       ,
                    TRK_PGM_ID                     ,
                    UPD_OPE_CD                     ,
                    UPD_DATE                       ,
                    UPD_PGM_ID)  
			      SELECT										
                    '112',
			        TTTR.REC_ID,									
			        TTTR.SHI_CD,									
                    NULL,
                    NULL,
			        TTTR.KYRYK_REC_ID,									
			        TTTR.KYRYK_SHI_CD,									
                    NULL,  
			        TTTR.S_NENDO,									
                    NULL,  
			        TTT.UPD_EIGY_YMD,									
                    NULL,  
			        TTTR.SORTKEY_NOHIN,									
                    NULL,              
                    iTensoYMD,
                    iOPE_CD,
                    iDATE,
                    iPGM_ID,
                    iOPE_CD,
                    iDATE,
                    iPGM_ID
			      FROM TT_TIKY_SHI TTS											
			              LEFT OUTER JOIN TT_EIGY_YMD_KANRI TEYK ON 1 = 1												
			              INNER JOIN TT_TIKY_TSUIKAITEM TTT	ON TTS.REC_ID = TTT.REC_ID AND TTS.SHI_CD = TTT.SHI_CD												
			              INNER JOIN TT_TIKY_TSUIKAITEM_RNSKNS TTTR	ON TTS.REC_ID = TTTR.REC_ID AND TTS.SHI_CD = TTTR.SHI_CD														
			    	WHERE�@TTS�DREC_ID�@= '00'																						
				       AND�@TTS�DDEL_FLG IS NULL																							
				       AND�@TTT�DDEL_FLG IS NULL																							
				       AND�@TEYK�DPK = '1'																																								
					   AND�@TTTR�DS_NENDO BETWEEN TEYK�DEIGY_NENDO - 1 AND TEYK�DEIGY_NENDO + 1;	

	--
	EXECUTE_SQL :=   'INSERT INTO TD_NA_TSUIKAITEM_RNSKNS('||
                    'LAYOUT_KBN                     ,'||
                    'DCF_CD_REC_ID                  ,'||
                    'DCF_CD_SHI_CD                  ,'||
                    'DCF_CD_YOBI                    ,'||
                    'MOD_KBN                        ,'||
                    'KYRYK_CD_REC_ID                ,'||
                    'KYRYK_CD_SHI_CD                ,'||
                    'KYRYK_CD_YOBI                  ,'||
                    'S_NENDO                        ,'||
                    'YOBI_1                         ,'||
                    'MENTE_YMD                      ,'||
                    'YOBI_2                         ,'||
                    'SORTKEY                        ,'||
                    'TSUIKA_DEL_KBN                 ,'||
                    'TENSO_YMD                      ,'||
                    'TRK_OPE_CD                     ,'||
                    'TRK_DATE                       ,'||
                    'TRK_PGM_ID                     ,'||
                    'UPD_OPE_CD                     ,'||
                    'UPD_DATE                       ,'||
                    'UPD_PGM_ID)  '||
			      'SELECT				'||						
                    '''112'','||
			        'TTTR.REC_ID,'||									
			        'TTTR.SHI_CD,'||									
                    'NULL,'||
                    'NULL,'||
			        'TTTR.KYRYK_REC_ID,'||									
			        'TTTR.KYRYK_SHI_CD,'||									
                    'NULL,'||  
			        'TTTR.S_NENDO,'||									
                    'NULL,'||  
			        'TTT.UPD_EIGY_YMD,'||									
                    'NULL,'||  
			        'TTTR.SORTKEY_NOHIN,'||									
                    'NULL,'||              
                    'iTensoYMD,'||
                    'iOPE_CD,'||
                    'iDATE,'||
                    'iPGM_ID,'||
                    'iOPE_CD,'||
                    'iDATE,'||
                    'iPGM_ID'||
			      'FROM TT_TIKY_SHI TTS'||											
			              'LEFT OUTER JOIN TT_EIGY_YMD_KANRI TEYK ON 1 = 1'||												
			              'INNER JOIN TT_TIKY_TSUIKAITEM TTT	ON TTS.REC_ID = TTT.REC_ID AND TTS.SHI_CD = TTT.SHI_CD'||												
			              'INNER JOIN TT_TIKY_TSUIKAITEM_RNSKNS TTTR	ON TTS.REC_ID = TTTR.REC_ID AND TTS.SHI_CD = TTTR.SHI_CD'||														
			    	'WHERE�@TTS�DREC_ID�@= ''00'''||																						
				       'AND�@TTS�DDEL_FLG IS NULL'||																							
				       'AND�@TTT�DDEL_FLG IS NULL'||
				       'AND�@TEYK�DPK = ''1'''||																																								
					   'AND�@TTTR�DS_NENDO BETWEEN TEYK�DEIGY_NENDO - 1 AND TEYK�DEIGY_NENDO + 1';	


	ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

    END IF;
    COMMIT;
      -- �I�����O�o��
   	 ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'PL/SQL End',PGM_ID || '�̏������I�����܂����B',iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

  oROW_COUNT := -1;
    return 0;
    -- ��O����
  EXCEPTION
    -- ���̑��G���[
    WHEN OTHERS THEN
      W_ERR_INF_RCD.ERR_CD     := TO_CHAR(SQLCODE);
      W_ERR_INF_RCD.ERR_MSG     := SUBSTR(SQLERRM, 0, 500);
      W_ERR_INF_RCD.ERR_KEY_INF   := SUBSTR('iShimeKind:' || iShimeKind , 0,500);
      W_INDEX_N           := W_ERR_INF_TBL.COUNT + 1;
      W_ERR_INF_TBL.EXTEND;
      W_ERR_INF_TBL(W_INDEX_N)   := W_ERR_INF_RCD;

      OPEN oOUT_ERR_INF_CSR FOR
        SELECT * FROM TABLE(W_ERR_INF_TBL);

        ROLLBACK;
        
	  --�G���[���O�̓o�^
        ULT_INSERT_LOG_TABLE('ERROR',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'ERROR_INFO',W_ERR_INF_RCD.ERR_MSG,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

  return 1;
END;

END;
/
