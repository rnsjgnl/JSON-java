CREATE OR REPLACE PACKAGE NH010106B001_401
/* **********************************************************
 *  Copyright(c) 2011 beyond, INTEC Inc. All rights reserved.
 * **********************************************************/
AUTHID CURRENT_USER
IS
	/*** �J�[�\���^ ***************************************************************/
	-- �G���[���i�[�p�J�[�\���^
	TYPE ERR_INF_CSR		IS REF CURSOR;

  /*
  ************************************************************************
  *  �b��_�S��_DCF�{�ݐV���ڃe�[�u���̍쐬
  *  CREATE_DCF_SHISETSU_SHIN
  ************************************************************************
  */
  FUNCTION CREATE_DCF_SHISETSU_SHIN(
  iLayoutKbn  IN  INTEGER,                    -- ���C�A�E�g�敪
  iShimeKind  IN  INTEGER,                    -- ���ߓ��敪
  iOPE_CD IN Varchar2,                      -- �I�y���[�^�R�[�h
  iPGM_ID IN Varchar2,                      -- �v���O����ID
  iDATE DATE,                               -- �V�X�e������
  iIP_ADDR  IN TL_STORED_SHORI.IP%TYPE,              -- ���s�[��IP�A�h���X (FW�Őݒ�)
  iWINDOWS_LOGIN_USER  IN TL_STORED_SHORI.WINDOWS_LOGIN_USER%TYPE, -- ���s�[��OS���[�U�[ (FW�Őݒ�)
  oROW_COUNT  OUT NUMBER,         -- �o�^����
  oOUT_ERR_INF_CSR   OUT ERR_INF_CSR    -- �G���[���J�[�\��
  ) RETURN NUMBER; 

END;
/
CREATE OR REPLACE PACKAGE BODY NH010106B001_401
/* **********************************************************
 *  Copyright(c) 2011 beyond, INTEC Inc. All rights reserved.
 * **********************************************************/
IS
  /*
   ************************************************************************
   * Function ID  : CREATE_DCF_SHISETSU_SHIN
   * Program Name : �b��_�S��_DCF�{�ݐV���ڃe�[�u���̍쐬
   * Parameter    :  <I> iLayoutKbn    �F���C�A�E�g�敪
   *                 <I> iShimeKind    �F���ߓ��敪
   *                 <I> iOPE_CD    �F�I�y���[�^�R�[�h
   *                 <I> iPGM_ID    �F�v���O����ID
   *                 <I> iDATE    �F�V�X�e������ 
   *                 <I> iIP_ADDR    �F���s�[��IP�A�h���X
   *                 <I> iWINDOWS_LOGIN_USER  �F���s�[��IP�A�h���X
   *                <O> oROW_COUNT        �F�X�V����
   *                <O> oOUT_ERR_INF_CSR  �F�G���[���J�[�\��
   * Return       �F�������ʁi0:����I���A1:�ُ�I���j
   ************************************************************************
   */
  FUNCTION CREATE_DCF_SHISETSU_SHIN(
  iLayoutKbn  IN  INTEGER,                    -- ���C�A�E�g�敪
  iShimeKind  IN  INTEGER,                    -- ���ߓ��敪
  iOPE_CD IN Varchar2,                      -- �I�y���[�^�R�[�h
  iPGM_ID IN Varchar2,                      -- �v���O����ID
  iDATE DATE,                               -- �V�X�e������  
  iIP_ADDR  IN TL_STORED_SHORI.IP%TYPE,              -- ���s�[��IP�A�h���X (FW�Őݒ�)
  iWINDOWS_LOGIN_USER  IN TL_STORED_SHORI.WINDOWS_LOGIN_USER%TYPE, -- ���s�[��OS���[�U�[ (FW�Őݒ�)
  oROW_COUNT  OUT NUMBER,         -- �o�^����
  oOUT_ERR_INF_CSR   OUT ERR_INF_CSR    -- �G���[���J�[�\��
  )RETURN NUMBER IS
PRAGMA AUTONOMOUS_TRANSACTION;
  /************************************************************************/
  /*                              �G���[����                              */
  /************************************************************************/
  W_INDEX_N           NUMBER(10) := 0;
  W_ERR_INF_TBL         TYPE_ERR_INFO_TBL := TYPE_ERR_INFO_TBL();
  W_ERR_INF_RCD         TYPE_ERR_INFO_RCD := TYPE_ERR_INFO_RCD(NULL,NULL,NULL,NULL);
  vSchemaNm     TM_JOSU.HANYO_KOMOKU%TYPE := NULL; -- �X�L�[�}����
  PGM_ID        VARCHAR2(50) := 'NH010106B001_401.CREATE_DCF_SHISETSU_SHIN';
  EXECUTE_SQL   VARCHAR2(32767) := NULL;
 
  BEGIN
  	  
  	  -- �J�n���O�o��
      ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'PL/SQL Start',PGM_ID || '�̏������J�n���܂��B',iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);
    
      IF iLayoutKbn = ULT_COMMON.LAYOUT_SBT_CD_ZANTEI THEN
          -- �b�背�C�A�E�g
        
        IF iShimeKind = ULT_COMMON.SHIME_SBT_CD_NAKASHIME OR iShimeKind = ULT_COMMON.SHIME_SBT_CD_MATSUSHIME THEN

          -- �[�i�p�X�L�[�}�̎擾���s���B
          vSchemaNm := ULT_COMMON.GET_SCHEMA_NAME(ULT_COMMON.SYS_ENV_JOSU_DAI_CD, ULT_COMMON.NOHIN_SHEMA_JOSU_SHO_CD);

          --�b��_�S��_DCF�{�ݐV���ڃe�[�u���̃f�[�^���N���A����B         
           EXECUTE_SQL := 'TRUNCATE TABLE ' || vSchemaNm || '.' || 'TD_PA_DCF_SHI_SHIN';
           EXECUTE IMMEDIATE EXECUTE_SQL;
           ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);
                       
            -- �b��_�S��_DCF�{�ݐV���ڃe�[�u���̃f�[�^��o�^����
            INSERT INTO TD_PA_DCF_SHI_SHIN(
						                SHIREC_ID,
						                SHI_CD,
						                SHI_CD_YOBI,
						                SHIN_SEISHIKI_SHI_NM,
						                SHIN_SEISHIKI_SHI_NM_KANA,
						                JUSHO_COUNT_KANJI_KEN,
						                JUSHO_COUNT_KANJI_SHIKU,
						                JUSHO_COUNT_KANJI_OAZA,
						                JUSHO_COUNT_KANJI_AZA,
						                JUSHO_COUNT_KANA_KEN,
						                JUSHO_COUNT_KANA_SHIKU,
						                JUSHO_COUNT_KANA_OAZA,
						                JUSHO_COUNT_KANA_AZA,
						                KEIEITAI_CD,
						                SNRYKMK_1,
						                SNRYKMK_2,
						                SNRYKMK_3,
						                SNRYKMK_4,
						                SNRYKMK_5,
						                SNRYKMK_6,
						                SNRYKMK_7,
						                SNRYKMK_8,
						                SNRYKMK_9,
						                SNRYKMK_10,
						                SNRYKMK_11,
						                SNRYKMK_12,
						                SNRYKMK_13,
						                SNRYKMK_14,
						                SNRYKMK_15,
						                SNRYKMK_16,
						                SNRYKMK_17,
						                SNRYKMK_18,
						                SNRYKMK_19,
						                SNRYKMK_20,
						                SNRYKMK_21,
						                SNRYKMK_22,
						                SNRYKMK_23,
						                SNRYKMK_24,
						                SNRYKMK_25,
						                SNRYKMK_26,
						                SNRYKMK_27,
						                SNRYKMK_28,
						                SNRYKMK_29,
						                SNRYKMK_30,
						                SNRYKMK_31,
						                SNRYKMK_32,
						                SNRYKMK_33,
						                SNRYKMK_34,
						                SNRYKMK_35,
						                SNRYKMK_36,
						                SNRYKMK_37,
						                SNRYKMK_38,
						                SNRYKMK_39,
						                SNRYKMK_40,
						                SNRYKMK_41,
						                SNRYKMK_42,
						                SNRYKMK_43,
						                SNRYKMK_44,
						                SNRYKMK_45,
						                SNRYKMK_46,
						                SNRYKMK_47,
						                SNRYKMK_48,
						                SNRYKMK_49,
						                SNRYKMK_50,
						                SNRYKMK_51,
						                SNRYKMK_52,
						                SNRYKMK_53,
						                SNRYKMK_54,
						                SNRYKMK_55,
						                SNRYKMK_56,
						                SNRYKMK_57,
						                SNRYKMK_58,
						                SNRYKMK_59,
						                SNRYKMK_60,
						                TEL_NASHI_FLG,
						                TRK_OPE_CD,
						                TRK_DATE,
						                TRK_PGM_ID,
						                UPD_OPE_CD,
						                UPD_DATE,
						                UPD_PGM_ID)  
					            SELECT
					                TTS.REC_ID,
					                TTS.SHI_CD,
					                NULL,
					                TTS.SEISHIKI_SHI_NM,
					                TTS.SEISHIKI_SHI_NM_KANA,
					                --TTS.KEN_NM_KANJI_MOJI_SU,
					                --TTS.SHIKU_NM_KANJI_MOJI_SU,
					                --TTS.OAZA_NM_KANJI_MOJI_SU,
					                --TTS.AZA_NM_KANJI_MOJI_SU,
					                --TTS.KEN_NM_KANA_MOJI_SU,
					                --TTS.SHIKU_NM_KANA_MOJI_SU,
					                --TTS.OAZA_NM_KANA_MOJI_SU,
					                --TTS.AZA_NM_KANA_MOJI_SU,             
					                TO_CHAR(TTS.KEN_NM_KANJI_MOJI_SU,'FM09') AS KEN_NM_KANJI_MOJI_SU,
					                TO_CHAR(TTS.SHIKU_NM_KANJI_MOJI_SU,'FM09') AS SHIKU_NM_KANJI_MOJI_SU,
					                TO_CHAR(TTS.OAZA_NM_KANJI_MOJI_SU,'FM09') AS OAZA_NM_KANJI_MOJI_SU,
					                TO_CHAR(TTS.AZA_NM_KANJI_MOJI_SU,'FM09') AS AZA_NM_KANJI_MOJI_SU,
					                TO_CHAR(TTS.KEN_NM_KANA_MOJI_SU,'FM09') AS KEN_NM_KANA_MOJI_SU,
					                TO_CHAR(TTS.SHIKU_NM_KANA_MOJI_SU,'FM09') AS SHIKU_NM_KANA_MOJI_SU,
					                TO_CHAR(TTS.OAZA_NM_KANA_MOJI_SU,'FM09') AS OAZA_NM_KANA_MOJI_SU,
					                TO_CHAR(TTS.AZA_NM_KANA_MOJI_SU,'FM09') AS AZA_NM_KANA_MOJI_SU,
					                TTS.KEIEITAI_CD,
					                TTS.SNRYKMK_CD_01,
					                TTS.SNRYKMK_CD_02,
					                TTS.SNRYKMK_CD_03,
					                TTS.SNRYKMK_CD_04,
					                TTS.SNRYKMK_CD_05,
					                TTS.SNRYKMK_CD_06,
					                TTS.SNRYKMK_CD_07,
					                TTS.SNRYKMK_CD_08,
					                TTS.SNRYKMK_CD_09,
					                TTS.SNRYKMK_CD_10,
					                TTS.SNRYKMK_CD_11,
					                TTS.SNRYKMK_CD_12,
					                TTS.SNRYKMK_CD_13,
					                TTS.SNRYKMK_CD_14,
					                TTS.SNRYKMK_CD_15,
					                TTS.SNRYKMK_CD_16,
					                TTS.SNRYKMK_CD_17,
					                TTS.SNRYKMK_CD_18,
					                TTS.SNRYKMK_CD_19,
					                TTS.SNRYKMK_CD_20,
					                TTS.SNRYKMK_CD_21,
					                TTS.SNRYKMK_CD_22,
					                TTS.SNRYKMK_CD_23,
					                TTS.SNRYKMK_CD_24,
					                TTS.SNRYKMK_CD_25,
					                TTS.SNRYKMK_CD_26,
					                TTS.SNRYKMK_CD_27,
					                TTS.SNRYKMK_CD_28,
					                TTS.SNRYKMK_CD_29,
					                TTS.SNRYKMK_CD_30,
					                TTS.SNRYKMK_CD_31,
					                TTS.SNRYKMK_CD_32,
					                TTS.SNRYKMK_CD_33,
					                TTS.SNRYKMK_CD_34,
					                TTS.SNRYKMK_CD_35,
					                TTS.SNRYKMK_CD_36,
					                TTS.SNRYKMK_CD_37,
					                TTS.SNRYKMK_CD_38,
					                TTS.SNRYKMK_CD_39,
					                TTS.SNRYKMK_CD_40,
					                TTS.SNRYKMK_CD_41,
					                TTS.SNRYKMK_CD_42,
					                TTS.SNRYKMK_CD_43,
					                TTS.SNRYKMK_CD_44,
					                TTS.SNRYKMK_CD_45,
					                TTS.SNRYKMK_CD_46,
					                TTS.SNRYKMK_CD_47,
					                TTS.SNRYKMK_CD_48,
					                TTS.SNRYKMK_CD_49,
					                TTS.SNRYKMK_CD_50,
					                TTS.SNRYKMK_CD_51,
					                TTS.SNRYKMK_CD_52,
					                TTS.SNRYKMK_CD_53,
					                TTS.SNRYKMK_CD_54,
					                TTS.SNRYKMK_CD_55,
					                TTS.SNRYKMK_CD_56,
					                TTS.SNRYKMK_CD_57,
					                TTS.SNRYKMK_CD_58,
					                TTS.SNRYKMK_CD_59,
					                TTS.SNRYKMK_CD_60,
					                TTS.TEL_NASHI_FLG,
					                iOPE_CD,
					                iDATE,
					                iPGM_ID,
					                iOPE_CD,
					                iDATE,
					                iPGM_ID
					             FROM TT_TIKY_SHI TTS                                                                                    
								 WHERE TTS.REC_ID = '00'                                   
								 AND TTS.DEL_FLG IS NULL ;
		   -- ���O��o�^����
		   EXECUTE_SQL := '  INSERT INTO TD_PA_DCF_SHI_SHIN(                               ' ||
							'  		                SHIREC_ID,                               ' ||
							'  		                SHI_CD,                                  ' ||
							'  		                SHI_CD_YOBI,                             ' ||
							'  		                SHIN_SEISHIKI_SHI_NM,                    ' ||
							'  		                SHIN_SEISHIKI_SHI_NM_KANA,               ' ||
							'  		                JUSHO_COUNT_KANJI_KEN,                   ' ||
							'  		                JUSHO_COUNT_KANJI_SHIKU,                 ' ||
							'  		                JUSHO_COUNT_KANJI_OAZA,                  ' ||
							'  		                JUSHO_COUNT_KANJI_AZA,                   ' ||
							'  		                JUSHO_COUNT_KANA_KEN,                    ' ||
							'  		                JUSHO_COUNT_KANA_SHIKU,                  ' ||
							'  		                JUSHO_COUNT_KANA_OAZA,                   ' ||
							'  		                JUSHO_COUNT_KANA_AZA,                    ' ||
							'  		                KEIEITAI_CD,                             ' ||
							'  		                SNRYKMK_1,                               ' ||
							'  		                SNRYKMK_2,                               ' ||
							'  		                SNRYKMK_3,                               ' ||
							'  		                SNRYKMK_4,                               ' ||
							'  		                SNRYKMK_5,                               ' ||
							'  		                SNRYKMK_6,                               ' ||
							'  		                SNRYKMK_7,                               ' ||
							'  		                SNRYKMK_8,                               ' ||
							'  		                SNRYKMK_9,                               ' ||
							'  		                SNRYKMK_10,                              ' ||
							'  		                SNRYKMK_11,                              ' ||
							'  		                SNRYKMK_12,                              ' ||
							'  		                SNRYKMK_13,                              ' ||
							'  		                SNRYKMK_14,                              ' ||
							'  		                SNRYKMK_15,                              ' ||
							'  		                SNRYKMK_16,                              ' ||
							'  		                SNRYKMK_17,                              ' ||
							'  		                SNRYKMK_18,                              ' ||
							'  		                SNRYKMK_19,                              ' ||
							'  		                SNRYKMK_20,                              ' ||
							'  		                SNRYKMK_21,                              ' ||
							'  		                SNRYKMK_22,                              ' ||
							'  		                SNRYKMK_23,                              ' ||
							'  		                SNRYKMK_24,                              ' ||
							'  		                SNRYKMK_25,                              ' ||
							'  		                SNRYKMK_26,                              ' ||
							'  		                SNRYKMK_27,                              ' ||
							'  		                SNRYKMK_28,                              ' ||
							'  		                SNRYKMK_29,                              ' ||
							'  		                SNRYKMK_30,                              ' ||
							'  		                SNRYKMK_31,                              ' ||
							'  		                SNRYKMK_32,                              ' ||
							'  		                SNRYKMK_33,                              ' ||
							'  		                SNRYKMK_34,                              ' ||
							'  		                SNRYKMK_35,                              ' ||
							'  		                SNRYKMK_36,                              ' ||
							'  		                SNRYKMK_37,                              ' ||
							'  		                SNRYKMK_38,                              ' ||
							'  		                SNRYKMK_39,                              ' ||
							'  		                SNRYKMK_40,                              ' ||
							'  		                SNRYKMK_41,                              ' ||
							'  		                SNRYKMK_42,                              ' ||
							'  		                SNRYKMK_43,                              ' ||
							'  		                SNRYKMK_44,                              ' ||
							'  		                SNRYKMK_45,                              ' ||
							'  		                SNRYKMK_46,                              ' ||
							'  		                SNRYKMK_47,                              ' ||
							'  		                SNRYKMK_48,                              ' ||
							'  		                SNRYKMK_49,                              ' ||
							'  		                SNRYKMK_50,                              ' ||
							'  		                SNRYKMK_51,                              ' ||
							'  		                SNRYKMK_52,                              ' ||
							'  		                SNRYKMK_53,                              ' ||
							'  		                SNRYKMK_54,                              ' ||
							'  		                SNRYKMK_55,                              ' ||
							'  		                SNRYKMK_56,                              ' ||
							'  		                SNRYKMK_57,                              ' ||
							'  		                SNRYKMK_58,                              ' ||
							'  		                SNRYKMK_59,                              ' ||
							'  		                SNRYKMK_60,                              ' ||
							'  		                TEL_NASHI_FLG,                           ' ||
							'  		                TRK_OPE_CD,                              ' ||
							'  		                TRK_DATE,                                ' ||
							'  		                TRK_PGM_ID,                              ' ||
							'  		                UPD_OPE_CD,                              ' ||
							'  		                UPD_DATE,                                ' ||
							'  		                UPD_PGM_ID)                              ' ||
							'  	            SELECT                                           ' ||
							'  	                TTS.REC_ID,                                  ' ||
							'  	                TTS.SHI_CD,                                  ' ||
							'  	                NULL,                                        ' ||
							'  	                TTS.SEISHIKI_SHI_NM,                         ' ||
							'  	                TTS.SEISHIKI_SHI_NM_KANA,                    ' ||
							'  	                TTS.KEN_NM_KANJI_MOJI_SU,                    ' ||
							'  	                TTS.SHIKU_NM_KANJI_MOJI_SU,                  ' ||
							'  	                TTS.OAZA_NM_KANJI_MOJI_SU,                   ' ||
							'  	                TTS.AZA_NM_KANJI_MOJI_SU,                    ' ||
							'  	                TTS.KEN_NM_KANA_MOJI_SU,                     ' ||
							'  	                TTS.SHIKU_NM_KANA_MOJI_SU,                   ' ||
							'  	                TTS.OAZA_NM_KANA_MOJI_SU,                    ' ||
							'  	                TTS.AZA_NM_KANA_MOJI_SU,                     ' ||
							'  	                TTS.KEIEITAI_CD,                             ' ||
							'  	                TTS.SNRYKMK_CD_01,                           ' ||
							'  	                TTS.SNRYKMK_CD_02,                           ' ||
							'  	                TTS.SNRYKMK_CD_03,                           ' ||
							'  	                TTS.SNRYKMK_CD_04,                           ' ||
							'  	                TTS.SNRYKMK_CD_05,                           ' ||
							'  	                TTS.SNRYKMK_CD_06,                           ' ||
							'  	                TTS.SNRYKMK_CD_07,                           ' ||
							'  	                TTS.SNRYKMK_CD_08,                           ' ||
							'  	                TTS.SNRYKMK_CD_09,                           ' ||
							'  	                TTS.SNRYKMK_CD_10,                           ' ||
							'  	                TTS.SNRYKMK_CD_11,                           ' ||
							'  	                TTS.SNRYKMK_CD_12,                           ' ||
							'  	                TTS.SNRYKMK_CD_13,                           ' ||
							'  	                TTS.SNRYKMK_CD_14,                           ' ||
							'  	                TTS.SNRYKMK_CD_15,                           ' ||
							'  	                TTS.SNRYKMK_CD_16,                           ' ||
							'  	                TTS.SNRYKMK_CD_17,                           ' ||
							'  	                TTS.SNRYKMK_CD_18,                           ' ||
							'  	                TTS.SNRYKMK_CD_19,                           ' ||
							'  	                TTS.SNRYKMK_CD_20,                           ' ||
							'  	                TTS.SNRYKMK_CD_21,                           ' ||
							'  	                TTS.SNRYKMK_CD_22,                           ' ||
							'  	                TTS.SNRYKMK_CD_23,                           ' ||
							'  	                TTS.SNRYKMK_CD_24,                           ' ||
							'  	                TTS.SNRYKMK_CD_25,                           ' ||
							'  	                TTS.SNRYKMK_CD_26,                           ' ||
							'  	                TTS.SNRYKMK_CD_27,                           ' ||
							'  	                TTS.SNRYKMK_CD_28,                           ' ||
							'  	                TTS.SNRYKMK_CD_29,                           ' ||
							'  	                TTS.SNRYKMK_CD_30,                           ' ||
							'  	                TTS.SNRYKMK_CD_31,                           ' ||
							'  	                TTS.SNRYKMK_CD_32,                           ' ||
							'  	                TTS.SNRYKMK_CD_33,                           ' ||
							'  	                TTS.SNRYKMK_CD_34,                           ' ||
							'  	                TTS.SNRYKMK_CD_35,                           ' ||
							'  	                TTS.SNRYKMK_CD_36,                           ' ||
							'  	                TTS.SNRYKMK_CD_37,                           ' ||
							'  	                TTS.SNRYKMK_CD_38,                           ' ||
							'  	                TTS.SNRYKMK_CD_39,                           ' ||
							'  	                TTS.SNRYKMK_CD_40,                           ' ||
							'  	                TTS.SNRYKMK_CD_41,                           ' ||
							'  	                TTS.SNRYKMK_CD_42,                           ' ||
							'  	                TTS.SNRYKMK_CD_43,                           ' ||
							'  	                TTS.SNRYKMK_CD_44,                           ' ||
							'  	                TTS.SNRYKMK_CD_45,                           ' ||
							'  	                TTS.SNRYKMK_CD_46,                           ' ||
							'  	                TTS.SNRYKMK_CD_47,                           ' ||
							'  	                TTS.SNRYKMK_CD_48,                           ' ||
							'  	                TTS.SNRYKMK_CD_49,                           ' ||
							'  	                TTS.SNRYKMK_CD_50,                           ' ||
							'  	                TTS.SNRYKMK_CD_51,                           ' ||
							'  	                TTS.SNRYKMK_CD_52,                           ' ||
							'  	                TTS.SNRYKMK_CD_53,                           ' ||
							'  	                TTS.SNRYKMK_CD_54,                           ' ||
							'  	                TTS.SNRYKMK_CD_55,                           ' ||
							'  	                TTS.SNRYKMK_CD_56,                           ' ||
							'  	                TTS.SNRYKMK_CD_57,                           ' ||
							'  	                TTS.SNRYKMK_CD_58,                           ' ||
							'  	                TTS.SNRYKMK_CD_59,                           ' ||
							'  	                TTS.SNRYKMK_CD_60,                           ' ||
							'  	                TTS.TEL_NASHI_FLG,                           ' ||
							  	                iOPE_CD                         ||       ',' ||
							  	                iDATE                           ||       ',' ||
							  	                iPGM_ID                         ||       ',' ||
							  	                iOPE_CD                         ||       ',' || 
							  	                iDATE                           ||       ',' ||
							  	                iPGM_ID                                      ||
							'  	             FROM TT_TIKY_SHI TTS                            ' ||                                                        
							'               WHERE TTS.REC_ID = '|| '''00'''                    ||         
							'  				 AND TTS.DEL_FLG IS NULL                         ' ;
           ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);   
            
          END IF;
        END IF; 

 	 COMMIT;

      oROW_COUNT := -1;
      
      -- �I�����O�o��
      ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'PL/SQL End',PGM_ID || '�̏������I�����܂����B',iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

      return 0;
    -- ��O����
  EXCEPTION
    -- ���̑��G���[
    WHEN OTHERS THEN
      W_ERR_INF_RCD.ERR_CD     := TO_CHAR(SQLCODE);
      W_ERR_INF_RCD.ERR_MSG     := SUBSTR(SQLERRM, 0, 500);
      W_ERR_INF_RCD.ERR_KEY_INF   := SUBSTR('iLayoutKbn:' || iLayoutKbn || ', iShimeKind:' || iShimeKind , 0,500);
      W_INDEX_N           := W_ERR_INF_TBL.COUNT + 1;
      W_ERR_INF_TBL.EXTEND;
      W_ERR_INF_TBL(W_INDEX_N)   := W_ERR_INF_RCD;

      OPEN oOUT_ERR_INF_CSR FOR
        SELECT * FROM TABLE(W_ERR_INF_TBL);
        

	  ROLLBACK;
	  
	  --�G���[���O�̓o�^
      ULT_INSERT_LOG_TABLE('ERROR',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'ERROR_INFO',W_ERR_INF_RCD.ERR_MSG,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

	  return 1;
END;

END;
/

