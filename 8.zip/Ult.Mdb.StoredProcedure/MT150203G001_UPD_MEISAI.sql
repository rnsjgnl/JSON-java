CREATE OR REPLACE PACKAGE       MT150203G001_UPD_MEISAI
/* **********************************************************
 *  Copyright(c) 2011 beyond, INTEC Inc. All rights reserved.
 * **********************************************************/
AUTHID CURRENT_USER
IS
	/*** �J�[�\���^ ***************************************************************/
	-- �G���[���i�[�p�J�[�\���^
	TYPE ERR_INF_CSR		       IS REF CURSOR;

	TYPE FB_USER_CD_TBL        IS TABLE OF TT_FB_KKIMAE_KJN_MEISAI.FB_USER_CD%TYPE INDEX BY BINARY_INTEGER;
	TYPE FB_SHIKIBETSU_CD_TBL  IS TABLE OF TT_FB_KKIMAE_KJN_MEISAI.FB_SHIKIBETSU_CD%TYPE INDEX BY BINARY_INTEGER;
	TYPE FB_LOT_NO_TBL         IS TABLE OF TT_FB_KKIMAE_KJN_MEISAI.FB_LOT_NO%TYPE INDEX BY BINARY_INTEGER;
	TYPE EDABAN_TBL            IS TABLE OF TT_FB_KKIMAE_KJN_MEISAI.EDABAN%TYPE INDEX BY BINARY_INTEGER;
	TYPE FB_KOMOKU_NO_TBL      IS TABLE OF TT_FB_KKIMAE_KJN_MEISAI.FB_KOMOKU_NO%TYPE INDEX BY BINARY_INTEGER;
	TYPE HENKO_MAE_TBL         IS TABLE OF VARCHAR(4000) INDEX BY BINARY_INTEGER;
	TYPE HENKO_GO_TBL          IS TABLE OF VARCHAR(4000) INDEX BY BINARY_INTEGER;
	TYPE TAIO_KBN_TBL          IS TABLE OF TT_FB_KKIMAE_KJN_MEISAI.TAIO_KBN%TYPE INDEX BY BINARY_INTEGER;
	TYPE COMMENTS_TBL          IS TABLE OF TT_FB_KKIMAE_KJN_MEISAI.COMMENTS%TYPE INDEX BY BINARY_INTEGER;
	TYPE JIZEN_CHKZUMI_FLG_TBL IS TABLE OF TT_FB_KKIMAE_KJN_MEISAI.JIZEN_CHKZUMI_FLG%TYPE INDEX BY BINARY_INTEGER;
	TYPE TRK_EIGY_YMD_TBL      IS TABLE OF TT_FB_KKIMAE_KJN_MEISAI.TRK_EIGY_YMD%TYPE INDEX BY BINARY_INTEGER;
	TYPE UPD_EIGY_YMD_TBL      IS TABLE OF TT_FB_KKIMAE_KJN_MEISAI.UPD_EIGY_YMD%TYPE INDEX BY BINARY_INTEGER;

	/*
	************************************************************************
	*  FB���J�O�{�݃��b�g�e�[�u���̈ꊇ�X�V����
	************************************************************************
	*/
	FUNCTION UPDATE_MEISAI(
		iSHI_KJN_KBN          IN VARCHAR2,
		iFB_USER_CD           IN FB_USER_CD_TBL,
		iFB_SHIKIBETSU_CD     IN FB_SHIKIBETSU_CD_TBL,
		iFB_LOT_NO            IN FB_LOT_NO_TBL,
		iEDABAN               IN EDABAN_TBL,
		iFB_KOMOKU_NO         IN FB_KOMOKU_NO_TBL,
		iHENKO_MAE            IN HENKO_MAE_TBL,
		iHENKO_GO             IN HENKO_GO_TBL,
		iTAIO_KBN             IN TAIO_KBN_TBL,
		iCOMMENTS             IN COMMENTS_TBL,
		iJIZEN_CHKZUMI_FLG    IN JIZEN_CHKZUMI_FLG_TBL,
		iUPD_EIGY_YMD         IN UPD_EIGY_YMD_TBL,
        iOPE_CD               IN VARCHAR2, -- �I�y���[�^�R�[�h
        iPGM_ID               IN VARCHAR2, -- �v���O����ID
        iDATE                 IN DATE,     -- ��������
        iIP_ADDR              IN TL_STORED_SHORI.IP%TYPE, -- ���s�[��IP�A�h���X
        iWINDOWS_LOGIN_USER   IN TL_STORED_SHORI.WINDOWS_LOGIN_USER%TYPE, -- ���s�[��OS���[�U�[
        oROW_COUNT            OUT NUMBER, -- �X�V����
        oOUT_ERR_INF_CSR      OUT ERR_INF_CSR -- �G���[���J�[�\��
	) RETURN NUMBER;

	FUNCTION UPDATE_MEISAI_SHI_CLOB(
		iSHI_KJN_KBN          IN VARCHAR2,
		iFB_USER_CD           IN TT_FB_KKIMAE_SHI_MEISAI.FB_USER_CD%TYPE,
		iFB_SHIKIBETSU_CD     IN TT_FB_KKIMAE_SHI_MEISAI.FB_SHIKIBETSU_CD%TYPE,
		iFB_LOT_NO            IN TT_FB_KKIMAE_SHI_MEISAI.FB_LOT_NO%TYPE,
		iEDABAN               IN TT_FB_KKIMAE_SHI_MEISAI.EDABAN%TYPE,
		iFB_KOMOKU_NO         IN TT_FB_KKIMAE_SHI_MEISAI.FB_KOMOKU_NO%TYPE,
		iHENKO_MAE            IN TT_FB_KKIMAE_SHI_MEISAI.HENKO_MAE%TYPE,
		iHENKO_GO             IN TT_FB_KKIMAE_SHI_MEISAI.HENKO_GO%TYPE,
		iTAIO_KBN             IN TT_FB_KKIMAE_SHI_MEISAI.TAIO_KBN%TYPE,
		iCOMMENTS             IN TT_FB_KKIMAE_SHI_MEISAI.COMMENTS%TYPE,
		iJIZEN_CHKZUMI_FLG    IN TT_FB_KKIMAE_SHI_MEISAI.JIZEN_CHKZUMI_FLG%TYPE,
		iUPD_EIGY_YMD         IN TT_FB_KKIMAE_SHI_MEISAI.UPD_EIGY_YMD%TYPE,
        iOPE_CD               IN VARCHAR2, -- �I�y���[�^�R�[�h
        iPGM_ID               IN VARCHAR2, -- �v���O����ID
        iDATE                 IN DATE,     -- ��������
        iIP_ADDR              IN TL_STORED_SHORI.IP%TYPE, -- ���s�[��IP�A�h���X
        iWINDOWS_LOGIN_USER   IN TL_STORED_SHORI.WINDOWS_LOGIN_USER%TYPE, -- ���s�[��OS���[�U�[
        oROW_COUNT            OUT NUMBER, -- �X�V����
        oOUT_ERR_INF_CSR      OUT ERR_INF_CSR -- �G���[���J�[�\��
	) RETURN NUMBER;
END;
/

CREATE OR REPLACE PACKAGE BODY       MT150203G001_UPD_MEISAI
/* **********************************************************
 *  Copyright(c) 2011 beyond, INTEC Inc. All rights reserved.
 * **********************************************************/
IS

    FUNCTION UPDATE_MEISAI(
    	iSHI_KJN_KBN		IN VARCHAR2,
		iFB_USER_CD IN FB_USER_CD_TBL,
		iFB_SHIKIBETSU_CD IN FB_SHIKIBETSU_CD_TBL,
		iFB_LOT_NO IN FB_LOT_NO_TBL,
		iEDABAN IN EDABAN_TBL,
		iFB_KOMOKU_NO IN FB_KOMOKU_NO_TBL,
		iHENKO_MAE IN HENKO_MAE_TBL,
		iHENKO_GO IN HENKO_GO_TBL,
		iTAIO_KBN IN TAIO_KBN_TBL,
		iCOMMENTS IN COMMENTS_TBL,
		iJIZEN_CHKZUMI_FLG IN JIZEN_CHKZUMI_FLG_TBL,
		iUPD_EIGY_YMD IN UPD_EIGY_YMD_TBL,
		iOPE_CD                 IN VARCHAR2, -- �I�y���[�^�R�[�h
	    iPGM_ID                 IN VARCHAR2, -- �v���O����ID
        iDATE                   IN DATE,     -- ��������
	    iIP_ADDR                IN TL_STORED_SHORI.IP%TYPE, -- ���s�[��IP�A�h���X
	    iWINDOWS_LOGIN_USER     IN TL_STORED_SHORI.WINDOWS_LOGIN_USER%TYPE, -- ���s�[��OS���[�U�[
	    oROW_COUNT    	        OUT NUMBER, -- �X�V����
	    oOUT_ERR_INF_CSR        OUT ERR_INF_CSR -- �G���[���J�[�\��
    ) RETURN NUMBER IS

    /************************************************************************/
    /*                              �G���[����                              */
    /************************************************************************/
    PGM_ID  VARCHAR2(50) := 'MT150203G001_UPD_MEISAI.UPDATE_MEISAI';
    W_INDEX_N                     NUMBER(10) := 0;
    W_ERR_INF_TBL                 TYPE_ERR_INFO_TBL := TYPE_ERR_INFO_TBL();
    W_ERR_INF_RCD                 TYPE_ERR_INFO_RCD := TYPE_ERR_INFO_RCD(NULL,NULL,NULL,NULL);
    vSQL VARCHAR2(1500);

    BEGIN

        -- �J�n���O�o��
        ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'PL/SQL Start',PGM_ID || '�̏������J�n���܂��B',iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

				-- �X�V�������s
				-- ���I�r�p�k�g�ݗ���
        			vSQL := '';
        			
				-- �{�݌l�敪���P���AFB���J�O�{�ݖ��׃e�[�u��
			        IF iSHI_KJN_KBN = '1' THEN
				vSQL := vSQL || ' UPDATE TT_FB_KKIMAE_SHI_MEISAI  ';
			        -- �{�݌l�敪���Q���AFB���J�O���׃��b�g�e�[�u��
			        ELSIF iSHI_KJN_KBN = '2' THEN
				vSQL := vSQL || ' UPDATE TT_FB_KKIMAE_KJN_MEISAI  ';
			        END IF;
				vSQL := vSQL || 'SET ';
				vSQL := vSQL || 'FB_USER_CD = :iFB_USER_CD,';
				vSQL := vSQL || 'FB_SHIKIBETSU_CD = :iFB_SHIKIBETSU_CD,';
				vSQL := vSQL || 'FB_LOT_NO = :iFB_LOT_NO,';
				vSQL := vSQL || 'EDABAN = :iEDABAN,';
				vSQL := vSQL || 'FB_KOMOKU_NO = :iFB_KOMOKU_NO,';
				vSQL := vSQL || 'HENKO_MAE = :iHENKO_MAE,';
				vSQL := vSQL || 'HENKO_GO = :iHENKO_GO,';
				vSQL := vSQL || 'TAIO_KBN = :iTAIO_KBN,';
				vSQL := vSQL || 'COMMENTS = :iCOMMENTS,';
				vSQL := vSQL || 'JIZEN_CHKZUMI_FLG = :iJIZEN_CHKZUMI_FLG,';
				vSQL := vSQL || 'UPD_EIGY_YMD = :iUPD_EIGY_YMD,';

				vSQL := vSQL || 'UPD_OPE_CD = :iUPD_OPE_CD,';
				vSQL := vSQL || 'UPD_DATE = :iUPD_DATE,';
				vSQL := vSQL || 'UPD_PGM_ID = :iUPD_PGM_ID ';

				vSQL := vSQL || 'WHERE ';
				vSQL := vSQL || 'FB_USER_CD            = :iFB_USER_CD ';
				vSQL := vSQL || 'AND FB_SHIKIBETSU_CD  = :iFB_SHIKIBETSU_CD ';
				vSQL := vSQL || 'AND FB_LOT_NO         = :iFB_LOT_NO ';
				vSQL := vSQL || 'AND EDABAN         = :iEDABAN ';
				vSQL := vSQL || 'AND FB_KOMOKU_NO         = :iFB_KOMOKU_NO ';

				FORALL i IN iFB_USER_CD.FIRST .. iFB_USER_CD.LAST
	        			-- ���I�r�p�k���s
	        			EXECUTE IMMEDIATE vSQL USING in 
						iFB_USER_CD(i),
						iFB_SHIKIBETSU_CD(i),
						iFB_LOT_NO(i),
						iEDABAN(i),
						iFB_KOMOKU_NO(i),
						iHENKO_MAE(i),
						iHENKO_GO(i),
						iTAIO_KBN(i),
						iCOMMENTS(i),
						iJIZEN_CHKZUMI_FLG(i),
						iUPD_EIGY_YMD(i),
						iOPE_CD,
						iDATE,
						iPGM_ID,
	        			iFB_USER_CD(i),
						iFB_SHIKIBETSU_CD(i),
						iFB_LOT_NO(i),
						iEDABAN(i),
						iFB_KOMOKU_NO(i);

		oROW_COUNT := iFB_USER_CD.COUNT;

        -- �I�����O�o��
        ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'PL/SQL End',PGM_ID || '�̏������I�����܂����B',iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

        -- ����I��
        RETURN 0;

    -- ��O����
    EXCEPTION
        -- ���̑��G���[
        WHEN OTHERS THEN
            W_ERR_INF_RCD.ERR_CD         := TO_CHAR(SQLCODE);
            W_ERR_INF_RCD.ERR_MSG        := SUBSTR(SQLERRM, 0, 500);
            W_INDEX_N                    := W_ERR_INF_TBL.COUNT + 1;
            W_ERR_INF_TBL.EXTEND;
            W_ERR_INF_TBL(W_INDEX_N)     := W_ERR_INF_RCD;

            OPEN oOUT_ERR_INF_CSR FOR
                SELECT * FROM TABLE(W_ERR_INF_TBL);

            --�G���[���O�̓o�^
            ULT_INSERT_LOG_TABLE('ERROR',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'ERROR_INFO',W_ERR_INF_RCD.ERR_MSG,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

        RAISE;
    END;

    FUNCTION UPDATE_MEISAI_SHI_CLOB(
		iSHI_KJN_KBN          IN VARCHAR2,
		iFB_USER_CD           IN TT_FB_KKIMAE_SHI_MEISAI.FB_USER_CD%TYPE,
		iFB_SHIKIBETSU_CD     IN TT_FB_KKIMAE_SHI_MEISAI.FB_SHIKIBETSU_CD%TYPE,
		iFB_LOT_NO            IN TT_FB_KKIMAE_SHI_MEISAI.FB_LOT_NO%TYPE,
		iEDABAN               IN TT_FB_KKIMAE_SHI_MEISAI.EDABAN%TYPE,
		iFB_KOMOKU_NO         IN TT_FB_KKIMAE_SHI_MEISAI.FB_KOMOKU_NO%TYPE,
		iHENKO_MAE            IN TT_FB_KKIMAE_SHI_MEISAI.HENKO_MAE%TYPE,
		iHENKO_GO             IN TT_FB_KKIMAE_SHI_MEISAI.HENKO_GO%TYPE,
		iTAIO_KBN             IN TT_FB_KKIMAE_SHI_MEISAI.TAIO_KBN%TYPE,
		iCOMMENTS             IN TT_FB_KKIMAE_SHI_MEISAI.COMMENTS%TYPE,
		iJIZEN_CHKZUMI_FLG    IN TT_FB_KKIMAE_SHI_MEISAI.JIZEN_CHKZUMI_FLG%TYPE,
		iUPD_EIGY_YMD         IN TT_FB_KKIMAE_SHI_MEISAI.UPD_EIGY_YMD%TYPE,
        iOPE_CD               IN VARCHAR2, -- �I�y���[�^�R�[�h
        iPGM_ID               IN VARCHAR2, -- �v���O����ID
        iDATE                 IN DATE,     -- ��������
        iIP_ADDR              IN TL_STORED_SHORI.IP%TYPE, -- ���s�[��IP�A�h���X
        iWINDOWS_LOGIN_USER   IN TL_STORED_SHORI.WINDOWS_LOGIN_USER%TYPE, -- ���s�[��OS���[�U�[
        oROW_COUNT            OUT NUMBER, -- �X�V����
        oOUT_ERR_INF_CSR      OUT ERR_INF_CSR -- �G���[���J�[�\��
    ) RETURN NUMBER IS

    /************************************************************************/
    /*                              �G���[����                              */
    /************************************************************************/
    PGM_ID  VARCHAR2(50) := 'MT150203G001_UPD_MEISAI.UPDATE_MEISAI_SHI';
    W_INDEX_N                     NUMBER(10) := 0;
    W_ERR_INF_TBL                 TYPE_ERR_INFO_TBL := TYPE_ERR_INFO_TBL();
    W_ERR_INF_RCD                 TYPE_ERR_INFO_RCD := TYPE_ERR_INFO_RCD(NULL,NULL,NULL,NULL);
    vSQL VARCHAR2(1500);

    BEGIN

        -- �J�n���O�o��
        -- ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'PL/SQL Start',PGM_ID || '�̏������J�n���܂��B',iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

				-- �X�V�������s
				UPDATE TT_FB_KKIMAE_SHI_MEISAI
				SET 
					FB_USER_CD = iFB_USER_CD,
					FB_SHIKIBETSU_CD = iFB_SHIKIBETSU_CD,
					FB_LOT_NO = iFB_LOT_NO,
					EDABAN = iEDABAN,
					FB_KOMOKU_NO = iFB_KOMOKU_NO,
					HENKO_MAE = iHENKO_MAE,
					HENKO_GO = iHENKO_GO,
					TAIO_KBN = iTAIO_KBN,
					COMMENTS = iCOMMENTS,
					JIZEN_CHKZUMI_FLG = iJIZEN_CHKZUMI_FLG,
					UPD_EIGY_YMD = iUPD_EIGY_YMD,
					UPD_OPE_CD = iOPE_CD,
					UPD_DATE = iDATE,
					UPD_PGM_ID = iPGM_ID
				WHERE 
					FB_USER_CD = iFB_USER_CD 
				AND FB_SHIKIBETSU_CD  = iFB_SHIKIBETSU_CD 
				AND FB_LOT_NO = iFB_LOT_NO 
				AND EDABAN = iEDABAN 
				AND FB_KOMOKU_NO = iFB_KOMOKU_NO;


		oROW_COUNT := SQL%ROWCOUNT;
        -- �I�����O�o��
        -- ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'PL/SQL End',PGM_ID || '�̏������I�����܂����B',iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

        -- ����I��
        RETURN 0;

    -- ��O����
    EXCEPTION
        -- ���̑��G���[
        WHEN OTHERS THEN
            W_ERR_INF_RCD.ERR_CD         := TO_CHAR(SQLCODE);
            W_ERR_INF_RCD.ERR_MSG        := SUBSTR(SQLERRM, 0, 500);
            W_INDEX_N                    := W_ERR_INF_TBL.COUNT + 1;
            W_ERR_INF_TBL.EXTEND;
            W_ERR_INF_TBL(W_INDEX_N)     := W_ERR_INF_RCD;

            OPEN oOUT_ERR_INF_CSR FOR
                SELECT * FROM TABLE(W_ERR_INF_TBL);

            --�G���[���O�̓o�^
            ULT_INSERT_LOG_TABLE('ERROR',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'ERROR_INFO',W_ERR_INF_RCD.ERR_MSG,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

        RAISE;
    END;
END;
/
