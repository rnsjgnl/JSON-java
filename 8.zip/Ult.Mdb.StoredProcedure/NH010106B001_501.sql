CREATE OR REPLACE PACKAGE NH010106B001_501
/* **********************************************************
 *  Copyright(c) 2011 beyond, INTEC Inc. All rights reserved.
 * **********************************************************/
AUTHID CURRENT_USER
IS
	/*** �J�[�\���^ ***************************************************************/
	-- �G���[���i�[�p�J�[�\���^
	TYPE ERR_INF_CSR		IS REF CURSOR;
	
	/*
	************************************************************************
	*  DCF��t�f��DB�f�[�^�̍쐬
	*  CREATE_DCF_ISI
	************************************************************************
	*/
	FUNCTION CREATE_DCF_ISI(
	iLayoutKind	IN	INTEGER,										-- ���C�A�E�g�敪
	iShimeKind	IN	INTEGER,										-- ���ߓ��敪
  iTensoYMD	IN	VARCHAR2,										-- �]���N���� 
	iIP_ADDR	IN TL_STORED_SHORI.IP%TYPE,							-- ���s�[��IP�A�h���X (FW�Őݒ�)
	iWINDOWS_LOGIN_USER	IN TL_STORED_SHORI.WINDOWS_LOGIN_USER%TYPE, -- ���s�[��OS���[�U�[ (FW�Őݒ�)
	oROW_COUNT	OUT NUMBER,         -- �o�^����
	oOUT_ERR_INF_CSR 	OUT ERR_INF_CSR,    -- �G���[���J�[�\��
   iOPE_CD IN Varchar2,                      -- �I�y���[�^�R�[�h
  iPGM_ID IN Varchar2,                      -- �v���O����ID
  iDATE DATE                              -- �V�X�e������
	) RETURN NUMBER;
    
END;
/

CREATE OR REPLACE PACKAGE BODY NH010106B001_501
/* **********************************************************
 *  Copyright(c) 2011 beyond, INTEC Inc. All rights reserved.
 * **********************************************************/
IS
	/*
	 ************************************************************************
	 * Function ID  : CREATE_DCF_ISI
	 * Program Name : DCF��t�t�@�C�� �f��DB�f�[�^�̍쐬
	 * Parameter    :  <I> iLayoutKind	    	�F���C�A�E�g�敪
	 *		   		   <I> iShimeKind	    	�F���ߓ��敪
	 *				   <I> iTensoYMD	    	�F�]���N����
	 *				   <I> iOPE_CD		        �F�I�y���[�^�R�[�h
	 *				   <I> iPGM_ID		        �F�v���O����ID
	 *				   <I> iDATE		        �F�V�X�e������ 
	 *		           <I> iIP_ADDR		        �F���s�[��IP�A�h���X
	 *		           <I> iWINDOWS_LOGIN_USER  �F���s�[��IP�A�h���X
	 *                 <O> oROW_COUNT		    �F�X�V����
	 *                <O> oOUT_ERR_INF_CSR	�F�G���[���J�[�\��
	 * Return       �F�������ʁi0:����I���A1:�ُ�I���j
	 ************************************************************************
	 */
	FUNCTION CREATE_DCF_ISI(
	iLayoutKind	IN	INTEGER,										-- ���C�A�E�g�敪
	iShimeKind	IN	INTEGER,										-- ���ߓ��敪
        iTensoYMD	IN	VARCHAR2,										-- �]���N���� 
	iIP_ADDR	IN TL_STORED_SHORI.IP%TYPE,							-- ���s�[��IP�A�h���X (FW�Őݒ�)
	iWINDOWS_LOGIN_USER	IN TL_STORED_SHORI.WINDOWS_LOGIN_USER%TYPE, -- ���s�[��OS���[�U�[ (FW�Őݒ�)
	oROW_COUNT	OUT NUMBER,         -- �o�^����
	oOUT_ERR_INF_CSR 	OUT ERR_INF_CSR,    -- �G���[���J�[�\��
  iOPE_CD IN Varchar2,                      -- �I�y���[�^�R�[�h
  iPGM_ID IN Varchar2,                      -- �v���O����ID
  iDATE DATE                            -- �V�X�e������  
	)RETURN NUMBER IS
  
  PRAGMA AUTONOMOUS_TRANSACTION;
	/************************************************************************/
	/*                              �G���[����                              */
	/************************************************************************/
	W_INDEX_N 					NUMBER(10) := 0;
	W_ERR_INF_TBL 				TYPE_ERR_INFO_TBL := TYPE_ERR_INFO_TBL();
	W_ERR_INF_RCD 				TYPE_ERR_INFO_RCD := TYPE_ERR_INFO_RCD(NULL,NULL,NULL,NULL);
    vSchemaNm     TM_JOSU.HANYO_KOMOKU%TYPE := NULL; -- �X�L�[�}����
	PGM_ID        VARCHAR2(50) := 'NH010106B001_501.CREATE_DCF_ISI';
	EXECUTE_SQL   VARCHAR2(32767) := NULL;  

BEGIN
      -- �J�n���O�o��
      ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'PL/SQL Start',PGM_ID || '�̏������J�n���܂��B',iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);
      -- �[�i�p�X�L�[�}�̎擾���s���B
      vSchemaNm := ULT_COMMON.GET_SCHEMA_NAME(ULT_COMMON.SYS_ENV_JOSU_DAI_CD, ULT_COMMON.NOHIN_SHEMA_JOSU_SHO_CD);
      oROW_COUNT:= -1;

      IF iLayoutKind = 1 THEN
          -- �V���C�A�E�g       
        IF iShimeKind = 1 THEN
          --�V_�S��_DCF��t�e�[�u���̃f�[�^���N���A����B
          EXECUTE_SQL := 'TRUNCATE TABLE ' || vSchemaNm || '.' || 'TD_NA_DCF_KJN';
          EXECUTE IMMEDIATE EXECUTE_SQL;
          ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);
            
          -- �擾�����f��DB�f�[�^���������J��Ԃ�
            EXECUTE_SQL :=  'INSERT INTO TD_NA_DCF_KJN(     '  ||
					                'LAYOUT_KBN,                                '  ||
					                'KJNREC_ID,                                 '  ||
					                'KJN_CD,                                    '  ||
					                'KJN_CD_YOBI,			            '  ||		 										
					                'MOD_KBN,				    '  ||											
					                'MENTE_YMD,				    '  ||											
					                'YOBI_1,			            '  ||		 										
					                'DEL_YOTEI_RIYU,			    '  ||												
					                'AITSK_CD_KJNREC_ID,			    '  ||												   
					                'AITSK_CD_KJN_CD,			    '  ||												
					                'AITSK_CD_KJN_CD_YOBI,			    '  ||												
					                'ISHI_NM_KANJI,				    '  ||											
					                'ISHI_NM_KANA,				    '  ||											
					                'SEIBETSU,				    '  ||											
					                'BIRTH_GENGO,				    '  ||											
					                'BIRTH_Y,				    '  ||											
					                'BIRTH_M,				    '  ||											             
					                'BIRTH_D,				    '  ||											
					                'SHUSSHIN_KEN_CD,			    '  ||												
					                'ISHIKAI_CD,				    '  ||											          
					                'STNEN_GENGO,				    '  ||											
					                'STNEN_Y,				    '  ||											
					                'SHUSSHINKO_SHUSSHINKO_CD,		    '  ||													
					                'SHUSSHINKO_GAKUBU_SKBT_CD,		    '  ||													
					                'TRKNEN_GENGO,				    '  ||											
					                'TRKNEN_Y,				    '  ||											
					                'SNRYKMK_1,				    '  ||											
					                'SNRYKMK_2,				    '  ||											
					                'SNRYKMK_3,				    '  ||											
					                'SNRYKMK_4,				    '  ||											
					                'SNRYKMK_5,				    '  ||											
					                'JUSHOFUMEI,				    '  ||											
					                'JUSHO_CD_KEN_CD,			    '  ||												
					                'JUSHO_CD_SHIKU_CD,			    '  ||												
					                'JUSHO_CD_OAZA_CD,			    '  ||												
					                'JUSHO_CD_AZA_CD,			    '  ||												
					                'ZIP,					    '  ||										
					                'JITAKU_JUSHO_KANJI,			    '  ||												
					                'JITAKU_JUSHO_KANA,			    '  ||												
					                'JUSHO_HYOJI_NO,			    '  ||												
					                'JUSHO_COUNT_KANJI_KEN,			    '  ||												
					                'JUSHO_COUNT_KANJI_SHIKU,		    '  ||													
					                'JUSHO_COUNT_KANJI_OAZA,		    '  ||													
					                'JUSHO_COUNT_KANJI_AZA,			    '  ||												
					                'JUSHO_COUNT_KANA_KEN,			    '  ||												
					                'JUSHO_COUNT_KANA_SHIKU,		    '  ||													
					                'JUSHO_COUNT_KANA_OAZA,			    '  ||												
					                'JUSHO_COUNT_KANA_AZA,			    '  ||												
					                'JITAKU_TEL,				    '  ||											             
					                'RIYOTEISHI_RIYOTEISHI_KBN,		    '  ||													
					                'RIYOTEISHI_RIYOTEISHI_RIYU,		    '  ||													
					                'RIYOTEISHI_TRK_YMD,			    '  ||												
					                'RIYOTEISHI_KAIJO_YMD,			    '  ||												
					                'KAIKIN_KBN,				    '  ||											
					                'KAIGYONEN_GENGO,			    '  ||												
					                'KAIGYONEN_Y,				    '  ||											
					                'IKKATSU_TRK_FLG,			    '  ||												
					                'YOBI_2,				    '  ||										
					                'TENSO_YMD,                                 '  ||
					                'TRK_OPE_CD,                                '  ||
					                'TRK_DATE,                                  '  ||
					                'TRK_PGM_ID,                                '  ||
					                'UPD_OPE_CD,                                '  ||
					                'UPD_DATE,                                  '  ||
					                'UPD_PGM_ID)	                            '  ||
					           'SELECT                                    '  ||                
							       '''501'' AS LAYOUT_KBN,                                  '  ||
							       'REC_ID AS KJNREC_ID,				        '  ||		                                                  
							       'KJN_CD AS KJN_CD,                                       '  ||
							       'NULL AS KJN_CD_YOBI,				        '  ||		
							       'NULL AS MOD_KBN,					'  ||		                                                 
							       'UPD_EIGY_YMD AS MENTE_YMD,                              '  ||
							       'NULL AS YOBI_1,                                         '  ||   
							       'DEL_YOTEI_RIYU_CD AS DEL_YOTEI_RIYU,                    '  ||                              
							       'CHOFUKU_AITSK_REC_ID AS AITSK_CD_KJNREC_ID,             '  ||                                     
							       'CHOFUKU_AITSK_KJN_CD AS AITSK_CD_KJN_CD,                '  ||
							       'NULL AS AITSK_CD_KJN_CD_YOBI,                           '  ||                     
							       'KJN_NM AS ISHI_NM_KANJI,				'  ||														
							       'KJN_NM_KANA AS ISHI_NM_KANA,				'  ||														
							       'SEIBETSU_KBN AS SEIBETSU,				'  ||														
							       'BIRTH_GENGO_CD AS BIRTH_GENGO,				'  ||														
							       'BIRTH_WY AS BIRTH_Y,					'  ||													
							       'BIRTH_M AS BIRTH_M,					'  ||													
							       'BIRTH_D AS BIRTH_D,					'  ||													
							       'SHUSSHINCHI_RIDAI_CD AS SHUSSHIN_KEN_CD,		'  ||																
							       'KANYU_ISHIKAI_RIDAI_CD AS ISHIKAI_CD,			'  ||															
							       'STNEN_GENGO_CD AS STNEN_GENGO,				'  ||														
							       'STNEN_WY AS STNEN_Y,					'  ||													
							       'SHUSSHINKO_CD AS SHUSSHINKO_SHUSSHINKO_CD,		'  ||																
							       'GAKUBU_SHIKIBETSU_KBN AS SHUSSHINKO_GAKUBU_SKBT_CD,	'  ||																	
							       'TRKNEN_GENGO_CD AS TRKNEN_GENGO,			'  ||															
							       'TRKNEN_WY AS TRKNEN_Y,					'  ||													
							       'SNRYKMK_CD_1 AS SNRYKMK_1,				'  ||														
							       'SNRYKMK_CD_2 AS SNRYKMK_2,				'  ||														
							       'SNRYKMK_CD_3 AS SNRYKMK_3,				'  ||														
							       'SNRYKMK_CD_4 AS SNRYKMK_4,				'  ||														
							       'SNRYKMK_CD_5 AS SNRYKMK_5,				'  ||														
							       'JUSHOFUMEI_CD AS JUSHOFUMEI,				'  ||														
							       'KEN_CD AS JUSHO_CD_KEN_CD,				'  ||														
							       'SHIKU_CD AS JUSHO_CD_SHIKU_CD,				'  ||														
							       'OAZA_CD AS JUSHO_CD_OAZA_CD,				'  ||														
							       'AZA_CD AS JUSHO_CD_AZA_CD,				'  ||														
							       'ZIP AS ZIP,						'  ||												
							       'JUSHO_KANJI_RENKETSU AS JITAKU_JUSHO_KANJI,		'  ||																
							       'JUSHO_KANA_RENKETSU AS JITAKU_JUSHO_KANA,		'  ||																
							       'JUSHO_HYOJI_NO AS JUSHO_HYOJI_NO,			'  ||															
							       'KEN_NM_KANJI_MOJI_SU AS JUSHO_COUNT_KANJI_KEN,		'  ||																
							       'SHIKU_NM_KANJI_MOJI_SU AS JUSHO_COUNT_KANJI_SHIKU,	'  ||																	
							       'OAZA_NM_KANJI_MOJI_SU AS JUSHO_COUNT_KANJI_OAZA,	'  ||																	
							       'AZA_NM_KANJI_MOJI_SU AS JUSHO_COUNT_KANJI_AZA,		'  ||																
							       'KEN_NM_KANA_MOJI_SU AS JUSHO_COUNT_KANA_KEN,		'  ||																
							       'SHIKU_NM_KANA_MOJI_SU AS JUSHO_COUNT_KANA_SHIKU,	'  ||																	
							       'OAZA_NM_KANA_MOJI_SU AS JUSHO_COUNT_KANA_OAZA,		'  ||																
							       'AZA_NM_KANA_MOJI_SU AS JUSHO_COUNT_KANA_AZA,		'  ||																
							       'TEL AS JITAKU_TEL,					'  ||													
							       'RIYOTEISHI_KBN_CD AS RIYOTEISHI_RIYOTEISHI_KBN,		'  ||																
							       'RIYOTEISHI_RIYU_CD AS RIYOTEISHI_RIYOTEISHI_RIYU,	'  ||																	
							       'RIYOTEISHI_TRK_YMD AS RIYOTEISHI_TRK_YMD,		'  ||																
							       'RIYOTEISHI_KAIJO_YMD AS RIYOTEISHI_KAIJO_YMD,		'  ||																
							       'KAIKIN_KBN AS KAIKIN_KBN,				'  ||														
							       'KAIGYONEN_GENGO_CD AS KAIGYONEN_GENGO,			'  ||															
							       'KAIGYONEN_WY AS KAIGYONEN_Y,				'  ||														
							       'IKKATSU_TRK_FLG AS IKKATSU_TRK_FLG,                     '  ||
							       'NULL AS YOBI_2,						'  ||
							       iTensoYMD|| ','                                                                              ||
							       iOPE_CD  || ','                                                                              ||
									iDATE    || ','                                                                              ||
									iPGM_ID  || ','                                                                              ||
									iOPE_CD  || ','                                                                          ||
									iDATE    || ','                                                                              ||
									iPGM_ID  ||																																		
							       'FROM TT_TIKY_KJN                                        '  ||                                    
							       'WHERE REC_ID = ''01''                                   '  ||
							       'AND DEL_FLG IS NULL ';
	  ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);
	    
	    -- �V_�S��_DCF��t�e�[�u���̃f�[�^��o�^����
          INSERT INTO TD_NA_DCF_KJN( 
          							LAYOUT_KBN,                                  
					                KJNREC_ID,                                   
					                KJN_CD,                                      
					                KJN_CD_YOBI,			              		 										
					                MOD_KBN,				      											
					                MENTE_YMD,				      											
					                YOBI_1,			              		 										
					                DEL_YOTEI_RIYU,			      												
					                AITSK_CD_KJNREC_ID,			      												   
					                AITSK_CD_KJN_CD,			      												
					                AITSK_CD_KJN_CD_YOBI,			      												
					                ISHI_NM_KANJI,				      											
					                ISHI_NM_KANA,				      											
					                SEIBETSU,				      											
					                BIRTH_GENGO,				      											
					                BIRTH_Y,				      											
					                BIRTH_M,				      											             
					                BIRTH_D,				      											
					                SHUSSHIN_KEN_CD,			      												
					                ISHIKAI_CD,				      											          
					                STNEN_GENGO,				      											
					                STNEN_Y,				      											
					                SHUSSHINKO_SHUSSHINKO_CD,		      													
					                SHUSSHINKO_GAKUBU_SKBT_CD,		      													
					                TRKNEN_GENGO,				      											
					                TRKNEN_Y,				      											
					                SNRYKMK_1,				      											
					                SNRYKMK_2,				      											
					                SNRYKMK_3,				      											
					                SNRYKMK_4,				      											
					                SNRYKMK_5,				      											
					                JUSHOFUMEI,				      											
					                JUSHO_CD_KEN_CD,			      												
					                JUSHO_CD_SHIKU_CD,			      												
					                JUSHO_CD_OAZA_CD,			      												
					                JUSHO_CD_AZA_CD,			      												
					                ZIP,					      										
					                JITAKU_JUSHO_KANJI,			      												
					                JITAKU_JUSHO_KANA,			      												
					                JUSHO_HYOJI_NO,			      												
					                JUSHO_COUNT_KANJI_KEN,			      												
					                JUSHO_COUNT_KANJI_SHIKU,		      													
					                JUSHO_COUNT_KANJI_OAZA,		      													
					                JUSHO_COUNT_KANJI_AZA,			      												
					                JUSHO_COUNT_KANA_KEN,			      												
					                JUSHO_COUNT_KANA_SHIKU,		      													
					                JUSHO_COUNT_KANA_OAZA,			      												
					                JUSHO_COUNT_KANA_AZA,			      												
					                JITAKU_TEL,				      											             
					                RIYOTEISHI_RIYOTEISHI_KBN,		      													
					                RIYOTEISHI_RIYOTEISHI_RIYU,		      													
					                RIYOTEISHI_TRK_YMD,			      												
					                RIYOTEISHI_KAIJO_YMD,			      												
					                KAIKIN_KBN,				      											
					                KAIGYONEN_GENGO,			      												
					                KAIGYONEN_Y,				      											
					                IKKATSU_TRK_FLG,			      												
					                YOBI_2,				      										
					                TENSO_YMD,                                   
					                TRK_OPE_CD,                                  
					                TRK_DATE,                                    
					                TRK_PGM_ID,                                  
					                UPD_OPE_CD,                                  
					                UPD_DATE,                                    
					                UPD_PGM_ID
					              )	                              
					    SELECT                                                       
					       '501' AS LAYOUT_KBN,
					       REC_ID AS KJNREC_ID,							                                                  
					       KJN_CD AS KJN_CD, 
					       NULL AS KJN_CD_YOBI,							
					       NULL AS MOD_KBN,							                                                 
					       UPD_EIGY_YMD AS MENTE_YMD, 
					       NULL AS YOBI_1,                                                 
					       DEL_YOTEI_RIYU_CD AS DEL_YOTEI_RIYU,                                                  
					       CHOFUKU_AITSK_REC_ID AS AITSK_CD_KJNREC_ID,                                                  
					       CHOFUKU_AITSK_KJN_CD AS AITSK_CD_KJN_CD,  
					       NULL AS AITSK_CD_KJN_CD_YOBI,                                                
					       KJN_NM AS ISHI_NM_KANJI,																		
					       KJN_NM_KANA AS ISHI_NM_KANA,																		
					       SEIBETSU_KBN AS SEIBETSU,																		
					       BIRTH_GENGO_CD AS BIRTH_GENGO,																		
					       BIRTH_WY AS BIRTH_Y,																		
					       BIRTH_M AS BIRTH_M,																		
					       BIRTH_D AS BIRTH_D,																		
					       SHUSSHINCHI_RIDAI_CD AS SHUSSHIN_KEN_CD,																		
					       KANYU_ISHIKAI_RIDAI_CD AS ISHIKAI_CD,																		
					       STNEN_GENGO_CD AS STNEN_GENGO,																		
					       STNEN_WY AS STNEN_Y,																		
					       SHUSSHINKO_CD AS SHUSSHINKO_SHUSSHINKO_CD,																		
					       GAKUBU_SHIKIBETSU_KBN AS SHUSSHINKO_GAKUBU_SKBT_CD,																		
					       TRKNEN_GENGO_CD AS TRKNEN_GENGO,																		
					       TRKNEN_WY AS TRKNEN_Y,																		
					       SNRYKMK_CD_1 AS SNRYKMK_1,																		
					       SNRYKMK_CD_2 AS SNRYKMK_2,																		
					       SNRYKMK_CD_3 AS SNRYKMK_3,																		
					       SNRYKMK_CD_4 AS SNRYKMK_4,																		
					       SNRYKMK_CD_5 AS SNRYKMK_5,																		
					       JUSHOFUMEI_CD AS JUSHOFUMEI,																		
					       KEN_CD AS JUSHO_CD_KEN_CD,																		
					       SHIKU_CD AS JUSHO_CD_SHIKU_CD,																		
					       OAZA_CD AS JUSHO_CD_OAZA_CD,																		
					       AZA_CD AS JUSHO_CD_AZA_CD,																		
					       ZIP AS ZIP,																		
					       JUSHO_KANJI_RENKETSU AS JITAKU_JUSHO_KANJI,																		
					       JUSHO_KANA_RENKETSU AS JITAKU_JUSHO_KANA,																		
					       JUSHO_HYOJI_NO AS JUSHO_HYOJI_NO,																		
					       KEN_NM_KANJI_MOJI_SU AS JUSHO_COUNT_KANJI_KEN,																		
					       SHIKU_NM_KANJI_MOJI_SU AS JUSHO_COUNT_KANJI_SHIKU,																		
					       OAZA_NM_KANJI_MOJI_SU AS JUSHO_COUNT_KANJI_OAZA,																		
					       AZA_NM_KANJI_MOJI_SU AS JUSHO_COUNT_KANJI_AZA,																		
					       KEN_NM_KANA_MOJI_SU AS JUSHO_COUNT_KANA_KEN,																		
					       SHIKU_NM_KANA_MOJI_SU AS JUSHO_COUNT_KANA_SHIKU,																		
					       OAZA_NM_KANA_MOJI_SU AS JUSHO_COUNT_KANA_OAZA,																		
					       AZA_NM_KANA_MOJI_SU AS JUSHO_COUNT_KANA_AZA,																		
					       TEL AS JITAKU_TEL,																		
					       RIYOTEISHI_KBN_CD AS RIYOTEISHI_RIYOTEISHI_KBN,																		
					       RIYOTEISHI_RIYU_CD AS RIYOTEISHI_RIYOTEISHI_RIYU,																		
					       RIYOTEISHI_TRK_YMD AS RIYOTEISHI_TRK_YMD,																		
					       RIYOTEISHI_KAIJO_YMD AS RIYOTEISHI_KAIJO_YMD,																		
					       KAIKIN_KBN AS KAIKIN_KBN,																		
					       KAIGYONEN_GENGO_CD AS KAIGYONEN_GENGO,																		
					       KAIGYONEN_WY AS KAIGYONEN_Y,																		
					       IKKATSU_TRK_FLG AS IKKATSU_TRK_FLG,
					       NULL AS YOBI_2,
					        iTensoYMD,
					        iOPE_CD,
							iDATE,
							iPGM_ID,
							iOPE_CD,
							iDATE,
							iPGM_ID																									
					  FROM TT_TIKY_KJN                                                                                
					  WHERE REC_ID = '01'                                   
					  AND DEL_FLG IS NULL ;                                  
        END IF;
        
      ELSIF iLayoutKind = 2 THEN
        -- �b�背�C�A�E�g
        IF iShimeKind = 1 THEN
          
          --�b��_�S��_DCF��t�e�[�u���̃f�[�^���N���A����B
          EXECUTE_SQL := 'TRUNCATE TABLE ' || vSchemaNm || '.' || 'TD_PA_DCF_KJN';
          EXECUTE IMMEDIATE EXECUTE_SQL;
          ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);
             
          --�b��_�S��_���p��~(DCF��t)�e�[�u���̃f�[�^���N���A����B
          EXECUTE_SQL := 'TRUNCATE TABLE ' || vSchemaNm || '.' || 'TD_PA_DCF_KJN_TIS';
          EXECUTE IMMEDIATE EXECUTE_SQL;
          ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);
             
          --�b��_�S��_�w�����e�[�u���̃f�[�^���N���A����B
          EXECUTE_SQL := 'TRUNCATE TABLE ' || vSchemaNm || '.' || 'TD_PA_DCF_KJN_SENMONI';
          EXECUTE IMMEDIATE EXECUTE_SQL;
          ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);
             
            --�b��_�S��_DCFDCF��t�̓o�^
            EXECUTE_SQL :=  'INSERT INTO TD_PA_DCF_KJN(                    '  ||
					              'KJNREC_ID,                                                  '  ||
					              'KJN_CD,                                                     '  ||
					              'KJN_CD_YOBI,                                                '  ||  
					              'ISHI_NM_KANA,						   '  ||				
					              'SEIBETSU,						   '  || 				
					              'BIRTH_GENGO,						   '  ||				
					              'BIRTH_Y,							   '  ||			
					              'BIRTH_M,							   '  ||			
					              'BIRTH_D,                                                    '  ||
					              'YOBI_1,							   '  ||			
					              'SHUSSHIN_KEN_CD,						   '  ||										
					              'ISHIKAI_CD,						   '  ||										
					              'STNEN_GENGO,						   '  ||										
					              'STNEN_Y,							   '  ||									
					              'SHUSSHINKO_SHUSSHINKO_CD,				   '  ||												
					              'SHUSSHINKO_GAKUBU_SKBT_CD,				   '  ||												
					              'KAIKIN_KBN,						   '  ||										
					              'KAIGYONEN_GENGO,						   '  ||										
					              'KAIGYONEN_Y,						   '  ||										
					              'SNRYKMK_1,						   '  ||										
					              'SNRYKMK_2,						   '  ||										
					              'SNRYKMK_3,						   '  ||										
					              'SNRYKMK_4,						   '  ||										
					              'SNRYKMK_5,						   '  ||										
					              'JUSHO_CD_KEN_CD,						   '  ||										
					              'JUSHO_CD_SHIKU_CD,					   '  ||											
					              'JUSHO_CD_OAZA_CD,					   '  ||											
					              'JUSHO_CD_AZA_CD,						   '  ||										
					              'ZIP,							   '  ||									
					              'JUSHO_HYOJI_NO,						   '  ||																				
					              'YOBI_2,							   '  ||																			
					              'JITAKU_JUSHO_KANA,					   '  ||																					
					              'JUSHO_COUNT_KANA_KEN,					   '  ||																					
					              'JUSHO_COUNT_KANA_SHIKU,					   '  ||																					
					              'JUSHO_COUNT_KANA_OAZA,					   '  ||																					
					              'JUSHO_COUNT_KANA_AZA,					   '  ||																					
					              'JUSHO_COUNT_KANJI_KEN,					   '  ||																					
					              'JUSHO_COUNT_KANJI_SHIKU,					   '  ||																					
					              'JUSHO_COUNT_KANJI_OAZA,					   '  ||																					
					              'JUSHO_COUNT_KANJI_AZA,					   '  ||																					
					              'JITAKU_TEL,						   '  ||																				
					              'STATUS_JUSHOFUMEI,					   '  ||																					
					              'STATUS_DEL_YOTEI_RIYU,					   '  ||																					
					              'STATUS_IKKATSU_TRK_FLG,					   '  ||																					
					              'STATUS_YOBI,						   '  ||																				
					              'TRKNEN_GENGO,						   '  ||																				
					              'TRKNEN_Y,						   '  ||																				
					              'KOTEI_KOMOKU_YOBI_AREA,					   '  ||																					
					              'ISHI_NM_KANJI,						   '  ||																				
					              'JITAKU_JUSHO_KANJI,					   '  ||																					
					              'KINMUSAKI_SHIREC_ID,					   '  ||																					
					              'KINMUSAKI_SHI_CD,					   '  ||																					
					              'KINMUSAKI_SHI_CD_YOBI,					   '  ||																					
					              'KINMUSAKI_YAKUSHOKU_CD,					   '  ||																					
					              'KINMUSAKI_SHOKUI,					   '  ||																					
					              'KINMUSAKI_SZKBUKA_CD,					   '  ||																					
					              'KINMUSAKI_HENKO_UMU_FLG,					   '  ||																					
					              'YOBI_3,							   '  ||																			
					              'RYKSK_SHI_NM_KANA,					   '  ||																					
					              'RYKSK_SHI_NM_KANJI,					   '  ||																					
					              'SZKBUKA_KANA,						   '  ||																				
					              'SZKBUKA_KANJI,						   '  ||																				
					              'KINMUSAKI_KOMOKU_YOBI_AREA,				   '  ||																						
					              'AITSK_CD_KJNREC_ID,					   '  ||																					
					              'AITSK_CD_KJN_CD,						   '  ||																				
					              'AITSK_CD_KJN_CD_YOBI,					   '  ||																					
					              'MOD_SHORI_YMD_Y,						   '  ||																				
					              'MOD_SHORI_YMD_M,						   '  ||																				
					              'MOD_SHORI_YMD_D,						   '  ||																				
					              'TENSO_Y,							   '  ||																			
					              'TENSO_M,							   '  ||																			
					              'TENSO_D,							   '  ||																			
					              'TAISHOKU_IDO_FLG,					   '  ||																					
					              'DM_FUKA_FLG,						   '  ||																				
					              'MOD_KBN,					                   '  ||
					              'TRK_OPE_CD,                                                 '  ||
					              'TRK_DATE,                                                   '  ||
					              'TRK_PGM_ID,                                                 '  ||
					              'UPD_OPE_CD,                                                 '  ||
					              'UPD_DATE,                                                   '  ||
					              'UPD_PGM_ID)                                                 '  ||
					        'SELECT                                       '  ||                
							       'A.REC_ID AS KJNREC_ID,                                      '  ||            
							       'A.KJN_CD AS KJN_CD,                                         '  ||
							       'NULL AS KJN_CD_YOBI,                                        '  ||          
							       'A.KJN_NM_KANA AS ISHI_NM_KANA,				    '  ||						
							       'A.SEIBETSU_KBN AS SEIBETSU,				    '  ||						
							       'A.BIRTH_GENGO_CD AS BIRTH_GENGO,			    '  ||							
							       'A.BIRTH_WY AS BIRTH_Y,					    '  ||					
							       'A.BIRTH_M AS BIRTH_M,					    '  ||					
							       'A.BIRTH_D AS BIRTH_D,                                       '  ||
							       'NULL AS YOBI_1,						    '  ||				
							       'A.SHUSSHINCHI_RIDAI_CD AS SHUSSHIN_KEN_CD,		    '  ||														
							       'A.KANYU_ISHIKAI_RIDAI_CD AS ISHIKAI_CD,			    '  ||													
							       'A.STNEN_GENGO_CD AS STNEN_GENGO,			    '  ||													
							       'A.STNEN_WY AS STNEN_Y,					    '  ||											
							       'A.SHUSSHINKO_CD AS SHUSSHINKO_SHUSSHINKO_CD,		    '  ||														
							       'A.GAKUBU_SHIKIBETSU_KBN AS SHUSSHINKO_GAKUBU_SKBT_CD,	    '  ||															
							       'A.KAIKIN_KBN AS KAIKIN_KBN,				    '  ||												
							       'A.KAIGYONEN_GENGO_CD AS KAIGYONEN_GENGO,		    '  ||														
							       'A.KAIGYONEN_WY AS KAIGYONEN_Y,				    '  ||												
							       'A.SNRYKMK_CD_1 AS SNRYKMK_1,				    '  ||												
							       'A.SNRYKMK_CD_2 AS SNRYKMK_2,				    '  ||												
							       'A.SNRYKMK_CD_3 AS SNRYKMK_3,				    '  ||												
							       'A.SNRYKMK_CD_4 AS SNRYKMK_4,				    '  ||												
							       'A.SNRYKMK_CD_5 AS SNRYKMK_5,				    '  ||												
							       'A.KEN_CD AS JUSHO_CD_KEN_CD,				    '  ||												
							       'A.SHIKU_CD AS JUSHO_CD_SHIKU_CD,			    '  ||													
							       'A.OAZA_CD AS JUSHO_CD_OAZA_CD,				    '  ||												
							       'A.AZA_CD AS JUSHO_CD_AZA_CD,				    '  ||												
							       'A.ZIP AS ZIP,						    '  ||										
							       'A.JUSHO_HYOJI_NO AS JUSHO_HYOJI_NO,			    '  ||																							
							       'NULL AS YOBI_2,						    '  ||																				
							       'A.JUSHO_KANA_RENKETSU AS JITAKU_JUSHO_KANA,		    '  ||																								
							       'TO_CHAR(A.KEN_NM_KANA_MOJI_SU,''fm09'') AS JUSHO_COUNT_KANA_KEN,	      '  ||																									
							       'TO_CHAR(A.SHIKU_NM_KANA_MOJI_SU,''fm09'') AS JUSHO_COUNT_KANA_SHIKU,    '  ||																										
							       'TO_CHAR(A.OAZA_NM_KANA_MOJI_SU,''fm09'') AS JUSHO_COUNT_KANA_OAZA,      '  ||																										
							       'TO_CHAR(A.AZA_NM_KANA_MOJI_SU,''fm09'') AS JUSHO_COUNT_KANA_AZA,	      '  ||																									
							       'TO_CHAR(A.KEN_NM_KANJI_MOJI_SU,''fm09'') AS JUSHO_COUNT_KANJI_KEN,      '  ||																										
							       'TO_CHAR(A.SHIKU_NM_KANJI_MOJI_SU,''fm09'') AS JUSHO_COUNT_KANJI_SHIKU,  '  ||																										
							       'TO_CHAR(A.OAZA_NM_KANJI_MOJI_SU,''fm09'') AS JUSHO_COUNT_KANJI_OAZA,    '  ||																										
							       'TO_CHAR(A.AZA_NM_KANJI_MOJI_SU,''fm09'') AS JUSHO_COUNT_KANJI_AZA,      '  ||																										
							       'A.TEL AS JITAKU_TEL,						      '  ||																				
							       'A.JUSHOFUMEI_CD AS STATUS_JUSHOFUMEI,				      '  ||																						
							       'A.DEL_YOTEI_RIYU_CD AS STATUS_DEL_YOTEI_RIYU,			      '  ||																							
							       'A.IKKATSU_TRK_FLG AS STATUS_IKKATSU_TRK_FLG,			      '  ||																							
							       'NULL AS STATUS_YOBI,						      '  ||																				
							       'A.TRKNEN_GENGO_CD AS TRKNEN_GENGO,				      '  ||																						
							       'A.TRKNEN_WY AS TRKNEN_Y,					      '  ||																					
							       'NULL AS KOTEI_KOMOKU_YOBI_AREA,					      '  ||																					
							       'A.KJN_NM AS ISHI_NM_KANJI,					      '  ||																					
							       'A.JUSHO_KANJI_RENKETSU AS JITAKU_JUSHO_KANJI,                         '  ||
							       'E.KINMUSAKI_REC_ID AS KINMUSAKI_SHIREC_ID,		      '  ||																								
							       'E.KINMUSAKI_SHI_CD AS KINMUSAKI_SHI_CD,		      '  ||																						
							       'NULL AS KINMUSAKI_SHI_CD_YOBI,					      '  ||																					
							       'B.YAKUSHOKU_CD AS KINMUSAKI_YAKUSHOKU_CD,			      '  ||																							
							       'B.SHOKUI_CD AS KINMUSAKI_SHOKUI,				      '  ||																						
							       'B.SZKBUKA_CD AS KINMUSAKI_SZKBUKA_CD,				      '  ||																						
							       'NULL AS KINMUSAKI_HENKO_UMU_FLG,				      '  ||																						
							       'NULL AS YOBI_3,							      '  ||																			
							       'C.SHI_RN_KANA AS RYKSK_SHI_NM_KANA,				      '  ||																						
							       'C.SHI_RN AS RYKSK_SHI_NM_KANJI,					      '  ||																					
							       'DECODE(B.SZKBUKA_CD, ''9999'', B.NYURYOKU_SZKBUKA_NM_KANA, D.SZKBUKA_NM_KANA) AS SZKBUKA_KANA,		'  ||																								
							       'DECODE(B.SZKBUKA_CD, ''9999'', B.NYURYOKU_SZKBUKA_NM, D.SZKBUKA_NM) AS SZKBUKA_KANJI,			'  ||																							
							       'NULL AS KINMUSAKI_KOMOKU_YOBI_AREA,									'  ||																	
							       'A.CHOFUKU_AITSK_REC_ID AS AITSK_CD_KJNREC_ID,								'  ||																		
							       'A.CHOFUKU_AITSK_KJN_CD AS AITSK_CD_KJN_CD,								'  ||																		
							       'NULL AS AITSK_CD_KJN_CD_YOBI,										'  ||																
							       'SUBSTR(E.MAX_UPD_EIGY_YMD,1,4) AS MOD_SHORI_YMD_Y,							'  ||																			
							       'SUBSTR(E.MAX_UPD_EIGY_YMD,5,2) AS MOD_SHORI_YMD_M,							'  ||																			
							       'SUBSTR(E.MAX_UPD_EIGY_YMD,7,2) AS MOD_SHORI_YMD_D,							'  ||																			
							       'SUBSTR(iTensoYMD,1,4) AS TENSO_Y,									'  ||																	
							       'SUBSTR(iTensoYMD,5,2) AS TENSO_M,									'  ||																	
							       'SUBSTR(iTensoYMD,7,2) AS TENSO_D,									'  ||																	
							       'NULL AS TAISHOKU_IDO_FLG,										'  ||																
							       'B.KINMUSAKI_DM_FUKA_FLG AS DM_FUKA_FLG,									'  ||																	
							       'NULL AS MOD_KBN,												'  ||
							       iOPE_CD  || ','                                                                              ||
									iDATE    || ','                                                                              ||
									iPGM_ID  || ','                                                                              ||
									iOPE_CD  || ','                                                                              ||
									iDATE    || ','                                                                              ||
									iPGM_ID  ||																
							       'FROM TT_TIKY_KJN A                                                                                      '  ||
							       'LEFT OUTER JOIN (SELECT F.KJN_CD,COUNT(NVL(G.TAISHOKU_FLG,0)) AS CNT,SUM(G.TAISHOKU_FLG) AS SM,		'  ||																												
									'MAX(CASE WHEN F.UPD_EIGY_YMD>G.UPD_EIGY_YMD THEN F.UPD_EIGY_YMD ELSE (CASE WHEN G.UPD_EIGY_YMD IS NULL THEN F.UPD_EIGY_YMD ELSE G.UPD_EIGY_YMD END)  END) AS MAX_UPD_EIGY_YMD				'  ||																								
									'FROM TT_TIKY_KJN F																							'  ||						
									'LEFT OUTER JOIN TT_TIKY_KJN_KINMUSAKI G																				'  ||									
									'ON F.REC_ID = G.REC_ID																							'  ||						
									'AND F.KJN_CD = G.KJN_CD																						'  ||					
									'WHERE F.REC_ID = ''01''																							'  ||						
									'AND F.DEL_FLG IS NULL                       '  ||
							                'GROUP BY F.KJN_CD ) E			     '  ||																										
								'ON A.KJN_CD = E.KJN_CD				     '  ||																																																								
								'LEFT OUTER JOIN TT_TIKY_KJN_KINMUSAKI B	     '  ||																													
									'ON A.REC_ID = B.REC_ID			     '  ||																										
									'AND A.KJN_CD = B.KJN_CD                     '  ||
								'LEFT OUTER JOIN TT_TIKY_SHI C					      '  ||																									
									'ON B.KINMUSAKI_REC_ID = C.REC_ID			      '  ||																										
									'AND B.KINMUSAKI_SHI_CD = C.SHI_CD                            '  ||
								'LEFT OUTER JOIN TM_TIKY_HIFG_SSY_SZKBUKA D			      '  ||																											
									'ON B.SZKBUKA_CD = D.SZKBUKA_CD	                              '  ||
								'WHERE A.REC_ID = ''01''						      '  ||					
								'AND A.DEL_FLG IS NULL                                                ';
	   ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);
	   
          -- �񋟗p�e�[�u������S�̃f�[�^(�b��p)���擾����J�[�\��
		  INSERT INTO TD_PA_DCF_KJN(
		  							  KJNREC_ID,                                                    
						              KJN_CD,                                                       
						              KJN_CD_YOBI,                                                    
						              ISHI_NM_KANA,						     				
						              SEIBETSU,						      				
						              BIRTH_GENGO,						     				
						              BIRTH_Y,							     			
						              BIRTH_M,							     			
						              BIRTH_D,                                                      
						              YOBI_1,							     			
						              SHUSSHIN_KEN_CD,						     										
						              ISHIKAI_CD,						     										
						              STNEN_GENGO,						     										
						              STNEN_Y,							     									
						              SHUSSHINKO_SHUSSHINKO_CD,				     												
						              SHUSSHINKO_GAKUBU_SKBT_CD,				     												
						              KAIKIN_KBN,						     										
						              KAIGYONEN_GENGO,						     										
						              KAIGYONEN_Y,						     										
						              SNRYKMK_1,						     										
						              SNRYKMK_2,						     										
						              SNRYKMK_3,						     										
						              SNRYKMK_4,						     										
						              SNRYKMK_5,						     										
						              JUSHO_CD_KEN_CD,						     										
						              JUSHO_CD_SHIKU_CD,					     											
						              JUSHO_CD_OAZA_CD,					     											
						              JUSHO_CD_AZA_CD,						     										
						              ZIP,							     									
						              JUSHO_HYOJI_NO,						     																				
						              YOBI_2,							     																			
						              JITAKU_JUSHO_KANA,					     																					
						              JUSHO_COUNT_KANA_KEN,					     																					
						              JUSHO_COUNT_KANA_SHIKU,					     																					
						              JUSHO_COUNT_KANA_OAZA,					     																					
						              JUSHO_COUNT_KANA_AZA,					     																					
						              JUSHO_COUNT_KANJI_KEN,					     																					
						              JUSHO_COUNT_KANJI_SHIKU,					     																					
						              JUSHO_COUNT_KANJI_OAZA,					     																					
						              JUSHO_COUNT_KANJI_AZA,					     																					
						              JITAKU_TEL,						     																				
						              STATUS_JUSHOFUMEI,					     																					
						              STATUS_DEL_YOTEI_RIYU,					     																					
						              STATUS_IKKATSU_TRK_FLG,					     																					
						              STATUS_YOBI,						     																				
						              TRKNEN_GENGO,						     																				
						              TRKNEN_Y,						     																				
						              KOTEI_KOMOKU_YOBI_AREA,					     																					
						              ISHI_NM_KANJI,						     																				
						              JITAKU_JUSHO_KANJI,					     																					
						              KINMUSAKI_SHIREC_ID,					     																					
						              KINMUSAKI_SHI_CD,					     																					
						              KINMUSAKI_SHI_CD_YOBI,					     																					
						              KINMUSAKI_YAKUSHOKU_CD,					     																					
						              KINMUSAKI_SHOKUI,					     																					
						              KINMUSAKI_SZKBUKA_CD,					     																					
						              KINMUSAKI_HENKO_UMU_FLG,					     																					
						              YOBI_3,							     																			
						              RYKSK_SHI_NM_KANA,					     																					
						              RYKSK_SHI_NM_KANJI,					     																					
						              SZKBUKA_KANA,						     																				
						              SZKBUKA_KANJI,						     																				
						              KINMUSAKI_KOMOKU_YOBI_AREA,				     																						
						              AITSK_CD_KJNREC_ID,					     																					
						              AITSK_CD_KJN_CD,						     																				
						              AITSK_CD_KJN_CD_YOBI,					     																					
						              MOD_SHORI_YMD_Y,						     																				
						              MOD_SHORI_YMD_M,						     																				
						              MOD_SHORI_YMD_D,						     																				
						              TENSO_Y,							     																			
						              TENSO_M,							     																			
						              TENSO_D,							     																			
						              TAISHOKU_IDO_FLG,					     																					
						              DM_FUKA_FLG,						     																				
						              MOD_KBN,					                     
						              TRK_OPE_CD,                                                   
						              TRK_DATE,                                                     
						              TRK_PGM_ID,                                                   
						              UPD_OPE_CD,                                                   
						              UPD_DATE,                                                     
						              UPD_PGM_ID
						            )                                                   										
						      SELECT                                                       
							       A.REC_ID AS KJNREC_ID,                                                  
							       A.KJN_CD AS KJN_CD,
							       NULL AS KJN_CD_YOBI,                                                  
							       A.KJN_NM_KANA AS ISHI_NM_KANA,										
							       A.SEIBETSU_KBN AS SEIBETSU,										
							       A.BIRTH_GENGO_CD AS BIRTH_GENGO,										
							       A.BIRTH_WY AS BIRTH_Y,										
							       A.BIRTH_M AS BIRTH_M,										
							       A.BIRTH_D AS BIRTH_D,
							       NULL AS YOBI_1,										
							       A.SHUSSHINCHI_RIDAI_CD AS SHUSSHIN_KEN_CD,																
							       A.KANYU_ISHIKAI_RIDAI_CD AS ISHIKAI_CD,																
							       A.STNEN_GENGO_CD AS STNEN_GENGO,																
							       A.STNEN_WY AS STNEN_Y,																
							       A.SHUSSHINKO_CD AS SHUSSHINKO_SHUSSHINKO_CD,																
							       A.GAKUBU_SHIKIBETSU_KBN AS SHUSSHINKO_GAKUBU_SKBT_CD,																
							       A.KAIKIN_KBN AS KAIKIN_KBN,																
							       A.KAIGYONEN_GENGO_CD AS KAIGYONEN_GENGO,																
							       A.KAIGYONEN_WY AS KAIGYONEN_Y,																
							       A.SNRYKMK_CD_1 AS SNRYKMK_1,																
							       A.SNRYKMK_CD_2 AS SNRYKMK_2,																
							       A.SNRYKMK_CD_3 AS SNRYKMK_3,																
							       A.SNRYKMK_CD_4 AS SNRYKMK_4,																
							       A.SNRYKMK_CD_5 AS SNRYKMK_5,																
							       A.KEN_CD AS JUSHO_CD_KEN_CD,																
							       A.SHIKU_CD AS JUSHO_CD_SHIKU_CD,																
							       A.OAZA_CD AS JUSHO_CD_OAZA_CD,																
							       A.AZA_CD AS JUSHO_CD_AZA_CD,																
							       A.ZIP AS ZIP,																
							       A.JUSHO_HYOJI_NO AS JUSHO_HYOJI_NO,																										
							       NULL AS YOBI_2,																										
							       A.JUSHO_KANA_RENKETSU AS JITAKU_JUSHO_KANA,																										
							       TO_CHAR(A.KEN_NM_KANA_MOJI_SU,'fm09') AS JUSHO_COUNT_KANA_KEN,																										
							       TO_CHAR(A.SHIKU_NM_KANA_MOJI_SU,'fm09') AS JUSHO_COUNT_KANA_SHIKU,																										
							       TO_CHAR(A.OAZA_NM_KANA_MOJI_SU,'fm09') AS JUSHO_COUNT_KANA_OAZA,																										
							       TO_CHAR(A.AZA_NM_KANA_MOJI_SU,'fm09') AS JUSHO_COUNT_KANA_AZA,																										
							       TO_CHAR(A.KEN_NM_KANJI_MOJI_SU,'fm09') AS JUSHO_COUNT_KANJI_KEN,																										
							       TO_CHAR(A.SHIKU_NM_KANJI_MOJI_SU,'fm09') AS JUSHO_COUNT_KANJI_SHIKU,																										
							       TO_CHAR(A.OAZA_NM_KANJI_MOJI_SU,'fm09') AS JUSHO_COUNT_KANJI_OAZA,																										
							       TO_CHAR(A.AZA_NM_KANJI_MOJI_SU,'fm09') AS JUSHO_COUNT_KANJI_AZA,																										
							       A.TEL AS JITAKU_TEL,																										
							       A.JUSHOFUMEI_CD AS STATUS_JUSHOFUMEI,																										
							       A.DEL_YOTEI_RIYU_CD AS STATUS_DEL_YOTEI_RIYU,																										
							       A.IKKATSU_TRK_FLG AS STATUS_IKKATSU_TRK_FLG,																										
							       NULL AS STATUS_YOBI,																										
							       A.TRKNEN_GENGO_CD AS TRKNEN_GENGO,																										
							       A.TRKNEN_WY AS TRKNEN_Y,																										
							       NULL AS KOTEI_KOMOKU_YOBI_AREA,																										
							       A.KJN_NM AS ISHI_NM_KANJI,																										
							       A.JUSHO_KANJI_RENKETSU AS JITAKU_JUSHO_KANJI,
							       -- ������2012/10/09 CP000114�̑Ή�
							       E.KINMUSAKI_REC_ID AS KINMUSAKI_SHIREC_ID,
							       E.KINMUSAKI_SHI_CD AS KINMUSAKI_SHI_CD,
							       --NVL(B.KINMUSAKI_REC_ID,'00') AS KINMUSAKI_SHIREC_ID,																										
							       --NVL(B.KINMUSAKI_SHI_CD,'9999999') AS KINMUSAKI_SHI_CD,																								
							       -- ������2012/10/09 CP000114�̑Ή�
							       NULL AS KINMUSAKI_SHI_CD_YOBI,																										
							       B.YAKUSHOKU_CD AS KINMUSAKI_YAKUSHOKU_CD,																										
							       B.SHOKUI_CD AS KINMUSAKI_SHOKUI,																										
							       B.SZKBUKA_CD AS KINMUSAKI_SZKBUKA_CD,																										
							       NULL AS KINMUSAKI_HENKO_UMU_FLG,																										
							       NULL AS YOBI_3,																										
							       C.SHI_RN_KANA AS RYKSK_SHI_NM_KANA,																										
							       C.SHI_RN AS RYKSK_SHI_NM_KANJI,																										
							       DECODE(B.SZKBUKA_CD, '9999', B.NYURYOKU_SZKBUKA_NM_KANA, SUBSTR(D.SZKBUKA_NM_KANA, 1, 20)) AS SZKBUKA_KANA,	
							       DECODE(B.SZKBUKA_CD, '9999', B.NYURYOKU_SZKBUKA_NM, SUBSTR(D.SZKBUKA_NM, 1, 15)) AS SZKBUKA_KANJI,	
							       NULL AS KINMUSAKI_KOMOKU_YOBI_AREA,																										
							       A.CHOFUKU_AITSK_REC_ID AS AITSK_CD_KJNREC_ID,																										
							       A.CHOFUKU_AITSK_KJN_CD AS AITSK_CD_KJN_CD,																										
							       NULL AS AITSK_CD_KJN_CD_YOBI,																										
							       SUBSTR(E.MAX_UPD_EIGY_YMD,1,4) AS MOD_SHORI_YMD_Y,																										
							       SUBSTR(E.MAX_UPD_EIGY_YMD,5,2) AS MOD_SHORI_YMD_M,																										
							       SUBSTR(E.MAX_UPD_EIGY_YMD,7,2) AS MOD_SHORI_YMD_D,																										
							       SUBSTR(iTensoYMD,1,4) AS TENSO_Y,																										
							       SUBSTR(iTensoYMD,5,2) AS TENSO_M,																										
							       SUBSTR(iTensoYMD,7,2) AS TENSO_D,																										
							       NULL AS TAISHOKU_IDO_FLG,																										
							       B.KINMUSAKI_DM_FUKA_FLG AS DM_FUKA_FLG,																										
							       NULL AS MOD_KBN,
							        iOPE_CD,
									iDATE,
									iPGM_ID,
									iOPE_CD,
									iDATE,
									iPGM_ID																											
						       FROM TT_TIKY_KJN A
						       -- ������2012/10/09 CP000114�̑Ή�
						       LEFT OUTER JOIN (SELECT
						       						DISTINCT
						       						TT.REC_ID,
						       						TT.KJN_CD,
						       						TT.KINMUSAKI_REC_ID,
						       						TT.KINMUSAKI_SHI_CD,
						       						TT.MAX_UPD_EIGY_YMD
						       					FROM (
								       					SELECT
								       						  TTK.REC_ID,
								       						  TTK.KJN_CD,
								       						  CASE
								       						  	WHEN TTKK.REC_ID IS NULL THEN
								       						  		'00'
								       						  	WHEN TTKK.REC_ID IS NOT NULL AND TTK.CNT = TTK.SM THEN
								       						  		'00'
								       						  	WHEN TTKK.REC_ID IS NOT NULL AND TTK.CNT <> TTK.SM AND TTKK.TAISHOKU_FLG IS NOT NULL THEN
								       						  		'99'  -- �ސE�s�v�ȃ��R�[�h�p��`
								       						  	ELSE
								       						  		TTKK.KINMUSAKI_REC_ID
								       						  END AS KINMUSAKI_REC_ID,
								       						  CASE
								       						  	WHEN TTKK.REC_ID IS NULL THEN
								       						  		'9999999'
								       						  	WHEN TTKK.REC_ID IS NOT NULL AND TTK.CNT = TTK.SM THEN
								       						  		'9999999'
								       						  	WHEN TTKK.REC_ID IS NOT NULL AND TTK.CNT <> TTK.SM AND TTKK.TAISHOKU_FLG IS NOT NULL THEN
								       						  		'9999999'
								       						  	ELSE
								       						  		TTKK.KINMUSAKI_SHI_CD
								       						  END AS KINMUSAKI_SHI_CD,
								       						  TTK.MAX_UPD_EIGY_YMD
								       					FROM (	SELECT F.REC_ID,
								       								   F.KJN_CD,
										       						   SUM(DECODE(G.TAISHOKU_FLG,'1',1,0)) AS CNT,
										       						   COUNT(1) AS SM,																														
																       MAX(CASE 
																       		WHEN NVL(F.UPD_EIGY_YMD, '19700101') > NVL(G.UPD_EIGY_YMD, '19700101')
																       		THEN F.UPD_EIGY_YMD 
																       		ELSE G.UPD_EIGY_YMD END
																       	  ) AS MAX_UPD_EIGY_YMD																												
																FROM TT_TIKY_KJN F																													
																LEFT OUTER JOIN TT_TIKY_KJN_KINMUSAKI G																													
																	ON F.REC_ID = G.REC_ID																													
																	AND F.KJN_CD = G.KJN_CD																											
																WHERE F.REC_ID = '01'																													
																	AND F.DEL_FLG IS NULL
														        GROUP BY 
														        		F.REC_ID,
														        		F.KJN_CD
														    ) TTK
														LEFT OUTER JOIN TT_TIKY_KJN_KINMUSAKI TTKK
															ON TTK.REC_ID = TTKK.REC_ID																													
														    AND TTK.KJN_CD = TTKK.KJN_CD
													) TT
												WHERE TT.KINMUSAKI_REC_ID <> '99'	
										        ) E																													
							ON A.KJN_CD = E.KJN_CD
							AND A.REC_ID = E.REC_ID																																																												
							LEFT OUTER JOIN TT_TIKY_KJN_KINMUSAKI B																														
								ON E.REC_ID = B.REC_ID																													
								AND E.KJN_CD = B.KJN_CD
						        AND E.KINMUSAKI_REC_ID = B.KINMUSAKI_REC_ID
						        AND E.KINMUSAKI_SHI_CD = B.KINMUSAKI_SHI_CD       
							LEFT OUTER JOIN TT_TIKY_SHI C																														
								ON B.KINMUSAKI_REC_ID = C.REC_ID																													
								AND B.KINMUSAKI_SHI_CD = C.SHI_CD
							LEFT OUTER JOIN TM_TIKY_HIFG_SSY_SZKBUKA D																														
								ON B.SZKBUKA_CD = D.SZKBUKA_CD	
							WHERE A.REC_ID = '01'											
							AND A.DEL_FLG IS NULL;
							-- ������2012/10/09 CP000114�̑Ή�

            --�b��_�S��_���p��~�iDCF��t�j�̓o�^
            EXECUTE_SQL :=  'INSERT INTO TD_PA_DCF_KJN_TIS(          '  ||
									              'KJNREC_ID,                                            '  ||
									              'KJN_CD,						     '  ||						
									              'KJN_CD_YOBI,					     '  ||							
									              'RIYOTEISHI_KBN,					     '  ||							
									              'RIYOTEISHI_RIYU,					     '  ||							
									              'TRK_YMD,						     '  ||						
									              'KAIJO_YMD,					     '  ||							
									              'TENSO_Y,						     '  ||						
									              'TENSO_M,						     '  ||						
									              'TENSO_D,						     '  ||						
									              'MENTE_Y,						     '  ||						
									              'MENTE_M,						     '  ||						
									              'MENTE_D,						     '  ||						
									              'MOD_KBN,		                                     '  ||	
									              'TRK_OPE_CD,                                           '  ||
									              'TRK_DATE,                                             '  ||
									              'TRK_PGM_ID,                                           '  ||
									              'UPD_OPE_CD,                                           '  ||
									              'UPD_DATE,                                             '  ||
									              'UPD_PGM_ID)                                           '  ||
							            'SELECT                                   '  ||                    
										       'REC_ID AS KJNREC_ID,                                    '  ||             
										       'KJN_CD AS KJN_CD,					'  ||							
										       'NULL AS KJN_CD_YOBI,					'  ||							
										       'RIYOTEISHI_KBN_CD AS RIYOTEISHI_KBN,			'  ||									
										       'RIYOTEISHI_RIYU_CD AS RIYOTEISHI_RIYU,			'  ||									
										       'RIYOTEISHI_TRK_YMD AS TRK_YMD,				'  ||								
										       'RIYOTEISHI_KAIJO_YMD AS KAIJO_YMD,			'  ||									
										       'SUBSTR(iTensoYMD,1,4) AS TENSO_Y,			'  ||									
										       'SUBSTR(iTensoYMD,5,2) AS TENSO_M,			'  ||									
										       'SUBSTR(iTensoYMD,7,2) AS TENSO_D,			'  ||									
										       'SUBSTR(UPD_EIGY_YMD,1,4) AS MENTE_Y,			'  ||									
										       'SUBSTR(UPD_EIGY_YMD,5,2) AS MENTE_M,			'  ||									
										       'SUBSTR(UPD_EIGY_YMD,7,2) AS MENTE_D,			'  ||									
										       'NULL AS MOD_KBN,						'  ||
										       	iOPE_CD  || ','                                                                              ||
												iDATE    || ','                                                                              ||
												iPGM_ID  || ','                                                                              ||
												iOPE_CD  || ','                                                                              ||
												iDATE    || ','                                                                              ||
												iPGM_ID  ||									
										       'FROM TT_TIKY_KJN                                        '  ||                                   
										       'WHERE REC_ID = ''01''                                   '  ||
										       'AND DEL_FLG IS NULL                                     '  ||
										       'AND RIYOTEISHI_KBN_CD IS NOT NULL  ';  

	  ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);
	  
             -- �b��_�S��_���p��~�iDCF��t�j�̓o�^��o�^����
             INSERT INTO TD_PA_DCF_KJN_TIS(
             								  KJNREC_ID,                                             
								              KJN_CD,						      						
								              KJN_CD_YOBI,					      							
								              RIYOTEISHI_KBN,					      							
								              RIYOTEISHI_RIYU,					      							
								              TRK_YMD,						      						
								              KAIJO_YMD,					      							
								              TENSO_Y,						      						
								              TENSO_M,						      						
								              TENSO_D,						      						
								              MENTE_Y,						      						
								              MENTE_M,						      						
								              MENTE_D,						      						
								              MOD_KBN,		                                      	
								              TRK_OPE_CD,                                            
								              TRK_DATE,                                              
								              TRK_PGM_ID,                                            
								              UPD_OPE_CD,                                            
								              UPD_DATE,                                              
								              UPD_PGM_ID
								           )                                            
								    SELECT                                                       
								       REC_ID AS KJNREC_ID,                                                 
								       KJN_CD AS KJN_CD,												
								       NULL AS KJN_CD_YOBI,												
								       RIYOTEISHI_KBN_CD AS RIYOTEISHI_KBN,												
								       RIYOTEISHI_RIYU_CD AS RIYOTEISHI_RIYU,												
								       RIYOTEISHI_TRK_YMD AS TRK_YMD,												
								       RIYOTEISHI_KAIJO_YMD AS KAIJO_YMD,												
								       SUBSTR(iTensoYMD,1,4) AS TENSO_Y,												
								       SUBSTR(iTensoYMD,5,2) AS TENSO_M,												
								       SUBSTR(iTensoYMD,7,2) AS TENSO_D,												
								       SUBSTR(UPD_EIGY_YMD,1,4) AS MENTE_Y,												
								       SUBSTR(UPD_EIGY_YMD,5,2) AS MENTE_M,												
								       SUBSTR(UPD_EIGY_YMD,7,2) AS MENTE_D,												
								       NULL AS MOD_KBN,
								       iOPE_CD,
										iDATE,
										iPGM_ID,
										iOPE_CD,
										iDATE,
										iPGM_ID													     
								  FROM TT_TIKY_KJN                                                                                
								  WHERE REC_ID = '01'                                   
								  AND DEL_FLG IS NULL 
								  AND RIYOTEISHI_KBN_CD IS NOT NULL;                                  
 
			 --�b��_�S��_�w�����̓o�^
            EXECUTE_SQL :=  'INSERT INTO TD_PA_DCF_KJN_SENMONI(             '  ||                                  												
									              'DCF_CD_REC_ID,                                               '  ||  
									              'DCF_CD_KJN_CD,						    '  ||									
									              'DCF_CD_YOBI,						    '  ||									
									              'SENMONI_CD,						    '  ||									
									              'SENMONI_FLG,						    '  ||									
									              'SENMONI_KEISAI_D_Y,					    '  ||										
									              'SENMONI_KEISAI_D_M,					    '  ||										
									              'SENMONI_KEISAI_D_D,					    '  ||										
									              'NINTEII_FLG,						    '  ||									
									              'NINTEII_KEISAI_D_Y,					    '  ||										
									              'NINTEII_KEISAI_D_M,					    '  ||										
									              'NINTEII_KEISAI_D_D,					    '  ||										
									              'SHIDOI_FLG,						    '  ||									
									              'SHIDOI_KEISAI_D_Y,					    '  ||										
									              'SHIDOI_KEISAI_D_M,					    '  ||										
									              'SHIDOI_KEISAI_D_D,					    '  ||										
									              'YOBI,                                                        '  ||                                                                                                                                        															
									              'TENSO_Y,							    '  ||								
									              'TENSO_M,							    '  ||								
									              'TENSO_D,							    '  ||								
									              'MENTE_Y,							    '  ||								
									              'MENTE_M,							    '  ||								
									              'MENTE_D,							    '  ||								
									              'SENMONI_MENTE_KBN,					    '  ||										
									              'MOD_KBN,                                                     '  ||
									              'TRK_OPE_CD,                                                  '  ||
									              'TRK_DATE,                                                    '  ||
									              'TRK_PGM_ID,                                                  '  ||
									              'UPD_OPE_CD,                                                  '  ||
									              'UPD_DATE,                                                    '  ||
									              'UPD_PGM_ID)                                                  '  ||
								            'SELECT                                           '  ||            
									       'A.REC_ID AS DCF_CD_REC_ID,                                       '  ||          
									       'A.KJN_CD AS DCF_CD_KJN_CD,					 '  ||										
									       'NULL AS DCF_CD_YOBI,						 '  ||									
									       'B.SENMONI_CD AS SENMONI_CD,					 '  ||										
									       'B.SENMONI_FLG AS SENMONI_FLG,					 '  ||										
									       'SUBSTR(B.SENMONI_KEISAI_YMD, 1, 4) AS SENMONI_KEISAI_D_Y,	 '  ||														
									       'SUBSTR(B.SENMONI_KEISAI_YMD, 5, 2) AS SENMONI_KEISAI_D_M,	 '  ||														
									       'SUBSTR(B.SENMONI_KEISAI_YMD, 7, 2) AS SENMONI_KEISAI_D_D,	 '  ||														
									       'B.NINTEII_FLG AS NINTEII_FLG,					 '  ||										
									       'SUBSTR(B.NINTEII_KEISAI_YMD, 1, 4) AS NINTEII_KEISAI_D_Y,	 '  ||														
									       'SUBSTR(B.NINTEII_KEISAI_YMD, 5, 2) AS NINTEII_KEISAI_D_M,	 '  ||														
									       'SUBSTR(B.NINTEII_KEISAI_YMD, 7, 2) AS NINTEII_KEISAI_D_D,	 '  ||														
									       'B.SHIDOI_FLG AS SHIDOI_FLG,					 '  ||										
									       'SUBSTR(B.SHIDOI_KEISAI_YMD, 1, 4) AS SHIDOI_KEISAI_D_Y,		 '  ||													
									       'SUBSTR(B.SHIDOI_KEISAI_YMD, 5, 2) AS SHIDOI_KEISAI_D_M,		 '  ||													
									       'SUBSTR(B.SHIDOI_KEISAI_YMD, 7, 2) AS SHIDOI_KEISAI_D_D,		 '  ||													
									       'NULL AS YOBI,                                                    '  ||                                                                                                                                          											
									       'SUBSTR(iTensoYMD,1,4) AS TENSO_Y,				 '  ||											
									       'SUBSTR(iTensoYMD,5,2) AS TENSO_M,				 '  ||											
									       'SUBSTR(iTensoYMD,7,2) AS TENSO_D,				 '  ||											
									       'SUBSTR(E.MAX_UPD_EIGY_YMD, 1, 4) AS MENTE_Y,			 '  ||												
									       'SUBSTR(E.MAX_UPD_EIGY_YMD, 5, 2) AS MENTE_M,			 '  ||												
									       'SUBSTR(E.MAX_UPD_EIGY_YMD, 7, 2) AS MENTE_D,			 '  ||												
									       'NULL AS SENMONI_MENTE_KBN,					 '  ||										
									       'NULL AS MOD_KBN,                                                  '  ||
									       	iOPE_CD  || ','                                                                              ||
											iDATE    || ','                                                                              ||
											iPGM_ID  || ','                                                                              ||
											iOPE_CD  || ','                                                                              ||
											iDATE    || ','                                                                              ||
											iPGM_ID  ||			
									       'FROM TT_TIKY_KJN A                                               '  ||
										  'INNER JOIN TT_TIKY_KJN_SENMONI B				 '  ||														
											'ON A.REC_ID = B.REC_ID					 '  ||												
											'AND A.KJN_CD = B.KJN_CD				 '  ||													
											'AND B.SOSHITSU_FLG IS NULL				 '  ||													
										  'LEFT OUTER JOIN (SELECT F.KJN_CD,				 '  ||														
											'MAX(CASE WHEN G.UPD_EIGY_YMD IS NULL THEN F.UPD_EIGY_YMD ELSE G.UPD_EIGY_YMD END) AS MAX_UPD_EIGY_YMD				'  ||													
											'FROM TT_TIKY_KJN F														'  ||			
											'LEFT OUTER JOIN TT_TIKY_KJN_SENMONI G												'  ||					
											'ON F.REC_ID = G.REC_ID														'  ||			
											'AND F.KJN_CD = G.KJN_CD													'  ||				
									                'WHERE F.REC_ID = ''01''														'  ||			
											'AND F.DEL_FLG IS NULL														'  ||			
											'GROUP BY F.KJN_CD ) E														'  ||			
										  'ON A.KJN_CD = E.KJN_CD															'  ||			
									        'WHERE A.REC_ID = ''01''                                  '  ||
									        'AND A.DEL_FLG IS NULL      '; 

	  ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);
			
		   --�b��_�S��_�w�����̓o�^��o�^����
		   INSERT INTO TD_PA_DCF_KJN_SENMONI(
		   									 DCF_CD_REC_ID,                                                  
								             DCF_CD_KJN_CD,						     									
								             DCF_CD_YOBI,						     									
								             SENMONI_CD,						     									
								             SENMONI_FLG,						     									
								             SENMONI_KEISAI_D_Y,					     										
								             SENMONI_KEISAI_D_M,					     										
								             SENMONI_KEISAI_D_D,					     										
								             NINTEII_FLG,						     									
								             NINTEII_KEISAI_D_Y,					     										
								             NINTEII_KEISAI_D_M,					     										
								             NINTEII_KEISAI_D_D,					     										
								             SHIDOI_FLG,						     									
								             SHIDOI_KEISAI_D_Y,					     										
								             SHIDOI_KEISAI_D_M,					     										
								             SHIDOI_KEISAI_D_D,					     										
								             YOBI,                                                                                                                                                                                                 															
								             TENSO_Y,							     								
								             TENSO_M,							     								
								             TENSO_D,							     								
								             MENTE_Y,							     								
								             MENTE_M,							     								
								             MENTE_D,							     								
								             SENMONI_MENTE_KBN,					     										
								             MOD_KBN,                                                      
								             TRK_OPE_CD,                                                   
								             TRK_DATE,                                                     
								             TRK_PGM_ID,                                                   
								             UPD_OPE_CD,                                                   
								             UPD_DATE,                                                     
								             UPD_PGM_ID
								            )                                                   
								   SELECT                                                       
								       A.REC_ID AS DCF_CD_REC_ID,                                                 
								       A.KJN_CD AS DCF_CD_KJN_CD,															
								       NULL AS DCF_CD_YOBI,															
								       B.SENMONI_CD AS SENMONI_CD,															
								       B.SENMONI_FLG AS SENMONI_FLG,															
								       SUBSTR(B.SENMONI_KEISAI_YMD, 1, 4) AS SENMONI_KEISAI_D_Y,															
								       SUBSTR(B.SENMONI_KEISAI_YMD, 5, 2) AS SENMONI_KEISAI_D_M,															
								       SUBSTR(B.SENMONI_KEISAI_YMD, 7, 2) AS SENMONI_KEISAI_D_D,															
								       B.NINTEII_FLG AS NINTEII_FLG,															
								       SUBSTR(B.NINTEII_KEISAI_YMD, 1, 4) AS NINTEII_KEISAI_D_Y,															
								       SUBSTR(B.NINTEII_KEISAI_YMD, 5, 2) AS NINTEII_KEISAI_D_M,															
								       SUBSTR(B.NINTEII_KEISAI_YMD, 7, 2) AS NINTEII_KEISAI_D_D,															
								       B.SHIDOI_FLG AS SHIDOI_FLG,															
								       SUBSTR(B.SHIDOI_KEISAI_YMD, 1, 4) AS SHIDOI_KEISAI_D_Y,															
								       SUBSTR(B.SHIDOI_KEISAI_YMD, 5, 2) AS SHIDOI_KEISAI_D_M,															
								       SUBSTR(B.SHIDOI_KEISAI_YMD, 7, 2) AS SHIDOI_KEISAI_D_D,															
								       NULL AS YOBI,                                                                                                                                                                                             											
								       SUBSTR(iTensoYMD,1,4) AS TENSO_Y,															
								       SUBSTR(iTensoYMD,5,2) AS TENSO_M,															
								       SUBSTR(iTensoYMD,7,2) AS TENSO_D,															
								       SUBSTR(E.MAX_UPD_EIGY_YMD, 1, 4) AS MENTE_Y,															
								       SUBSTR(E.MAX_UPD_EIGY_YMD, 5, 2) AS MENTE_M,															
								       SUBSTR(E.MAX_UPD_EIGY_YMD, 7, 2) AS MENTE_D,															
								       NULL AS SENMONI_MENTE_KBN,															
								       NULL AS MOD_KBN,
								       	iOPE_CD,
										iDATE,
										iPGM_ID,
										iOPE_CD,
										iDATE,
										iPGM_ID	
								  FROM TT_TIKY_KJN A    
								  INNER JOIN TT_TIKY_KJN_SENMONI B																		
										ON A.REC_ID = B.REC_ID																	
										AND A.KJN_CD = B.KJN_CD																	
										AND B.SOSHITSU_FLG IS NULL																	
								  LEFT OUTER JOIN (SELECT F.KJN_CD,																		
										MAX(CASE WHEN NVL(F.UPD_EIGY_YMD, '19700101') > NVL(G.UPD_EIGY_YMD, '19700101')
											 THEN F.UPD_EIGY_YMD ELSE G.UPD_EIGY_YMD END) AS MAX_UPD_EIGY_YMD																	
										FROM TT_TIKY_KJN F																	
										LEFT OUTER JOIN TT_TIKY_KJN_SENMONI G																	
										ON F.REC_ID = G.REC_ID																	
										AND F.KJN_CD = G.KJN_CD																	
								        WHERE F.REC_ID = '01'																	
										AND F.DEL_FLG IS NULL																	
										GROUP BY F.KJN_CD ) E																	
									ON A.KJN_CD = E.KJN_CD																			                                                                         
								  WHERE A.REC_ID = '01'                                  
								  AND A.DEL_FLG IS NULL;                                  
        END IF; 
      ELSIF iShimeKind = 4 OR iShimeKind = 5 THEN
            
         -- �Q����O���C�A�E�g
        
          --�b��_�S��_2����O_DCF��t�e�[�u���̃f�[�^���N���A����B
          EXECUTE_SQL := 'TRUNCATE TABLE ' || vSchemaNm || '.' || 'TD_PA_GEN_DCF_KJN';
          EXECUTE IMMEDIATE EXECUTE_SQL;
          ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);
          
          --�b��_�S��_2����O_DCF��t�̓o�^
            EXECUTE_SQL :=  'INSERT INTO TD_PA_GEN_DCF_KJN(           '  ||
								              'KJNREC_ID,                                             '  ||
								              'KJN_CD,						      '  ||																							
								              'KJN_CD_YOBI,					      '  ||	 																							
								              'ISHI_NM_KANA,					      '  ||																								
								              'SEIBETSU,					      '  ||																								
								              'BIRTH_GENGO,					      '  ||																								
								              'BIRTH_Y,						      '  ||																							
								              'BIRTH_M,						      '  ||																							
								              'BIRTH_D,						      '  ||																							
								              'YOBI_1,						      '  ||																							
								              'SHUSSHIN_KEN_CD,					      '  ||																								
								              'ISHIKAI_CD,					      '  ||																								
								              'STNEN_GENGO,					      '  ||																								
								              'STNEN_Y,						      '  ||																							
								              'SHUSSHINKO_SHUSSHINKO_CD,			      '  ||																										
								              'SHUSSHINKO_GAKUBU_SKBT_CD,			      '  ||																										
								              'KAIKIN_KBN,					      '  ||																								
								              'KAIGYONEN_GENGO,					      '  ||																								
								              'KAIGYONEN_Y,					      '  ||																								
								              'SNRYKMK_1,					      '  ||																								
								              'SNRYKMK_2,					      '  ||																								
								              'SNRYKMK_3,					      '  ||																								
								              'SNRYKMK_4,					      '  ||																								
								              'SNRYKMK_5,					      '  ||																								
								              'JUSHO_CD_KEN_CD,					      '  ||																								
								              'JUSHO_CD_SHIKU_CD,				      '  ||																									
								              'JUSHO_CD_OAZA_CD,				      '  ||																									
								              'JUSHO_CD_AZA_CD,					      '  ||																								
								              'ZIP,						      '  ||																							
								              'JUSHO_HYOJI_NO,					      '  ||																								
								              'YOBI_2,						      '  ||																							
								              'JITAKU_JUSHO_KANA,				      '  ||																									
								              'JUSHO_COUNT_KANA_KEN,				      '  ||																									
								              'JUSHO_COUNT_KANA_SHIKU,				      '  ||																									
								              'JUSHO_COUNT_KANA_OAZA,				      '  ||																									
								              'JUSHO_COUNT_KANJI_KEN,				      '  ||																									
								              'JUSHO_COUNT_KANJI_SHIKU,				      '  ||																									
								              'JUSHO_COUNT_KANJI_OAZA,				      '  ||																									
								              'JITAKU_TEL,					      '  ||																								
								              'STATUS_JUSHOFUMEI,				      '  ||																									
								              'STATUS_DEL_YOTEI_RIYU,				      '  ||																									
								              'STATUS_YOBI,					      '  ||																								
								              'KOTEI_KOMOKU_YOBI_AREA,				      '  ||																									
								              'ISHI_NM_KANJI,					      '  ||																								
								              'JITAKU_JUSHO_KANJI,				      '  ||																									
								              'KINMUSAKI_SHIREC_ID,				      '  ||																									
								              'KINMUSAKI_SHI_CD,				      '  ||																									
								              'KINMUSAKI_SHI_CD_YOBI,				      '  ||																									
								              'KINMUSAKI_YAKUSHOKU_CD,				      '  ||																									
								              'KINMUSAKI_SHOKUI,				      '  ||																									
								              'KINMUSAKI_SZKBUKA_CD,				      '  ||																									
								              'YOBI_3,						      '  ||																							
								              'RYKSK_SHI_NM_KANA,				      '  ||																									
								              'RYKSK_SHI_NM_KANJI,				      '  ||																									
								              'SZKBUKA_KANA,					      '  ||																								
								              'SZKBUKA_KANJI,					      '  ||																								
								              'KINMUSAKI_KOMOKU_YOBI_AREA,			      '  ||																										
								              'AITSK_CD_KJNREC_ID,				      '  ||																									
								              'AITSK_CD_KJN_CD,					      '  ||																								
								              'AITSK_CD_KJN_CD_YOBI,				      '  ||																									
								              'MOD_SHORI_YMD_Y,					      '  ||																								
								              'MOD_SHORI_YMD_M,					      '  ||																								
								              'MOD_SHORI_YMD_D,					      '  ||																								
								              'MOD_KBN,                                               '  ||
								              'TRK_OPE_CD,                                            '  ||
								              'TRK_DATE,                                              '  ||
								              'TRK_PGM_ID,                                            '  ||
								              'UPD_OPE_CD,                                            '  ||
								              'UPD_DATE,                                              '  ||
								              'UPD_PGM_ID)                                            '  ||
				            	'SELECT                                       '  ||                
										'A.REC_ID AS KJNREC_ID,					     '  ||																								
										'A.KJN_CD AS KJN_CD,					     '  ||																								
										'NULL AS KJN_CD_YOBI,					     '  ||																								
										'A.KJN_NM_KANA AS ISHI_NM_KANA,				     '  ||																									
										'A.SEIBETSU_KBN AS SEIBETSU,				     '  ||																									
										'A.BIRTH_GENGO_CD AS BIRTH_GENGO,			     '  ||																										
										'A.BIRTH_WY AS BIRTH_Y,					     '  ||																								
										'A.BIRTH_M AS BIRTH_M,					     '  ||																								
										'A.BIRTH_D AS BIRTH_D,					     '  ||																								
									        'NULL AS YOBI_1,					     '  ||																								
										'A.SHUSSHINCHI_RIDAI_CD AS SHUSSHIN_KEN_CD,		     '  ||																											
										'A.KANYU_ISHIKAI_RIDAI_CD AS ISHIKAI_CD,		     '  ||																											
										'A.STNEN_GENGO_CD AS STNEN_GENGO,			     '  ||																										
										'A.STNEN_WY AS STNEN_Y,					     '  ||																								
										'A.SHUSSHINKO_CD AS SHUSSHINKO_SHUSSHINKO_CD,		     '  ||																											
										'A.GAKUBU_SHIKIBETSU_KBN AS SHUSSHINKO_GAKUBU_SKBT_CD,	     '  ||																												
										'A.KAIKIN_KBN AS KAIKIN_KBN,				     '  ||																									
										'A.KAIGYONEN_GENGO_CD AS KAIGYONEN_GENGO,		     '  ||																											
										'A.KAIGYONEN_WY AS KAIGYONEN_Y,				     '  ||																									
										'A.SNRYKMK_CD_1 AS SNRYKMK_1,				     '  ||																									
										'A.SNRYKMK_CD_2 AS SNRYKMK_2,				     '  ||																									
										'A.SNRYKMK_CD_3 AS SNRYKMK_3,				     '  ||																									
										'A.SNRYKMK_CD_4 AS SNRYKMK_4,				     '  ||																									
										'A.SNRYKMK_CD_5 AS SNRYKMK_5,				     '  ||																									
										'A.KEN_CD AS JUSHO_CD_KEN_CD,				     '  ||																									
										'A.SHIKU_CD AS JUSHO_CD_SHIKU_CD,			     '  ||																										
										'A.OAZA_CD AS JUSHO_CD_OAZA_CD,				     '  ||																									
										'A.AZA_CD AS JUSHO_CD_AZA_CD,				     '  ||																									
										'A.ZIP AS ZIP,						     '  ||																							
										'A.JUSHO_HYOJI_NO AS JUSHO_HYOJI_NO,			     '  ||																										
										'NULL AS YOBI_2,					     '  ||																								
										'A.JUSHO_KANA_RENKETSU AS JITAKU_JUSHO_KANA,		     '  ||																											
										'TO_CHAR(A.KEN_NM_KANA_MOJI_SU,''fm09'') AS JUSHO_COUNT_KANA_KEN,			'  ||																										
										'TO_CHAR(A.SHIKU_NM_KANA_MOJI_SU,''fm09'') AS JUSHO_COUNT_KANA_SHIKU,		'  ||																											
										'TO_CHAR(A.OAZA_NM_KANA_MOJI_SU,''fm09'') AS JUSHO_COUNT_KANA_OAZA,		'  ||																											
										'TO_CHAR(A.KEN_NM_KANJI_MOJI_SU,''fm09'') AS JUSHO_COUNT_KANJI_KEN,		'  ||																											
										'TO_CHAR(A.SHIKU_NM_KANJI_MOJI_SU,''fm09'') AS JUSHO_COUNT_KANJI_SHIKU,		'  ||																											
										'TO_CHAR(A.OAZA_NM_KANJI_MOJI_SU,''fm09'') AS JUSHO_COUNT_KANJI_OAZA,		'  ||																											
										'A.TEL AS JITAKU_TEL,								'  ||																					
										'A.JUSHOFUMEI_CD AS STATUS_JUSHOFUMEI,						'  ||																							
										'A.DEL_YOTEI_RIYU_CD AS STATUS_DEL_YOTEI_RIYU,					'  ||																								
										'A.IKKATSU_TRK_FLG AS STATUS_YOBI,						'  ||																							
										'A.TRKNEN_GENGO_CD||A.TRKNEN_WY AS KOTEI_KOMOKU_YOBI_AREA,			'  ||																										
										'A.KJN_NM AS ISHI_NM_KANJI,							'  ||																						
										'A.JUSHO_KANJI_RENKETSU AS JITAKU_JUSHO_KANJI,					'  ||																								
										'NVL(B.KINMUSAKI_REC_ID,''00'') AS KINMUSAKI_SHIREC_ID,				'  ||																									
										'NVL(B.KINMUSAKI_SHI_CD,''9999999'') AS KINMUSAKI_SHI_CD,				'  ||																									
										'NULL AS KINMUSAKI_SHI_CD_YOBI,							'  ||																						
										'B.YAKUSHOKU_CD AS KINMUSAKI_YAKUSHOKU_CD,					'  ||																								
										'B.SHOKUI_CD AS KINMUSAKI_SHOKUI,						'  ||																							
										'B.SZKBUKA_CD AS KINMUSAKI_SZKBUKA_CD,						'  ||																							
										'NULL AS YOBI_3,								'  ||																					
										'C.SHI_RN_KANA AS RYKSK_SHI_NM_KANA,						'  ||																							
										'C.SHI_RN AS RYKSK_SHI_NM_KANJI,						'  ||																							
										'DECODE(B.SZKBUKA_CD, ''9999'', B.NYURYOKU_SZKBUKA_NM_KANA, D.SZKBUKA_NM_KANA) AS SZKBUKA_KANA,		'  ||																											
										'DECODE(B.SZKBUKA_CD, ''9999'', B.NYURYOKU_SZKBUKA_NM, D.SZKBUKA_NM) AS SZKBUKA_KANJI,			'  ||																										
										'NULL AS KINMUSAKI_KOMOKU_YOBI_AREA,									'  ||																				
										'NULL AS AITSK_CD_KJNREC_ID,										'  ||																			
										'NULL AS AITSK_CD_KJN_CD,										'  ||																			
										'NULL  AS AITSK_CD_KJN_CD_YOBI,										'  ||																			
										'NULL AS MOD_SHORI_YMD_Y,										'  ||																			
										'NULL AS MOD_SHORI_YMD_M,										'  ||																			
										'NULL AS MOD_SHORI_YMD_D,										'  ||																			
										'NULL AS MOD_KBN,											'  ||
										iOPE_CD  || ','                                                                              ||
										iDATE    || ','                                                                              ||
										iPGM_ID  || ','                                                                              ||
										iOPE_CD  || ','                                                                              ||
										iDATE    || ','                                                                              ||
										iPGM_ID  ||																		
							        'FROM TT_TIKY_KJN A                                                                                     '  || 
							        'LEFT OUTER JOIN (SELECT F.KJN_CD,COUNT(NVL(G.TAISHOKU_FLG,0)) AS CNT,SUM(G.TAISHOKU_FLG) AS SM		'  ||																										
											'FROM TT_TIKY_KJN F										'  ||																			
											'LEFT OUTER JOIN TT_TIKY_KJN_KINMUSAKI G							'  ||																						
											'ON F.REC_ID = G.REC_ID										'  ||																			
											'AND F.KJN_CD = G.KJN_CD									'  ||																		
											'WHERE F.REC_ID = ''01''										'  ||																			
											'AND F.DEL_FLG IS NULL                                                                          '  ||
							                'GROUP BY F.KJN_CD ) E										'  ||																			
									'ON A.KJN_CD = E.KJN_CD		                                                                        '  ||
									'LEFT OUTER JOIN TT_TIKY_KJN_KINMUSAKI B								'  ||						
										'ON A.REC_ID = B.REC_ID										'  ||			
										'AND A.KJN_CD = B.KJN_CD	                                                                '  ||
								        'AND ((E.CNT = E.SM AND 1 = 0) OR (E.CNT <> E.SM AND 1=1))					'  ||							
									'LEFT OUTER JOIN TT_TIKY_SHI C										'  ||				
										'ON B.KINMUSAKI_REC_ID = C.REC_ID								'  ||					
										'AND B.KINMUSAKI_SHI_CD = C.SHI_CD                                                              '  ||
								        'AND ((E.CNT = E.SM AND 1 = 0) OR (E.CNT <> E.SM AND 1=1))					'  ||								
									'LEFT OUTER JOIN TM_TIKY_HIFG_SSY_SZKBUKA D								'  ||						
										'ON B.SZKBUKA_CD = D.SZKBUKA_CD									'  ||				
								        'AND ((E.CNT = E.SM AND 1 = 0) OR (E.CNT <> E.SM AND 1=1))					'  ||										
									'WHERE A.REC_ID = ''01''									        '  ||
									'AND A.DEL_FLG IS NULL                                                                                  '  ||
								    'AND (B.TAISHOKU_FLG IS NULL OR E.CNT = E.SM)     '; 
	  ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);
            
        --�b��_�S��_2����O_DCF��t�e�[�u���̃f�[�^��o�^����     
        INSERT INTO TD_PA_GEN_DCF_KJN( 
						         	  KJNREC_ID,                                              
						              KJN_CD,						       																							
						              KJN_CD_YOBI,					       	 																							
						              ISHI_NM_KANA,					       																								
						              SEIBETSU,					       																								
						              BIRTH_GENGO,					       																								
						              BIRTH_Y,						       																							
						              BIRTH_M,						       																							
						              BIRTH_D,						       																							
						              YOBI_1,						       																							
						              SHUSSHIN_KEN_CD,					       																								
						              ISHIKAI_CD,					       																								
						              STNEN_GENGO,					       																								
						              STNEN_Y,						       																							
						              SHUSSHINKO_SHUSSHINKO_CD,			       																										
						              SHUSSHINKO_GAKUBU_SKBT_CD,			       																										
						              KAIKIN_KBN,					       																								
						              KAIGYONEN_GENGO,					       																								
						              KAIGYONEN_Y,					       																								
						              SNRYKMK_1,					       																								
						              SNRYKMK_2,					       																								
						              SNRYKMK_3,					       																								
						              SNRYKMK_4,					       																								
						              SNRYKMK_5,					       																								
						              JUSHO_CD_KEN_CD,					       																								
						              JUSHO_CD_SHIKU_CD,				       																									
						              JUSHO_CD_OAZA_CD,				       																									
						              JUSHO_CD_AZA_CD,					       																								
						              ZIP,						       																							
						              JUSHO_HYOJI_NO,					       																								
						              YOBI_2,						       																							
						              JITAKU_JUSHO_KANA,				       																									
						              JUSHO_COUNT_KANA_KEN,				       																									
						              JUSHO_COUNT_KANA_SHIKU,				       																									
						              JUSHO_COUNT_KANA_OAZA,				       																									
						              JUSHO_COUNT_KANJI_KEN,				       																									
						              JUSHO_COUNT_KANJI_SHIKU,				       																									
						              JUSHO_COUNT_KANJI_OAZA,				       																									
						              JITAKU_TEL,					       																								
						              STATUS_JUSHOFUMEI,				       																									
						              STATUS_DEL_YOTEI_RIYU,				       																									
						              STATUS_YOBI,					       																								
						              KOTEI_KOMOKU_YOBI_AREA,				       																									
						              ISHI_NM_KANJI,					       																								
						              JITAKU_JUSHO_KANJI,				       																									
						              KINMUSAKI_SHIREC_ID,				       																									
						              KINMUSAKI_SHI_CD,				       																									
						              KINMUSAKI_SHI_CD_YOBI,				       																									
						              KINMUSAKI_YAKUSHOKU_CD,				       																									
						              KINMUSAKI_SHOKUI,				       																									
						              KINMUSAKI_SZKBUKA_CD,				       																									
						              YOBI_3,						       																							
						              RYKSK_SHI_NM_KANA,				       																									
						              RYKSK_SHI_NM_KANJI,				       																									
						              SZKBUKA_KANA,					       																								
						              SZKBUKA_KANJI,					       																								
						              KINMUSAKI_KOMOKU_YOBI_AREA,			       																										
						              AITSK_CD_KJNREC_ID,				       																									
						              AITSK_CD_KJN_CD,					       																								
						              AITSK_CD_KJN_CD_YOBI,				       																									
						              MOD_SHORI_YMD_Y,					       																								
						              MOD_SHORI_YMD_M,					       																								
						              MOD_SHORI_YMD_D,					       																								
						              MOD_KBN,                                                
						              TRK_OPE_CD,                                             
						              TRK_DATE,                                               
						              TRK_PGM_ID,                                             
						              UPD_OPE_CD,                                             
						              UPD_DATE,                                               
						              UPD_PGM_ID
						             ) 
				 		SELECT                                                       
							A.REC_ID AS KJNREC_ID,																													
							A.KJN_CD AS KJN_CD,																													
							NULL AS KJN_CD_YOBI,																													
							A.KJN_NM_KANA AS ISHI_NM_KANA,																													
							A.SEIBETSU_KBN AS SEIBETSU,																													
							A.BIRTH_GENGO_CD AS BIRTH_GENGO,																													
							A.BIRTH_WY AS BIRTH_Y,																													
							A.BIRTH_M AS BIRTH_M,																													
							A.BIRTH_D AS BIRTH_D,																													
						    NULL AS YOBI_1,																													
							A.SHUSSHINCHI_RIDAI_CD AS SHUSSHIN_KEN_CD,																													
							A.KANYU_ISHIKAI_RIDAI_CD AS ISHIKAI_CD,																													
							A.STNEN_GENGO_CD AS STNEN_GENGO,																													
							A.STNEN_WY AS STNEN_Y,																													
							A.SHUSSHINKO_CD AS SHUSSHINKO_SHUSSHINKO_CD,																													
							A.GAKUBU_SHIKIBETSU_KBN AS SHUSSHINKO_GAKUBU_SKBT_CD,																													
							A.KAIKIN_KBN AS KAIKIN_KBN,																													
							A.KAIGYONEN_GENGO_CD AS KAIGYONEN_GENGO,																													
							A.KAIGYONEN_WY AS KAIGYONEN_Y,																													
							A.SNRYKMK_CD_1 AS SNRYKMK_1,																													
							A.SNRYKMK_CD_2 AS SNRYKMK_2,																													
							A.SNRYKMK_CD_3 AS SNRYKMK_3,																													
							A.SNRYKMK_CD_4 AS SNRYKMK_4,																													
							A.SNRYKMK_CD_5 AS SNRYKMK_5,																													
							A.KEN_CD AS JUSHO_CD_KEN_CD,																													
							A.SHIKU_CD AS JUSHO_CD_SHIKU_CD,																													
							A.OAZA_CD AS JUSHO_CD_OAZA_CD,																													
							A.AZA_CD AS JUSHO_CD_AZA_CD,																													
							A.ZIP AS ZIP,																													
							A.JUSHO_HYOJI_NO AS JUSHO_HYOJI_NO,																													
							NULL AS YOBI_2,																													
							A.JUSHO_KANA_RENKETSU AS JITAKU_JUSHO_KANA,																													
							TO_CHAR(A.KEN_NM_KANA_MOJI_SU,'fm09') AS JUSHO_COUNT_KANA_KEN,																													
							TO_CHAR(A.SHIKU_NM_KANA_MOJI_SU,'fm09') AS JUSHO_COUNT_KANA_SHIKU,																													
							TO_CHAR(A.OAZA_NM_KANA_MOJI_SU,'fm09') AS JUSHO_COUNT_KANA_OAZA,																													
							TO_CHAR(A.KEN_NM_KANJI_MOJI_SU,'fm09') AS JUSHO_COUNT_KANJI_KEN,																													
							TO_CHAR(A.SHIKU_NM_KANJI_MOJI_SU,'fm09') AS JUSHO_COUNT_KANJI_SHIKU,																													
							TO_CHAR(A.OAZA_NM_KANJI_MOJI_SU,'fm09') AS JUSHO_COUNT_KANJI_OAZA,																													
							A.TEL AS JITAKU_TEL,																													
							A.JUSHOFUMEI_CD AS STATUS_JUSHOFUMEI,																													
							A.DEL_YOTEI_RIYU_CD AS STATUS_DEL_YOTEI_RIYU,																													
							A.IKKATSU_TRK_FLG AS STATUS_YOBI,																													
							A.TRKNEN_GENGO_CD||A.TRKNEN_WY AS KOTEI_KOMOKU_YOBI_AREA,																													
							A.KJN_NM AS ISHI_NM_KANJI,																													
							A.JUSHO_KANJI_RENKETSU AS JITAKU_JUSHO_KANJI,																													
							-- ������2012/10/09 CP000114�̑Ή�
					        E.KINMUSAKI_REC_ID AS KINMUSAKI_SHIREC_ID,
					        E.KINMUSAKI_SHI_CD AS KINMUSAKI_SHI_CD,
					        --NVL(B.KINMUSAKI_REC_ID,'00') AS KINMUSAKI_SHIREC_ID,																										
					        --NVL(B.KINMUSAKI_SHI_CD,'9999999') AS KINMUSAKI_SHI_CD,																								
					        -- ������2012/10/09 CP000114�̑Ή�																												
							NULL AS KINMUSAKI_SHI_CD_YOBI,																													
							B.YAKUSHOKU_CD AS KINMUSAKI_YAKUSHOKU_CD,																													
							B.SHOKUI_CD AS KINMUSAKI_SHOKUI,																													
							B.SZKBUKA_CD AS KINMUSAKI_SZKBUKA_CD,																													
							NULL AS YOBI_3,																													
							C.SHI_RN_KANA AS RYKSK_SHI_NM_KANA,																													
							C.SHI_RN AS RYKSK_SHI_NM_KANJI,																													
							DECODE(B.SZKBUKA_CD, '9999', B.NYURYOKU_SZKBUKA_NM_KANA, SUBSTR(D.SZKBUKA_NM_KANA, 1, 20)) AS SZKBUKA_KANA,
							DECODE(B.SZKBUKA_CD, '9999', B.NYURYOKU_SZKBUKA_NM, SUBSTR(D.SZKBUKA_NM, 1, 15)) AS SZKBUKA_KANJI,	
							NULL AS KINMUSAKI_KOMOKU_YOBI_AREA,																													
							NULL AS AITSK_CD_KJNREC_ID,																													
							NULL AS AITSK_CD_KJN_CD,																													
							NULL  AS AITSK_CD_KJN_CD_YOBI,																													
							NULL AS MOD_SHORI_YMD_Y,																													
							NULL AS MOD_SHORI_YMD_M,																													
							NULL AS MOD_SHORI_YMD_D,																													
							NULL AS MOD_KBN,
							iOPE_CD,
							iDATE,
							iPGM_ID,
							iOPE_CD,
							iDATE,
							iPGM_ID																													
					  	FROM TT_TIKY_KJN A
					  	-- ������2012/10/09 CP000114�̑Ή�
				        LEFT OUTER JOIN (SELECT
				       						DISTINCT
				       						TT.REC_ID,
				       						TT.KJN_CD,
				       						TT.KINMUSAKI_REC_ID,
				       						TT.KINMUSAKI_SHI_CD,
				       						TT.MAX_UPD_EIGY_YMD
				       					FROM (
						       					SELECT
						       						  TTK.REC_ID,
						       						  TTK.KJN_CD,
						       						  CASE
						       						  	WHEN TTKK.REC_ID IS NULL THEN
						       						  		'00'
						       						  	WHEN TTKK.REC_ID IS NOT NULL AND TTK.CNT = TTK.SM THEN
						       						  		'00'
						       						  	WHEN TTKK.REC_ID IS NOT NULL AND TTK.CNT <> TTK.SM AND TTKK.TAISHOKU_FLG IS NOT NULL THEN
						       						  		'99'  -- �ސE�s�v�ȃ��R�[�h�p��`
						       						  	ELSE
						       						  		TTKK.KINMUSAKI_REC_ID
						       						  END AS KINMUSAKI_REC_ID,
						       						  CASE
						       						  	WHEN TTKK.REC_ID IS NULL THEN
						       						  		'9999999'
						       						  	WHEN TTKK.REC_ID IS NOT NULL AND TTK.CNT = TTK.SM THEN
						       						  		'9999999'
						       						  	WHEN TTKK.REC_ID IS NOT NULL AND TTK.CNT <> TTK.SM AND TTKK.TAISHOKU_FLG IS NOT NULL THEN
						       						  		'9999999'
						       						  	ELSE
						       						  		TTKK.KINMUSAKI_SHI_CD
						       						  END AS KINMUSAKI_SHI_CD,
						       						  TTK.MAX_UPD_EIGY_YMD
						       					FROM (	SELECT F.REC_ID,
						       								   F.KJN_CD,
								       						   SUM(DECODE(G.TAISHOKU_FLG,'1',1,0)) AS CNT,
								       						   COUNT(1) AS SM,																														
														       MAX(CASE 
														       		WHEN NVL(F.UPD_EIGY_YMD, '19700101') > NVL(G.UPD_EIGY_YMD, '19700101')
														       		THEN F.UPD_EIGY_YMD 
														       		ELSE G.UPD_EIGY_YMD END
														       	  ) AS MAX_UPD_EIGY_YMD																												
														FROM TT_TIKY_KJN F																													
														LEFT OUTER JOIN TT_TIKY_KJN_KINMUSAKI G																													
															ON F.REC_ID = G.REC_ID																													
															AND F.KJN_CD = G.KJN_CD																											
														WHERE F.REC_ID = '01'																													
															AND F.DEL_FLG IS NULL
												        GROUP BY 
												        		F.REC_ID,
												        		F.KJN_CD
												    ) TTK
												LEFT OUTER JOIN TT_TIKY_KJN_KINMUSAKI TTKK
													ON TTK.REC_ID = TTKK.REC_ID																													
												    AND TTK.KJN_CD = TTKK.KJN_CD
											) TT
										WHERE TT.KINMUSAKI_REC_ID <> '99'	
								        ) E																													
							ON A.KJN_CD = E.KJN_CD
							AND A.REC_ID = E.REC_ID																																																												
							LEFT OUTER JOIN TT_TIKY_KJN_KINMUSAKI B																														
								ON E.REC_ID = B.REC_ID																													
								AND E.KJN_CD = B.KJN_CD
						        AND E.KINMUSAKI_REC_ID = B.KINMUSAKI_REC_ID
						        AND E.KINMUSAKI_SHI_CD = B.KINMUSAKI_SHI_CD       
							LEFT OUTER JOIN TT_TIKY_SHI C																														
								ON B.KINMUSAKI_REC_ID = C.REC_ID																													
								AND B.KINMUSAKI_SHI_CD = C.SHI_CD
							LEFT OUTER JOIN TM_TIKY_HIFG_SSY_SZKBUKA D																														
								ON B.SZKBUKA_CD = D.SZKBUKA_CD	
							WHERE A.REC_ID = '01'											
							AND A.DEL_FLG IS NULL;
							-- ������2012/10/09 CP000114�̑Ή�;                                                           
      END IF;
      
      commit;
      -- �I�����O�o��
      ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'PL/SQL End',PGM_ID || '�̏������I�����܂����B',iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);
      return 0;
    -- ��O����
	EXCEPTION
		-- ���̑��G���[
		WHEN OTHERS THEN
			W_ERR_INF_RCD.ERR_CD 		:= TO_CHAR(SQLCODE);
			W_ERR_INF_RCD.ERR_MSG 		:= SUBSTR(SQLERRM, 0, 500);
			W_ERR_INF_RCD.ERR_KEY_INF 	:= SUBSTR('iLayoutKind:' || iLayoutKind || ', iShimeKind:' || iShimeKind , 0,500);
			W_INDEX_N 					:= W_ERR_INF_TBL.COUNT + 1;
			W_ERR_INF_TBL.EXTEND;
			W_ERR_INF_TBL(W_INDEX_N) 	:= W_ERR_INF_RCD;

			OPEN oOUT_ERR_INF_CSR FOR
				SELECT * FROM TABLE(W_ERR_INF_TBL);
          ROLLBACK;  
          --�G���[���O�̓o�^
          ULT_INSERT_LOG_TABLE('ERROR',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'ERROR_INFO',W_ERR_INF_RCD.ERR_MSG,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

        return 1;
        END;
    END;
/

