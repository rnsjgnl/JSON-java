CREATE OR REPLACE PACKAGE NH010106B001_132
/* **********************************************************
 *  Copyright(c) 2011 beyond, INTEC Inc. All rights reserved.
 * **********************************************************/
AUTHID CURRENT_USER
IS
	/*** �J�[�\���^ ***************************************************************/
	-- �G���[���i�[�p�J�[�\���^
	TYPE ERR_INF_CSR		IS REF CURSOR;

	/*
	************************************************************************
	*  �s���{����Ë@�\���t�@�C���iCSV�F��{�j�f��DB�f�[�^�̍쐬
	*  CREATE_KEN_IKJ_KHN
	************************************************************************
	*/
	FUNCTION CREATE_KEN_IKJ_KHN(
	iLayoutKind	IN	INTEGER,										-- ���C�A�E�g�敪
	iShimeKind	IN	INTEGER,										-- ���ߓ��敪
  iTensoYMD	IN	VARCHAR2,										-- �]���N���� 
	iIP_ADDR	IN TL_STORED_SHORI.IP%TYPE,							-- ���s�[��IP�A�h���X (FW�Őݒ�)
	iWINDOWS_LOGIN_USER	IN TL_STORED_SHORI.WINDOWS_LOGIN_USER%TYPE, -- ���s�[��OS���[�U�[ (FW�Őݒ�)
	oROW_COUNT	OUT NUMBER,         -- �o�^����
	oOUT_ERR_INF_CSR 	OUT ERR_INF_CSR,    -- �G���[���J�[�\��
   iOPE_CD IN Varchar2,                      -- �I�y���[�^�R�[�h
  iPGM_ID IN Varchar2,                      -- �v���O����ID
  iDATE DATE                              -- �V�X�e������
	) RETURN NUMBER;
 
END;
/

CREATE OR REPLACE PACKAGE BODY NH010106B001_132
/* **********************************************************
 *  Copyright(c) 2011 beyond, INTEC Inc. All rights reserved.
 * **********************************************************/
IS
	/*
	 ************************************************************************
	 * Function ID  : CREATE_KEN_IKJ_KHN
	 * Program Name : �s���{����Ë@�\���t�@�C���iCSV�F��{�j�f��DB�f�[�^�̍쐬
	 * Parameter    :  <I> iLayoutKind	    	�F���C�A�E�g�敪
	 *		   		   <I> iShimeKind	    	�F���ߓ��敪
	 *				   <I> iTensoYMD	    	�F�]���N����
	 *				   <I> iOPE_CD		        �F�I�y���[�^�R�[�h
	 *				   <I> iPGM_ID		        �F�v���O����ID
	 *				   <I> iDATE		        �F�V�X�e������ 
	 *		           <I> iIP_ADDR		        �F���s�[��IP�A�h���X
	 *		           <I> iWINDOWS_LOGIN_USER  �F���s�[��IP�A�h���X
	 *                 <O> oROW_COUNT		    �F�X�V����
	 *                <O> oOUT_ERR_INF_CSR	�F�G���[���J�[�\��
	 * Return       �F�������ʁi0:����I���A1:�ُ�I���j
	 ************************************************************************
	 */
	FUNCTION CREATE_KEN_IKJ_KHN(
	iLayoutKind	IN	INTEGER,										-- ���C�A�E�g�敪
	iShimeKind	IN	INTEGER,										-- ���ߓ��敪
	iTensoYMD	IN	VARCHAR2,										-- �]���N����
	iIP_ADDR	IN TL_STORED_SHORI.IP%TYPE,							-- ���s�[��IP�A�h���X (FW�Őݒ�)
	iWINDOWS_LOGIN_USER	IN TL_STORED_SHORI.WINDOWS_LOGIN_USER%TYPE, -- ���s�[��OS���[�U�[ (FW�Őݒ�)
	oROW_COUNT	OUT NUMBER,                                         -- �o�^����
	oOUT_ERR_INF_CSR 	OUT ERR_INF_CSR,                            -- �G���[���J�[�\��
	iOPE_CD IN Varchar2,                                            -- �I�y���[�^�R�[�h
	iPGM_ID IN Varchar2,                                            -- �v���O����ID
	iDATE DATE                                                      -- �V�X�e������  
	)RETURN NUMBER IS

  PRAGMA AUTONOMOUS_TRANSACTION;
	/************************************************************************/
	/*                              �G���[����                              */
	/************************************************************************/
	W_INDEX_N 				NUMBER(10) := 0;
	W_ERR_INF_TBL 				TYPE_ERR_INFO_TBL := TYPE_ERR_INFO_TBL();
	W_ERR_INF_RCD 				TYPE_ERR_INFO_RCD := TYPE_ERR_INFO_RCD(NULL,NULL,NULL,NULL);
	vSQL VARCHAR2(200);
        vSchemaNm     TM_JOSU.HANYO_KOMOKU%TYPE := NULL; -- �X�L�[�}����
	PGM_ID        VARCHAR2(50) := 'NH010106B001_132.CREATE_KEN_IKJ_KHN';
	EXECUTE_SQL   VARCHAR2(32767) := NULL;  

	BEGIN
        -- �J�n���O�o��
        ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'PL/SQL Start',PGM_ID || '�̏������J�n���܂��B',iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);
        -- �[�i�p�X�L�[�}�̎擾���s���B
	vSchemaNm := ULT_COMMON.GET_SCHEMA_NAME(ULT_COMMON.SYS_ENV_JOSU_DAI_CD, ULT_COMMON.NOHIN_SHEMA_JOSU_SHO_CD);
	oROW_COUNT:= -1;
          -- �V���C�A�E�g
	  IF iLayoutKind = 1 THEN

             --�V_�S��_��Ë@�\���_CSV_��{�̃f�[�^���N���A����B
             EXECUTE_SQL := 'TRUNCATE TABLE ' || vSchemaNm || '.' || 'TD_NA_IKJ_CSV_KHN';
             EXECUTE IMMEDIATE EXECUTE_SQL;
             ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);
             
	     -- �擾�����f��DB�f�[�^���������J��Ԃ�
             INSERT INTO TD_NA_IKJ_CSV_KHN(
                    LAYOUT_KBN,												
	            DCF_CD_REC_ID,												
                    DCF_CD_SHI_CD,												
                    DCF_CD_YOBI,												
		    MOD_KBN,											
		    YOBI_1,											
		    MENTE_YMD,												
		    YOBI_2,												
		    JOHO_YMD,												
		    ANNAIYO_HOMEPAGE_ADDRESS,												
		    INNAI_SHOHO_FLG,												
		    INGAI_SHOHO_FLG,												
		    CHIKENJISSHI_FLG,												
		    CHIKENJISSHI_KIYK_KENSU,												
		    CHIKENJISSHI_KIKAN_S,												
		    CHIKENJISSHI_KIKAN_E,												
		    SHI_STB_FLG,												
		    SHIKKAN_CHRY_FLG,												
		    TNK_TIZI_SJT_FLG,												
		    SMG_FLG,												
		    RNKITISI_MADOGUCHI_FLG,												
		    RNKITISI_CHIKRENKEIPATH_FLG,												
		    RNKITISI_RNKITISI,												
		    KNRTISI_ORDERINGSYSTEM_UMU_FLG,												
		    KNRTISI_ORDERINGSYSTEM_KENSA,												
		    KNRTISI_ORDERINGSYSTEM_SHOHO,												
		    KNRTISI_ORDERINGSYSTEM_YOYAKU,												
		    KNRTISI_ICD_CD_RIYO_FLG,												
		    KNRTISI_DENSHI_KARTE_FLG,												
		    KNRTISI_SENNIN_FLG,												
		    KNRTISI_SENNIN_SU,												
		    KANJYASU_AVG_BED_SBT_IPPAN,												
		    KANJYASU_AVG_BED_SBT_RYOYO,												
		    KANJYASU_AVG_BED_SBT_RYOYO_IRY,												
		    KANJYASU_AVG_BED_SBT_RYOYO_KIG,												
		    KANJYASU_AVG_BED_SBT_SEISHIN,												
		    KANJYASU_AVG_BED_SBT_KEKKAKU,												
		    KANJYASU_AVG_BED_SBT_KANSEN,												
		    KANJYASU_AVG_BED_SBT_ZENTAI,												
		    KANJYASU_AVG_BED_SBT_KIKAN_S,												
		    KANJYASU_AVG_BED_SBT_KIKAN_E,												
		    KANJYASU_AVG_GAIRAI_KANJYASU,												
		    KANJYASU_AVG_GAIRAI_KIKAN_S,												
		    KANJYASU_AVG_GAIRAI_KIKAN_E,												
		    KANJYASU_AVG_ZAITAKU_KANJYASU,												
		    KANJYASU_AVG_ZAITAKU_KIKAN_S,												
		    KANJYASU_AVG_ZAITAKU_KIKAN_E,												
		    KANJYASU_NSU_BED_SBT_IPPAN,												
		    KANJYASU_NSU_BED_SBT_RYOYO,												
		    KANJYASU_NSU_BED_SBT_RYOYO_IRY,												
		    KANJYASU_NSU_BED_SBT_RYOYO_KIG,												
		    KANJYASU_NSU_BED_SBT_SEISHIN,												
		    KANJYASU_NSU_BED_SBT_KEKKAKU,												
		    KANJYASU_NSU_BED_SBT_KANSEN,												
		    KANJYASU_NSU_BED_SBT_ZENTAI,												
		    KANJYASU_NSU_BED_SBT_KIKAN_S,												
		    KANJYASU_NSU_BED_SBT_KIKAN_E,												
		    KANJYASU_NSU_GAIRAI_KANJYASU,												
		    KANJYASU_NSU_GAIRAI_KIKAN_S,												
		    KANJYASU_NSU_GAIRAI_KIKAN_E,												
		    KANJYASU_NSU_ZAITAKU_KANJYASU,												
		    KANJYASU_NSU_ZAITAKU_KIKAN_S,												
		    KANJYASU_NSU_ZAITAKU_KIKAN_E,												
		    AVGNISSU_IPPAN,												
		    AVGNISSU_RYOYO,												
		    AVGNISSU_RYOYO_IRY,												
		    AVGNISSU_RYOYO_KIG,												
		    AVGNISSU_SEISHIN,												
		    AVGNISSU_KEKKAKU,												
		    AVGNISSU_KANSEN,												
		    AVGNISSU_ZENTAI,												
		    AVGNISSU_KIKAN_S,												
		    AVGNISSU_KIKAN_E,
                    TSUIKA_DEL_KBN,
                    TENSO_YMD,
		    TRK_OPE_CD,
		    TRK_DATE,
		    TRK_PGM_ID,
		    UPD_OPE_CD,
		    UPD_DATE,
		    UPD_PGM_ID)
                    SELECT
                    '132',
                    '00',
                    IK.SHI_CD,
                    NULL,
                    NULL,
                    NULL,
                    CASE WHEN iShimeKind = 1 THEN IK.UPD_EIGY_YMD ELSE NULL END,
                    NULL,
                    IK.JOHO_YMD,
                    IK.ANNAIYO_URL,
                    IK.INNAI_SHOHO_FLG,
                    IK.INGAI_SHOHO_FLG,
                    IK.CHIKENJISSHI_FLG,
                    IK.CHIKENJISSHI_KIYK_KENSU,
                    IK.CHIKENJISSHI_S_YMD,
                    IK.CHIKENJISSHI_E_YMD,
                    IK.STB_FLG,
                    IK.SHIKKAN_CHRY_FLG,
                    IK.TNK_TIZI_SJT_FLG,
                    IK.SMG_FLG,
                    IK.CHIKRENKEI_MADOGUCHI_FLG,
                    IK.CHIKRENKEIPATH_FLG_IKJ,
                    IK.NYUINSNRY_INNAI_RNKITISI_FLG,
                    IK.ORDERINGSYSTEM_FLG,
                    IK.ORDERINGSYSTEM_KENSA_FLG,
                    IK.ORDERINGSYSTEM_SHOHO_FLG,
                    IK.ORDERINGSYSTEM_YOYAKU_FLG,
                    IK.ICD_CD_RIYO_FLG,
                    IK.DENSHI_KARTE_FLG,
                    IK.KARTEKANRI_SENNIN_FLG,
                    IK.KARTEKANRI_SENNIN_SU,
               	    TRIM(TO_CHAR(IK.KANJYASU_IPPAN_BED,'99990.0')),
		    TRIM(TO_CHAR(IK.KANJYASU_RYOYO_BED,'99990.0')),
	            TRIM(TO_CHAR(IK.KANJYASU_RYOYO_BED_IRY_HKN,'99990.0')),
		    TRIM(TO_CHAR(IK.KANJYASU_RYOYO_BED_KIG_HKN,'99990.0')),
	            TRIM(TO_CHAR(IK.KANJYASU_SEISHIN_BED,'99990.0')),
		    TRIM(TO_CHAR(IK.KANJYASU_KEKKAKU_BED,'99990.0')),
		    TRIM(TO_CHAR(IK.KANJYASU_KANSEN,'99990.0')),
		    TRIM(TO_CHAR(IK.KANJYASU_ZENTAI_BED,'99990.0')),
		    IK.KANJYASU_BED_SBT_S_YMD,
		    IK.KANJYASU_BED_SBT_E_YMD,
		    TRIM(TO_CHAR(IK.KANJYASU_GAIRAI,'99990.0')),
		    IK.KANJYASU_GAIRAI_S_YMD,
		    IK.KANJYASU_GAIRAI_E_YMD,
		    TRIM(TO_CHAR(IK.KANJYASU_ZAITAKU,'99990.0')),
		    IK.KANJYASU_ZAITAKU_S_YMD,
		    IK.KANJYASU_ZAITAKU_E_YMD,
		    IK.KANJYANSU_IPPAN_BED,
		    IK.KANJYANSU_RYOYO_BED,	
		    IK.KANJYANSU_RYOYO_BED_IRY_HKN,
		    IK.KANJYANSU_RYOYO_BED_KIG_HKN,
		    IK.KANJYANSU_SEISHIN_BED,
		    IK.KANJYANSU_KEKKAKU_BED,
		    IK.KANJYANSU_KANSEN,
		    IK.KANJYANSU_ZENTAI_BED,
		    IK.KANJYANSU_BED_SBT_S_YMD,
		    IK.KANJYANSU_BED_SBT_E_YMD,
		    IK.KANJYANSU_GAIRAI,
		    IK.KANJYANSU_GAIRAI_S_YMD,
		    IK.KANJYANSU_GAIRAI_E_YMD,
		    IK.KANJYANSU_ZAITAKU,
		    IK.KANJYANSU_ZAITAKU_S_YMD,
		    IK.KANJYANSU_ZAITAKU_E_YMD,
		    TRIM(TO_CHAR(IK.AVGNISSU_IPPAN_BED,'99990.0')),	
		    TRIM(TO_CHAR(IK.AVGNISSU_RYOYO_BED,'99990.0')),	
		    TRIM(TO_CHAR(IK.AVGNISSU_RYOYO_BED_IRY_HKN,'99990.0')),	
		    TRIM(TO_CHAR(IK.AVGNISSU_RYOYO_BED_KIG_HKN,'99990.0')),
		    TRIM(TO_CHAR(IK.AVGNISSU_SEISHIN_BED,'99990.0')),
		    TRIM(TO_CHAR(IK.AVGNISSU_KEKKAKU_BED,'99990.0')),
		    TRIM(TO_CHAR(IK.AVGNISSU_KANSEN,'99990.0')),
		    TRIM(TO_CHAR(IK.AVGNISSU_ZENTAI_BED,'99990.0')),
		    IK.AVGNISSU_S_YMD,
	            IK.AVGNISSU_E_YMD,
                    NULL,
                    CASE WHEN iShimeKind = 1 THEN iTensoYMD ELSE NULL END,
                    iOPE_CD,
                    iDATE,
                    iPGM_ID,
                    iOPE_CD,
                    iDATE,
                    iPGM_ID
        FROM TT_TIKY_SHI S										
	INNER JOIN TT_TIKY_IKJ_KIHON IK ON (										
		IK.REC_ID = S.REC_ID									
		AND IK.SHI_CD = S.SHI_CD)
        WHERE S.REC_ID = '00'							
	AND S.DEL_FLG IS NULL
        AND IK.DEL_FLG IS NULL;	

	EXECUTE_SQL :=  'INSERT INTO TD_NA_IKJ_CSV_KHN('||
                    'LAYOUT_KBN,'||												
	            'DCF_CD_REC_ID,'||												
                    'DCF_CD_SHI_CD,'||												
                    'DCF_CD_YOBI,'||												
		    'MOD_KBN,'||											
		    'YOBI_1,'||											
		    'MENTE_YMD,'||												
		    'YOBI_2,'||												
		    'JOHO_YMD,'||												
		    'ANNAIYO_HOMEPAGE_ADDRESS,'||												
		    'INNAI_SHOHO_FLG,'||												
		    'INGAI_SHOHO_FLG,'||												
		    'CHIKENJISSHI_FLG,'||												
		    'CHIKENJISSHI_KIYK_KENSU,'||												
		    'CHIKENJISSHI_KIKAN_S,'||												
		    'CHIKENJISSHI_KIKAN_E,'||												
		    'SHI_STB_FLG,'||												
		    'SHIKKAN_CHRY_FLG,'||												
		    'TNK_TIZI_SJT_FLG,'||												
		    'SMG_FLG,'||												
		    'RNKITISI_MADOGUCHI_FLG,'||												
		    'RNKITISI_CHIKRENKEIPATH_FLG,'||												
		    'RNKITISI_RNKITISI,'||												
		    'KNRTISI_ORDERINGSYSTEM_UMU_FLG,'||												
		    'KNRTISI_ORDERINGSYSTEM_KENSA,'||												
		    'KNRTISI_ORDERINGSYSTEM_SHOHO,'||												
		    'KNRTISI_ORDERINGSYSTEM_YOYAKU,'||												
		    'KNRTISI_ICD_CD_RIYO_FLG,'||												
		    'KNRTISI_DENSHI_KARTE_FLG,'||												
		    'KNRTISI_SENNIN_FLG,'||												
		    'KNRTISI_SENNIN_SU,'||												
		    'KANJYASU_AVG_BED_SBT_IPPAN,'||												
		    'KANJYASU_AVG_BED_SBT_RYOYO,'||												
		    'KANJYASU_AVG_BED_SBT_RYOYO_IRY,'||												
		    'KANJYASU_AVG_BED_SBT_RYOYO_KIG,'||												
		    'KANJYASU_AVG_BED_SBT_SEISHIN,'||												
		    'KANJYASU_AVG_BED_SBT_KEKKAKU,'||												
		    'KANJYASU_AVG_BED_SBT_KANSEN,'||												
		    'KANJYASU_AVG_BED_SBT_ZENTAI,'||												
		    'KANJYASU_AVG_BED_SBT_KIKAN_S,'||												
		    'KANJYASU_AVG_BED_SBT_KIKAN_E,'||												
		    'KANJYASU_AVG_GAIRAI_KANJYASU,'||												
		    'KANJYASU_AVG_GAIRAI_KIKAN_S,'||												
		    'KANJYASU_AVG_GAIRAI_KIKAN_E,'||												
		    'KANJYASU_AVG_ZAITAKU_KANJYASU,'||												
		    'KANJYASU_AVG_ZAITAKU_KIKAN_S,'||												
		    'KANJYASU_AVG_ZAITAKU_KIKAN_E,'||												
		    'KANJYASU_NSU_BED_SBT_IPPAN,'||												
		    'KANJYASU_NSU_BED_SBT_RYOYO,'||												
		    'KANJYASU_NSU_BED_SBT_RYOYO_IRY,'||												
		    'KANJYASU_NSU_BED_SBT_RYOYO_KIG,'||												
		    'KANJYASU_NSU_BED_SBT_SEISHIN,'||												
		    'KANJYASU_NSU_BED_SBT_KEKKAKU,'||												
		    'KANJYASU_NSU_BED_SBT_KANSEN,'||												
		    'KANJYASU_NSU_BED_SBT_ZENTAI,'||												
		    'KANJYASU_NSU_BED_SBT_KIKAN_S,'||												
		    'KANJYASU_NSU_BED_SBT_KIKAN_E,'||												
		    'KANJYASU_NSU_GAIRAI_KANJYASU,'||												
		    'KANJYASU_NSU_GAIRAI_KIKAN_S,'||												
		    'KANJYASU_NSU_GAIRAI_KIKAN_E,'||												
		    'KANJYASU_NSU_ZAITAKU_KANJYASU,'||												
		    'KANJYASU_NSU_ZAITAKU_KIKAN_S,'||												
		    'KANJYASU_NSU_ZAITAKU_KIKAN_E,'||												
		    'AVGNISSU_IPPAN,'||												
		    'AVGNISSU_RYOYO,'||												
		    'AVGNISSU_RYOYO_IRY,'||												
		    'AVGNISSU_RYOYO_KIG,'||												
		    'AVGNISSU_SEISHIN,'||												
		    'AVGNISSU_KEKKAKU,'||												
		    'AVGNISSU_KANSEN,'||												
		    'AVGNISSU_ZENTAI,'||												
		    'AVGNISSU_KIKAN_S,'||												
		    'AVGNISSU_KIKAN_E,'||
                    'TSUIKA_DEL_KBN,'||
                    'TENSO_YMD,'||
		    'TRK_OPE_CD,'||
		    'TRK_DATE,'||
		    'TRK_PGM_ID,'||
		    'UPD_OPE_CD,'||
		    'UPD_DATE,'||
		    'UPD_PGM_ID)'||
          '    SELECT                                                          '||
                  '''132'''  || ','                                        ||
                  '''00'''   || ','                                        ||
                    'IK.SHI_CD,'||
                    'NULL,'||
                    'NULL,'||
                    'NULL,'||
                    'CASE WHEN iShimeKind = 1 THEN IK.UPD_EIGY_YMD ELSE NULL END,'||
                    'NULL,'||
                    'IK.JOHO_YMD,'||
                    'IK.ANNAIYO_URL,'||
                    'IK.INNAI_SHOHO_FLG,'||
                    'IK.INGAI_SHOHO_FLG,'||
                    'IK.CHIKENJISSHI_FLG,'||
                    'IK.CHIKENJISSHI_KIYK_KENSU,'||
                    'IK.CHIKENJISSHI_S_YMD,'||
                    'IK.CHIKENJISSHI_E_YMD,'||
                    'IK.STB_FLG,'||
                    'IK.SHIKKAN_CHRY_FLG,'||
                    'IK.TNK_TIZI_SJT_FLG,'||
                    'IK.SMG_FLG,'||
                    'IK.CHIKRENKEI_MADOGUCHI_FLG,'||
                    'IK.CHIKRENKEIPATH_FLG_IKJ,'||
                    'IK.NYUINSNRY_INNAI_RNKITISI_FLG,'||
                    'IK.ORDERINGSYSTEM_FLG,'||
                    'IK.ORDERINGSYSTEM_KENSA_FLG,'||
                    'IK.ORDERINGSYSTEM_SHOHO_FLG,'||
                    'IK.ORDERINGSYSTEM_YOYAKU_FLG,'||
                    'IK.ICD_CD_RIYO_FLG,'||
                    'IK.DENSHI_KARTE_FLG,'||
                    'IK.KARTEKANRI_SENNIN_FLG,'||
                    'IK.KARTEKANRI_SENNIN_SU,'||
               	    'TRIM(TO_CHAR(IK.KANJYASU_IPPAN_BED, ' || '''99990.0''' || ')),'||
		    'TRIM(TO_CHAR(IK.KANJYASU_RYOYO_BED, ' || '''99990.0''' || ')),'||
	            'TRIM(TO_CHAR(IK.KANJYASU_RYOYO_BED_IRY_HKN, ' || '''99990.0''' || ')),'||
		    'TRIM(TO_CHAR(IK.KANJYASU_RYOYO_BED_KIG_HKN, ' || '''99990.0''' || ')),'||
	            'TRIM(TO_CHAR(IK.KANJYASU_SEISHIN_BED, ' || '''99990.0''' || ')),'||
		    'TRIM(TO_CHAR(IK.KANJYASU_KEKKAKU_BED, ' || '''99990.0''' || ')),'||
		    'TRIM(TO_CHAR(IK.KANJYASU_KANSEN, ' || '''99990.0''' || ')),'||
		    'TRIM(TO_CHAR(IK.KANJYASU_ZENTAI_BED, ' || '''99990.0''' || ')),'||
		    'IK.KANJYASU_BED_SBT_S_YMD,'||
		    'IK.KANJYASU_BED_SBT_E_YMD,'||
		    'TRIM(TO_CHAR(IK.KANJYASU_GAIRAI, ' || '''99990.0''' || ')),'||
		    'IK.KANJYASU_GAIRAI_S_YMD,'||
		    'IK.KANJYASU_GAIRAI_E_YMD,'||
		    'TRIM(TO_CHAR(IK.KANJYASU_ZAITAKU, ' || '''99990.0''' || ')),'||
		    'IK.KANJYASU_ZAITAKU_S_YMD,'||
		    'IK.KANJYASU_ZAITAKU_E_YMD,'||
		    'IK.KANJYANSU_IPPAN_BED,'||
		    'IK.KANJYANSU_RYOYO_BED,'||	
		    'IK.KANJYANSU_RYOYO_BED_IRY_HKN,'||
		    'IK.KANJYANSU_RYOYO_BED_KIG_HKN,'||
		    'IK.KANJYANSU_SEISHIN_BED,'||
		    'IK.KANJYANSU_KEKKAKU_BED,'||
		    'IK.KANJYANSU_KANSEN,'||
		    'IK.KANJYANSU_ZENTAI_BED,'||
		    'IK.KANJYANSU_BED_SBT_S_YMD,'||
		    'IK.KANJYANSU_BED_SBT_E_YMD,'||
		    'IK.KANJYANSU_GAIRAI,'||
		    'IK.KANJYANSU_GAIRAI_S_YMD,'||
		    'IK.KANJYANSU_GAIRAI_E_YMD,'||
		    'IK.KANJYANSU_ZAITAKU,'||
		    'IK.KANJYANSU_ZAITAKU_S_YMD,'||
		    'IK.KANJYANSU_ZAITAKU_E_YMD,'||
		    'TRIM(TO_CHAR(IK.AVGNISSU_IPPAN_BED, ' || '''99990.0''' || ')),'||	
		    'TRIM(TO_CHAR(IK.AVGNISSU_RYOYO_BED, ' || '''99990.0''' || ')),'||	
		    'TRIM(TO_CHAR(IK.AVGNISSU_RYOYO_BED_IRY_HKN, ' || '''99990.0''' || ')),'||	
		    'TRIM(TO_CHAR(IK.AVGNISSU_RYOYO_BED_KIG_HKN, ' || '''99990.0''' || ')),'||
		    'TRIM(TO_CHAR(IK.AVGNISSU_SEISHIN_BED, ' || '''99990.0''' || ')),'||
		    'TRIM(TO_CHAR(IK.AVGNISSU_KEKKAKU_BED, ' || '''99990.0''' || ')),'||
		    'TRIM(TO_CHAR(IK.AVGNISSU_KANSEN, ' || '''99990.0''' || ')),'||
		    'TRIM(TO_CHAR(IK.AVGNISSU_ZENTAI_BED, ' || '''99990.0''' || ')),'||
		    'IK.AVGNISSU_S_YMD,'||
	            'IK.AVGNISSU_E_YMD,'||
                    'NULL,'||
                    'CASE WHEN iShimeKind = 1 THEN iTensoYMD ELSE NULL END,'||
                    'iOPE_CD,'||
                    'iDATE,'||
                    'iPGM_ID,'||
                    'iOPE_CD,'||
                    'iDATE,'||
                    'iPGM_ID'||
        'FROM TT_TIKY_SHI S'||										
	'INNER JOIN TT_TIKY_IKJ_KIHON IK ON ('||										
		'IK.REC_ID = S.REC_ID	'||								
		'AND IK.SHI_CD = S.SHI_CD)'||
        'WHERE S.REC_ID = ''00''	'||						
	'AND S.DEL_FLG IS NULL'||
        'AND IK.DEL_FLG IS NULL';	
							
	ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

        -- �b�背�C�A�E�g
        ELSIF iLayoutKind = 2 THEN
               IF iShimeKind = 4 OR iShimeKind = 5 THEN
			--�b��S����Ë@�\(��{)�e�[�u���̃f�[�^���N���A����B
                        EXECUTE_SQL := 'TRUNCATE TABLE ' || vSchemaNm || '.' || 'TD_PA_IKJ_KHN';
                        EXECUTE IMMEDIATE EXECUTE_SQL;
                        ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

	            --�b��S����Ë@�\(��{)
                      INSERT INTO TD_PA_IKJ_KHN(
		         DCF_CD_REC_ID,											
		         DCF_CD_SHI_CD,											
		         JOHO_YMD_Y,											
		         JOHO_YMD_M,											
		         JOHO_YMD_D,											
		         ANNAIYO_HOMEPAGE_ADDRESS,											
		         INNAI_SHOHO_FLG,											
		         INGAI_SHOHO_FLG,											
		         CHIKENJISSHI_FLG,											
		         CHIKENJISSHI_KIYK_KENSU,											
		         KIKAN_S_Y,											
		         KIKAN_S_M,											
		         KIKAN_S_D,											
		         KIKAN_E_Y,											
		         KIKAN_E_M,											
		         KIKAN_E_D,											
		         SHI_STB_FLG,											
		         SHIKKAN_CHRY_FLG,											
		         TNK_TIZI_SJT_FLG,											
		         SMG_FLG,											
		         RNKITISI_MADOGUCHI_FLG,											
	                 RNKITISI_CHIKRENKEIPATH_FLG,											
		         RNKITISI_RNKITISI,											
		         KNRTISI_ORDERINGSYSTEM_UMU_FLG,											
		         KNRTISI_ORDERINGSYSTEM_KENSA,											
		         KNRTISI_ORDERINGSYSTEM_SHOHO,											
		         KNRTISI_ORDERINGSYSTEM_YOYAKU,											
		         KNRTISI_ICD_CD_RIYO_FLG,											
		         KNRTISI_DENSHI_KARTE_FLG,											
		         KNRTISI_SENNIN_FLG,											
		         KNRTISI_SENNIN_SU,											
		         KANJYASU_AVG_BED_SBT_IPPAN,											
		         KANJYASU_AVG_BED_SBT_RYOYO,											
		         KANJYASU_AVG_BED_SBT_RYOYO_IRY,											
		         KANJYASU_AVG_BED_SBT_RYOYO_KIG,											
		         KANJYASU_AVG_BED_SBT_SEISHIN,											
		         KANJYASU_AVG_BED_SBT_KEKKAKU,											
		         KANJYASU_AVG_BED_SBT_KANSEN,											
		         KANJYASU_AVG_BED_SBT_ZENTAI,											
		         KANJYASU_AVG_BED_SBT_KIKAN_S_Y,											
		         KANJYASU_AVG_BED_SBT_KIKAN_S_M,											
		         KANJYASU_AVG_BED_SBT_KIKAN_S_D,											
		         KANJYASU_AVG_BED_SBT_KIKAN_E_Y,											
		         KANJYASU_AVG_BED_SBT_KIKAN_E_M,											
		         KANJYASU_AVG_BED_SBT_KIKAN_E_D,											
		         KANJYASU_AVG_GAIRAI_KANJYASU,											
		         KANJYASU_AVG_GAIRAI_KIKAN_S_Y,											
		         KANJYASU_AVG_GAIRAI_KIKAN_S_M,											
		         KANJYASU_AVG_GAIRAI_KIKAN_S_D,											
		         KANJYASU_AVG_GAIRAI_KIKAN_E_Y,											
		         KANJYASU_AVG_GAIRAI_KIKAN_E_M,											
		         KANJYASU_AVG_GAIRAI_KIKAN_E_D,											
		         KANJYASU_AVG_ZAITAKU_KANJYASU,											
		         KANJYASU_AVG_ZAITAKU_KIKAN_S_Y,											
		         KANJYASU_AVG_ZAITAKU_KIKAN_S_M,											
		         KANJYASU_AVG_ZAITAKU_KIKAN_S_D,											
		         KANJYASU_AVG_ZAITAKU_KIKAN_E_Y,											
		         KANJYASU_AVG_ZAITAKU_KIKAN_E_M,											
		         KANJYASU_AVG_ZAITAKU_KIKAN_E_D,											
		         KANJYASU_NSU_BED_SBT_IPPAN,											
		         KANJYASU_NSU_BED_SBT_RYOYO,											
		         KANJYASU_NSU_BED_SBT_RYOYO_IRY,											
		         KANJYASU_NSU_BED_SBT_RYOYO_KIG,											
		         KANJYASU_NSU_BED_SBT_SEISHIN,											
		         KANJYASU_NSU_BED_SBT_KEKKAKU,											
		         KANJYASU_NSU_BED_SBT_KANSEN,											
		         KANJYASU_NSU_BED_SBT_ZENTAI,											
		         KANJYASU_NSU_BED_SBT_KIKAN_S_Y,											
		         KANJYASU_NSU_BED_SBT_KIKAN_S_M,											
		         KANJYASU_NSU_BED_SBT_KIKAN_S_D,											
		         KANJYASU_NSU_BED_SBT_KIKAN_E_Y,											
		         KANJYASU_NSU_BED_SBT_KIKAN_E_M,											
		         KANJYASU_NSU_BED_SBT_KIKAN_E_D,											
		         KANJYASU_NSU_GAIRAI_KANJYASU,											
		         KANJYASU_NSU_GAIRAI_KIKAN_S_Y,											
		         KANJYASU_NSU_GAIRAI_KIKAN_S_M,											
		         KANJYASU_NSU_GAIRAI_KIKAN_S_D,											
		         KANJYASU_NSU_GAIRAI_KIKAN_E_Y,											
		         KANJYASU_NSU_GAIRAI_KIKAN_E_M,											
		         KANJYASU_NSU_GAIRAI_KIKAN_E_D,											
		         KANJYASU_NSU_ZAITAKU_KANJYASU,											
		         KANJYASU_NSU_ZAITAKU_KIKAN_S_Y,											
		         KANJYASU_NSU_ZAITAKU_KIKAN_S_M,											
		         KANJYASU_NSU_ZAITAKU_KIKAN_S_D,											
		         KANJYASU_NSU_ZAITAKU_KIKAN_E_Y,											
		         KANJYASU_NSU_ZAITAKU_KIKAN_E_M,											
		         KANJYASU_NSU_ZAITAKU_KIKAN_E_D,											
		         AVGNISSU_IPPAN,											
		         AVGNISSU_RYOYO,											
		         AVGNISSU_RYOYO_IRY,											
		         AVGNISSU_RYOYO_KIG,											
		         AVGNISSU_SEISHIN,											
		         AVGNISSU_KEKKAKU,											
		         AVGNISSU_KANSEN,											
		         AVGNISSU_ZENTAI,											
		         AVGNISSU_KIKAN_S_Y,											
		         AVGNISSU_KIKAN_S_M,											
		         AVGNISSU_KIKAN_S_D,											
		         AVGNISSU_KIKAN_E_Y,											
		         AVGNISSU_KIKAN_E_M,											
		         AVGNISSU_KIKAN_E_D,
                         TRK_OPE_CD,
		         TRK_DATE,
		         TRK_PGM_ID,
		         UPD_OPE_CD,
		         UPD_DATE,
		         UPD_PGM_ID)
                         SELECT
                         '00',
                         IK.SHI_CD,
                         -- ������2012/10/16 ST000101�̑Ή�
                         SUBSTR(TRIM(IK.JOHO_YMD),1,4),
                         SUBSTR(TRIM(IK.JOHO_YMD),5,2),
                         SUBSTR(TRIM(IK.JOHO_YMD),7,2),
                         -- ������2012/10/16 ST000101�̑Ή�
                         IK.ANNAIYO_URL,
                         IK.INNAI_SHOHO_FLG,
                         IK.INGAI_SHOHO_FLG,
                         IK.CHIKENJISSHI_FLG,
                         IK.CHIKENJISSHI_KIYK_KENSU,
                         SUBSTR(IK.CHIKENJISSHI_S_YMD,1,4),
                         SUBSTR(IK.CHIKENJISSHI_S_YMD,5,2),
                         SUBSTR(IK.CHIKENJISSHI_S_YMD,7,2),
                         SUBSTR(IK.CHIKENJISSHI_E_YMD,1,4),
                         SUBSTR(IK.CHIKENJISSHI_E_YMD,5,2),
                         SUBSTR(IK.CHIKENJISSHI_E_YMD,7,2),
	                 IK.STB_FLG,
	                 IK.SHIKKAN_CHRY_FLG,
	                 IK.TNK_TIZI_SJT_FLG,
	                 IK.SMG_FLG,
                         IK.CHIKRENKEI_MADOGUCHI_FLG ,
                         IK.CHIKRENKEIPATH_FLG_IKJ,
                         IK.NYUINSNRY_INNAI_RNKITISI_FLG,
                         IK.ORDERINGSYSTEM_FLG,
                         IK.ORDERINGSYSTEM_KENSA_FLG,
                         IK.ORDERINGSYSTEM_SHOHO_FLG,
                         IK.ORDERINGSYSTEM_YOYAKU_FLG,
                         IK.ICD_CD_RIYO_FLG,
                         IK.DENSHI_KARTE_FLG,
                         IK.KARTEKANRI_SENNIN_FLG,
                         IK.KARTEKANRI_SENNIN_SU,
                         TRIM(TO_CHAR(IK.KANJYASU_IPPAN_BED,'99990.0')),
                         TRIM(TO_CHAR(IK.KANJYASU_RYOYO_BED,'99990.0')),
                         TRIM(TO_CHAR(IK.KANJYASU_RYOYO_BED_IRY_HKN,'99990.0')),
                         TRIM(TO_CHAR(IK.KANJYASU_RYOYO_BED_KIG_HKN,'99990.0')),
                         TRIM(TO_CHAR(IK.KANJYASU_SEISHIN_BED ,'99990.0')),
                         TRIM(TO_CHAR(IK.KANJYASU_KEKKAKU_BED,'99990.0')),
                         TRIM(TO_CHAR(IK.KANJYASU_KANSEN,'99990.0')),
                         TRIM(TO_CHAR(IK.KANJYASU_ZENTAI_BED,'99990.0')),
                         SUBSTR(IK.KANJYASU_BED_SBT_S_YMD,1,4),
                         SUBSTR(IK.KANJYASU_BED_SBT_S_YMD,5,2),
                         SUBSTR(IK.KANJYASU_BED_SBT_S_YMD,7,2),
                         SUBSTR(IK.KANJYASU_BED_SBT_E_YMD,1,4),
                         SUBSTR(IK.KANJYASU_BED_SBT_E_YMD,5,2),
                         SUBSTR(IK.KANJYASU_BED_SBT_E_YMD,7,2),
                         TRIM(TO_CHAR(IK.KANJYASU_GAIRAI,'99990.0')),
                         SUBSTR(IK.KANJYASU_GAIRAI_S_YMD,1,4),
                         SUBSTR(IK.KANJYASU_GAIRAI_S_YMD,5,2),
                         SUBSTR(IK.KANJYASU_GAIRAI_S_YMD,7,2),
                         SUBSTR(IK.KANJYASU_GAIRAI_E_YMD,1,4),
                         SUBSTR(IK.KANJYASU_GAIRAI_E_YMD,5,2),
                         SUBSTR(IK.KANJYASU_GAIRAI_E_YMD,7,2),
                         TRIM(TO_CHAR(IK.KANJYASU_ZAITAKU,'99990.0')),
                         SUBSTR(IK.KANJYASU_ZAITAKU_S_YMD,1,4),
                         SUBSTR(IK.KANJYASU_ZAITAKU_S_YMD,5,2),
                         SUBSTR(IK.KANJYASU_ZAITAKU_S_YMD,7,2),
                         SUBSTR(IK.KANJYASU_ZAITAKU_E_YMD,1,4),
                         SUBSTR(IK.KANJYASU_ZAITAKU_E_YMD,5,2),
                         SUBSTR(IK.KANJYASU_ZAITAKU_E_YMD,7,2),
                         IK.KANJYANSU_IPPAN_BED,
                         IK.KANJYANSU_RYOYO_BED,
                         IK.KANJYANSU_RYOYO_BED_IRY_HKN,
                         IK.KANJYANSU_RYOYO_BED_KIG_HKN,
                         IK.KANJYANSU_SEISHIN_BED,
                         IK.KANJYANSU_KEKKAKU_BED,
                         IK.KANJYANSU_KANSEN,
                         IK.KANJYANSU_ZENTAI_BED,
                         SUBSTR(IK.KANJYANSU_BED_SBT_S_YMD,1,4),
                         SUBSTR(IK.KANJYANSU_BED_SBT_S_YMD,5,2),
                         SUBSTR(IK.KANJYANSU_BED_SBT_S_YMD,7,2),
                         SUBSTR(IK.KANJYANSU_BED_SBT_E_YMD,1,4),
                         SUBSTR(IK.KANJYANSU_BED_SBT_E_YMD,5,2),
                         SUBSTR(IK.KANJYANSU_BED_SBT_E_YMD,7,2),
                         IK.KANJYANSU_GAIRAI,
                         SUBSTR(IK.KANJYANSU_GAIRAI_S_YMD,1,4),
                         SUBSTR(IK.KANJYANSU_GAIRAI_S_YMD,5,2),
                         SUBSTR(IK.KANJYANSU_GAIRAI_S_YMD,7,2),
                         SUBSTR(IK.KANJYANSU_GAIRAI_E_YMD,1,4),
                         SUBSTR(IK.KANJYANSU_GAIRAI_E_YMD,5,2),
                         SUBSTR(IK.KANJYANSU_GAIRAI_E_YMD,7,2),										
                         IK.KANJYANSU_ZAITAKU,
                         SUBSTR(IK.KANJYANSU_ZAITAKU_S_YMD,1,4),
                         SUBSTR(IK.KANJYANSU_ZAITAKU_S_YMD,5,2),
                         SUBSTR(IK.KANJYANSU_ZAITAKU_S_YMD,7,2),
                         SUBSTR(IK.KANJYANSU_ZAITAKU_E_YMD,1,4),
                         SUBSTR(IK.KANJYANSU_ZAITAKU_E_YMD,5,2),
                         SUBSTR(IK.KANJYANSU_ZAITAKU_E_YMD,7,2),
                         TRIM(TO_CHAR(IK.AVGNISSU_IPPAN_BED,'99990.0')),
                         TRIM(TO_CHAR(IK.AVGNISSU_RYOYO_BED,'99990.0')),
                         TRIM(TO_CHAR(IK.AVGNISSU_RYOYO_BED_IRY_HKN,'99990.0')),
                         TRIM(TO_CHAR(IK.AVGNISSU_RYOYO_BED_KIG_HKN,'99990.0')),
                         TRIM(TO_CHAR(IK.AVGNISSU_SEISHIN_BED,'99990.0')),
                         TRIM(TO_CHAR(IK.AVGNISSU_KEKKAKU_BED ,'99990.0')),
                         TRIM(TO_CHAR(IK.AVGNISSU_KANSEN,'99990.0')),
                         TRIM(TO_CHAR(IK.AVGNISSU_ZENTAI_BED,'99990.0')),
                         SUBSTR(IK.AVGNISSU_S_YMD,1,4),
                         SUBSTR(IK.AVGNISSU_S_YMD,5,2),
                         SUBSTR(IK.AVGNISSU_S_YMD,7,2),
                         SUBSTR(IK.AVGNISSU_E_YMD,1,4),
                         SUBSTR(IK.AVGNISSU_E_YMD,5,2),
                         SUBSTR(IK.AVGNISSU_E_YMD,7,2),
                         iOPE_CD,
                         iDATE,
                         iPGM_ID,
                         iOPE_CD,
                         iDATE,
                         iPGM_ID
          FROM TT_TIKY_SHI S										
	     INNER JOIN TT_TIKY_IKJ_KIHON IK ON (										
		IK.REC_ID = S.REC_ID									
		AND IK.SHI_CD = S.SHI_CD)
        WHERE S.REC_ID = '00'							
	   AND S.DEL_FLG IS NULL
        AND (IK.JOHO_YMD IS NOT NULL													
	    OR IK.ANNAIYO_URL IS NOT NULL													
	    OR IK.INNAI_SHOHO_FLG IS NOT NULL													
	    OR IK.INGAI_SHOHO_FLG IS NOT NULL													
	    OR IK.CHIKENJISSHI_FLG IS NOT NULL													
	    OR IK.CHIKENJISSHI_S_YMD IS NOT NULL													
	    OR IK.CHIKENJISSHI_E_YMD IS NOT NULL													
	    OR IK.CHIKENJISSHI_KIYK_KENSU IS NOT NULL													
	    OR IK.CHIKRENKEI_MADOGUCHI_FLG IS NOT NULL													
	    OR IK.CHIKRENKEIPATH_FLG_IKJ IS NOT NULL													
	    OR IK.NYUINSNRY_INNAI_RNKITISI_FLG IS NOT NULL													
	    OR IK.ORDERINGSYSTEM_FLG IS NOT NULL													
	    OR IK.ORDERINGSYSTEM_KENSA_FLG IS NOT NULL													
	    OR IK.ORDERINGSYSTEM_SHOHO_FLG IS NOT NULL													
	    OR IK.ORDERINGSYSTEM_YOYAKU_FLG IS NOT NULL													
	    OR IK.ICD_CD_RIYO_FLG IS NOT NULL													
	    OR IK.DENSHI_KARTE_FLG IS NOT NULL													
	    OR IK.KARTEKANRI_SENNIN_FLG IS NOT NULL													
	    OR IK.KARTEKANRI_SENNIN_SU IS NOT NULL													
	    OR IK.COMMENTS IS NOT NULL													
	    OR IK.KANJYASU_IPPAN_BED IS NOT NULL													
	    OR IK.KANJYASU_RYOYO_BED IS NOT NULL													
	    OR IK.KANJYASU_RYOYO_BED_IRY_HKN IS NOT NULL													
	    OR IK.KANJYASU_RYOYO_BED_KIG_HKN IS NOT NULL													
	    OR IK.KANJYASU_SEISHIN_BED IS NOT NULL													
	    OR IK.KANJYASU_KEKKAKU_BED IS NOT NULL													
	    OR IK.KANJYASU_KANSEN IS NOT NULL													
	    OR IK.KANJYASU_ZENTAI_BED IS NOT NULL													
	    OR IK.KANJYASU_BED_SBT_S_YMD IS NOT NULL													
	    OR IK.KANJYASU_BED_SBT_E_YMD IS NOT NULL													
	    OR IK.KANJYASU_GAIRAI IS NOT NULL													
	    OR IK.KANJYASU_GAIRAI_S_YMD IS NOT NULL													
	    OR IK.KANJYASU_GAIRAI_E_YMD IS NOT NULL													
	    OR IK.KANJYASU_ZAITAKU IS NOT NULL													
	    OR IK.KANJYASU_ZAITAKU_S_YMD IS NOT NULL													
	    OR IK.KANJYASU_ZAITAKU_E_YMD IS NOT NULL													
	    OR IK.KANJYANSU_IPPAN_BED IS NOT NULL													
	    OR IK.KANJYANSU_RYOYO_BED IS NOT NULL													
	    OR IK.KANJYANSU_RYOYO_BED_IRY_HKN IS NOT NULL													
	    OR IK.KANJYANSU_RYOYO_BED_KIG_HKN IS NOT NULL													
	    OR IK.KANJYANSU_SEISHIN_BED IS NOT NULL													
	    OR IK.KANJYANSU_KEKKAKU_BED IS NOT NULL													
	    OR IK.KANJYANSU_KANSEN IS NOT NULL													
	    OR IK.KANJYANSU_ZENTAI_BED IS NOT NULL													
	    OR IK.KANJYANSU_BED_SBT_S_YMD IS NOT NULL													
	    OR IK.KANJYANSU_BED_SBT_E_YMD IS NOT NULL													
	    OR IK.KANJYANSU_GAIRAI IS NOT NULL													
	    OR IK.KANJYANSU_GAIRAI_S_YMD IS NOT NULL													
	    OR IK.KANJYANSU_GAIRAI_E_YMD IS NOT NULL													
	    OR IK.KANJYANSU_ZAITAKU IS NOT NULL													
	    OR IK.KANJYANSU_ZAITAKU_S_YMD IS NOT NULL													
	    OR IK.KANJYANSU_ZAITAKU_E_YMD IS NOT NULL													
	    OR IK.AVGNISSU_IPPAN_BED IS NOT NULL													
	    OR IK.AVGNISSU_RYOYO_BED IS NOT NULL													
	    OR IK.AVGNISSU_RYOYO_BED_IRY_HKN IS NOT NULL													
	    OR IK.AVGNISSU_RYOYO_BED_KIG_HKN IS NOT NULL													
	    OR IK.AVGNISSU_SEISHIN_BED IS NOT NULL													
	    OR IK.AVGNISSU_KEKKAKU_BED IS NOT NULL													
	    OR IK.AVGNISSU_KANSEN IS NOT NULL													
	    OR IK.AVGNISSU_ZENTAI_BED IS NOT NULL)	
            AND IK.DEL_FLG IS NULL;
	    EXECUTE_SQL := 'INSERT INTO TD_PA_IKJ_KHN(' ||
		         'DCF_CD_REC_ID,' ||											
		         'DCF_CD_SHI_CD,' ||											
		         'JOHO_YMD_Y,' ||											
		         'JOHO_YMD_M,' ||											
		         'JOHO_YMD_D,' ||											
		         'ANNAIYO_HOMEPAGE_ADDRESS,' ||											
		         'INNAI_SHOHO_FLG,' ||											
		         'INGAI_SHOHO_FLG,' ||											
		         'CHIKENJISSHI_FLG,' ||											
		         'CHIKENJISSHI_KIYK_KENSU,' ||											
		         'KIKAN_S_Y,' ||											
		         'KIKAN_S_M,' ||											
		         'KIKAN_S_D,' ||											
		         'KIKAN_E_Y,' ||											
		         'KIKAN_E_M,' ||											
		         'KIKAN_E_D,' ||											
		         'SHI_STB_FLG,' ||											
		         'SHIKKAN_CHRY_FLG,' ||											
		         'TNK_TIZI_SJT_FLG,' ||											
		         'SMG_FLG,' ||											
		         'RNKITISI_MADOGUCHI_FLG,' ||											
	                 'RNKITISI_CHIKRENKEIPATH_FLG,' ||											
		         'RNKITISI_RNKITISI,' ||											
		         'KNRTISI_ORDERINGSYSTEM_UMU_FLG,' ||											
		         'KNRTISI_ORDERINGSYSTEM_KENSA,' ||											
		         'KNRTISI_ORDERINGSYSTEM_SHOHO,' ||											
		         'KNRTISI_ORDERINGSYSTEM_YOYAKU,' ||											
		         'KNRTISI_ICD_CD_RIYO_FLG,' ||											
		         'KNRTISI_DENSHI_KARTE_FLG,' ||											
		         'KNRTISI_SENNIN_FLG,' ||											
		         'KNRTISI_SENNIN_SU,' ||											
		         'KANJYASU_AVG_BED_SBT_IPPAN,' ||											
		         'KANJYASU_AVG_BED_SBT_RYOYO,' ||											
		         'KANJYASU_AVG_BED_SBT_RYOYO_IRY,' ||											
		         'KANJYASU_AVG_BED_SBT_RYOYO_KIG,' ||											
		         'KANJYASU_AVG_BED_SBT_SEISHIN,' ||											
		         'KANJYASU_AVG_BED_SBT_KEKKAKU,' ||											
		         'KANJYASU_AVG_BED_SBT_KANSEN,' ||											
		         'KANJYASU_AVG_BED_SBT_ZENTAI,' ||											
		         'KANJYASU_AVG_BED_SBT_KIKAN_S_Y,' ||											
		         'KANJYASU_AVG_BED_SBT_KIKAN_S_M,' ||											
		         'KANJYASU_AVG_BED_SBT_KIKAN_S_D,' ||											
		         'KANJYASU_AVG_BED_SBT_KIKAN_E_Y,' ||											
		         'KANJYASU_AVG_BED_SBT_KIKAN_E_M,' ||											
		         'KANJYASU_AVG_BED_SBT_KIKAN_E_D,' ||											
		         'KANJYASU_AVG_GAIRAI_KANJYASU,	' ||										
		         'KANJYASU_AVG_GAIRAI_KIKAN_S_Y,' ||											
		         'KANJYASU_AVG_GAIRAI_KIKAN_S_M,' ||											
		         'KANJYASU_AVG_GAIRAI_KIKAN_S_D,' ||											
		         'KANJYASU_AVG_GAIRAI_KIKAN_E_Y,' ||											
		         'KANJYASU_AVG_GAIRAI_KIKAN_E_M,' ||											
		         'KANJYASU_AVG_GAIRAI_KIKAN_E_D,' ||											
		         'KANJYASU_AVG_ZAITAKU_KANJYASU,' ||											
		         'KANJYASU_AVG_ZAITAKU_KIKAN_S_Y,' ||											
		         'KANJYASU_AVG_ZAITAKU_KIKAN_S_M,' ||											
		         'KANJYASU_AVG_ZAITAKU_KIKAN_S_D,' ||											
		         'KANJYASU_AVG_ZAITAKU_KIKAN_E_Y,' ||											
		         'KANJYASU_AVG_ZAITAKU_KIKAN_E_M,' ||											
		         'KANJYASU_AVG_ZAITAKU_KIKAN_E_D,' ||											
		         'KANJYASU_NSU_BED_SBT_IPPAN,' ||											
		         'KANJYASU_NSU_BED_SBT_RYOYO,	' ||										
		         'KANJYASU_NSU_BED_SBT_RYOYO_IRY,' ||											
		         'KANJYASU_NSU_BED_SBT_RYOYO_KIG,' ||											
		         'KANJYASU_NSU_BED_SBT_SEISHIN,	' ||										
		         'KANJYASU_NSU_BED_SBT_KEKKAKU,	' ||										
		         'KANJYASU_NSU_BED_SBT_KANSEN,	' ||										
		         'KANJYASU_NSU_BED_SBT_ZENTAI,	' ||										
		         'KANJYASU_NSU_BED_SBT_KIKAN_S_Y,' ||											
		         'KANJYASU_NSU_BED_SBT_KIKAN_S_M,' ||											
		         'KANJYASU_NSU_BED_SBT_KIKAN_S_D,' ||											
		         'KANJYASU_NSU_BED_SBT_KIKAN_E_Y,' ||											
		         'KANJYASU_NSU_BED_SBT_KIKAN_E_M,' ||											
		         'KANJYASU_NSU_BED_SBT_KIKAN_E_D,' ||											
		         'KANJYASU_NSU_GAIRAI_KANJYASU,	' ||										
		         'KANJYASU_NSU_GAIRAI_KIKAN_S_Y,' ||											
		         'KANJYASU_NSU_GAIRAI_KIKAN_S_M,' ||											
		         'KANJYASU_NSU_GAIRAI_KIKAN_S_D,' ||											
		         'KANJYASU_NSU_GAIRAI_KIKAN_E_Y,' ||											
		         'KANJYASU_NSU_GAIRAI_KIKAN_E_M,' ||											
		         'KANJYASU_NSU_GAIRAI_KIKAN_E_D,' ||											
		         'KANJYASU_NSU_ZAITAKU_KANJYASU,' ||											
		         'KANJYASU_NSU_ZAITAKU_KIKAN_S_Y,' ||											
		         'KANJYASU_NSU_ZAITAKU_KIKAN_S_M,' ||											
		         'KANJYASU_NSU_ZAITAKU_KIKAN_S_D,' ||											
		         'KANJYASU_NSU_ZAITAKU_KIKAN_E_Y,' ||											
		         'KANJYASU_NSU_ZAITAKU_KIKAN_E_M,' ||											
		         'KANJYASU_NSU_ZAITAKU_KIKAN_E_D,' ||											
		         'AVGNISSU_IPPAN,		' ||									
		         'AVGNISSU_RYOYO,		' ||									
		         'AVGNISSU_RYOYO_IRY,		' ||									
		         'AVGNISSU_RYOYO_KIG,		' ||									
		         'AVGNISSU_SEISHIN,		' ||									
		         'AVGNISSU_KEKKAKU,		' ||									
		         'AVGNISSU_KANSEN,		' ||									
		         'AVGNISSU_ZENTAI,		' ||									
		         'AVGNISSU_KIKAN_S_Y,		' ||									
		         'AVGNISSU_KIKAN_S_M,		' ||									
		         'AVGNISSU_KIKAN_S_D,		' ||									
		         'AVGNISSU_KIKAN_E_Y,		' ||									
		         'AVGNISSU_KIKAN_E_M,		' ||									
		         'AVGNISSU_KIKAN_E_D,' ||
                         'TRK_OPE_CD,' ||
		         'TRK_DATE,' ||
		         'TRK_PGM_ID,' ||
		         'UPD_OPE_CD,' ||
		         'UPD_DATE,' ||
		         'UPD_PGM_ID)' ||
                          '     SELECT                                           ' ||
                          '''00'''  || ',' ||
                         'IK.SHI_CD,' ||
                         'SUBSTR(IK.JOHO_YMD,1,4),' ||
                         'SUBSTR(IK.JOHO_YMD,5,2),' ||
                         'SUBSTR(IK.JOHO_YMD,7,2),' ||
                         'IK.ANNAIYO_URL,' ||
                         'IK.INNAI_SHOHO_FLG,' ||
                         'IK.INGAI_SHOHO_FLG,' ||
                         'IK.CHIKENJISSHI_FLG,' ||
                         'IK.CHIKENJISSHI_KIYK_KENSU,' ||
                         'SUBSTR(IK.CHIKENJISSHI_S_YMD,1,4),' ||
                         'SUBSTR(IK.CHIKENJISSHI_S_YMD,5,2),' ||
                         'SUBSTR(IK.CHIKENJISSHI_S_YMD,7,2),' ||
                         'SUBSTR(IK.CHIKENJISSHI_E_YMD,1,4),' ||
                         'SUBSTR(IK.CHIKENJISSHI_E_YMD,5,2),' ||
                         'SUBSTR(IK.CHIKENJISSHI_E_YMD,7,2),' ||
	                 'IK.STB_FLG,' ||
	                 'IK.SHIKKAN_CHRY_FLG,' ||
	                 'IK.TNK_TIZI_SJT_FLG,' ||
	                 'IK.SMG_FLG,' ||
                         'IK.CHIKRENKEI_MADOGUCHI_FLG ,' ||
                         'IK.CHIKRENKEIPATH_FLG_IKJ,' ||
                         'IK.NYUINSNRY_INNAI_RNKITISI_FLG,' ||
                         'IK.ORDERINGSYSTEM_FLG,' ||
                         'IK.ORDERINGSYSTEM_KENSA_FLG,' ||
                         'IK.ORDERINGSYSTEM_SHOHO_FLG,' ||
                         'IK.ORDERINGSYSTEM_YOYAKU_FLG,' ||
                         'IK.ICD_CD_RIYO_FLG,' ||
                         'IK.DENSHI_KARTE_FLG,' ||
                         'IK.KARTEKANRI_SENNIN_FLG,' ||
                         'IK.KARTEKANRI_SENNIN_SU,' ||
                         'TRIM(TO_CHAR(IK.KANJYASU_IPPAN_BED,' || '''99990.0''' || ')),' ||
                         'TRIM(TO_CHAR(IK.KANJYASU_RYOYO_BED,' || '''99990.0''' || ')),' ||
                         'TRIM(TO_CHAR(IK.KANJYASU_RYOYO_BED_IRY_HKN,' || '''99990.0''' || ')),' ||
                         'TRIM(TO_CHAR(IK.KANJYASU_RYOYO_BED_KIG_HKN,' || '''99990.0''' || ')),' ||
                         'TRIM(TO_CHAR(IK.KANJYASU_SEISHIN_BED ,' || '''99990.0''' || ')),' ||
                         'TRIM(TO_CHAR(IK.KANJYASU_KEKKAKU_BED,' || '''99990.0''' || ')),' ||
                         'TRIM(TO_CHAR(IK.KANJYASU_KANSEN,' || '''99990.0''' || ')),' ||
                         'TRIM(TO_CHAR(IK.KANJYASU_ZENTAI_BED,' || '''99990.0''' || ')),' ||
                         'SUBSTR(IK.KANJYASU_BED_SBT_S_YMD,1,4),' ||
                         'SUBSTR(IK.KANJYASU_BED_SBT_S_YMD,5,2),' ||
                         'SUBSTR(IK.KANJYASU_BED_SBT_S_YMD,7,2),' ||
                         'SUBSTR(IK.KANJYASU_BED_SBT_E_YMD,1,4),' ||
                         'SUBSTR(IK.KANJYASU_BED_SBT_E_YMD,5,2),' ||
                         'SUBSTR(IK.KANJYASU_BED_SBT_E_YMD,7,2),' ||
                         'TRIM(TO_CHAR(IK.KANJYASU_GAIRAI,' || '''99990.0''' || ')),' ||
                         'SUBSTR(IK.KANJYASU_GAIRAI_S_YMD,1,4),' ||
                         'SUBSTR(IK.KANJYASU_GAIRAI_S_YMD,5,2),' ||
                         'SUBSTR(IK.KANJYASU_GAIRAI_S_YMD,7,2),' ||
                         'SUBSTR(IK.KANJYASU_GAIRAI_E_YMD,1,4),' ||
                         'SUBSTR(IK.KANJYASU_GAIRAI_E_YMD,5,2),' ||
                         'SUBSTR(IK.KANJYASU_GAIRAI_E_YMD,7,2),' ||
                         'TRIM(TO_CHAR(IK.KANJYASU_ZAITAKU,' || '''99990.0''' || ')),' ||
                         'SUBSTR(IK.KANJYASU_ZAITAKU_S_YMD,1,4),' ||
                         'SUBSTR(IK.KANJYASU_ZAITAKU_S_YMD,5,2),' ||
                         'SUBSTR(IK.KANJYASU_ZAITAKU_S_YMD,7,2),' ||
                         'SUBSTR(IK.KANJYASU_ZAITAKU_E_YMD,1,4),' ||
                         'SUBSTR(IK.KANJYASU_ZAITAKU_E_YMD,5,2),' ||
                         'SUBSTR(IK.KANJYASU_ZAITAKU_E_YMD,7,2),' ||
                         'IK.KANJYANSU_IPPAN_BED,' ||
                         'IK.KANJYANSU_RYOYO_BED,' ||
                         'IK.KANJYANSU_RYOYO_BED_IRY_HKN,' ||
                         'IK.KANJYANSU_RYOYO_BED_KIG_HKN,' ||
                         'IK.KANJYANSU_SEISHIN_BED,' ||
                         'IK.KANJYANSU_KEKKAKU_BED,' ||
                         'IK.KANJYANSU_KANSEN,' ||
                         'IK.KANJYANSU_ZENTAI_BED,' ||
                         'SUBSTR(IK.KANJYANSU_BED_SBT_S_YMD,1,4),' ||
                         'SUBSTR(IK.KANJYANSU_BED_SBT_S_YMD,5,2),' ||
                         'SUBSTR(IK.KANJYANSU_BED_SBT_S_YMD,7,2),' ||
                         'SUBSTR(IK.KANJYANSU_BED_SBT_E_YMD,1,4),' ||
                         'SUBSTR(IK.KANJYANSU_BED_SBT_E_YMD,5,2),' ||
                         'SUBSTR(IK.KANJYANSU_BED_SBT_E_YMD,7,2),' ||
                         'IK.KANJYANSU_GAIRAI,' ||
                         'SUBSTR(IK.KANJYANSU_GAIRAI_S_YMD,1,4),' ||
                         'SUBSTR(IK.KANJYANSU_GAIRAI_S_YMD,5,2),' ||
                         'SUBSTR(IK.KANJYANSU_GAIRAI_S_YMD,7,2),' ||
                         'SUBSTR(IK.KANJYANSU_GAIRAI_E_YMD,1,4),' ||
                         'SUBSTR(IK.KANJYANSU_GAIRAI_E_YMD,5,2),' ||
                         'SUBSTR(IK.KANJYANSU_GAIRAI_E_YMD,7,2),' ||										
                         'IK.KANJYANSU_ZAITAKU,' ||
                         'SUBSTR(IK.KANJYANSU_ZAITAKU_S_YMD,1,4),' ||
                         'SUBSTR(IK.KANJYANSU_ZAITAKU_S_YMD,5,2),' ||
                         'SUBSTR(IK.KANJYANSU_ZAITAKU_S_YMD,7,2),' ||
                         'SUBSTR(IK.KANJYANSU_ZAITAKU_E_YMD,1,4),' ||
                         'SUBSTR(IK.KANJYANSU_ZAITAKU_E_YMD,5,2),' ||
                         'SUBSTR(IK.KANJYANSU_ZAITAKU_E_YMD,7,2),' ||
                         'TRIM(TO_CHAR(IK.AVGNISSU_IPPAN_BED,' || '''99990.0''' || ')),' ||
                         'TRIM(TO_CHAR(IK.AVGNISSU_RYOYO_BED,' || '''99990.0''' || ')),' ||
                         'TRIM(TO_CHAR(IK.AVGNISSU_RYOYO_BED_IRY_HKN,' || '''99990.0''' || ')),' ||
                         'TRIM(TO_CHAR(IK.AVGNISSU_RYOYO_BED_KIG_HKN,' || '''99990.0''' || ')),' ||
                         'TRIM(TO_CHAR(IK.AVGNISSU_SEISHIN_BED,' || '''99990.0''' || ')),' ||
                         'TRIM(TO_CHAR(IK.AVGNISSU_KEKKAKU_BED ,' || '''99990.0''' || ')),' ||
                         'TRIM(TO_CHAR(IK.AVGNISSU_KANSEN,' || '''99990.0''' || ')),' ||
                         'TRIM(TO_CHAR(IK.AVGNISSU_ZENTAI_BED,' || '''99990.0''' || ')),' ||
                         'SUBSTR(IK.AVGNISSU_S_YMD,1,4),' ||
                         'SUBSTR(IK.AVGNISSU_S_YMD,5,2),' ||
                         'SUBSTR(IK.AVGNISSU_S_YMD,7,2),' ||
                         'SUBSTR(IK.AVGNISSU_E_YMD,1,4),' ||
                         'SUBSTR(IK.AVGNISSU_E_YMD,5,2),' ||
                         'SUBSTR(IK.AVGNISSU_E_YMD,7,2),' ||
                         'iOPE_CD,' ||
                         'iDATE,' ||
                         'iPGM_ID,' ||
                         'iOPE_CD,' ||
                         'iDATE,' ||
                         'iPGM_ID' ||
          'FROM TT_TIKY_SHI S	' ||									
	     'INNER JOIN TT_TIKY_IKJ_KIHON IK ON (	' ||									
		'IK.REC_ID = S.REC_ID			' ||						
		'AND IK.SHI_CD = S.SHI_CD)' ||
        'WHERE S.REC_ID = ''00''		' ||					
	   'AND S.DEL_FLG IS NULL' ||
        'AND (IK.JOHO_YMD IS NOT NULL' ||													
	    'OR IK.ANNAIYO_URL IS NOT NULL	' ||												
	    'OR IK.INNAI_SHOHO_FLG IS NOT NULL	' ||												
	    'OR IK.INGAI_SHOHO_FLG IS NOT NULL	' ||												
	    'OR IK.CHIKENJISSHI_FLG IS NOT NULL	' ||												
	    'OR IK.CHIKENJISSHI_S_YMD IS NOT NULL ' ||													
	    'OR IK.CHIKENJISSHI_E_YMD IS NOT NULL ' ||													
	    'OR IK.CHIKENJISSHI_KIYK_KENSU IS NOT NULL	' ||												
	    'OR IK.CHIKRENKEI_MADOGUCHI_FLG IS NOT NULL	' ||												
	    'OR IK.CHIKRENKEIPATH_FLG_IKJ IS NOT NULL	' ||												
	    'OR IK.NYUINSNRY_INNAI_RNKITISI_FLG IS NOT NULL	' ||												
	    'OR IK.ORDERINGSYSTEM_FLG IS NOT NULL		' ||											
	    'OR IK.ORDERINGSYSTEM_KENSA_FLG IS NOT NULL		' ||											
	    'OR IK.ORDERINGSYSTEM_SHOHO_FLG IS NOT NULL		' ||											
	    'OR IK.ORDERINGSYSTEM_YOYAKU_FLG IS NOT NULL	' ||												
	    'OR IK.ICD_CD_RIYO_FLG IS NOT NULL			' ||										
	    'OR IK.DENSHI_KARTE_FLG IS NOT NULL			' ||										
	    'OR IK.KARTEKANRI_SENNIN_FLG IS NOT NULL		' ||											
	    'OR IK.KARTEKANRI_SENNIN_SU IS NOT NULL		' ||											
	    'OR IK.COMMENTS IS NOT NULL				' ||									
	    'OR IK.KANJYASU_IPPAN_BED IS NOT NULL		' ||											
	    'OR IK.KANJYASU_RYOYO_BED IS NOT NULL		' ||											
	    'OR IK.KANJYASU_RYOYO_BED_IRY_HKN IS NOT NULL	' ||												
	    'OR IK.KANJYASU_RYOYO_BED_KIG_HKN IS NOT NULL	' ||												
	    'OR IK.KANJYASU_SEISHIN_BED IS NOT NULL		' ||											
	    'OR IK.KANJYASU_KEKKAKU_BED IS NOT NULL		' ||											
	    'OR IK.KANJYASU_KANSEN IS NOT NULL			' ||										
	    'OR IK.KANJYASU_ZENTAI_BED IS NOT NULL		' ||											
	    'OR IK.KANJYASU_BED_SBT_S_YMD IS NOT NULL		' ||											
	    'OR IK.KANJYASU_BED_SBT_E_YMD IS NOT NULL		' ||											
	    'OR IK.KANJYASU_GAIRAI IS NOT NULL			' ||										
	    'OR IK.KANJYASU_GAIRAI_S_YMD IS NOT NULL		' ||											
	    'OR IK.KANJYASU_GAIRAI_E_YMD IS NOT NULL		' ||											
	    'OR IK.KANJYASU_ZAITAKU IS NOT NULL			' ||										
	    'OR IK.KANJYASU_ZAITAKU_S_YMD IS NOT NULL		' ||											
	    'OR IK.KANJYASU_ZAITAKU_E_YMD IS NOT NULL		' ||											
	    'OR IK.KANJYANSU_IPPAN_BED IS NOT NULL		' ||											
	    'OR IK.KANJYANSU_RYOYO_BED IS NOT NULL		' ||											
	    'OR IK.KANJYANSU_RYOYO_BED_IRY_HKN IS NOT NULL	' ||												
	    'OR IK.KANJYANSU_RYOYO_BED_KIG_HKN IS NOT NULL	' ||												
	    'OR IK.KANJYANSU_SEISHIN_BED IS NOT NULL		' ||											
	    'OR IK.KANJYANSU_KEKKAKU_BED IS NOT NULL		' ||											
	    'OR IK.KANJYANSU_KANSEN IS NOT NULL			' ||										
	    'OR IK.KANJYANSU_ZENTAI_BED IS NOT NULL		' ||											
	    'OR IK.KANJYANSU_BED_SBT_S_YMD IS NOT NULL		' ||											
	    'OR IK.KANJYANSU_BED_SBT_E_YMD IS NOT NULL		' ||											
	    'OR IK.KANJYANSU_GAIRAI IS NOT NULL			' ||										
	    'OR IK.KANJYANSU_GAIRAI_S_YMD IS NOT NULL		' ||											
	    'OR IK.KANJYANSU_GAIRAI_E_YMD IS NOT NULL		' ||											
	    'OR IK.KANJYANSU_ZAITAKU IS NOT NULL		' ||											
	    'OR IK.KANJYANSU_ZAITAKU_S_YMD IS NOT NULL		' ||											
	    'OR IK.KANJYANSU_ZAITAKU_E_YMD IS NOT NULL		' ||											
	    'OR IK.AVGNISSU_IPPAN_BED IS NOT NULL		' ||											
	    'OR IK.AVGNISSU_RYOYO_BED IS NOT NULL		' ||											
	    'OR IK.AVGNISSU_RYOYO_BED_IRY_HKN IS NOT NULL	' ||												
	    'OR IK.AVGNISSU_RYOYO_BED_KIG_HKN IS NOT NULL	' ||												
	    'OR IK.AVGNISSU_SEISHIN_BED IS NOT NULL		' ||											
	    'OR IK.AVGNISSU_KEKKAKU_BED IS NOT NULL		' ||											
	    'OR IK.AVGNISSU_KANSEN IS NOT NULL			' ||										
	    'OR IK.AVGNISSU_ZENTAI_BED IS NOT NULL)	' ||
            'AND IK.DEL_FLG IS NULL';

		ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);	

        END IF; 
      END IF;
      COMMIT;
      -- �I�����O�o��
      ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'PL/SQL End',PGM_ID || '�̏������I�����܂����B',iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);
      return 0;
    -- ��O����
	EXCEPTION
		-- ���̑��G���[
		WHEN OTHERS THEN
			W_ERR_INF_RCD.ERR_CD 		:= TO_CHAR(SQLCODE);
			W_ERR_INF_RCD.ERR_MSG 		:= SUBSTR(SQLERRM, 0, 500);
			W_ERR_INF_RCD.ERR_KEY_INF 	:= SUBSTR('iLayoutKind:' || iLayoutKind || ', iShimeKind:' || iShimeKind , 0,500);
			W_INDEX_N 			:= W_ERR_INF_TBL.COUNT + 1;
			W_ERR_INF_TBL.EXTEND;
			W_ERR_INF_TBL(W_INDEX_N) 	:= W_ERR_INF_RCD;

			OPEN oOUT_ERR_INF_CSR FOR
				SELECT * FROM TABLE(W_ERR_INF_TBL);

	   ROLLBACK;
        
	  --�G���[���O�̓o�^
          ULT_INSERT_LOG_TABLE('ERROR',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'ERROR_INFO',W_ERR_INF_RCD.ERR_MSG,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

        return 1;
        END;
    END;
/

