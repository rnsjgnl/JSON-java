CREATE OR REPLACE PACKAGE NH010106B001_124
/* **********************************************************
 *  Copyright(c) 2011 beyond, INTEC Inc. All rights reserved.
 * **********************************************************/
AUTHID CURRENT_USER
IS
	/*** �J�[�\���^ ***************************************************************/
	-- �G���[���i�[�p�J�[�\���^
	TYPE ERR_INF_CSR		IS REF CURSOR;

  /*
  ************************************************************************
  *  �V_�S��_2����Ì��Z���e�[�u���̍쐬
  *  CREATE_TD_NA_IRK_2JI_JUSHO
  ************************************************************************
  */
  FUNCTION CREATE_TD_NA_IRK_2JI_JUSHO(
  iLayoutKbn  IN  INTEGER,                    -- ���C�A�E�g�敪
  iShimeKind  IN  INTEGER,                    -- ���ߓ��敪
  iTensoYMD	IN	VARCHAR2,                     -- �]���N����
  iOPE_CD IN Varchar2,                      -- �I�y���[�^�R�[�h
  iPGM_ID IN Varchar2,                      -- �v���O����ID
  iDATE DATE,                               -- �V�X�e������
  iIP_ADDR  IN TL_STORED_SHORI.IP%TYPE,              -- ���s�[��IP�A�h���X (FW�Őݒ�)
  iWINDOWS_LOGIN_USER  IN TL_STORED_SHORI.WINDOWS_LOGIN_USER%TYPE, -- ���s�[��OS���[�U�[ (FW�Őݒ�)
  oROW_COUNT  OUT NUMBER,         -- �o�^����
  oOUT_ERR_INF_CSR   OUT ERR_INF_CSR    -- �G���[���J�[�\��
  ) RETURN NUMBER;  

END;
/
CREATE OR REPLACE PACKAGE BODY NH010106B001_124
/* **********************************************************
 *  Copyright(c) 2011 beyond, INTEC Inc. All rights reserved.
 * **********************************************************/
IS
  /*
   ************************************************************************
   * Function ID  : CREATE_TD_NA_IRK_2JI_JUSHO
   * Program Name : �V_�S��_2����Ì��Z���e�[�u���̍쐬
   * Parameter    :  <I> iLayoutKbn    �F���C�A�E�g�敪
   *                 <I> iShimeKind    �F���ߓ��敪
   *                 <I> iTensoYMD    �F�]���N����
   *                 <I> iOPE_CD    �F�I�y���[�^�R�[�h
   *                 <I> iPGM_ID    �F�v���O����ID
   *                 <I> iDATE    �F�V�X�e������ 
   *                 <I> iIP_ADDR    �F���s�[��IP�A�h���X
   *                 <I> iWINDOWS_LOGIN_USER  �F���s�[��IP�A�h���X
   *                <O> oROW_COUNT        �F�X�V����
   *                <O> oOUT_ERR_INF_CSR  �F�G���[���J�[�\��
   * Return       �F�������ʁi0:����I���A1:�ُ�I���j
   ************************************************************************
   */
  FUNCTION CREATE_TD_NA_IRK_2JI_JUSHO(
  iLayoutKbn  IN  INTEGER,                    -- ���C�A�E�g�敪
  iShimeKind  IN  INTEGER,                    -- ���ߓ��敪
  iTensoYMD	IN	VARCHAR2,                     -- �]���N����
  iOPE_CD IN Varchar2,                      -- �I�y���[�^�R�[�h
  iPGM_ID IN Varchar2,                      -- �v���O����ID
  iDATE DATE,                               -- �V�X�e������  
  iIP_ADDR  IN TL_STORED_SHORI.IP%TYPE,              -- ���s�[��IP�A�h���X (FW�Őݒ�)
  iWINDOWS_LOGIN_USER  IN TL_STORED_SHORI.WINDOWS_LOGIN_USER%TYPE, -- ���s�[��OS���[�U�[ (FW�Őݒ�)
  oROW_COUNT  OUT NUMBER,         -- �o�^����
  oOUT_ERR_INF_CSR   OUT ERR_INF_CSR    -- �G���[���J�[�\��
  )RETURN NUMBER IS
PRAGMA AUTONOMOUS_TRANSACTION;
  /************************************************************************/
  /*                              �G���[����                              */
  /************************************************************************/
  W_INDEX_N           NUMBER(10) := 0;
  W_ERR_INF_TBL         TYPE_ERR_INFO_TBL := TYPE_ERR_INFO_TBL();
  W_ERR_INF_RCD         TYPE_ERR_INFO_RCD := TYPE_ERR_INFO_RCD(NULL,NULL,NULL,NULL);
  vSchemaNm     TM_JOSU.HANYO_KOMOKU%TYPE := NULL; -- �X�L�[�}����
  PGM_ID        VARCHAR2(50) := 'NH010106B001_124.CREATE_TD_NA_IRK_2JI_JUSHO';
  EXECUTE_SQL   VARCHAR2(32767) := NULL;
 
  BEGIN
  	   -- �J�n���O�o��
       ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'PL/SQL Start',PGM_ID || '�̏������J�n���܂��B',iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);
        
      --�V���C�A�E�g
      IF iLayoutKbn = ULT_COMMON.LAYOUT_SBT_CD_SHIN THEN
      
         -- �[�i�p�X�L�[�}�̎擾���s���B
         vSchemaNm := ULT_COMMON.GET_SCHEMA_NAME(ULT_COMMON.SYS_ENV_JOSU_DAI_CD, ULT_COMMON.NOHIN_SHEMA_JOSU_SHO_CD);

         --�V_�S��_2����Ì��Z���̃f�[�^���N���A����
         EXECUTE IMMEDIATE 'TRUNCATE TABLE ' || vSchemaNm || '.' || 'TD_NA_IRK_2JI_JUSHO';
         
          -- �V_�S��_2����Ì��Z���̃f�[�^��o�^����
          INSERT INTO TD_NA_IRK_2JI_JUSHO(
                LAYOUT_KBN                     ,
                IRK_CD_KEN_CD_2JI              ,
                IRK_CD_IRK_CD_2JI              ,
                MOD_KBN                        ,
                JIS_JUSHO_CD_KEN               ,
                JIS_JUSHO_CD_SHIKU             ,
                YOBI_1                         ,
                MENTE_YMD                      ,
                YOBI_2                         ,
                IDOMOTO_2JI_CD_KEN_CD          ,
                IDOMOTO_2JI_CD_IRK_CD          ,
                TSUIKA_DEL_KBN                 ,
                TENSO_YMD                      ,   
                TRK_OPE_CD                     ,
                TRK_DATE                       ,
                TRK_PGM_ID                     ,
                UPD_OPE_CD                     ,
                UPD_DATE                       ,
                UPD_PGM_ID)  
            SELECT
                '124',
                SUBSTR(A.IRK_2JI_CD,1,2),
                SUBSTR(A.IRK_2JI_CD,3,2),
                NULL,
                A.KEN_CD,
                A.SHIKU_CD,
                NULL, 
                DECODE(iShimeKind,'1',A.UPD_EIGY_YMD,NULL),
                NULL,
                NULL,
                NULL,
                NULL,
                DECODE(iShimeKind,'1',iTensoYMD,NULL),                                                       
                iOPE_CD,
                iDATE,
                iPGM_ID,
                iOPE_CD,
                iDATE,
                iPGM_ID
            FROM TT_TIKY_IRK_KANKATSU A                                                                                   
    		ORDER BY IRK_2JI_CD ASC,KEN_CD ASC,SHIKU_CD ASC;
                       
       -- �V_�S��_2����Ì��Z���̃��O��o�^����
       EXECUTE_SQL:=' INSERT INTO TD_NA_IRK_2JI_JUSHO(                             ' ||
					'                 LAYOUT_KBN                     ,             ' ||
					'                 IRK_CD_KEN_CD_2JI              ,             ' ||
					'                 IRK_CD_IRK_CD_2JI              ,             ' ||
					'                 MOD_KBN                        ,             ' ||
					'                 JIS_JUSHO_CD_KEN               ,             ' ||
					'                 JIS_JUSHO_CD_SHIKU             ,             ' ||
					'                 YOBI_1                         ,             ' ||
					'                 MENTE_YMD                      ,             ' ||
					'                 YOBI_2                         ,             ' ||
					'                 IDOMOTO_2JI_CD_KEN_CD          ,             ' ||
					'                 IDOMOTO_2JI_CD_IRK_CD          ,             ' ||
					'                 TSUIKA_DEL_KBN                 ,             ' ||
					'                 TENSO_YMD                      ,             ' ||
					'                 TRK_OPE_CD                     ,             ' ||
					'                 TRK_DATE                       ,             ' ||
					'                 TRK_PGM_ID                     ,             ' ||
					'                 UPD_OPE_CD                     ,             ' ||
					'                 UPD_DATE                       ,             ' ||
					'                 UPD_PGM_ID)                                  ' ||
					'             SELECT                                           ' ||
					'                 ''124'',                                       ' ||
					'                 SUBSTR(A.IRK_2JI_CD,1,2),                    ' ||
					'                 SUBSTR(A.IRK_2JI_CD,3,2),                    ' ||
					'                 NULL,                                        ' ||
					'                 A.KEN_CD,                                    ' ||
					'                 A.SHIKU_CD,                                  ' ||
					'                 NULL,                                        ' ||
					'                 DECODE(' || iShimeKind || ',''1'',A.UPD_EIGY_YMD,NULL),  ' ||
					'                 NULL,                                        ' ||
					'                 NULL,                                        ' ||
					'                 NULL,                                        ' ||
					'                 NULL,                                        ' ||
					'                 DECODE(' || iShimeKind || ',''1'',iTensoYMD,NULL),       ' ||
					                 iOPE_CD  || ','                                ||
					                 iDATE    || ','                                ||
					                 iPGM_ID  || ','                                ||
					                 iOPE_CD  || ','                                ||
					                 iDATE    || ','                                ||
					                 iPGM_ID                                        ||
					'             FROM TT_TIKY_IRK_KANKATSU A                      ' ||
					'     		ORDER BY IRK_2JI_CD ASC,KEN_CD ASC,SHIKU_CD ASC    ' ;
       ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);
         
      END IF; 
  COMMIT;

  oROW_COUNT := -1;
  
  -- �I�����O�o��
  ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'PL/SQL End',PGM_ID || '�̏������I�����܂����B',iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);
  
  return 0;
  -- ��O����
  EXCEPTION
    -- ���̑��G���[
    WHEN OTHERS THEN
      W_ERR_INF_RCD.ERR_CD     := TO_CHAR(SQLCODE);
      W_ERR_INF_RCD.ERR_MSG     := SUBSTR(SQLERRM, 0, 500);
      W_ERR_INF_RCD.ERR_KEY_INF   := SUBSTR('iLayoutKbn:' || iLayoutKbn || ', iShimeKind:' || iShimeKind , 0,500);
      W_INDEX_N           := W_ERR_INF_TBL.COUNT + 1;
      W_ERR_INF_TBL.EXTEND;
      W_ERR_INF_TBL(W_INDEX_N)   := W_ERR_INF_RCD;

      OPEN oOUT_ERR_INF_CSR FOR
        SELECT * FROM TABLE(W_ERR_INF_TBL);

       ROLLBACK;
       
        --�G���[���O�̓o�^
        ULT_INSERT_LOG_TABLE('ERROR',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'ERROR_INFO',W_ERR_INF_RCD.ERR_MSG,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

  		return 1;
END;

END;
/
