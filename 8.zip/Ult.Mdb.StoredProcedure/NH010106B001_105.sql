CREATE OR REPLACE PACKAGE NH010106B001_105
/* **********************************************************
 *  Copyright(c) 2011 beyond, INTEC Inc. All rights reserved.
 * **********************************************************/
AUTHID CURRENT_USER
IS
	/*** �J�[�\���^ ***************************************************************/
	-- �G���[���i�[�p�J�[�\���^
	TYPE ERR_INF_CSR		IS REF CURSOR;

	/*
	************************************************************************
	*  SEF���̑��{�ݑf��DB�f�[�^�̍쐬
	*  CREATE_SEF_SONOTASHISETSU
	************************************************************************
	*/
	FUNCTION CREATE_SEF_SONOTASHISETSU(
		iLayoutKind		IN	INTEGER,				-- ���C�A�E�g�敪
		iShimeKind		IN	INTEGER,				-- ���ߓ��敪
		iTensoYMD		IN	VARCHAR2,				-- �]���N����
		iOPE_CD 		IN	Varchar2,                               -- �I�y���[�^�R�[�h
		iPGM_ID 		IN	Varchar2,                               -- �v���O����ID
		iDATE 			DATE,                                           -- �V�X�e������  
		iIP_ADDR		IN	TL_STORED_SHORI.IP%TYPE,		-- ���s�[��IP�A�h���X (FW�Őݒ�)
		iWINDOWS_LOGIN_USER	IN	TL_STORED_SHORI.WINDOWS_LOGIN_USER%TYPE,-- ���s�[��OS���[�U�[ (FW�Őݒ�)
		oROW_COUNT		OUT	NUMBER,                                	-- �o�^����
		oOUT_ERR_INF_CSR 	OUT	ERR_INF_CSR                            	-- �G���[���J�[�\��
	) RETURN NUMBER;

END;
/

CREATE OR REPLACE PACKAGE BODY NH010106B001_105
/* **********************************************************
 *  Copyright(c) 2011 beyond, INTEC Inc. All rights reserved.
 * **********************************************************/
IS
	/*
	 ************************************************************************
	 * Function ID  : CREATE_SEF_SONOTASHISETSU
	 * Program Name : SEF���̑��{�ݑf��DB�f�[�^�̍쐬
	 * Parameter    :  <I> iLayoutKind	    	�F���C�A�E�g�敪
	 *		   <I> iShimeKind	    	�F���ߓ��敪
	 *		   <I> iTensoYMD	    	�F�]���N����
	 *		   <I> iOPE_CD		        �F�I�y���[�^�R�[�h
	 *		   <I> iPGM_ID		        �F�v���O����ID
	 *		   <I> iDATE		        �F�V�X�e������ 
	 *		   <I> iIP_ADDR		        �F���s�[��IP�A�h���X
	 *		   <I> iWINDOWS_LOGIN_USER  	�F���s�[��IP�A�h���X
	 *                 <O> oROW_COUNT		�F�X�V����
	 *                 <O> oOUT_ERR_INF_CSR	�F�G���[���J�[�\��
	 * Return       �F�������ʁi0:����I���A1:�ُ�I���j
	 ************************************************************************
	 */
	FUNCTION CREATE_SEF_SONOTASHISETSU(
		iLayoutKind		IN	INTEGER,				-- ���C�A�E�g�敪
		iShimeKind		IN	INTEGER,				-- ���ߓ��敪
		iTensoYMD		IN	VARCHAR2,				-- �]���N����
		iOPE_CD 		IN	VARCHAR2,                               -- �I�y���[�^�R�[�h
		iPGM_ID 		IN	VARCHAR2,                               -- �v���O����ID
		iDATE 			DATE,                                           -- �V�X�e������  
		iIP_ADDR		IN	TL_STORED_SHORI.IP%TYPE,		-- ���s�[��IP�A�h���X (FW�Őݒ�)
		iWINDOWS_LOGIN_USER	IN	TL_STORED_SHORI.WINDOWS_LOGIN_USER%TYPE,-- ���s�[��OS���[�U�[ (FW�Őݒ�)
		oROW_COUNT		OUT	NUMBER,                                	-- �o�^����
		oOUT_ERR_INF_CSR 	OUT	ERR_INF_CSR                            	-- �G���[���J�[�\�� 
	)RETURN NUMBER IS

  PRAGMA AUTONOMOUS_TRANSACTION;
	/************************************************************************/
	/*                              �G���[����                              */
	/************************************************************************/
	W_INDEX_N 				NUMBER(10) := 0;
	W_ERR_INF_TBL 				TYPE_ERR_INFO_TBL := TYPE_ERR_INFO_TBL();
	W_ERR_INF_RCD 				TYPE_ERR_INFO_RCD := TYPE_ERR_INFO_RCD(NULL,NULL,NULL,NULL);
	
	V_SCHEMA_NM   TM_JOSU.HANYO_KOMOKU%TYPE := NULL; -- �X�L�[�}����
	PGM_ID        VARCHAR2(50) := 'NH010106B001_105.CREATE_SEF_SONOTASHISETSU';
	EXECUTE_SQL   VARCHAR2(32767) := NULL;

	BEGIN

	-- �J�n���O�o��
    	ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'PL/SQL Start',PGM_ID || '�̏������J�n���܂��B',iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

	  -- �X�V�����̏�����
	  oROW_COUNT := -1;

	  -- �[�i�p�X�L�[�}�̎擾���s���B
	  V_SCHEMA_NM := ULT_COMMON.GET_SCHEMA_NAME(ULT_COMMON.SYS_ENV_JOSU_DAI_CD, ULT_COMMON.NOHIN_SHEMA_JOSU_SHO_CD);

		-- ���ߋ敪:"1"(������)
		IF iShimeKind = 1 THEN
			-- �V���C�A�E�g
			IF iLayoutKind = 1 THEN

				-- �V_�S��_SEF���̑��{�݃e�[�u���̃f�[�^���N���A����
				EXECUTE_SQL := 'TRUNCATE TABLE ' || V_SCHEMA_NM || '.' || 'TD_NA_SEF_SHI';
				EXECUTE IMMEDIATE EXECUTE_SQL;
				ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

                                INSERT INTO TD_NA_SEF_SHI(
							LAYOUT_KBN,
							ECF_CD_REC_ID,
							ECF_CD_ECF_CD,
							ECF_CD_YOBI,
							MOD_KBN,
							MENTE_YMD,
							YOBI_1,
							MIKAKUNIN_FLG,
							DEL_YOTEI_RIYU,
							AITSK_CD_ECF_CD_REC_ID,
							AITSK_CD_ECF_CD_ECF_CD,
							AITSK_CD_ECF_CD_YOBI,
							SEISHIKI_TNP_SHI_NM_KANJI,
							SEISHIKI_TNP_SHI_NM_KANA,
							RYKSK_TNP_SHI_NM_KANJI,
							RYKSK_TNP_SHI_NM_KANA,
							JUSHOFUMEI,
							JUSHO_CD_KEN_CD,
							JUSHO_CD_SHIKU_CD,
							JUSHO_CD_OAZA_CD,
							JUSHO_CD_AZA_CD,
							ZIP,
							JUSHO_KANJI,
							JUSHO_KANA,
							JUSHO_HYOJI_NO,
							JUSHO_COUNT_KANJI_KEN,
							JUSHO_COUNT_KANJI_SHIKU,
							JUSHO_COUNT_KANJI_OAZA,
							JUSHO_COUNT_KANJI_AZA,
							JUSHO_COUNT_KANA_KEN,
							JUSHO_COUNT_KANA_SHIKU,
							JUSHO_COUNT_KANA_OAZA,
							JUSHO_COUNT_KANA_AZA,
							TEL_NASHI_FLG,
							TEL,
							KEIEITAI,
							SHI_KBN,
							YOBI_2,
							DAIHYO_KANJI,
							DAIHYO_KANA,
							KAIGYO_YOTEI_KAIGYO_YOTEI_FLG,
							KAIGYO_YOTEI_KAIGYO_YOTEI_YM,
							KYUIN_KYUIN_FLG,
							KYUIN_KYUIN_S_YM,
							YOBI_3,
							YOBI_4,
							YOBI_5,
							YOBI_6,
							TENSO_YMD,
							TRK_OPE_CD,
							TRK_DATE,
							TRK_PGM_ID,
							UPD_OPE_CD,
							UPD_DATE,
							UPD_PGM_ID)
                               SELECT
							'105',
							REC_ID,
							SHI_CD,
							NULL,
							NULL,
							UPD_EIGY_YMD,
							NULL,
							MIKAKUNIN_FLG,
							DEL_YOTEI_RIYU_CD,
							CHOFUKU_AITSK_REC_ID,
							CHOFUKU_AITSK_SHI_CD,
							NULL,
							SEISHIKI_SHI_NM,
							SEISHIKI_SHI_NM_KANA,
							SHI_RN,
							SHI_RN_KANA,
							JUSHOFUMEI_CD,
							KEN_CD,
							SHIKU_CD,
							OAZA_CD,
							AZA_CD,
							CASE WHEN ZIP IS NULL THEN '' ELSE SUBSTR(ZIP,1,3)||'-'||SUBSTR(ZIP,4) END,
							JUSHO_KANJI_RENKETSU,
							JUSHO_KANA_RENKETSU,
							JUSHO_HYOJI_NO,
							KEN_NM_KANJI_MOJI_SU,
							SHIKU_NM_KANJI_MOJI_SU,
							OAZA_NM_KANJI_MOJI_SU,
							AZA_NM_KANJI_MOJI_SU,
							KEN_NM_KANA_MOJI_SU,
							SHIKU_NM_KANA_MOJI_SU,
							OAZA_NM_KANA_MOJI_SU,
							AZA_NM_KANA_MOJI_SU,
							TEL_NASHI_FLG,
							TEL,
							KEIEITAI_CD,
							SHI_KBN_CD,
							NULL,
							DAIHYO_NM,
							DAIHYO_NM_KANA,
							KAIGYO_YOTEI_FLG,
							KAIGYO_YOTEI_YM,
							KYUIN_FLG,
							KYUIN_S_YM,
							NULL,
							NULL,
							NULL,
							NULL,
							iTensoYMD,
							iOPE_CD,
							iDATE,
							iPGM_ID,
							iOPE_CD,
							iDATE,
							iPGM_ID
	                        FROM TT_TIKY_SHI
	                        WHERE REC_ID = '06'
	                        AND DEL_FLG IS NULL
	                        AND (SUBSTR(SHI_KBN_CD, 1, 1) = 'G'
	                        OR SUBSTR(SHI_KBN_CD, 1, 1) = 'Q');
				-- �V_�S��_SEF���̑��{�݃e�[�u���̓o�^
 				EXECUTE_SQL :=  'INSERT INTO TD_NA_SEF_SHI('||
							'LAYOUT_KBN,'||
							'ECF_CD_REC_ID,'||
							'ECF_CD_ECF_CD,'||
							'ECF_CD_YOBI,'||
							'MOD_KBN,'||
							'MENTE_YMD,'||
							'YOBI_1,'||
							'MIKAKUNIN_FLG,'||
							'DEL_YOTEI_RIYU,'||
							'AITSK_CD_ECF_CD_REC_ID,'||
							'AITSK_CD_ECF_CD_ECF_CD,'||
							'AITSK_CD_ECF_CD_YOBI,'||
							'SEISHIKI_TNP_SHI_NM_KANJI,'||
							'SEISHIKI_TNP_SHI_NM_KANA,'||
							'RYKSK_TNP_SHI_NM_KANJI,'||
							'RYKSK_TNP_SHI_NM_KANA,'||
							'JUSHOFUMEI,'||
							'JUSHO_CD_KEN_CD,'||
							'JUSHO_CD_SHIKU_CD,'||
							'JUSHO_CD_OAZA_CD,'||
							'JUSHO_CD_AZA_CD,'||
							'ZIP,'||
							'JUSHO_KANJI,'||
							'JUSHO_KANA,'||
							'JUSHO_HYOJI_NO,'||
							'JUSHO_COUNT_KANJI_KEN,'||
							'JUSHO_COUNT_KANJI_SHIKU,'||
							'JUSHO_COUNT_KANJI_OAZA,'||
							'JUSHO_COUNT_KANJI_AZA,'||
							'JUSHO_COUNT_KANA_KEN,'||
							'JUSHO_COUNT_KANA_SHIKU,'||
							'JUSHO_COUNT_KANA_OAZA,'||
							'JUSHO_COUNT_KANA_AZA,'||
							'TEL_NASHI_FLG,'||
							'TEL,'||
							'KEIEITAI,'||
							'SHI_KBN,'||
							'YOBI_2,'||
							'DAIHYO_KANJI,'||
							'DAIHYO_KANA,'||
							'KAIGYO_YOTEI_KAIGYO_YOTEI_FLG,'||
							'KAIGYO_YOTEI_KAIGYO_YOTEI_YM,'||
							'KYUIN_KYUIN_FLG,'||
							'KYUIN_KYUIN_S_YM,'||
							'YOBI_3,'||
							'YOBI_4,'||
							'YOBI_5,'||
							'YOBI_6,'||
							'TENSO_YMD,'||
							'TRK_OPE_CD,'||
							'TRK_DATE,'||
							'TRK_PGM_ID,'||
							'UPD_OPE_CD,'||
							'UPD_DATE,'||
							'UPD_PGM_ID)'||
                                '    SELECT                                                          '||
                                                        '''105'''  || ','                                        ||
							'REC_ID,'||
							'SHI_CD,'||
							'NULL,'||
							'NULL,'||
							'UPD_EIGY_YMD,'||
							'NULL,'||
							'MIKAKUNIN_FLG,'||
							'DEL_YOTEI_RIYU_CD,'||
							'CHOFUKU_AITSK_REC_ID,'||
							'CHOFUKU_AITSK_SHI_CD,'||
							'NULL,'||
							'SEISHIKI_SHI_NM,'||
							'SEISHIKI_SHI_NM_KANA,'||
							'SHI_RN,'||
							'SHI_RN_KANA,'||
							'JUSHOFUMEI_CD,'||
							'KEN_CD,'||
							'SHIKU_CD,'||
							'OAZA_CD,'||
							'AZA_CD,'||
							'CASE WHEN ZIP IS NULL THEN '''' ELSE SUBSTR(ZIP,1,3)||''-''||SUBSTR(ZIP,4) END,'||
							'JUSHO_KANJI_RENKETSU,'||
							'JUSHO_KANA_RENKETSU,'||
							'JUSHO_HYOJI_NO,'||
							'KEN_NM_KANJI_MOJI_SU,'||
							'SHIKU_NM_KANJI_MOJI_SU,'||
							'OAZA_NM_KANJI_MOJI_SU,'||
							'AZA_NM_KANJI_MOJI_SU,'||
							'KEN_NM_KANA_MOJI_SU,'||
							'SHIKU_NM_KANA_MOJI_SU,'||
							'OAZA_NM_KANA_MOJI_SU,'||
							'AZA_NM_KANA_MOJI_SU,'||
							'TEL_NASHI_FLG,'||
							'TEL,'||
							'KEIEITAI_CD,'||
							'SHI_KBN_CD,'||
							'NULL,'||
							'DAIHYO_NM,'||
							'DAIHYO_NM_KANA,'||
							'KAIGYO_YOTEI_FLG,'||
							'KAIGYO_YOTEI_YM,'||
							'KYUIN_FLG,'||
							'KYUIN_S_YM,'||
							'NULL,'||
							'NULL,'||
							'NULL,'||
							'NULL,'||
							'iTensoYMD,'||
							'iOPE_CD,'||
							'iDATE,'||
							'iPGM_ID,'||
							'iOPE_CD,'||
							'iDATE,'||
							'iPGM_ID'||
	                        'FROM TT_TIKY_SHI'||
	                        'WHERE REC_ID = ''06'''||
	                        'AND DEL_FLG IS NULL'||
	                        'AND (SUBSTR(SHI_KBN_CD, 1, 1) = ''G'''||
	                        'OR SUBSTR(SHI_KBN_CD, 1, 1) = ''Q'')';
				ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);


	        -- �b�背�C�A�E�g
	        ELSIF iLayoutKind = 2 THEN

			-- �b��_�S��_SEF���̑��{�݃e�[�u���̃f�[�^���N���A����B
			EXECUTE_SQL := 'TRUNCATE TABLE ' || V_SCHEMA_NM || '.' || 'TD_PA_SEF_SHI';
			EXECUTE IMMEDIATE EXECUTE_SQL;
			ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

                        INSERT INTO TD_PA_SEF_SHI(
						ECF_CD_REC_ID,
						ECF_CD_ECF_CD,
						ECF_CD_YOBI,
						SEISHIKI_TNP_SHI_NM_KANA,
						RYKSK_TNP_SHI_NM_KANA,
						JUSHO_CD_KEN_CD,
						JUSHO_CD_SHIKU_CD,
						JUSHO_CD_OAZA_CD,
						JUSHO_CD_AZA_CD,
						ZIP,
						JUSHO_HYOJI_NO,
						YOBI_1,
						JUSHO_KANA,
						JUSHO_COUNT_KANA_KEN,
						JUSHO_COUNT_KANA_SHIKU,
						JUSHO_COUNT_KANA_OAZA,
						JUSHO_COUNT_KANA_AZA,
						JUSHO_COUNT_KANJI_KEN,
						JUSHO_COUNT_KANJI_SHIKU,
						JUSHO_COUNT_KANJI_OAZA,
						JUSHO_COUNT_KANJI_AZA,
						TEL,
						YOBI_2,
						YOBI_3,
						SHI_KBN,
						YOBI_4,
						STATUS_JUSHOFUMEI,
						STATUS_KYUTEN_FLG,
						STATUS_DEL_YOTEI_RIYU,
						STATUS_KAIGYO_YOTEI_FLG,
						STATUS_YOBI,
						KYTN_S_KGY_YOTEI_Y,
						KYTN_S_KGY_YOTEI_M,
						YOBI_5,
						SEISHIKI_TNP_SHI_NM_KANJI,
						RYKSK_TNP_SHI_NM_KANJI,
						JUSHO_KANJI,
						YOBI_6,
						DAIHYO_KANA,
						DAIHYO_KANJI,
						YOBI_7,
						AITSK_CD_ECF_CD_REC_ID,
						AITSK_CD_ECF_CD_ECF_CD,
						AITSK_CD_ECF_CD_YOBI,
						MOD_SHORI_HIZUKE_Y,
						MOD_SHORI_HIZUKE_M,
						MOD_SHORI_HIZUKE_D,
						TENSO_Y,
						TENSO_M,
						TENSO_D,
						KEIEITAI,
						SHIN_SEISHIKI_TNP_SHI_NM_KANJI,
						SHIN_SEISHIKI_TNP_SHI_NM_KANA,
						MOD_KBN,
						TRK_OPE_CD,
						TRK_DATE,
						TRK_PGM_ID,
						UPD_OPE_CD,
						UPD_DATE,
						UPD_PGM_ID)
                                SELECT
					REC_ID,
					SHI_CD,
					NULL,
					SEISHIKI_SHI_NM_KANA40,
					SHI_RN_KANA,
					KEN_CD,
					SHIKU_CD,
					OAZA_CD,
					AZA_CD,
					CASE WHEN ZIP IS NULL THEN '' ELSE SUBSTR(ZIP,1,3)||'-'||SUBSTR(ZIP,4) END,
					JUSHO_HYOJI_NO,
					NULL,
					JUSHO_KANA_RENKETSU,
					TO_CHAR(KEN_NM_KANA_MOJI_SU,'FM09'),
					TO_CHAR(SHIKU_NM_KANA_MOJI_SU,'FM09'),
					TO_CHAR(OAZA_NM_KANA_MOJI_SU,'FM09'),
					TO_CHAR(AZA_NM_KANA_MOJI_SU,'FM09'),
					TO_CHAR(KEN_NM_KANJI_MOJI_SU,'FM09'),
					TO_CHAR(SHIKU_NM_KANJI_MOJI_SU,'FM09'),
					TO_CHAR(OAZA_NM_KANJI_MOJI_SU,'FM09'),
					TO_CHAR(AZA_NM_KANJI_MOJI_SU,'FM09'),
					TEL,
					NULL,
					NULL,
					SHI_KBN_CD,
					NULL,
					JUSHOFUMEI_CD,
					KYUIN_FLG,
					DEL_YOTEI_RIYU_CD,
					KAIGYO_YOTEI_FLG,
					NULL,
					CASE WHEN KYUIN_FLG = '1' THEN SUBSTR(KYUIN_S_YM,1,4) WHEN KAIGYO_YOTEI_FLG = '1' THEN SUBSTR(KAIGYO_YOTEI_YM,1,4) END,
					CASE WHEN KYUIN_FLG = '1' THEN SUBSTR(KYUIN_S_YM,5,2) WHEN KAIGYO_YOTEI_FLG = '1' THEN SUBSTR(KAIGYO_YOTEI_YM,5,2) END,
					NULL,
					SEISHIKI_SHI_NM30,
					SHI_RN,
					JUSHO_KANJI_RENKETSU,
					NULL,
					DAIHYO_NM_KANA,
					DAIHYO_NM,
					NULL,
					CHOFUKU_AITSK_REC_ID,
					CHOFUKU_AITSK_SHI_CD,
					NULL,
					SUBSTR(UPD_EIGY_YMD,1,4),
					SUBSTR(UPD_EIGY_YMD,5,2),
					SUBSTR(UPD_EIGY_YMD,7,2),
					SUBSTR(iTensoYMD,1,4),
					SUBSTR(iTensoYMD,5,2),
					SUBSTR(iTensoYMD,7,2),
					KEIEITAI_CD,
					SEISHIKI_SHI_NM	,
					SEISHIKI_SHI_NM_KANA,
					NULL,
					iOPE_CD,
					iDATE,
					iPGM_ID,
					iOPE_CD,
					iDATE,
					iPGM_ID
	                FROM TT_TIKY_SHI
	                WHERE REC_ID = '06'
	                AND DEL_FLG IS NULL
	                AND (SUBSTR(SHI_KBN_CD, 1, 1) = 'G'
	                OR SUBSTR(SHI_KBN_CD, 1, 1) = 'Q');
			-- �b��_�S��_SEF���̑��{�݂̓o�^
			EXECUTE_SQL :=  'INSERT INTO TD_PA_SEF_SHI('||
						'ECF_CD_REC_ID,'||
						'ECF_CD_ECF_CD,'||
						'ECF_CD_YOBI,'||
						'SEISHIKI_TNP_SHI_NM_KANA,'||
						'RYKSK_TNP_SHI_NM_KANA,'||
						'JUSHO_CD_KEN_CD,'||
						'JUSHO_CD_SHIKU_CD,'||
						'JUSHO_CD_OAZA_CD,'||
						'JUSHO_CD_AZA_CD,'||
						'ZIP,'||
						'JUSHO_HYOJI_NO,'||
						'YOBI_1,'||
						'JUSHO_KANA,'||
						'JUSHO_COUNT_KANA_KEN,'||
						'JUSHO_COUNT_KANA_SHIKU,'||
						'JUSHO_COUNT_KANA_OAZA,'||
						'JUSHO_COUNT_KANA_AZA,'||
						'JUSHO_COUNT_KANJI_KEN,'||
						'JUSHO_COUNT_KANJI_SHIKU,'||
						'JUSHO_COUNT_KANJI_OAZA,'||
						'JUSHO_COUNT_KANJI_AZA,'||
						'TEL,'||
						'YOBI_2,'||
						'YOBI_3,'||
						'SHI_KBN,'||
						'YOBI_4,'||
						'STATUS_JUSHOFUMEI,'||
						'STATUS_KYUTEN_FLG,'||
						'STATUS_DEL_YOTEI_RIYU,'||
						'STATUS_KAIGYO_YOTEI_FLG,'||
						'STATUS_YOBI,'||
						'KYTN_S_KGY_YOTEI_Y,'||
						'KYTN_S_KGY_YOTEI_M,'||
						'YOBI_5,'||
						'SEISHIKI_TNP_SHI_NM_KANJI,'||
						'RYKSK_TNP_SHI_NM_KANJI,'||
						'JUSHO_KANJI,'||
						'YOBI_6,'||
						'DAIHYO_KANA,'||
						'DAIHYO_KANJI,'||
						'YOBI_7,'||
						'AITSK_CD_ECF_CD_REC_ID,'||
						'AITSK_CD_ECF_CD_ECF_CD,'||
						'AITSK_CD_ECF_CD_YOBI,'||
						'MOD_SHORI_HIZUKE_Y,'||
						'MOD_SHORI_HIZUKE_M,'||
						'MOD_SHORI_HIZUKE_D,'||
						'TENSO_Y,'||
						'TENSO_M,'||
						'TENSO_D,'||
						'KEIEITAI,'||
						'SHIN_SEISHIKI_TNP_SHI_NM_KANJI,'||
						'SHIN_SEISHIKI_TNP_SHI_NM_KANA,'||
						'MOD_KBN,'||
						'TRK_OPE_CD,'||
						'TRK_DATE,'||
						'TRK_PGM_ID,'||
						'UPD_OPE_CD,'||
						'UPD_DATE,'||
						'UPD_PGM_ID)'||
                                'SELECT'||
					'REC_ID,'||
					'SHI_CD,'||
					'NULL,'||
					'SEISHIKI_SHI_NM_KANA40,'||
					'SHI_RN_KANA,'||
					'KEN_CD,'||
					'SHIKU_CD,'||
					'OAZA_CD,'||
					'AZA_CD,'||
					'CASE WHEN ZIP IS NULL THEN '''' ELSE SUBSTR(ZIP,1,3)||''-''||SUBSTR(ZIP,4) END,'||
					'JUSHO_HYOJI_NO,'||
					'NULL,'||
					'JUSHO_KANA_RENKETSU,'||
					'TO_CHAR(KEN_NM_KANA_MOJI_SU,''FM09''),'||
					'TO_CHAR(SHIKU_NM_KANA_MOJI_SU,''FM09''),'||
					'TO_CHAR(OAZA_NM_KANA_MOJI_SU,''FM09''),'||
					'TO_CHAR(AZA_NM_KANA_MOJI_SU,''FM09''),'||
					'TO_CHAR(KEN_NM_KANJI_MOJI_SU,''FM09''),'||
					'TO_CHAR(SHIKU_NM_KANJI_MOJI_SU,''FM09''),'||
					'TO_CHAR(OAZA_NM_KANJI_MOJI_SU,''FM09''),'||
					'TO_CHAR(AZA_NM_KANJI_MOJI_SU,''FM09''),'||
					'TEL,'||
					'NULL,'||
					'NULL,'||
					'SHI_KBN_CD,'||
					'NULL,'||
					'JUSHOFUMEI_CD,'||
					'KYUIN_FLG,'||
					'DEL_YOTEI_RIYU_CD,'||
					'KAIGYO_YOTEI_FLG,'||
					'NULL,'||
					'CASE WHEN KYUIN_FLG = ''1'' THEN SUBSTR(KYUIN_S_YM,1,4) WHEN KAIGYO_YOTEI_FLG = ''1'' THEN SUBSTR(KAIGYO_YOTEI_YM,1,4) END,'||
					'CASE WHEN KYUIN_FLG = ''1'' THEN SUBSTR(KYUIN_S_YM,5,2) WHEN KAIGYO_YOTEI_FLG = ''1'' THEN SUBSTR(KAIGYO_YOTEI_YM,5,2) END,'||
					'NULL,'||
					'SEISHIKI_SHI_NM30,'||
					'SHI_RN,'||
					'JUSHO_KANJI_RENKETSU,'||
					'NULL,'||
					'DAIHYO_NM_KANA,'||
					'DAIHYO_NM,'||
					'NULL,'||
					'CHOFUKU_AITSK_REC_ID,'||
					'CHOFUKU_AITSK_SHI_CD,'||
					'NULL,'||
					'SUBSTR(UPD_EIGY_YMD,1,4),'||
					'SUBSTR(UPD_EIGY_YMD,5,2),'||
					'SUBSTR(UPD_EIGY_YMD,7,2),'||
					'SUBSTR(iTensoYMD,1,4),'||
					'SUBSTR(iTensoYMD,5,2),'||
					'SUBSTR(iTensoYMD,7,2),'||
					'KEIEITAI_CD,'||
					'SEISHIKI_SHI_NM	,'||
					'SEISHIKI_SHI_NM_KANA,'||
					'NULL,'||
					'iOPE_CD,'||
					'iDATE,'||
					'iPGM_ID,'||
					'iOPE_CD,'||
					'iDATE,'||
					'iPGM_ID'||
	                'FROM TT_TIKY_SHI'||
	                'WHERE REC_ID = ''06'''||
	                'AND DEL_FLG IS NULL'||
	                'AND (SUBSTR(SHI_KBN_CD, 1, 1) = ''G'''||
	                'OR SUBSTR(SHI_KBN_CD, 1, 1) = ''Q'')';
			ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);


        	END IF; 
	END IF;
	COMMIT;

        -- �I�����O�o��
        ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'PL/SQL End',PGM_ID || '�̏������I�����܂����B',iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

	return 0;
    -- ��O����
	EXCEPTION
		-- ���̑��G���[
		WHEN OTHERS THEN
			W_ERR_INF_RCD.ERR_CD 		:= TO_CHAR(SQLCODE);
			W_ERR_INF_RCD.ERR_MSG 		:= SUBSTR(SQLERRM, 0, 500);
			W_ERR_INF_RCD.ERR_KEY_INF 	:= SUBSTR('iLayoutKind:' || iLayoutKind || ', iShimeKind:' || iShimeKind , 0,500);
			W_INDEX_N 			:= W_ERR_INF_TBL.COUNT + 1;
			W_ERR_INF_TBL.EXTEND;
			W_ERR_INF_TBL(W_INDEX_N) 	:= W_ERR_INF_RCD;

			OPEN oOUT_ERR_INF_CSR FOR
				SELECT * FROM TABLE(W_ERR_INF_TBL);

			ROLLBACK;
			-- �G���[���O�̓o�^
          		ULT_INSERT_LOG_TABLE('ERROR',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'ERROR_INFO',W_ERR_INF_RCD.ERR_MSG,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);
			return 1;
        END;
    END;
/
