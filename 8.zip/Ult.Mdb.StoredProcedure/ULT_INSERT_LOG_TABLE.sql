CREATE OR REPLACE PROCEDURE ULT_INSERT_LOG_TABLE(
	iLOG_LEVEL	IN	TL_STORED_SHORI.LOG_LEVEL%TYPE,
	iIP_ADDR	IN	TL_STORED_SHORI.IP%TYPE,
	iWINDOWS_LOGIN_USER	IN	TL_STORED_SHORI.WINDOWS_LOGIN_USER%TYPE,
	iOPE_CD		IN	TL_STORED_SHORI.OPE_CD%TYPE,
	iTITLE		IN	TL_STORED_SHORI.TITLE%TYPE,
	iMESSAGE	IN	CLOB,
	iTRK_OPE_CD	IN	TL_STORED_SHORI.TRK_OPE_CD%TYPE,
	iTRK_DATE	IN	TL_STORED_SHORI.TRK_DATE%TYPE,
	iTRK_PGM_ID	IN	TL_STORED_SHORI.TRK_PGM_ID%TYPE,
	iUPD_OPE_CD	IN	TL_STORED_SHORI.UPD_OPE_CD%TYPE,
	iUPD_DATE	IN	TL_STORED_SHORI.UPD_DATE%TYPE,
	iUPD_PGM_ID	IN	TL_STORED_SHORI.UPD_PGM_ID%TYPE
)AS
PRAGMA AUTONOMOUS_TRANSACTION;
	LenMessage NUMBER(38) ;
	LoopCounter NUMBER(38) ;
	StartIndex NUMBER(38);
	RestStr NUMBER(38);
	CutLength NUMBER(10) := 500;
	Title VARCHAR(100);
BEGIN
	StartIndex := 1;
	RestStr := 0;
	Title := iTITLE;
	---���b�Z�[�W��500�����𒴂����番�����ēo�^
	LenMessage := LENGTH(iMESSAGE);
	LoopCounter := Trunc( LenMessage / 500) + 1;

	FOR i IN 1..LoopCounter LOOP
	
		IF i = LoopCounter Then
			RestStr := LenMessage;
			IF LoopCounter > 1 then 
				Title := iTITLE || ' ' ||i;
			END IF;
		ELSE
			RestStr := CutLength;
				Title := iTITLE || ' ' ||i;
		End IF;
		INSERT INTO TL_STORED_SHORI(
			SEQ
			,LOG_LEVEL
			,SHORI_DATE
			,IP
			,WINDOWS_LOGIN_USER
			,OPE_CD
			,TITLE
			,MESSAGE
			,TRK_OPE_CD
			,TRK_DATE
			,TRK_PGM_ID
			,UPD_OPE_CD
			,UPD_DATE
			,UPD_PGM_ID)
		values(
			SEQ_STORED_SHORI_PK.NEXTVAL
			,iLOG_LEVEL
			,SYSDATE
			,iIP_ADDR
			,iWINDOWS_LOGIN_USER
			,iUPD_OPE_CD
			,Title
			,SUBSTR(iMESSAGE,StartIndex,RestStr)
			,iUPD_OPE_CD
			,iUPD_DATE
			,iUPD_PGM_ID
			,iUPD_OPE_CD
			,iUPD_DATE
			,iUPD_PGM_ID);
	
		StartIndex := StartIndex + CutLength;
		LenMessage := LenMessage -CutLength;
	END LOOP ;

COMMIT;
END ;
/
