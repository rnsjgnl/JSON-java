CREATE OR REPLACE PACKAGE NH010106B001_020
/* **********************************************************
 *  Copyright(c) 2011 beyond, INTEC Inc. All rights reserved.
 * **********************************************************/
AUTHID CURRENT_USER
IS
	/*** �J�[�\���^ ***************************************************************/
	-- �G���[���i�[�p�J�[�\���^
	TYPE ERR_INF_CSR		IS REF CURSOR;

  /*
  ************************************************************************
  *  �ǉ��A�C�e���P�e�[�u��(�R�[�h�\)�̍쐬
  *  CREATE_TSUIKAITEM1_ALL
  ************************************************************************
  */
  FUNCTION CREATE_TSUIKAITEM1_ALL(
  iShimeKind  IN  INTEGER,                    -- ���ߓ��敪
  iTensoYMD	IN	VARCHAR2,                     -- �]���N����
  iOPE_CD IN Varchar2,                      -- �I�y���[�^�R�[�h
  iPGM_ID IN Varchar2,                      -- �v���O����ID
  iDATE DATE,                               -- �V�X�e������
  iIP_ADDR  IN TL_STORED_SHORI.IP%TYPE,              -- ���s�[��IP�A�h���X (FW�Őݒ�)
  iWINDOWS_LOGIN_USER  IN TL_STORED_SHORI.WINDOWS_LOGIN_USER%TYPE, -- ���s�[��OS���[�U�[ (FW�Őݒ�)
  oROW_COUNT  OUT NUMBER,         -- �o�^����
  oOUT_ERR_INF_CSR   OUT ERR_INF_CSR    -- �G���[���J�[�\��
  ) RETURN NUMBER;

END;
/
CREATE OR REPLACE PACKAGE BODY NH010106B001_020
/* **********************************************************
 *  Copyright(c) 2011 beyond, INTEC Inc. All rights reserved.
 * **********************************************************/
IS
  /*
   ************************************************************************
   * Function ID  : CREATE_TSUIKAITEM1_ALL
   * Program Name : �ǉ��A�C�e���P�e�[�u��(�R�[�h�\)�̍쐬
   * Parameter    :  <I> iShimeKind    �F���ߓ��敪
   *                 <I> iTensoYMD    �F�]���N����
   *                 <I> iOPE_CD    �F�I�y���[�^�R�[�h
   *                 <I> iPGM_ID    �F�v���O����ID
   *                 <I> iDATE    �F�V�X�e������ 
   *                 <I> iIP_ADDR    �F���s�[��IP�A�h���X
   *                 <I> iWINDOWS_LOGIN_USER  �F���s�[��IP�A�h���X
   *                <O> oROW_COUNT        �F�X�V����
   *                <O> oOUT_ERR_INF_CSR  �F�G���[���J�[�\��
   * Return       �F�������ʁi0:����I���A1:�ُ�I���j
   ************************************************************************
   */
  FUNCTION CREATE_TSUIKAITEM1_ALL(
  iShimeKind  IN  INTEGER,                    -- ���ߓ��敪
  iTensoYMD	IN	VARCHAR2,                     -- �]���N����
  iOPE_CD IN Varchar2,                      -- �I�y���[�^�R�[�h
  iPGM_ID IN Varchar2,                      -- �v���O����ID
  iDATE DATE,                               -- �V�X�e������  
  iIP_ADDR  IN TL_STORED_SHORI.IP%TYPE,              -- ���s�[��IP�A�h���X (FW�Őݒ�)
  iWINDOWS_LOGIN_USER  IN TL_STORED_SHORI.WINDOWS_LOGIN_USER%TYPE, -- ���s�[��OS���[�U�[ (FW�Őݒ�)
  oROW_COUNT  OUT NUMBER,         -- �o�^����
  oOUT_ERR_INF_CSR   OUT ERR_INF_CSR    -- �G���[���J�[�\��
  )RETURN NUMBER IS

PRAGMA AUTONOMOUS_TRANSACTION;

  /************************************************************************/
  /*                              �G���[����                              */
  /************************************************************************/
  W_INDEX_N           NUMBER(10) := 0;
  W_ERR_INF_TBL         TYPE_ERR_INFO_TBL := TYPE_ERR_INFO_TBL();
  W_ERR_INF_RCD         TYPE_ERR_INFO_RCD := TYPE_ERR_INFO_RCD(NULL,NULL,NULL,NULL);
  vSchemaNm           TM_JOSU.HANYO_KOMOKU%TYPE := NULL; -- �X�L�[�}����
  PGM_ID        VARCHAR2(50) := 'NH010106B001_020.CREATE_TSUIKAITEM1_ALL';
  EXECUTE_SQL   VARCHAR2(32767) := NULL;
 
  BEGIN

	-- �J�n���O�o��
    ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'PL/SQL Start',PGM_ID || '�̏������J�n���܂��B',iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);
    
    -- �����D���ߋ敪��"1"(������)��
    IF iShimeKind = ULT_COMMON.SHIME_SBT_CD_HISHIME THEN

      -- �[�i�p�X�L�[�}�̎擾���s���B
      vSchemaNm := ULT_COMMON.GET_SCHEMA_NAME(ULT_COMMON.SYS_ENV_JOSU_DAI_CD, ULT_COMMON.NOHIN_SHEMA_JOSU_SHO_CD);

      --�ǉ��A�C�e���P�e�[�u��(�R�[�h�\)�̃f�[�^���N���A����
      EXECUTE_SQL := 'TRUNCATE TABLE ' || vSchemaNm || '.' || 'TD_PA_TSUIKATBL_Q';
      EXECUTE IMMEDIATE EXECUTE_SQL;
      ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);
      
      EXECUTE_SQL := 'TRUNCATE TABLE ' || vSchemaNm || '.' || 'TD_PA_TSUIKATBL_R';
      EXECUTE IMMEDIATE EXECUTE_SQL;
      ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);
      
      EXECUTE_SQL := 'TRUNCATE TABLE ' || vSchemaNm || '.' || 'TD_PA_TSUIKATBL_S';
      EXECUTE IMMEDIATE EXECUTE_SQL;
      ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);
      
      EXECUTE_SQL := 'TRUNCATE TABLE ' || vSchemaNm || '.' || 'TD_PA_TSUIKATBL_T';
      EXECUTE IMMEDIATE EXECUTE_SQL;
      ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);
      
      -- �b��_�S��_�ǉ��A�C�e��1�e�[�u��_���x��i��Ãe�[�u���ɓo�^����
      INSERT INTO TD_PA_TSUIKATBL_Q(
            REC_ID            ,
            KBN_Q             ,
            SENSHIN_CD        ,
            MEISYO_KANJI      ,
            FILLER            ,
            TENSO_Y           ,
            TENSO_M           ,
            TENSO_D           ,
            MENTE_Y           ,
            MENTE_M           ,
            MENTE_D           ,
            MOD_KBN           ,
            TRK_OPE_CD        ,
            TRK_DATE          ,
            TRK_PGM_ID        ,
            UPD_OPE_CD        ,
            UPD_DATE          ,               
            UPD_PGM_ID)  
        SELECT
            '11',       
            'Q',   
            TTS.SENSHIN_CD || TTS.SENSHIN_JOGAI_KBN,
            TTS.SENSHIN_NM,
            NULL,
            SUBSTR(iTensoYMD,1,4),
            SUBSTR(iTensoYMD,5,2),
            SUBSTR(iTensoYMD,7,2),
            SUBSTR(TTS.UPD_EIGY_YMD,1,4),
            SUBSTR(TTS.UPD_EIGY_YMD,5,2),
            SUBSTR(TTS.UPD_EIGY_YMD,7,2),  
            NULL,          
            iOPE_CD,
            iDATE,
            iPGM_ID,
            iOPE_CD,
            iDATE,
            iPGM_ID
       FROM TM_TIKY_SENSHIN TTS;
       -- 2012/11/12 �d�l�ύX�̑Ή�
	   -- WHERE TTS.HAISHI_FLG IS NULL;
	   -- 2012/11/12 �d�l�ύX�̑Ή�
	   
	  -- �b��_�S��_�ǉ��A�C�e��1�e�[�u��_���x��i��Ãe�[�u���̃��O��o�^����
	  EXECUTE_SQL:=' INSERT INTO TD_PA_TSUIKATBL_Q(                       ' ||
					'             REC_ID            ,                      ' ||
					'             KBN_Q             ,                      ' ||
					'             SENSHIN_CD        ,                      ' ||
					'             MEISYO_KANJI      ,                      ' ||
					'             FILLER            ,                      ' ||
					'             TENSO_Y           ,                      ' ||
					'             TENSO_M           ,                      ' ||
					'             TENSO_D           ,                      ' ||
					'             MENTE_Y           ,                      ' ||
					'             MENTE_M           ,                      ' ||
					'             MENTE_D           ,                      ' ||
					'             MOD_KBN           ,                      ' ||
					'             TRK_OPE_CD        ,                      ' ||
					'             TRK_DATE          ,                      ' ||
					'             TRK_PGM_ID        ,                      ' ||
					'             UPD_OPE_CD        ,                      ' ||
					'             UPD_DATE          ,                      ' ||
					'             UPD_PGM_ID)                              ' ||
					'         SELECT                                       ' ||
					'             ''11'',                                    ' ||
					'             ''Q'',                                     ' ||
					'             TTS.SENSHIN_CD || TTS.SENSHIN_JOGAI_KBN, ' ||
					'             TTS.SENSHIN_NM,                          ' ||
					'             NULL,                                    ' ||
					'             SUBSTR(iTensoYMD,1,4),                   ' ||
					'             SUBSTR(iTensoYMD,5,2),                   ' ||
					'             SUBSTR(iTensoYMD,7,2),                   ' ||
					'             SUBSTR(TTS.UPD_EIGY_YMD,1,4),            ' ||
					'             SUBSTR(TTS.UPD_EIGY_YMD,5,2),            ' ||
					'             SUBSTR(TTS.UPD_EIGY_YMD,7,2),            ' ||
					'             NULL,                                    ' ||
								iOPE_CD   || ','           ||
					            iDATE     || ','           ||
					            iPGM_ID   || ','           ||
					            iOPE_CD   || ','           ||
					            iDATE     || ','           ||
					            iPGM_ID                    ||
					'        FROM TM_TIKY_SENSHIN TTS                      ' ;
					-- 2012/11/12 �d�l�ύX�̑Ή�
					-- ||	' 	   WHERE TTS.HAISHI_FLG IS NULL                    ' ;
					-- 2012/11/12 �d�l�ύX�̑Ή�
					
	  ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);
     
      -- �b��_�S��_�ǉ��A�C�e��1�e�[�u��_��[��Ë@��e�[�u���ɓo�^����
      INSERT INTO TD_PA_TSUIKATBL_R(
           REC_ID            ,
           KBN_R             ,
           SENSHIN_CD        ,
           MEISYO_KANJI      ,
           FILLER            ,
           TENSO_Y           ,
           TENSO_M           ,
           TENSO_D           ,
           MENTE_Y           ,
           MENTE_M           ,
           MENTE_D           ,
           MOD_KBN           ,
           TRK_OPE_CD        ,
           TRK_DATE          ,
           TRK_PGM_ID        ,
           UPD_OPE_CD        ,
           UPD_DATE          ,               
           UPD_PGM_ID)  
        SELECT
           '11',       
           'R',   
           '00' || TTS.SNTNIRY_CD,
           TTS.SNTNIRY_NM,
           NULL,
		   SUBSTR(iTensoYMD,1,4),
		   SUBSTR(iTensoYMD,5,2),
		   SUBSTR(iTensoYMD,7,2),
		   SUBSTR(TTS.UPD_EIGY_YMD,1,4),
		   SUBSTR(TTS.UPD_EIGY_YMD,5,2),
		   SUBSTR(TTS.UPD_EIGY_YMD,7,2), 
           NULL,          
           iOPE_CD,
           iDATE,
           iPGM_ID,
           iOPE_CD,
           iDATE,
           iPGM_ID
        FROM TM_TIKY_SNTNIRY TTS;
        -- 2012/11/12 �d�l�ύX�̑Ή�
        -- WHERE TTS.HAISHI_FLG IS NULL;
        -- 2012/11/12 �d�l�ύX�̑Ή�  
        
      -- �b��_�S��_�ǉ��A�C�e��1�e�[�u��_��[��Ë@��e�[�u���̃��O��o�^����
      EXECUTE_SQL:=' INSERT INTO TD_PA_TSUIKATBL_R(         ' ||
					'            REC_ID            ,         ' ||
					'            KBN_R             ,         ' ||
					'            SENSHIN_CD        ,         ' ||
					'            MEISYO_KANJI      ,         ' ||
					'            FILLER            ,         ' ||
					'            TENSO_Y           ,         ' ||
					'            TENSO_M           ,         ' ||
					'            TENSO_D           ,         ' ||
					'            MENTE_Y           ,         ' ||
					'            MENTE_M           ,         ' ||
					'            MENTE_D           ,         ' ||
					'            MOD_KBN           ,         ' ||
					'            TRK_OPE_CD        ,         ' ||
					'            TRK_DATE          ,         ' ||
					'            TRK_PGM_ID        ,         ' ||
					'            UPD_OPE_CD        ,         ' ||
					'            UPD_DATE          ,         ' ||
					'            UPD_PGM_ID)                 ' ||
					'         SELECT                         ' ||
					'            ''11'',                       ' ||
					'            ''R'',                        ' ||
					'            ''00'' || TTS.SNTNIRY_CD,     ' ||
					'            TTS.SNTNIRY_NM,             ' ||
					'            NULL,                       ' ||
					' 		   SUBSTR(iTensoYMD,1,4),        ' ||
					' 		   SUBSTR(iTensoYMD,5,2),        ' ||
					' 		   SUBSTR(iTensoYMD,7,2),        ' ||
					' 		   SUBSTR(TTS.UPD_EIGY_YMD,1,4), ' ||
					' 		   SUBSTR(TTS.UPD_EIGY_YMD,5,2), ' ||
					' 		   SUBSTR(TTS.UPD_EIGY_YMD,7,2), ' ||
					'            NULL,                       ' ||
								iOPE_CD   || ','           ||
					            iDATE     || ','           ||
					            iPGM_ID   || ','           ||
					            iOPE_CD   || ','           ||
					            iDATE     || ','           ||
					            iPGM_ID                    ||
					'         FROM TM_TIKY_SNTNIRY TTS       ' ;
					-- 2012/11/12 �d�l�ύX�̑Ή�
					-- || '         WHERE TTS.HAISHI_FLG IS NULL   ' ; 
					-- 2012/11/12 �d�l�ύX�̑Ή�
					           
      ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);
      
      -- �b��_�S��_�ǉ��A�C�e��1�e�[�u��_�Ō��ʃe�[�u���ɓo�^����
      INSERT INTO TD_PA_TSUIKATBL_S(
           REC_ID            ,
           KBN_S             ,
           KNG_SBT_BNRI_CD   ,
           MEISYO_KANJI      ,
           FILLER            ,
           TENSO_Y           ,
           TENSO_M           ,
           TENSO_D           ,
           MENTE_Y           ,
           MENTE_M           ,
           MENTE_D           ,
           MOD_KBN           ,
           TRK_OPE_CD        ,
           TRK_DATE          ,
           TRK_PGM_ID        ,
           UPD_OPE_CD        ,
           UPD_DATE          ,               
           UPD_PGM_ID)  
        SELECT
           '11',       
           'S',   
           TTKS.KNG_SBT_CD,
           TTKS.KNG_SBT_NM,
           NULL,
           SUBSTR(iTensoYMD,1,4),
		   SUBSTR(iTensoYMD,5,2),
		   SUBSTR(iTensoYMD,7,2),
		   SUBSTR(TTKS.UPD_EIGY_YMD,1,4),
		   SUBSTR(TTKS.UPD_EIGY_YMD,5,2),
		   SUBSTR(TTKS.UPD_EIGY_YMD,7,2),  
           NULL,          
           iOPE_CD,
           iDATE,
           iPGM_ID,
           iOPE_CD,
           iDATE,
           iPGM_ID
        FROM TM_TIKY_KNG_SBT TTKS;
        -- 2012/11/12 �d�l�ύX�̑Ή�
      	-- WHERE TTKS.HAISHI_FLG IS NULL; 
      	-- 2012/11/12 �d�l�ύX�̑Ή�
      	
      -- �b��_�S��_�ǉ��A�C�e��1�e�[�u��_�Ō��ʃe�[�u���̃��O��o�^���� 
      EXECUTE_SQL:=' INSERT INTO TD_PA_TSUIKATBL_S(            ' ||
					'            REC_ID            ,            ' ||
					'            KBN_S             ,            ' ||
					'            KNG_SBT_BNRI_CD   ,            ' ||
					'            MEISYO_KANJI      ,            ' ||
					'            FILLER            ,            ' ||
					'            TENSO_Y           ,            ' ||
					'            TENSO_M           ,            ' ||
					'            TENSO_D           ,            ' ||
					'            MENTE_Y           ,            ' ||
					'            MENTE_M           ,            ' ||
					'            MENTE_D           ,            ' ||
					'            MOD_KBN           ,            ' ||
					'            TRK_OPE_CD        ,            ' ||
					'            TRK_DATE          ,            ' ||
					'            TRK_PGM_ID        ,            ' ||
					'            UPD_OPE_CD        ,            ' ||
					'            UPD_DATE          ,            ' ||
					'            UPD_PGM_ID)                    ' ||
					'         SELECT                            ' ||
					'            ''11'',                          ' ||
					'            ''S'',                           ' ||
					'            TTKS.KNG_SBT_CD,               ' ||
					'            TTKS.KNG_SBT_NM,               ' ||
					'            NULL,                          ' ||
					'            SUBSTR(iTensoYMD,1,4),         ' ||
					' 		   SUBSTR(iTensoYMD,5,2),           ' ||
					' 		   SUBSTR(iTensoYMD,7,2),           ' ||
					' 		   SUBSTR(TTKS.UPD_EIGY_YMD,1,4),   ' ||
					' 		   SUBSTR(TTKS.UPD_EIGY_YMD,5,2),   ' ||
					' 		   SUBSTR(TTKS.UPD_EIGY_YMD,7,2),   ' ||
					'            NULL,                          ' ||
								iOPE_CD   || ','           ||
					            iDATE     || ','           ||
					            iPGM_ID   || ','           ||
					            iOPE_CD   || ','           ||
					            iDATE     || ','           ||
					            iPGM_ID                    ||
					'         FROM TM_TIKY_KNG_SBT TTKS         '; 
					
					-- 2012/11/12 �d�l�ύX�̑Ή�
					-- || '       	WHERE TTKS.HAISHI_FLG IS NULL   ' ;
					-- 2012/11/12 �d�l�ύX�̑Ή�
					
      ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

      -- �b��_�S��_�ǉ��A�C�e��1�e�[�u��_��Ë@�\�]���e�[�u���ɓo�^����
      INSERT INTO TD_PA_TSUIKATBL_T(
           REC_ID            ,
           KBN_T             ,
           IRYHYOKA_CD       ,
           MEISYO_KANJI      ,
           FILLER            ,
           TENSO_Y           ,
           TENSO_M           ,
           TENSO_D           ,
           MENTE_Y           ,
           MENTE_M           ,
           MENTE_D           ,
           MOD_KBN           ,
           TRK_OPE_CD        ,
           TRK_DATE          ,
           TRK_PGM_ID        ,
           UPD_OPE_CD        ,
           UPD_DATE          ,               
           UPD_PGM_ID)  
        SELECT
           '11',       
           'T',   
           '00' || TTI.IRYHYOKA_CD,
           TTI.IRYHYOKA_NM,
           NULL,
           SUBSTR(iTensoYMD,1,4),
		   SUBSTR(iTensoYMD,5,2),
		   SUBSTR(iTensoYMD,7,2),
		   SUBSTR(TTI.UPD_EIGY_YMD,1,4),
		   SUBSTR(TTI.UPD_EIGY_YMD,5,2),
		   SUBSTR(TTI.UPD_EIGY_YMD,7,2),  
           NULL,          
           iOPE_CD,
           iDATE,
           iPGM_ID,
           iOPE_CD,
           iDATE,
           iPGM_ID
       FROM TM_TIKY_IRYHYOKA TTI;
       -- 2012/11/12 �d�l�ύX�̑Ή�
       -- WHERE TTI.HAISHI_FLG IS NULL;
       -- 2012/11/12 �d�l�ύX�̑Ή�
       
	   -- �b��_�S��_�ǉ��A�C�e��1�e�[�u��_��Ë@�\�]���e�[�u���̃��O��o�^����
	   EXECUTE_SQL:='  INSERT INTO TD_PA_TSUIKATBL_T(        ' ||
					'             REC_ID            ,        ' ||
					'             KBN_T             ,        ' ||
					'             IRYHYOKA_CD       ,        ' ||
					'             MEISYO_KANJI      ,        ' ||
					'             FILLER            ,        ' ||
					'             TENSO_Y           ,        ' ||
					'             TENSO_M           ,        ' ||
					'             TENSO_D           ,        ' ||
					'             MENTE_Y           ,        ' ||
					'             MENTE_M           ,        ' ||
					'             MENTE_D           ,        ' ||
					'             MOD_KBN           ,        ' ||
					'             TRK_OPE_CD        ,        ' ||
					'             TRK_DATE          ,        ' ||
					'             TRK_PGM_ID        ,        ' ||
					'             UPD_OPE_CD        ,        ' ||
					'             UPD_DATE          ,        ' ||       
					'             UPD_PGM_ID)                ' ||
					'          SELECT                        ' ||
					'             ''11'',                      ' ||
					'             ''T'',                       ' ||
					'             ''00'' || TTI.IRYHYOKA_CD,   ' ||
					'             TTI.IRYHYOKA_NM,           ' ||
					'             NULL,                      ' ||
					'             SUBSTR(iTensoYMD,1,4),     ' ||
					'  		   SUBSTR(iTensoYMD,5,2),        ' ||
					'  		   SUBSTR(iTensoYMD,7,2),        ' ||
					'  		   SUBSTR(TTI.UPD_EIGY_YMD,1,4), ' ||
					'  		   SUBSTR(TTI.UPD_EIGY_YMD,5,2), ' ||
					'  		   SUBSTR(TTI.UPD_EIGY_YMD,7,2), ' || 
					'             NULL,                      ' ||
								iOPE_CD   || ','           ||
					            iDATE     || ','           ||
					            iPGM_ID   || ','           ||
					            iOPE_CD   || ','           ||
					            iDATE     || ','           ||
					            iPGM_ID                    ||
					'         FROM TM_TIKY_IRYHYOKA TTI      ' ;
					-- 2012/11/12 �d�l�ύX�̑Ή�
					-- || '         WHERE TTI.HAISHI_FLG IS NULL   ' ;
					-- 2012/11/12 �d�l�ύX�̑Ή�
	   ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);
      
    END IF;

   COMMIT;
   
   -- �I�����O�o��
   ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'PL/SQL End',PGM_ID || '�̏������I�����܂����B',iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

   oROW_COUNT := -1; 

  return 0;

  -- ��O����
  EXCEPTION
    -- ���̑��G���[
    WHEN OTHERS THEN
      W_ERR_INF_RCD.ERR_CD     := TO_CHAR(SQLCODE);
      W_ERR_INF_RCD.ERR_MSG     := SUBSTR(SQLERRM, 0, 500);
      W_ERR_INF_RCD.ERR_KEY_INF   := SUBSTR('iShimeKind:' || iShimeKind , 0,500);
      W_INDEX_N           := W_ERR_INF_TBL.COUNT + 1;
      W_ERR_INF_TBL.EXTEND;
      W_ERR_INF_TBL(W_INDEX_N)   := W_ERR_INF_RCD;

      OPEN oOUT_ERR_INF_CSR FOR
        SELECT * FROM TABLE(W_ERR_INF_TBL);

        ROLLBACK;
        
      --�G���[���O�̓o�^
      ULT_INSERT_LOG_TABLE('ERROR',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'ERROR_INFO',W_ERR_INF_RCD.ERR_MSG,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

  return 1;
END;

END;
/
