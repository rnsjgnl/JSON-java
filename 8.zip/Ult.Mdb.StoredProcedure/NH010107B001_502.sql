CREATE OR REPLACE PACKAGE NH010107B001_502
/* **********************************************************
 *  Copyright(c) 2011 beyond, INTEC Inc. All rights reserved.
 * **********************************************************/
AUTHID CURRENT_USER
IS
	/*** �J�[�\���^ ***************************************************************/
	-- �G���[���i�[�p�J�[�\���^
	TYPE ERR_INF_CSR		IS REF CURSOR;
  --�ҏW��`�z��(��W��)�̌^
  TYPE EditInfoArray IS TABLE OF NUMBER;
   --�ҏW��`�z��(�W��)�̌^
  TYPE EditInfoArrayArray is table of EditInfoArray; 
  /*
	************************************************************************
	*  �ҏW���̔z��ɂ���āA����f�[�^�ƑO��f�[�^�������ꍇ�A
  *  ����f�[�^�̔z��Ɏw�肳�ꂽ�l��ݒ肷��
	*  ChangeToNull
	************************************************************************
	*/
  PROCEDURE ChangeToNull(
     array1 IN OUT ULT_COMMON.VarcharArray,     --����f�[�^
     array2 IN ULT_COMMON.VarcharArray,         --�O��f�[�^
     editArray IN EditInfoArray             --�ҏW���̔z�� 
  );
  /*
	************************************************************************
	*  �ҏW���̔z��ɂ���āA����f�[�^�ƑO��f�[�^�������ꍇ�A
  *  ����f�[�^�̔z��Ɏw�肳�ꂽ�l��ݒ肷��
	*  ChangeToDefault
	************************************************************************
	*/
  PROCEDURE ChangeToDefault(
     array1 IN OUT ULT_COMMON.VarcharArray,     --����f�[�^
     array2 IN ULT_COMMON.VarcharArray,         --�O��f�[�^
     editArray IN EditInfoArray             --�ҏW���̔z��
  );
 /*
	************************************************************************
	*  �ҏW����2�����z��ɂ���āA����f�[�^�ƑO��f�[�^�������ꍇ�A
  *  ����f�[�^�̔z��ɏ����l��ݒ肷��
	*  ChangeToNullForArray
	************************************************************************
	*/
  PROCEDURE ChangeToNullForArray(
     array1 IN OUT ULT_COMMON.VarcharArray,     --����f�[�^
     array2 IN ULT_COMMON.VarcharArray,         --�O��f�[�^
     editArray IN EditInfoArrayArray        --�ҏW����2�����z��
  );
 /*
	************************************************************************
	*  �ҏW����2�����z��ɂ���āA����f�[�^�ƑO��f�[�^�������ꍇ�A
  *  ����f�[�^�̔z��ɏ����l��ݒ肷��
	*  ChangeToDefaultForArray
	************************************************************************
	*/
  PROCEDURE ChangeToDefaultForArray(
     array1 IN OUT ULT_COMMON.VarcharArray,     --����f�[�^
     array2 IN ULT_COMMON.VarcharArray,         --�O��f�[�^
     editArray IN EditInfoArrayArray        --�ҏW����2�����z��
  );
	/*
	************************************************************************
	*  DCF��t�Ζ���f��DB�f�[�^�̍쐬
	*  CREATE_DCF_ISHI_KM_SABUN
	************************************************************************
	*/
	FUNCTION CREATE_DCF_ISHI_KM_SABUN(
	iLayoutKind	IN	VARCHAR2,										-- ���C�A�E�g�敪
	iShimeKind	IN	VARCHAR2,										-- ���ߓ��敪
  iShimeFrom	IN	VARCHAR2,										-- ���ߔ͈́iFrom�j
  iShimeTo	IN	VARCHAR2,										-- ���ߔ͈́iTo�j
  iTensoYMD	IN	VARCHAR2,										-- �]���N���� 
  iM2Flg IN	VARCHAR2,										    -- ���Q���߃t���O
	iIP_ADDR	IN TL_STORED_SHORI.IP%TYPE,							-- ���s�[��IP�A�h���X (FW�Őݒ�)
	iWINDOWS_LOGIN_USER	IN TL_STORED_SHORI.WINDOWS_LOGIN_USER%TYPE, -- ���s�[��OS���[�U�[ (FW�Őݒ�)
	oROW_COUNT	OUT NUMBER,         -- �o�^����
	oOUT_ERR_INF_CSR 	OUT ERR_INF_CSR,    -- �G���[���J�[�\��
  iOPE_CD IN Varchar2,                      -- �I�y���[�^�R�[�h
  iPGM_ID IN Varchar2,                      -- �v���O����ID
  iDATE DATE                              -- �V�X�e������
	) RETURN NUMBER;
  
 
END;
/
CREATE OR REPLACE PACKAGE BODY NH010107B001_502
/* **********************************************************
 *  Copyright(c) 2011 beyond, INTEC Inc. All rights reserved.
 * **********************************************************/
IS
/*
   ************************************************************************
   * Function ID  : ChangeToNull
   * Program Name : �ҏW���̔z��ɂ���āA����f�[�^�ƑO��f�[�^�������ꍇ�A
   *                ����f�[�^�̔z���NULL��ݒ肷��
   * Parameter    :  <IO> array1    �F����f�[�^
   *                 <I> array2    �F�O��f�[�^
   *                 <I> editArray    �F�ҏW���
	 ************************************************************************
	 */
  PROCEDURE ChangeToNull(
     array1 IN OUT ULT_COMMON.VarcharArray,     --����f�[�^
     array2 IN ULT_COMMON.VarcharArray,         --�O��f�[�^
     editArray IN EditInfoArray             --�ҏW���̔z��     
  ) IS
  BEGIN
    FOR i in 1..editArray.COUNT LOOP
      IF array1(editArray(i)) = array2(editArray(i)) THEN
        array1(editArray(i)) := NULL;
      END IF;        
    END LOOP;    
  END;
 /*
   ************************************************************************
   * Function ID  : ChangeToDefault
   * Program Name : �ҏW���̔z��ɂ���āA����f�[�^�ƑO��f�[�^�������ꍇ�A
   *                ����f�[�^�̔z��ɏ����l��ݒ肷��
   * Parameter    :  <IO> array1    �F����f�[�^
   *                 <I> array2    �F�O��f�[�^
   *                 <I> editArray    �F�ҏW���̔z��
	 ************************************************************************
	 */
  PROCEDURE ChangeToDefault(
     array1 IN OUT ULT_COMMON.VarcharArray,     --����f�[�^
     array2 IN ULT_COMMON.VarcharArray,         --�O��f�[�^
     editArray IN EditInfoArray             --�ҏW���     
  ) IS
  BEGIN
    FOR i in 1..editArray.COUNT LOOP
      IF array1(editArray(i)) = array2(editArray(i)) THEN
        array1(editArray(i)) := NULL;
      ELSIF array1(editArray(i)) IS NULL AND array2(editArray(i)) IS NOT NULL THEN
        array1(editArray(i)) := ULT_COMMON.INSERT_HALF_DEFAULT;
      END IF;        
    END LOOP;    
  END;  
/*
   ************************************************************************
   * Function ID  : ChangeToNullForArray
   * Program Name : �ҏW���̂Q�����z��ɂ���āA����f�[�^�ƑO��f�[�^�������ꍇ�A
   *                ����f�[�^�̔z���NULL��ݒ肷��
   * Parameter    :  <I> array1    �F����f�[�^
   *                 <I> array2    �F�O��f�[�^
   *                 <I> editArray    �F�ҏW���
	 ************************************************************************
	 */
  PROCEDURE ChangeToNullForArray(
     array1 IN OUT ULT_COMMON.VarcharArray,     --����f�[�^
     array2 IN ULT_COMMON.VarcharArray,         --�O��f�[�^
     editArray IN EditInfoArrayArray             --�ҏW���
  ) IS
  ret int:=0;
  BEGIN
    FOR i in 1..editArray.COUNT LOOP
      ret := 0;
      FOR j IN 1..editArray(i).COUNT LOOP
        IF NVL(array1(editArray(i)(j)),0) != NVL(array2(editArray(i)(j)),0) THEN
          ret := 1;
          EXIT;
        END IF;        
      END LOOP;
      IF ret = 0 THEN
        FOR j IN 1..editArray(i).COUNT LOOP
           array1(editArray(i)(j)):=NULL;
        END LOOP;
      END IF;      
    END LOOP;    
  END; 
  /*
   ************************************************************************
   * Function ID  : ChangeToDefaultForArray
   * Program Name : �ҏW���̂Q�����z��ɂ���āA����f�[�^�ƑO��f�[�^�������ꍇ�A
   *                ����f�[�^�̔z���NULL��ݒ肷��
   * Parameter    :  <I> array1    �F����f�[�^
   *                 <I> array2    �F�O��f�[�^
   *                 <I> editArray    �F�ҏW���
	 ************************************************************************
	 */
  PROCEDURE ChangeToDefaultForArray(
     array1 IN OUT ULT_COMMON.VarcharArray,     --����f�[�^
     array2 IN ULT_COMMON.VarcharArray,         --�O��f�[�^
     editArray IN EditInfoArrayArray             --�ҏW���
  ) IS
  ret int:=0;
  BEGIN
    FOR i in 1..editArray.COUNT LOOP
      ret := 0;
      FOR j IN 1..editArray(i).COUNT LOOP
        IF NVL(array1(editArray(i)(j)),0) != NVL(array2(editArray(i)(j)),0) THEN
          ret := 1;
          EXIT;
        END IF;        
      END LOOP;
      IF ret = 0 THEN
        FOR j IN 1..editArray(i).COUNT LOOP
           array1(editArray(i)(j)):=NULL;
        END LOOP;
      ELSE
        FOR j IN 1..editArray(i).COUNT LOOP
          IF array1(editArray(i)(j)) IS NULL AND array2(editArray(i)(j)) IS NOT NULL THEN
            ret := 2;
          END IF;
        END LOOP;
        IF ret = 2 THEN
          array1(editArray(i)(1)):=ULT_COMMON.INSERT_HALF_DEFAULT;
        END IF;
      END IF;      
    END LOOP;    
  END;  
	/*
	 ************************************************************************
	 * Function ID  : CREATE_DCF_ISHI_KM_SABUN
	 * Program Name : DCF��t�Ζ���Ζ���f��DB�f�[�^�̍쐬
	 * Parameter    :  <I> iLayoutKind		�F���C�A�E�g�敪
	 *				         <I> iShimeKind		�F���ߓ��敪
   *				         <I> iShimeFrom		�F���ߔ͈�(From)
   *				         <I> iShimeTo		�F���ߔ͈�(To)
   *				         <I> iTensoYMD		�F�]���N����
   *				         <I> iM2Flg		  �F���Q���߃t���O
   *		             <I> iIP_ADDR		�F���s�[��IP�A�h���X
	 *		             <I> iWINDOWS_LOGIN_USER  �F���s�[��IP�A�h���X
	 *                <O> oROW_COUNT		    �F�X�V����
	 *                <O> oOUT_ERR_INF_CSR	�F�G���[���J�[�\��
   *				         <I> iOPE_CD		�F�I�y���[�^�R�[�h
   *				         <I> iPGM_ID		�F�v���O����ID
   *				         <I> iDATE		�F�V�X�e������    
	 * Return       �F��������(0:����I���A1:�ُ�I��)
	 ************************************************************************
	 */
	FUNCTION CREATE_DCF_ISHI_KM_SABUN(
	iLayoutKind	IN	VARCHAR2,										-- ���C�A�E�g�敪
	iShimeKind	IN	VARCHAR2,										-- ���ߓ��敪
  iShimeFrom	IN	VARCHAR2,								 -- ���ߔ͈�(From)
  iShimeTo	IN	VARCHAR2,										-- ���ߔ͈�(To)
  iTensoYMD	IN	VARCHAR2,										-- �]���N���� 
  iM2Flg IN	VARCHAR2,										    -- ���Q���߃t���O
	iIP_ADDR	IN TL_STORED_SHORI.IP%TYPE,							-- ���s�[��IP�A�h���X (FW�Őݒ�)
	iWINDOWS_LOGIN_USER	IN TL_STORED_SHORI.WINDOWS_LOGIN_USER%TYPE, -- ���s�[��OS���[�U�[ (FW�Őݒ�)
	oROW_COUNT	OUT NUMBER,         -- �o�^����
	oOUT_ERR_INF_CSR 	OUT ERR_INF_CSR,    -- �G���[���J�[�\��
  iOPE_CD IN Varchar2,                      -- �I�y���[�^�R�[�h
  iPGM_ID IN Varchar2,                      -- �v���O����ID
  iDATE DATE                            -- �V�X�e������  
	)RETURN NUMBER IS
  
  PRAGMA AUTONOMOUS_TRANSACTION;
	/************************************************************************/
	/*                              �G���[����                              */
	/************************************************************************/
	W_INDEX_N 					NUMBER(10) := 0;
	W_ERR_INF_TBL 				TYPE_ERR_INFO_TBL := TYPE_ERR_INFO_TBL();
	W_ERR_INF_RCD 				TYPE_ERR_INFO_RCD := TYPE_ERR_INFO_RCD(NULL,NULL,NULL,NULL);
  
 
  vTempModKbn VARCHAR2(1);  --�C���敪(�ꎞ�p)
  vMODKBN VARCHAR2(1);  --�C���敪  
  vTAISHOKU_FLG VARCHAR2(1);  --�ސE�ٓ��t���O
  vSelectSQL VARCHAR2(32767);     --SQL��Select��
  vFromSQL VARCHAR2(32767);       --SQL��From��
  vWhereSQL VARCHAR2(32767);      --SQL��Where��
  vTABLE1 VARCHAR2(50);           --�e�[�u����1
  vTABLE2 VARCHAR2(50);           --�e�[�u����2
  --vTABLE3 VARCHAR2(50);           --�e�[�u����3
  vLAYOUT_KBN VARCHAR(3):= '502';  --���C�A�E�g�敪 
  vNowData ULT_COMMON.VarcharArray;    --����f�[�^�̔z��
  vLastData ULT_COMMON.VarcharArray;    --�O��f�[�^�̔z��
  vLen int;   --���R�[�h�h�c�ƌl�R�[�h�̒���
  vSchemaNm     TM_JOSU.HANYO_KOMOKU%TYPE := NULL; -- �X�L�[�}����
	PGM_ID        VARCHAR2(50) := 'NH010107B001_502.CREATE_DCF_ISHI_KM_SABUN';
	EXECUTE_SQL   VARCHAR2(32767) := NULL;  
  
  -- ��r�p�f�[�^�̃J�[�\���^
	TYPE compareCSR		IS REF CURSOR;
  cur compareCSR;
  --�V���C�A�E�g��r�p�f�[�^�̃��R�[�h�^   
  TYPE tRECORD IS RECORD (
    FIELD1 VARCHAR(32767),           --��r����1
    FIELD2 VARCHAR(32767),           --��r����2
    SZKBUKA_CD  VARCHAR(4),        --���񏊑����ȃR�[�h
    SZKBUKA_NM_KANA1  VARCHAR(60),        --���񏊑����Ȗ��J�i
    SZKBUKA_NM1  VARCHAR(100),        --���񏊑����Ȗ�
    SZKBUKA_NM_KANA2  VARCHAR(60),        --�O�񏊑����Ȗ��J�i    
    SZKBUKA_NM2  VARCHAR(100),        --�O�񏊑����Ȗ�
    UPD_EIGY_YMD VARCHAR(8),         --�X�V�����c�ƔN����     
    KJN_CD  TT_TIKY_KJN.KJN_CD%TYPE,   --�l�e�[�u���ύX���f

	---- 2012/12/06 START NH00021�Ή�----
    KINMUSAKI_REC_ID VARCHAR2(2), -- �Ζ���REC_ID
    ZEN_KINMUSAKI_REC_ID VARCHAR2(2), -- �Ζ���REC_ID
	---- 2012/12/06 END NH00021�Ή�----
    
	-- 2012/11/06 CP000193�̑Ή�
    TAISHOKU_FLG TT_TIKY_KJN_KINMUSAKI.TAISHOKU_FLG%TYPE,  -- �ސE�t���O
    ZEN_TAISHOKU_FLG TT_TIKY_KJN_KINMUSAKI.TAISHOKU_FLG%TYPE -- �ސE�t���O
    -- 2012/11/06 CP000193�̑Ή�
  );
  
  vRECORD tRECORD;--��r�p�f�[�^
  tempRecord tRECORD;--�ꎞ���R�[�h
  
  --�}�̗p��r�p�f�[�^�̃��R�[�h�̔z��̌^     
  TYPE t_TABLE IS table of tRECORD;
  tempTABLE t_TABLE:=t_TABLE();
  
  editInfo2 EditInfoArray;   --�ҏW��`�z��(��W���A�����l����)
  editInfoArray1 EditInfoArrayArray;   --�ҏW��`�z��(�W���A�����l�Ȃ�)
  vINSERT_TBL VARCHAR2(100):= '';	-- INSERT�Ώۃe�[�u����ҏW����
  vINSERT_SQL VARCHAR2(32767):= '';	-- INSERT����ҏW����
  
  
  BEGIN
    -- �J�n���O�o��
    ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'PL/SQL Start',PGM_ID || '�̏������J�n���܂��B',iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);
    -- �[�i�p�X�L�[�}�̎擾���s���B
		vSchemaNm := ULT_COMMON.GET_SCHEMA_NAME(ULT_COMMON.SYS_ENV_JOSU_DAI_CD, ULT_COMMON.NOHIN_SHEMA_JOSU_SHO_CD);
  
    oROW_COUNT:=0;  
    vSelectSQL := 
        'SELECT	
          A.REC_ID||'''||ULT_COMMON.DELIMITER||'''||
          A.KJN_CD||'''||ULT_COMMON.DELIMITER||'''||
          B.KINMUSAKI_REC_ID||'''||ULT_COMMON.DELIMITER||'''||
          B.KINMUSAKI_SHI_CD||'''||ULT_COMMON.DELIMITER||'''||
          B.YAKUSHOKU_CD||'''||ULT_COMMON.DELIMITER||'''||
          B.SHOKUI_CD||'''||ULT_COMMON.DELIMITER||'''||
          B.SZKBUKA_CD||'''||ULT_COMMON.DELIMITER||'''||
          B.KINMUSAKI_DM_FUKA_FLG||'''||ULT_COMMON.DELIMITER||'''||
          B.TAISHOKU_FLG
          AS FIELD1,
          D.REC_ID||'''||ULT_COMMON.DELIMITER||'''||
          D.KJN_CD||'''||ULT_COMMON.DELIMITER||'''||
          E.KINMUSAKI_REC_ID||'''||ULT_COMMON.DELIMITER||'''||
          E.KINMUSAKI_SHI_CD||'''||ULT_COMMON.DELIMITER||'''||
          E.YAKUSHOKU_CD||'''||ULT_COMMON.DELIMITER||'''||
          E.SHOKUI_CD||'''||ULT_COMMON.DELIMITER||'''||
          E.SZKBUKA_CD||'''||ULT_COMMON.DELIMITER||'''||
          E.KINMUSAKI_DM_FUKA_FLG||'''||ULT_COMMON.DELIMITER||'''||
          E.TAISHOKU_FLG
          AS FIELD2,          
          B.SZKBUKA_CD AS SZKBUKA_CD,
          DECODE(B.SZKBUKA_CD, ''9999'', B.NYURYOKU_SZKBUKA_NM_KANA, NULL) AS SZKBUKA_NM_KANA1,
          DECODE(B.SZKBUKA_CD, ''9999'', B.NYURYOKU_SZKBUKA_NM, NULL) AS SZKBUKA_NM1,
          DECODE(E.SZKBUKA_CD, ''9999'', E.NYURYOKU_SZKBUKA_NM_KANA, NULL) AS SZKBUKA_NM_KANA2,
          DECODE(E.SZKBUKA_CD, ''9999'', E.NYURYOKU_SZKBUKA_NM, NULL) AS SZKBUKA_NM2,';
           
          
        --editInfo1:=EditInfoArray(6,7,8,13,14,48,51);  --��W���A�����l�Ȃ�
        editInfo2:=EditInfoArray(5,6,8);  --��W���A�����l����
        editInfoArray1:=EditInfoArrayArray(  --�W���A�����l�Ȃ�
                          EditInfoArray(7,10,11)
                          );
        
      
      -- ���ߓ��敪��"1"(������) �܂��́A"2"(�T����) ���� �����D���C�A�E�g�敪��"1"(�V���C�A�E�g) �̏ꍇ�A
	    IF (iShimeKind = ULT_COMMON.SHIME_SBT_CD_HISHIME OR iShimeKind = ULT_COMMON.SHIME_SBT_CD_SHUSHIME) AND
        iLayoutKind = ULT_COMMON.LAYOUT_SBT_CD_SHIN   THEN          
        
        IF iShimeKind = ULT_COMMON.SHIME_SBT_CD_HISHIME THEN
          --�V_������_DCF��t�Ζ���e�[�u���̃f�[�^���N���A����B
          EXECUTE_SQL := 'TRUNCATE TABLE ' || vSchemaNm || '.' || 'TD_ND_DCF_KJN_KINMUSAKI';
          EXECUTE IMMEDIATE EXECUTE_SQL;
          vTABLE1:='TT_Z_D_KJN';
          vTABLE2:='TT_Z_D_KJN_KINMUSAKI';
          --vTABLE3:='TM_Z_D_HIFG_SSY_SZKBUKA';
        ELSE
          --�V_�T����_DCF��t�Ζ���e�[�u���̃f�[�^���N���A����B          
          EXECUTE_SQL := 'TRUNCATE TABLE ' || vSchemaNm || '.' || 'TD_NW_DCF_KJN_KINMUSAKI';
          EXECUTE IMMEDIATE EXECUTE_SQL;
          vTABLE1:='TT_Z_W_KJN';
          vTABLE2:='TT_Z_W_KJN_KINMUSAKI';
          --vTABLE3:='TM_Z_W_HIFG_SSY_SZKBUKA';
        END IF;
        ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);
        vFromSQL :='B.UPD_EIGY_YMD AS UPD_EIGY_YMD,null, null, null, null, null 
          FROM TT_TIKY_KJN A  
          INNER JOIN TT_TIKY_KJN_KINMUSAKI B  
            ON A.REC_ID = B.REC_ID
            AND A.KJN_CD = B.KJN_CD          
          LEFT OUTER JOIN '||vTABLE1||' D  
            ON A.REC_ID = D.REC_ID
            AND A.KJN_CD = D.KJN_CD
          LEFT OUTER JOIN '||vTABLE2||' E  
            ON A.REC_ID = E.REC_ID
            AND A.KJN_CD = E.KJN_CD
            AND B.KINMUSAKI_REC_ID = E.KINMUSAKI_REC_ID
            AND B.KINMUSAKI_SHI_CD = E.KINMUSAKI_SHI_CD 
         ';        
        vWhereSQL:='WHERE A.REC_ID = ''01''
          AND B.UPD_EIGY_YMD >= '''||NVL(iShimeFrom,ULT_COMMON.ORIGINAL_YMD)||'''
          AND B.UPD_EIGY_YMD <= '''||iShimeTo||'''
          AND A.DEL_FLG IS NULL
          AND (B.TAISHOKU_FLG IS NULL OR D.REC_ID IS NOT NULL)'; 
        
        ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',vSelectSQL||vFromSQL||vWhereSQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);  
        OPEN cur FOR vSelectSQL||vFromSQL||vWhereSQL;
        LOOP
          FETCH cur INTO vRECORD;     
          EXIT WHEN cur%NOTFOUND; 
          oROW_COUNT:=oROW_COUNT+1;
          vMODKBN := ULT_COMMON.MOD_KBN_NO;
          vTAISHOKU_FLG := ULT_COMMON.TAISHOKU_FLG_HENKOU;
          --��r����1�Ɣ�r����2����v���Ă��Ȃ��܂��́A����͂̏������ȂɕύX������ꍇ
          IF vRECORD.FIELD1 != vRECORD.FIELD2 OR (vRECORD.SZKBUKA_CD = '9999' AND (NVL(vRECORD.SZKBUKA_NM_KANA1,0) != NVL(vRECORD.SZKBUKA_NM_KANA2,0) 
            OR NVL(vRECORD.SZKBUKA_NM1,0) != NVL(vRECORD.SZKBUKA_NM2,0)))  
          THEN
             
            --����f�[�^������A�O��f�[�^���Ȃ��ꍇ�A�ǉ��Ƃ��ēo�^����(��r����2�̐擪��TAB�̏ꍇ)
            IF SUBSTR(vRECORD.FIELD2,1,1) = ULT_COMMON.DELIMITER THEN
            	-- ������2012/10/09 ST000056�̑Ή�
              	vNowData := ULT_COMMON.StrSplit(vRECORD.FIELD1, ULT_COMMON.DELIMITER);
				IF NVL(vNowData(9),'0') = ULT_COMMON.TAISHOKU_FLG_TAISHOKU THEN
					vMODKBN := ULT_COMMON.MOD_KBN_DEL;
				ELSE
					vMODKBN  := ULT_COMMON.MOD_KBN_ADD;
					vTAISHOKU_FLG := ULT_COMMON.TAISHOKU_FLG_IDOU;
					vNowData(11):= vRECORD.SZKBUKA_NM_KANA1;
					vNowData(10):= vRECORD.SZKBUKA_NM1;
				END IF;
				-- ������2012/10/09 ST000056�̑Ή�
                         
            -- ����ƑO��ŕω��̂���f�[�^�͕ύX�Ƃ��ēo�^����i��r����1�Ɣ�r����2����v���Ă��Ȃ��܂��́A����͂̏������ȂɕύX������ꍇ�j
            ELSE  
              vMODKBN := ULT_COMMON.MOD_KBN_YES;
              vTAISHOKU_FLG := ULT_COMMON.TAISHOKU_FLG_HENKOU;
              vNowData := ULT_COMMON.StrSplit(vRECORD.FIELD1, ULT_COMMON.DELIMITER);
              vLastData:= ULT_COMMON.StrSplit(vRECORD.FIELD2, ULT_COMMON.DELIMITER); 
              vNowData(10):= vRECORD.SZKBUKA_NM1;     
              vLastData(10):= vRECORD.SZKBUKA_NM2;
              vNowData(11):= vRECORD.SZKBUKA_NM_KANA1;     
              vLastData(11):= vRECORD.SZKBUKA_NM_KANA2;
              
              -- ������2012/12/26 NH000087�̑Ή�         
              IF vLastData(3) IS NULL THEN
              	IF NVL(vNowData(9),'0') != ULT_COMMON.TAISHOKU_FLG_TAISHOKU THEN
              		vTAISHOKU_FLG := ULT_COMMON.TAISHOKU_FLG_IDOU;
              	ELSE
              		vMODKBN := ULT_COMMON.MOD_KBN_DEL;
              	END IF;
              ELSE
              	IF NVL(vNowData(9),'0') = ULT_COMMON.TAISHOKU_FLG_TAISHOKU THEN
              		IF NVL(vLastData(9),'0') = ULT_COMMON.TAISHOKU_FLG_TAISHOKU THEN
              			vMODKBN := ULT_COMMON.MOD_KBN_DEL;
              		ELSE
              			vTAISHOKU_FLG := ULT_COMMON.TAISHOKU_FLG_TAISHOKU;
              		END IF;
              	ELSE
              		IF NVL(vLastData(9),'0') = ULT_COMMON.TAISHOKU_FLG_TAISHOKU THEN
              			vTAISHOKU_FLG := ULT_COMMON.TAISHOKU_FLG_IDOU;
              		END IF;
              	END IF;
              END IF;
              
              IF NVL(vTAISHOKU_FLG,'0') = ULT_COMMON.TAISHOKU_FLG_HENKOU 
                 AND NVL(vMODKBN,'0') != ULT_COMMON.MOD_KBN_DEL THEN
              	  --�����l�ݒ�(��W���A�����l����)
	              ChangeToDefault(vNowData,vLastData,editInfo2);
	              --NULL�ݒ�(�W���A�����l�Ȃ�)
	              ChangeToNullForArray(vNowData,vLastData,editInfoArray1);
	          ELSIF NVL(vTAISHOKU_FLG,'0') = ULT_COMMON.TAISHOKU_FLG_TAISHOKU THEN
	          	  -- �f�[�^�������N���A�����B
	          	  vNowData(5):= NULL; 
	          	  vNowData(6):= NULL; 
	          	  vNowData(7):= NULL; 
	          	  vNowData(8):= NULL; 
	          	  vNowData(10):= NULL; 
	          	  vNowData(11):= NULL; 
              END IF;
              -- ������2012/12/26 NH000087�̑Ή�
            END IF;
            
            --�o�^����
            IF NVL(vMODKBN,'0') != ULT_COMMON.MOD_KBN_DEL THEN
              IF iShimeKind = ULT_COMMON.SHIME_SBT_CD_HISHIME THEN
                INSERT INTO TD_ND_DCF_KJN_KINMUSAKI(
                    LAYOUT_KBN,
                    KJNREC_ID,
                    KJN_CD,                    
                    MOD_KBN,
                    SHIREC_ID,
                    SHI_CD,                   
                    TAISHOKU_IDO_KBN,
                    MENTE_YMD,
                    TENSO_YMD,
                    YAKUSHOKU_CD,
                    SHOKUI,
                    SZKBUKA_CD,
                    SZKBUKA_KANJI,
                    SZKBUKA_KANA,
                    DM_FUKA_FLG,
                    Trk_Ope_Cd,
                    Trk_Date,
                    Trk_Pgm_Id,
                    Upd_Ope_Cd,
                    Upd_Date,
                    Upd_Pgm_Id
                    )
                  VALUES(
                    vLAYOUT_KBN,
                    vNowData(1),
                    vNowData(2),
                    vMODKBN,
                    vNowData(3),
                    vNowData(4),
                    TRIM(vTAISHOKU_FLG),
                    vRECORD.UPD_EIGY_YMD,
                    iTensoYMD,                    
                    TRIM(vNowData(5)),
                    TRIM(vNowData(6)),
                    vNowData(7),
                    vNowData(10),
                    vNowData(11),
                    TRIM(vNowData(8)),                    
                    iOPE_CD,
                    iDATE,
                    iPGM_ID,
                    iOPE_CD,
                    iDATE,
                    iPGM_ID            
                  );
                EXECUTE_SQL := 'INSERT INTO TD_ND_DCF_KJN_KINMUSAKI(';
              ELSE
                INSERT INTO TD_NW_DCF_KJN_KINMUSAKI(
                    LAYOUT_KBN,
                    KJNREC_ID,
                    KJN_CD,                    
                    MOD_KBN,
                    SHIREC_ID,
                    SHI_CD,                   
                    TAISHOKU_IDO_KBN,
                    MENTE_YMD,
                    TENSO_YMD,
                    YAKUSHOKU_CD,
                    SHOKUI,
                    SZKBUKA_CD,
                    SZKBUKA_KANJI,
                    SZKBUKA_KANA,
                    DM_FUKA_FLG,
                    Trk_Ope_Cd,
                    Trk_Date,
                    Trk_Pgm_Id,
                    Upd_Ope_Cd,
                    Upd_Date,
                    Upd_Pgm_Id
                    )
                  VALUES(
                    vLAYOUT_KBN,
                    vNowData(1),
                    vNowData(2),
                    vMODKBN,
                    vNowData(3),
                    vNowData(4),
                    TRIM(vTAISHOKU_FLG),
                    vRECORD.UPD_EIGY_YMD,
                    iTensoYMD,                    
                    TRIM(vNowData(5)),
                    TRIM(vNowData(6)),
                    vNowData(7),
                    vNowData(10),
                    vNowData(11),
                    TRIM(vNowData(8)),                    
                    iOPE_CD,
                    iDATE,
                    iPGM_ID,
                    iOPE_CD,
                    iDATE,
                    iPGM_ID            
                  );
                EXECUTE_SQL := 'INSERT INTO TD_NW_DCF_KJN_KINMUSAKI(';
              END IF;    
              EXECUTE_SQL := EXECUTE_SQL || '
                    LAYOUT_KBN,
                    KJNREC_ID,
                    KJN_CD,                    
                    MOD_KBN,
                    SHIREC_ID,
                    SHI_CD,                   
                    TAISHOKU_IDO_KBN,
                    MENTE_YMD,
                    TENSO_YMD,
                    YAKUSHOKU_CD,
                    SHOKUI,
                    SZKBUKA_CD,
                    SZKBUKA_KANJI,
                    SZKBUKA_KANA,
                    DM_FUKA_FLG,
                    Trk_Ope_Cd,
                    Trk_Date,
                    Trk_Pgm_Id,
                    Upd_Ope_Cd,
                    Upd_Date,
                    Upd_Pgm_Id
                    )
                  VALUES(
                    '''||vLAYOUT_KBN||''',
					          '''||vNowData(1)||''',
                    '''||vNowData(2)||''',
                    '''||vMODKBN||''',
                    '''||vNowData(3)||''',
                    '''||vNowData(4)||''',
                    '''||TRIM(vTAISHOKU_FLG)||''',
                    '''||vRECORD.UPD_EIGY_YMD||''',
                    '''||iTensoYMD||''',                    
                    '''||TRIM(vNowData(5))||''',
                    '''||TRIM(vNowData(6))||''',
                    '''||vNowData(7)||''',
                    '''||vNowData(10)||''',
                    '''||vNowData(11)||''',
                    '''||TRIM(vNowData(8))||''',                    
                    '''||iOPE_CD||''',
                    '''||iDATE||''',
                    '''||iPGM_ID||''',
                    '''||iOPE_CD||''',
                    '''||iDATE||''',
                    '''||iPGM_ID||''')';
              ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);      
            END IF;          
          END IF;  
        END LOOP;
        CLOSE cur;
        
      -- ���ߓ��敪��"4"(������)�A�܂��́A"5"(������)�A���� �����D���C�A�E�g�敪��"1"(�V���C�A�E�g) �̏ꍇ�A  
      ELSIF (iShimeKind = ULT_COMMON.SHIME_SBT_CD_NAKASHIME OR iShimeKind = ULT_COMMON.SHIME_SBT_CD_MATSUSHIME) AND
        iLayoutKind = ULT_COMMON.LAYOUT_SBT_CD_SHIN   THEN
        
        IF iM2Flg = ULT_COMMON.FLG_NO THEN
            --�V_��1����_DCF��t�Ζ���e�[�u���̃f�[�^���N���A����B            
            EXECUTE_SQL := 'TRUNCATE TABLE ' || vSchemaNm || '.' || 'TD_NM_DCF_KJN_KINMUSAKI';
            EXECUTE IMMEDIATE EXECUTE_SQL;
            
            -- 2012/11/06 CP000193�̑Ή�
            IF iShimeKind = ULT_COMMON.SHIME_SBT_CD_NAKASHIME THEN
            	vTABLE1:='TT_Z_MM_KJN';
	            vTABLE2:='TT_Z_MM_KJN_KINMUSAKI';
	            --vTABLE3:='TM_Z_MM_HIFG_SSY_SZKBUKA';
            ELSE
            	vTABLE1:='TT_Z_ME_KJN';
            	vTABLE2:='TT_Z_ME_KJN_KINMUSAKI';
            END IF;
            -- 2012/11/06 CP000193�̑Ή�
        ELSE
            --�V_��2����_DCF��t�Ζ���e�[�u���̃f�[�^���N���A����B
            EXECUTE_SQL := 'TRUNCATE TABLE ' || vSchemaNm || '.' || 'TD_N2_DCF_KJN_KINMUSAKI';
            EXECUTE IMMEDIATE EXECUTE_SQL;
            
            -- 2012/11/06 CP000193�̑Ή�
            IF iShimeKind = ULT_COMMON.SHIME_SBT_CD_NAKASHIME THEN
            	vTABLE1:='TT_Z_ME_KJN';
            	vTABLE2:='TT_Z_ME_KJN_KINMUSAKI';
            ELSE
            	vTABLE1:='TT_Z_MM_KJN';
	            vTABLE2:='TT_Z_MM_KJN_KINMUSAKI';
            END IF;
            -- 2012/11/06 CP000193�̑Ή�
        END IF; 
        ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);
        
        vSelectSQL := vSelectSQL||
          'CASE WHEN NVL(T.MAX_UPD_EIGY_YMD, ''19700101'') > NVL(A.UPD_EIGY_YMD, ''19700101'') THEN T.MAX_UPD_EIGY_YMD ELSE A.UPD_EIGY_YMD END AS UPD_EIGY_YMD,
           TTK.KJN_CD, B.KINMUSAKI_REC_ID, E.KINMUSAKI_REC_ID AS ZEN_KINMUSAKI_REC_ID, B.TAISHOKU_FLG, E.TAISHOKU_FLG AS ZEN_TAISHOKU_FLG';  
                
        vFromSQL :='
        FROM TT_TIKY_KJN A	
        INNER JOIN TT_TIKY_KJN_KINMUSAKI B	
          ON A.REC_ID = B.REC_ID
          AND A.KJN_CD = B.KJN_CD         
        LEFT OUTER JOIN '||vTABLE1||' D	
          ON A.REC_ID = D.REC_ID
          AND A.KJN_CD = D.KJN_CD
        LEFT OUTER JOIN '||vTABLE2||' E	
          ON A.REC_ID = E.REC_ID
          AND A.KJN_CD = E.KJN_CD
          AND B.KINMUSAKI_REC_ID = E.KINMUSAKI_REC_ID
          AND B.KINMUSAKI_SHI_CD = E.KINMUSAKI_SHI_CD
        LEFT OUTER JOIN 
        	(SELECT
				Y.KJN_CD,
				MAX(CASE WHEN NVL(Y.UPD_EIGY_YMD,''19700101'') > NVL(Z.UPD_EIGY_YMD,''19700101'') THEN Y.UPD_EIGY_YMD ELSE Z.UPD_EIGY_YMD END) AS MAX_UPD_EIGY_YMD
			FROM
				TT_TIKY_KJN Y
			LEFT OUTER JOIN
				TT_TIKY_KJN_KINMUSAKI Z
				ON Y.REC_ID = Z.REC_ID
				AND Y.KJN_CD = Z.KJN_CD
			WHERE
				Y.REC_ID = ''01''
				AND ((Y.UPD_EIGY_YMD >='''||NVL(iShimeFrom,ULT_COMMON.ORIGINAL_YMD)||'''
				AND Y.UPD_EIGY_YMD <= '''||iShimeTo||''')
				OR (Z.UPD_EIGY_YMD >= '''||NVL(iShimeFrom,ULT_COMMON.ORIGINAL_YMD)||'''
				AND Z.UPD_EIGY_YMD <= '''||iShimeTo||'''))
			GROUP BY
				Y.KJN_CD
			) T
			ON A.KJN_CD = T.KJN_CD
		LEFT OUTER JOIN
			(
				SELECT
					DISTINCT
					TT.KJN_CD
				FROM (
						SELECT
							TTK.KJN_CD,
							NULLIF( ''1'' || TTK.DEL_YOTEI_RIYU_CD,      ''1'' || TTZ.DEL_YOTEI_RIYU_CD      ) AS DEL_YOTEI_RIYU_CD,
							NULLIF( ''1'' || TTK.CHOFUKU_AITSK_REC_ID,   ''1'' || TTZ.CHOFUKU_AITSK_REC_ID   ) AS CHOFUKU_AITSK_REC_ID,
							NULLIF( ''1'' || TTK.CHOFUKU_AITSK_KJN_CD,   ''1'' || TTZ.CHOFUKU_AITSK_KJN_CD   ) AS CHOFUKU_AITSK_KJN_CD,
							NULLIF( ''1'' || TTK.KJN_NM,                 ''1'' || TTZ.KJN_NM                 ) AS KJN_NM,
							NULLIF( ''1'' || TTK.KJN_NM_KANA,            ''1'' || TTZ.KJN_NM_KANA            ) AS KJN_NM_KANA,
							NULLIF( ''1'' || TTK.SEIBETSU_KBN,           ''1'' || TTZ.SEIBETSU_KBN           ) AS SEIBETSU_KBN,
							NULLIF( ''1'' || TTK.BIRTH_GENGO_CD,         ''1'' || TTZ.BIRTH_GENGO_CD         ) AS BIRTH_GENGO_CD,
							NULLIF( ''1'' || TTK.BIRTH_WY,               ''1'' || TTZ.BIRTH_WY               ) AS BIRTH_WY,
							NULLIF( ''1'' || TTK.BIRTH_M,                ''1'' || TTZ.BIRTH_M                ) AS BIRTH_M,
							NULLIF( ''1'' || TTK.BIRTH_D,                ''1'' || TTZ.BIRTH_D                ) AS BIRTH_D,
							NULLIF( ''1'' || TTK.SHUSSHINCHI_RIDAI_CD,   ''1'' || TTZ.SHUSSHINCHI_RIDAI_CD   ) AS SHUSSHINCHI_RIDAI_CD,
							NULLIF( ''1'' || TTK.KANYU_ISHIKAI_RIDAI_CD, ''1'' || TTZ.KANYU_ISHIKAI_RIDAI_CD ) AS KANYU_ISHIKAI_RIDAI_CD,
							NULLIF( ''1'' || TTK.STNEN_GENGO_CD,         ''1'' || TTZ.STNEN_GENGO_CD         ) AS STNEN_GENGO_CD,
							NULLIF( ''1'' || TTK.STNEN_WY,               ''1'' || TTZ.STNEN_WY               ) AS STNEN_WY,
							NULLIF( ''1'' || TTK.SHUSSHINKO_CD,          ''1'' || TTZ.SHUSSHINKO_CD          ) AS SHUSSHINKO_CD,
							NULLIF( ''1'' || TTK.GAKUBU_SHIKIBETSU_KBN,  ''1'' || TTZ.GAKUBU_SHIKIBETSU_KBN  ) AS GAKUBU_SHIKIBETSU_KBN,
							NULLIF( ''1'' || TTK.TRKNEN_GENGO_CD,        ''1'' || TTZ.TRKNEN_GENGO_CD        ) AS TRKNEN_GENGO_CD,
							NULLIF( ''1'' || TTK.TRKNEN_WY,              ''1'' || TTZ.TRKNEN_WY              ) AS TRKNEN_WY,
							NULLIF( ''1'' || TTK.SNRYKMK_CD_1,           ''1'' || TTZ.SNRYKMK_CD_1           ) AS SNRYKMK_CD_1,
							NULLIF( ''1'' || TTK.SNRYKMK_CD_2,           ''1'' || TTZ.SNRYKMK_CD_2           ) AS SNRYKMK_CD_2,
							NULLIF( ''1'' || TTK.SNRYKMK_CD_3,           ''1'' || TTZ.SNRYKMK_CD_3           ) AS SNRYKMK_CD_3,
							NULLIF( ''1'' || TTK.SNRYKMK_CD_4,           ''1'' || TTZ.SNRYKMK_CD_4           ) AS SNRYKMK_CD_4,
							NULLIF( ''1'' || TTK.SNRYKMK_CD_5,           ''1'' || TTZ.SNRYKMK_CD_5           ) AS SNRYKMK_CD_5,
							NULLIF( ''1'' || TTK.JUSHOFUMEI_CD,          ''1'' || TTZ.JUSHOFUMEI_CD          ) AS JUSHOFUMEI_CD,
							NULLIF( ''1'' || TTK.KEN_CD,                 ''1'' || TTZ.KEN_CD                 ) AS KEN_CD,
							NULLIF( ''1'' || TTK.SHIKU_CD,               ''1'' || TTZ.SHIKU_CD               ) AS SHIKU_CD,
							NULLIF( ''1'' || TTK.OAZA_CD,                ''1'' || TTZ.OAZA_CD                ) AS OAZA_CD,
							NULLIF( ''1'' || TTK.AZA_CD,                 ''1'' || TTZ.AZA_CD                 ) AS AZA_CD,
							NULLIF( ''1'' || TTK.ZIP,                    ''1'' || TTZ.ZIP                    ) AS ZIP,
							NULLIF( ''1'' || TTK.JUSHO_KANJI_RENKETSU,   ''1'' || TTZ.JUSHO_KANJI_RENKETSU   ) AS JUSHO_KANJI_RENKETSU,
							NULLIF( ''1'' || TTK.JUSHO_KANA_RENKETSU,    ''1'' || TTZ.JUSHO_KANA_RENKETSU    ) AS JUSHO_KANA_RENKETSU,
							NULLIF( ''1'' || TTK.JUSHO_HYOJI_NO,         ''1'' || TTZ.JUSHO_HYOJI_NO         ) AS JUSHO_HYOJI_NO,
							NULLIF( ''1'' || TTK.KEN_NM_KANJI_MOJI_SU,   ''1'' || TTZ.KEN_NM_KANJI_MOJI_SU   ) AS KEN_NM_KANJI_MOJI_SU,
							NULLIF( ''1'' || TTK.SHIKU_NM_KANJI_MOJI_SU, ''1'' || TTZ.SHIKU_NM_KANJI_MOJI_SU ) AS SHIKU_NM_KANJI_MOJI_SU,
							NULLIF( ''1'' || TTK.OAZA_NM_KANJI_MOJI_SU,  ''1'' || TTZ.OAZA_NM_KANJI_MOJI_SU  ) AS OAZA_NM_KANJI_MOJI_SU,
							NULLIF( ''1'' || TTK.AZA_NM_KANJI_MOJI_SU,   ''1'' || TTZ.AZA_NM_KANJI_MOJI_SU   ) AS AZA_NM_KANJI_MOJI_SU,
							NULLIF( ''1'' || TTK.KEN_NM_KANA_MOJI_SU,    ''1'' || TTZ.KEN_NM_KANA_MOJI_SU    ) AS KEN_NM_KANA_MOJI_SU,
							NULLIF( ''1'' || TTK.SHIKU_NM_KANA_MOJI_SU,  ''1'' || TTZ.SHIKU_NM_KANA_MOJI_SU  ) AS SHIKU_NM_KANA_MOJI_SU,
							NULLIF( ''1'' || TTK.OAZA_NM_KANA_MOJI_SU,   ''1'' || TTZ.OAZA_NM_KANA_MOJI_SU   ) AS OAZA_NM_KANA_MOJI_SU,
							NULLIF( ''1'' || TTK.AZA_NM_KANA_MOJI_SU,	 ''1'' || TTZ.AZA_NM_KANA_MOJI_SU	 ) AS AZA_NM_KANA_MOJI_SU,	
							NULLIF( ''1'' || TTK.TEL,                    ''1'' || TTZ.TEL                    ) AS TEL,
							NULLIF( ''1'' || TTK.RIYOTEISHI_KBN_CD,      ''1'' || TTZ.RIYOTEISHI_KBN_CD      ) AS RIYOTEISHI_KBN_CD,
							NULLIF( ''1'' || TTK.RIYOTEISHI_RIYU_CD,     ''1'' || TTZ.RIYOTEISHI_RIYU_CD     ) AS RIYOTEISHI_RIYU_CD,
							NULLIF( ''1'' || TTK.RIYOTEISHI_TRK_YMD,     ''1'' || TTZ.RIYOTEISHI_TRK_YMD     ) AS RIYOTEISHI_TRK_YMD,
							NULLIF( ''1'' || TTK.RIYOTEISHI_KAIJO_YMD,   ''1'' || TTZ.RIYOTEISHI_KAIJO_YMD   ) AS RIYOTEISHI_KAIJO_YMD,
							NULLIF( ''1'' || TTK.kaikin_kbn,             ''1'' || TTZ.kaikin_kbn             ) AS kaikin_kbn,
							NULLIF( ''1'' || TTK.KAIGYONEN_GENGO_CD,     ''1'' || TTZ.KAIGYONEN_GENGO_CD     ) AS KAIGYONEN_GENGO_CD,
							NULLIF( ''1'' || TTK.KAIGYONEN_WY,           ''1'' || TTZ.KAIGYONEN_WY           ) AS KAIGYONEN_WY,
							NULLIF( ''1'' || TTK.IKKATSU_TRK_FLG,        ''1'' || TTZ.IKKATSU_TRK_FLG        ) AS IKKATSU_TRK_FLG	
						FROM TT_TIKY_KJN TTK
						LEFT OUTER JOIN TT_TIKY_KJN_KINMUSAKI TTKK
						ON TTK.REC_ID = TTKK.REC_ID
						AND TTK.KJN_CD = TTKK.KJN_CD
						LEFT OUTER JOIN '||vTABLE1||' TTZ
						ON TTK.REC_ID = TTZ.REC_ID
						AND TTK.KJN_CD = TTZ.KJN_CD
						WHERE TTK.REC_ID = ''01''
						AND ((TTK.UPD_EIGY_YMD >='''||NVL(iShimeFrom,ULT_COMMON.ORIGINAL_YMD)||'''
								AND TTK.UPD_EIGY_YMD <= '''||iShimeTo||'''
							 )
							OR (TTKK.UPD_EIGY_YMD >= '''||NVL(iShimeFrom,ULT_COMMON.ORIGINAL_YMD)||'''
								AND TTKK.UPD_EIGY_YMD <= '''||iShimeTo||'''
							   )
						    )
						AND TTK.DEL_FLG IS NULL
					 ) TT
				WHERE TT.DEL_YOTEI_RIYU_CD      IS NOT NULL
					OR TT.CHOFUKU_AITSK_REC_ID   IS NOT NULL
					OR TT.CHOFUKU_AITSK_KJN_CD   IS NOT NULL
					OR TT.KJN_NM                 IS NOT NULL
					OR TT.KJN_NM_KANA            IS NOT NULL
					OR TT.SEIBETSU_KBN           IS NOT NULL
					OR TT.BIRTH_GENGO_CD         IS NOT NULL
					OR TT.BIRTH_WY               IS NOT NULL
					OR TT.BIRTH_M                IS NOT NULL
					OR TT.BIRTH_D                IS NOT NULL
					OR TT.SHUSSHINCHI_RIDAI_CD   IS NOT NULL
					OR TT.KANYU_ISHIKAI_RIDAI_CD IS NOT NULL
					OR TT.STNEN_GENGO_CD         IS NOT NULL
					OR TT.STNEN_WY               IS NOT NULL
					OR TT.SHUSSHINKO_CD          IS NOT NULL
					OR TT.GAKUBU_SHIKIBETSU_KBN  IS NOT NULL
					OR TT.TRKNEN_GENGO_CD        IS NOT NULL
					OR TT.TRKNEN_WY              IS NOT NULL
					OR TT.SNRYKMK_CD_1           IS NOT NULL
					OR TT.SNRYKMK_CD_2           IS NOT NULL
					OR TT.SNRYKMK_CD_3           IS NOT NULL
					OR TT.SNRYKMK_CD_4           IS NOT NULL
					OR TT.SNRYKMK_CD_5           IS NOT NULL
					OR TT.JUSHOFUMEI_CD          IS NOT NULL
					OR TT.KEN_CD                 IS NOT NULL
					OR TT.SHIKU_CD               IS NOT NULL
					OR TT.OAZA_CD                IS NOT NULL
					OR TT.AZA_CD                 IS NOT NULL
					OR TT.ZIP                    IS NOT NULL
					OR TT.JUSHO_KANJI_RENKETSU   IS NOT NULL
					OR TT.JUSHO_KANA_RENKETSU    IS NOT NULL
					OR TT.JUSHO_HYOJI_NO         IS NOT NULL
					OR TT.KEN_NM_KANJI_MOJI_SU   IS NOT NULL
					OR TT.SHIKU_NM_KANJI_MOJI_SU IS NOT NULL
					OR TT.OAZA_NM_KANJI_MOJI_SU  IS NOT NULL
					OR TT.AZA_NM_KANJI_MOJI_SU   IS NOT NULL
					OR TT.KEN_NM_KANA_MOJI_SU    IS NOT NULL
					OR TT.SHIKU_NM_KANA_MOJI_SU  IS NOT NULL
					OR TT.OAZA_NM_KANA_MOJI_SU   IS NOT NULL
					OR TT.AZA_NM_KANA_MOJI_SU	 IS NOT NULL
					OR TT.TEL                    IS NOT NULL
					OR TT.RIYOTEISHI_KBN_CD      IS NOT NULL
					OR TT.RIYOTEISHI_RIYU_CD     IS NOT NULL
					OR TT.RIYOTEISHI_TRK_YMD     IS NOT NULL
					OR TT.RIYOTEISHI_KAIJO_YMD   IS NOT NULL
					OR TT.kaikin_kbn             IS NOT NULL
					OR TT.KAIGYONEN_GENGO_CD     IS NOT NULL
					OR TT.KAIGYONEN_WY           IS NOT NULL
					OR TT.IKKATSU_TRK_FLG        IS NOT NULL
			) TTK
			ON A.KJN_CD = TTK.KJN_CD
        ';
        --�������� 2012/10/04 �d�l�ύX�̑Ή��i�l�f�[�^�̕ύX���o�͑ΏۂƂ���j
                 
        vWhereSQL:=' WHERE A.REC_ID = ''01''
				          AND ((A.UPD_EIGY_YMD >='''||NVL(iShimeFrom,ULT_COMMON.ORIGINAL_YMD)||'''
									AND A.UPD_EIGY_YMD <= '''||iShimeTo||'''
								  )
								OR (B.UPD_EIGY_YMD >= '''||NVL(iShimeFrom,ULT_COMMON.ORIGINAL_YMD)||'''
									AND B.UPD_EIGY_YMD <= '''||iShimeTo||'''
								   )
								)      
				          AND A.DEL_FLG IS NULL
				     ORDER BY
				     	A.REC_ID ASC,
				     	A.KJN_CD ASC';
		-- ������ 2012/10/04 �d�l�ύX�̑Ή��i�l�f�[�^�̕ύX���o�͑ΏۂƂ���j
        
        vMODKBN:=ULT_COMMON.MOD_KBN_NO;       
        vLen := 8+LENGTH(ULT_COMMON.DELIMITER);
        
        ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',vSelectSQL||vFromSQL||vWhereSQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);
        OPEN cur FOR vSelectSQL||vFromSQL||vWhereSQL;
        LOOP
          FETCH cur INTO vRECORD;     
          --EXIT WHEN cur%NOTFOUND; 
          oROW_COUNT:=oROW_COUNT+1;
          --����l�P�ʂ̃f�[�^�ƑO��ŕω�������f�[�^�͓o�^����
          IF tempTABLE.COUNT>0 AND 
            (SUBSTR(vRECORD.FIELD1,1,vLen) !=  SUBSTR(tempTABLE(tempTABLE.COUNT).FIELD1,1,vLen) OR cur%NOTFOUND)
          THEN
            IF vMODKBN != ULT_COMMON.MOD_KBN_NO THEN
              FOR i IN 1..tempTABLE.COUNT LOOP
                tempRecord := tempTABLE(i);
                
                -- �C���敪(�ꎞ�p)�̍Đݒ���s��
              	vTempModKbn := NULL;
              	vTempModKbn := vMODKBN;
                
                --��r���ڂ��獡��f�[�^�̔z��ƑO��f�[�^�̔z����擾����
                vNowData := ULT_COMMON.StrSplit(tempRecord.FIELD1, ULT_COMMON.DELIMITER);
                vLastData := ULT_COMMON.StrSplit(tempRecord.FIELD2, ULT_COMMON.DELIMITER);
                
                --�C���敪��"B"�̏ꍇ�A
                IF vMODKBN=ULT_COMMON.MOD_KBN_YES THEN
				  IF vLastData(3) IS NULL THEN
				  	IF vNowData(3) IS NOT NULL THEN
				  		IF vNowData(9) IS NOT NULL THEN
				  			-- ���o�����Ζ����񂪑ސE�����ꍇ�A�A
	                    	vTempModKbn := ULT_COMMON.MOD_KBN_NO;
                  		END IF;
				  	END IF;
				  ELSE
				  	IF vNowData(9) IS NOT NULL THEN
				  		IF vLastData(9) IS NOT NULL THEN
				  			-- ���o�����Ζ����񂪑ސE�����ꍇ�A�A
	                    	vTempModKbn := ULT_COMMON.MOD_KBN_NO;
	                    ELSE
	                    	-- ���o�����Ζ����񂪑ސE�����ꍇ�A�A
	                    	vTempModKbn := 'D';	
                  		END IF;
				  	END IF;
				  END IF;
                -- �C���敪��"A"�̏ꍇ�A
                ELSIF vMODKBN=ULT_COMMON.MOD_KBN_ADD THEN
                 	IF vNowData(9) IS NOT NULL THEN
                  		-- ���o�����Ζ����񂪑ސE�����ꍇ�A
	                    vTempModKbn := ULT_COMMON.MOD_KBN_NO;
                  	END IF;
                END IF;
                
                IF vTempModKbn != ULT_COMMON.MOD_KBN_NO THEN
                  --�o�^����
                  IF iM2Flg = ULT_COMMON.FLG_NO THEN
                    INSERT INTO TD_NM_DCF_KJN_KINMUSAKI(
                      LAYOUT_KBN,
                      KJNREC_ID,
                      KJN_CD,                    
                      MOD_KBN,
                      SHIREC_ID,
                      SHI_CD,
                      MENTE_YMD,                    
                      YAKUSHOKU_CD,
                      SHOKUI,
                      SZKBUKA_CD,
                      SZKBUKA_KANJI,
                      SZKBUKA_KANA,
                      DM_FUKA_FLG,
                      Trk_Ope_Cd,
                      Trk_Date,
                      Trk_Pgm_Id,
                      Upd_Ope_Cd,
                      Upd_Date,
                      Upd_Pgm_Id
                      )
                    VALUES(
                      vLAYOUT_KBN,
                      vNowData(1),
                      vNowData(2),
                      vTempModKbn,
                      vNowData(3),
                      vNowData(4),                    
                      tempRecord.UPD_EIGY_YMD,                                        
                      vNowData(5),
                      vNowData(6),
                      vNowData(7),
                      tempRecord.SZKBUKA_NM1,
                      tempRecord.SZKBUKA_NM_KANA1,
                      vNowData(8),                    
                      iOPE_CD,
                      iDATE,
                      iPGM_ID,
                      iOPE_CD,
                      iDATE,
                      iPGM_ID            
                    );    
                    EXECUTE_SQL := 'INSERT INTO TD_NM_DCF_KJN_KINMUSAKI(';
                  ELSE
                    INSERT INTO TD_N2_DCF_KJN_KINMUSAKI(
                      LAYOUT_KBN,
                      KJNREC_ID,
                      KJN_CD,                    
                      MOD_KBN,
                      SHIREC_ID,
                      SHI_CD,
                      MENTE_YMD,                    
                      YAKUSHOKU_CD,
                      SHOKUI,
                      SZKBUKA_CD,
                      SZKBUKA_KANJI,
                      SZKBUKA_KANA,
                      DM_FUKA_FLG,
                      Trk_Ope_Cd,
                      Trk_Date,
                      Trk_Pgm_Id,
                      Upd_Ope_Cd,
                      Upd_Date,
                      Upd_Pgm_Id
                      )
                    VALUES(
                      vLAYOUT_KBN,
                      vNowData(1),
                      vNowData(2),
                      vTempModKbn,
                      vNowData(3),
                      vNowData(4),                    
                      tempRecord.UPD_EIGY_YMD,                                        
                      vNowData(5),
                      vNowData(6),
                      vNowData(7),
                      tempRecord.SZKBUKA_NM1,
                      tempRecord.SZKBUKA_NM_KANA1,
                      vNowData(8),                    
                      iOPE_CD,
                      iDATE,
                      iPGM_ID,
                      iOPE_CD,
                      iDATE,
                      iPGM_ID);
                    EXECUTE_SQL := 'INSERT INTO TD_N2_DCF_KJN_KINMUSAKI(';
                  END IF;
                  EXECUTE_SQL := EXECUTE_SQL || '
                    LAYOUT_KBN,
                        KJNREC_ID,
                        KJN_CD,                    
                        MOD_KBN,
                        SHIREC_ID,
                        SHI_CD,
                        MENTE_YMD,                    
                        YAKUSHOKU_CD,
                        SHOKUI,
                        SZKBUKA_CD,
                        SZKBUKA_KANJI,
                        SZKBUKA_KANA,
                        DM_FUKA_FLG,
                        Trk_Ope_Cd,
                        Trk_Date,
                        Trk_Pgm_Id,
                        Upd_Ope_Cd,
                        Upd_Date,
                        Upd_Pgm_Id
                        )
                      VALUES(
                   '''||vLAYOUT_KBN||''',
                   '''||vNowData(1)||''',
                   '''||vNowData(2)||''',
                   '''||vTempModKbn||''',
                   '''||vNowData(3)||''',
                   '''||vNowData(4)||''',
                   '''||tempRecord.UPD_EIGY_YMD||''',
                   '''||vNowData(5)||''',
                   '''||vNowData(6)||''',
                   '''||vNowData(7)||''',
                   '''||tempRecord.SZKBUKA_NM1||''',
                   '''||tempRecord.SZKBUKA_NM_KANA1||''',
                   '''||vNowData(8)||''',
                   '''||iOPE_CD||''',
                   '''||iDATE||''',
                   '''||iPGM_ID||''',
                   '''||iOPE_CD||''',
                   '''||iDATE||''',
                   '''||iPGM_ID||''')';	
                   ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);
                END IF;
              END LOOP;
            END IF;
            --������
            vMODKBN:=ULT_COMMON.MOD_KBN_NO;
            tempTABLE.DELETE;
          END IF;
          EXIT WHEN cur%NOTFOUND;          
          
          IF vMODKBN = ULT_COMMON.MOD_KBN_NO  THEN
            --����f�[�^������A�O��f�[�^���Ȃ��ꍇ�A�ǉ��Ƃ��ēo�^����i��r����2�̐擪��TAB�̏ꍇ�j
            IF SUBSTR(vRECORD.FIELD2,1,1)=ULT_COMMON.DELIMITER THEN
              vMODKBN:=ULT_COMMON.MOD_KBN_ADD;
              vRECORD.FIELD1:=vRECORD.FIELD1||ULT_COMMON.DELIMITER||ULT_COMMON.DELIMITER;
                 
            --����ƑO��ŕω��̂���f�[�^�͕ύX�Ƃ��ēo�^����i��r����1�Ɣ�r����2����v���Ă��Ȃ��܂��́A����͂̏������ȂɕύX������ꍇ�j
            ELSIF vRECORD.KJN_CD IS NOT NULL
            	 OR vRECORD.FIELD1 != vRECORD.FIELD2 
            	 OR                  
                 ( 	NVL(vRECORD.SZKBUKA_NM_KANA1,0) != NVL(vRECORD.SZKBUKA_NM_KANA2,0) 
                  OR
                  	NVL(vRECORD.SZKBUKA_NM1,0) != NVL(vRECORD.SZKBUKA_NM2,0)
                 ) 
                 -- ������ 2012/10/04 �d�l�ύX�̑Ή��i�l�f�[�^�̕ύX���o�͑ΏۂƂ���j
            THEN
            	-- ������2012/11/06 CP000193�̑Ή�
            	IF NVL(vRECORD.TAISHOKU_FLG, '0') = '1' AND NVL(vRECORD.ZEN_TAISHOKU_FLG, '0') = '1' THEN
            	    NULL;
				---- 2012/12/06 START NH00021�Ή�----
            	ELSIF NVL(vRECORD.TAISHOKU_FLG, '0') = '1' AND TRIM(vRECORD.ZEN_KINMUSAKI_REC_ID) IS NULL THEN
            	    NULL;
				---- 2012/12/06 END NH00021�Ή�----
            	ELSE
            		vMODKBN:=ULT_COMMON.MOD_KBN_YES;
            	END IF;
            	-- ������2012/11/06 CP000193�̑Ή�
            	
                vRECORD.FIELD1:=vRECORD.FIELD1||ULT_COMMON.DELIMITER||vRECORD.SZKBUKA_NM_KANA1||ULT_COMMON.DELIMITER||vRECORD.SZKBUKA_NM1;
            END IF;            
          END IF;
          
          --���݂̃f�[�^���ꎞ�ϐ��ɂ����
          tempTABLE.EXTEND;
          tempTABLE(tempTABLE.COUNT):=vRECORD;
          
       END LOOP;
       CLOSE cur;
       
       vINSERT_SQL := NULL;
       -- �l�P�ʂŃf�[�^��o�^���鏈���i�l�ɕR�Â��S�f�[�^���o�^���ꂽ��Ԃɂ���j
	   -- �u�l�R�[�h_���R�[�hID�A�l�R�[�h_�l�R�[�h�v����v���A
	   -- �u�Ζ���_�{�݃R�[�h_���R�[�hID�A�Ζ���_�{�݃R�[�h_�{�݃R�[�h�v���s��v�̃f�[�^��o�^����΂悢
       IF iM2Flg = ULT_COMMON.FLG_NO THEN
			vINSERT_TBL := ' TD_NM_DCF_KJN_KINMUSAKI ';
       ELSE
			vINSERT_TBL := ' TD_N2_DCF_KJN_KINMUSAKI '; 
       END IF;
       
       vINSERT_SQL := 'INSERT INTO ' || vINSERT_TBL
       					|| ' SELECT'
       					|| '''' || vLAYOUT_KBN || ''''
						|| ',A.REC_ID'
						|| ',A.KJN_CD'
						|| ',NULL'
						|| ',''B'''
						|| ',B.KINMUSAKI_REC_ID'
						|| ',B.KINMUSAKI_SHI_CD'
						|| ',NULL'
						|| ',NULL'
						|| ',M.MENTE_YMD'
						|| ',NULL'
						|| ',B.YAKUSHOKU_CD'
						|| ',B.SHOKUI_CD'
						|| ',B.SZKBUKA_CD'
						|| ',DECODE(B.SZKBUKA_CD, ''9999'', B.NYURYOKU_SZKBUKA_NM, NULL)'
						|| ',DECODE(B.SZKBUKA_CD, ''9999'', B.NYURYOKU_SZKBUKA_NM_KANA, NULL)'
						|| ',B.KINMUSAKI_DM_FUKA_FLG'
						|| ',''' || iOPE_CD || ''''
						|| ',TO_DATE(' || TO_CHAR(iDATE, 'YYYYMMDDHH24MISS') || ', ''YYYYMMDDHH24MISS'')'
						|| ',''' || iPGM_ID || ''''
						|| ',''' || iOPE_CD || ''''
						|| ',TO_DATE(' || TO_CHAR(iDATE, 'YYYYMMDDHH24MISS') || ', ''YYYYMMDDHH24MISS'')'
						|| ',''' || iPGM_ID || ''''
						|| ' FROM'
						|| ' TT_TIKY_KJN A'
						|| ' INNER JOIN '
						|| '              ( '
						|| '                 SELECT '
						|| '                       TBL.KJNREC_ID, '
						|| '                       TBL.KJN_CD, '
						|| '                       MAX(TBL.MENTE_YMD) AS MENTE_YMD '
						|| '                 FROM  ' || vINSERT_TBL || ' TBL '
						|| '                 GROUP BY '
						|| '                       TBL.KJNREC_ID, '
						|| '                       TBL.KJN_CD '
						|| '               ) M '
						|| '     ON A.REC_ID = M.KJNREC_ID '
						|| '     AND A.KJN_CD = M.KJN_CD '
						|| ' INNER JOIN'
						|| '     TT_TIKY_KJN_KINMUSAKI B'
						|| '     ON A.REC_ID = B.REC_ID'
						|| '     AND A.KJN_CD = B.KJN_CD'
						|| '     AND B.TAISHOKU_FLG IS NULL'
						|| ' WHERE A.DEL_FLG IS NULL '
						|| '     AND A.REC_ID = ''01'' '
						|| '     AND NOT EXISTS'
						|| '     				(SELECT S.KJNREC_ID '
						|| '                     FROM ' || vINSERT_TBL || ' S'
						|| '      				 WHERE A.REC_ID = S.KJNREC_ID'
						|| '      				   AND A.KJN_CD = S.KJN_CD'
						|| '                       AND B.KINMUSAKI_REC_ID = S.SHIREC_ID '
						|| '                       AND B.KINMUSAKI_SHI_CD = S.SHI_CD '
						|| '                    ) '
				;

		EXECUTE IMMEDIATE vINSERT_SQL;
		
		--�ސE�f�[�^�͕s�v�̂��ߌ�t���폜����
		IF iM2Flg = ULT_COMMON.FLG_YES THEN
			vINSERT_SQL := 'DELETE FROM TD_N2_DCF_KJN_KINMUSAKI';
		ELSE
			vINSERT_SQL := 'DELETE FROM TD_NM_DCF_KJN_KINMUSAKI';
		END IF;
		
		vINSERT_SQL := vINSERT_SQL || ' TBL '	|| ' WHERE TBL.MOD_KBN = ''D''';
		
		EXECUTE IMMEDIATE vINSERT_SQL;

     END IF;
      
	 commit;

     -- �I�����O�o��
   	 ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'PL/SQL End',PGM_ID || '�̏������I�����܂����B',iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);
        
    -- ����I��
    oROW_COUNT := -1;
    RETURN 0;
    
    -- ��O����
	EXCEPTION
		-- ���̑��G���[
		WHEN OTHERS THEN
			W_ERR_INF_RCD.ERR_CD 		:= TO_CHAR(SQLCODE);
			W_ERR_INF_RCD.ERR_MSG 		:= SUBSTR(SQLERRM, 0, 500);
			W_ERR_INF_RCD.ERR_KEY_INF 	:= SUBSTR('iLayoutKind:' || iLayoutKind || ', iShimeKind:' || iShimeKind , 0,500);
			W_INDEX_N 					:= W_ERR_INF_TBL.COUNT + 1;
			W_ERR_INF_TBL.EXTEND;
			W_ERR_INF_TBL(W_INDEX_N) 	:= W_ERR_INF_RCD;

			OPEN oOUT_ERR_INF_CSR FOR
				SELECT * FROM TABLE(W_ERR_INF_TBL);
      ROLLBACK;

      --�G���[���O�̓o�^
      ULT_INSERT_LOG_TABLE('ERROR',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'ERROR_INFO',W_ERR_INF_RCD.ERR_MSG,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);
 
 	  -- �ُ�G���[�Ƃ��A
      RETURN ULT_COMMON.RESULT_ERROR;
			
END;

END;
/
