CREATE OR REPLACE PACKAGE NH010107B001_132
/* **********************************************************
*  Copyright(c) 2011 beyond, INTEC Inc. All rights reserved.
* **********************************************************/
AUTHID CURRENT_USER
IS
    /*** �J�[�\���^ ***************************************************************/
    -- �G���[���i�[�p�J�[�\���^
    TYPE ERR_INF_CSR   IS REF CURSOR;
    -- ��Ë@�\���i�[�p�J�[�\���^
    TYPE IKJ_INF_CSR IS REF CURSOR;
    /*** ���R�[�h�^ ***************************************************************/
    -- ��Ë@�\���_��{���i�[�p���R�[�h�^
    TYPE IKJ_KHN_ROW IS RECORD(
    N_P_SHI_CD                     TT_TIKY_SHI.SHI_CD%TYPE,
    N_P_DEL_FLG                    TT_TIKY_SHI.DEL_FLG%TYPE,
    O_P_SHI_CD                     TT_Z_D_SHI.SHI_CD%TYPE,
    O_P_DEL_FLG                    TT_Z_D_SHI.DEL_FLG%TYPE,
    N_C_SHI_CD                     TT_TIKY_IKJ_KIHON.SHI_CD%TYPE,
    N_C_DEL_FLG                    TT_TIKY_IKJ_KIHON.DEL_FLG%TYPE,
    O_C_SHI_CD                     TT_Z_D_IKJ_KIHON.SHI_CD%TYPE,
    O_C_DEL_FLG                    TT_Z_D_IKJ_KIHON.DEL_FLG%TYPE,
    N_C_UPD_EIGY_YMD               TT_TIKY_IKJ_KIHON.UPD_EIGY_YMD%TYPE,
    N_C_JOHO_YMD                   TT_TIKY_IKJ_KIHON.JOHO_YMD%TYPE,
    N_C_ANNAIYO_URL                TT_TIKY_IKJ_KIHON.ANNAIYO_URL%TYPE,
    N_C_INNAI_SHOHO_FLG            TT_TIKY_IKJ_KIHON.INNAI_SHOHO_FLG%TYPE,
    N_C_INGAI_SHOHO_FLG            TT_TIKY_IKJ_KIHON.INGAI_SHOHO_FLG%TYPE,
    N_C_CHIKENJISSHI_FLG           TT_TIKY_IKJ_KIHON.CHIKENJISSHI_FLG%TYPE,
    N_C_CHIKENJISSHI_KIYK_KENSU    TT_TIKY_IKJ_KIHON.CHIKENJISSHI_KIYK_KENSU%TYPE,
    N_C_CHIKENJISSHI_S_YMD         TT_TIKY_IKJ_KIHON.CHIKENJISSHI_S_YMD%TYPE,
    N_C_CHIKENJISSHI_E_YMD         TT_TIKY_IKJ_KIHON.CHIKENJISSHI_E_YMD%TYPE,
    N_C_STB_FLG                    TT_TIKY_IKJ_KIHON.STB_FLG%TYPE,
    N_C_SHIKKAN_CHRY_FLG           TT_TIKY_IKJ_KIHON.SHIKKAN_CHRY_FLG%TYPE,
    N_C_TNK_TIZI_SJT_FLG           TT_TIKY_IKJ_KIHON.TNK_TIZI_SJT_FLG%TYPE,
    N_C_SMG_FLG                    TT_TIKY_IKJ_KIHON.SMG_FLG%TYPE,
    N_C_CHIKRENKEI_MADOGUCHI_FLG   TT_TIKY_IKJ_KIHON.CHIKRENKEI_MADOGUCHI_FLG%TYPE,
    N_C_CHIKRENKEIPATH_FLG_IKJ     TT_TIKY_IKJ_KIHON.CHIKRENKEIPATH_FLG_IKJ%TYPE,
    N_C_NYUINSNRY_INNAI_R_FLG      TT_TIKY_IKJ_KIHON.NYUINSNRY_INNAI_RNKITISI_FLG%TYPE,
    N_C_ORDERINGSYSTEM_FLG         TT_TIKY_IKJ_KIHON.ORDERINGSYSTEM_FLG%TYPE,
    N_C_ORDERINGSYSTEM_KENSA_FLG   TT_TIKY_IKJ_KIHON.ORDERINGSYSTEM_KENSA_FLG%TYPE,
    N_C_ORDERINGSYSTEM_SHOHO_FLG   TT_TIKY_IKJ_KIHON.ORDERINGSYSTEM_SHOHO_FLG%TYPE,
    N_C_ORDERINGSYSTEM_YOYAKU_FLG  TT_TIKY_IKJ_KIHON.ORDERINGSYSTEM_YOYAKU_FLG%TYPE,
    N_C_ICD_CD_RIYO_FLG            TT_TIKY_IKJ_KIHON.ICD_CD_RIYO_FLG%TYPE,
    N_C_DENSHI_KARTE_FLG           TT_TIKY_IKJ_KIHON.DENSHI_KARTE_FLG%TYPE,
    N_C_KARTEKANRI_SENNIN_FLG      TT_TIKY_IKJ_KIHON.KARTEKANRI_SENNIN_FLG%TYPE,
    N_C_KARTEKANRI_SENNIN_SU       TT_TIKY_IKJ_KIHON.KARTEKANRI_SENNIN_SU%TYPE,
    N_C_KANJYASU_IPPAN_BED         TT_TIKY_IKJ_KIHON.KANJYASU_IPPAN_BED%TYPE,
    N_C_KANJYASU_RYOYO_BED         TT_TIKY_IKJ_KIHON.KANJYASU_RYOYO_BED%TYPE,
    N_C_KANJYASU_R_BED_IRY_HKN     TT_TIKY_IKJ_KIHON.KANJYASU_RYOYO_BED_IRY_HKN%TYPE,
    N_C_KANJYASU_R_BED_KIG_HKN     TT_TIKY_IKJ_KIHON.KANJYASU_RYOYO_BED_KIG_HKN%TYPE,
    N_C_KANJYASU_SEISHIN_BED       TT_TIKY_IKJ_KIHON.KANJYASU_SEISHIN_BED%TYPE,
    N_C_KANJYASU_KEKKAKU_BED       TT_TIKY_IKJ_KIHON.KANJYASU_KEKKAKU_BED%TYPE,
    N_C_KANJYASU_KANSEN            TT_TIKY_IKJ_KIHON.KANJYASU_KANSEN%TYPE,
    N_C_KANJYASU_ZENTAI_BED        TT_TIKY_IKJ_KIHON.KANJYASU_ZENTAI_BED%TYPE,
    N_C_KANJYASU_BED_SBT_S_YMD     TT_TIKY_IKJ_KIHON.KANJYASU_BED_SBT_S_YMD%TYPE,
    N_C_KANJYASU_BED_SBT_E_YMD     TT_TIKY_IKJ_KIHON.KANJYASU_BED_SBT_E_YMD%TYPE,
    N_C_KANJYASU_GAIRAI            TT_TIKY_IKJ_KIHON.KANJYASU_GAIRAI%TYPE,
    N_C_KANJYASU_GAIRAI_S_YMD      TT_TIKY_IKJ_KIHON.KANJYASU_GAIRAI_S_YMD%TYPE,
    N_C_KANJYASU_GAIRAI_E_YMD      TT_TIKY_IKJ_KIHON.KANJYASU_GAIRAI_E_YMD%TYPE,
    N_C_KANJYASU_ZAITAKU           TT_TIKY_IKJ_KIHON.KANJYASU_ZAITAKU%TYPE,
    N_C_KANJYASU_ZAITAKU_S_YMD     TT_TIKY_IKJ_KIHON.KANJYASU_ZAITAKU_S_YMD%TYPE,
    N_C_KANJYASU_ZAITAKU_E_YMD     TT_TIKY_IKJ_KIHON.KANJYASU_ZAITAKU_E_YMD%TYPE,
    N_C_KANJYANSU_IPPAN_BED        TT_TIKY_IKJ_KIHON.KANJYANSU_IPPAN_BED%TYPE,
    N_C_KANJYANSU_RYOYO_BED        TT_TIKY_IKJ_KIHON.KANJYANSU_RYOYO_BED%TYPE,
    N_C_KANJYANSU_R_BED_IRY_HKN    TT_TIKY_IKJ_KIHON.KANJYANSU_RYOYO_BED_IRY_HKN%TYPE,
    N_C_KANJYANSU_R_BED_KIG_HKN    TT_TIKY_IKJ_KIHON.KANJYANSU_RYOYO_BED_KIG_HKN%TYPE,
    N_C_KANJYANSU_SEISHIN_BED      TT_TIKY_IKJ_KIHON.KANJYANSU_SEISHIN_BED%TYPE,
    N_C_KANJYANSU_KEKKAKU_BED      TT_TIKY_IKJ_KIHON.KANJYANSU_KEKKAKU_BED%TYPE,
    N_C_KANJYANSU_KANSEN           TT_TIKY_IKJ_KIHON.KANJYANSU_KANSEN%TYPE,
    N_C_KANJYANSU_ZENTAI_BED       TT_TIKY_IKJ_KIHON.KANJYANSU_ZENTAI_BED%TYPE,
    N_C_KANJYANSU_BED_SBT_S_YMD    TT_TIKY_IKJ_KIHON.KANJYANSU_BED_SBT_S_YMD%TYPE,
    N_C_KANJYANSU_BED_SBT_E_YMD    TT_TIKY_IKJ_KIHON.KANJYANSU_BED_SBT_E_YMD%TYPE,
    N_C_KANJYANSU_GAIRAI           TT_TIKY_IKJ_KIHON.KANJYANSU_GAIRAI%TYPE,
    N_C_KANJYANSU_GAIRAI_S_YMD     TT_TIKY_IKJ_KIHON.KANJYANSU_GAIRAI_S_YMD%TYPE,
    N_C_KANJYANSU_GAIRAI_E_YMD     TT_TIKY_IKJ_KIHON.KANJYANSU_GAIRAI_E_YMD%TYPE,
    N_C_KANJYANSU_ZAITAKU          TT_TIKY_IKJ_KIHON.KANJYANSU_ZAITAKU%TYPE,
    N_C_KANJYANSU_ZAITAKU_S_YMD    TT_TIKY_IKJ_KIHON.KANJYANSU_ZAITAKU_S_YMD%TYPE,
    N_C_KANJYANSU_ZAITAKU_E_YMD    TT_TIKY_IKJ_KIHON.KANJYANSU_ZAITAKU_E_YMD%TYPE,
    N_C_AVGNISSU_IPPAN_BED         TT_TIKY_IKJ_KIHON.AVGNISSU_IPPAN_BED%TYPE,
    N_C_AVGNISSU_RYOYO_BED         TT_TIKY_IKJ_KIHON.AVGNISSU_RYOYO_BED%TYPE,
    N_C_AVGNISSU_R_BED_IRY_HKN     TT_TIKY_IKJ_KIHON.AVGNISSU_RYOYO_BED_IRY_HKN%TYPE,
    N_C_AVGNISSU_R_BED_KIG_HKN     TT_TIKY_IKJ_KIHON.AVGNISSU_RYOYO_BED_KIG_HKN%TYPE,
    N_C_AVGNISSU_SEISHIN_BED       TT_TIKY_IKJ_KIHON.AVGNISSU_SEISHIN_BED%TYPE,
    N_C_AVGNISSU_KEKKAKU_BED       TT_TIKY_IKJ_KIHON.AVGNISSU_KEKKAKU_BED%TYPE,
    N_C_AVGNISSU_KANSEN            TT_TIKY_IKJ_KIHON.AVGNISSU_KANSEN%TYPE,
    N_C_AVGNISSU_ZENTAI_BED        TT_TIKY_IKJ_KIHON.AVGNISSU_ZENTAI_BED%TYPE,
    N_C_AVGNISSU_S_YMD             TT_TIKY_IKJ_KIHON.AVGNISSU_S_YMD%TYPE,
    N_C_AVGNISSU_E_YMD             TT_TIKY_IKJ_KIHON.AVGNISSU_E_YMD%TYPE,
    O_C_JOHO_YMD                   TT_Z_D_IKJ_KIHON.JOHO_YMD%TYPE,
    O_C_ANNAIYO_URL                TT_Z_D_IKJ_KIHON.ANNAIYO_URL%TYPE,
    O_C_INNAI_SHOHO_FLG            TT_Z_D_IKJ_KIHON.INNAI_SHOHO_FLG%TYPE,
    O_C_INGAI_SHOHO_FLG            TT_Z_D_IKJ_KIHON.INGAI_SHOHO_FLG%TYPE,
    O_C_CHIKENJISSHI_FLG           TT_Z_D_IKJ_KIHON.CHIKENJISSHI_FLG%TYPE,
    O_C_CHIKENJISSHI_KIYK_KENSU    TT_Z_D_IKJ_KIHON.CHIKENJISSHI_KIYK_KENSU%TYPE,
    O_C_CHIKENJISSHI_S_YMD         TT_Z_D_IKJ_KIHON.CHIKENJISSHI_S_YMD%TYPE,
    O_C_CHIKENJISSHI_E_YMD         TT_Z_D_IKJ_KIHON.CHIKENJISSHI_E_YMD%TYPE,
    O_C_STB_FLG                    TT_Z_D_IKJ_KIHON.STB_FLG%TYPE,
    O_C_SHIKKAN_CHRY_FLG           TT_Z_D_IKJ_KIHON.SHIKKAN_CHRY_FLG%TYPE,
    O_C_TNK_TIZI_SJT_FLG           TT_Z_D_IKJ_KIHON.TNK_TIZI_SJT_FLG%TYPE,
    O_C_SMG_FLG                    TT_Z_D_IKJ_KIHON.SMG_FLG%TYPE,
    O_C_CHIKRENKEI_MADOGUCHI_FLG   TT_Z_D_IKJ_KIHON.CHIKRENKEI_MADOGUCHI_FLG%TYPE,
    O_C_CHIKRENKEIPATH_FLG_IKJ     TT_Z_D_IKJ_KIHON.CHIKRENKEIPATH_FLG_IKJ%TYPE,
    O_C_NYUINSNRY_INNAI_R_FLG      TT_Z_D_IKJ_KIHON.NYUINSNRY_INNAI_RNKITISI_FLG%TYPE,
    O_C_ORDERINGSYSTEM_FLG         TT_Z_D_IKJ_KIHON.ORDERINGSYSTEM_FLG%TYPE,
    O_C_ORDERINGSYSTEM_KENSA_FLG   TT_Z_D_IKJ_KIHON.ORDERINGSYSTEM_KENSA_FLG%TYPE,
    O_C_ORDERINGSYSTEM_SHOHO_FLG   TT_Z_D_IKJ_KIHON.ORDERINGSYSTEM_SHOHO_FLG%TYPE,
    O_C_ORDERINGSYSTEM_YOYAKU_FLG  TT_Z_D_IKJ_KIHON.ORDERINGSYSTEM_YOYAKU_FLG%TYPE,
    O_C_ICD_CD_RIYO_FLG            TT_Z_D_IKJ_KIHON.ICD_CD_RIYO_FLG%TYPE,
    O_C_DENSHI_KARTE_FLG           TT_Z_D_IKJ_KIHON.DENSHI_KARTE_FLG%TYPE,
    O_C_KARTEKANRI_SENNIN_FLG      TT_Z_D_IKJ_KIHON.KARTEKANRI_SENNIN_FLG%TYPE,
    O_C_KARTEKANRI_SENNIN_SU       TT_Z_D_IKJ_KIHON.KARTEKANRI_SENNIN_SU%TYPE,
    O_C_KANJYASU_IPPAN_BED         TT_Z_D_IKJ_KIHON.KANJYASU_IPPAN_BED%TYPE,
    O_C_KANJYASU_RYOYO_BED         TT_Z_D_IKJ_KIHON.KANJYASU_RYOYO_BED%TYPE,
    O_C_KANJYASU_R_BED_IRY_HKN     TT_Z_D_IKJ_KIHON.KANJYASU_RYOYO_BED_IRY_HKN%TYPE,
    O_C_KANJYASU_R_BED_KIG_HKN     TT_Z_D_IKJ_KIHON.KANJYASU_RYOYO_BED_KIG_HKN%TYPE,
    O_C_KANJYASU_SEISHIN_BED       TT_Z_D_IKJ_KIHON.KANJYASU_SEISHIN_BED%TYPE,
    O_C_KANJYASU_KEKKAKU_BED       TT_Z_D_IKJ_KIHON.KANJYASU_KEKKAKU_BED%TYPE,
    O_C_KANJYASU_KANSEN            TT_Z_D_IKJ_KIHON.KANJYASU_KANSEN%TYPE,
    O_C_KANJYASU_ZENTAI_BED        TT_Z_D_IKJ_KIHON.KANJYASU_ZENTAI_BED%TYPE,
    O_C_KANJYASU_BED_SBT_S_YMD     TT_Z_D_IKJ_KIHON.KANJYASU_BED_SBT_S_YMD%TYPE,
    O_C_KANJYASU_BED_SBT_E_YMD     TT_Z_D_IKJ_KIHON.KANJYASU_BED_SBT_E_YMD%TYPE,
    O_C_KANJYASU_GAIRAI            TT_Z_D_IKJ_KIHON.KANJYASU_GAIRAI%TYPE,
    O_C_KANJYASU_GAIRAI_S_YMD      TT_Z_D_IKJ_KIHON.KANJYASU_GAIRAI_S_YMD%TYPE,
    O_C_KANJYASU_GAIRAI_E_YMD      TT_Z_D_IKJ_KIHON.KANJYASU_GAIRAI_E_YMD%TYPE,
    O_C_KANJYASU_ZAITAKU           TT_Z_D_IKJ_KIHON.KANJYASU_ZAITAKU%TYPE,
    O_C_KANJYASU_ZAITAKU_S_YMD     TT_Z_D_IKJ_KIHON.KANJYASU_ZAITAKU_S_YMD%TYPE,
    O_C_KANJYASU_ZAITAKU_E_YMD     TT_Z_D_IKJ_KIHON.KANJYASU_ZAITAKU_E_YMD%TYPE,
    O_C_KANJYANSU_IPPAN_BED        TT_Z_D_IKJ_KIHON.KANJYANSU_IPPAN_BED%TYPE,
    O_C_KANJYANSU_RYOYO_BED        TT_Z_D_IKJ_KIHON.KANJYANSU_RYOYO_BED%TYPE,
    O_C_KANJYANSU_R_BED_IRY_HKN    TT_Z_D_IKJ_KIHON.KANJYANSU_RYOYO_BED_IRY_HKN%TYPE,
    O_C_KANJYANSU_R_BED_KIG_HKN    TT_Z_D_IKJ_KIHON.KANJYANSU_RYOYO_BED_KIG_HKN%TYPE,
    O_C_KANJYANSU_SEISHIN_BED      TT_Z_D_IKJ_KIHON.KANJYANSU_SEISHIN_BED%TYPE,
    O_C_KANJYANSU_KEKKAKU_BED      TT_Z_D_IKJ_KIHON.KANJYANSU_KEKKAKU_BED%TYPE,
    O_C_KANJYANSU_KANSEN           TT_Z_D_IKJ_KIHON.KANJYANSU_KANSEN%TYPE,
    O_C_KANJYANSU_ZENTAI_BED       TT_Z_D_IKJ_KIHON.KANJYANSU_ZENTAI_BED%TYPE,
    O_C_KANJYANSU_BED_SBT_S_YMD    TT_Z_D_IKJ_KIHON.KANJYANSU_BED_SBT_S_YMD%TYPE,
    O_C_KANJYANSU_BED_SBT_E_YMD    TT_Z_D_IKJ_KIHON.KANJYANSU_BED_SBT_E_YMD%TYPE,
    O_C_KANJYANSU_GAIRAI           TT_Z_D_IKJ_KIHON.KANJYANSU_GAIRAI%TYPE,
    O_C_KANJYANSU_GAIRAI_S_YMD     TT_Z_D_IKJ_KIHON.KANJYANSU_GAIRAI_S_YMD%TYPE,
    O_C_KANJYANSU_GAIRAI_E_YMD     TT_Z_D_IKJ_KIHON.KANJYANSU_GAIRAI_E_YMD%TYPE,
    O_C_KANJYANSU_ZAITAKU          TT_Z_D_IKJ_KIHON.KANJYANSU_ZAITAKU%TYPE,
    O_C_KANJYANSU_ZAITAKU_S_YMD    TT_Z_D_IKJ_KIHON.KANJYANSU_ZAITAKU_S_YMD%TYPE,
    O_C_KANJYANSU_ZAITAKU_E_YMD    TT_Z_D_IKJ_KIHON.KANJYANSU_ZAITAKU_E_YMD%TYPE,
    O_C_AVGNISSU_IPPAN_BED         TT_Z_D_IKJ_KIHON.AVGNISSU_IPPAN_BED%TYPE,
    O_C_AVGNISSU_RYOYO_BED         TT_Z_D_IKJ_KIHON.AVGNISSU_RYOYO_BED%TYPE,
    O_C_AVGNISSU_R_BED_IRY_HKN     TT_Z_D_IKJ_KIHON.AVGNISSU_RYOYO_BED_IRY_HKN%TYPE,
    O_C_AVGNISSU_R_BED_KIG_HKN     TT_Z_D_IKJ_KIHON.AVGNISSU_RYOYO_BED_KIG_HKN%TYPE,
    O_C_AVGNISSU_SEISHIN_BED       TT_Z_D_IKJ_KIHON.AVGNISSU_SEISHIN_BED%TYPE,
    O_C_AVGNISSU_KEKKAKU_BED       TT_Z_D_IKJ_KIHON.AVGNISSU_KEKKAKU_BED%TYPE,
    O_C_AVGNISSU_KANSEN            TT_Z_D_IKJ_KIHON.AVGNISSU_KANSEN%TYPE,
    O_C_AVGNISSU_ZENTAI_BED        TT_Z_D_IKJ_KIHON.AVGNISSU_ZENTAI_BED%TYPE,
    O_C_AVGNISSU_S_YMD             TT_Z_D_IKJ_KIHON.AVGNISSU_S_YMD%TYPE,
    O_C_AVGNISSU_E_YMD             TT_Z_D_IKJ_KIHON.AVGNISSU_E_YMD%TYPE
    );

    /*
    ************************************************************************
    *  �����p�f�[�^�ޔ�
    *  CREATE_IKJ_KHN
    ************************************************************************
    */
    FUNCTION CREATE_IKJ_KHN(
    iSHIME_KBN          IN  VARCHAR2,     -- ���ߋ敪
    iSHIME_FROM         IN  VARCHAR2,     -- ���ߔ͈́iFrom�j
    iSHIME_TO           IN  VARCHAR2,     -- ���ߔ͈́iTo�j
    iTENSO_DATE         IN  VARCHAR2,     -- �]���N����
    iIP_ADDR            IN  TL_STORED_SHORI.IP%TYPE,   -- ���s�[��IP�A�h���X
    iWINDOWS_LOGIN_USER IN  TL_STORED_SHORI.WINDOWS_LOGIN_USER%TYPE, -- ���s�[��OS���[�U�[
    oROW_COUNT          OUT NUMBER,             -- �쐬����
    oOUT_ERR_INF_CSR    OUT ERR_INF_CSR,        -- �G���[���J�[�\��
    iOPE_CD             IN  VARCHAR2,     -- �I�y���[�^�R�[�h
    iPGM_ID             IN  VARCHAR2,     -- �v���O����ID
    iDATE               IN  DATE     -- �V�X�e������
    ) RETURN NUMBER;

END;
/

CREATE OR REPLACE PACKAGE BODY NH010107B001_132
/* **********************************************************
*  Copyright(c) 2011 beyond, INTEC Inc. All rights reserved.
* **********************************************************/
IS
    /*
    ************************************************************************
    * Function ID  : CREATE_IKJ_KHN
    * Program Name : �����p�f�[�^�ޔ�
    * Return       �F�������ʁi0:����I���A1:�ُ�I���j
    ************************************************************************
    */
    FUNCTION CREATE_IKJ_KHN(
    iSHIME_KBN          IN  VARCHAR2,     -- ���ߋ敪
    iSHIME_FROM         IN  VARCHAR2,     -- ���ߔ͈́iFrom�j
    iSHIME_TO           IN  VARCHAR2,     -- ���ߔ͈́iTo�j
    iTENSO_DATE         IN  VARCHAR2,     -- �]���N����
    iIP_ADDR            IN  TL_STORED_SHORI.IP%TYPE,   -- ���s�[��IP�A�h���X
    iWINDOWS_LOGIN_USER IN  TL_STORED_SHORI.WINDOWS_LOGIN_USER%TYPE, -- ���s�[��OS���[�U�[
    oROW_COUNT          OUT NUMBER,             -- �쐬����
    oOUT_ERR_INF_CSR    OUT ERR_INF_CSR,        -- �G���[���J�[�\��
    iOPE_CD             IN  VARCHAR2,     -- �I�y���[�^�R�[�h
    iPGM_ID             IN  VARCHAR2,     -- �v���O����ID
    iDATE               IN  DATE     -- �V�X�e������
    ) RETURN NUMBER IS

    PRAGMA AUTONOMOUS_TRANSACTION;

    /************************************************************************/
    /*                              �G���[����                              */
    /************************************************************************/
    W_INDEX_N         NUMBER(10) := 0;
    W_ERR_INF_TBL         TYPE_ERR_INFO_TBL := TYPE_ERR_INFO_TBL();
    W_ERR_INF_RCD         TYPE_ERR_INFO_RCD := TYPE_ERR_INFO_RCD(NULL,NULL,NULL,NULL);

    ikjInfCsr IKJ_INF_CSR;
    ikjInfRow IKJ_KHN_ROW;
    vSchemaNm     TM_JOSU.HANYO_KOMOKU%TYPE := NULL; -- �X�L�[�}����
    PGM_ID        VARCHAR2(50) := 'NH010107B001_132.CREATE_IKJ_KHN';
    EXECUTE_SQL   VARCHAR2(32767) := NULL;

    -- �e�[�u���敪�i�����߁FD�A�T���߁FW�j
    tableKbn VARCHAR2(1);
    -- �C���敪�i�ǉ��FA�A�C���FB�j
    modKbn VARCHAR2(1);
    -- �ǉ��폜�敪�i�폜�F1�A�ǉ��F2�j
    tsuikaDelKbn VARCHAR2(1);
    -- �W�����ڂ������l�ɂȂ�t���O�i�����̎��{�j
    groupFlgChiken BOOLEAN:=FALSE;
    groupFlgChiken2 VARCHAR2(1):='3';
    -- �W�����ڂ������l�ɂȂ�t���O�i�f�Ï��Ǘ��̐�_�I�[�_�����O�V�X�e���j
    groupFlgOrderingsystem BOOLEAN:=FALSE;
    groupFlgOrderingsystem2 VARCHAR2(1):='3';
    -- �W�����ڂ������l�ɂȂ�t���O�i�f�Ï��Ǘ��̐�_��C�]���ҁj
    groupFlgSennin BOOLEAN:=FALSE;
    groupFlgSennin2 VARCHAR2(1):='3';
    -- �W�����ڂ������l�ɂȂ�t���O�i���Ґ�����_�a����ʁj
    groupFlgKanjyasuBedSbt BOOLEAN:=FALSE;
    groupFlgKanjyasuBedSbt2 VARCHAR2(1):='3';
    -- �W�����ڂ������l�ɂȂ�t���O�i���Ґ�����_�O���j
    groupFlgKanjyasuGairai BOOLEAN:=FALSE;
    groupFlgKanjyasuGairai2 VARCHAR2(1):='3';
    -- �W�����ڂ������l�ɂȂ�t���O�i���Ґ�����_�ݑ�j
    groupFlgKanjyasuZaitaku BOOLEAN:=FALSE;
    groupFlgKanjyasuZaitaku2 VARCHAR2(1):='3';
    -- �W�����ڂ������l�ɂȂ�t���O�i���Ґ�����_�a����ʁj
    groupFlgKanjyansuBedSbt BOOLEAN:=FALSE;
    groupFlgKanjyansuBedSbt2 VARCHAR2(1):='3';
    -- �W�����ڂ������l�ɂȂ�t���O�i���Ґ�����_�O���j
    groupFlgKanjyansuGairai BOOLEAN:=FALSE;
    groupFlgKanjyansuGairai2 VARCHAR2(1):='3';
    -- �W�����ڂ������l�ɂȂ�t���O�i���Ґ�����_�ݑ�j
    groupFlgKanjyansuZaitaku BOOLEAN:=FALSE;
    groupFlgKanjyansuZaitaku2 VARCHAR2(1):='3';
    -- �W�����ڂ������l�ɂȂ�t���O�i���ύ݉@�����j
    groupFlgAvgnissu BOOLEAN:=FALSE;
    groupFlgAvgnissu2 VARCHAR2(1):='3';

BEGIN

    -- �J�n���O�o��
    ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'PL/SQL Start',PGM_ID || '�̏������J�n���܂��B',iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

    -- �X�V�����̏�����
    oROW_COUNT := 0;

    -- �[�i�p�X�L�[�}�̎擾���s���B
    vSchemaNm := ULT_COMMON.GET_SCHEMA_NAME(ULT_COMMON.SYS_ENV_JOSU_DAI_CD, ULT_COMMON.NOHIN_SHEMA_JOSU_SHO_CD);

    IF iSHIME_KBN = ULT_COMMON.SHIME_SBT_CD_HISHIME THEN
        tableKbn := 'D';
    ELSIF iSHIME_KBN = ULT_COMMON.SHIME_SBT_CD_SHUSHIME THEN
        tableKbn := 'W';
    END IF;       

    --  �V_������_��Ë@�\���_��{�e�[�u��/�V_�T����_��Ë@�\���_��{�e�[�u�����폜����
    EXECUTE_SQL := 'TRUNCATE TABLE ' || vSchemaNm || '.TD_N' || tableKbn || '_IKJ_KHN';
    ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);
    EXECUTE IMMEDIATE EXECUTE_SQL;

    EXECUTE_SQL := 'SELECT NEW_PARENT.SHI_CD AS N_P_SHI_CD,' ||
    '       NEW_PARENT.DEL_FLG AS N_P_DEL_FLG,' ||
    '       OLD_PARENT.SHI_CD AS O_P_SHI_CD,' ||
    '       OLD_PARENT.DEL_FLG AS O_P_DEL_FLG,' ||
    '       NEW_CHILD.SHI_CD AS N_C_SHI_CD,' ||
    '       NEW_CHILD.DEL_FLG AS N_C_DEL_FLG,' ||
    '       OLD_CHILD.SHI_CD AS O_C_SHI_CD,' ||
    '       OLD_CHILD.DEL_FLG AS O_C_DEL_FLG,' ||
    '       NEW_CHILD.UPD_EIGY_YMD AS N_C_UPD_EIGY_YMD,' ||
    '       NEW_CHILD.JOHO_YMD AS N_C_JOHO_YMD,' ||
    '       NEW_CHILD.ANNAIYO_URL AS N_C_ANNAIYO_URL,' ||
    '       NEW_CHILD.INNAI_SHOHO_FLG AS N_C_INNAI_SHOHO_FLG,' ||
    '       NEW_CHILD.INGAI_SHOHO_FLG AS N_C_INGAI_SHOHO_FLG,' ||
    '       NEW_CHILD.CHIKENJISSHI_FLG AS N_C_CHIKENJISSHI_FLG,' ||
    '       NEW_CHILD.CHIKENJISSHI_KIYK_KENSU AS N_C_CHIKENJISSHI_KIYK_KENSU,' ||
    '       NEW_CHILD.CHIKENJISSHI_S_YMD AS N_C_CHIKENJISSHI_S_YMD,' ||
    '       NEW_CHILD.CHIKENJISSHI_E_YMD AS N_C_CHIKENJISSHI_E_YMD,' ||
    '       NEW_CHILD.STB_FLG AS N_C_STB_FLG,' ||
    '       NEW_CHILD.SHIKKAN_CHRY_FLG AS N_C_SHIKKAN_CHRY_FLG,' ||
    '       NEW_CHILD.TNK_TIZI_SJT_FLG AS N_C_TNK_TIZI_SJT_FLG,' ||
    '       NEW_CHILD.SMG_FLG AS N_C_SMG_FLG,' ||
    '       NEW_CHILD.CHIKRENKEI_MADOGUCHI_FLG AS N_C_CHIKRENKEI_MADOGUCHI_FLG,' ||
    '       NEW_CHILD.CHIKRENKEIPATH_FLG_IKJ AS N_C_CHIKRENKEIPATH_FLG_IKJ,' ||
    '       NEW_CHILD.NYUINSNRY_INNAI_RNKITISI_FLG AS N_C_NYUINSNRY_INNAI_R_FLG,' ||
    '       NEW_CHILD.ORDERINGSYSTEM_FLG AS N_C_ORDERINGSYSTEM_FLG,' ||
    '       NEW_CHILD.ORDERINGSYSTEM_KENSA_FLG AS N_C_ORDERINGSYSTEM_KENSA_FLG,' ||
    '       NEW_CHILD.ORDERINGSYSTEM_SHOHO_FLG AS N_C_ORDERINGSYSTEM_SHOHO_FLG,' ||
    '       NEW_CHILD.ORDERINGSYSTEM_YOYAKU_FLG AS N_C_ORDERINGSYSTEM_YOYAKU_FLG,' ||
    '       NEW_CHILD.ICD_CD_RIYO_FLG AS N_C_ICD_CD_RIYO_FLG,' ||
    '       NEW_CHILD.DENSHI_KARTE_FLG AS N_C_DENSHI_KARTE_FLG,' ||
    '       NEW_CHILD.KARTEKANRI_SENNIN_FLG AS N_C_KARTEKANRI_SENNIN_FLG,' ||
    '       NEW_CHILD.KARTEKANRI_SENNIN_SU AS N_C_KARTEKANRI_SENNIN_SU,' ||
    '       NEW_CHILD.KANJYASU_IPPAN_BED AS N_C_KANJYASU_IPPAN_BED,' ||
    '       NEW_CHILD.KANJYASU_RYOYO_BED AS N_C_KANJYASU_RYOYO_BED,' ||
    '       NEW_CHILD.KANJYASU_RYOYO_BED_IRY_HKN AS N_C_KANJYASU_R_BED_IRY_HKN,' ||
    '       NEW_CHILD.KANJYASU_RYOYO_BED_KIG_HKN AS N_C_KANJYASU_R_BED_KIG_HKN,' ||
    '       NEW_CHILD.KANJYASU_SEISHIN_BED AS N_C_KANJYASU_SEISHIN_BED,' ||
    '       NEW_CHILD.KANJYASU_KEKKAKU_BED AS N_C_KANJYASU_KEKKAKU_BED,' ||
    '       NEW_CHILD.KANJYASU_KANSEN AS N_C_KANJYASU_KANSEN,' ||
    '       NEW_CHILD.KANJYASU_ZENTAI_BED AS N_C_KANJYASU_ZENTAI_BED,' ||
    '       NEW_CHILD.KANJYASU_BED_SBT_S_YMD AS N_C_KANJYASU_BED_SBT_S_YMD,' ||
    '       NEW_CHILD.KANJYASU_BED_SBT_E_YMD AS N_C_KANJYASU_BED_SBT_E_YMD,' ||
    '       NEW_CHILD.KANJYASU_GAIRAI AS N_C_KANJYASU_GAIRAI,' ||
    '       NEW_CHILD.KANJYASU_GAIRAI_S_YMD AS N_C_KANJYASU_GAIRAI_S_YMD,' ||
    '       NEW_CHILD.KANJYASU_GAIRAI_E_YMD AS N_C_KANJYASU_GAIRAI_E_YMD,' ||
    '       NEW_CHILD.KANJYASU_ZAITAKU AS N_C_KANJYASU_ZAITAKU,' ||
    '       NEW_CHILD.KANJYASU_ZAITAKU_S_YMD AS N_C_KANJYASU_ZAITAKU_S_YMD,' ||
    '       NEW_CHILD.KANJYASU_ZAITAKU_E_YMD AS N_C_KANJYASU_ZAITAKU_E_YMD,' ||
    '       NEW_CHILD.KANJYANSU_IPPAN_BED AS N_C_KANJYANSU_IPPAN_BED,' ||
    '       NEW_CHILD.KANJYANSU_RYOYO_BED AS N_C_KANJYANSU_RYOYO_BED,' ||
    '       NEW_CHILD.KANJYANSU_RYOYO_BED_IRY_HKN AS N_C_KANJYANSU_R_BED_IRY_HKN,' ||
    '       NEW_CHILD.KANJYANSU_RYOYO_BED_KIG_HKN AS N_C_KANJYANSU_R_BED_KIG_HKN,' ||
    '       NEW_CHILD.KANJYANSU_SEISHIN_BED AS N_C_KANJYANSU_SEISHIN_BED,' ||
    '       NEW_CHILD.KANJYANSU_KEKKAKU_BED AS N_C_KANJYANSU_KEKKAKU_BED,' ||
    '       NEW_CHILD.KANJYANSU_KANSEN AS N_C_KANJYANSU_KANSEN,' ||
    '       NEW_CHILD.KANJYANSU_ZENTAI_BED AS N_C_KANJYANSU_ZENTAI_BED,' ||
    '       NEW_CHILD.KANJYANSU_BED_SBT_S_YMD AS N_C_KANJYANSU_BED_SBT_S_YMD,' ||
    '       NEW_CHILD.KANJYANSU_BED_SBT_E_YMD AS N_C_KANJYANSU_BED_SBT_E_YMD,' ||
    '       NEW_CHILD.KANJYANSU_GAIRAI AS N_C_KANJYANSU_GAIRAI,' ||
    '       NEW_CHILD.KANJYANSU_GAIRAI_S_YMD AS N_C_KANJYANSU_GAIRAI_S_YMD,' ||
    '       NEW_CHILD.KANJYANSU_GAIRAI_E_YMD AS N_C_KANJYANSU_GAIRAI_E_YMD,' ||
    '       NEW_CHILD.KANJYANSU_ZAITAKU AS N_C_KANJYANSU_ZAITAKU,' ||
    '       NEW_CHILD.KANJYANSU_ZAITAKU_S_YMD AS N_C_KANJYANSU_ZAITAKU_S_YMD,' ||
    '       NEW_CHILD.KANJYANSU_ZAITAKU_E_YMD AS N_C_KANJYANSU_ZAITAKU_E_YMD,' ||
    '       NEW_CHILD.AVGNISSU_IPPAN_BED AS N_C_AVGNISSU_IPPAN_BED,' ||
    '       NEW_CHILD.AVGNISSU_RYOYO_BED AS N_C_AVGNISSU_RYOYO_BED,' ||
    '       NEW_CHILD.AVGNISSU_RYOYO_BED_IRY_HKN AS N_C_AVGNISSU_R_BED_IRY_HKN,' ||
    '       NEW_CHILD.AVGNISSU_RYOYO_BED_KIG_HKN AS N_C_AVGNISSU_R_BED_KIG_HKN,' ||
    '       NEW_CHILD.AVGNISSU_SEISHIN_BED AS N_C_AVGNISSU_SEISHIN_BED,' ||
    '       NEW_CHILD.AVGNISSU_KEKKAKU_BED AS N_C_AVGNISSU_KEKKAKU_BED,' ||
    '       NEW_CHILD.AVGNISSU_KANSEN AS N_C_AVGNISSU_KANSEN,' ||
    '       NEW_CHILD.AVGNISSU_ZENTAI_BED AS N_C_AVGNISSU_ZENTAI_BED,' ||
    '       NEW_CHILD.AVGNISSU_S_YMD AS N_C_AVGNISSU_S_YMD,' ||
    '       NEW_CHILD.AVGNISSU_E_YMD AS N_C_AVGNISSU_E_YMD,' ||
    '       OLD_CHILD.JOHO_YMD AS O_C_JOHO_YMD,' ||
    '       OLD_CHILD.ANNAIYO_URL AS O_C_ANNAIYO_URL,' ||
    '       OLD_CHILD.INNAI_SHOHO_FLG AS O_C_INNAI_SHOHO_FLG,' ||
    '       OLD_CHILD.INGAI_SHOHO_FLG AS O_C_INGAI_SHOHO_FLG,' ||
    '       OLD_CHILD.CHIKENJISSHI_FLG AS O_C_CHIKENJISSHI_FLG,' ||
    '       OLD_CHILD.CHIKENJISSHI_KIYK_KENSU AS O_C_CHIKENJISSHI_KIYK_KENSU,' ||
    '       OLD_CHILD.CHIKENJISSHI_S_YMD AS O_C_CHIKENJISSHI_S_YMD,' ||
    '       OLD_CHILD.CHIKENJISSHI_E_YMD AS O_C_CHIKENJISSHI_E_YMD,' ||
    '       OLD_CHILD.STB_FLG AS O_C_STB_FLG,' ||
    '       OLD_CHILD.SHIKKAN_CHRY_FLG AS O_C_SHIKKAN_CHRY_FLG,' ||
    '       OLD_CHILD.TNK_TIZI_SJT_FLG AS O_C_TNK_TIZI_SJT_FLG,' ||
    '       OLD_CHILD.SMG_FLG AS O_C_SMG_FLG,' ||
    '       OLD_CHILD.CHIKRENKEI_MADOGUCHI_FLG AS O_C_CHIKRENKEI_MADOGUCHI_FLG,' ||
    '       OLD_CHILD.CHIKRENKEIPATH_FLG_IKJ AS O_C_CHIKRENKEIPATH_FLG_IKJ,' ||
    '       OLD_CHILD.NYUINSNRY_INNAI_RNKITISI_FLG AS O_C_NYUINSNRY_INNAI_R_FLG,' ||
    '       OLD_CHILD.ORDERINGSYSTEM_FLG AS O_C_ORDERINGSYSTEM_FLG,' ||
    '       OLD_CHILD.ORDERINGSYSTEM_KENSA_FLG AS O_C_ORDERINGSYSTEM_KENSA_FLG,' ||
    '       OLD_CHILD.ORDERINGSYSTEM_SHOHO_FLG AS O_C_ORDERINGSYSTEM_SHOHO_FLG,' ||
    '       OLD_CHILD.ORDERINGSYSTEM_YOYAKU_FLG AS O_C_ORDERINGSYSTEM_YOYAKU_FLG,' ||
    '       OLD_CHILD.ICD_CD_RIYO_FLG AS O_C_ICD_CD_RIYO_FLG,' ||
    '       OLD_CHILD.DENSHI_KARTE_FLG AS O_C_DENSHI_KARTE_FLG,' ||
    '       OLD_CHILD.KARTEKANRI_SENNIN_FLG AS O_C_KARTEKANRI_SENNIN_FLG,' ||
    '       OLD_CHILD.KARTEKANRI_SENNIN_SU AS O_C_KARTEKANRI_SENNIN_SU,' ||
    '       OLD_CHILD.KANJYASU_IPPAN_BED AS O_C_KANJYASU_IPPAN_BED,' ||
    '       OLD_CHILD.KANJYASU_RYOYO_BED AS O_C_KANJYASU_RYOYO_BED,' ||
    '       OLD_CHILD.KANJYASU_RYOYO_BED_IRY_HKN AS O_C_KANJYASU_R_BED_IRY_HKN,' ||
    '       OLD_CHILD.KANJYASU_RYOYO_BED_KIG_HKN AS O_C_KANJYASU_R_BED_KIG_HKN,' ||
    '       OLD_CHILD.KANJYASU_SEISHIN_BED AS O_C_KANJYASU_SEISHIN_BED,' ||
    '       OLD_CHILD.KANJYASU_KEKKAKU_BED AS O_C_KANJYASU_KEKKAKU_BED,' ||
    '       OLD_CHILD.KANJYASU_KANSEN AS O_C_KANJYASU_KANSEN,' ||
    '       OLD_CHILD.KANJYASU_ZENTAI_BED AS O_C_KANJYASU_ZENTAI_BED,' ||
    '       OLD_CHILD.KANJYASU_BED_SBT_S_YMD AS O_C_KANJYASU_BED_SBT_S_YMD,' ||
    '       OLD_CHILD.KANJYASU_BED_SBT_E_YMD AS O_C_KANJYASU_BED_SBT_E_YMD,' ||
    '       OLD_CHILD.KANJYASU_GAIRAI AS O_C_KANJYASU_GAIRAI,' ||
    '       OLD_CHILD.KANJYASU_GAIRAI_S_YMD AS O_C_KANJYASU_GAIRAI_S_YMD,' ||
    '       OLD_CHILD.KANJYASU_GAIRAI_E_YMD AS O_C_KANJYASU_GAIRAI_E_YMD,' ||
    '       OLD_CHILD.KANJYASU_ZAITAKU AS O_C_KANJYASU_ZAITAKU,' ||
    '       OLD_CHILD.KANJYASU_ZAITAKU_S_YMD AS O_C_KANJYASU_ZAITAKU_S_YMD,' ||
    '       OLD_CHILD.KANJYASU_ZAITAKU_E_YMD AS O_C_KANJYASU_ZAITAKU_E_YMD,' ||
    '       OLD_CHILD.KANJYANSU_IPPAN_BED AS O_C_KANJYANSU_IPPAN_BED,' ||
    '       OLD_CHILD.KANJYANSU_RYOYO_BED AS O_C_KANJYANSU_RYOYO_BED,' ||
    '       OLD_CHILD.KANJYANSU_RYOYO_BED_IRY_HKN AS O_C_KANJYANSU_R_BED_IRY_HKN,' ||
    '       OLD_CHILD.KANJYANSU_RYOYO_BED_KIG_HKN AS O_C_KANJYANSU_R_BED_KIG_HKN,' ||
    '       OLD_CHILD.KANJYANSU_SEISHIN_BED AS O_C_KANJYANSU_SEISHIN_BED,' ||
    '       OLD_CHILD.KANJYANSU_KEKKAKU_BED AS O_C_KANJYANSU_KEKKAKU_BED,' ||
    '       OLD_CHILD.KANJYANSU_KANSEN AS O_C_KANJYANSU_KANSEN,' ||
    '       OLD_CHILD.KANJYANSU_ZENTAI_BED AS O_C_KANJYANSU_ZENTAI_BED,' ||
    '       OLD_CHILD.KANJYANSU_BED_SBT_S_YMD AS O_C_KANJYANSU_BED_SBT_S_YMD,' ||
    '       OLD_CHILD.KANJYANSU_BED_SBT_E_YMD AS O_C_KANJYANSU_BED_SBT_E_YMD,' ||
    '       OLD_CHILD.KANJYANSU_GAIRAI AS O_C_KANJYANSU_GAIRAI,' ||
    '       OLD_CHILD.KANJYANSU_GAIRAI_S_YMD AS O_C_KANJYANSU_GAIRAI_S_YMD,' ||
    '       OLD_CHILD.KANJYANSU_GAIRAI_E_YMD AS O_C_KANJYANSU_GAIRAI_E_YMD,' ||
    '       OLD_CHILD.KANJYANSU_ZAITAKU AS O_C_KANJYANSU_ZAITAKU,' ||
    '       OLD_CHILD.KANJYANSU_ZAITAKU_S_YMD AS O_C_KANJYANSU_ZAITAKU_S_YMD,' ||
    '       OLD_CHILD.KANJYANSU_ZAITAKU_E_YMD AS O_C_KANJYANSU_ZAITAKU_E_YMD,' ||
    '       OLD_CHILD.AVGNISSU_IPPAN_BED AS O_C_AVGNISSU_IPPAN_BED,' ||
    '       OLD_CHILD.AVGNISSU_RYOYO_BED AS O_C_AVGNISSU_RYOYO_BED,' ||
    '       OLD_CHILD.AVGNISSU_RYOYO_BED_IRY_HKN AS O_C_AVGNISSU_R_BED_IRY_HKN,' ||
    '       OLD_CHILD.AVGNISSU_RYOYO_BED_KIG_HKN AS O_C_AVGNISSU_R_BED_KIG_HKN,' ||
    '       OLD_CHILD.AVGNISSU_SEISHIN_BED AS O_C_AVGNISSU_SEISHIN_BED,' ||
    '       OLD_CHILD.AVGNISSU_KEKKAKU_BED AS O_C_AVGNISSU_KEKKAKU_BED,' ||
    '       OLD_CHILD.AVGNISSU_KANSEN AS O_C_AVGNISSU_KANSEN,' ||
    '       OLD_CHILD.AVGNISSU_ZENTAI_BED AS O_C_AVGNISSU_ZENTAI_BED,' ||
    '       OLD_CHILD.AVGNISSU_S_YMD AS O_C_AVGNISSU_S_YMD,' ||
    '       OLD_CHILD.AVGNISSU_E_YMD AS O_C_AVGNISSU_E_YMD' ||
    '  FROM TT_TIKY_IKJ_KIHON NEW_CHILD' ||
    '  LEFT OUTER' ||
    '  JOIN TT_Z_' || tableKbn || '_IKJ_KIHON OLD_CHILD ON NEW_CHILD.SHI_CD = OLD_CHILD.SHI_CD' ||
    ' INNER JOIN TT_TIKY_SHI NEW_PARENT ON NEW_CHILD.SHI_CD = NEW_PARENT.SHI_CD' ||
    '   AND NEW_PARENT.REC_ID = ''00''' ||
    '  LEFT OUTER JOIN TT_Z_' || tableKbn || '_SHI OLD_PARENT ON NEW_CHILD.SHI_CD = OLD_PARENT.SHI_CD' ||
    '   AND OLD_PARENT.REC_ID = ''00''' ||
    ' WHERE NEW_CHILD.UPD_EIGY_YMD >= NVL(' || iSHIME_FROM || ', ''' || ULT_COMMON.ORIGINAL_YMD || ''')' ||
    '       AND NEW_CHILD.UPD_EIGY_YMD <= ' || iSHIME_TO ||
    '       AND NEW_PARENT.DEL_FLG IS NULL' ||
    ' ORDER BY NEW_CHILD.SHI_CD ';
    ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',SUBSTR(EXECUTE_SQL, 0, 2000),iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

    -- �擾���������f�ރf�[�^�f�[�^���������J��Ԃ�
    OPEN ikjInfCsr FOR EXECUTE_SQL;

    LOOP
        FETCH ikjInfCsr INTO ikjInfRow;
        EXIT WHEN ikjInfCsr%NOTFOUND;

	    -- �W�����ڂ������l�ɂȂ�t���O�i�����̎��{�j
	    groupFlgChiken :=FALSE;
	    groupFlgChiken2 :='3';
	    -- �W�����ڂ������l�ɂȂ�t���O�i�f�Ï��Ǘ��̐�_�I�[�_�����O�V�X�e���j
	    groupFlgOrderingsystem :=FALSE;
	    groupFlgOrderingsystem2 :='3';
	    -- �W�����ڂ������l�ɂȂ�t���O�i�f�Ï��Ǘ��̐�_��C�]���ҁj
	    groupFlgSennin :=FALSE;
	    groupFlgSennin2 :='3';
	    -- �W�����ڂ������l�ɂȂ�t���O�i���Ґ�����_�a����ʁj
	    groupFlgKanjyasuBedSbt :=FALSE;
	    groupFlgKanjyasuBedSbt2 :='3';
	    -- �W�����ڂ������l�ɂȂ�t���O�i���Ґ�����_�O���j
	    groupFlgKanjyasuGairai :=FALSE;
	    groupFlgKanjyasuGairai2 :='3';
	    -- �W�����ڂ������l�ɂȂ�t���O�i���Ґ�����_�ݑ�j
	    groupFlgKanjyasuZaitaku :=FALSE;
	    groupFlgKanjyasuZaitaku2 :='3';
	    -- �W�����ڂ������l�ɂȂ�t���O�i���Ґ�����_�a����ʁj
	    groupFlgKanjyansuBedSbt :=FALSE;
	    groupFlgKanjyansuBedSbt2 :='3';
	    -- �W�����ڂ������l�ɂȂ�t���O�i���Ґ�����_�O���j
	    groupFlgKanjyansuGairai :=FALSE;
	    groupFlgKanjyansuGairai2 :='3';
	    -- �W�����ڂ������l�ɂȂ�t���O�i���Ґ�����_�ݑ�j
	    groupFlgKanjyansuZaitaku :=FALSE;
	    groupFlgKanjyansuZaitaku2 :='3';
	    -- �W�����ڂ������l�ɂȂ�t���O�i���ύ݉@�����j
	    groupFlgAvgnissu :=FALSE;
	    groupFlgAvgnissu2 :='3';

        -- �擾�����O�������Ë@�\����{�e�[�u��.�{�݃R�[�h��NULL�̏ꍇ
        IF ikjInfRow.O_C_SHI_CD IS NULL THEN
            -- �擾�����񋟗p��Ë@�\����{�e�[�u��.�폜�t���O��"1"�̏ꍇ
            IF ikjInfRow.N_C_DEL_FLG IS NOT NULL THEN
                tsuikaDelKbn := '';
                modKbn := ULT_COMMON.MOD_KBN_NO;
                -- �擾�����O������{�݃e�[�u��.�{�݃R�[�h��NULL�̏ꍇ
            ELSIF ikjInfRow.O_P_SHI_CD IS NULL THEN
                tsuikaDelKbn := ULT_COMMON.TSUIKA_DEL_KBN_ADD;
                modKbn := ULT_COMMON.MOD_KBN_ADD;
                -- ��L�ȊO�̏ꍇ
            ELSE
                tsuikaDelKbn := ULT_COMMON.TSUIKA_DEL_KBN_ADD;
                modKbn := ULT_COMMON.MOD_KBN_YES;
            END IF;                             
            -- �擾�����O�������Ë@�\����{�e�[�u��.�폜�t���O��NULL�A���A
            -- �擾�����񋟗p��Ë@�\����{�e�[�u��.�폜�t���O��"1"�̏ꍇ
        ELSIF ikjInfRow.O_C_DEL_FLG IS NULL AND ikjInfRow.N_C_DEL_FLG IS NOT NULL THEN
            tsuikaDelKbn := ULT_COMMON.TSUIKA_DEL_KBN_DEL;
            modKbn := ULT_COMMON.MOD_KBN_YES;
            -- �擾�����O�������Ë@�\����{�e�[�u��.�폜�t���O��"1"�A���A
            -- �񋟗p��Ë@�\����{�e�[�u��.�폜�t���O��NULL�̏ꍇ
        ELSIF ikjInfRow.O_C_DEL_FLG IS NOT NULL AND ikjInfRow.N_C_DEL_FLG IS NULL THEN
            tsuikaDelKbn := ULT_COMMON.TSUIKA_DEL_KBN_ADD;
            modKbn := ULT_COMMON.MOD_KBN_YES;
            -- �擾�����O�������Ë@�\����{�e�[�u��.�폜�t���O��"1"�A���A
            -- �񋟗p��Ë@�\����{�e�[�u��.�폜�t���O��"1"�̏ꍇ
        ELSIF ikjInfRow.O_C_DEL_FLG IS NOT NULL AND ikjInfRow.N_C_DEL_FLG IS NOT NULL THEN
            tsuikaDelKbn := '';
            modKbn := ULT_COMMON.MOD_KBN_NO;
            -- �擾�����񋟗p��Ë@�\����{�e�[�u���̃f�[�^��
            -- �擾�����O�������Ë@�\����{�e�[�u���̃f�[�^�́A
            -- �������̂̃A�C�e�����r���Ă����ꂩ���s��v�� 
        ELSIF ikjInfRow.N_C_JOHO_YMD || ',' || 
        ikjInfRow.N_C_ANNAIYO_URL || ',' || 
        ikjInfRow.N_C_INNAI_SHOHO_FLG || ',' || 
        ikjInfRow.N_C_INGAI_SHOHO_FLG || ',' || 
        ikjInfRow.N_C_CHIKENJISSHI_FLG || ',' || 
        ikjInfRow.N_C_CHIKENJISSHI_KIYK_KENSU || ',' || 
        ikjInfRow.N_C_CHIKENJISSHI_S_YMD || ',' || 
        ikjInfRow.N_C_CHIKENJISSHI_E_YMD || ',' || 
        ikjInfRow.N_C_STB_FLG || ',' || 
        ikjInfRow.N_C_SHIKKAN_CHRY_FLG || ',' || 
        ikjInfRow.N_C_TNK_TIZI_SJT_FLG || ',' || 
        ikjInfRow.N_C_SMG_FLG || ',' || 
        ikjInfRow.N_C_CHIKRENKEI_MADOGUCHI_FLG || ',' || 
        ikjInfRow.N_C_CHIKRENKEIPATH_FLG_IKJ || ',' || 
        ikjInfRow.N_C_NYUINSNRY_INNAI_R_FLG || ',' || 
        ikjInfRow.N_C_ORDERINGSYSTEM_FLG || ',' || 
        ikjInfRow.N_C_ORDERINGSYSTEM_KENSA_FLG || ',' || 
        ikjInfRow.N_C_ORDERINGSYSTEM_SHOHO_FLG || ',' || 
        ikjInfRow.N_C_ORDERINGSYSTEM_YOYAKU_FLG || ',' || 
        ikjInfRow.N_C_ICD_CD_RIYO_FLG || ',' || 
        ikjInfRow.N_C_DENSHI_KARTE_FLG || ',' || 
        ikjInfRow.N_C_KARTEKANRI_SENNIN_FLG || ',' || 
        ikjInfRow.N_C_KARTEKANRI_SENNIN_SU || ',' || 
        ikjInfRow.N_C_KANJYASU_IPPAN_BED || ',' || 
        ikjInfRow.N_C_KANJYASU_RYOYO_BED || ',' || 
        ikjInfRow.N_C_KANJYASU_R_BED_IRY_HKN || ',' || 
        ikjInfRow.N_C_KANJYASU_R_BED_KIG_HKN || ',' || 
        ikjInfRow.N_C_KANJYASU_SEISHIN_BED || ',' || 
        ikjInfRow.N_C_KANJYASU_KEKKAKU_BED || ',' || 
        ikjInfRow.N_C_KANJYASU_KANSEN || ',' || 
        ikjInfRow.N_C_KANJYASU_ZENTAI_BED || ',' || 
        ikjInfRow.N_C_KANJYASU_BED_SBT_S_YMD || ',' || 
        ikjInfRow.N_C_KANJYASU_BED_SBT_E_YMD || ',' || 
        ikjInfRow.N_C_KANJYASU_GAIRAI || ',' || 
        ikjInfRow.N_C_KANJYASU_GAIRAI_S_YMD || ',' || 
        ikjInfRow.N_C_KANJYASU_GAIRAI_E_YMD || ',' || 
        ikjInfRow.N_C_KANJYASU_ZAITAKU || ',' || 
        ikjInfRow.N_C_KANJYASU_ZAITAKU_S_YMD || ',' || 
        ikjInfRow.N_C_KANJYASU_ZAITAKU_E_YMD || ',' || 
        ikjInfRow.N_C_KANJYANSU_IPPAN_BED || ',' || 
        ikjInfRow.N_C_KANJYANSU_RYOYO_BED || ',' || 
        ikjInfRow.N_C_KANJYANSU_R_BED_IRY_HKN || ',' || 
        ikjInfRow.N_C_KANJYANSU_R_BED_KIG_HKN || ',' || 
        ikjInfRow.N_C_KANJYANSU_SEISHIN_BED || ',' || 
        ikjInfRow.N_C_KANJYANSU_KEKKAKU_BED || ',' || 
        ikjInfRow.N_C_KANJYANSU_KANSEN || ',' || 
        ikjInfRow.N_C_KANJYANSU_ZENTAI_BED || ',' || 
        ikjInfRow.N_C_KANJYANSU_BED_SBT_S_YMD || ',' || 
        ikjInfRow.N_C_KANJYANSU_BED_SBT_E_YMD || ',' || 
        ikjInfRow.N_C_KANJYANSU_GAIRAI || ',' || 
        ikjInfRow.N_C_KANJYANSU_GAIRAI_S_YMD || ',' || 
        ikjInfRow.N_C_KANJYANSU_GAIRAI_E_YMD || ',' || 
        ikjInfRow.N_C_KANJYANSU_ZAITAKU || ',' || 
        ikjInfRow.N_C_KANJYANSU_ZAITAKU_S_YMD || ',' || 
        ikjInfRow.N_C_KANJYANSU_ZAITAKU_E_YMD || ',' || 
        ikjInfRow.N_C_AVGNISSU_IPPAN_BED || ',' || 
        ikjInfRow.N_C_AVGNISSU_RYOYO_BED || ',' || 
        ikjInfRow.N_C_AVGNISSU_R_BED_IRY_HKN || ',' || 
        ikjInfRow.N_C_AVGNISSU_R_BED_KIG_HKN || ',' || 
        ikjInfRow.N_C_AVGNISSU_SEISHIN_BED || ',' || 
        ikjInfRow.N_C_AVGNISSU_KEKKAKU_BED || ',' || 
        ikjInfRow.N_C_AVGNISSU_KANSEN || ',' || 
        ikjInfRow.N_C_AVGNISSU_ZENTAI_BED || ',' || 
        ikjInfRow.N_C_AVGNISSU_S_YMD || ',' || 
        ikjInfRow.N_C_AVGNISSU_E_YMD 
        !=
        ikjInfRow.O_C_JOHO_YMD || ',' || 
        ikjInfRow.O_C_ANNAIYO_URL || ',' || 
        ikjInfRow.O_C_INNAI_SHOHO_FLG || ',' || 
        ikjInfRow.O_C_INGAI_SHOHO_FLG || ',' || 
        ikjInfRow.O_C_CHIKENJISSHI_FLG || ',' || 
        ikjInfRow.O_C_CHIKENJISSHI_KIYK_KENSU || ',' || 
        ikjInfRow.O_C_CHIKENJISSHI_S_YMD || ',' || 
        ikjInfRow.O_C_CHIKENJISSHI_E_YMD || ',' || 
        ikjInfRow.O_C_STB_FLG || ',' || 
        ikjInfRow.O_C_SHIKKAN_CHRY_FLG || ',' || 
        ikjInfRow.O_C_TNK_TIZI_SJT_FLG || ',' || 
        ikjInfRow.O_C_SMG_FLG || ',' || 
        ikjInfRow.O_C_CHIKRENKEI_MADOGUCHI_FLG || ',' || 
        ikjInfRow.O_C_CHIKRENKEIPATH_FLG_IKJ || ',' || 
        ikjInfRow.O_C_NYUINSNRY_INNAI_R_FLG || ',' || 
        ikjInfRow.O_C_ORDERINGSYSTEM_FLG || ',' || 
        ikjInfRow.O_C_ORDERINGSYSTEM_KENSA_FLG || ',' || 
        ikjInfRow.O_C_ORDERINGSYSTEM_SHOHO_FLG || ',' || 
        ikjInfRow.O_C_ORDERINGSYSTEM_YOYAKU_FLG || ',' || 
        ikjInfRow.O_C_ICD_CD_RIYO_FLG || ',' || 
        ikjInfRow.O_C_DENSHI_KARTE_FLG || ',' || 
        ikjInfRow.O_C_KARTEKANRI_SENNIN_FLG || ',' || 
        ikjInfRow.O_C_KARTEKANRI_SENNIN_SU || ',' || 
        ikjInfRow.O_C_KANJYASU_IPPAN_BED || ',' || 
        ikjInfRow.O_C_KANJYASU_RYOYO_BED || ',' || 
        ikjInfRow.O_C_KANJYASU_R_BED_IRY_HKN || ',' || 
        ikjInfRow.O_C_KANJYASU_R_BED_KIG_HKN || ',' || 
        ikjInfRow.O_C_KANJYASU_SEISHIN_BED || ',' || 
        ikjInfRow.O_C_KANJYASU_KEKKAKU_BED || ',' || 
        ikjInfRow.O_C_KANJYASU_KANSEN || ',' || 
        ikjInfRow.O_C_KANJYASU_ZENTAI_BED || ',' || 
        ikjInfRow.O_C_KANJYASU_BED_SBT_S_YMD || ',' || 
        ikjInfRow.O_C_KANJYASU_BED_SBT_E_YMD || ',' || 
        ikjInfRow.O_C_KANJYASU_GAIRAI || ',' || 
        ikjInfRow.O_C_KANJYASU_GAIRAI_S_YMD || ',' || 
        ikjInfRow.O_C_KANJYASU_GAIRAI_E_YMD || ',' || 
        ikjInfRow.O_C_KANJYASU_ZAITAKU || ',' || 
        ikjInfRow.O_C_KANJYASU_ZAITAKU_S_YMD || ',' || 
        ikjInfRow.O_C_KANJYASU_ZAITAKU_E_YMD || ',' || 
        ikjInfRow.O_C_KANJYANSU_IPPAN_BED || ',' || 
        ikjInfRow.O_C_KANJYANSU_RYOYO_BED || ',' || 
        ikjInfRow.O_C_KANJYANSU_R_BED_IRY_HKN || ',' || 
        ikjInfRow.O_C_KANJYANSU_R_BED_KIG_HKN || ',' || 
        ikjInfRow.O_C_KANJYANSU_SEISHIN_BED || ',' || 
        ikjInfRow.O_C_KANJYANSU_KEKKAKU_BED || ',' || 
        ikjInfRow.O_C_KANJYANSU_KANSEN || ',' || 
        ikjInfRow.O_C_KANJYANSU_ZENTAI_BED || ',' || 
        ikjInfRow.O_C_KANJYANSU_BED_SBT_S_YMD || ',' || 
        ikjInfRow.O_C_KANJYANSU_BED_SBT_E_YMD || ',' || 
        ikjInfRow.O_C_KANJYANSU_GAIRAI || ',' || 
        ikjInfRow.O_C_KANJYANSU_GAIRAI_S_YMD || ',' || 
        ikjInfRow.O_C_KANJYANSU_GAIRAI_E_YMD || ',' || 
        ikjInfRow.O_C_KANJYANSU_ZAITAKU || ',' || 
        ikjInfRow.O_C_KANJYANSU_ZAITAKU_S_YMD || ',' || 
        ikjInfRow.O_C_KANJYANSU_ZAITAKU_E_YMD || ',' || 
        ikjInfRow.O_C_AVGNISSU_IPPAN_BED || ',' || 
        ikjInfRow.O_C_AVGNISSU_RYOYO_BED || ',' || 
        ikjInfRow.O_C_AVGNISSU_R_BED_IRY_HKN || ',' || 
        ikjInfRow.O_C_AVGNISSU_R_BED_KIG_HKN || ',' || 
        ikjInfRow.O_C_AVGNISSU_SEISHIN_BED || ',' || 
        ikjInfRow.O_C_AVGNISSU_KEKKAKU_BED || ',' || 
        ikjInfRow.O_C_AVGNISSU_KANSEN || ',' || 
        ikjInfRow.O_C_AVGNISSU_ZENTAI_BED || ',' || 
        ikjInfRow.O_C_AVGNISSU_S_YMD || ',' || 
        ikjInfRow.O_C_AVGNISSU_E_YMD THEN
            tsuikaDelKbn := '';
            modKbn := ULT_COMMON.MOD_KBN_YES;
        ELSE
            tsuikaDelKbn := '';
            modKbn := ULT_COMMON.MOD_KBN_NO;
        END IF;                    

        IF modKbn != ULT_COMMON.MOD_KBN_NO THEN
            -- �W�����ڂ������l���𔻒肷��

            -- �W�����ځi�����̎��{�j
            IF '1' || ikjInfRow.N_C_CHIKENJISSHI_FLG = '1' || ikjInfRow.O_C_CHIKENJISSHI_FLG AND
            '1' || ikjInfRow.N_C_CHIKENJISSHI_KIYK_KENSU = '1' || ikjInfRow.O_C_CHIKENJISSHI_KIYK_KENSU AND
            '1' || ikjInfRow.N_C_CHIKENJISSHI_S_YMD = '1' || ikjInfRow.O_C_CHIKENJISSHI_S_YMD AND
            '1' || ikjInfRow.N_C_CHIKENJISSHI_E_YMD = '1' || ikjInfRow.O_C_CHIKENJISSHI_E_YMD THEN
                groupFlgChiken2 :='2';
            ELSIF ikjInfRow.N_C_CHIKENJISSHI_FLG IS NULL AND
            ikjInfRow.N_C_CHIKENJISSHI_KIYK_KENSU IS NULL AND
            ikjInfRow.N_C_CHIKENJISSHI_S_YMD IS NULL AND
            ikjInfRow.N_C_CHIKENJISSHI_E_YMD IS NULL THEN
                groupFlgChiken :=TRUE;
                groupFlgChiken2 :='1';
            END IF;               
            -- �W�����ځi�f�Ï��Ǘ��̐�_�I�[�_�����O�V�X�e���j
            IF '1' || ikjInfRow.N_C_ORDERINGSYSTEM_FLG = '1' || ikjInfRow.O_C_ORDERINGSYSTEM_FLG AND
            '1' || ikjInfRow.N_C_ORDERINGSYSTEM_KENSA_FLG = '1' || ikjInfRow.O_C_ORDERINGSYSTEM_KENSA_FLG AND
            '1' || ikjInfRow.N_C_ORDERINGSYSTEM_SHOHO_FLG = '1' || ikjInfRow.O_C_ORDERINGSYSTEM_SHOHO_FLG AND
            '1' || ikjInfRow.N_C_ORDERINGSYSTEM_YOYAKU_FLG = '1' || ikjInfRow.O_C_ORDERINGSYSTEM_YOYAKU_FLG THEN
                groupFlgOrderingsystem2 :='2';
            ELSIF ikjInfRow.N_C_ORDERINGSYSTEM_FLG IS NULL AND
            ikjInfRow.N_C_ORDERINGSYSTEM_KENSA_FLG IS NULL AND
            ikjInfRow.N_C_ORDERINGSYSTEM_SHOHO_FLG IS NULL AND
            ikjInfRow.N_C_ORDERINGSYSTEM_YOYAKU_FLG IS NULL THEN
                groupFlgOrderingsystem :=TRUE;
                groupFlgOrderingsystem2 :='1';
            END IF;               
            -- �W�����ځi�f�Ï��Ǘ��̐�_��C�]���ҁj
            IF '1' || ikjInfRow.N_C_KARTEKANRI_SENNIN_FLG = '1' || ikjInfRow.O_C_KARTEKANRI_SENNIN_FLG AND
            '1' || ikjInfRow.N_C_KARTEKANRI_SENNIN_SU = '1' || ikjInfRow.O_C_KARTEKANRI_SENNIN_SU THEN
                groupFlgSennin2 :='2';
            ELSIF ikjInfRow.N_C_KARTEKANRI_SENNIN_FLG IS NULL AND
            ikjInfRow.N_C_KARTEKANRI_SENNIN_SU IS NULL THEN
                groupFlgSennin :=TRUE;
                groupFlgSennin2 :='1';
            END IF;               
            -- �W�����ځi���Ґ�����_�a����ʁj
            IF '1' || ikjInfRow.N_C_KANJYASU_IPPAN_BED = '1' || ikjInfRow.O_C_KANJYASU_IPPAN_BED AND
            '1' || ikjInfRow.N_C_KANJYASU_RYOYO_BED = '1' || ikjInfRow.O_C_KANJYASU_RYOYO_BED AND
            '1' || ikjInfRow.N_C_KANJYASU_R_BED_IRY_HKN = '1' || ikjInfRow.O_C_KANJYASU_R_BED_IRY_HKN AND
            '1' || ikjInfRow.N_C_KANJYASU_R_BED_KIG_HKN = '1' || ikjInfRow.O_C_KANJYASU_R_BED_KIG_HKN AND
            '1' || ikjInfRow.N_C_KANJYASU_SEISHIN_BED = '1' || ikjInfRow.O_C_KANJYASU_SEISHIN_BED AND
            '1' || ikjInfRow.N_C_KANJYASU_KEKKAKU_BED = '1' || ikjInfRow.O_C_KANJYASU_KEKKAKU_BED AND
            '1' || ikjInfRow.N_C_KANJYASU_KANSEN = '1' || ikjInfRow.O_C_KANJYASU_KANSEN AND
            '1' || ikjInfRow.N_C_KANJYASU_ZENTAI_BED = '1' || ikjInfRow.O_C_KANJYASU_ZENTAI_BED AND
            '1' || ikjInfRow.N_C_KANJYASU_BED_SBT_S_YMD = '1' || ikjInfRow.O_C_KANJYASU_BED_SBT_S_YMD AND
            '1' || ikjInfRow.N_C_KANJYASU_BED_SBT_E_YMD = '1' || ikjInfRow.O_C_KANJYASU_BED_SBT_E_YMD THEN
                groupFlgKanjyasuBedSbt2 :='2';
            ELSIF ikjInfRow.N_C_KANJYASU_IPPAN_BED IS NULL AND
            ikjInfRow.N_C_KANJYASU_RYOYO_BED IS NULL AND
            ikjInfRow.N_C_KANJYASU_R_BED_IRY_HKN IS NULL AND
            ikjInfRow.N_C_KANJYASU_R_BED_KIG_HKN IS NULL AND
            ikjInfRow.N_C_KANJYASU_SEISHIN_BED IS NULL AND
            ikjInfRow.N_C_KANJYASU_KEKKAKU_BED IS NULL AND
            ikjInfRow.N_C_KANJYASU_KANSEN IS NULL AND
            ikjInfRow.N_C_KANJYASU_ZENTAI_BED IS NULL AND
            ikjInfRow.N_C_KANJYASU_BED_SBT_S_YMD IS NULL AND
            ikjInfRow.N_C_KANJYASU_BED_SBT_E_YMD IS NULL THEN
                groupFlgKanjyasuBedSbt :=TRUE;
                groupFlgKanjyasuBedSbt2 :='1';
            END IF;               
            -- �W�����ځi���Ґ�����_�O���j
            IF '1' || ikjInfRow.N_C_KANJYASU_GAIRAI = '1' || ikjInfRow.O_C_KANJYASU_GAIRAI AND
            '1' || ikjInfRow.N_C_KANJYASU_GAIRAI_S_YMD = '1' || ikjInfRow.O_C_KANJYASU_GAIRAI_S_YMD AND
            '1' || ikjInfRow.N_C_KANJYASU_GAIRAI_E_YMD = '1' || ikjInfRow.O_C_KANJYASU_GAIRAI_E_YMD THEN
                groupFlgKanjyasuGairai2 :='2';
            ELSIF ikjInfRow.N_C_KANJYASU_GAIRAI IS NULL AND
            ikjInfRow.N_C_KANJYASU_GAIRAI_S_YMD IS NULL AND
            ikjInfRow.N_C_KANJYASU_GAIRAI_E_YMD IS NULL THEN
                groupFlgKanjyasuGairai :=TRUE;
                groupFlgKanjyasuGairai2 :='1';
            END IF;             
            -- �W�����ځi���Ґ�����_�ݑ�j
            IF '1' || ikjInfRow.N_C_KANJYASU_ZAITAKU = '1' || ikjInfRow.O_C_KANJYASU_ZAITAKU AND
            '1' || ikjInfRow.N_C_KANJYASU_ZAITAKU_S_YMD = '1' || ikjInfRow.O_C_KANJYASU_ZAITAKU_S_YMD AND
            '1' || ikjInfRow.N_C_KANJYASU_ZAITAKU_E_YMD = '1' || ikjInfRow.O_C_KANJYASU_ZAITAKU_E_YMD THEN
                groupFlgKanjyasuZaitaku2 :='2';
            ELSIF ikjInfRow.N_C_KANJYASU_ZAITAKU IS NULL AND
            ikjInfRow.N_C_KANJYASU_ZAITAKU_S_YMD IS NULL AND
            ikjInfRow.N_C_KANJYASU_ZAITAKU_E_YMD IS NULL THEN
                groupFlgKanjyasuZaitaku :=TRUE;
                groupFlgKanjyasuZaitaku2 :='1';
            END IF;               
            -- �W�����ځi���Ґ�����_�a����ʁj
            IF '1' || ikjInfRow.N_C_KANJYANSU_IPPAN_BED = '1' || ikjInfRow.O_C_KANJYANSU_IPPAN_BED AND
            '1' || ikjInfRow.N_C_KANJYANSU_RYOYO_BED = '1' || ikjInfRow.O_C_KANJYANSU_RYOYO_BED AND
            '1' || ikjInfRow.N_C_KANJYANSU_R_BED_IRY_HKN = '1' || ikjInfRow.O_C_KANJYANSU_R_BED_IRY_HKN AND
            '1' || ikjInfRow.N_C_KANJYANSU_R_BED_KIG_HKN = '1' || ikjInfRow.O_C_KANJYANSU_R_BED_KIG_HKN AND
            '1' || ikjInfRow.N_C_KANJYANSU_SEISHIN_BED = '1' || ikjInfRow.O_C_KANJYANSU_SEISHIN_BED AND
            '1' || ikjInfRow.N_C_KANJYANSU_KEKKAKU_BED = '1' || ikjInfRow.O_C_KANJYANSU_KEKKAKU_BED AND
            '1' || ikjInfRow.N_C_KANJYANSU_KANSEN = '1' || ikjInfRow.O_C_KANJYANSU_KANSEN AND
            '1' || ikjInfRow.N_C_KANJYANSU_ZENTAI_BED = '1' || ikjInfRow.O_C_KANJYANSU_ZENTAI_BED AND
            '1' || ikjInfRow.N_C_KANJYANSU_BED_SBT_S_YMD = '1' || ikjInfRow.O_C_KANJYANSU_BED_SBT_S_YMD AND
            '1' || ikjInfRow.N_C_KANJYANSU_BED_SBT_E_YMD = '1' || ikjInfRow.O_C_KANJYANSU_BED_SBT_E_YMD THEN
                groupFlgKanjyansuBedSbt2 :='2';
            ELSIF ikjInfRow.N_C_KANJYANSU_IPPAN_BED IS NULL AND
            ikjInfRow.N_C_KANJYANSU_RYOYO_BED IS NULL AND
            ikjInfRow.N_C_KANJYANSU_R_BED_IRY_HKN IS NULL AND
            ikjInfRow.N_C_KANJYANSU_R_BED_KIG_HKN IS NULL AND
            ikjInfRow.N_C_KANJYANSU_SEISHIN_BED IS NULL AND
            ikjInfRow.N_C_KANJYANSU_KEKKAKU_BED IS NULL AND
            ikjInfRow.N_C_KANJYANSU_KANSEN IS NULL AND
            ikjInfRow.N_C_KANJYANSU_ZENTAI_BED IS NULL AND
            ikjInfRow.N_C_KANJYANSU_BED_SBT_S_YMD IS NULL AND
            ikjInfRow.N_C_KANJYANSU_BED_SBT_E_YMD IS NULL THEN
                groupFlgKanjyansuBedSbt :=TRUE;
                groupFlgKanjyansuBedSbt2 :='1';
            END IF;               
            -- �W�����ځi���Ґ�����_�O���j
            IF '1' || ikjInfRow.N_C_KANJYANSU_GAIRAI = '1' || ikjInfRow.O_C_KANJYANSU_GAIRAI AND
            '1' || ikjInfRow.N_C_KANJYANSU_GAIRAI_S_YMD = '1' || ikjInfRow.O_C_KANJYANSU_GAIRAI_S_YMD AND
            '1' || ikjInfRow.N_C_KANJYANSU_GAIRAI_E_YMD = '1' || ikjInfRow.O_C_KANJYANSU_GAIRAI_E_YMD THEN
                groupFlgKanjyansuGairai2 :='2';
            ELSIF ikjInfRow.N_C_KANJYANSU_GAIRAI IS NULL AND
            ikjInfRow.N_C_KANJYANSU_GAIRAI_S_YMD IS NULL AND
            ikjInfRow.N_C_KANJYANSU_GAIRAI_E_YMD IS NULL THEN
                groupFlgKanjyansuGairai :=TRUE;
                groupFlgKanjyansuGairai2 :='1';
            END IF;               
            -- �W�����ځi���Ґ�����_�ݑ�j
            IF '1' || ikjInfRow.N_C_KANJYANSU_ZAITAKU = '1' || ikjInfRow.O_C_KANJYANSU_ZAITAKU AND
            '1' || ikjInfRow.N_C_KANJYANSU_ZAITAKU_S_YMD = '1' || ikjInfRow.O_C_KANJYANSU_ZAITAKU_S_YMD AND
            '1' || ikjInfRow.N_C_KANJYANSU_ZAITAKU_E_YMD = '1' || ikjInfRow.O_C_KANJYANSU_ZAITAKU_E_YMD THEN
                groupFlgKanjyansuZaitaku2 :='2';
            ELSIF ikjInfRow.N_C_KANJYANSU_ZAITAKU IS NULL AND
            ikjInfRow.N_C_KANJYANSU_ZAITAKU_S_YMD IS NULL AND
            ikjInfRow.N_C_KANJYANSU_ZAITAKU_E_YMD IS NULL THEN
                groupFlgKanjyansuZaitaku :=TRUE;
                groupFlgKanjyansuZaitaku2 :='1';
            END IF;               
            -- �W�����ځi���ύ݉@�����j
            IF '1' || ikjInfRow.N_C_AVGNISSU_IPPAN_BED = '1' || ikjInfRow.O_C_AVGNISSU_IPPAN_BED AND
            '1' || ikjInfRow.N_C_AVGNISSU_RYOYO_BED = '1' || ikjInfRow.O_C_AVGNISSU_RYOYO_BED AND
            '1' || ikjInfRow.N_C_AVGNISSU_R_BED_IRY_HKN = '1' || ikjInfRow.O_C_AVGNISSU_R_BED_IRY_HKN AND
            '1' || ikjInfRow.N_C_AVGNISSU_R_BED_KIG_HKN = '1' || ikjInfRow.O_C_AVGNISSU_R_BED_KIG_HKN AND
            '1' || ikjInfRow.N_C_AVGNISSU_SEISHIN_BED = '1' || ikjInfRow.O_C_AVGNISSU_SEISHIN_BED AND
            '1' || ikjInfRow.N_C_AVGNISSU_KEKKAKU_BED = '1' || ikjInfRow.O_C_AVGNISSU_KEKKAKU_BED AND
            '1' || ikjInfRow.N_C_AVGNISSU_KANSEN = '1' || ikjInfRow.O_C_AVGNISSU_KANSEN AND
            '1' || ikjInfRow.N_C_AVGNISSU_ZENTAI_BED = '1' || ikjInfRow.O_C_AVGNISSU_ZENTAI_BED AND
            '1' || ikjInfRow.N_C_AVGNISSU_S_YMD = '1' || ikjInfRow.O_C_AVGNISSU_S_YMD AND
            '1' || ikjInfRow.N_C_AVGNISSU_E_YMD = '1' || ikjInfRow.O_C_AVGNISSU_E_YMD THEN
                groupFlgAvgnissu2 :='2';
            ELSIF ikjInfRow.N_C_AVGNISSU_IPPAN_BED IS NULL AND
            ikjInfRow.N_C_AVGNISSU_RYOYO_BED IS NULL AND
            ikjInfRow.N_C_AVGNISSU_R_BED_IRY_HKN IS NULL AND
            ikjInfRow.N_C_AVGNISSU_R_BED_KIG_HKN IS NULL AND
            ikjInfRow.N_C_AVGNISSU_SEISHIN_BED IS NULL AND
            ikjInfRow.N_C_AVGNISSU_KEKKAKU_BED IS NULL AND
            ikjInfRow.N_C_AVGNISSU_KANSEN IS NULL AND
            ikjInfRow.N_C_AVGNISSU_ZENTAI_BED IS NULL AND
            ikjInfRow.N_C_AVGNISSU_S_YMD IS NULL AND
            ikjInfRow.N_C_AVGNISSU_E_YMD IS NULL THEN
                groupFlgAvgnissu :=TRUE;
                groupFlgAvgnissu2 :='1';
            END IF;               

            -- �V_������_��Ë@�\���_��{�e�[�u��/�V_�T����_��Ë@�\���_��{�e�[�u����o�^����
            EXECUTE_SQL := 'INSERT INTO TD_N' || tableKbn || '_IKJ_KHN' ||
            '(LAYOUT_KBN,' ||
            'DCF_CD_REC_ID,' ||
            'DCF_CD_SHI_CD,' ||
            'DCF_CD_YOBI,' ||
            'MOD_KBN,' ||
            'MENTE_YMD,' ||
            'JOHO_YMD,' ||
            'ANNAIYO_HOMEPAGE_ADDRESS,' ||
            'INNAI_SHOHO_FLG,' ||
            'INGAI_SHOHO_FLG,' ||
            'CHIKENJISSHI_FLG,' ||
            'CHIKENJISSHI_KIYK_KENSU,' ||
            'CHIKENJISSHI_KIKAN_S,' ||
            'CHIKENJISSHI_KIKAN_E,' ||
            'SHI_STB_FLG,' ||
            'SHIKKAN_CHRY_FLG,' ||
            'TNK_TIZI_SJT_FLG,' ||
            'SMG_FLG,' ||
            'RNKITISI_MADOGUCHI_FLG,' ||
            'RNKITISI_CHIKRENKEIPATH_FLG,' ||
            'RNKITISI_RNKITISI,' ||
            'KNRTISI_ORDERINGSYSTEM_UMU_FLG,' ||
            'KNRTISI_ORDERINGSYSTEM_KENSA,' ||
            'KNRTISI_ORDERINGSYSTEM_SHOHO,' ||
            'KNRTISI_ORDERINGSYSTEM_YOYAKU,' ||
            'KNRTISI_ICD_CD_RIYO_FLG,' ||
            'KNRTISI_DENSHI_KARTE_FLG,' ||
            'KNRTISI_SENNIN_FLG,' ||
            'KNRTISI_SENNIN_SU,' ||
            'KANJYASU_AVG_BED_SBT_IPPAN,' ||
            'KANJYASU_AVG_BED_SBT_RYOYO,' ||
            'KANJYASU_AVG_BED_SBT_RYOYO_IRY,' ||
            'KANJYASU_AVG_BED_SBT_RYOYO_KIG,' ||
            'KANJYASU_AVG_BED_SBT_SEISHIN,' ||
            'KANJYASU_AVG_BED_SBT_KEKKAKU,' ||
            'KANJYASU_AVG_BED_SBT_KANSEN,' ||
            'KANJYASU_AVG_BED_SBT_ZENTAI,' ||
            'KANJYASU_AVG_BED_SBT_KIKAN_S,' ||
            'KANJYASU_AVG_BED_SBT_KIKAN_E,' ||
            'KANJYASU_AVG_GAIRAI_KANJYASU,' ||
            'KANJYASU_AVG_GAIRAI_KIKAN_S,' ||
            'KANJYASU_AVG_GAIRAI_KIKAN_E,' ||
            'KANJYASU_AVG_ZAITAKU_KANJYASU,' ||
            'KANJYASU_AVG_ZAITAKU_KIKAN_S,' ||
            'KANJYASU_AVG_ZAITAKU_KIKAN_E,' ||
            'KANJYASU_NSU_BED_SBT_IPPAN,' ||
            'KANJYASU_NSU_BED_SBT_RYOYO,' ||
            'KANJYASU_NSU_BED_SBT_RYOYO_IRY,' ||
            'KANJYASU_NSU_BED_SBT_RYOYO_KIG,' ||
            'KANJYASU_NSU_BED_SBT_SEISHIN,' ||
            'KANJYASU_NSU_BED_SBT_KEKKAKU,' ||
            'KANJYASU_NSU_BED_SBT_KANSEN,' ||
            'KANJYASU_NSU_BED_SBT_ZENTAI,' ||
            'KANJYASU_NSU_BED_SBT_KIKAN_S,' ||
            'KANJYASU_NSU_BED_SBT_KIKAN_E,' ||
            'KANJYASU_NSU_GAIRAI_KANJYASU,' ||
            'KANJYASU_NSU_GAIRAI_KIKAN_S,' ||
            'KANJYASU_NSU_GAIRAI_KIKAN_E,' ||
            'KANJYASU_NSU_ZAITAKU_KANJYASU,' ||
            'KANJYASU_NSU_ZAITAKU_KIKAN_S,' ||
            'KANJYASU_NSU_ZAITAKU_KIKAN_E,' ||
            'AVGNISSU_IPPAN,' ||
            'AVGNISSU_RYOYO,' ||
            'AVGNISSU_RYOYO_IRY,' ||
            'AVGNISSU_RYOYO_KIG,' ||
            'AVGNISSU_SEISHIN,' ||
            'AVGNISSU_KEKKAKU,' ||
            'AVGNISSU_KANSEN,' ||
            'AVGNISSU_ZENTAI,' ||
            'AVGNISSU_KIKAN_S,' ||
            'AVGNISSU_KIKAN_E,' ||
            'TSUIKA_DEL_KBN,' ||
            'TENSO_YMD,' ||
            'TRK_OPE_CD,' ||
            'TRK_DATE,' ||
            'TRK_PGM_ID,' ||
            'UPD_OPE_CD,' ||
            'UPD_DATE,' ||
            'UPD_PGM_ID)' ||
            -- ���C�A�E�g�敪
            'VALUES (''132'',' ||
            -- DCF�R�[�h_���R�[�hID
            '''00'',' ||
            -- DCF�R�[�h_�{�݃R�[�h
            '''' || ikjInfRow.N_C_SHI_CD || ''',' ||
            -- DCF�R�[�h_�\��
            'NULL,' ||
            -- �C���敪
            '''' || modKbn || ''',' ||
            -- �����e�i���X�N����
            '''' || ikjInfRow.N_C_UPD_EIGY_YMD || ''',' ||
            -- ���N����
            '''' || TRIM(ULT_COMMON.ConvertData(modKbn, tsuikaDelKbn, ikjInfRow.N_C_JOHO_YMD, ikjInfRow.O_C_JOHO_YMD)) || ''',' ||
            -- �ē��p�z�[���y�[�W�A�h���X
            '''' || ULT_COMMON.ConvertData(modKbn, tsuikaDelKbn, ikjInfRow.N_C_ANNAIYO_URL, ikjInfRow.O_C_ANNAIYO_URL) || ''',' ||
            -- �@�������t���O
            '''' || ULT_COMMON.ConvertData(modKbn, tsuikaDelKbn, ikjInfRow.N_C_INNAI_SHOHO_FLG, ikjInfRow.O_C_INNAI_SHOHO_FLG) || ''',' ||
            -- �@�O�����t���O
            '''' || ULT_COMMON.ConvertData(modKbn, tsuikaDelKbn, ikjInfRow.N_C_INGAI_SHOHO_FLG, ikjInfRow.O_C_INGAI_SHOHO_FLG) || ''',' ||
            -- �����̎��{_�t���O
            '''' || ULT_COMMON.ConvertData(modKbn, tsuikaDelKbn, ikjInfRow.N_C_CHIKENJISSHI_FLG, ikjInfRow.O_C_CHIKENJISSHI_FLG, FALSE,groupFlgChiken2) || ''',' ||
            -- �����̎��{_�_�񌏐�
            '''' || ULT_COMMON.ConvertData(modKbn, tsuikaDelKbn, ikjInfRow.N_C_CHIKENJISSHI_KIYK_KENSU, ikjInfRow.O_C_CHIKENJISSHI_KIYK_KENSU, groupFlgChiken, groupFlgChiken2) || ''',' ||
            -- �����̎��{_����_��
            '''' || ULT_COMMON.ConvertData(modKbn, tsuikaDelKbn, ikjInfRow.N_C_CHIKENJISSHI_S_YMD, ikjInfRow.O_C_CHIKENJISSHI_S_YMD, groupFlgChiken, groupFlgChiken2) || ''',' ||
            -- �����̎��{_����_��
            '''' || ULT_COMMON.ConvertData(modKbn, tsuikaDelKbn, ikjInfRow.N_C_CHIKENJISSHI_E_YMD, ikjInfRow.O_C_CHIKENJISSHI_E_YMD, groupFlgChiken, groupFlgChiken2) || ''',' ||
            -- �ۗL����{�ݐݔ�_�t���O
            '''' || ULT_COMMON.ConvertData(modKbn, tsuikaDelKbn, ikjInfRow.N_C_STB_FLG, ikjInfRow.O_C_STB_FLG) || ''',' ||
            -- �Ή����邱�Ƃ��ł��鎾���E���Â̓��e_�t���O
            '''' || ULT_COMMON.ConvertData(modKbn, tsuikaDelKbn, ikjInfRow.N_C_SHIKKAN_CHRY_FLG, ikjInfRow.O_C_SHIKKAN_CHRY_FLG) || ''',' ||
            -- �Ή����邱�Ƃ��ł���Z���؍ݎ�p_�t���O
            '''' || ULT_COMMON.ConvertData(modKbn, tsuikaDelKbn, ikjInfRow.N_C_TNK_TIZI_SJT_FLG, ikjInfRow.O_C_TNK_TIZI_SJT_FLG) || ''',' ||
            -- ���O��_�t���O
            '''' || ULT_COMMON.ConvertData(modKbn, tsuikaDelKbn, ikjInfRow.N_C_SMG_FLG, ikjInfRow.O_C_SMG_FLG) || ''',' ||
            -- �n���ØA�g�̐�_�����ݒu�t���O
            '''' || ULT_COMMON.ConvertData(modKbn, tsuikaDelKbn, ikjInfRow.N_C_CHIKRENKEI_MADOGUCHI_FLG, ikjInfRow.O_C_CHIKRENKEI_MADOGUCHI_FLG) || ''',' ||
            -- �n���ØA�g�̐�_�n��A�g�p�X�t���O
            '''' || ULT_COMMON.ConvertData(modKbn, tsuikaDelKbn, ikjInfRow.N_C_CHIKRENKEIPATH_FLG_IKJ, ikjInfRow.O_C_CHIKRENKEIPATH_FLG_IKJ) || ''',' ||
            -- �n���ØA�g�̐�_���@�f�Ìv����莞�ɂ�����@���̘A�g�̐�
            '''' || ULT_COMMON.ConvertData(modKbn, tsuikaDelKbn, ikjInfRow.N_C_NYUINSNRY_INNAI_R_FLG, ikjInfRow.O_C_NYUINSNRY_INNAI_R_FLG) || ''',' ||
            -- �f�Ï��Ǘ��̐�_�I�[�_�����O�V�X�e��_�L���t���O
            '''' || ULT_COMMON.ConvertData(modKbn, tsuikaDelKbn, ikjInfRow.N_C_ORDERINGSYSTEM_FLG, ikjInfRow.O_C_ORDERINGSYSTEM_FLG,FALSE ,groupFlgOrderingsystem2) || ''',' ||
            -- �f�Ï��Ǘ��̐�_�I�[�_�����O�V�X�e��_����
            '''' || ULT_COMMON.ConvertData(modKbn, tsuikaDelKbn, ikjInfRow.N_C_ORDERINGSYSTEM_KENSA_FLG, ikjInfRow.O_C_ORDERINGSYSTEM_KENSA_FLG, groupFlgOrderingsystem, groupFlgOrderingsystem2) || ''',' ||
            -- �f�Ï��Ǘ��̐�_�I�[�_�����O�V�X�e��_����
            '''' || ULT_COMMON.ConvertData(modKbn, tsuikaDelKbn, ikjInfRow.N_C_ORDERINGSYSTEM_SHOHO_FLG, ikjInfRow.O_C_ORDERINGSYSTEM_SHOHO_FLG, groupFlgOrderingsystem, groupFlgOrderingsystem2) || ''',' ||
            -- �f�Ï��Ǘ��̐�_�I�[�_�����O�V�X�e��_�\��
            '''' || ULT_COMMON.ConvertData(modKbn, tsuikaDelKbn, ikjInfRow.N_C_ORDERINGSYSTEM_YOYAKU_FLG, ikjInfRow.O_C_ORDERINGSYSTEM_YOYAKU_FLG, groupFlgOrderingsystem, groupFlgOrderingsystem2) || ''',' ||
            -- �f�Ï��Ǘ��̐�_ICD�R�[�h���p�t���O
            '''' || ULT_COMMON.ConvertData(modKbn, tsuikaDelKbn, ikjInfRow.N_C_ICD_CD_RIYO_FLG, ikjInfRow.O_C_ICD_CD_RIYO_FLG) || ''',' ||
            -- �f�Ï��Ǘ��̐�_�d�q�J���e�t���O
            '''' || ULT_COMMON.ConvertData(modKbn, tsuikaDelKbn, ikjInfRow.N_C_DENSHI_KARTE_FLG, ikjInfRow.O_C_DENSHI_KARTE_FLG) || ''',' ||
            -- �f�Ï��Ǘ��̐�_��C�]���҃t���O
            '''' || ULT_COMMON.ConvertData(modKbn, tsuikaDelKbn, ikjInfRow.N_C_KARTEKANRI_SENNIN_FLG, ikjInfRow.O_C_KARTEKANRI_SENNIN_FLG,FALSE ,groupFlgSennin2) || ''',' ||
            -- �f�Ï��Ǘ��̐�_��C�]���Ґ�
            '''' || ULT_COMMON.ConvertData(modKbn, tsuikaDelKbn, ikjInfRow.N_C_KARTEKANRI_SENNIN_SU, ikjInfRow.O_C_KARTEKANRI_SENNIN_SU, groupFlgSennin, groupFlgSennin2) || ''',' ||
            -- ���Ґ�����_�a�����_���
            'DECODE(''' || ULT_COMMON.ConvertData(modKbn, tsuikaDelKbn, ikjInfRow.N_C_KANJYASU_IPPAN_BED, ikjInfRow.O_C_KANJYASU_IPPAN_BED,FALSE ,groupFlgKanjyasuBedSbt2) || ''',''' || ULT_COMMON.INSERT_HALF_DEFAULT || ''',''' || ULT_COMMON.INSERT_HALF_DEFAULT || ''',TRIM(TO_CHAR(''' || ULT_COMMON.ConvertData(modKbn, tsuikaDelKbn, ikjInfRow.N_C_KANJYASU_IPPAN_BED, ikjInfRow.O_C_KANJYASU_IPPAN_BED,FALSE ,groupFlgKanjyasuBedSbt2) || ''',''99990.0''))),' ||
            -- ���Ґ�����_�a�����_�×{
            'DECODE(''' || ULT_COMMON.ConvertData(modKbn, tsuikaDelKbn, ikjInfRow.N_C_KANJYASU_RYOYO_BED, ikjInfRow.O_C_KANJYASU_RYOYO_BED, groupFlgKanjyasuBedSbt, groupFlgKanjyasuBedSbt2) || ''',''' || ULT_COMMON.INSERT_HALF_DEFAULT || ''',''' || ULT_COMMON.INSERT_HALF_DEFAULT || ''',TRIM(TO_CHAR(''' || ULT_COMMON.ConvertData(modKbn, tsuikaDelKbn, ikjInfRow.N_C_KANJYASU_RYOYO_BED, ikjInfRow.O_C_KANJYASU_RYOYO_BED, groupFlgKanjyasuBedSbt, groupFlgKanjyasuBedSbt2) || ''',''99990.0''))),' ||
            -- ���Ґ�����_�a�����_�×{(���)
            'DECODE(''' || ULT_COMMON.ConvertData(modKbn, tsuikaDelKbn, ikjInfRow.N_C_KANJYASU_R_BED_IRY_HKN, ikjInfRow.O_C_KANJYASU_R_BED_IRY_HKN, groupFlgKanjyasuBedSbt, groupFlgKanjyasuBedSbt2) || ''',''' || ULT_COMMON.INSERT_HALF_DEFAULT || ''',''' || ULT_COMMON.INSERT_HALF_DEFAULT || ''',TRIM(TO_CHAR(''' || ULT_COMMON.ConvertData(modKbn, tsuikaDelKbn, ikjInfRow.N_C_KANJYASU_R_BED_IRY_HKN, ikjInfRow.O_C_KANJYASU_R_BED_IRY_HKN, groupFlgKanjyasuBedSbt, groupFlgKanjyasuBedSbt2) || ''',''99990.0''))),' ||
            -- ���Ґ�����_�a�����_�×{(���)
            'DECODE(''' || ULT_COMMON.ConvertData(modKbn, tsuikaDelKbn, ikjInfRow.N_C_KANJYASU_R_BED_KIG_HKN, ikjInfRow.O_C_KANJYASU_R_BED_KIG_HKN, groupFlgKanjyasuBedSbt, groupFlgKanjyasuBedSbt2) || ''',''' || ULT_COMMON.INSERT_HALF_DEFAULT || ''',''' || ULT_COMMON.INSERT_HALF_DEFAULT || ''',TRIM(TO_CHAR(''' || ULT_COMMON.ConvertData(modKbn, tsuikaDelKbn, ikjInfRow.N_C_KANJYASU_R_BED_KIG_HKN, ikjInfRow.O_C_KANJYASU_R_BED_KIG_HKN, groupFlgKanjyasuBedSbt, groupFlgKanjyasuBedSbt2) || ''',''99990.0''))),' ||
            -- ���Ґ�����_�a�����_���_
            'DECODE(''' || ULT_COMMON.ConvertData(modKbn, tsuikaDelKbn, ikjInfRow.N_C_KANJYASU_SEISHIN_BED, ikjInfRow.O_C_KANJYASU_SEISHIN_BED, groupFlgKanjyasuBedSbt, groupFlgKanjyasuBedSbt2) || ''',''' || ULT_COMMON.INSERT_HALF_DEFAULT || ''',''' || ULT_COMMON.INSERT_HALF_DEFAULT || ''',TRIM(TO_CHAR(''' || ULT_COMMON.ConvertData(modKbn, tsuikaDelKbn, ikjInfRow.N_C_KANJYASU_SEISHIN_BED, ikjInfRow.O_C_KANJYASU_SEISHIN_BED, groupFlgKanjyasuBedSbt, groupFlgKanjyasuBedSbt2) || ''',''99990.0''))),' ||
            -- ���Ґ�����_�a�����_���j
            'DECODE(''' || ULT_COMMON.ConvertData(modKbn, tsuikaDelKbn, ikjInfRow.N_C_KANJYASU_KEKKAKU_BED, ikjInfRow.O_C_KANJYASU_KEKKAKU_BED, groupFlgKanjyasuBedSbt, groupFlgKanjyasuBedSbt2) || ''',''' || ULT_COMMON.INSERT_HALF_DEFAULT || ''',''' || ULT_COMMON.INSERT_HALF_DEFAULT || ''',TRIM(TO_CHAR(''' || ULT_COMMON.ConvertData(modKbn, tsuikaDelKbn, ikjInfRow.N_C_KANJYASU_KEKKAKU_BED, ikjInfRow.O_C_KANJYASU_KEKKAKU_BED, groupFlgKanjyasuBedSbt, groupFlgKanjyasuBedSbt2) || ''',''99990.0''))),' ||
            -- ���Ґ�����_�a�����_������
            'DECODE(''' || ULT_COMMON.ConvertData(modKbn, tsuikaDelKbn, ikjInfRow.N_C_KANJYASU_KANSEN, ikjInfRow.O_C_KANJYASU_KANSEN, groupFlgKanjyasuBedSbt, groupFlgKanjyasuBedSbt2) || ''',''' || ULT_COMMON.INSERT_HALF_DEFAULT || ''',''' || ULT_COMMON.INSERT_HALF_DEFAULT || ''',TRIM(TO_CHAR(''' || ULT_COMMON.ConvertData(modKbn, tsuikaDelKbn, ikjInfRow.N_C_KANJYASU_KANSEN, ikjInfRow.O_C_KANJYASU_KANSEN, groupFlgKanjyasuBedSbt, groupFlgKanjyasuBedSbt2) || ''',''99990.0''))),' ||
            -- ���Ґ�����_�a�����_�S��
            'DECODE(''' || ULT_COMMON.ConvertData(modKbn, tsuikaDelKbn, ikjInfRow.N_C_KANJYASU_ZENTAI_BED, ikjInfRow.O_C_KANJYASU_ZENTAI_BED, groupFlgKanjyasuBedSbt, groupFlgKanjyasuBedSbt2) || ''',''' || ULT_COMMON.INSERT_HALF_DEFAULT || ''',''' || ULT_COMMON.INSERT_HALF_DEFAULT || ''',TRIM(TO_CHAR(''' || ULT_COMMON.ConvertData(modKbn, tsuikaDelKbn, ikjInfRow.N_C_KANJYASU_ZENTAI_BED, ikjInfRow.O_C_KANJYASU_ZENTAI_BED, groupFlgKanjyasuBedSbt, groupFlgKanjyasuBedSbt2) || ''',''99990.0''))),' ||
            -- ���Ґ�����_�a�����_����_��
            '''' || ULT_COMMON.ConvertData(modKbn, tsuikaDelKbn, ikjInfRow.N_C_KANJYASU_BED_SBT_S_YMD, ikjInfRow.O_C_KANJYASU_BED_SBT_S_YMD, groupFlgKanjyasuBedSbt, groupFlgKanjyasuBedSbt2) || ''',' ||
            -- ���Ґ�����_�a�����_����_��
            '''' || ULT_COMMON.ConvertData(modKbn, tsuikaDelKbn, ikjInfRow.N_C_KANJYASU_BED_SBT_E_YMD, ikjInfRow.O_C_KANJYASU_BED_SBT_E_YMD, groupFlgKanjyasuBedSbt, groupFlgKanjyasuBedSbt2) || ''',' ||
            -- ���Ґ�����_�O��_���Ґ�
            'DECODE(''' || ULT_COMMON.ConvertData(modKbn, tsuikaDelKbn, ikjInfRow.N_C_KANJYASU_GAIRAI, ikjInfRow.O_C_KANJYASU_GAIRAI,FALSE,groupFlgKanjyasuGairai2) || ''',''' || ULT_COMMON.INSERT_HALF_DEFAULT || ''',''' || ULT_COMMON.INSERT_HALF_DEFAULT || ''',TRIM(TO_CHAR(''' || ULT_COMMON.ConvertData(modKbn, tsuikaDelKbn, ikjInfRow.N_C_KANJYASU_GAIRAI, ikjInfRow.O_C_KANJYASU_GAIRAI,FALSE,groupFlgKanjyasuGairai2) || ''',''99990.0''))),' ||
            -- ���Ґ�����_�O��_����_��
            '''' || ULT_COMMON.ConvertData(modKbn, tsuikaDelKbn, ikjInfRow.N_C_KANJYASU_GAIRAI_S_YMD, ikjInfRow.O_C_KANJYASU_GAIRAI_S_YMD, groupFlgKanjyasuGairai,groupFlgKanjyasuGairai2) || ''',' ||
            -- ���Ґ�����_�O��_����_��
            '''' || ULT_COMMON.ConvertData(modKbn, tsuikaDelKbn, ikjInfRow.N_C_KANJYASU_GAIRAI_E_YMD, ikjInfRow.O_C_KANJYASU_GAIRAI_E_YMD, groupFlgKanjyasuGairai,groupFlgKanjyasuGairai2) || ''',' ||
            -- ���Ґ�����_�ݑ�_���Ґ�
            'DECODE(''' || ULT_COMMON.ConvertData(modKbn, tsuikaDelKbn, ikjInfRow.N_C_KANJYASU_ZAITAKU, ikjInfRow.O_C_KANJYASU_ZAITAKU,FALSE,groupFlgKanjyasuZaitaku2) || ''',''' || ULT_COMMON.INSERT_HALF_DEFAULT ||''',''' || ULT_COMMON.INSERT_HALF_DEFAULT || ''',TRIM(TO_CHAR(''' || ULT_COMMON.ConvertData(modKbn, tsuikaDelKbn, ikjInfRow.N_C_KANJYASU_ZAITAKU, ikjInfRow.O_C_KANJYASU_ZAITAKU,FALSE,groupFlgKanjyasuZaitaku2) || ''',''99990.0''))),' ||
            -- ���Ґ�����_�ݑ�_����_��
            '''' || ULT_COMMON.ConvertData(modKbn, tsuikaDelKbn, ikjInfRow.N_C_KANJYASU_ZAITAKU_S_YMD, ikjInfRow.O_C_KANJYASU_ZAITAKU_S_YMD, groupFlgKanjyasuZaitaku,groupFlgKanjyasuZaitaku2) || ''',' ||
            -- ���Ґ�����_�ݑ�_����_��
            '''' || ULT_COMMON.ConvertData(modKbn, tsuikaDelKbn, ikjInfRow.N_C_KANJYASU_ZAITAKU_E_YMD, ikjInfRow.O_C_KANJYASU_ZAITAKU_E_YMD, groupFlgKanjyasuZaitaku,groupFlgKanjyasuZaitaku2) || ''',' ||
            -- ���Ґ�����_�a�����_���
            '''' || ULT_COMMON.ConvertData(modKbn, tsuikaDelKbn, ikjInfRow.N_C_KANJYANSU_IPPAN_BED, ikjInfRow.O_C_KANJYANSU_IPPAN_BED,FALSE,groupFlgKanjyansuBedSbt2) || ''',' ||
            -- ���Ґ�����_�a�����_�×{
            '''' || ULT_COMMON.ConvertData(modKbn, tsuikaDelKbn, ikjInfRow.N_C_KANJYANSU_RYOYO_BED, ikjInfRow.O_C_KANJYANSU_RYOYO_BED, groupFlgKanjyansuBedSbt,groupFlgKanjyansuBedSbt2) || ''',' ||
            -- ���Ґ�����_�a�����_�×{(���)
            '''' || ULT_COMMON.ConvertData(modKbn, tsuikaDelKbn, ikjInfRow.N_C_KANJYANSU_R_BED_IRY_HKN, ikjInfRow.O_C_KANJYANSU_R_BED_IRY_HKN, groupFlgKanjyansuBedSbt,groupFlgKanjyansuBedSbt2) || ''',' ||
            -- ���Ґ�����_�a�����_�×{(���)
            '''' || ULT_COMMON.ConvertData(modKbn, tsuikaDelKbn, ikjInfRow.N_C_KANJYANSU_R_BED_KIG_HKN, ikjInfRow.O_C_KANJYANSU_R_BED_KIG_HKN, groupFlgKanjyansuBedSbt,groupFlgKanjyansuBedSbt2) || ''',' ||
            -- ���Ґ�����_�a�����_���_
            '''' || ULT_COMMON.ConvertData(modKbn, tsuikaDelKbn, ikjInfRow.N_C_KANJYANSU_SEISHIN_BED, ikjInfRow.O_C_KANJYANSU_SEISHIN_BED, groupFlgKanjyansuBedSbt,groupFlgKanjyansuBedSbt2) || ''',' ||
            -- ���Ґ�����_�a�����_���j
            '''' || ULT_COMMON.ConvertData(modKbn, tsuikaDelKbn, ikjInfRow.N_C_KANJYANSU_KEKKAKU_BED, ikjInfRow.O_C_KANJYANSU_KEKKAKU_BED, groupFlgKanjyansuBedSbt,groupFlgKanjyansuBedSbt2) || ''',' ||
            -- ���Ґ�����_�a�����_������
            '''' || ULT_COMMON.ConvertData(modKbn, tsuikaDelKbn, ikjInfRow.N_C_KANJYANSU_KANSEN, ikjInfRow.O_C_KANJYANSU_KANSEN, groupFlgKanjyansuBedSbt,groupFlgKanjyansuBedSbt2) || ''',' ||
            -- ���Ґ�����_�a�����_�S��
            '''' || ULT_COMMON.ConvertData(modKbn, tsuikaDelKbn, ikjInfRow.N_C_KANJYANSU_ZENTAI_BED, ikjInfRow.O_C_KANJYANSU_ZENTAI_BED, groupFlgKanjyansuBedSbt,groupFlgKanjyansuBedSbt2) || ''',' ||
            -- ���Ґ�����_�a�����_����_��
            '''' || ULT_COMMON.ConvertData(modKbn, tsuikaDelKbn, ikjInfRow.N_C_KANJYANSU_BED_SBT_S_YMD, ikjInfRow.O_C_KANJYANSU_BED_SBT_S_YMD, groupFlgKanjyansuBedSbt,groupFlgKanjyansuBedSbt2) || ''',' ||
            -- ���Ґ�����_�a�����_����_��
            '''' || ULT_COMMON.ConvertData(modKbn, tsuikaDelKbn, ikjInfRow.N_C_KANJYANSU_BED_SBT_E_YMD, ikjInfRow.O_C_KANJYANSU_BED_SBT_E_YMD, groupFlgKanjyansuBedSbt,groupFlgKanjyansuBedSbt2) || ''',' ||
            -- ���Ґ�����_�O��_���Ґ�
            '''' || ULT_COMMON.ConvertData(modKbn, tsuikaDelKbn, ikjInfRow.N_C_KANJYANSU_GAIRAI, ikjInfRow.O_C_KANJYANSU_GAIRAI,FALSE,groupFlgKanjyansuGairai2) || ''',' ||
            -- ���Ґ�����_�O��_����_��
            '''' || ULT_COMMON.ConvertData(modKbn, tsuikaDelKbn, ikjInfRow.N_C_KANJYANSU_GAIRAI_S_YMD, ikjInfRow.O_C_KANJYANSU_GAIRAI_S_YMD, groupFlgKanjyansuGairai,groupFlgKanjyansuGairai2) || ''',' ||
            -- ���Ґ�����_�O��_����_��
            '''' || ULT_COMMON.ConvertData(modKbn, tsuikaDelKbn, ikjInfRow.N_C_KANJYANSU_GAIRAI_E_YMD, ikjInfRow.O_C_KANJYANSU_GAIRAI_E_YMD, groupFlgKanjyansuGairai,groupFlgKanjyansuGairai2) || ''',' ||
            -- ���Ґ�����_�ݑ�_���Ґ�
            '''' || ULT_COMMON.ConvertData(modKbn, tsuikaDelKbn, ikjInfRow.N_C_KANJYANSU_ZAITAKU, ikjInfRow.O_C_KANJYANSU_ZAITAKU,FALSE,groupFlgKanjyansuZaitaku2) || ''',' ||
            -- ���Ґ�����_�ݑ�_����_��
            '''' || ULT_COMMON.ConvertData(modKbn, tsuikaDelKbn, ikjInfRow.N_C_KANJYANSU_ZAITAKU_S_YMD, ikjInfRow.O_C_KANJYANSU_ZAITAKU_S_YMD, groupFlgKanjyansuZaitaku,groupFlgKanjyansuZaitaku2) || ''',' ||
            -- ���Ґ�����_�ݑ�_����_��
            '''' || ULT_COMMON.ConvertData(modKbn, tsuikaDelKbn, ikjInfRow.N_C_KANJYANSU_ZAITAKU_E_YMD, ikjInfRow.O_C_KANJYANSU_ZAITAKU_E_YMD, groupFlgKanjyansuZaitaku,groupFlgKanjyansuZaitaku2) || ''',' ||
            -- ���ύ݉@����_���
            'DECODE(''' || ULT_COMMON.ConvertData(modKbn, tsuikaDelKbn, ikjInfRow.N_C_AVGNISSU_IPPAN_BED, ikjInfRow.O_C_AVGNISSU_IPPAN_BED, FALSE,groupFlgAvgnissu2) || ''',''' || ULT_COMMON.INSERT_HALF_DEFAULT || ''',''' || ULT_COMMON.INSERT_HALF_DEFAULT || ''',TRIM(TO_CHAR(''' || ULT_COMMON.ConvertData(modKbn, tsuikaDelKbn, ikjInfRow.N_C_AVGNISSU_IPPAN_BED, ikjInfRow.O_C_AVGNISSU_IPPAN_BED, FALSE,groupFlgAvgnissu2) || ''',''99990.0''))),' ||
            -- ���ύ݉@����_�×{
            'DECODE(''' || ULT_COMMON.ConvertData(modKbn, tsuikaDelKbn, ikjInfRow.N_C_AVGNISSU_RYOYO_BED, ikjInfRow.O_C_AVGNISSU_RYOYO_BED, groupFlgAvgnissu, groupFlgAvgnissu2) || ''',''' || ULT_COMMON.INSERT_HALF_DEFAULT || ''',''' || ULT_COMMON.INSERT_HALF_DEFAULT || ''',TRIM(TO_CHAR(''' || ULT_COMMON.ConvertData(modKbn, tsuikaDelKbn, ikjInfRow.N_C_AVGNISSU_RYOYO_BED, ikjInfRow.O_C_AVGNISSU_RYOYO_BED, groupFlgAvgnissu, groupFlgAvgnissu2) || ''',''99990.0''))),' ||
            -- ���ύ݉@����_�×{�i��Áj
            'DECODE(''' || ULT_COMMON.ConvertData(modKbn, tsuikaDelKbn, ikjInfRow.N_C_AVGNISSU_R_BED_IRY_HKN, ikjInfRow.O_C_AVGNISSU_R_BED_IRY_HKN, groupFlgAvgnissu, groupFlgAvgnissu2) || ''',''' || ULT_COMMON.INSERT_HALF_DEFAULT || ''',''' || ULT_COMMON.INSERT_HALF_DEFAULT || ''',TRIM(TO_CHAR(''' || ULT_COMMON.ConvertData(modKbn, tsuikaDelKbn, ikjInfRow.N_C_AVGNISSU_R_BED_IRY_HKN, ikjInfRow.O_C_AVGNISSU_R_BED_IRY_HKN, groupFlgAvgnissu, groupFlgAvgnissu2) || ''',''99990.0''))),' ||
            -- ���ύ݉@����_�×{�i���j
            'DECODE(''' || ULT_COMMON.ConvertData(modKbn, tsuikaDelKbn, ikjInfRow.N_C_AVGNISSU_R_BED_KIG_HKN, ikjInfRow.O_C_AVGNISSU_R_BED_KIG_HKN, groupFlgAvgnissu, groupFlgAvgnissu2) || ''',''' || ULT_COMMON.INSERT_HALF_DEFAULT || ''',''' || ULT_COMMON.INSERT_HALF_DEFAULT || ''',TRIM(TO_CHAR(''' || ULT_COMMON.ConvertData(modKbn, tsuikaDelKbn, ikjInfRow.N_C_AVGNISSU_R_BED_KIG_HKN, ikjInfRow.O_C_AVGNISSU_R_BED_KIG_HKN, groupFlgAvgnissu, groupFlgAvgnissu2) || ''',''99990.0''))),' ||
            -- ���ύ݉@����_���_
            'DECODE(''' || ULT_COMMON.ConvertData(modKbn, tsuikaDelKbn, ikjInfRow.N_C_AVGNISSU_SEISHIN_BED, ikjInfRow.O_C_AVGNISSU_SEISHIN_BED, groupFlgAvgnissu, groupFlgAvgnissu2) || ''',''' || ULT_COMMON.INSERT_HALF_DEFAULT || ''',''' || ULT_COMMON.INSERT_HALF_DEFAULT || ''',TRIM(TO_CHAR(''' || ULT_COMMON.ConvertData(modKbn, tsuikaDelKbn, ikjInfRow.N_C_AVGNISSU_SEISHIN_BED, ikjInfRow.O_C_AVGNISSU_SEISHIN_BED, groupFlgAvgnissu, groupFlgAvgnissu2) || ''',''99990.0''))),' ||
            -- ���ύ݉@����_���j
            'DECODE(''' || ULT_COMMON.ConvertData(modKbn, tsuikaDelKbn, ikjInfRow.N_C_AVGNISSU_KEKKAKU_BED, ikjInfRow.O_C_AVGNISSU_KEKKAKU_BED, groupFlgAvgnissu, groupFlgAvgnissu2) || ''',''' || ULT_COMMON.INSERT_HALF_DEFAULT || ''',''' || ULT_COMMON.INSERT_HALF_DEFAULT || ''',TRIM(TO_CHAR(''' || ULT_COMMON.ConvertData(modKbn, tsuikaDelKbn, ikjInfRow.N_C_AVGNISSU_KEKKAKU_BED, ikjInfRow.O_C_AVGNISSU_KEKKAKU_BED, groupFlgAvgnissu, groupFlgAvgnissu2) || ''',''99990.0''))),' ||
            -- ���ύ݉@����_������
            'DECODE(''' || ULT_COMMON.ConvertData(modKbn, tsuikaDelKbn, ikjInfRow.N_C_AVGNISSU_KANSEN, ikjInfRow.O_C_AVGNISSU_KANSEN, groupFlgAvgnissu, groupFlgAvgnissu2) || ''',''' || ULT_COMMON.INSERT_HALF_DEFAULT || ''',''' || ULT_COMMON.INSERT_HALF_DEFAULT || ''',TRIM(TO_CHAR(''' || ULT_COMMON.ConvertData(modKbn, tsuikaDelKbn, ikjInfRow.N_C_AVGNISSU_KANSEN, ikjInfRow.O_C_AVGNISSU_KANSEN, groupFlgAvgnissu, groupFlgAvgnissu2) || ''',''99990.0''))),' ||
            -- ���ύ݉@����_�S��
            'DECODE(''' || ULT_COMMON.ConvertData(modKbn, tsuikaDelKbn, ikjInfRow.N_C_AVGNISSU_ZENTAI_BED, ikjInfRow.O_C_AVGNISSU_ZENTAI_BED, groupFlgAvgnissu, groupFlgAvgnissu2) || ''',''' || ULT_COMMON.INSERT_HALF_DEFAULT || ''',''' || ULT_COMMON.INSERT_HALF_DEFAULT || ''',TRIM(TO_CHAR(''' || ULT_COMMON.ConvertData(modKbn, tsuikaDelKbn, ikjInfRow.N_C_AVGNISSU_ZENTAI_BED, ikjInfRow.O_C_AVGNISSU_ZENTAI_BED, groupFlgAvgnissu, groupFlgAvgnissu2) || ''',''99990.0''))),' ||
            -- ���ύ݉@����_����_��
            '''' || ULT_COMMON.ConvertData(modKbn, tsuikaDelKbn, ikjInfRow.N_C_AVGNISSU_S_YMD, ikjInfRow.O_C_AVGNISSU_S_YMD, groupFlgAvgnissu, groupFlgAvgnissu2) || ''',' ||
            -- ���ύ݉@����_����_��
            '''' || ULT_COMMON.ConvertData(modKbn, tsuikaDelKbn, ikjInfRow.N_C_AVGNISSU_E_YMD, ikjInfRow.O_C_AVGNISSU_E_YMD, groupFlgAvgnissu, groupFlgAvgnissu2) || ''',' ||
            -- �ǉ��폜�敪
            '''' || tsuikaDelKbn || ''',' ||
            -- �]���N����
            '''' || iTENSO_DATE || ''',' ||
            -- �o�^�I�y���[�^�R�[�h
            '''' || iOPE_CD || ''',' ||
            -- �o�^����
            'TO_DATE(''' || iDATE || ''', ''yy-mm-dd''),' ||
            -- �o�^�v���O����ID
            '''' || iPGM_ID || ''',' ||
            -- �X�V�I�y���[�^�R�[�h
            '''' || iOPE_CD || ''',' ||
            -- �X�V����
            'TO_DATE(''' || iDATE || ''', ''yy-mm-dd''),' ||
            -- �X�V�v���O����ID
            '''' || iPGM_ID || ''')';
            ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',SUBSTR(EXECUTE_SQL, 0, 2000),iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);
            EXECUTE IMMEDIATE EXECUTE_SQL;

            -- �X�V�����̍Đݒ�
            oROW_COUNT:=oROW_COUNT+1;
        END IF; 
    END LOOP;       
    CLOSE ikjInfCsr;

    -- �X�V�����̍Đݒ�
    IF oROW_COUNT = 0 THEN
        oROW_COUNT := ULT_COMMON.KOSHIN_COUNT_DEFAULT;
    END IF;          

    -- �I�����O�o��
    ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'PL/SQL End',PGM_ID || '�̏������I�����܂����B',iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

    COMMIT;

    -- ����I��
    RETURN ULT_COMMON.RESULT_SUCCESS;

    -- ��O����
EXCEPTION
    -- ���̑��G���[
    WHEN OTHERS THEN
        W_ERR_INF_RCD.ERR_CD     := TO_CHAR(SQLCODE);
        W_ERR_INF_RCD.ERR_MSG     := SUBSTR(SQLERRM, 0, 2000);
        W_ERR_INF_RCD.ERR_KEY_INF   := SUBSTR('iSHIME_KBN:' || iSHIME_KBN || ', iSHIME_FROM:' || iSHIME_FROM || ', iSHIME_TO:' || iSHIME_TO || ', iTENSO_DATE:' || iTENSO_DATE, 0, 500);
        W_INDEX_N       := W_ERR_INF_TBL.COUNT + 1;
        W_ERR_INF_TBL.EXTEND;
        W_ERR_INF_TBL(W_INDEX_N)   := W_ERR_INF_RCD;

        OPEN oOUT_ERR_INF_CSR FOR
        SELECT *
          FROM TABLE(W_ERR_INF_TBL) ;
        ROLLBACK;

        --�G���[���O�̓o�^
        ULT_INSERT_LOG_TABLE('ERROR',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'ERROR_INFO',W_ERR_INF_RCD.ERR_MSG,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

        -- �ُ�G���[�Ƃ��A
        RETURN ULT_COMMON.RESULT_ERROR;
END;
END;
/
