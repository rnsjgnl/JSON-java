CREATE OR REPLACE PACKAGE NH010106B001_505
/* **********************************************************
 *  Copyright(c) 2011 beyond, INTEC Inc. All rights reserved.
 * **********************************************************/
AUTHID CURRENT_USER
IS
	/*** �J�[�\���^ ***************************************************************/
	-- �G���[���i�[�p�J�[�\���^
	TYPE ERR_INF_CSR		IS REF CURSOR;

	/*
	************************************************************************
	*  DNF���Ȉ�t�f��DB�f�[�^�̍쐬
	*  CREATE_DNF_SHIKAYISHI
	************************************************************************
	*/
	FUNCTION CREATE_DNF_SHIKAYISHI(
	iLayoutKind	IN	INTEGER,										-- ���C�A�E�g�敪
	iShimeKind	IN	INTEGER,										-- ���ߓ��敪
    iTensoYMD	IN	VARCHAR2,										-- �]���N����
    iOPE_CD IN Varchar2,                                            -- �I�y���[�^�R�[�h
    iPGM_ID IN Varchar2,                                            -- �v���O����ID
    iDATE DATE,                                                     -- �V�X�e������
	iIP_ADDR	IN TL_STORED_SHORI.IP%TYPE,							-- ���s�[��IP�A�h���X (FW�Őݒ�)
	iWINDOWS_LOGIN_USER	IN TL_STORED_SHORI.WINDOWS_LOGIN_USER%TYPE, -- ���s�[��OS���[�U�[ (FW�Őݒ�)
	oROW_COUNT	OUT NUMBER,                                         -- �o�^����
	oOUT_ERR_INF_CSR 	OUT ERR_INF_CSR                             -- �G���[���J�[�\��
	) RETURN NUMBER;

END;
/

CREATE OR REPLACE PACKAGE BODY NH010106B001_505
/* **********************************************************
 *  Copyright(c) 2011 beyond, INTEC Inc. All rights reserved.
 * **********************************************************/
IS
  /*
   ************************************************************************
   * Function ID  : CREATE_DNF_SHIKAYISHI
   * Program Name : DNF���Ȉ�t�f��DB�f�[�^�̍쐬
   * Parameter    :  <I> iLayoutKind        �F���C�A�E�g�敪
   *              <I> iShimeKind        �F���ߓ��敪
   *           <I> iTensoYMD        �F�]���N����
   *           <I> iOPE_CD            �F�I�y���[�^�R�[�h
   *           <I> iPGM_ID            �F�v���O����ID
   *           <I> iDATE            �F�V�X�e������
   *               <I> iIP_ADDR            �F���s�[��IP�A�h���X
   *               <I> iWINDOWS_LOGIN_USER  �F���s�[��IP�A�h���X
   *                 <O> oROW_COUNT        �F�X�V����
   *                <O> oOUT_ERR_INF_CSR  �F�G���[���J�[�\��
   * Return       �F�������ʁi0:����I���A1:�ُ�I���j
   ************************************************************************
   */
  FUNCTION CREATE_DNF_SHIKAYISHI(
  iLayoutKind  IN  INTEGER,                    -- ���C�A�E�g�敪
  iShimeKind  IN  INTEGER,                    -- ���ߓ��敪
  iTensoYMD  IN  VARCHAR2,                    -- �]���N����
  iOPE_CD IN Varchar2,                                            -- �I�y���[�^�R�[�h
  iPGM_ID IN Varchar2,                                            -- �v���O����ID
  iDATE DATE,                                                     -- �V�X�e������
  iIP_ADDR  IN TL_STORED_SHORI.IP%TYPE,              -- ���s�[��IP�A�h���X (FW�Őݒ�)
  iWINDOWS_LOGIN_USER  IN TL_STORED_SHORI.WINDOWS_LOGIN_USER%TYPE, -- ���s�[��OS���[�U�[ (FW�Őݒ�)
  oROW_COUNT  OUT NUMBER,                                         -- �o�^����
  oOUT_ERR_INF_CSR   OUT ERR_INF_CSR                             -- �G���[���J�[�\��
  )RETURN NUMBER IS

  PRAGMA AUTONOMOUS_TRANSACTION;
  /************************************************************************/
  /*                              �G���[����                              */
  /************************************************************************/
  W_INDEX_N         NUMBER(10) := 0;
  W_ERR_INF_TBL         TYPE_ERR_INFO_TBL := TYPE_ERR_INFO_TBL();
  W_ERR_INF_RCD         TYPE_ERR_INFO_RCD := TYPE_ERR_INFO_RCD(NULL,NULL,NULL,NULL);
  V_SCHEMA_NM   TM_JOSU.HANYO_KOMOKU%TYPE := NULL; -- �X�L�[�}����
  PGM_ID        VARCHAR2(50) := 'NH010106B001_505.CREATE_DNF_SHIKAYISHI';
  EXECUTE_SQL   VARCHAR2(32767) := NULL;

  BEGIN

    -- �J�n���O�o��
      ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'PL/SQL Start',PGM_ID || '�̏������J�n���܂��B',iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

    -- �X�V�����̏�����
    oROW_COUNT := -1;

    -- �[�i�p�X�L�[�}�̎擾���s���B
    V_SCHEMA_NM := ULT_COMMON.GET_SCHEMA_NAME(ULT_COMMON.SYS_ENV_JOSU_DAI_CD, ULT_COMMON.NOHIN_SHEMA_JOSU_SHO_CD);

    -- ���ߋ敪:"1"(������)
    IF iShimeKind = 1 THEN
    -- �V���C�A�E�g
    IF iLayoutKind = 1 THEN

      -- �V_�S��_DNF���Ȉ�t�e�[�u���̃f�[�^���N���A����
      EXECUTE_SQL := 'TRUNCATE TABLE ' || V_SCHEMA_NM || '.' || 'TD_NA_DNF_KJN';
      EXECUTE IMMEDIATE EXECUTE_SQL;
      ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

      -- �V_�S��_DNF���Ȉ�t�̓o�^���s��
      INSERT INTO TD_NA_DNF_KJN(
              LAYOUT_KBN,
              KJNREC_ID,
              KJN_CD,
              KJN_CD_YOBI,
              MOD_KBN,
              MENTE_YMD,
              YOBI_1,
              DEL_YOTEI_RIYU,
              AITSK_CD_KJNREC_ID,
              AITSK_CD_KJN_CD,
              AITSK_CD_KJN_CD_YOBI,
              ISHI_NM_KANJI,
              ISHI_NM_KANA,
              SEIBETSU,
              BIRTH_GENGO,
              BIRTH_Y,
              BIRTH_M,
              BIRTH_D,
              SHUSSHIN_KEN_CD,
              SHIKAISHIKAI_CD,
              STNEN_GENGO,
              STNEN_Y,
              SHUSSHINKO_SHUSSHINKO_CD,
              SHUSSHINKO_GAKUBU_SKBT_CD,
              TRKNEN_GENGO,
              TRKNEN_Y,
              SNRYKMK_1,
              SNRYKMK_2,
              SNRYKMK_3,
              SNRYKMK_4,
              SNRYKMK_5,
              JUSHOFUMEI,
              JUSHO_CD_KEN_CD,
              JUSHO_CD_SHIKU_CD,
              JUSHO_CD_OAZA_CD,
              JUSHO_CD_AZA_CD,
              ZIP,
              JITAKU_JUSHO_KANJI,
              JITAKU_JUSHO_KANA,
              JUSHO_HYOJI_NO,
              JUSHO_COUNT_KANJI_KEN,
              JUSHO_COUNT_KANJI_SHIKU,
              JUSHO_COUNT_KANJI_OAZA,
              JUSHO_COUNT_KANJI_AZA,
              JUSHO_COUNT_KANA_KEN,
              JUSHO_COUNT_KANA_SHIKU,
              JUSHO_COUNT_KANA_OAZA,
              JUSHO_COUNT_KANA_AZA,
              JITAKU_TEL,
              RIYOTEISHI_RIYOTEISHI_KBN,
              RIYOTEISHI_RIYOTEISHI_RIYU,
              RIYOTEISHI_TRK_YMD,
              RIYOTEISHI_KAIJO_YMD,
              KAIKIN_KBN,
              YOBI_2,
              TAIO_DCF_ISHI_REC_ID,
              TAIO_DCF_ISHI_KJN_CD,
              TAIO_DCF_ISHI_YOBI,
              TENSO_YMD,
              TRK_OPE_CD,
              TRK_DATE,
              TRK_PGM_ID,
              UPD_OPE_CD,
              UPD_DATE,
              UPD_PGM_ID
            )
          SELECT
              '505'
            , TTK.REC_ID
            , TTK.KJN_CD
            , NULL
            , NULL
            , TTK.UPD_EIGY_YMD
            , NULL
            , TTK.DEL_YOTEI_RIYU_CD
            , TTK.CHOFUKU_AITSK_REC_ID
            , TTK.CHOFUKU_AITSK_KJN_CD
            , NULL
            , TTK.KJN_NM
            , TTK.KJN_NM_KANA
            , TTK.SEIBETSU_KBN
            , TTK.BIRTH_GENGO_CD
            , TTK.BIRTH_WY
            , TTK.BIRTH_M
            , TTK.BIRTH_D
            , TTK.SHUSSHINCHI_RIDAI_CD
            , TTK.KANYU_ISHIKAI_RIDAI_CD
            , TTK.STNEN_GENGO_CD
            , TTK.STNEN_WY
            , TTK.SHUSSHINKO_CD
            , TTK.GAKUBU_SHIKIBETSU_KBN
            , TTK.TRKNEN_GENGO_CD
            , TTK.TRKNEN_WY
            , TTK.SNRYKMK_CD_1
            , TTK.SNRYKMK_CD_2
            , TTK.SNRYKMK_CD_3
            , TTK.SNRYKMK_CD_4
            , TTK.SNRYKMK_CD_5
            , TTK.JUSHOFUMEI_CD
            , TTK.KEN_CD
            , TTK.SHIKU_CD
            , TTK.OAZA_CD
            , TTK.AZA_CD
            , CASE WHEN TTK.ZIP IS NULL THEN NULL ELSE SUBSTR(TTK.ZIP,1,3) || '-' || SUBSTR(TTK.ZIP,4) END AS ZIP
            , TTK.JUSHO_KANJI_RENKETSU
            , TTK.JUSHO_KANA_RENKETSU
            , TTK.JUSHO_HYOJI_NO
            , TTK.KEN_NM_KANJI_MOJI_SU
            , TTK.SHIKU_NM_KANJI_MOJI_SU
            , TTK.OAZA_NM_KANJI_MOJI_SU
            , TTK.AZA_NM_KANJI_MOJI_SU
            , TTK.KEN_NM_KANA_MOJI_SU
            , TTK.SHIKU_NM_KANA_MOJI_SU
            , TTK.OAZA_NM_KANA_MOJI_SU
            , TTK.AZA_NM_KANA_MOJI_SU
            , TTK.TEL
            , TTK.RIYOTEISHI_KBN_CD
            , TTK.RIYOTEISHI_RIYU_CD
            , TTK.RIYOTEISHI_TRK_YMD
            , TTK.RIYOTEISHI_KAIJO_YMD
            , TTK.KAIKIN_KBN
            , NULL
            , TTK.DCFCHOFUKU_REC_ID
            , TTK.DCFCHOFUKU_KJN_CD
            , NULL
            , iTensoYMD
            , iOPE_CD
            , iDATE
            , iPGM_ID
            , iOPE_CD
            , iDATE
            , iPGM_ID
          FROM TT_TIKY_KJN TTK
          WHERE TTK.REC_ID = '05'
          AND TTK.DEL_FLG IS NULL;

      -- �V_�S��_DNF���Ȉ�t�̓o�^���O��o�^����
      EXECUTE_SQL :=  'INSERT INTO TD_NA_DNF_KJN(    '  ||
            'LAYOUT_KBN,        '  ||
            'KJNREC_ID,        '  ||
            'KJN_CD,        '  ||
            'KJN_CD_YOBI,        '  ||
            'MOD_KBN,        '  ||
            'MENTE_YMD,        '  ||
            'YOBI_1,        '  ||
            'DEL_YOTEI_RIYU,      '  ||
            'AITSK_CD_KJNREC_ID,      '  ||
            'AITSK_CD_KJN_CD,      '  ||
            'AITSK_CD_KJN_CD_YOBI,      '  ||
            'ISHI_NM_KANJI,        '  ||
            'ISHI_NM_KANA,        '  ||
            'SEIBETSU,        '  ||
            'BIRTH_GENGO,        '  ||
            'BIRTH_Y,        '  ||
            'BIRTH_M,        '  ||
            'BIRTH_D,        '  ||
            'SHUSSHIN_KEN_CD,      '  ||
            'SHIKAISHIKAI_CD,      '  ||
            'STNEN_GENGO,        '  ||
            'STNEN_Y,        '  ||
            'SHUSSHINKO_SHUSSHINKO_CD,    '  ||
            'SHUSSHINKO_GAKUBU_SKBT_CD,    '  ||
            'TRKNEN_GENGO,        '  ||
            'TRKNEN_Y,        '  ||
            'SNRYKMK_1,        '  ||
            'SNRYKMK_2,        '  ||
            'SNRYKMK_3,        '  ||
            'SNRYKMK_4,        '  ||
            'SNRYKMK_5,        '  ||
            'JUSHOFUMEI,        '  ||
            'JUSHO_CD_KEN_CD,      '  ||
            'JUSHO_CD_SHIKU_CD,      '  ||
            'JUSHO_CD_OAZA_CD,      '  ||
            'JUSHO_CD_AZA_CD,      '  ||
            'ZIP,          '  ||
            'JITAKU_JUSHO_KANJI,      '  ||
            'JITAKU_JUSHO_KANA,      '  ||
            'JUSHO_HYOJI_NO,      '  ||
            'JUSHO_COUNT_KANJI_KEN,      '  ||
            'JUSHO_COUNT_KANJI_SHIKU,    '  ||
            'JUSHO_COUNT_KANJI_OAZA,    '  ||
            'JUSHO_COUNT_KANJI_AZA,      '  ||
            'JUSHO_COUNT_KANA_KEN,      '  ||
            'JUSHO_COUNT_KANA_SHIKU,    '  ||
            'JUSHO_COUNT_KANA_OAZA,      '  ||
            'JUSHO_COUNT_KANA_AZA,      '  ||
            'JITAKU_TEL,        '  ||
            'RIYOTEISHI_RIYOTEISHI_KBN,    '  ||
            'RIYOTEISHI_RIYOTEISHI_RIYU,    '  ||
            'RIYOTEISHI_TRK_YMD,      '  ||
            'RIYOTEISHI_KAIJO_YMD,      '  ||
            'KAIKIN_KBN,        '  ||
            'YOBI_2,        '  ||
            'TAIO_DCF_ISHI_REC_ID,      '  ||
            'TAIO_DCF_ISHI_KJN_CD,      '  ||
            'TAIO_DCF_ISHI_YOBI,      '  ||
            'TENSO_YMD,        '  ||
            'TRK_OPE_CD,        '  ||
            'TRK_DATE,        '  ||
            'TRK_PGM_ID,        '  ||
            'UPD_OPE_CD,        '  ||
            'UPD_DATE,        '  ||
            'UPD_PGM_ID)        '  ||
            ' SELECT                          ' ||
            '     ''505''                       ' ||
            '   , TTK.REC_ID                  ' ||
            '   , TTK.KJN_CD                  ' ||
            '   , NULL                        ' ||
            '   , NULL                        ' ||
            '   , TTK.UPD_EIGY_YMD            ' ||
            '   , NULL                        ' ||
            '   , TTK.DEL_YOTEI_RIYU_CD       ' ||
            '   , TTK.CHOFUKU_AITSK_REC_ID    ' ||
            '   , TTK.CHOFUKU_AITSK_KJN_CD    ' ||
            '   , NULL                        ' ||
            '   , TTK.KJN_NM                  ' ||
            '   , TTK.KJN_NM_KANA             ' ||
            '   , TTK.SEIBETSU_KBN            ' ||
            '   , TTK.BIRTH_GENGO_CD          ' ||
            '   , TTK.BIRTH_WY                ' ||
            '   , TTK.BIRTH_M                 ' ||
            '   , TTK.BIRTH_D                 ' ||
            '   , TTK.SHUSSHINCHI_RIDAI_CD    ' ||
            '   , TTK.KANYU_ISHIKAI_RIDAI_CD  ' ||
            '   , TTK.STNEN_GENGO_CD          ' ||
            '   , TTK.STNEN_WY                ' ||
            '   , TTK.SHUSSHINKO_CD           ' ||
            '   , TTK.GAKUBU_SHIKIBETSU_KBN   ' ||
            '   , TTK.TRKNEN_GENGO_CD         ' ||
            '   , TTK.TRKNEN_WY               ' ||
            '   , TTK.SNRYKMK_CD_1            ' ||
            '   , TTK.SNRYKMK_CD_2            ' ||
            '   , TTK.SNRYKMK_CD_3            ' ||
            '   , TTK.SNRYKMK_CD_4            ' ||
            '   , TTK.SNRYKMK_CD_5            ' ||
            '   , TTK.JUSHOFUMEI_CD           ' ||
            '   , TTK.KEN_CD                  ' ||
            '   , TTK.SHIKU_CD                ' ||
            '   , TTK.OAZA_CD                 ' ||
            '   , TTK.AZA_CD                  ' ||
            '   , CASE WHEN TTK.ZIP IS NULL THEN  ELSE SUBSTR(TTK.ZIP,1,3) || ''-'' || SUBSTR(TTK.ZIP,4) END AS ZIP ' ||
            '   , TTK.JUSHO_KANJI_RENKETSU    ' ||
            '   , TTK.JUSHO_KANA_RENKETSU     ' ||
            '   , TTK.JUSHO_HYOJI_NO          ' ||
            '   , TTK.KEN_NM_KANJI_MOJI_SU    ' ||
            '   , TTK.SHIKU_NM_KANJI_MOJI_SU  ' ||
            '   , TTK.OAZA_NM_KANJI_MOJI_SU   ' ||
            '   , TTK.AZA_NM_KANJI_MOJI_SU    ' ||
            '   , TTK.KEN_NM_KANA_MOJI_SU     ' ||
            '   , TTK.SHIKU_NM_KANA_MOJI_SU   ' ||
            '   , TTK.OAZA_NM_KANA_MOJI_SU    ' ||
            '   , TTK.AZA_NM_KANA_MOJI_SU     ' ||
            '   , TTK.TEL                     ' ||
            '   , TTK.RIYOTEISHI_KBN_CD       ' ||
            '   , TTK.RIYOTEISHI_RIYU_CD      ' ||
            '   , TTK.RIYOTEISHI_TRK_YMD      ' ||
            '   , TTK.RIYOTEISHI_KAIJO_YMD    ' ||
            '   , TTK.KAIKIN_KBN              ' ||
            '   , NULL                        ' ||
            '   , TTK.DCFCHOFUKU_REC_ID       ' ||
            '   , TTK.DCFCHOFUKU_KJN_CD       ' ||
            '   , NULL                        ' ||
             ',' || iTensoYMD                     ||
             ',' || iOPE_CD            ||
             ',' || iDATE                ||
             ',' || iPGM_ID              ||
             ',' || iOPE_CD              ||
             ',' || iDATE                ||
             ',' || iPGM_ID              ||
            ' FROM TT_TIKY_KJN TTK            ' ||
            ' WHERE TTK.REC_ID = ''05''       ' ||
            ' AND TTK.DEL_FLG IS NULL         ' ;
      ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

        -- �b�背�C�A�E�g
        ELSIF iLayoutKind = 2 THEN

    -- �b��_�S��_DNF���Ȉ�t�e�[�u���̃f�[�^���N���A����B
    EXECUTE_SQL := 'TRUNCATE TABLE ' || V_SCHEMA_NM || '.' || 'TD_PA_DNF_KJN';
    EXECUTE IMMEDIATE EXECUTE_SQL;
    ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

    -- �b��_�S��_���p��~�iDNF���Ȉ�t�j�e�[�u���̃f�[�^���N���A����B
    EXECUTE_SQL := 'TRUNCATE TABLE ' || V_SCHEMA_NM || '.' || 'TD_PA_DNF_KJN_TIS';
    EXECUTE IMMEDIATE EXECUTE_SQL;
    ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

      -- �b��_�S��_DNF���Ȉ�t��o�^����
      INSERT INTO TD_PA_DNF_KJN(
                KJNREC_ID,
                      KJN_CD,
                      KJN_CD_YOBI,
                      ISHI_NM_KANA,
                      SEIBETSU,
                      BIRTH_GENGO,
                      BIRTH_Y,
                      BIRTH_M,
                      BIRTH_D,
                      YOBI_1,
                      SHUSSHIN_KEN_CD,
                      ISHIKAI_CD,
                      STNEN_GENGO,
                      STNEN_Y,
                      SHUSSHINKO_SHUSSHINKO_CD,
                      SHUSSHINKO_GAKUBU_SKBT_CD,
                      KAIKIN_KBN,
                      YOBI_2,
                      YOBI_3,
                      SNRYKMK_1,
                      SNRYKMK_2,
                      SNRYKMK_3,
                      SNRYKMK_4,
                      SNRYKMK_5,
                      JUSHO_CD_KEN_CD,
                      JUSHO_CD_SHIKU_CD,
                      JUSHO_CD_OAZA_CD,
                      JUSHO_CD_AZA_CD,
                      ZIP,
                      JUSHO_HYOJI_NO,
                      YOBI_4,
                      JITAKU_JUSHO_KANA,
                      JUSHO_COUNT_KANA_KEN,
                      JUSHO_COUNT_KANA_SHIKU,
                      JUSHO_COUNT_KANA_OAZA,
                      JUSHO_COUNT_KANA_AZA,
                      JUSHO_COUNT_KANJI_KEN,
                      JUSHO_COUNT_KANJI_SHIKU,
                      JUSHO_COUNT_KANJI_OAZA,
                      JUSHO_COUNT_KANJI_AZA,
                      JITAKU_TEL,
                      STATUS_JUSHOFUMEI,
                      STATUS_DEL_YOTEI_RIYU,
                      STATUS_YOBI_1,
                      STATUS_YOBI_2,
                      TRKNEN_GENGO,
                      TRKNEN_Y,
                      KOTEI_KOMOKU_YOBI_AREA,
                      TAIO_DCF_ISHI_REC_ID,
                      TAIO_DCF_ISHI_KJN_CD,
                      TAIO_DCF_ISHI_YOBI,
                      ISHI_NM_KANJI,
                      JITAKU_JUSHO_KANJI,
                      KINMUSAKI_SHIREC_ID,
                      KINMUSAKI_SHI_CD,
                      KINMUSAKI_SHI_CD_YOBI,
                      KINMUSAKI_YAKUSHOKU_CD,
                      KINMUSAKI_SHOKUI,
                      KINMUSAKI_SZKBUKA_CD,
                      KINMUSAKI_HENKO_UMU_FLG,
                      YOBI_5,
                      RYKSK_SHI_NM_KANA,
                      RYKSK_SHI_NM_KANJI,
                      SZKBUKA_KANA,
                      SZKBUKA_KANJI,
                      KINMUSAKI_KOMOKU_YOBI_AREA,
                      AITSK_CD_KJNREC_ID,
                      AITSK_CD_KJN_CD,
                      AITSK_CD_KJN_CD_YOBI,
                      MOD_SHORI_YMD_Y,
                      MOD_SHORI_YMD_M,
                      MOD_SHORI_YMD_D,
                      TENSO_Y,
                      TENSO_M,
                      TENSO_D,
                      TAISHOKU_IDO_FLG,
                      DM_FUKA_FLG,
                      MOD_KBN,
                      TRK_OPE_CD,
                      TRK_DATE,
                      TRK_PGM_ID,
                      UPD_OPE_CD,
                      UPD_DATE,
                      UPD_PGM_ID
                    )
              SELECT
                    A.REC_ID
                ,   A.KJN_CD
                ,   NULL
                ,   A.KJN_NM_KANA
                ,   A.SEIBETSU_KBN
                ,   A.BIRTH_GENGO_CD
                ,   A.BIRTH_WY
                ,   A.BIRTH_M
                ,   A.BIRTH_D
                ,   NULL
                ,   A.SHUSSHINCHI_RIDAI_CD
                ,   A.KANYU_ISHIKAI_RIDAI_CD
                ,   A.STNEN_GENGO_CD
                ,   A.STNEN_WY
                ,   A.SHUSSHINKO_CD
                ,   A.GAKUBU_SHIKIBETSU_KBN
                ,   A.KAIKIN_KBN
                ,   NULL
                ,   NULL
                ,   A.SNRYKMK_CD_1
                ,   A.SNRYKMK_CD_2
                ,   A.SNRYKMK_CD_3
                ,   A.SNRYKMK_CD_4
                ,   A.SNRYKMK_CD_5
                ,   A.KEN_CD
                ,   A.SHIKU_CD
                ,   A.OAZA_CD
                ,   A.AZA_CD
                -- �X�֔ԍ���4���{"-"�{�X�֔ԍ���3
                ,   CASE WHEN A.ZIP IS NULL THEN NULL ELSE SUBSTR(A.ZIP,1,3) || '-' || SUBSTR(A.ZIP,4) END AS ZIP
                ,   A.JUSHO_HYOJI_NO
                ,   NULL
                ,   A.JUSHO_KANA_RENKETSU
                ,   TO_CHAR(A.KEN_NM_KANA_MOJI_SU,'FM09')
                ,   TO_CHAR(A.SHIKU_NM_KANA_MOJI_SU,'FM09')
                ,   TO_CHAR(A.OAZA_NM_KANA_MOJI_SU,'FM09')
                ,   TO_CHAR(A.AZA_NM_KANA_MOJI_SU,'FM09')
                ,   TO_CHAR(A.KEN_NM_KANJI_MOJI_SU,'FM09')
                ,   TO_CHAR(A.SHIKU_NM_KANJI_MOJI_SU,'FM09')
                ,   TO_CHAR(A.OAZA_NM_KANJI_MOJI_SU,'FM09')
                ,   TO_CHAR(A.AZA_NM_KANJI_MOJI_SU,'FM09')
                ,   A.TEL
                ,   A.JUSHOFUMEI_CD
                ,   A.DEL_YOTEI_RIYU_CD
                ,   NULL
                ,   NULL
                ,   A.TRKNEN_GENGO_CD
                ,   A.TRKNEN_WY
                ,   NULL
                ,   A.DCFCHOFUKU_REC_ID
                ,   A.DCFCHOFUKU_KJN_CD
                ,   NULL
                ,   A.KJN_NM
                ,   A.JUSHO_KANJI_RENKETSU
                ,   CASE WHEN B.KINMUSAKI_REC_ID IS NULL AND B.KINMUSAKI_SHI_CD IS NULL THEN '04' ELSE B.KINMUSAKI_REC_ID END AS KINMUSAKI_REC_ID
                ,   CASE WHEN B.KINMUSAKI_REC_ID IS NULL AND B.KINMUSAKI_SHI_CD IS NULL THEN '9999999' ELSE B.KINMUSAKI_SHI_CD END AS KINMUSAKI_SHI_CD
                ,   NULL
                ,   B.YAKUSHOKU_CD
                ,   B.SHOKUI_CD
                ,   B.SZKBUKA_CD
                ,   NULL
                ,   NULL
                ,   C.SHI_RN_KANA
                ,   C.SHI_RN
                ,   CASE WHEN B.SZKBUKA_CD = '9999' THEN B.NYURYOKU_SZKBUKA_NM_KANA ELSE SUBSTR(D.SZKBUKA_NM_KANA, 1, 20) END
                ,   CASE WHEN B.SZKBUKA_CD = '9999' THEN B.NYURYOKU_SZKBUKA_NM ELSE SUBSTR(D.SZKBUKA_NM, 1, 15) END
                ,   NULL
                ,   A.CHOFUKU_AITSK_REC_ID
                ,   A.CHOFUKU_AITSK_KJN_CD
                ,   NULL
                -- �X�V�����c�ƔN����>=�ő�̍X�V�����c�ƔN�����̏ꍇ�A�X�V�����c�ƔN������ݒ肷��
                -- ��L�ȊO�̏ꍇ�A�ő�̍X�V�����c�ƔN������ݒ肷��
                ,   CASE WHEN E.MAX_UPD_EIGY_YMD IS NULL THEN SUBSTR(A.UPD_EIGY_YMD,1,4) ELSE SUBSTR(GREATEST(A.UPD_EIGY_YMD, E.MAX_UPD_EIGY_YMD),1,4) END
                ,   CASE WHEN E.MAX_UPD_EIGY_YMD IS NULL THEN SUBSTR(A.UPD_EIGY_YMD,5,2) ELSE SUBSTR(GREATEST(A.UPD_EIGY_YMD, E.MAX_UPD_EIGY_YMD),5,2) END
                ,   CASE WHEN E.MAX_UPD_EIGY_YMD IS NULL THEN SUBSTR(A.UPD_EIGY_YMD,7,2) ELSE SUBSTR(GREATEST(A.UPD_EIGY_YMD, E.MAX_UPD_EIGY_YMD),7,2) END
                ,   SUBSTR(iTensoYMD,1,4)
                ,   SUBSTR(iTensoYMD,5,2)
                ,   SUBSTR(iTensoYMD,7,2)
                ,   NULL
                ,   B.KINMUSAKI_DM_FUKA_FLG
                ,   NULL
                , iOPE_CD
            , iDATE
            , iPGM_ID
            , iOPE_CD
            , iDATE
            , iPGM_ID
              FROM TT_TIKY_KJN A
              LEFT OUTER JOIN TT_TIKY_KJN_KINMUSAKI B
                ON A.REC_ID = B.REC_ID
                AND A.KJN_CD = B.KJN_CD
		AND NVL(B.TAISHOKU_FLG,' ') = ' '
              LEFT OUTER JOIN TT_TIKY_SHI C
                ON B.KINMUSAKI_REC_ID = C.REC_ID
                AND B.KINMUSAKI_SHI_CD = C.SHI_CD
              LEFT OUTER JOIN TM_TIKY_HIFG_SSY_SZKBUKA D
                ON B.SZKBUKA_CD = D.SZKBUKA_CD
              LEFT OUTER JOIN (SELECT F.KJN_CD,
                                     -- ������2012/10/16 ST000104�̑Ή�
              						MAX(GREATEST(NVL(F.UPD_EIGY_YMD,'19700101'), NVL(G.UPD_EIGY_YMD,'19700101'))) AS MAX_UPD_EIGY_YMD
	                                --MAX(G.UPD_EIGY_YMD) AS MAX_UPD_EIGY_YMD
	                                -- ��������2012/10/16 ST000104�̑Ή�
	                           FROM TT_TIKY_KJN F
	                           LEFT OUTER JOIN TT_TIKY_KJN_KINMUSAKI G
	                              ON F.REC_ID = G.REC_ID
	                              AND F.KJN_CD = G.KJN_CD
				      			  AND G.TAISHOKU_FLG IS NULL
	                           WHERE F.REC_ID = '05'
	                              AND F.DEL_FLG IS NULL
	                           GROUP BY F.KJN_CD
                          ) E
              ON A.KJN_CD = E.KJN_CD
              WHERE A.REC_ID = '05'
              AND A.DEL_FLG IS NULL
              ORDER BY A.KJN_CD ASC;
      -- -- �b��_�S��_DNF���Ȉ�t�̃��O��o�^����
      EXECUTE_SQL :=  'INSERT INTO TD_PA_DNF_KJN(    '  ||
              'KJNREC_ID,        '  ||
              'KJN_CD,        '  ||
              'KJN_CD_YOBI,        '  ||
              'ISHI_NM_KANA,        '  ||
              'SEIBETSU,        '  ||
              'BIRTH_GENGO,        '  ||
              'BIRTH_Y,        '  ||
              'BIRTH_M,        '  ||
              'BIRTH_D,        '  ||
              'YOBI_1,        '  ||
              'SHUSSHIN_KEN_CD,      '  ||
              'ISHIKAI_CD,        '  ||
              'STNEN_GENGO,        '  ||
              'STNEN_Y,        '  ||
              'SHUSSHINKO_SHUSSHINKO_CD,    '  ||
              'SHUSSHINKO_GAKUBU_SKBT_CD,    '  ||
              'KAIKIN_KBN,        '  ||
              'YOBI_2,        '  ||
              'YOBI_3,        '  ||
              'SNRYKMK_1,        '  ||
              'SNRYKMK_2,        '  ||
              'SNRYKMK_3,        '  ||
              'SNRYKMK_4,        '  ||
              'SNRYKMK_5,        '  ||
              'JUSHO_CD_KEN_CD,      '  ||
              'JUSHO_CD_SHIKU_CD,      '  ||
              'JUSHO_CD_OAZA_CD,      '  ||
              'JUSHO_CD_AZA_CD,      '  ||
              'ZIP,          '  ||
              'JUSHO_HYOJI_NO,      '  ||
              'YOBI_4,        '  ||
              'JITAKU_JUSHO_KANA,      '  ||
              'JUSHO_COUNT_KANA_KEN,      '  ||
              'JUSHO_COUNT_KANA_SHIKU,    '  ||
              'JUSHO_COUNT_KANA_OAZA,      '  ||
              'JUSHO_COUNT_KANA_AZA,      '  ||
              'JUSHO_COUNT_KANJI_KEN,      '  ||
              'JUSHO_COUNT_KANJI_SHIKU,    '  ||
              'JUSHO_COUNT_KANJI_OAZA,    '  ||
              'JUSHO_COUNT_KANJI_AZA,      '  ||
              'JITAKU_TEL,        '  ||
              'STATUS_JUSHOFUMEI,      '  ||
              'STATUS_DEL_YOTEI_RIYU,      '  ||
              'STATUS_YOBI_1,        '  ||
              'STATUS_YOBI_2,        '  ||
              'TRKNEN_GENGO,        '  ||
              'TRKNEN_Y,        '  ||
              'KOTEI_KOMOKU_YOBI_AREA,    '  ||
              'TAIO_DCF_ISHI_REC_ID,      '  ||
              'TAIO_DCF_ISHI_KJN_CD,      '  ||
              'TAIO_DCF_ISHI_YOBI,      '  ||
              'ISHI_NM_KANJI,        '  ||
              'JITAKU_JUSHO_KANJI,      '  ||
              'KINMUSAKI_SHIREC_ID,      '  ||
              'KINMUSAKI_SHI_CD,      '  ||
              'KINMUSAKI_SHI_CD_YOBI,      '  ||
              'KINMUSAKI_YAKUSHOKU_CD,    '  ||
              'KINMUSAKI_SHOKUI,      '  ||
              'KINMUSAKI_SZKBUKA_CD,      '  ||
              'KINMUSAKI_HENKO_UMU_FLG,    '  ||
              'YOBI_5,        '  ||
              'RYKSK_SHI_NM_KANA,      '  ||
              'RYKSK_SHI_NM_KANJI,      '  ||
              'SZKBUKA_KANA,        '  ||
              'SZKBUKA_KANJI,        '  ||
              'KINMUSAKI_KOMOKU_YOBI_AREA,    '  ||
              'AITSK_CD_KJNREC_ID,      '  ||
              'AITSK_CD_KJN_CD,      '  ||
              'AITSK_CD_KJN_CD_YOBI,      '  ||
              'MOD_SHORI_YMD_Y,      '  ||
              'MOD_SHORI_YMD_M,      '  ||
              'MOD_SHORI_YMD_D,      '  ||
              'TENSO_Y,        '  ||
              'TENSO_M,        '  ||
              'TENSO_D,        '  ||
              'TAISHOKU_IDO_FLG,      '  ||
              'DM_FUKA_FLG,        '  ||
              'MOD_KBN,        '  ||
              'TRK_OPE_CD,        '  ||
              'TRK_DATE,        '  ||
              'TRK_PGM_ID,        '  ||
              'UPD_OPE_CD,        '  ||
              'UPD_DATE,        '  ||
              'UPD_PGM_ID)        '  ||
        ' SELECT                  ' ||
        '       A.REC_ID          ' ||
        '   ,   A.KJN_CD          ' ||
        '   ,   NULL              ' ||
        '   ,   A.KJN_NM_KANA     ' ||
        '   ,   A.SEIBETSU_KBN    ' ||
        '   ,   A.BIRTH_GENGO_CD  ' ||
        '   ,   A.BIRTH_WY        ' ||
        '   ,   A.BIRTH_M         ' ||
        '   ,   A.BIRTH_D         ' ||
        '   ,   NULL              ' ||
        '   ,   A.SHUSSHINCHI_RIDAI_CD     ' ||
        '   ,   A.KANYU_ISHIKAI_RIDAI_CD   ' ||
        '   ,   A.STNEN_GENGO_CD  ' ||
        '   ,   A.STNEN_WY        ' ||
        '   ,   A.SHUSSHINKO_CD   ' ||
        '   ,   A.GAKUBU_SHIKIBETSU_KBN    ' ||
        '   ,   A.KAIKIN_KBN      ' ||
        '   ,   NULL              ' ||
        '   ,   NULL              ' ||
        '   ,   A.SNRYKMK_CD_1    ' ||
        '   ,   A.SNRYKMK_CD_2    ' ||
        '   ,   A.SNRYKMK_CD_3    ' ||
        '   ,   A.SNRYKMK_CD_4    ' ||
        '   ,   A.SNRYKMK_CD_5    ' ||
        '   ,   A.KEN_CD          ' ||
        '   ,   A.SHIKU_CD        ' ||
        '   ,   A.OAZA_CD         ' ||
        '   ,   A.AZA_CD          ' ||
        '   ,   CASE WHEN A.ZIP IS NULL THEN NULL ELSE SUBSTR(A.ZIP,1,3) || ''-'' || SUBSTR(A.ZIP,4) END AS ZIP       ' ||
        '   ,   A.JUSHO_HYOJI_NO  ' ||
        '   ,   NULL              ' ||
        '   ,   A.JUSHO_KANA_RENKETSU      ' ||
        '   ,   TO_CHAR(A.KEN_NM_KANA_MOJI_SU,''FM09'')         ' ||
        '   ,   TO_CHAR(A.SHIKU_NM_KANA_MOJI_SU,''FM09'')       ' ||
        '   ,   TO_CHAR(A.OAZA_NM_KANA_MOJI_SU,''FM09'')        ' ||
        '   ,   TO_CHAR(A.AZA_NM_KANA_MOJI_SU,''FM09'')         ' ||
        '   ,   TO_CHAR(A.KEN_NM_KANJI_MOJI_SU,''FM09'')        ' ||
        '   ,   TO_CHAR(A.SHIKU_NM_KANJI_MOJI_SU,''FM09'')      ' ||
        '   ,   TO_CHAR(A.OAZA_NM_KANJI_MOJI_SU,''FM09'')       ' ||
        '   ,   TO_CHAR(A.AZA_NM_KANJI_MOJI_SU,''FM09'')        ' ||
        '   ,   A.TEL             ' ||
        '   ,   A.JUSHOFUMEI_CD   ' ||
        '   ,   A.DEL_YOTEI_RIYU_CD        ' ||
        '   ,   NULL              ' ||
        '   ,   NULL              ' ||
        '   ,   A.TRKNEN_GENGO_CD ' ||
        '   ,   A.TRKNEN_WY       ' ||
        '   ,   NULL              ' ||
        '   ,   A.DCFCHOFUKU_REC_ID        ' ||
        '   ,   A.DCFCHOFUKU_KJN_CD        ' ||
        '   ,   NULL              ' ||
        '   ,   A.KJN_NM          ' ||
        '   ,   A.JUSHO_KANJI_RENKETSU     ' ||
        '   ,   CASE WHEN B.KINMUSAKI_REC_ID IS NULL AND B.KINMUSAKI_SHI_CD IS NULL THEN ''04'' ELSE B.KINMUSAKI_REC_ID END AS KINMUSAKI_REC_ID         ' ||
        '   ,   CASE WHEN B.KINMUSAKI_REC_ID IS NULL AND B.KINMUSAKI_SHI_CD IS NULL THEN ''9999999'' ELSE B.KINMUSAKI_SHI_CD END AS KINMUSAKI_SHI_CD    ' ||
        '   ,   NULL              ' ||
        '   ,   B.YAKUSHOKU_CD    ' ||
        '   ,   B.SHOKUI_CD       ' ||
        '   ,   B.SZKBUKA_CD      ' ||
        '   ,   NULL              ' ||
        '   ,   NULL              ' ||
        '   ,   C.SHI_RN_KANA     ' ||
        '   ,   C.SHI_RN          ' ||
        '   ,   CASE WHEN B.SZKBUKA_CD = ''9999'' THEN B.NYURYOKU_SZKBUKA_NM_KANA ELSE D.SZKBUKA_NM_KANA END' ||
        '   ,   CASE WHEN B.SZKBUKA_CD = ''9999'' THEN B.NYURYOKU_SZKBUKA_NM ELSE D.SZKBUKA_NM END          ' ||
        '   ,   NULL              ' ||
        '   ,   A.CHOFUKU_AITSK_REC_ID     ' ||
        '   ,   A.CHOFUKU_AITSK_KJN_CD     ' ||
        '   ,   NULL              ' ||
        '   ,   CASE WHEN E.MAX_UPD_EIGY_YMD IS NULL THEN SUBSTR(A.UPD_EIGY_YMD,1,4) ELSE SUBSTR(GREATEST(A.UPD_EIGY_YMD, E.MAX_UPD_EIGY_YMD),1,4) END' ||
        '   ,   CASE WHEN E.MAX_UPD_EIGY_YMD IS NULL THEN SUBSTR(A.UPD_EIGY_YMD,5,2) ELSE SUBSTR(GREATEST(A.UPD_EIGY_YMD, E.MAX_UPD_EIGY_YMD),5,2) END' ||
        '   ,   CASE WHEN E.MAX_UPD_EIGY_YMD IS NULL THEN SUBSTR(A.UPD_EIGY_YMD,7,2) ELSE SUBSTR(GREATEST(A.UPD_EIGY_YMD, E.MAX_UPD_EIGY_YMD),7,2) END' ||
        '   ,   SUBSTR(' || iTensoYMD || ',1,4)      ' ||
        '     ,   SUBSTR(' || iTensoYMD || ',5,2)    ' ||
        '     ,   SUBSTR(' || iTensoYMD || ',7,2)    ' ||
        '     ,   NULL            ' ||
        '     ,   B.KINMUSAKI_DM_FUKA_FLG  ' ||
        '     ,   NULL            ' ||
           ',' || iOPE_CD            ||
           ',' || iDATE                ||
           ',' || iPGM_ID              ||
           ',' || iOPE_CD              ||
           ',' || iDATE                ||
           ',' || iPGM_ID              ||
        ' FROM TT_TIKY_KJN A      ' ||
        ' LEFT OUTER JOIN TT_TIKY_KJN_KINMUSAKI B             ' ||
        ' ON A.REC_ID = B.REC_ID  ' ||
        ' AND A.KJN_CD = B.KJN_CD ' ||
        ' AND NVL(B.TAISHOKU_FLG,'' '') = '' ''  ' ||
        ' LEFT OUTER JOIN TT_TIKY_SHI C    ' ||
        ' ON B.KINMUSAKI_REC_ID = C.REC_ID ' ||
        ' AND B.KINMUSAKI_SHI_CD = C.SHI_CD' ||
        ' LEFT OUTER JOIN TM_TIKY_HIFG_SSY_SZKBUKA D          ' ||
        ' ON B.SZKBUKA_CD = D.SZKBUKA_CD   ' ||
        ' LEFT OUTER JOIN (SELECT F.KJN_CD,' ||
        '                   MAX(G.UPD_EIGY_YMD) AS MAX_UPD_EIGY_YMD   ' ||
        '                FROM TT_TIKY_KJN F' ||
        '                LEFT OUTER JOIN TT_TIKY_KJN_KINMUSAKI G      ' ||
        '                   ON F.REC_ID = G.REC_ID            ' ||
        '                   AND F.KJN_CD = G.KJN_CD           ' ||
        '                   AND NVL(G.TAISHOKU_FLG,'' '') = '' ''  ' ||
        '                   AND F.REC_ID = ''05''               ' ||
        '                   AND F.DEL_FLG IS NULL             ' ||
        '                GROUP BY F.KJN_CD ' ||
        '               ) E       ' ||
        ' ON A.KJN_CD = E.KJN_CD  ' ||
        ' WHERE A.REC_ID = ''05''   ' ||
        ' AND A.DEL_FLG IS NULL   ' ||
        ' ORDER BY A.KJN_CD ASC   ' ;
        ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

        -- �b��_�S��_���p��~�iDNF���Ȉ�t�j�e�[�u���֓o�^����
        INSERT INTO TD_PA_DNF_KJN_TIS(
                        KJNREC_ID,
                        KJN_CD,
                        KJN_CD_YOBI,
                        RIYOTEISHI_KBN,
                        RIYOTEISHI_RIYU,
                        TRK_YMD,
                        KAIJO_YMD,
                        TENSO_Y,
                        TENSO_M,
                        TENSO_D,
                        MENTE_Y,
                        MENTE_M,
                        MENTE_D,
                        MOD_KBN,
                        TRK_OPE_CD,
                        TRK_DATE,
                        TRK_PGM_ID,
                        UPD_OPE_CD,
                        UPD_DATE,
                        UPD_PGM_ID
                        )
                SELECT
                      A.REC_ID
                  ,   A.KJN_CD
                  ,   NULL
                  ,   A.RIYOTEISHI_KBN_CD
                  ,   A.RIYOTEISHI_RIYU_CD
                  ,   A.RIYOTEISHI_TRK_YMD
                  ,   A.RIYOTEISHI_KAIJO_YMD
                  ,   SUBSTR(iTensoYMD,1,4)
                  ,   SUBSTR(iTensoYMD,5,2)
                  ,   SUBSTR(iTensoYMD,7,2)
                  ,   SUBSTR(E.MAX_UPD_EIGY_YMD,1,4)
                  ,   SUBSTR(E.MAX_UPD_EIGY_YMD,5,2)
                  ,   SUBSTR(E.MAX_UPD_EIGY_YMD,7,2)
                  ,   NULL
                  ,   iOPE_CD
                  ,   iDATE
                  ,   iPGM_ID
                  ,   iOPE_CD
                  ,   iDATE
                  ,   iPGM_ID
                 FROM TT_TIKY_KJN A
                 LEFT OUTER JOIN (SELECT F.KJN_CD,
                                  MAX(GREATEST(NVL(F.UPD_EIGY_YMD,'19700101'), NVL(G.UPD_EIGY_YMD,'19700101'))) AS MAX_UPD_EIGY_YMD
                               FROM TT_TIKY_KJN F
                               LEFT OUTER JOIN TT_TIKY_KJN_KINMUSAKI G
                                  ON F.REC_ID = G.REC_ID
                                  AND F.KJN_CD = G.KJN_CD
			      	  AND NVL(G.TAISHOKU_FLG,' ') = ' '
                                  AND F.REC_ID = '05'
                                  AND F.DEL_FLG IS NULL
                               GROUP BY F.KJN_CD
                              ) E
                  ON A.KJN_CD = E.KJN_CD
                  WHERE A.REC_ID = '05'
                  AND A.DEL_FLG IS NULL
                  AND A.RIYOTEISHI_KBN_CD IS NOT NULL
                  ORDER BY A.KJN_CD ASC;

          -- �b��_�S��_���p��~�iDNF���Ȉ�t�j�̃��O��o�^����
          EXECUTE_SQL :=  'INSERT INTO TD_PA_DNF_KJN_TIS(      '  ||
                  'KJNREC_ID,        '  ||
                  'KJN_CD,        '  ||
                  'KJN_CD_YOBI,        '  ||
                  'RIYOTEISHI_KBN,      '  ||
                  'RIYOTEISHI_RIYU,      '  ||
                  'TRK_YMD,        '  ||
                  'KAIJO_YMD,        '  ||
                  'TENSO_Y,        '  ||
                  'TENSO_M,        '  ||
                  'TENSO_D,        '  ||
                  'MENTE_Y,        '  ||
                  'MENTE_M,        '  ||
                  'MENTE_D,        '  ||
                  'MOD_KBN,        '  ||
                  'TRK_OPE_CD,        '  ||
                  'TRK_DATE,        '  ||
                  'TRK_PGM_ID,        '  ||
                  'UPD_OPE_CD,        '  ||
                  'UPD_DATE,        '  ||
                  'UPD_PGM_ID)        '  ||
                  '   SELECT                             ' ||
                  '        A.REC_ID                       ' ||
                  '    ,   A.KJN_CD                       ' ||
                  '    ,   NULL                           ' ||
                  '    ,   A.RIYOTEISHI_KBN_CD            ' ||
                  '    ,   A.RIYOTEISHI_RIYU_CD           ' ||
                  '    ,   A.RIYOTEISHI_TRK_YMD           ' ||
                  '    ,   A.RIYOTEISHI_KAIJO_YMD         ' ||
                  '    ,   SUBSTR(' || iTensoYMD || ',1,4)          ' ||
                  '    ,   SUBSTR(' || iTensoYMD || ',5,2)          ' ||
                  '    ,   SUBSTR(' || iTensoYMD || ',7,2)          ' ||
                  '    ,   SUBSTR(E.MAX_UPD_EIGY_YMD,1,4) ' ||
                  '    ,   SUBSTR(E.MAX_UPD_EIGY_YMD,5,2) ' ||
                  '    ,   SUBSTR(E.MAX_UPD_EIGY_YMD,7,2) ' ||
                  '    ,   NULL                           ' ||
                      ',' || iOPE_CD                         ||
                      ',' || iDATE                           ||
                      ',' || iPGM_ID                         ||
                      ',' || iOPE_CD                         ||
                      ',' || iDATE                           ||
                      ',' || iPGM_ID                         ||
                  '  FROM TT_TIKY_KJN A                  ' ||
                  '  LEFT OUTER JOIN (SELECT F.KJN_CD,   ' ||
                  '                    MAX(GREATEST(NVL(F.UPD_EIGY_YMD,''19700101''), NVL(G.UPD_EIGY_YMD,''19700101''))) AS MAX_UPD_EIGY_YMD ' ||
                  '                 FROM TT_TIKY_KJN F   ' ||
                  '                 LEFT OUTER JOIN TT_TIKY_KJN_KINMUSAKI G   ' ||
                  '                    ON F.REC_ID = G.REC_ID                 ' ||
                  '                    AND F.KJN_CD = G.KJN_CD                ' ||
                  '                    AND NVL(G.TAISHOKU_FLG,'' '') = '' ''  ' ||
                  '                    AND F.REC_ID = ''05''                    ' ||
                  '                    AND F.DEL_FLG IS NULL                  ' ||
                  '                 GROUP BY F.KJN_CD    ' ||
                  '                ) E                   ' ||
                  '  ON A.KJN_CD = E.KJN_CD              ' ||
                  '  WHERE A.REC_ID = ''05''               ' ||
                  '  AND A.DEL_FLG IS NULL               ' ||
                  '  AND A.RIYOTEISHI_KBN_CD IS NOT NULL ' ||
                  '  ORDER BY A.KJN_CD ASC               ' ;
        ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);
    END IF;
  END IF;
  COMMIT;

        -- �I�����O�o��
        ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'PL/SQL End',PGM_ID || '�̏������I�����܂����B',iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

  return 0;
  -- ��O����
  EXCEPTION
    -- ���̑��G���[
    WHEN OTHERS THEN
      W_ERR_INF_RCD.ERR_CD     := TO_CHAR(SQLCODE);
      W_ERR_INF_RCD.ERR_MSG     := SUBSTR(SQLERRM, 0, 500);
      W_ERR_INF_RCD.ERR_KEY_INF   := SUBSTR('iLayoutKind:' || iLayoutKind || ', iShimeKind:' || iShimeKind , 0,500);
      W_INDEX_N       := W_ERR_INF_TBL.COUNT + 1;
      W_ERR_INF_TBL.EXTEND;
      W_ERR_INF_TBL(W_INDEX_N)   := W_ERR_INF_RCD;

      OPEN oOUT_ERR_INF_CSR FOR
        SELECT * FROM TABLE(W_ERR_INF_TBL);

      ROLLBACK;
      -- �G���[���O�̓o�^
              ULT_INSERT_LOG_TABLE('ERROR',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'ERROR_INFO',W_ERR_INF_RCD.ERR_MSG,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);
      return 1;
        END;
    END;
/
