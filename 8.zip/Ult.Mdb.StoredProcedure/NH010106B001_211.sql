CREATE OR REPLACE PACKAGE NH010106B001_211
/* **********************************************************
 *  Copyright(c) 2011 beyond, INTEC Inc. All rights reserved.
 * **********************************************************/
AUTHID CURRENT_USER
IS
	/*** �J�[�\���^ ***************************************************************/
	-- �G���[���i�[�p�J�[�\���^
	TYPE ERR_INF_CSR		IS REF CURSOR;

	/*
	************************************************************************
	*  KGF��{�f��DB�f�[�^�̍쐬
	*  CREATE_KGF_KIHON
	************************************************************************
	*/
	FUNCTION CREATE_KGF_KIHON(
	iLayoutKind	IN	INTEGER,										-- ���C�A�E�g�敪
	iShimeKind	IN	INTEGER,										-- ���ߓ��敪
        dcfShisetsu	IN	VARCHAR2,										-- �]���N���� 
	iIP_ADDR	IN TL_STORED_SHORI.IP%TYPE,							-- ���s�[��IP�A�h���X (FW�Őݒ�)
	iWINDOWS_LOGIN_USER	IN TL_STORED_SHORI.WINDOWS_LOGIN_USER%TYPE, -- ���s�[��OS���[�U�[ (FW�Őݒ�)
	oROW_COUNT	OUT NUMBER,         -- �o�^����
	oOUT_ERR_INF_CSR 	OUT ERR_INF_CSR,    -- �G���[���J�[�\��
   iOPE_CD IN Varchar2,                      -- �I�y���[�^�R�[�h
  iPGM_ID IN Varchar2,                      -- �v���O����ID
  iDATE DATE                              -- �V�X�e������
	) RETURN NUMBER;
    
END;
/

CREATE OR REPLACE PACKAGE BODY NH010106B001_211
/* **********************************************************
 *  Copyright(c) 2011 beyond, INTEC Inc. All rights reserved.
 * **********************************************************/
IS
	/*
	 ************************************************************************
	 * Function ID  : CREATE_KGF_KIHON
	 * Program Name : KGF��{ �f��DB�f�[�^�̍쐬
	 * Parameter    :  <I> iLayoutKind	    	�F���C�A�E�g�敪
	 *		   		   <I> iShimeKind	    	�F���ߓ��敪
	 *				   <I> dcfShisetsu	    	�F���R�[�hID
	 *				   <I> iOPE_CD		        �F�I�y���[�^�R�[�h
	 *				   <I> iPGM_ID		        �F�v���O����ID
	 *				   <I> iDATE		        �F�V�X�e������ 
	 *		           <I> iIP_ADDR		        �F���s�[��IP�A�h���X
	 *		           <I> iWINDOWS_LOGIN_USER  �F���s�[��IP�A�h���X
	 *                 <O> oROW_COUNT		    �F�X�V����
	 *                <O> oOUT_ERR_INF_CSR	�F�G���[���J�[�\��
	 * Return       �F�������ʁi0:����I���A1:�ُ�I���j
	 ************************************************************************
	 */
	FUNCTION CREATE_KGF_KIHON(
	iLayoutKind	IN	INTEGER,										-- ���C�A�E�g�敪
	iShimeKind	IN	INTEGER,										-- ���ߓ��敪
        dcfShisetsu	IN	VARCHAR2,										-- ���R�[�hID
	iIP_ADDR	IN TL_STORED_SHORI.IP%TYPE,							-- ���s�[��IP�A�h���X (FW�Őݒ�)
	iWINDOWS_LOGIN_USER	IN TL_STORED_SHORI.WINDOWS_LOGIN_USER%TYPE, -- ���s�[��OS���[�U�[ (FW�Őݒ�)
	oROW_COUNT	OUT NUMBER,         -- �o�^����
	oOUT_ERR_INF_CSR 	OUT ERR_INF_CSR,    -- �G���[���J�[�\��
        iOPE_CD IN Varchar2,                      -- �I�y���[�^�R�[�h
        iPGM_ID IN Varchar2,                      -- �v���O����ID
        iDATE DATE                            -- �V�X�e������  
	)RETURN NUMBER IS
  
  PRAGMA AUTONOMOUS_TRANSACTION;
	/************************************************************************/
	/*                              �G���[����                              */
	/************************************************************************/
	W_INDEX_N 					NUMBER(10) := 0;
	W_ERR_INF_TBL 				TYPE_ERR_INFO_TBL := TYPE_ERR_INFO_TBL();
	W_ERR_INF_RCD 				TYPE_ERR_INFO_RCD := TYPE_ERR_INFO_RCD(NULL,NULL,NULL,NULL);
        vSQL VARCHAR2(200);
        vSchemaNm     TM_JOSU.HANYO_KOMOKU%TYPE := NULL; -- �X�L�[�}����
	PGM_ID        VARCHAR2(50) := 'NH010106B001_211.CREATE_KGF_KIHON';
	EXECUTE_SQL   VARCHAR2(32767) := NULL;  
        vSelectSQL    VARCHAR2(32767) := NULL; 

      BEGIN
      -- �J�n���O�o��
      ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'PL/SQL Start',PGM_ID || '�̏������J�n���܂��B',iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);
      -- �[�i�p�X�L�[�}�̎擾���s���B
      vSchemaNm := ULT_COMMON.GET_SCHEMA_NAME(ULT_COMMON.SYS_ENV_JOSU_DAI_CD, ULT_COMMON.NOHIN_SHEMA_JOSU_SHO_CD);
      oROW_COUNT:= -1;

          --�V_�S��_KGF��{�e�[�u���̃f�[�^���N���A����B
          EXECUTE_SQL := 'TRUNCATE TABLE ' || vSchemaNm || '.' || 'TD_NA_KGF';
          EXECUTE IMMEDIATE EXECUTE_SQL;
          ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);
          INSERT INTO TD_NA_KGF(											
	        SHIREC_ID,												
                SHI_CD,												
                SHI_CD_YOBI,												
                RYKSK_MEISYO_KANJI,												
                IPPAN_FLG,												
                IPPAN_UCHI_1_KNG_SBT,												
                IPPAN_UCHI_1_BYOTO_SU,												
                IPPAN_UCHI_1_BED_SU,												
                IPPAN_UCHI_1_SHONIN_YMD_Y,												
                IPPAN_UCHI_1_SHONIN_YMD_M,												
                IPPAN_UCHI_1_SHONIN_YMD_D,												
                IPPAN_UCHI_2_KNG_SBT,												
                IPPAN_UCHI_2_BYOTO_SU,												
                IPPAN_UCHI_2_BED_SU,												
                IPPAN_UCHI_2_SHONIN_YMD_Y,												
                IPPAN_UCHI_2_SHONIN_YMD_M,												
                IPPAN_UCHI_2_SHONIN_YMD_D,												
                IPPAN_UCHI_3_KNG_SBT,												
                IPPAN_UCHI_3_BYOTO_SU,												
                IPPAN_UCHI_3_BED_SU,												
                IPPAN_UCHI_3_SHONIN_YMD_Y,												
                IPPAN_UCHI_3_SHONIN_YMD_M,												
                IPPAN_UCHI_3_SHONIN_YMD_D,												
                IPPAN_UCHI_4_KNG_SBT,												
                IPPAN_UCHI_4_BYOTO_SU,												
                IPPAN_UCHI_4_BED_SU,												
                IPPAN_UCHI_4_SHONIN_YMD_Y,												
                IPPAN_UCHI_4_SHONIN_YMD_M,												
                IPPAN_UCHI_4_SHONIN_YMD_D,												
                IPPAN_UCHI_5_KNG_SBT,												
                IPPAN_UCHI_5_BYOTO_SU,												
                IPPAN_UCHI_5_BED_SU,												
                IPPAN_UCHI_5_SHONIN_YMD_Y,												
                IPPAN_UCHI_5_SHONIN_YMD_M,												
                IPPAN_UCHI_5_SHONIN_YMD_D,												
                IPPAN_UCHI_6_KNG_SBT,												
                IPPAN_UCHI_6_BYOTO_SU,												
                IPPAN_UCHI_6_BED_SU,												
                IPPAN_UCHI_6_SHONIN_YMD_Y,												
                IPPAN_UCHI_6_SHONIN_YMD_M,												
                IPPAN_UCHI_6_SHONIN_YMD_D,												
                IPPAN_GOKEI_KNG_SBT_SU,												
                IPPAN_GOKEI_BYOTO_SU,												
                IPPAN_GOKEI_BED_SU,												
                SEISHIN_FLG,												
                SEISHIN_UCHI_1_KNG_SBT,												
                SEISHIN_UCHI_1_BYOTO_SU,												
                SEISHIN_UCHI_1_BED_SU,												
                SEISHIN_UCHI_1_SHONIN_YMD_Y,												
                SEISHIN_UCHI_1_SHONIN_YMD_M,												
                SEISHIN_UCHI_1_SHONIN_YMD_D,												
                SEISHIN_UCHI_2_KNG_SBT,												
                SEISHIN_UCHI_2_BYOTO_SU,												
                SEISHIN_UCHI_2_BED_SU,												
                SEISHIN_UCHI_2_SHONIN_YMD_Y,												
                SEISHIN_UCHI_2_SHONIN_YMD_M,												
                SEISHIN_UCHI_2_SHONIN_YMD_D,												
                SEISHIN_UCHI_3_KNG_SBT,												
                SEISHIN_UCHI_3_BYOTO_SU,												
                SEISHIN_UCHI_3_BED_SU,												
                SEISHIN_UCHI_3_SHONIN_YMD_Y,												
                SEISHIN_UCHI_3_SHONIN_YMD_M,												
                SEISHIN_UCHI_3_SHONIN_YMD_D,												
                SEISHIN_UCHI_4_KNG_SBT,												
                SEISHIN_UCHI_4_BYOTO_SU,												
                SEISHIN_UCHI_4_BED_SU,												
                SEISHIN_UCHI_4_SHONIN_YMD_Y,												
                SEISHIN_UCHI_4_SHONIN_YMD_M,												
                SEISHIN_UCHI_4_SHONIN_YMD_D,												
                SEISHIN_UCHI_5_KNG_SBT,												
                SEISHIN_UCHI_5_BYOTO_SU,												
                SEISHIN_UCHI_5_BED_SU,												
                SEISHIN_UCHI_5_SHONIN_YMD_Y,												
                SEISHIN_UCHI_5_SHONIN_YMD_M,												
                SEISHIN_UCHI_5_SHONIN_YMD_D,												
                SEISHIN_UCHI_6_KNG_SBT,												
                SEISHIN_UCHI_6_BYOTO_SU,												
                SEISHIN_UCHI_6_BED_SU,												
                SEISHIN_UCHI_6_SHONIN_YMD_Y,												
                SEISHIN_UCHI_6_SHONIN_YMD_M,												
                SEISHIN_UCHI_6_SHONIN_YMD_D,												
                SEISHIN_GOKEI_KNG_SBT_SU,												
                SEISHIN_GOKEI_BYOTO_SU,												
                SEISHIN_GOKEI_BED_SU,												
                KEKKAKU_FLG,												
                KEKKAKU_UCHI_1_KNG_SBT,												
                KEKKAKU_UCHI_1_BYOTO_SU,												
                KEKKAKU_UCHI_1_BED_SU,												
                KEKKAKU_UCHI_1_SHONIN_YMD_Y,												
                KEKKAKU_UCHI_1_SHONIN_YMD_M,												
                KEKKAKU_UCHI_1_SHONIN_YMD_D,												
                KEKKAKU_UCHI_2_KNG_SBT,												
                KEKKAKU_UCHI_2_BYOTO_SU,												
                KEKKAKU_UCHI_2_BED_SU,												
                KEKKAKU_UCHI_2_SHONIN_YMD_Y,												
                KEKKAKU_UCHI_2_SHONIN_YMD_M,												
                KEKKAKU_UCHI_2_SHONIN_YMD_D,												
                KEKKAKU_UCHI_3_KNG_SBT,												
                KEKKAKU_UCHI_3_BYOTO_SU,												
                KEKKAKU_UCHI_3_BED_SU,												
                KEKKAKU_UCHI_3_SHONIN_YMD_Y,												
                KEKKAKU_UCHI_3_SHONIN_YMD_M,												
                KEKKAKU_UCHI_3_SHONIN_YMD_D,												
                KEKKAKU_UCHI_4_KNG_SBT,												
                KEKKAKU_UCHI_4_BYOTO_SU,												
                KEKKAKU_UCHI_4_BED_SU,												
                KEKKAKU_UCHI_4_SHONIN_YMD_Y,												
                KEKKAKU_UCHI_4_SHONIN_YMD_M,												
                KEKKAKU_UCHI_4_SHONIN_YMD_D,												
                KEKKAKU_GOKEI_KNG_SBT_SU,												
                KEKKAKU_GOKEI_BYOTO_SU,												
                KEKKAKU_GOKEI_BED_SU,												
                SONOTA_1_KNG_SBT,												
                SONOTA_1_BED_SU,												
                SONOTA_2_KNG_SBT,												
                SONOTA_2_BED_SU,												
                SONOTA_3_KNG_SBT,												
                SONOTA_3_BED_SU,												
                SONOTA_4_KNG_SBT,												
                SONOTA_4_BED_SU,												
                SONOTA_5_KNG_SBT,												
                SONOTA_5_BED_SU,												
                SONOTA_6_KNG_SBT,												
                SONOTA_6_BED_SU,												
                SONOTA_7_KNG_SBT,												
                SONOTA_7_BED_SU,												
                SONOTA_8_KNG_SBT,												
                SONOTA_8_BED_SU,												
                RYOYO_BED_SU,												
                ROJIN_BED_SU,												
                KANSEN_SU,												
                HANSEN_BED_SU,												
                YOBI_1,												
                GAISOSHIN_FLG,												
                GAISOSHIN_JURI_YMD_Y,												
                GAISOSHIN_JURI_YMD_M,												
                GAISOSHIN_JURI_YMD_D,												
                GAISOSHIN_CANCEL_YMD_Y,												
                GAISOSHIN_CANCEL_YMD_M,												
                GAISOSHIN_CANCEL_YMD_D,												
                GAISOSHIN_SAIJURI_YMD_Y,												
                GAISOSHIN_SAIJURI_YMD_M,												
                GAISOSHIN_SAIJURI_YMD_D,												
                YOBI_2,												
                LOT,
                TRK_OPE_CD,
                TRK_DATE,
                TRK_PGM_ID,
                UPD_OPE_CD,
                UPD_DATE,
                UPD_PGM_ID)
        SELECT	
                A.REC_ID,
	        A.SHI_CD,
	        NULL,
	        B.SHI_RN,
	        CASE WHEN (A.IPPAN_1_KNG_SBT_CD IS NOT NULL OR A.IPPAN_1_BED_SU IS NOT NULL OR A.IPPAN_1_SHONIN_YMD IS NOT NULL 
                OR A.IPPAN_2_KNG_SBT_CD IS NOT NULL OR A.IPPAN_2_BED_SU IS NOT NULL OR A.IPPAN_2_SHONIN_YMD IS NOT NULL 
                OR A.IPPAN_3_KNG_SBT_CD IS NOT NULL OR A.IPPAN_3_BED_SU IS NOT NULL OR A.IPPAN_3_SHONIN_YMD IS NOT NULL 
                OR A.IPPAN_4_KNG_SBT_CD IS NOT NULL OR A.IPPAN_4_BED_SU IS NOT NULL OR A.IPPAN_4_SHONIN_YMD IS NOT NULL 
                OR A.IPPAN_5_KNG_SBT_CD IS NOT NULL OR A.IPPAN_5_BED_SU IS NOT NULL OR A.IPPAN_5_SHONIN_YMD IS NOT NULL 
                OR A.IPPAN_6_KNG_SBT_CD IS NOT NULL OR A.IPPAN_6_BED_SU IS NOT NULL OR A.IPPAN_6_SHONIN_YMD IS NOT NULL) THEN 1 ELSE NULL END,
	        A.IPPAN_1_KNG_SBT_CD,
	        NULL,
                A.IPPAN_1_BED_SU,
	        SUBSTR(A.IPPAN_1_SHONIN_YMD,1,4),
                SUBSTR(A.IPPAN_1_SHONIN_YMD,5,2),
                SUBSTR(A.IPPAN_1_SHONIN_YMD,7,2),
                A.IPPAN_2_KNG_SBT_CD,
	        NULL,
                A.IPPAN_2_BED_SU,
	        SUBSTR(A.IPPAN_2_SHONIN_YMD,1,4),
                SUBSTR(A.IPPAN_2_SHONIN_YMD,5,2),
                SUBSTR(A.IPPAN_2_SHONIN_YMD,7,2),
                A.IPPAN_3_KNG_SBT_CD,
	        NULL,
                A.IPPAN_3_BED_SU,
	        SUBSTR(A.IPPAN_3_SHONIN_YMD,1,4),
                SUBSTR(A.IPPAN_3_SHONIN_YMD,5,2),
                SUBSTR(A.IPPAN_3_SHONIN_YMD,7,2),
                A.IPPAN_4_KNG_SBT_CD,
	        NULL,
                A.IPPAN_4_BED_SU,
	        SUBSTR(A.IPPAN_4_SHONIN_YMD,1,4),
                SUBSTR(A.IPPAN_4_SHONIN_YMD,5,2),
                SUBSTR(A.IPPAN_4_SHONIN_YMD,7,2),
                A.IPPAN_5_KNG_SBT_CD,
	        NULL,
                A.IPPAN_5_BED_SU,
	        SUBSTR(A.IPPAN_5_SHONIN_YMD,1,4),
                SUBSTR(A.IPPAN_5_SHONIN_YMD,5,2),
                SUBSTR(A.IPPAN_5_SHONIN_YMD,7,2),
                A.IPPAN_6_KNG_SBT_CD,
	        NULL,
                A.IPPAN_6_BED_SU,
	        SUBSTR(A.IPPAN_6_SHONIN_YMD,1,4),
                SUBSTR(A.IPPAN_6_SHONIN_YMD,5,2),
                SUBSTR(A.IPPAN_6_SHONIN_YMD,7,2),
                A.IPPANKEI_KNG_SBT_SU,
                NULL,
	        A.IPPANKEI_BED_SU,
                CASE WHEN (A.SEISHIN_1_KNG_SBT_CD IS NOT NULL OR A.SEISHIN_1_BED_SU IS NOT NULL OR A.SEISHIN_1_SHONIN_YMD IS NOT NULL 
                OR A.SEISHIN_2_KNG_SBT_CD IS NOT NULL OR A.SEISHIN_2_BED_SU IS NOT NULL OR A.SEISHIN_2_SHONIN_YMD IS NOT NULL
                OR A.SEISHIN_3_KNG_SBT_CD IS NOT NULL OR A.SEISHIN_3_BED_SU IS NOT NULL OR A.SEISHIN_3_SHONIN_YMD IS NOT NULL
                OR A.SEISHIN_4_KNG_SBT_CD IS NOT NULL OR A.SEISHIN_4_BED_SU IS NOT NULL OR A.SEISHIN_4_SHONIN_YMD IS NOT NULL
                OR A.SEISHIN_5_KNG_SBT_CD IS NOT NULL OR A.SEISHIN_5_BED_SU IS NOT NULL OR A.SEISHIN_5_SHONIN_YMD IS NOT NULL
                OR A.SEISHIN_6_KNG_SBT_CD IS NOT NULL OR A.SEISHIN_6_BED_SU IS NOT NULL OR A.SEISHIN_6_SHONIN_YMD IS NOT NULL) THEN 1 ELSE NULL END,
		A.SEISHIN_1_KNG_SBT_CD,
		NULL,
	        A.SEISHIN_1_BED_SU,
                SUBSTR(A.SEISHIN_1_SHONIN_YMD,1,4),
                SUBSTR(A.SEISHIN_1_SHONIN_YMD,5,2),
                SUBSTR(A.SEISHIN_1_SHONIN_YMD,7,2),
                A.SEISHIN_2_KNG_SBT_CD,
		NULL,
	        A.SEISHIN_2_BED_SU,
                SUBSTR(A.SEISHIN_2_SHONIN_YMD,1,4),
                SUBSTR(A.SEISHIN_2_SHONIN_YMD,5,2),
                SUBSTR(A.SEISHIN_2_SHONIN_YMD,7,2),
                A.SEISHIN_3_KNG_SBT_CD,
		NULL,
	        A.SEISHIN_3_BED_SU,
                SUBSTR(A.SEISHIN_3_SHONIN_YMD,1,4),
                SUBSTR(A.SEISHIN_3_SHONIN_YMD,5,2),
                SUBSTR(A.SEISHIN_3_SHONIN_YMD,7,2),
                A.SEISHIN_4_KNG_SBT_CD,
		NULL,
	        A.SEISHIN_4_BED_SU,
                SUBSTR(A.SEISHIN_4_SHONIN_YMD,1,4),
                SUBSTR(A.SEISHIN_4_SHONIN_YMD,5,2),
                SUBSTR(A.SEISHIN_4_SHONIN_YMD,7,2),
                A.SEISHIN_5_KNG_SBT_CD,
		NULL,
	        A.SEISHIN_5_BED_SU,
                SUBSTR(A.SEISHIN_5_SHONIN_YMD,1,4),
                SUBSTR(A.SEISHIN_5_SHONIN_YMD,5,2),
                SUBSTR(A.SEISHIN_5_SHONIN_YMD,7,2),
                A.SEISHIN_6_KNG_SBT_CD,
		NULL,
	        A.SEISHIN_6_BED_SU,
                SUBSTR(A.SEISHIN_6_SHONIN_YMD,1,4),
                SUBSTR(A.SEISHIN_6_SHONIN_YMD,5,2),
                SUBSTR(A.SEISHIN_6_SHONIN_YMD,7,2),
                A.SEISHINKEI_KNG_SBT_SU,
                NULL,
                A.SEISHINKEI_BED_SU,
                CASE WHEN (A.KEKKAKU_1_KNG_SBT_CD IS NOT NULL OR A.KEKKAKU_1_SHONIN_YMD IS NOT NULL OR A.KEKKAKU_1_BED_SU IS NOT NULL 
                OR A.KEKKAKU_2_KNG_SBT_CD IS NOT NULL OR A.KEKKAKU_2_SHONIN_YMD IS NOT NULL OR A.KEKKAKU_2_BED_SU IS NOT NULL 
                OR A.KEKKAKU_3_KNG_SBT_CD IS NOT NULL OR A.KEKKAKU_3_SHONIN_YMD IS NOT NULL OR A.KEKKAKU_3_BED_SU IS NOT NULL ) THEN 1 ELSE NULL END,
		A.KEKKAKU_1_KNG_SBT_CD,
		NULL,
	        A.KEKKAKU_1_BED_SU,
                SUBSTR(A.KEKKAKU_1_SHONIN_YMD,1,4),
                SUBSTR(A.KEKKAKU_1_SHONIN_YMD,5,2),
                SUBSTR(A.KEKKAKU_1_SHONIN_YMD,7,2),
                A.KEKKAKU_2_KNG_SBT_CD,
		NULL,
	        A.KEKKAKU_2_BED_SU,
                SUBSTR(A.KEKKAKU_2_SHONIN_YMD,1,4),
                SUBSTR(A.KEKKAKU_2_SHONIN_YMD,5,2),
                SUBSTR(A.KEKKAKU_2_SHONIN_YMD,7,2),
                A.KEKKAKU_3_KNG_SBT_CD,
		NULL,
	        A.KEKKAKU_3_BED_SU,
                SUBSTR(A.KEKKAKU_3_SHONIN_YMD,1,4),
                SUBSTR(A.KEKKAKU_3_SHONIN_YMD,5,2),
                SUBSTR(A.KEKKAKU_3_SHONIN_YMD,7,2),
                A.KEKKAKU_4_KNG_SBT_CD,
		NULL,
	        A.KEKKAKU_4_BED_SU,
                SUBSTR(A.KEKKAKU_4_SHONIN_YMD,1,4),
                SUBSTR(A.KEKKAKU_4_SHONIN_YMD,5,2),
                SUBSTR(A.KEKKAKU_4_SHONIN_YMD,7,2),
                A.KEKKAKUKEI_KNG_SBT_SU,
                NULL,
                A.KEKKAKUKEI_BED_SU,
                A.SONOTA_1_KNG_SBT_CD,
                A.SONOTA_1_BED_SU,
                A.SONOTA_2_KNG_SBT_CD,
                A.SONOTA_2_BED_SU,
                A.SONOTA_3_KNG_SBT_CD,
                A.SONOTA_3_BED_SU,
                A.SONOTA_4_KNG_SBT_CD,
                A.SONOTA_4_BED_SU,
                A.SONOTA_5_KNG_SBT_CD,
                A.SONOTA_5_BED_SU,
                A.SONOTA_6_KNG_SBT_CD,
                A.SONOTA_6_BED_SU,
                A.SONOTA_7_KNG_SBT_CD,
                A.SONOTA_7_BED_SU,
                A.SONOTA_8_KNG_SBT_CD,
                A.SONOTA_8_BED_SU,
                A.RYOYO_BED_SU,
                NULL,
                A.KANSEN_BED_SU,
                A.HANSEN_BED_SU,
                NULL,
                NULL,
                NULL,
                NULL,
                NULL,
                NULL,
                NULL,
                NULL,
                NULL,
                NULL,
                NULL,
                NULL,
                TRIM(A.KGF_LOT_NO),
                iOPE_CD,
                iDATE,
                iPGM_ID,
                iOPE_CD,
                iDATE,
                iPGM_ID
                FROM TT_TIKY_KGF_KNG A										
               INNER JOIN TT_TIKY_SHI B										
               ON A.REC_ID = B.REC_ID										
               AND A.SHI_CD = B.SHI_CD										
	       WHERE B.REC_ID = dcfShisetsu									
               AND B.DEL_FLG IS NULL									
               AND B.DEL_YOTEI_RIYU_CD IS NULL									
               AND A.DEL_FLG IS NULL
               AND (A.IPPAN_1_KNG_SBT_CD IS NOT NULL
                    OR A.IPPAN_1_BED_SU IS NOT NULL
                    OR A.IPPAN_1_KIFKK_IPPAN_RYOYO_KBN IS NOT NULL
                    OR A.IPPAN_1_SHONIN_YMD IS NOT NULL
                    OR A.IPPAN_1_MOD_EIGY_YMD IS NOT NULL
                    OR A.IPPAN_2_KNG_SBT_CD IS NOT NULL
                    OR A.IPPAN_2_BED_SU IS NOT NULL
                    OR A.IPPAN_2_KIFKK_IPPAN_RYOYO_KBN IS NOT NULL
                    OR A.IPPAN_2_SHONIN_YMD IS NOT NULL
                    OR A.IPPAN_2_MOD_EIGY_YMD IS NOT NULL
                    OR A.IPPAN_3_KNG_SBT_CD IS NOT NULL
                    OR A.IPPAN_3_BED_SU IS NOT NULL
                    OR A.IPPAN_3_KIFKK_IPPAN_RYOYO_KBN IS NOT NULL
                    OR A.IPPAN_3_SHONIN_YMD IS NOT NULL
                    OR A.IPPAN_3_MOD_EIGY_YMD IS NOT NULL
                    OR A.IPPAN_4_KNG_SBT_CD IS NOT NULL
                    OR A.IPPAN_4_BED_SU IS NOT NULL
                    OR A.IPPAN_4_KIFKK_IPPAN_RYOYO_KBN IS NOT NULL
                    OR A.IPPAN_4_SHONIN_YMD IS NOT NULL
                    OR A.IPPAN_4_MOD_EIGY_YMD IS NOT NULL
                    OR A.IPPAN_5_KNG_SBT_CD IS NOT NULL
                    OR A.IPPAN_5_BED_SU IS NOT NULL
                    OR A.IPPAN_5_KIFKK_IPPAN_RYOYO_KBN IS NOT NULL
                    OR A.IPPAN_5_SHONIN_YMD IS NOT NULL
                    OR A.IPPAN_5_MOD_EIGY_YMD IS NOT NULL
                    OR A.IPPAN_6_KNG_SBT_CD IS NOT NULL
                    OR A.IPPAN_6_BED_SU IS NOT NULL
                    OR A.IPPAN_6_KIFKK_IPPAN_RYOYO_KBN IS NOT NULL
                    OR A.IPPAN_6_SHONIN_YMD IS NOT NULL
                    OR A.IPPAN_6_MOD_EIGY_YMD IS NOT NULL
                    OR A.SEISHIN_1_KNG_SBT_CD IS NOT NULL
                    OR A.SEISHIN_1_BED_SU IS NOT NULL
                    OR A.SEISHIN_1_SHONIN_YMD IS NOT NULL
                    OR A.SEISHIN_1_MOD_EIGY_YMD IS NOT NULL
                    OR A.SEISHIN_2_KNG_SBT_CD IS NOT NULL
                    OR A.SEISHIN_2_BED_SU IS NOT NULL
                    OR A.SEISHIN_2_SHONIN_YMD IS NOT NULL
                    OR A.SEISHIN_2_MOD_EIGY_YMD IS NOT NULL
                    OR A.SEISHIN_3_KNG_SBT_CD IS NOT NULL
                    OR A.SEISHIN_3_BED_SU IS NOT NULL
                    OR A.SEISHIN_3_SHONIN_YMD IS NOT NULL
                    OR A.SEISHIN_3_MOD_EIGY_YMD IS NOT NULL
                    OR A.SEISHIN_4_KNG_SBT_CD IS NOT NULL
                    OR A.SEISHIN_4_BED_SU IS NOT NULL
                    OR A.SEISHIN_4_SHONIN_YMD IS NOT NULL
                    OR A.SEISHIN_4_MOD_EIGY_YMD IS NOT NULL
                    OR A.SEISHIN_5_KNG_SBT_CD IS NOT NULL
                    OR A.SEISHIN_5_BED_SU IS NOT NULL
                    OR A.SEISHIN_5_SHONIN_YMD IS NOT NULL
                    OR A.SEISHIN_5_MOD_EIGY_YMD IS NOT NULL
                    OR A.SEISHIN_6_KNG_SBT_CD IS NOT NULL
                    OR A.SEISHIN_6_BED_SU IS NOT NULL
                    OR A.SEISHIN_6_SHONIN_YMD IS NOT NULL
                    OR A.SEISHIN_6_MOD_EIGY_YMD IS NOT NULL
                    OR A.KEKKAKU_1_KNG_SBT_CD IS NOT NULL
                    OR A.KEKKAKU_1_BED_SU IS NOT NULL
                    OR A.KEKKAKU_1_SHONIN_YMD IS NOT NULL
                    OR A.KEKKAKU_1_MOD_EIGY_YMD IS NOT NULL
                    OR A.KEKKAKU_2_KNG_SBT_CD IS NOT NULL
                    OR A.KEKKAKU_2_BED_SU IS NOT NULL
                    OR A.KEKKAKU_2_SHONIN_YMD IS NOT NULL
                    OR A.KEKKAKU_2_MOD_EIGY_YMD IS NOT NULL
                    OR A.KEKKAKU_3_KNG_SBT_CD IS NOT NULL
                    OR A.KEKKAKU_3_BED_SU IS NOT NULL
                    OR A.KEKKAKU_3_SHONIN_YMD IS NOT NULL
                    OR A.KEKKAKU_3_MOD_EIGY_YMD IS NOT NULL
                    OR A.KEKKAKU_4_KNG_SBT_CD IS NOT NULL
                    OR A.KEKKAKU_4_BED_SU IS NOT NULL
                    OR A.KEKKAKU_4_SHONIN_YMD IS NOT NULL
                    OR A.KEKKAKU_4_MOD_EIGY_YMD IS NOT NULL
                    OR A.SONOTA_1_KNG_SBT_CD IS NOT NULL
                    OR A.SONOTA_1_KBN_1 IS NOT NULL
                    OR A.SONOTA_1_KBN_2 IS NOT NULL
                    OR A.SONOTA_1_BED_SU IS NOT NULL
                    OR A.SONOTA_1_KIFKK_IPPAN_RYOYO_KBN IS NOT NULL
                    OR A.SONOTA_1_MOD_EIGY_YMD IS NOT NULL
                    OR A.SONOTA_2_KNG_SBT_CD IS NOT NULL
                    OR A.SONOTA_2_KBN_1 IS NOT NULL
                    OR A.SONOTA_2_KBN_2 IS NOT NULL
                    OR A.SONOTA_2_BED_SU IS NOT NULL
                    OR A.SONOTA_2_KIFKK_IPPAN_RYOYO_KBN IS NOT NULL
                    OR A.SONOTA_2_MOD_EIGY_YMD IS NOT NULL
                    OR A.SONOTA_3_KNG_SBT_CD IS NOT NULL
                    OR A.SONOTA_3_KBN_1 IS NOT NULL
                    OR A.SONOTA_3_KBN_2 IS NOT NULL
                    OR A.SONOTA_3_BED_SU IS NOT NULL
                    OR A.SONOTA_3_KIFKK_IPPAN_RYOYO_KBN IS NOT NULL
                    OR A.SONOTA_3_MOD_EIGY_YMD IS NOT NULL
                    OR A.SONOTA_4_KNG_SBT_CD IS NOT NULL
                    OR A.SONOTA_4_KBN_1 IS NOT NULL
                    OR A.SONOTA_4_KBN_2 IS NOT NULL
                    OR A.SONOTA_4_BED_SU IS NOT NULL
                    OR A.SONOTA_4_KIFKK_IPPAN_RYOYO_KBN IS NOT NULL
                    OR A.SONOTA_4_MOD_EIGY_YMD IS NOT NULL
                    OR A.SONOTA_5_KNG_SBT_CD IS NOT NULL
                    OR A.SONOTA_5_KBN_1 IS NOT NULL
                    OR A.SONOTA_5_KBN_2 IS NOT NULL
                    OR A.SONOTA_5_BED_SU IS NOT NULL
                    OR A.SONOTA_5_KIFKK_IPPAN_RYOYO_KBN IS NOT NULL
                    OR A.SONOTA_5_MOD_EIGY_YMD IS NOT NULL
                    OR A.SONOTA_6_KNG_SBT_CD IS NOT NULL
                    OR A.SONOTA_6_KBN_1 IS NOT NULL
                    OR A.SONOTA_6_KBN_2 IS NOT NULL
                    OR A.SONOTA_6_BED_SU IS NOT NULL
                    OR A.SONOTA_6_KIFKK_IPPAN_RYOYO_KBN IS NOT NULL
                    OR A.SONOTA_6_MOD_EIGY_YMD IS NOT NULL
                    OR A.SONOTA_7_KNG_SBT_CD IS NOT NULL
                    OR A.SONOTA_7_KBN_1 IS NOT NULL
                    OR A.SONOTA_7_KBN_2 IS NOT NULL
                    OR A.SONOTA_7_BED_SU IS NOT NULL
                    OR A.SONOTA_7_KIFKK_IPPAN_RYOYO_KBN IS NOT NULL
                    OR A.SONOTA_7_MOD_EIGY_YMD IS NOT NULL
                    OR A.SONOTA_8_KNG_SBT_CD IS NOT NULL
                    OR A.SONOTA_8_KBN_1 IS NOT NULL
                    OR A.SONOTA_8_KBN_2 IS NOT NULL
                    OR A.SONOTA_8_BED_SU IS NOT NULL
                    OR A.SONOTA_8_KIFKK_IPPAN_RYOYO_KBN IS NOT NULL
                    OR A.SONOTA_8_MOD_EIGY_YMD IS NOT NULL
                    OR A.RYOYO_BED_SU IS NOT NULL
                    OR A.RYOYO_MOD_EIGY_YMD IS NOT NULL
                    OR A.KANSEN_BED_SU IS NOT NULL
                    OR A.KANSEN_MOD_EIGY_YMD IS NOT NULL
                    OR A.HANSEN_BED_SU IS NOT NULL
                    OR A.HANSEN_MOD_EIGY_YMD IS NOT NULL);
            EXECUTE_SQL :=  'INSERT INTO TD_NA_KGF(		'||									
	        'SHIREC_ID,					'||							
                'SHI_CD,					'||							
                'SHI_CD_YOBI,					'||							
                'RYKSK_MEISYO_KANJI,				'||								
                'IPPAN_FLG,					'||							
                'IPPAN_UCHI_1_KNG_SBT,				'||								
                'IPPAN_UCHI_1_BYOTO_SU,				'||								
                'IPPAN_UCHI_1_BED_SU,				'||								
                'IPPAN_UCHI_1_SHONIN_YMD_Y,			'||									
                'IPPAN_UCHI_1_SHONIN_YMD_M,			'||									
                'IPPAN_UCHI_1_SHONIN_YMD_D,			'||									
                'IPPAN_UCHI_2_KNG_SBT,				'||								
                'IPPAN_UCHI_2_BYOTO_SU,				'||								
                'IPPAN_UCHI_2_BED_SU,				'||								
                'IPPAN_UCHI_2_SHONIN_YMD_Y,			'||									
                'IPPAN_UCHI_2_SHONIN_YMD_M,			'||									
                'IPPAN_UCHI_2_SHONIN_YMD_D,			'||									
                'IPPAN_UCHI_3_KNG_SBT,				'||								
                'IPPAN_UCHI_3_BYOTO_SU,				'||								
                'IPPAN_UCHI_3_BED_SU,				'||								
                'IPPAN_UCHI_3_SHONIN_YMD_Y,			'||									
                'IPPAN_UCHI_3_SHONIN_YMD_M,			'||									
                'IPPAN_UCHI_3_SHONIN_YMD_D,			'||									
                'IPPAN_UCHI_4_KNG_SBT,				'||								
                'IPPAN_UCHI_4_BYOTO_SU,				'||								
                'IPPAN_UCHI_4_BED_SU,				'||								
                'IPPAN_UCHI_4_SHONIN_YMD_Y,			'||									
                'IPPAN_UCHI_4_SHONIN_YMD_M,			'||									
                'IPPAN_UCHI_4_SHONIN_YMD_D,			'||									
                'IPPAN_UCHI_5_KNG_SBT,				'||								
                'IPPAN_UCHI_5_BYOTO_SU,				'||								
                'IPPAN_UCHI_5_BED_SU,				'||								
                'IPPAN_UCHI_5_SHONIN_YMD_Y,			'||									
                'IPPAN_UCHI_5_SHONIN_YMD_M,			'||									
                'IPPAN_UCHI_5_SHONIN_YMD_D,			'||									
                'IPPAN_UCHI_6_KNG_SBT,				'||								
                'IPPAN_UCHI_6_BYOTO_SU,				'||								
                'IPPAN_UCHI_6_BED_SU,				'||								
                'IPPAN_UCHI_6_SHONIN_YMD_Y,			'||									
                'IPPAN_UCHI_6_SHONIN_YMD_M,			'||									
                'IPPAN_UCHI_6_SHONIN_YMD_D,			'||									
                'IPPAN_GOKEI_KNG_SBT_SU,			'||									
                'IPPAN_GOKEI_BYOTO_SU,				'||								
                'IPPAN_GOKEI_BED_SU,				'||								
                'SEISHIN_FLG,					'||							
                'SEISHIN_UCHI_1_KNG_SBT,			'||									
                'SEISHIN_UCHI_1_BYOTO_SU,			'||									
                'SEISHIN_UCHI_1_BED_SU,				'||								
                'SEISHIN_UCHI_1_SHONIN_YMD_Y,			'||									
                'SEISHIN_UCHI_1_SHONIN_YMD_M,			'||									
                'SEISHIN_UCHI_1_SHONIN_YMD_D,			'||									
                'SEISHIN_UCHI_2_KNG_SBT,			'||									
                'SEISHIN_UCHI_2_BYOTO_SU,			'||									
                'SEISHIN_UCHI_2_BED_SU,				'||								
                'SEISHIN_UCHI_2_SHONIN_YMD_Y,			'||									
                'SEISHIN_UCHI_2_SHONIN_YMD_M,			'||									
                'SEISHIN_UCHI_2_SHONIN_YMD_D,			'||									
                'SEISHIN_UCHI_3_KNG_SBT,			'||									
                'SEISHIN_UCHI_3_BYOTO_SU,			'||									
                'SEISHIN_UCHI_3_BED_SU,				'||								
                'SEISHIN_UCHI_3_SHONIN_YMD_Y,			'||									
                'SEISHIN_UCHI_3_SHONIN_YMD_M,			'||									
                'SEISHIN_UCHI_3_SHONIN_YMD_D,			'||									
                'SEISHIN_UCHI_4_KNG_SBT,			'||									
                'SEISHIN_UCHI_4_BYOTO_SU,			'||									
                'SEISHIN_UCHI_4_BED_SU,				'||								
                'SEISHIN_UCHI_4_SHONIN_YMD_Y,			'||									
                'SEISHIN_UCHI_4_SHONIN_YMD_M,			'||									
                'SEISHIN_UCHI_4_SHONIN_YMD_D,			'||									
                'SEISHIN_UCHI_5_KNG_SBT,			'||									
                'SEISHIN_UCHI_5_BYOTO_SU,			'||									
                'SEISHIN_UCHI_5_BED_SU,				'||								
                'SEISHIN_UCHI_5_SHONIN_YMD_Y,			'||									
                'SEISHIN_UCHI_5_SHONIN_YMD_M,			'||									
                'SEISHIN_UCHI_5_SHONIN_YMD_D,			'||									
                'SEISHIN_UCHI_6_KNG_SBT,			'||									
                'SEISHIN_UCHI_6_BYOTO_SU,			'||									
                'SEISHIN_UCHI_6_BED_SU,				'||								
                'SEISHIN_UCHI_6_SHONIN_YMD_Y,			'||									
                'SEISHIN_UCHI_6_SHONIN_YMD_M,			'||									
                'SEISHIN_UCHI_6_SHONIN_YMD_D,			'||									
                'SEISHIN_GOKEI_KNG_SBT_SU,			'||									
                'SEISHIN_GOKEI_BYOTO_SU,			'||									
                'SEISHIN_GOKEI_BED_SU,				'||								
                'KEKKAKU_FLG,					'||							
                'KEKKAKU_UCHI_1_KNG_SBT,			'||									
                'KEKKAKU_UCHI_1_BYOTO_SU,			'||									
                'KEKKAKU_UCHI_1_BED_SU,				'||								
                'KEKKAKU_UCHI_1_SHONIN_YMD_Y,			'||									
                'KEKKAKU_UCHI_1_SHONIN_YMD_M,			'||									
                'KEKKAKU_UCHI_1_SHONIN_YMD_D,			'||									
                'KEKKAKU_UCHI_2_KNG_SBT,			'||									
                'KEKKAKU_UCHI_2_BYOTO_SU,			'||									
                'KEKKAKU_UCHI_2_BED_SU,				'||								
                'KEKKAKU_UCHI_2_SHONIN_YMD_Y,			'||									
                'KEKKAKU_UCHI_2_SHONIN_YMD_M,			'||									
                'KEKKAKU_UCHI_2_SHONIN_YMD_D,			'||									
                'KEKKAKU_UCHI_3_KNG_SBT,			'||									
                'KEKKAKU_UCHI_3_BYOTO_SU,			'||									
                'KEKKAKU_UCHI_3_BED_SU,				'||								
                'KEKKAKU_UCHI_3_SHONIN_YMD_Y,			'||									
                'KEKKAKU_UCHI_3_SHONIN_YMD_M,			'||									
                'KEKKAKU_UCHI_3_SHONIN_YMD_D,			'||									
                'KEKKAKU_UCHI_4_KNG_SBT,			'||									
                'KEKKAKU_UCHI_4_BYOTO_SU,			'||									
                'KEKKAKU_UCHI_4_BED_SU,				'||								
                'KEKKAKU_UCHI_4_SHONIN_YMD_Y,			'||									
                'KEKKAKU_UCHI_4_SHONIN_YMD_M,			'||									
                'KEKKAKU_UCHI_4_SHONIN_YMD_D,			'||									
                'KEKKAKU_GOKEI_KNG_SBT_SU,			'||									
                'KEKKAKU_GOKEI_BYOTO_SU,			'||									
                'KEKKAKU_GOKEI_BED_SU,				'||								
                'SONOTA_1_KNG_SBT,				'||								
                'SONOTA_1_BED_SU,				'||								
                'SONOTA_2_KNG_SBT,				'||								
                'SONOTA_2_BED_SU,				'||								
                'SONOTA_3_KNG_SBT,				'||								
                'SONOTA_3_BED_SU,				'||								
                'SONOTA_4_KNG_SBT,				'||								
                'SONOTA_4_BED_SU,				'||								
                'SONOTA_5_KNG_SBT,				'||								
                'SONOTA_5_BED_SU,				'||								
                'SONOTA_6_KNG_SBT,				'||								
                'SONOTA_6_BED_SU,				'||								
                'SONOTA_7_KNG_SBT,				'||								
                'SONOTA_7_BED_SU,				'||								
                'SONOTA_8_KNG_SBT,				'||								
                'SONOTA_8_BED_SU,				'||								
                'RYOYO_BED_SU,					'||							
                'ROJIN_BED_SU,					'||							
                'KANSEN_SU,					'||							
                'HANSEN_BED_SU,					'||							
                'YOBI_1,					'||							
                'GAISOSHIN_FLG,					'||							
                'GAISOSHIN_JURI_YMD_Y,				'||								
                'GAISOSHIN_JURI_YMD_M,				'||								
                'GAISOSHIN_JURI_YMD_D,				'||								
                'GAISOSHIN_CANCEL_YMD_Y,			'||									
                'GAISOSHIN_CANCEL_YMD_M,			'||									
                'GAISOSHIN_CANCEL_YMD_D,			'||									
                'GAISOSHIN_SAIJURI_YMD_Y,			'||									
                'GAISOSHIN_SAIJURI_YMD_M,			'||									
                'GAISOSHIN_SAIJURI_YMD_D,			'||									
                'YOBI_2,					'||							
                'LOT,'||
                'TRK_OPE_CD,'||
                'TRK_DATE,'||
                'TRK_PGM_ID,'||
                'UPD_OPE_CD,'||
                'UPD_DATE,'||
                'UPD_PGM_ID)'||
        'SELECT	'||
                'A.REC_ID,'||
	        'A.SHI_CD,'||
	        'NULL,'||
	        'B.SHI_RN,'||
	        'CASE WHEN (A.IPPAN_1_KNG_SBT_CD IS NOT NULL OR A.IPPAN_1_BED_SU IS NOT NULL OR A.IPPAN_1_SHONIN_YMD IS NOT NULL '||
                'OR A.IPPAN_2_KNG_SBT_CD IS NOT NULL OR A.IPPAN_2_BED_SU IS NOT NULL OR A.IPPAN_2_SHONIN_YMD IS NOT NULL '||
                'OR A.IPPAN_3_KNG_SBT_CD IS NOT NULL OR A.IPPAN_3_BED_SU IS NOT NULL OR A.IPPAN_3_SHONIN_YMD IS NOT NULL '||
                'OR A.IPPAN_4_KNG_SBT_CD IS NOT NULL OR A.IPPAN_4_BED_SU IS NOT NULL OR A.IPPAN_4_SHONIN_YMD IS NOT NULL '||
                'OR A.IPPAN_5_KNG_SBT_CD IS NOT NULL OR A.IPPAN_5_BED_SU IS NOT NULL OR A.IPPAN_5_SHONIN_YMD IS NOT NULL '||
                'OR A.IPPAN_6_KNG_SBT_CD IS NOT NULL OR A.IPPAN_6_BED_SU IS NOT NULL OR A.IPPAN_6_SHONIN_YMD IS NOT NULL) THEN 1 ELSE NULL END,'||
	        'A.IPPAN_1_KNG_SBT_CD,'||
	        'NULL,'||
                'A.IPPAN_1_BED_SU,'||
	        'SUBSTR(A.IPPAN_1_SHONIN_YMD,1,4),'||
                'SUBSTR(A.IPPAN_1_SHONIN_YMD,5,2),'||
                'SUBSTR(A.IPPAN_1_SHONIN_YMD,7,2),'||
                'A.IPPAN_2_KNG_SBT_CD,'||
	        'NULL,'||
                'A.IPPAN_2_BED_SU,'||
	        'SUBSTR(A.IPPAN_2_SHONIN_YMD,1,4),'||
                'SUBSTR(A.IPPAN_2_SHONIN_YMD,5,2),'||
                'SUBSTR(A.IPPAN_2_SHONIN_YMD,7,2),'||
                'A.IPPAN_3_KNG_SBT_CD,'||
	        'NULL,'||
                'A.IPPAN_3_BED_SU,'||
	        'SUBSTR(A.IPPAN_3_SHONIN_YMD,1,4),'||
                'SUBSTR(A.IPPAN_3_SHONIN_YMD,5,2),'||
                'SUBSTR(A.IPPAN_3_SHONIN_YMD,7,2),'||
                'A.IPPAN_4_KNG_SBT_CD,'||
	        'NULL,'||
                'A.IPPAN_4_BED_SU,'||
	        'SUBSTR(A.IPPAN_4_SHONIN_YMD,1,4),'||
                'SUBSTR(A.IPPAN_4_SHONIN_YMD,5,2),'||
                'SUBSTR(A.IPPAN_4_SHONIN_YMD,7,2),'||
                'A.IPPAN_5_KNG_SBT_CD,'||
	        'NULL,'||
                'A.IPPAN_5_BED_SU,'||
	        'SUBSTR(A.IPPAN_5_SHONIN_YMD,1,4),'||
                'SUBSTR(A.IPPAN_5_SHONIN_YMD,5,2),'||
                'SUBSTR(A.IPPAN_5_SHONIN_YMD,7,2),'||
                'A.IPPAN_6_KNG_SBT_CD,'||
	        'NULL,'||
                'A.IPPAN_6_BED_SU,'||
	        'SUBSTR(A.IPPAN_6_SHONIN_YMD,1,4),'||
                'SUBSTR(A.IPPAN_6_SHONIN_YMD,5,2),'||
                'SUBSTR(A.IPPAN_6_SHONIN_YMD,7,2),'||
                'A.IPPANKEI_KNG_SBT_SU,'||
                'NULL,'||
	        'A.IPPANKEI_BED_SU,'||
                'CASE WHEN (A.SEISHIN_1_KNG_SBT_CD IS NOT NULL OR A.SEISHIN_1_BED_SU IS NOT NULL OR A.SEISHIN_1_SHONIN_YMD IS NOT NULL '||
                'OR A.SEISHIN_2_KNG_SBT_CD IS NOT NULL OR A.SEISHIN_2_BED_SU IS NOT NULL OR A.SEISHIN_2_SHONIN_YMD IS NOT NULL'||
                'OR A.SEISHIN_3_KNG_SBT_CD IS NOT NULL OR A.SEISHIN_3_BED_SU IS NOT NULL OR A.SEISHIN_3_SHONIN_YMD IS NOT NULL'||
                'OR A.SEISHIN_4_KNG_SBT_CD IS NOT NULL OR A.SEISHIN_4_BED_SU IS NOT NULL OR A.SEISHIN_4_SHONIN_YMD IS NOT NULL'||
                'OR A.SEISHIN_5_KNG_SBT_CD IS NOT NULL OR A.SEISHIN_5_BED_SU IS NOT NULL OR A.SEISHIN_5_SHONIN_YMD IS NOT NULL'||
                'OR A.SEISHIN_6_KNG_SBT_CD IS NOT NULL OR A.SEISHIN_6_BED_SU IS NOT NULL OR A.SEISHIN_6_SHONIN_YMD IS NOT NULL) THEN 1 ELSE NULL END,'||
		'A.SEISHIN_1_KNG_SBT_CD,'||
		'NULL,'||
	        'A.SEISHIN_1_BED_SU,'||
                'SUBSTR(A.SEISHIN_1_SHONIN_YMD,1,4),'||
                'SUBSTR(A.SEISHIN_1_SHONIN_YMD,5,2),'||
                'SUBSTR(A.SEISHIN_1_SHONIN_YMD,7,2),'||
                'A.SEISHIN_2_KNG_SBT_CD,'||
		'NULL,'||
	        'A.SEISHIN_2_BED_SU,'||
                'SUBSTR(shiRow.SEISHIN_2_SHONIN_YMD,1,4),'||
                'SUBSTR(shiRow.SEISHIN_2_SHONIN_YMD,5,2),'||
                'SUBSTR(shiRow.SEISHIN_2_SHONIN_YMD,7,2),'||
                'A.SEISHIN_3_KNG_SBT_CD,'||
		'NULL,'||
	        'A.SEISHIN_3_BED_SU,'||
                'SUBSTR(A.SEISHIN_3_SHONIN_YMD,1,4),'||
                'SUBSTR(A.SEISHIN_3_SHONIN_YMD,5,2),'||
                'SUBSTR(A.SEISHIN_3_SHONIN_YMD,7,2),'||
                'A.SEISHIN_4_KNG_SBT_CD,'||
		'NULL,'||
	        'A.SEISHIN_4_BED_SU,'||
                'SUBSTR(A.SEISHIN_4_SHONIN_YMD,1,4),'||
                'SUBSTR(A.SEISHIN_4_SHONIN_YMD,5,2),'||
                'SUBSTR(A.SEISHIN_4_SHONIN_YMD,7,2),'||
                'A.SEISHIN_5_KNG_SBT_CD,'||
		'NULL,'||
	        'A.SEISHIN_5_BED_SU,'||
                'SUBSTR(A.SEISHIN_5_SHONIN_YMD,1,4),'||
                'SUBSTR(A.SEISHIN_5_SHONIN_YMD,5,2),'||
                'SUBSTR(A.SEISHIN_5_SHONIN_YMD,7,2),'||
                'A.SEISHIN_6_KNG_SBT_CD,'||
		'NULL,'||
	        'A.SEISHIN_6_BED_SU,'||
                'SUBSTR(A.SEISHIN_6_SHONIN_YMD,1,4),'||
                'SUBSTR(A.SEISHIN_6_SHONIN_YMD,5,2),'||
                'SUBSTR(A.SEISHIN_6_SHONIN_YMD,7,2),'||
                'A.SEISHINKEI_KNG_SBT_SU,'||
                'NULL,'||
                'A.SEISHINKEI_BED_SU,'||
                'CASE WHEN (A.KEKKAKU_1_KNG_SBT_CD IS NOT NULL OR A.KEKKAKU_1_SHONIN_YMD IS NOT NULL OR A.KEKKAKU_1_BED_SU IS NOT NULL '||
                'OR A.KEKKAKU_2_KNG_SBT_CD IS NOT NULL OR A.KEKKAKU_2_SHONIN_YMD IS NOT NULL OR A.KEKKAKU_2_BED_SU IS NOT NULL '||
                'OR A.KEKKAKU_3_KNG_SBT_CD IS NOT NULL OR A.KEKKAKU_3_SHONIN_YMD IS NOT NULL OR A.KEKKAKU_3_BED_SU IS NOT NULL ) THEN 1 ELSE NULL END,'||
		'A.KEKKAKU_1_KNG_SBT_CD,'||
		'NULL,'||
	        'A.KEKKAKU_1_BED_SU,'||
                'SUBSTR(A.KEKKAKU_1_SHONIN_YMD,1,4),'||
                'SUBSTR(A.KEKKAKU_1_SHONIN_YMD,5,2),'||
                'SUBSTR(A.KEKKAKU_1_SHONIN_YMD,7,2),'||
                'A.KEKKAKU_2_KNG_SBT_CD,'||
		'NULL,'||
	        'A.KEKKAKU_2_BED_SU,'||
                'SUBSTR(A.KEKKAKU_2_SHONIN_YMD,1,4),'||
                'SUBSTR(A.KEKKAKU_2_SHONIN_YMD,5,2),'||
                'SUBSTR(A.KEKKAKU_2_SHONIN_YMD,7,2),'||
                'A.KEKKAKU_3_KNG_SBT_CD,'||
		'NULL,'||
	        'A.KEKKAKU_3_BED_SU,'||
                'SUBSTR(A.KEKKAKU_3_SHONIN_YMD,1,4),'||
                'SUBSTR(A.KEKKAKU_3_SHONIN_YMD,5,2),'||
                'SUBSTR(A.KEKKAKU_3_SHONIN_YMD,7,2),'||
                'A.KEKKAKU_4_KNG_SBT_CD,'||
		'NULL,'||
	        'A.KEKKAKU_4_BED_SU,'||
                'SUBSTR(A.KEKKAKU_4_SHONIN_YMD,1,4),'||
                'SUBSTR(A.KEKKAKU_4_SHONIN_YMD,5,2),'||
                'SUBSTR(A.KEKKAKU_4_SHONIN_YMD,7,2),'||
                'A.KEKKAKUKEI_KNG_SBT_SU,'||
                'NULL,'||
                'A.KEKKAKUKEI_BED_SU,'||
                'A.SONOTA_1_KNG_SBT_CD,'||
                'A.SONOTA_1_BED_SU,'||
                'A.SONOTA_2_KNG_SBT_CD,'||
                'A.SONOTA_2_BED_SU,'||
                'A.SONOTA_3_KNG_SBT_CD,'||
                'A.SONOTA_3_BED_SU,'||
                'A.SONOTA_4_KNG_SBT_CD,'||
                'A.SONOTA_4_BED_SU,'||
                'A.SONOTA_5_KNG_SBT_CD,'||
                'A.SONOTA_5_BED_SU,'||
                'A.SONOTA_6_KNG_SBT_CD,'||
                'A.SONOTA_6_BED_SU,'||
                'A.SONOTA_7_KNG_SBT_CD,'||
                'A.SONOTA_7_BED_SU,'||
                'A.SONOTA_8_KNG_SBT_CD,'||
                'A.SONOTA_8_BED_SU,'||
                'A.RYOYO_BED_SU,'||
                'NULL,'||
                'A.KANSEN_BED_SU,'||
                'A.HANSEN_BED_SU,'||
                'NULL,'||
                'NULL,'||
                'NULL,'||
                'NULL,'||
                'NULL,'||
                'NULL,'||
                'NULL,'||
                'NULL,'||
                'NULL,'||
                'NULL,'||
                'NULL,'||
                'NULL,'||
                'TRIM(A.KGF_LOT_NO),'||
                'iOPE_CD,'||
                'iDATE,'||
                'iPGM_ID,'||
                'iOPE_CD,'||
                'iDATE,'||
                'iPGM_ID'||
                'FROM TT_TIKY_KGF_KNG A				'||						
               'INNER JOIN TT_TIKY_SHI B			'||							
               'ON A.REC_ID = B.REC_ID				'||						
               'AND A.SHI_CD = B.SHI_CD				'||						
	       'WHERE B.REC_ID = dcfShisetsu			'||						
               'AND B.DEL_FLG IS NULL				'||					
               'AND B.DEL_YOTEI_RIYU_CD IS NULL			'||						
               'AND A.DEL_FLG IS NULL     ' ||
               'AND (A.IPPAN_1_KNG_SBT_CD IS NOT NULL ' ||
                    'OR A.IPPAN_1_BED_SU IS NOT NULL ' ||
                    'OR A.IPPAN_1_KIFKK_IPPAN_RYOYO_KBN IS NOT NULL ' ||
                    'OR A.IPPAN_1_SHONIN_YMD IS NOT NULL ' ||
                    'OR A.IPPAN_1_MOD_EIGY_YMD IS NOT NULL ' ||
                    'OR A.IPPAN_2_KNG_SBT_CD IS NOT NULL ' ||
                    'OR A.IPPAN_2_BED_SU IS NOT NULL ' ||
                    'OR A.IPPAN_2_KIFKK_IPPAN_RYOYO_KBN IS NOT NULL ' ||
                    'OR A.IPPAN_2_SHONIN_YMD IS NOT NULL ' ||
                    'OR A.IPPAN_2_MOD_EIGY_YMD IS NOT NULL ' ||
                    'OR A.IPPAN_3_KNG_SBT_CD IS NOT NULL ' ||
                    'OR A.IPPAN_3_BED_SU IS NOT NULL ' ||
                    'OR A.IPPAN_3_KIFKK_IPPAN_RYOYO_KBN IS NOT NULL ' ||
                    'OR A.IPPAN_3_SHONIN_YMD IS NOT NULL ' ||
                    'OR A.IPPAN_3_MOD_EIGY_YMD IS NOT NULL ' ||
                    'OR A.IPPAN_4_KNG_SBT_CD IS NOT NULL ' ||
                    'OR A.IPPAN_4_BED_SU IS NOT NULL ' ||
                    'OR A.IPPAN_4_KIFKK_IPPAN_RYOYO_KBN IS NOT NULL ' ||
                    'OR A.IPPAN_4_SHONIN_YMD IS NOT NULL ' ||
                    'OR A.IPPAN_4_MOD_EIGY_YMD IS NOT NULL ' ||
                    'OR A.IPPAN_5_KNG_SBT_CD IS NOT NULL ' ||
                    'OR A.IPPAN_5_BED_SU IS NOT NULL ' ||
                    'OR A.IPPAN_5_KIFKK_IPPAN_RYOYO_KBN IS NOT NULL ' ||
                    'OR A.IPPAN_5_SHONIN_YMD IS NOT NULL ' ||
                    'OR A.IPPAN_5_MOD_EIGY_YMD IS NOT NULL ' ||
                    'OR A.IPPAN_6_KNG_SBT_CD IS NOT NULL ' ||
                    'OR A.IPPAN_6_BED_SU IS NOT NULL ' ||
                    'OR A.IPPAN_6_KIFKK_IPPAN_RYOYO_KBN IS NOT NULL ' ||
                    'OR A.IPPAN_6_SHONIN_YMD IS NOT NULL ' ||
                    'OR A.IPPAN_6_MOD_EIGY_YMD IS NOT NULL ' ||
                    'OR A.SEISHIN_1_KNG_SBT_CD IS NOT NULL ' ||
                    'OR A.SEISHIN_1_BED_SU IS NOT NULL ' ||
                    'OR A.SEISHIN_1_SHONIN_YMD IS NOT NULL ' ||
                    'OR A.SEISHIN_1_MOD_EIGY_YMD IS NOT NULL ' ||
                    'OR A.SEISHIN_2_KNG_SBT_CD IS NOT NULL ' ||
                    'OR A.SEISHIN_2_BED_SU IS NOT NULL ' ||
                    'OR A.SEISHIN_2_SHONIN_YMD IS NOT NULL ' ||
                    'OR A.SEISHIN_2_MOD_EIGY_YMD IS NOT NULL ' ||
                    'OR A.SEISHIN_3_KNG_SBT_CD IS NOT NULL ' ||
                    'OR A.SEISHIN_3_BED_SU IS NOT NULL ' ||
                    'OR A.SEISHIN_3_SHONIN_YMD IS NOT NULL ' ||
                    'OR A.SEISHIN_3_MOD_EIGY_YMD IS NOT NULL ' ||
                    'OR A.SEISHIN_4_KNG_SBT_CD IS NOT NULL ' ||
                    'OR A.SEISHIN_4_BED_SU IS NOT NULL ' ||
                    'OR A.SEISHIN_4_SHONIN_YMD IS NOT NULL ' ||
                    'OR A.SEISHIN_4_MOD_EIGY_YMD IS NOT NULL ' ||
                    'OR A.SEISHIN_5_KNG_SBT_CD IS NOT NULL ' ||
                    'OR A.SEISHIN_5_BED_SU IS NOT NULL ' ||
                    'OR A.SEISHIN_5_SHONIN_YMD IS NOT NULL ' ||
                    'OR A.SEISHIN_5_MOD_EIGY_YMD IS NOT NULL ' ||
                    'OR A.SEISHIN_6_KNG_SBT_CD IS NOT NULL ' ||
                    'OR A.SEISHIN_6_BED_SU IS NOT NULL ' ||
                    'OR A.SEISHIN_6_SHONIN_YMD IS NOT NULL ' ||
                    'OR A.SEISHIN_6_MOD_EIGY_YMD IS NOT NULL ' ||
                    'OR A.KEKKAKU_1_KNG_SBT_CD IS NOT NULL ' ||
                    'OR A.KEKKAKU_1_BED_SU IS NOT NULL ' ||
                    'OR A.KEKKAKU_1_SHONIN_YMD IS NOT NULL ' ||
                    'OR A.KEKKAKU_1_MOD_EIGY_YMD IS NOT NULL ' ||
                    'OR A.KEKKAKU_2_KNG_SBT_CD IS NOT NULL ' ||
                    'OR A.KEKKAKU_2_BED_SU IS NOT NULL ' ||
                    'OR A.KEKKAKU_2_SHONIN_YMD IS NOT NULL ' ||
                    'OR A.KEKKAKU_2_MOD_EIGY_YMD IS NOT NULL ' ||
                    'OR A.KEKKAKU_3_KNG_SBT_CD IS NOT NULL ' ||
                    'OR A.KEKKAKU_3_BED_SU IS NOT NULL ' ||
                    'OR A.KEKKAKU_3_SHONIN_YMD IS NOT NULL ' ||
                    'OR A.KEKKAKU_3_MOD_EIGY_YMD IS NOT NULL ' ||
                    'OR A.KEKKAKU_4_KNG_SBT_CD IS NOT NULL ' ||
                    'OR A.KEKKAKU_4_BED_SU IS NOT NULL ' ||
                    'OR A.KEKKAKU_4_SHONIN_YMD IS NOT NULL ' ||
                    'OR A.KEKKAKU_4_MOD_EIGY_YMD IS NOT NULL ' ||
                    'OR A.SONOTA_1_KNG_SBT_CD IS NOT NULL ' ||
                    'OR A.SONOTA_1_KBN_1 IS NOT NULL ' ||
                    'OR A.SONOTA_1_KBN_2 IS NOT NULL ' ||
                    'OR A.SONOTA_1_BED_SU IS NOT NULL ' ||
                    'OR A.SONOTA_1_KIFKK_IPPAN_RYOYO_KBN IS NOT NULL ' ||
                    'OR A.SONOTA_1_MOD_EIGY_YMD IS NOT NULL ' ||
                    'OR A.SONOTA_2_KNG_SBT_CD IS NOT NULL ' ||
                    'OR A.SONOTA_2_KBN_1 IS NOT NULL ' ||
                    'OR A.SONOTA_2_KBN_2 IS NOT NULL ' ||
                    'OR A.SONOTA_2_BED_SU IS NOT NULL ' ||
                    'OR A.SONOTA_2_KIFKK_IPPAN_RYOYO_KBN IS NOT NULL ' ||
                    'OR A.SONOTA_2_MOD_EIGY_YMD IS NOT NULL ' ||
                    'OR A.SONOTA_3_KNG_SBT_CD IS NOT NULL ' ||
                    'OR A.SONOTA_3_KBN_1 IS NOT NULL ' ||
                    'OR A.SONOTA_3_KBN_2 IS NOT NULL ' ||
                    'OR A.SONOTA_3_BED_SU IS NOT NULL ' ||
                    'OR A.SONOTA_3_KIFKK_IPPAN_RYOYO_KBN IS NOT NULL ' ||
                    'OR A.SONOTA_3_MOD_EIGY_YMD IS NOT NULL ' ||
                    'OR A.SONOTA_4_KNG_SBT_CD IS NOT NULL ' ||
                    'OR A.SONOTA_4_KBN_1 IS NOT NULL ' ||
                    'OR A.SONOTA_4_KBN_2 IS NOT NULL ' ||
                    'OR A.SONOTA_4_BED_SU IS NOT NULL ' ||
                    'OR A.SONOTA_4_KIFKK_IPPAN_RYOYO_KBN IS NOT NULL ' ||
                    'OR A.SONOTA_4_MOD_EIGY_YMD IS NOT NULL ' ||
                    'OR A.SONOTA_5_KNG_SBT_CD IS NOT NULL ' ||
                    'OR A.SONOTA_5_KBN_1 IS NOT NULL ' ||
                    'OR A.SONOTA_5_KBN_2 IS NOT NULL ' ||
                    'OR A.SONOTA_5_BED_SU IS NOT NULL ' ||
                    'OR A.SONOTA_5_KIFKK_IPPAN_RYOYO_KBN IS NOT NULL ' ||
                    'OR A.SONOTA_5_MOD_EIGY_YMD IS NOT NULL ' ||
                    'OR A.SONOTA_6_KNG_SBT_CD IS NOT NULL ' ||
                    'OR A.SONOTA_6_KBN_1 IS NOT NULL ' ||
                    'OR A.SONOTA_6_KBN_2 IS NOT NULL ' ||
                    'OR A.SONOTA_6_BED_SU IS NOT NULL ' ||
                    'OR A.SONOTA_6_KIFKK_IPPAN_RYOYO_KBN IS NOT NULL ' ||
                    'OR A.SONOTA_6_MOD_EIGY_YMD IS NOT NULL ' ||
                    'OR A.SONOTA_7_KNG_SBT_CD IS NOT NULL ' ||
                    'OR A.SONOTA_7_KBN_1 IS NOT NULL ' ||
                    'OR A.SONOTA_7_KBN_2 IS NOT NULL ' ||
                    'OR A.SONOTA_7_BED_SU IS NOT NULL ' ||
                    'OR A.SONOTA_7_KIFKK_IPPAN_RYOYO_KBN IS NOT NULL ' ||
                    'OR A.SONOTA_7_MOD_EIGY_YMD IS NOT NULL ' ||
                    'OR A.SONOTA_8_KNG_SBT_CD IS NOT NULL ' ||
                    'OR A.SONOTA_8_KBN_1 IS NOT NULL ' ||
                    'OR A.SONOTA_8_KBN_2 IS NOT NULL ' ||
                    'OR A.SONOTA_8_BED_SU IS NOT NULL ' ||
                    'OR A.SONOTA_8_KIFKK_IPPAN_RYOYO_KBN IS NOT NULL ' ||
                    'OR A.SONOTA_8_MOD_EIGY_YMD IS NOT NULL ' ||
                    'OR A.RYOYO_BED_SU IS NOT NULL ' ||
                    'OR A.RYOYO_MOD_EIGY_YMD IS NOT NULL ' ||
                    'OR A.KANSEN_BED_SU IS NOT NULL ' ||
                    'OR A.KANSEN_MOD_EIGY_YMD IS NOT NULL ' ||
                    'OR A.HANSEN_BED_SU IS NOT NULL ' ||
                    'OR A.HANSEN_MOD_EIGY_YMD IS NOT NULL)';
	  ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);
     
 commit;
        
      -- �I�����O�o��
   	 ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'PL/SQL End',PGM_ID || '�̏������I�����܂����B',iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);
      return 0;
    -- ��O����
	EXCEPTION
		-- ���̑��G���[
		WHEN OTHERS THEN
			W_ERR_INF_RCD.ERR_CD 		:= TO_CHAR(SQLCODE);
			W_ERR_INF_RCD.ERR_MSG 		:= SUBSTR(SQLERRM, 0, 500);
			W_ERR_INF_RCD.ERR_KEY_INF 	:= SUBSTR('iLayoutKind:' || iLayoutKind || ', iShimeKind:' || iShimeKind , 0,500);
			W_INDEX_N 					:= W_ERR_INF_TBL.COUNT + 1;
			W_ERR_INF_TBL.EXTEND;
			W_ERR_INF_TBL(W_INDEX_N) 	:= W_ERR_INF_RCD;

			OPEN oOUT_ERR_INF_CSR FOR
				SELECT * FROM TABLE(W_ERR_INF_TBL);
      ROLLBACK;
       --�G���[���O�̓o�^
        ULT_INSERT_LOG_TABLE('ERROR',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'ERROR_INFO',W_ERR_INF_RCD.ERR_MSG,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

        return 1;
        END;

    END;
/
