CREATE OR REPLACE PACKAGE BT010301B001_SHI
/* **********************************************************
 *  Copyright(c) 2011 beyond, INTEC Inc. All rights reserved.
 * **********************************************************/
AUTHID CURRENT_USER
IS
    /*** �J�[�\���^ ***************************************************************/
    -- �G���[���i�[�p�J�[�\���^
    TYPE ERR_INF_CSR        IS REF CURSOR;

    /*
    ************************************************************************
    *  �{�ݍ폜����
    *  DEL_SHI_DATA
    ************************************************************************
    */
    FUNCTION DEL_SHI_DATA(
    
        iShimeYm IN CHAR,
        iShoriEigyoBi IN CHAR,
        
        iShitenEigyoshoNm IN TT_RRK_KJN_KINMUSAKI.SHITEN_EIGYOSHO_NM%TYPE,              -- �����쐬�p�@�x�X�c�Ə���
        iMrNm IN TT_RRK_KJN_KINMUSAKI.MR_NM%TYPE,                                       -- �����쐬�p�@MR��
        iChosaYmd IN TT_RRK_KJN_KINMUSAKI.CHOSA_YMD%TYPE,                               -- �����쐬�p�@�����N����
        
        iIP_ADDR    IN TL_STORED_SHORI.IP%TYPE,                                         -- ���s�[��IP�A�h���X
        iWINDOWS_LOGIN_USER    IN TL_STORED_SHORI.WINDOWS_LOGIN_USER%TYPE,              -- ���s�[��OS���[�U�[
        oROW_COUNT            OUT NUMBER,                                               -- �X�V����
        oOUT_ERR_INF_CSR     OUT ERR_INF_CSR,                                           -- �G���[���J�[�\��
        iOPE_CD        IN TT_SISN_KJN.UPD_OPE_CD%TYPE,                                  -- �I�y���[�^�R�[�h
        iPGM_ID        IN TT_SISN_KJN.UPD_PGM_ID%TYPE,                                  -- �@�\ID
        iDATE        IN TT_SISN_KJN.UPD_DATE%TYPE                                       -- ��������
    
    ) RETURN NUMBER;

END;
/

CREATE OR REPLACE PACKAGE BODY BT010301B001_SHI
/* **********************************************************
 *  Copyright(c) 2011 beyond, INTEC Inc. All rights reserved.
 * **********************************************************/
IS


    /*
    ************************************************************************
    *  �{�ݍ폜����
    *  DEL_SHI_DATA
    ************************************************************************
    */
    FUNCTION DEL_SHI_DATA(
    
        iShimeYm IN CHAR,
        iShoriEigyoBi IN CHAR,

        iShitenEigyoshoNm IN TT_RRK_KJN_KINMUSAKI.SHITEN_EIGYOSHO_NM%TYPE,              -- �����쐬�p�@�x�X�c�Ə���
        iMrNm IN TT_RRK_KJN_KINMUSAKI.MR_NM%TYPE,                                       -- �����쐬�p�@MR��
        iChosaYmd IN TT_RRK_KJN_KINMUSAKI.CHOSA_YMD%TYPE,                               -- �����쐬�p�@�����N����
        
        iIP_ADDR    IN TL_STORED_SHORI.IP%TYPE,                     -- ���s�[��IP�A�h���X
        iWINDOWS_LOGIN_USER    IN TL_STORED_SHORI.WINDOWS_LOGIN_USER%TYPE, -- ���s�[��OS���[�U�[
        oROW_COUNT            OUT NUMBER,              -- �X�V����
        oOUT_ERR_INF_CSR     OUT ERR_INF_CSR,          -- �G���[���J�[�\��
        iOPE_CD        IN TT_SISN_KJN.UPD_OPE_CD%TYPE,             -- �I�y���[�^�R�[�h
        iPGM_ID        IN TT_SISN_KJN.UPD_PGM_ID%TYPE,             -- �@�\ID
        iDATE        IN TT_SISN_KJN.UPD_DATE%TYPE                -- ��������
    
    ) RETURN NUMBER IS

    /************************************************************************/
    /*                              �G���[����                              */
    /************************************************************************/
    PGM_ID  VARCHAR2(50) := 'BT010301B001_SHI.DEL_SHI_DATA';
    W_INDEX_N                     NUMBER(10) := 0;
    W_ERR_INF_TBL                 TYPE_ERR_INFO_TBL := TYPE_ERR_INFO_TBL();
    W_ERR_INF_RCD                 TYPE_ERR_INFO_RCD := TYPE_ERR_INFO_RCD(NULL,NULL,NULL,NULL);

    -- NULL ����p
    vNULL VARCHAR(1) := NULL;

    -- �o���N�t�F�b�`�擾�T�C�Y
    BULK_SIZE CONSTANT PLS_INTEGER := 1000;

    TYPE t_RecID_Tbl IS TABLE OF TT_SISN_SHI.REC_ID%TYPE;
    TYPE t_ShiCD_Tbl IS TABLE OF TT_SISN_SHI.SHI_CD%TYPE;

    v_t_RecIdList t_RecID_Tbl;
    v_t_ShiCdList t_ShiCD_Tbl;

    -- �������폜�{�݃��X�g
    -- �����R�[�h��`
    CURSOR c_DelShiRec IS 
            SELECT
             A.REC_ID
             , A.SHI_CD
             , A.DEL_YOTEI_RIYU_CD
             , A.DEL_NYURYOKU_USER_CD
             , A.CHOFUKU_AITSK_REC_ID
             , A.CHOFUKU_AITSK_SHI_CD
             , B.DEL_YOTEI_RIYU_CD AS CHOFUKU_DEL_YOTEI_RIYU_CD
             FROM
             TT_SISN_SHI A
             LEFT OUTER JOIN TT_SISN_SHI B
             ON A.CHOFUKU_AITSK_REC_ID = B.REC_ID
             AND A.CHOFUKU_AITSK_SHI_CD = B.SHI_CD;

    TYPE t_DelShi IS TABLE OF c_DelShiRec%ROWTYPE INDEX BY BINARY_INTEGER;
    -- �t�F�b�`����
    v_t_DelShi t_DelShi;
    
    -- �����ISQL�J�[�\����`
    TYPE c_DelShi  IS REF CURSOR;
    v_c_DelShi c_DelShi;


    -- ���{�݂ɋΖ�����l���X�g���擾����
    -- �����R�[�h��`
    CURSOR c_KinmuKjnListRec IS
            SELECT
             A.REC_ID
             , A.KJN_CD
             , A.KINMUSAKI_DM_FUKA_FLG
             , B.KAIKIN_KBN
             , 'FALSE' AITE_KINMU
             , 'FALSE' AITE_TAISHOKU
             FROM
             TT_SISN_KJN_KINMUSAKI A
             INNER JOIN TT_SISN_KJN B
             ON A.REC_ID = B.REC_ID
             AND A.KJN_CD = B.KJN_CD;

    TYPE t_KinmuKjnList IS TABLE OF c_KinmuKjnListRec%ROWTYPE INDEX BY BINARY_INTEGER;
    -- �t�F�b�`����
    v_t_KinmuKjnList t_KinmuKjnList;

    -- �����ISQL�J�[�\����`
    TYPE c_KinmuKjnList  IS REF CURSOR;
    v_c_KinmuKjnList c_KinmuKjnList;


    -- �D��{�݃R�[�h
    vYusenShiCd TT_SISN_SHI.SHI_CD%TYPE;

    -- �����폜�{�݃��X�g���擾����SQL
    vSQL_DEL_LIST VARCHAR2(2000);
    -- �폜�t���O�𗧂Ă�SQL
    vSQL_UPD_DEL_FLG VARCHAR2(2000);
    -- �Ζ��惊�X�g�擾SQL
    vSQL_KINMU_LIST VARCHAR2(2000);
    -- �ٓ��D��{�݃R�[�h�擾SQL
    vSQL_YUSEN_SHI VARCHAR2(2000);
    -- �Ζ���ސE����
    vSQL_TAISHOKU_FUKATU VARCHAR2(2000);
    -- �l�ސE
    vSQL_KJN_TAISHOKU VARCHAR2(2000);
    -- �ސE�����쐬
    vSQL_TAISHOKU_RRK VARCHAR2(2000);
    -- ���{�㖱���֌W����
    vSQL_IMUSHITSU_CLR VARCHAR2(2000);
    -- ���{�㖱�������쐬
    vSQL_IMUSHITSU_RRK VARCHAR2(2000);
    -- �`�F�[���X�{���֌W����
    vSQL_HONBU_CLR VARCHAR2(2000);
    -- �`�F�[���X�{�������쐬
    vSQL_HONBU_RRK VARCHAR2(2000);
    -- �������O�폜
    vSQL_GETSUJI_DEL VARCHAR2(2000);
    -- �����l�Ζ���INSERT
    vSQL_INSERT_RRK_KJN_KINMU VARCHAR2(2000) := 'INSERT INTO TT_RRK_KJN_KINMUSAKI(SEQ,REC_ID,KJN_CD,KINMUSAKI_REC_ID,KINMUSAKI_SHI_CD,TAISHOKU_FLG,TAISHOKU_EIGY_YMD,SHITEN_EIGYOSHO_NM,MR_NM,CHOSA_YMD,DAIHYO_FLG,SZKBUKA_CD,NYURYOKU_SZKBUKA_NM,NYURYOKU_SZKBUKA_NM_KANA,YAKUSHOKU_CD,SHOKUI_CD,KINMUSAKI_DM_FUKA_FLG,KINMUSAKI_KKNN_YMD,KINMUSAKI_KKNN_USER_CD,KINMUSAKI_KKNN_OPE_CD,JOHO_YMD,GOMENTE_FLG,GOMENTE_CHK_OPE_CD,GOMENTE_CHK_USER_CD,GOMENTE_CHK_EIGY_YMD,TRK_FKT_EIGY_YMD,TRK_USER_CD,TRK_EIGY_YMD,UPD_USER_CD,UPD_EIGY_YMD,TRK_OPE_CD,TRK_DATE,TRK_PGM_ID,UPD_OPE_CD,UPD_DATE,UPD_PGM_ID)'
                                  || 'VALUES(:SEQ,:REC_ID,:KJN_CD,:KINMUSAKI_REC_ID,:KINMUSAKI_SHI_CD,:TAISHOKU_FLG,:TAISHOKU_EIGY_YMD,:SHITEN_EIGYOSHO_NM,:MR_NM,:CHOSA_YMD,:DAIHYO_FLG,:SZKBUKA_CD,:NYURYOKU_SZKBUKA_NM,:NYURYOKU_SZKBUKA_NM_KANA,:YAKUSHOKU_CD,:SHOKUI_CD,:KINMUSAKI_DM_FUKA_FLG,:KINMUSAKI_KKNN_YMD,:KINMUSAKI_KKNN_USER_CD,:KINMUSAKI_KKNN_OPE_CD,:JOHO_YMD,:GOMENTE_FLG,:GOMENTE_CHK_OPE_CD,:GOMENTE_CHK_USER_CD,:GOMENTE_CHK_EIGY_YMD,:UPD_EIGY_YMD,:TRK_USER_CD,:TRK_EIGY_YMD,:UPD_USER_CD,:UPD_EIGY_YMD,:TRK_OPE_CD,:TRK_DATE,:TRK_PGM_ID,:UPD_OPE_CD,:UPD_DATE,:UPD_PGM_ID)';
    -- �ŐV�l�Ζ���INSERT
    vSQL_INSERT_SISN_KJN_KINMU VARCHAR2(2000) := 'INSERT INTO TT_SISN_KJN_KINMUSAKI(REC_ID,KJN_CD,KINMUSAKI_REC_ID,KINMUSAKI_SHI_CD,TAISHOKU_FLG,TAISHOKU_EIGY_YMD,DAIHYO_FLG,SZKBUKA_CD,KENSAKU_SZKBUKA_BNRI_CD,NYURYOKU_SZKBUKA_NM,NYURYOKU_SZKBUKA_NM_KANA,YAKUSHOKU_CD,SHOKUI_CD,KINMUSAKI_DM_FUKA_FLG,KINMUSAKI_KKNN_YMD,KINMUSAKI_KKNN_USER_CD,KINMUSAKI_KKNN_OPE_CD,JOHO_YMD,TRK_FKT_EIGY_YMD,TRK_USER_CD,TRK_EIGY_YMD,UPD_USER_CD,UPD_EIGY_YMD,TRK_OPE_CD,TRK_DATE,TRK_PGM_ID,UPD_OPE_CD,UPD_DATE,UPD_PGM_ID)'
                                    || 'VALUES(:REC_ID,:KJN_CD,:KINMUSAKI_REC_ID,:KINMUSAKI_SHI_CD,:TAISHOKU_FLG,:TAISHOKU_EIGY_YMD,:DAIHYO_FLG,:SZKBUKA_CD,:KENSAKU_SZKBUKA_BNRI_CD,:NYURYOKU_SZKBUKA_NM,:NYURYOKU_SZKBUKA_NM_KANA,:YAKUSHOKU_CD,:SHOKUI_CD,:KINMUSAKI_DM_FUKA_FLG,:KINMUSAKI_KKNN_YMD,:KINMUSAKI_KKNN_USER_CD,:KINMUSAKI_KKNN_OPE_CD,:JOHO_YMD,:UPD_EIGY_YMD,:TRK_USER_CD,:TRK_EIGY_YMD,:UPD_USER_CD,:UPD_EIGY_YMD,:TRK_OPE_CD,:TRK_DATE,:TRK_PGM_ID,:UPD_OPE_CD,:UPD_DATE,:UPD_PGM_ID)';

    
    BEGIN
    
        -- �J�n���O�o��
        ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'PL/SQL Start',PGM_ID || '�̏������J�n���܂��B',iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);
        
        -- �����폜�{�݃��X�g���擾����
        vSQL_DEL_LIST := NULL;
        vSQL_DEL_LIST := vSQL_DEL_LIST || 'SELECT';
        vSQL_DEL_LIST := vSQL_DEL_LIST || ' A.REC_ID';
        vSQL_DEL_LIST := vSQL_DEL_LIST || ' , A.SHI_CD';
        vSQL_DEL_LIST := vSQL_DEL_LIST || ' , A.DEL_YOTEI_RIYU_CD';
        vSQL_DEL_LIST := vSQL_DEL_LIST || ' , A.DEL_NYURYOKU_USER_CD';
        vSQL_DEL_LIST := vSQL_DEL_LIST || ' , A.CHOFUKU_AITSK_REC_ID';
        vSQL_DEL_LIST := vSQL_DEL_LIST || ' , A.CHOFUKU_AITSK_SHI_CD';
        vSQL_DEL_LIST := vSQL_DEL_LIST || ' , B.DEL_YOTEI_RIYU_CD AS CHOFUKU_DEL_YOTEI_RIYU_CD';
        vSQL_DEL_LIST := vSQL_DEL_LIST || ' FROM';
        vSQL_DEL_LIST := vSQL_DEL_LIST || ' TT_SISN_SHI A';
        vSQL_DEL_LIST := vSQL_DEL_LIST || ' LEFT OUTER JOIN TT_SISN_SHI B';
        vSQL_DEL_LIST := vSQL_DEL_LIST || ' ON A.CHOFUKU_AITSK_REC_ID = B.REC_ID';
        vSQL_DEL_LIST := vSQL_DEL_LIST || ' AND A.CHOFUKU_AITSK_SHI_CD = B.SHI_CD';
        vSQL_DEL_LIST := vSQL_DEL_LIST || ' WHERE A.DEL_YM = :shimeYM';
        vSQL_DEL_LIST := vSQL_DEL_LIST || ' ORDER BY A.SHI_CD';

        -- �폜�t���O�𗧂Ă�SQL
        vSQL_UPD_DEL_FLG := NULL;
        vSQL_UPD_DEL_FLG := vSQL_UPD_DEL_FLG || 'UPDATE TT_SISN_SHI';
        vSQL_UPD_DEL_FLG := vSQL_UPD_DEL_FLG || '   SET DEL_EIGY_YMD         = :ShoriEigyoBi,';
        vSQL_UPD_DEL_FLG := vSQL_UPD_DEL_FLG || '       DEL_FLG              = 1,';
        vSQL_UPD_DEL_FLG := vSQL_UPD_DEL_FLG || '       UPD_USER_CD          = :UserCd,';
        vSQL_UPD_DEL_FLG := vSQL_UPD_DEL_FLG || '       UPD_EIGY_YMD         = :ShoriEigyoBi,';
        vSQL_UPD_DEL_FLG := vSQL_UPD_DEL_FLG || '       UPD_OPE_CD           = :OpeCd,';
        vSQL_UPD_DEL_FLG := vSQL_UPD_DEL_FLG || '       UPD_DATE             = :UpdDate,';
        vSQL_UPD_DEL_FLG := vSQL_UPD_DEL_FLG || '       UPD_PGM_ID           = :PgmId';
        vSQL_UPD_DEL_FLG := vSQL_UPD_DEL_FLG || ' WHERE REC_ID               = :RecId';
        vSQL_UPD_DEL_FLG := vSQL_UPD_DEL_FLG || '   AND SHI_CD               = :ShiCd';

        -- �Ζ��惊�X�g�擾SQL
        vSQL_KINMU_LIST := NULL;
        vSQL_KINMU_LIST := vSQL_KINMU_LIST || 'SELECT';
        vSQL_KINMU_LIST := vSQL_KINMU_LIST || ' A.REC_ID';
        vSQL_KINMU_LIST := vSQL_KINMU_LIST || ' , A.KJN_CD';
        vSQL_KINMU_LIST := vSQL_KINMU_LIST || ' , A.KINMUSAKI_DM_FUKA_FLG';
        vSQL_KINMU_LIST := vSQL_KINMU_LIST || ' , B.KAIKIN_KBN ';
        vSQL_KINMU_LIST := vSQL_KINMU_LIST || ' , CASE WHEN A1.REC_ID IS NULL THEN ''FALSE'' ELSE ''TRUE'' END AITE_KINMU';
        vSQL_KINMU_LIST := vSQL_KINMU_LIST || ' , CASE WHEN A1.TAISHOKU_FLG IS NOT NULL THEN ''TRUE'' ELSE ''FALSE'' END AITE_TAISHOKU';
        vSQL_KINMU_LIST := vSQL_KINMU_LIST || ' FROM';
        vSQL_KINMU_LIST := vSQL_KINMU_LIST || ' TT_SISN_KJN_KINMUSAKI A';
        vSQL_KINMU_LIST := vSQL_KINMU_LIST || ' INNER JOIN TT_SISN_KJN B';
        vSQL_KINMU_LIST := vSQL_KINMU_LIST || '   ON A.REC_ID = B.REC_ID';
        vSQL_KINMU_LIST := vSQL_KINMU_LIST || '   AND A.KJN_CD = B.KJN_CD';
        vSQL_KINMU_LIST := vSQL_KINMU_LIST || ' LEFT OUTER JOIN TT_SISN_KJN_KINMUSAKI A1';              -- �폜�����{�݂ɋΖ��󋵎擾
        vSQL_KINMU_LIST := vSQL_KINMU_LIST || '    ON A1.REC_ID = A.REC_ID ';
        vSQL_KINMU_LIST := vSQL_KINMU_LIST || '   AND A1.KJN_CD = A.KJN_CD ';
        vSQL_KINMU_LIST := vSQL_KINMU_LIST || '   AND A1.KINMUSAKI_REC_ID = :chofukuRecId ';
        vSQL_KINMU_LIST := vSQL_KINMU_LIST || '   AND A1.KINMUSAKI_SHI_CD = :chofukuShiCd ';
        vSQL_KINMU_LIST := vSQL_KINMU_LIST || ' WHERE A.KINMUSAKI_REC_ID = :kinmusakiRecId';
        vSQL_KINMU_LIST := vSQL_KINMU_LIST || ' AND A.KINMUSAKI_SHI_CD = :kinmusakiShiCd';
        vSQL_KINMU_LIST := vSQL_KINMU_LIST || ' AND A.TAISHOKU_FLG IS NULL';
        vSQL_KINMU_LIST := vSQL_KINMU_LIST || ' AND B.DEL_YM IS NULL';

        -- �ٓ��D��{�݃R�[�h�擾SQL
        vSQL_YUSEN_SHI := NULL;
        vSQL_YUSEN_SHI := vSQL_YUSEN_SHI || 'SELECT';
        vSQL_YUSEN_SHI := vSQL_YUSEN_SHI || ' MIN(A.SHI_CD) AS SHI_CD';
        vSQL_YUSEN_SHI := vSQL_YUSEN_SHI || ' FROM';
        vSQL_YUSEN_SHI := vSQL_YUSEN_SHI || ' TT_SISN_SHI A';
        vSQL_YUSEN_SHI := vSQL_YUSEN_SHI || ' INNER JOIN TT_SISN_KJN_KINMUSAKI B';
        vSQL_YUSEN_SHI := vSQL_YUSEN_SHI || ' ON A.REC_ID = B.KINMUSAKI_REC_ID';
        vSQL_YUSEN_SHI := vSQL_YUSEN_SHI || ' AND A.SHI_CD = B.KINMUSAKI_SHI_CD';
        vSQL_YUSEN_SHI := vSQL_YUSEN_SHI || ' WHERE A.DEL_YM = :shimeYM';
        vSQL_YUSEN_SHI := vSQL_YUSEN_SHI || ' AND A.DEL_YOTEI_RIYU_CD = ''5''';
        vSQL_YUSEN_SHI := vSQL_YUSEN_SHI || ' AND A.CHOFUKU_AITSK_REC_ID = :chofukuRecId';
        vSQL_YUSEN_SHI := vSQL_YUSEN_SHI || ' AND A.CHOFUKU_AITSK_SHI_CD = :chofukuShiCd';
        vSQL_YUSEN_SHI := vSQL_YUSEN_SHI || ' AND B.REC_ID = :recId';
        vSQL_YUSEN_SHI := vSQL_YUSEN_SHI || ' AND B.KJN_CD = :kjnCd';
        vSQL_YUSEN_SHI := vSQL_YUSEN_SHI || ' AND B.TAISHOKU_FLG IS NULL';

        -- �Ζ���ސE����
        vSQL_TAISHOKU_FUKATU := NULL;
        vSQL_TAISHOKU_FUKATU := vSQL_TAISHOKU_FUKATU || 'UPDATE TT_SISN_KJN_KINMUSAKI';
        vSQL_TAISHOKU_FUKATU := vSQL_TAISHOKU_FUKATU || '   SET TAISHOKU_FLG = NULL,';
        vSQL_TAISHOKU_FUKATU := vSQL_TAISHOKU_FUKATU || '       TAISHOKU_EIGY_YMD = NULL,';
        vSQL_TAISHOKU_FUKATU := vSQL_TAISHOKU_FUKATU || '       DAIHYO_FLG = NULL,';
        vSQL_TAISHOKU_FUKATU := vSQL_TAISHOKU_FUKATU || '       SZKBUKA_CD = :ShozokuBuka,';
        vSQL_TAISHOKU_FUKATU := vSQL_TAISHOKU_FUKATU || '       KENSAKU_SZKBUKA_BNRI_CD = NULL,';
        vSQL_TAISHOKU_FUKATU := vSQL_TAISHOKU_FUKATU || '       NYURYOKU_SZKBUKA_NM = NULL,';
        vSQL_TAISHOKU_FUKATU := vSQL_TAISHOKU_FUKATU || '       NYURYOKU_SZKBUKA_NM_KANA = NULL,';
        vSQL_TAISHOKU_FUKATU := vSQL_TAISHOKU_FUKATU || '       YAKUSHOKU_CD = :Yakushoku,';
        vSQL_TAISHOKU_FUKATU := vSQL_TAISHOKU_FUKATU || '       SHOKUI_CD = NULL,';
        vSQL_TAISHOKU_FUKATU := vSQL_TAISHOKU_FUKATU || '       KINMUSAKI_DM_FUKA_FLG = :DmFukaFlg,';
        vSQL_TAISHOKU_FUKATU := vSQL_TAISHOKU_FUKATU || '       KINMUSAKI_KKNN_YMD = NULL,';
        vSQL_TAISHOKU_FUKATU := vSQL_TAISHOKU_FUKATU || '       KINMUSAKI_KKNN_USER_CD = NULL,';
        vSQL_TAISHOKU_FUKATU := vSQL_TAISHOKU_FUKATU || '       KINMUSAKI_KKNN_OPE_CD = NULL,';
        vSQL_TAISHOKU_FUKATU := vSQL_TAISHOKU_FUKATU || '       JOHO_YMD = NULL,';
        vSQL_TAISHOKU_FUKATU := vSQL_TAISHOKU_FUKATU || '       TRK_FKT_EIGY_YMD = :ShoriEigyoBi,';
        vSQL_TAISHOKU_FUKATU := vSQL_TAISHOKU_FUKATU || '       UPD_USER_CD = :UserCd,';
        vSQL_TAISHOKU_FUKATU := vSQL_TAISHOKU_FUKATU || '       UPD_EIGY_YMD = :ShoriEigyoBi,';
        vSQL_TAISHOKU_FUKATU := vSQL_TAISHOKU_FUKATU || '       UPD_OPE_CD = :OpeCd,';
        vSQL_TAISHOKU_FUKATU := vSQL_TAISHOKU_FUKATU || '       UPD_DATE = :UpdDate,';
        vSQL_TAISHOKU_FUKATU := vSQL_TAISHOKU_FUKATU || '       UPD_PGM_ID = :PgmId';
        vSQL_TAISHOKU_FUKATU := vSQL_TAISHOKU_FUKATU || ' WHERE REC_ID = :RecId';
        vSQL_TAISHOKU_FUKATU := vSQL_TAISHOKU_FUKATU || '   AND KJN_CD = :KjnCd';
        vSQL_TAISHOKU_FUKATU := vSQL_TAISHOKU_FUKATU || '   AND KINMUSAKI_REC_ID = :KinmusakiRecId';
        vSQL_TAISHOKU_FUKATU := vSQL_TAISHOKU_FUKATU || '   AND KINMUSAKI_SHI_CD = :KinmusakiShiCd';

        -- �l�ސE
        vSQL_KJN_TAISHOKU := NULL;
        vSQL_KJN_TAISHOKU := vSQL_KJN_TAISHOKU || 'UPDATE TT_SISN_KJN_KINMUSAKI';
        vSQL_KJN_TAISHOKU := vSQL_KJN_TAISHOKU || '   SET TAISHOKU_FLG = ''1'',';
        vSQL_KJN_TAISHOKU := vSQL_KJN_TAISHOKU || '       TAISHOKU_EIGY_YMD = :ShoriEigyoBi,';
        vSQL_KJN_TAISHOKU := vSQL_KJN_TAISHOKU || '       UPD_USER_CD = :UserCd,';
        vSQL_KJN_TAISHOKU := vSQL_KJN_TAISHOKU || '       UPD_EIGY_YMD = :ShoriEigyoBi,';
        vSQL_KJN_TAISHOKU := vSQL_KJN_TAISHOKU || '       UPD_OPE_CD = :OPE_CD,';
        vSQL_KJN_TAISHOKU := vSQL_KJN_TAISHOKU || '       UPD_DATE = :UPD_DATE,';
        vSQL_KJN_TAISHOKU := vSQL_KJN_TAISHOKU || '       UPD_PGM_ID = :PGM_ID';
        vSQL_KJN_TAISHOKU := vSQL_KJN_TAISHOKU || ' WHERE REC_ID = :REC_ID';
        vSQL_KJN_TAISHOKU := vSQL_KJN_TAISHOKU || '   AND KJN_CD = :KJN_CD';
        vSQL_KJN_TAISHOKU := vSQL_KJN_TAISHOKU || '   AND KINMUSAKI_REC_ID = :KINMUSAKI_REC_ID';
        vSQL_KJN_TAISHOKU := vSQL_KJN_TAISHOKU || '   AND KINMUSAKI_SHI_CD = :KINMUSAKI_SHI_CD';

        -- ���{�㖱���֌W����
        vSQL_IMUSHITSU_CLR := NULL;
        vSQL_IMUSHITSU_CLR := vSQL_IMUSHITSU_CLR || 'UPDATE TT_SISN_SHI A ';
        vSQL_IMUSHITSU_CLR := vSQL_IMUSHITSU_CLR || '   SET IMUSHITSU_REC_ID = NULL,';
        vSQL_IMUSHITSU_CLR := vSQL_IMUSHITSU_CLR || '       IMUSHITSU_SHI_CD = NULL,';
        vSQL_IMUSHITSU_CLR := vSQL_IMUSHITSU_CLR || '       UPD_USER_CD = :UserCd,';
        vSQL_IMUSHITSU_CLR := vSQL_IMUSHITSU_CLR || '       UPD_EIGY_YMD = :ShoriEigyoBi,';
        vSQL_IMUSHITSU_CLR := vSQL_IMUSHITSU_CLR || '       UPD_OPE_CD = :OpeCd,';
        vSQL_IMUSHITSU_CLR := vSQL_IMUSHITSU_CLR || '       UPD_DATE = :UpdDate,';
        vSQL_IMUSHITSU_CLR := vSQL_IMUSHITSU_CLR || '       UPD_PGM_ID = :PgmId';
        vSQL_IMUSHITSU_CLR := vSQL_IMUSHITSU_CLR || ' WHERE A.IMUSHITSU_REC_ID = :ImuRecId';
        vSQL_IMUSHITSU_CLR := vSQL_IMUSHITSU_CLR || '   AND A.IMUSHITSU_SHI_CD = :ImuShiCd';
        vSQL_IMUSHITSU_CLR := vSQL_IMUSHITSU_CLR || '   AND A.DEL_FLG IS NULL';
        vSQL_IMUSHITSU_CLR := vSQL_IMUSHITSU_CLR || '   AND A.DEL_YOTEI_RIYU_CD IS NULL';
        vSQL_IMUSHITSU_CLR := vSQL_IMUSHITSU_CLR || '   RETURNING REC_ID, SHI_CD INTO :1, :2';

        -- ���{�㖱�������쐬
        vSQL_IMUSHITSU_RRK := NULL;
        vSQL_IMUSHITSU_RRK := vSQL_IMUSHITSU_RRK || 'INSERT INTO TT_RRK_SHI_TOKUI_TAIO';
        vSQL_IMUSHITSU_RRK := vSQL_IMUSHITSU_RRK || '    (SEQ';
        vSQL_IMUSHITSU_RRK := vSQL_IMUSHITSU_RRK || '    ,REC_ID';
        vSQL_IMUSHITSU_RRK := vSQL_IMUSHITSU_RRK || '    ,SHI_CD';
        vSQL_IMUSHITSU_RRK := vSQL_IMUSHITSU_RRK || '    ,SHITEN_EIGYOSHO_NM';
        vSQL_IMUSHITSU_RRK := vSQL_IMUSHITSU_RRK || '    ,MR_NM';
        vSQL_IMUSHITSU_RRK := vSQL_IMUSHITSU_RRK || '    ,CHOSA_YMD';
        vSQL_IMUSHITSU_RRK := vSQL_IMUSHITSU_RRK || '    ,IMUSHITSU_REC_ID';
        vSQL_IMUSHITSU_RRK := vSQL_IMUSHITSU_RRK || '    ,IMUSHITSU_SHI_CD';
        vSQL_IMUSHITSU_RRK := vSQL_IMUSHITSU_RRK || '    ,GOMENTE_FLG';
        vSQL_IMUSHITSU_RRK := vSQL_IMUSHITSU_RRK || '    ,GOMENTE_CHK_OPE_CD';
        vSQL_IMUSHITSU_RRK := vSQL_IMUSHITSU_RRK || '    ,GOMENTE_CHK_USER_CD';
        vSQL_IMUSHITSU_RRK := vSQL_IMUSHITSU_RRK || '    ,GOMENTE_CHK_EIGY_YMD';
        vSQL_IMUSHITSU_RRK := vSQL_IMUSHITSU_RRK || '    ,TRK_USER_CD';
        vSQL_IMUSHITSU_RRK := vSQL_IMUSHITSU_RRK || '    ,TRK_EIGY_YMD';
        vSQL_IMUSHITSU_RRK := vSQL_IMUSHITSU_RRK || '    ,UPD_USER_CD';
        vSQL_IMUSHITSU_RRK := vSQL_IMUSHITSU_RRK || '    ,UPD_EIGY_YMD';
        vSQL_IMUSHITSU_RRK := vSQL_IMUSHITSU_RRK || '    ,TRK_OPE_CD';
        vSQL_IMUSHITSU_RRK := vSQL_IMUSHITSU_RRK || '    ,TRK_DATE';
        vSQL_IMUSHITSU_RRK := vSQL_IMUSHITSU_RRK || '    ,TRK_PGM_ID';
        vSQL_IMUSHITSU_RRK := vSQL_IMUSHITSU_RRK || '    ,UPD_OPE_CD';
        vSQL_IMUSHITSU_RRK := vSQL_IMUSHITSU_RRK || '    ,UPD_DATE';
        vSQL_IMUSHITSU_RRK := vSQL_IMUSHITSU_RRK || '    ,UPD_PGM_ID)';
        vSQL_IMUSHITSU_RRK := vSQL_IMUSHITSU_RRK || 'VALUES(SEQ_RIREKI_PK.NEXTVAL';
        vSQL_IMUSHITSU_RRK := vSQL_IMUSHITSU_RRK || '    ,:RecId';
        vSQL_IMUSHITSU_RRK := vSQL_IMUSHITSU_RRK || '    ,:ShiCd';
        vSQL_IMUSHITSU_RRK := vSQL_IMUSHITSU_RRK || '    ,:ShitenEigyoshoNm';
        vSQL_IMUSHITSU_RRK := vSQL_IMUSHITSU_RRK || '    ,:MrNm';
        vSQL_IMUSHITSU_RRK := vSQL_IMUSHITSU_RRK || '    ,:ChosaYmd';
        vSQL_IMUSHITSU_RRK := vSQL_IMUSHITSU_RRK || '    ,NULL';
        vSQL_IMUSHITSU_RRK := vSQL_IMUSHITSU_RRK || '    ,NULL';
        vSQL_IMUSHITSU_RRK := vSQL_IMUSHITSU_RRK || '    ,NULL';
        vSQL_IMUSHITSU_RRK := vSQL_IMUSHITSU_RRK || '    ,NULL';
        vSQL_IMUSHITSU_RRK := vSQL_IMUSHITSU_RRK || '    ,NULL';
        vSQL_IMUSHITSU_RRK := vSQL_IMUSHITSU_RRK || '    ,NULL';
        vSQL_IMUSHITSU_RRK := vSQL_IMUSHITSU_RRK || '    ,:UserCd';
        vSQL_IMUSHITSU_RRK := vSQL_IMUSHITSU_RRK || '    ,:ShoriEigyoBi';
        vSQL_IMUSHITSU_RRK := vSQL_IMUSHITSU_RRK || '    ,:UserCd';
        vSQL_IMUSHITSU_RRK := vSQL_IMUSHITSU_RRK || '    ,:ShoriEigyoBi';
        vSQL_IMUSHITSU_RRK := vSQL_IMUSHITSU_RRK || '    ,:OPE_CD';
        vSQL_IMUSHITSU_RRK := vSQL_IMUSHITSU_RRK || '    ,:TRK_DATE';
        vSQL_IMUSHITSU_RRK := vSQL_IMUSHITSU_RRK || '    ,:PGM_ID';
        vSQL_IMUSHITSU_RRK := vSQL_IMUSHITSU_RRK || '    ,:OPE_CD';
        vSQL_IMUSHITSU_RRK := vSQL_IMUSHITSU_RRK || '    ,:UPD_DATE';
        vSQL_IMUSHITSU_RRK := vSQL_IMUSHITSU_RRK || '    ,:PGM_ID)';

        -- �`�F�[���X�{���֌W����
        vSQL_HONBU_CLR := NULL;
        vSQL_HONBU_CLR := vSQL_HONBU_CLR || 'UPDATE TT_SISN_SHI A ';
        vSQL_HONBU_CLR := vSQL_HONBU_CLR || '   SET CHAIN_HONBU_REC_ID  = NULL,';
        vSQL_HONBU_CLR := vSQL_HONBU_CLR || '       CHAIN_HONBU_SHI_CD  = NULL,';
        vSQL_HONBU_CLR := vSQL_HONBU_CLR || '       CHAIN_HONBU_SBT_CD  = NULL,';
        vSQL_HONBU_CLR := vSQL_HONBU_CLR || '       UPD_USER_CD         = :userCd,';
        vSQL_HONBU_CLR := vSQL_HONBU_CLR || '       UPD_EIGY_YMD        = :shoriEigyoBi,';
        vSQL_HONBU_CLR := vSQL_HONBU_CLR || '       UPD_OPE_CD          = :updOpeCd,';
        vSQL_HONBU_CLR := vSQL_HONBU_CLR || '       UPD_DATE            = :updDate,';
        vSQL_HONBU_CLR := vSQL_HONBU_CLR || '       UPD_PGM_ID          = :updPgmId';
        vSQL_HONBU_CLR := vSQL_HONBU_CLR || ' WHERE A.CHAIN_HONBU_REC_ID = :honbuRecId';
        vSQL_HONBU_CLR := vSQL_HONBU_CLR || '   AND A.CHAIN_HONBU_SHI_CD = :honbuShiCd';
        vSQL_HONBU_CLR := vSQL_HONBU_CLR || '   AND A.DEL_FLG IS NULL';
        vSQL_HONBU_CLR := vSQL_HONBU_CLR || '   AND A.DEL_YOTEI_RIYU_CD IS NULL';
        vSQL_HONBU_CLR := vSQL_HONBU_CLR || '   AND A.REC_ID = ''03''';
        vSQL_HONBU_CLR := vSQL_HONBU_CLR || '   RETURNING REC_ID, SHI_CD INTO :1, :2';

        -- �`�F�[���X�{�������쐬
        vSQL_HONBU_RRK := NULL;
        vSQL_HONBU_RRK := vSQL_HONBU_RRK || 'INSERT INTO TT_RRK_SHI_CHAIN_HONBU';
        vSQL_HONBU_RRK := vSQL_HONBU_RRK || '    (SEQ';
        vSQL_HONBU_RRK := vSQL_HONBU_RRK || '    ,REC_ID';
        vSQL_HONBU_RRK := vSQL_HONBU_RRK || '    ,SHI_CD';
        vSQL_HONBU_RRK := vSQL_HONBU_RRK || '    ,SHITEN_EIGYOSHO_NM';
        vSQL_HONBU_RRK := vSQL_HONBU_RRK || '    ,MR_NM';
        vSQL_HONBU_RRK := vSQL_HONBU_RRK || '    ,CHOSA_YMD';
        vSQL_HONBU_RRK := vSQL_HONBU_RRK || '    ,CHAIN_HONBU_SBT_CD';
        vSQL_HONBU_RRK := vSQL_HONBU_RRK || '    ,CHAIN_HONBU_REC_ID';
        vSQL_HONBU_RRK := vSQL_HONBU_RRK || '    ,CHAIN_HONBU_SHI_CD';
        vSQL_HONBU_RRK := vSQL_HONBU_RRK || '    ,GOMENTE_FLG';
        vSQL_HONBU_RRK := vSQL_HONBU_RRK || '    ,GOMENTE_CHK_OPE_CD';
        vSQL_HONBU_RRK := vSQL_HONBU_RRK || '    ,GOMENTE_CHK_USER_CD';
        vSQL_HONBU_RRK := vSQL_HONBU_RRK || '    ,GOMENTE_CHK_EIGY_YMD';
        vSQL_HONBU_RRK := vSQL_HONBU_RRK || '    ,TRK_USER_CD';
        vSQL_HONBU_RRK := vSQL_HONBU_RRK || '    ,TRK_EIGY_YMD';
        vSQL_HONBU_RRK := vSQL_HONBU_RRK || '    ,UPD_USER_CD';
        vSQL_HONBU_RRK := vSQL_HONBU_RRK || '    ,UPD_EIGY_YMD';
        vSQL_HONBU_RRK := vSQL_HONBU_RRK || '    ,TRK_OPE_CD';
        vSQL_HONBU_RRK := vSQL_HONBU_RRK || '    ,TRK_DATE';
        vSQL_HONBU_RRK := vSQL_HONBU_RRK || '    ,TRK_PGM_ID';
        vSQL_HONBU_RRK := vSQL_HONBU_RRK || '    ,UPD_OPE_CD';
        vSQL_HONBU_RRK := vSQL_HONBU_RRK || '    ,UPD_DATE';
        vSQL_HONBU_RRK := vSQL_HONBU_RRK || '    ,UPD_PGM_ID)';
        vSQL_HONBU_RRK := vSQL_HONBU_RRK || 'VALUES(SEQ_RIREKI_PK.NEXTVAL';
        vSQL_HONBU_RRK := vSQL_HONBU_RRK || '    ,:RecId';
        vSQL_HONBU_RRK := vSQL_HONBU_RRK || '    ,:ShiCd';
        vSQL_HONBU_RRK := vSQL_HONBU_RRK || '    ,:ShitenEigyoshoNm';
        vSQL_HONBU_RRK := vSQL_HONBU_RRK || '    ,:MrNm';
        vSQL_HONBU_RRK := vSQL_HONBU_RRK || '    ,:ChosaYmd';
        vSQL_HONBU_RRK := vSQL_HONBU_RRK || '    ,NULL';
        vSQL_HONBU_RRK := vSQL_HONBU_RRK || '    ,NULL';
        vSQL_HONBU_RRK := vSQL_HONBU_RRK || '    ,NULL';
        vSQL_HONBU_RRK := vSQL_HONBU_RRK || '    ,NULL';
        vSQL_HONBU_RRK := vSQL_HONBU_RRK || '    ,NULL';
        vSQL_HONBU_RRK := vSQL_HONBU_RRK || '    ,NULL';
        vSQL_HONBU_RRK := vSQL_HONBU_RRK || '    ,NULL';
        vSQL_HONBU_RRK := vSQL_HONBU_RRK || '    ,:UserCd';
        vSQL_HONBU_RRK := vSQL_HONBU_RRK || '    ,:ShoriEigyoBi';
        vSQL_HONBU_RRK := vSQL_HONBU_RRK || '    ,:UserCd';
        vSQL_HONBU_RRK := vSQL_HONBU_RRK || '    ,:ShoriEigyoBi';
        vSQL_HONBU_RRK := vSQL_HONBU_RRK || '    ,:OPE_CD';
        vSQL_HONBU_RRK := vSQL_HONBU_RRK || '    ,:TRK_DATE';
        vSQL_HONBU_RRK := vSQL_HONBU_RRK || '    ,:PGM_ID';
        vSQL_HONBU_RRK := vSQL_HONBU_RRK || '    ,:OPE_CD';
        vSQL_HONBU_RRK := vSQL_HONBU_RRK || '    ,:UPD_DATE';
        vSQL_HONBU_RRK := vSQL_HONBU_RRK || '    ,:PGM_ID)';

        -- �������O�폜
        vSQL_GETSUJI_DEL := NULL;
        vSQL_GETSUJI_DEL := vSQL_GETSUJI_DEL || 'DELETE TT_GETSUJI_LIST_JOGAI_SHI ';
        vSQL_GETSUJI_DEL := vSQL_GETSUJI_DEL || 'WHERE REC_ID = :recId ';
        vSQL_GETSUJI_DEL := vSQL_GETSUJI_DEL || '  AND SHI_CD = :shiCd ';
                
        -- ���I�r�p�k���s
        -- ���O�o��
        ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql [vSQL_DEL_LIST]',vSQL_DEL_LIST || ' :shimeYM = ''' || iShimeYm || '''',iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

        OPEN v_c_DelShi FOR vSQL_DEL_LIST USING iShimeYm;
        LOOP
            -- nested table�̏�����
            v_t_DelShi.DELETE;
            -- �폜�{�݈ꗗ�擾
            FETCH v_c_DelShi BULK COLLECT INTO v_t_DelShi LIMIT BULK_SIZE;
            EXIT WHEN v_t_DelShi.COUNT = 0;
            FOR i IN 1 .. v_t_DelShi.COUNT
            LOOP
                ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'BusinessLog Start [�{�ݍ폜�J�n]', 'REC_ID=''' || v_t_DelShi(i).REC_ID || ''' SHI_CD=''' || v_t_DelShi(i).SHI_CD || '''',iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);
                -- �폜�t���O�𓖂Ă�
                -- ���O�o��
                ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql [vSQL_UPD_DEL_FLG]',
                    vSQL_UPD_DEL_FLG
                    || ' :ShoriEigyoBi = ''' || iShoriEigyoBi
                    || ''' :UserCd = ''' || v_t_DelShi(i).DEL_NYURYOKU_USER_CD
                    || ''' :OpeCd = ''' || iOPE_CD
                    || ''' :UpdDate = ''' || iDATE
                    || ''' :PgmId = ''' || iPGM_ID
                    || ''' :RecId = ''' || v_t_DelShi(i).REC_ID
                    || ''' :ShiCd = ''' || v_t_DelShi(i).SHI_CD
                    ,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

                EXECUTE IMMEDIATE vSQL_UPD_DEL_FLG USING  iShoriEigyoBi, v_t_DelShi(i).DEL_NYURYOKU_USER_CD, iShoriEigyoBi, iOPE_CD, iDATE, iPGM_ID, v_t_DelShi(i).REC_ID, v_t_DelShi(i).SHI_CD;
                       
                -- �C���v�b�g�󋵃e�[�u���̓o�^
                BT010301B001_COMMON.INSERT_INPUT_JOKYO_SHI(
                          iShoriEigyoBi,
                          v_t_DelShi(i).REC_ID,
                          v_t_DelShi(i).DEL_NYURYOKU_USER_CD,
                          'C',
                          '0103',
                          v_t_DelShi(i).SHI_CD,
                          iIP_ADDR,
                          iWINDOWS_LOGIN_USER,
                          iOPE_CD,
                          iDATE,
                          iPGM_ID);
                
                -- �i�Q�j�폜���ꂽ�{�݂ɑ΂��Ċ֘A����f�[�^���X�V����
                -- �@�ŐV�l�Ζ���e�[�u���ɁA�Y���{�݂ɋΖ�����l���X�g���擾����i�A���ސE�͎擾�ΏۊO�j
                -- �{�݂ɋΖ�����l���X�g�擾
                -- ���O�o��
                ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql [vSQL_KINMU_LIST]',
                    vSQL_KINMU_LIST
                    || ' :kinmusakiRecId = ''' || v_t_DelShi(i).REC_ID
                    || ''' :kinmusakiShiCd = ''' || v_t_DelShi(i).SHI_CD
                    || ''' :shimeYM = ''' || iShimeYm
                    || ''' :chofukuRecId = ''' || v_t_DelShi(i).CHOFUKU_AITSK_REC_ID
                    || ''' :chofukuShiCd = ''' || v_t_DelShi(i).CHOFUKU_AITSK_SHI_CD
                    ,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

                OPEN v_c_KinmuKjnList FOR vSQL_KINMU_LIST USING
                    v_t_DelShi(i).CHOFUKU_AITSK_REC_ID,
                    v_t_DelShi(i).CHOFUKU_AITSK_SHI_CD,
                    v_t_DelShi(i).REC_ID,
                    v_t_DelShi(i).SHI_CD;

                LOOP
                    -- nested table�̏�����
                    v_t_KinmuKjnList.DELETE;
                    FETCH v_c_KinmuKjnList BULK COLLECT INTO v_t_KinmuKjnList LIMIT BULK_SIZE;
                    EXIT WHEN v_t_KinmuKjnList.COUNT = 0;
                    FOR j IN 1 .. v_t_KinmuKjnList.COUNT
                    LOOP
                        -- �A�폜�{�݁i�d�������j�̌l�ٓ��������s��
                        -- �Y���{�݂̍폜�\�藝�R�R�[�h���u5�F�d���폜�v�̏ꍇ
                        -- �d�������{�݂̍폜�\�藝�R�R�[�h�����ݒ�̏ꍇ�A�l�ٓ��������s��
                        IF v_t_DelShi(i).DEL_YOTEI_RIYU_CD = '5' AND v_t_DelShi(i).CHOFUKU_DEL_YOTEI_RIYU_CD IS NULL THEN

                            -- �Y���Ζ�����l�̗D��{�݃R�[�h���擾����
                            -- ���O�o��
                            ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql [vSQL_YUSEN_SHI]',
                                vSQL_YUSEN_SHI
                                || ' :shimeYM = ''' || iShimeYm
                                || ''' :chofukuRecId = ''' || v_t_DelShi(i).CHOFUKU_AITSK_REC_ID
                                || ''' :chofukuShiCd = ''' || v_t_DelShi(i).CHOFUKU_AITSK_SHI_CD
                                || ''' :recId = ''' || v_t_KinmuKjnList(j).REC_ID
                                || ''' :kjnCd = ''' || v_t_KinmuKjnList(j).KJN_CD, iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

                            vYusenShiCd := NULL;
                            EXECUTE IMMEDIATE vSQL_YUSEN_SHI INTO vYusenShiCd USING iShimeYm, v_t_DelShi(i).CHOFUKU_AITSK_REC_ID, v_t_DelShi(i).CHOFUKU_AITSK_SHI_CD, v_t_KinmuKjnList(j).REC_ID, v_t_KinmuKjnList(j).KJN_CD;

                            -- �擾���ꂽ�D��{�݃R�[�h�ƍ폜�Ώێ{�݃R�[�h�͈�v�̏ꍇ
                            IF vYusenShiCd = v_t_DelShi(i).SHI_CD THEN
                                IF v_t_KinmuKjnList(j).AITE_KINMU = 'FALSE' THEN
                                    -- �d�������{�݂ɋΖ����Ă��Ȃ��ꍇ
                                    -- �폜�{�݂ɋΖ�����l���d�������Ɉٓ�������
                                    -- ���O�o��
                                    ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql [vSQL_INSERT_SISN_KJN_KINMU]',
                                        vSQL_INSERT_SISN_KJN_KINMU
                                        || ' :REC_ID = ''' || v_t_KinmuKjnList(j).REC_ID
                                        || ''' :KJN_CD = ''' || v_t_KinmuKjnList(j).KJN_CD
                                        || ''' :KINMUSAKI_REC_ID = ''' || v_t_DelShi(i).CHOFUKU_AITSK_REC_ID
                                        || ''' :KINMUSAKI_SHI_CD = ''' || v_t_DelShi(i).CHOFUKU_AITSK_SHI_CD
                                        || ''' :SZKBUKA_CD = ''' || BT010301B001_COMMON.SZKBUKA_CD_MI
                                        || ''' :YAKUSHOKU_CD = ''' || BT010301B001_COMMON.YAKUSHOKU_CD_MI
                                        || ''' :KINMUSAKI_DM_FUKA_FLG = ''' || v_t_KinmuKjnList(j).KINMUSAKI_DM_FUKA_FLG || ''' �ق���NULL', iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

                                    EXECUTE IMMEDIATE vSQL_INSERT_SISN_KJN_KINMU
                                        USING v_t_KinmuKjnList(j).REC_ID,
                                        v_t_KinmuKjnList(j).KJN_CD,
                                        v_t_DelShi(i).CHOFUKU_AITSK_REC_ID,
                                        v_t_DelShi(i).CHOFUKU_AITSK_SHI_CD,
                                        vNULL,
                                        vNULL,
                                        vNULL,
                                        BT010301B001_COMMON.SZKBUKA_CD_MI,
                                        vNULL,
                                        vNULL,
                                        vNULL,
                                        BT010301B001_COMMON.YAKUSHOKU_CD_MI,
                                        vNULL,
                                        v_t_KinmuKjnList(j).KINMUSAKI_DM_FUKA_FLG,
                                        vNULL,
                                        vNULL,
                                        vNULL,
                                        vNULL,
                                        iShoriEigyoBi,
                                        v_t_DelShi(i).DEL_NYURYOKU_USER_CD,
                                        iShoriEigyoBi,
                                        v_t_DelShi(i).DEL_NYURYOKU_USER_CD,
                                        iShoriEigyoBi,
                                        iOPE_CD, iDATE, iPGM_ID, iOPE_CD, iDATE, iPGM_ID;

                                    -- �����쐬
                                    IF v_t_KinmuKjnList(j).REC_ID IN ('01', '02', '05') THEN

                                        -- ���O�o��
                                        ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql [vSQL_INSERT_RRK_KJN_KINMU]',
                                            vSQL_INSERT_RRK_KJN_KINMU
                                            || ' :REC_ID = ''' || v_t_KinmuKjnList(j).REC_ID
                                            || ''' :KJN_CD = ''' || v_t_KinmuKjnList(j).KJN_CD
                                            || ''' :KINMUSAKI_REC_ID = ''' || v_t_DelShi(i).CHOFUKU_AITSK_REC_ID
                                            || ''' :KINMUSAKI_SHI_CD = ''' || v_t_DelShi(i).CHOFUKU_AITSK_SHI_CD
                                            || ''' :SZKBUKA_CD = ''' || BT010301B001_COMMON.SZKBUKA_CD_MI
                                            || ''' :YAKUSHOKU_CD = ''' || BT010301B001_COMMON.YAKUSHOKU_CD_MI
                                            || ''' :KINMUSAKI_DM_FUKA_FLG = ''' || v_t_KinmuKjnList(j).KINMUSAKI_DM_FUKA_FLG || ' '' �ق���NULL', iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

                                        EXECUTE IMMEDIATE vSQL_INSERT_RRK_KJN_KINMU
                                            USING SEQ_RIREKI_PK.NEXTVAL,
                                                v_t_KinmuKjnList(j).REC_ID,
                                                v_t_KinmuKjnList(j).KJN_CD,
                                                v_t_DelShi(i).CHOFUKU_AITSK_REC_ID,
                                                v_t_DelShi(i).CHOFUKU_AITSK_SHI_CD,
                                                vNULL,
                                                vNULL,
                                                iShitenEigyoshoNm,
                                                iMrNm,
                                                iChosaYmd,
                                                vNULL,
                                                BT010301B001_COMMON.SZKBUKA_CD_MI, 
                                                vNULL,
                                                vNULL,
                                                BT010301B001_COMMON.YAKUSHOKU_CD_MI,
                                                vNULL,
                                                v_t_KinmuKjnList(j).KINMUSAKI_DM_FUKA_FLG,
                                                vNULL,
                                                vNULL,
                                                vNULL,
                                                vNULL,
                                                vNULL,
                                                vNULL,
                                                vNULL,
                                                vNULL,
                                                iShoriEigyoBi,
                                                v_t_DelShi(i).DEL_NYURYOKU_USER_CD,
                                                iShoriEigyoBi,
                                                v_t_DelShi(i).DEL_NYURYOKU_USER_CD,
                                                iShoriEigyoBi,
                                                iOPE_CD, iDATE, iPGM_ID, iOPE_CD, iDATE, iPGM_ID;

                                            -- �C���v�b�g�󋵃e�[�u���̓o�^
                                            BT010301B001_COMMON.INSERT_INPUT_JOKYO_KJN(
                                                    iShoriEigyoBi
                                                    ,v_t_KinmuKjnList(j).REC_ID
                                                    ,v_t_DelShi(i).DEL_NYURYOKU_USER_CD
                                                    ,'B'
                                                    ,'0017'
                                                    ,v_t_KinmuKjnList(j).KJN_CD
                                                    ,iIP_ADDR
                                                    ,iWINDOWS_LOGIN_USER
                                                    ,iOPE_CD
                                                    ,iDATE
                                                    ,iPGM_ID);

                                        END IF;  -- IF v_t_KinmuKjnList(j).REC_ID IN ('01', '02', '05') THEN
                                ELSE
                                    -- �d�������{�݂ɋΖ����Ă���
                                    -- ���ސE�ƂȂ��Ă���i�ސE�t���O��1�F�ސE�����j�ꍇ
                                    IF v_t_KinmuKjnList(j).AITE_TAISHOKU = 'TRUE' THEN

                                        -- ���O�o��
                                        ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql [vSQL_TAISHOKU_FUKATU]',
                                            vSQL_TAISHOKU_FUKATU
                                            || ' :RecId = ''' || v_t_KinmuKjnList(j).REC_ID
                                            || ''' :KjnCd = ''' || v_t_KinmuKjnList(j).KJN_CD
                                            || ''' :KinmusakiRecId = ''' || v_t_DelShi(i).CHOFUKU_AITSK_REC_ID
                                            || ''' :KinmusakiShiCd = ''' || v_t_DelShi(i).CHOFUKU_AITSK_SHI_CD
                                            || ''' :ShozokuBuka = ''' || BT010301B001_COMMON.SZKBUKA_CD_MI
                                            || ''' :Yakushoku = ''' || BT010301B001_COMMON.YAKUSHOKU_CD_MI
                                            || ''' :DmFukaFlg = ''' || v_t_KinmuKjnList(j).KINMUSAKI_DM_FUKA_FLG
                                            || ''' :UserCd = ''' || v_t_DelShi(i).DEL_NYURYOKU_USER_CD
                                            || '''', iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

                                        EXECUTE IMMEDIATE vSQL_TAISHOKU_FUKATU
                                            USING 
                                                    BT010301B001_COMMON.SZKBUKA_CD_MI,
                                                    BT010301B001_COMMON.YAKUSHOKU_CD_MI,
                                                    v_t_KinmuKjnList(j).KINMUSAKI_DM_FUKA_FLG,
                                                    iShoriEigyoBi,
                                                    v_t_DelShi(i).DEL_NYURYOKU_USER_CD,
                                                    iShoriEigyoBi,
                                                    iOPE_CD,
                                                    iDATE,
                                                    iPGM_ID,
                                                    v_t_KinmuKjnList(j).REC_ID,
                                                    v_t_KinmuKjnList(j).KJN_CD,
                                                    v_t_DelShi(i).CHOFUKU_AITSK_REC_ID,
                                                    v_t_DelShi(i).CHOFUKU_AITSK_SHI_CD;

                                        -- �����쐬
                                        IF v_t_KinmuKjnList(j).REC_ID IN ('01', '02', '05') THEN

                                            -- ���O�o��
                                            ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql [vSQL_INSERT_RRK_KJN_KINMU]',
                                                vSQL_INSERT_RRK_KJN_KINMU
                                                || ' :REC_ID = ''' || v_t_KinmuKjnList(j).REC_ID
                                                || ''' :KJN_CD = ''' || v_t_KinmuKjnList(j).KJN_CD
                                                || ''' :KINMUSAKI_REC_ID = ''' || v_t_DelShi(i).CHOFUKU_AITSK_REC_ID
                                                || ''' :KINMUSAKI_SHI_CD = ''' || v_t_DelShi(i).CHOFUKU_AITSK_SHI_CD
                                                || ''' :SZKBUKA_CD = ''' || BT010301B001_COMMON.SZKBUKA_CD_MI
                                                || ''' :YAKUSHOKU_CD = ''' || BT010301B001_COMMON.YAKUSHOKU_CD_MI
                                                || ''' :KINMUSAKI_DM_FUKA_FLG = ''' || v_t_KinmuKjnList(j).KINMUSAKI_DM_FUKA_FLG
                                                || ''' :UPD_USER_CD = ''' || v_t_DelShi(i).DEL_NYURYOKU_USER_CD
                                                || ''' �ق���NULL', iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

                                            EXECUTE IMMEDIATE vSQL_INSERT_RRK_KJN_KINMU
                                                USING SEQ_RIREKI_PK.NEXTVAL,
                                                    v_t_KinmuKjnList(j).REC_ID,
                                                    v_t_KinmuKjnList(j).KJN_CD,
                                                    v_t_DelShi(i).CHOFUKU_AITSK_REC_ID,
                                                    v_t_DelShi(i).CHOFUKU_AITSK_SHI_CD,
                                                    vNULL,
                                                    vNULL,
                                                    iShitenEigyoshoNm,
                                                    iMrNm,
                                                    iChosaYmd,
                                                    vNULL,
                                                    '9999', 
                                                    vNULL,
                                                    vNULL,
                                                    '501',
                                                    vNULL,
                                                    v_t_KinmuKjnList(j).KINMUSAKI_DM_FUKA_FLG,
                                                    vNULL,
                                                    vNULL,
                                                    vNULL,
                                                    vNULL,
                                                    vNULL,
                                                    vNULL,
                                                    vNULL,
                                                    vNULL,
                                                    iShoriEigyoBi,
                                                    v_t_DelShi(i).DEL_NYURYOKU_USER_CD,
                                                    iShoriEigyoBi,
                                                    v_t_DelShi(i).DEL_NYURYOKU_USER_CD,
                                                    iShoriEigyoBi,
                                                    iOPE_CD, iDATE, iPGM_ID, iOPE_CD, iDATE, iPGM_ID;

                                            -- �C���v�b�g�󋵃e�[�u���̓o�^
                                            -- ��E�R�[�h
                                            BT010301B001_COMMON.INSERT_INPUT_JOKYO_KJN(
                                                iShoriEigyoBi
                                                ,v_t_KinmuKjnList(j).REC_ID
                                                ,v_t_DelShi(i).DEL_NYURYOKU_USER_CD
                                                ,'B'
                                                ,'0019'
                                                ,v_t_KinmuKjnList(j).KJN_CD
                                                ,iIP_ADDR
                                                ,iWINDOWS_LOGIN_USER
                                                ,iOPE_CD
                                                ,iDATE
                                                ,iPGM_ID);
                                            -- ���������R�[�h
                                            BT010301B001_COMMON.INSERT_INPUT_JOKYO_KJN(
                                                iShoriEigyoBi
                                                ,v_t_KinmuKjnList(j).REC_ID
                                                ,v_t_DelShi(i).DEL_NYURYOKU_USER_CD
                                                ,'B'
                                                ,'0020'
                                                ,v_t_KinmuKjnList(j).KJN_CD
                                                ,iIP_ADDR
                                                ,iWINDOWS_LOGIN_USER
                                                ,iOPE_CD
                                                ,iDATE
                                                ,iPGM_ID);
                                            -- �ސE�t���O
                                            BT010301B001_COMMON.INSERT_INPUT_JOKYO_KJN(
                                                iShoriEigyoBi
                                                ,v_t_KinmuKjnList(j).REC_ID
                                                ,v_t_DelShi(i).DEL_NYURYOKU_USER_CD
                                                ,'B'
                                                ,'0017'
                                                ,v_t_KinmuKjnList(j).KJN_CD
                                                ,iIP_ADDR
                                                ,iWINDOWS_LOGIN_USER
                                                ,iOPE_CD
                                                ,iDATE
                                                ,iPGM_ID);
                                        END IF;  -- IF v_t_KinmuKjnList(j).REC_ID IN ('01', '02', '05')
                                    END IF;  -- IF vKijKinmuRec.TAISHOKU_FLG = '1' THEN
                                END IF;  -- IF vKjnKinmuCur%ROWCOUNT = 0 THEN
                                -- CLOSE vKjnKinmuCur;
                            END IF;  -- IF v_t_KinmuKjnList(j).YUSEN_SHI_CD = v_t_DelShi(i).SHI_CD THEN
                        END IF;  -- IF v_t_DelShi(i).DEL_YOTEI_RIYU_CD = '5' AND v_t_DelShi(i).CHOFUKU_DEL_YOTEI_RIYU_CD IS NULL THEN

                        -- �B�폜�{�݂̌l�ސE�������s���B�폜�{�݂ɋΖ�����l��ސE�i�ސE�t���O���Z�b�g�j������
                        -- �ŐV�l�Ζ���e�[�u���ɂ��̃f�[�^���X�V����
                        -- ���O�o��
                        ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql [vSQL_KJN_TAISHOKU]',
                            vSQL_KJN_TAISHOKU
                            || ' :REC_ID = ''' || v_t_KinmuKjnList(j).REC_ID
                            || ''' :KJN_CD = ''' || v_t_KinmuKjnList(j).KJN_CD
                            || ''' :KINMUSAKI_REC_ID = ''' || v_t_DelShi(i).CHOFUKU_AITSK_REC_ID
                            || ''' :KINMUSAKI_SHI_CD = ''' || v_t_DelShi(i).CHOFUKU_AITSK_SHI_CD
                            || ''' :SZKBUKA_CD = ''' || BT010301B001_COMMON.SZKBUKA_CD_MI
                            || ''' :YAKUSHOKU_CD = ''' || BT010301B001_COMMON.YAKUSHOKU_CD_MI
                            || ''' :KINMUSAKI_DM_FUKA_FLG = ''' || v_t_KinmuKjnList(j).KINMUSAKI_DM_FUKA_FLG
                            || ''' :UPD_USER_CD = ''' || v_t_DelShi(i).DEL_NYURYOKU_USER_CD
                            || '''', iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

                        EXECUTE IMMEDIATE vSQL_KJN_TAISHOKU
                            USING
                                iShoriEigyoBi,
                                v_t_DelShi(i).DEL_NYURYOKU_USER_CD,
                                iShoriEigyoBi,
                                iOPE_CD,
                                iDATE,
                                iPGM_ID,
                                v_t_KinmuKjnList(j).REC_ID,
                                v_t_KinmuKjnList(j).KJN_CD,
                                v_t_DelShi(i).REC_ID,
                                v_t_DelShi(i).SHI_CD;

                        -- �ސE�����ƃC���v�b�g�󋵂��쐬����B
                        BT010301B001_COMMON.CREATE_TAISHOKU_RRK(
                                v_t_KinmuKjnList(j).REC_ID,
                                v_t_KinmuKjnList(j).KJN_CD,
                                v_t_DelShi(i).REC_ID,
                                v_t_DelShi(i).SHI_CD,
                                v_t_DelShi(i).DEL_NYURYOKU_USER_CD,
                                iShoriEigyoBi,
                                iShitenEigyoshoNm,
                                iMrNm,
                                iChosaYmd,
                                iIP_ADDR,
                                iWINDOWS_LOGIN_USER,
                                iOPE_CD,
                                iDATE,
                                iPGM_ID);

                        -- �CkjnKinmusakiRow.���R�[�hID��02�FPCF�l�ȊO�̏ꍇ
                        -- �l�ɑ΂��ĊJ�΋敪���X�V����
                        BT010301B001_COMMON.UPDATE_KAIKIN_KBN(
                                v_t_KinmuKjnList(j).REC_ID,
                                v_t_KinmuKjnList(j).KJN_CD,
                                v_t_DelShi(i).DEL_NYURYOKU_USER_CD,
                                iShoriEigyoBi,
                                iShitenEigyoshoNm,
                                iMrNm,
                                iChosaYmd,
                                iIP_ADDR,
                                iWINDOWS_LOGIN_USER,
                                iOPE_CD,
                                iDATE,
                                iPGM_ID);
                    END LOOP;
                END LOOP;
                CLOSE v_c_KinmuKjnList;

                -- �D�{�ݍ폜�ɔ����֘A���폜���s��
                -- a�D���{�{�݂ƈ㖱���̊֌W����
                -- ���O�o��
                ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql [vSQL_IMUSHITSU_CLR]',
                    vSQL_IMUSHITSU_CLR
                    || ' :UserCd = ''' || v_t_DelShi(i).DEL_NYURYOKU_USER_CD
                    || ''' :ShoriEigyoBi = ''' || iShoriEigyoBi
                    || ''' :ImuRecId = ''' || v_t_DelShi(i).REC_ID
                    || ''' :ImuShiCd = ''' || v_t_DelShi(i).SHI_CD
                    || '''', iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

                v_t_RecIdList := t_RecID_Tbl(NULL);
                v_t_ShiCdList := t_ShiCD_Tbl(NULL);
                EXECUTE IMMEDIATE vSQL_IMUSHITSU_CLR USING
                    v_t_DelShi(i).DEL_NYURYOKU_USER_CD,
                    iShoriEigyoBi,
                    iOPE_CD,
                    iDATE,
                    iPGM_ID,
                    v_t_DelShi(i).REC_ID,
                    v_t_DelShi(i).SHI_CD
                    RETURNING BULK COLLECT INTO v_t_RecIdList, v_t_ShiCdList;

                -- ����o�^
                FOR k IN 1 .. v_t_RecIdList.COUNT
                LOOP

                    -- ���O�o��
                    ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql [vSQL_IMUSHITSU_RRK]',
                        vSQL_IMUSHITSU_RRK
                        || ' :RecId = ''' || v_t_RecIdList(k)
                        || ''' :ShiCd = ''' || v_t_ShiCdList(k)
                        || ''' :ShitenEigyoshoNm = ''' || iShitenEigyoshoNm
                        || ''' :MrNm = ''' || iMrNm
                        || ''' :ChosaYmd = ''' || iChosaYmd
                        || ''' :UserCd = ''' || v_t_DelShi(i).DEL_NYURYOKU_USER_CD
                        || ''' :ShoriEigyoBi = ''' || iShoriEigyoBi
                        || '''', iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

                    EXECUTE IMMEDIATE vSQL_IMUSHITSU_RRK USING
                        v_t_RecIdList(k),
                        v_t_ShiCdList(k),
                        iShitenEigyoshoNm,
                        iMrNm,
                        iChosaYmd,
                        v_t_DelShi(i).DEL_NYURYOKU_USER_CD,
                        iShoriEigyoBi,
                        v_t_DelShi(i).DEL_NYURYOKU_USER_CD,
                        iShoriEigyoBi,
                        iOPE_CD,
                        iDATE,
                        iPGM_ID,
                        iOPE_CD,
                        iDATE,
                        iPGM_ID;

                END LOOP;


                -- b.���R�[�hID = '03'�iDSF�{�݁j�̏ꍇ�A�`�F�[���X�Ɩ{���̊֌W����
                -- ���O�o��
                ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql [vSQL_HONBU_CLR]',
                    vSQL_HONBU_CLR
                    || ' :UserCd = ''' || v_t_DelShi(i).DEL_NYURYOKU_USER_CD
                    || ''' :ShoriEigyoBi = ''' || iShoriEigyoBi
                    || ''' :HonbuRecId = ''' || v_t_DelShi(i).REC_ID
                    || ''' :HonbuShiCd = ''' || v_t_DelShi(i).SHI_CD
                    || '''', iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

                v_t_RecIdList := t_RecID_Tbl(NULL);
                v_t_ShiCdList := t_ShiCD_Tbl(NULL);
                EXECUTE IMMEDIATE vSQL_HONBU_CLR USING v_t_DelShi(i).DEL_NYURYOKU_USER_CD, iShoriEigyoBi, iOPE_CD, iDATE, iPGM_ID, v_t_DelShi(i).REC_ID, v_t_DelShi(i).SHI_CD RETURNING BULK COLLECT INTO v_t_RecIdList, v_t_ShiCdList;

                -- �����{�݃`�F�[���X�{���e�[�u��                
                FOR k IN 1 .. v_t_RecIdList.COUNT
                LOOP

                    -- ���O�o��
                    ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql [vSQL_HONBU_RRK]',
                        vSQL_HONBU_RRK
                        || ' :RecId = ''' || v_t_RecIdList(k)
                        || ''' :ShiCd = ''' || v_t_ShiCdList(k)
                        || ''' :ShitenEigyoshoNm = ''' || iShitenEigyoshoNm
                        || ''' :MrNm = ''' || iMrNm
                        || ''' :ChosaYmd = ''' || iChosaYmd
                        || ''' :UserCd = ''' || v_t_DelShi(i).DEL_NYURYOKU_USER_CD
                        || ''' :ShoriEigyoBi = ''' || iShoriEigyoBi
                        || '''', iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

                    EXECUTE IMMEDIATE vSQL_HONBU_RRK USING
                        v_t_RecIdList(k),
                        v_t_ShiCdList(k),
                        iShitenEigyoshoNm,
                        iMrNm,
                        iChosaYmd,
                        v_t_DelShi(i).DEL_NYURYOKU_USER_CD,
                        iShoriEigyoBi,
                        v_t_DelShi(i).DEL_NYURYOKU_USER_CD,
                        iShoriEigyoBi,
                        iOPE_CD,
                        iDATE,
                        iPGM_ID,
                        iOPE_CD,
                        iDATE,
                        iPGM_ID;

                END LOOP;

                -- c�D�������X�g���O�{�݃e�[�u�����畨���폜
                -- �������X�g���O�{�݃e�[�u�������폜
                -- ���O�o��
                ULT_INSERT_LOG_TABLE('INFO', iIP_ADDR, iWINDOWS_LOGIN_USER, iOPE_CD, 'Execute Sql [vSQL_GETSUJI_DEL]', vSQL_GETSUJI_DEL || 
                        ' :recId = ' || v_t_DelShi(i).REC_ID || ' :shiCd = ' || v_t_DelShi(i).SHI_CD, iOPE_CD, iDATE, iPGM_ID, iOPE_CD, iDATE, iPGM_ID);

                -- ���I�r�p�k���s
                EXECUTE IMMEDIATE vSQL_GETSUJI_DEL USING v_t_DelShi(i).REC_ID, v_t_DelShi(i).SHI_CD;

                ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'BusinessLog End [�{�ݍ폜�I��]', 'REC_ID=''' || v_t_DelShi(i).REC_ID || ''' SHI_CD=''' || v_t_DelShi(i).SHI_CD || '''',iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);
            END LOOP;
        
        END LOOP;
        CLOSE v_c_DelShi;

        -- �I�����O�o��
        ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'PL/SQL End',PGM_ID || '�̏������I�����܂����B',iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

        -- ����I��
        oROW_COUNT := 1;
        RETURN 0;
        
    -- ��O����
    EXCEPTION
        -- ���̑��G���[
        WHEN OTHERS THEN
            W_ERR_INF_RCD.ERR_CD         := TO_CHAR(SQLCODE);
            W_ERR_INF_RCD.ERR_MSG         := SUBSTR(SQLERRM, 0, 2000);
            W_INDEX_N             := W_ERR_INF_TBL.COUNT + 1;
            W_ERR_INF_TBL.EXTEND;
            W_ERR_INF_TBL(W_INDEX_N)     := W_ERR_INF_RCD;

            OPEN oOUT_ERR_INF_CSR FOR
                SELECT * FROM TABLE(W_ERR_INF_TBL);
            
      --�G���[���O�̓o�^
            ULT_INSERT_LOG_TABLE('ERROR',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'ERROR_INFO',W_ERR_INF_RCD.ERR_MSG,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

            RAISE;
    
    END;
END;
/