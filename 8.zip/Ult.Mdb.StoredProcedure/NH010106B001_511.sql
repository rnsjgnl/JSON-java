CREATE OR REPLACE PACKAGE NH010106B001_511
/* **********************************************************
 *  Copyright(c) 2011 beyond, INTEC Inc. All rights reserved.
 * **********************************************************/
AUTHID CURRENT_USER
IS
	/*** �J�[�\���^ ***************************************************************/
	-- �G���[���i�[�p�J�[�\���^
	TYPE ERR_INF_CSR		IS REF CURSOR;

	/*
	************************************************************************
	*  �w�����f��DB�f�[�^�̍쐬
	*  CREATE_DCF_KJN_SENMONI
	************************************************************************
	*/
	FUNCTION CREATE_DCF_KJN_SENMONI(
		iLayoutKind		IN	INTEGER,				-- ���C�A�E�g�敪
		iShimeKind		IN	INTEGER,				-- ���ߓ��敪
		iTensoYMD		IN	VARCHAR2,				-- �]���N����
		iOPE_CD 		IN	Varchar2,                               -- �I�y���[�^�R�[�h
		iPGM_ID 		IN	Varchar2,                               -- �v���O����ID
		iDATE 			DATE,                                           -- �V�X�e������  
		iIP_ADDR		IN	TL_STORED_SHORI.IP%TYPE,		-- ���s�[��IP�A�h���X (FW�Őݒ�)
		iWINDOWS_LOGIN_USER	IN	TL_STORED_SHORI.WINDOWS_LOGIN_USER%TYPE,-- ���s�[��OS���[�U�[ (FW�Őݒ�)
		oROW_COUNT		OUT	NUMBER,                                	-- �o�^����
		oOUT_ERR_INF_CSR 	OUT	ERR_INF_CSR                            	-- �G���[���J�[�\��
	) RETURN NUMBER;
  
END;
/

CREATE OR REPLACE PACKAGE BODY NH010106B001_511
/* **********************************************************
 *  Copyright(c) 2011 beyond, INTEC Inc. All rights reserved.
 * **********************************************************/
IS
	/*
	 ************************************************************************
	 * Function ID  : CREATE_DCF_KJN_SENMONI
	 * Program Name : �w�����f��DB�f�[�^�̍쐬
	 * Parameter    :	<I> iLayoutKind	    	�F���C�A�E�g�敪
	 *			<I> iShimeKind	    	�F���ߓ��敪
	 *			<I> iTensoYMD	    	�F�]���N����
	 *			<I> iOPE_CD		�F�I�y���[�^�R�[�h
	 *			<I> iPGM_ID		�F�v���O����ID
	 *			<I> iDATE		�F�V�X�e������ 
	 *			<I> iIP_ADDR		�F���s�[��IP�A�h���X
	 *			<I> iWINDOWS_LOGIN_USER �F���s�[��IP�A�h���X
	 *			<O> oROW_COUNT		�F�X�V����
	 *			<O> oOUT_ERR_INF_CSR	�F�G���[���J�[�\��
	 * Return       �F�������ʁi0:����I���A1:�ُ�I���j
	 ************************************************************************
	 */
	FUNCTION CREATE_DCF_KJN_SENMONI(
		iLayoutKind		IN	INTEGER,				-- ���C�A�E�g�敪
		iShimeKind		IN	INTEGER,				-- ���ߓ��敪
		iTensoYMD		IN	VARCHAR2,				-- �]���N����
		iOPE_CD 		IN	Varchar2,                               -- �I�y���[�^�R�[�h
		iPGM_ID 		IN	Varchar2,                               -- �v���O����ID
		iDATE 			DATE,                                           -- �V�X�e������  
		iIP_ADDR		IN	TL_STORED_SHORI.IP%TYPE,		-- ���s�[��IP�A�h���X (FW�Őݒ�)
		iWINDOWS_LOGIN_USER	IN	TL_STORED_SHORI.WINDOWS_LOGIN_USER%TYPE,-- ���s�[��OS���[�U�[ (FW�Őݒ�)
		oROW_COUNT		OUT	NUMBER,                                	-- �o�^����
		oOUT_ERR_INF_CSR 	OUT	ERR_INF_CSR                            	-- �G���[���J�[�\��
	)RETURN NUMBER IS

  PRAGMA AUTONOMOUS_TRANSACTION;
	/************************************************************************/
	/*                              �G���[����                                */
	/************************************************************************/
	W_INDEX_N 				NUMBER(10) := 0;
	W_ERR_INF_TBL 				TYPE_ERR_INFO_TBL := TYPE_ERR_INFO_TBL();
	W_ERR_INF_RCD 				TYPE_ERR_INFO_RCD := TYPE_ERR_INFO_RCD(NULL,NULL,NULL,NULL);
	vSQL VARCHAR2(200);
        vSchemaNm     TM_JOSU.HANYO_KOMOKU%TYPE := NULL; -- �X�L�[�}����
	PGM_ID        VARCHAR2(50) := 'NH010106B001_511.CREATE_DCF_KJN_SENMONI';
	EXECUTE_SQL   VARCHAR2(32767) := NULL;  

	BEGIN
	-- �J�n���O�o��
        ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'PL/SQL Start',PGM_ID || '�̏������J�n���܂��B',iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);
        -- �[�i�p�X�L�[�}�̎擾���s���B
	vSchemaNm := ULT_COMMON.GET_SCHEMA_NAME(ULT_COMMON.SYS_ENV_JOSU_DAI_CD, ULT_COMMON.NOHIN_SHEMA_JOSU_SHO_CD);
	oROW_COUNT:= -1;
	  -- �V���C�A�E�g
	  IF iLayoutKind= 1 THEN
		-- ���ߋ敪:"1"(������)
		IF   iShimeKind = 1THEN

			-- �V_�S��_DNF���Ȉ�t�e�[�u���̃f�[�^���N���A����
                        EXECUTE_SQL := 'TRUNCATE TABLE ' || vSchemaNm || '.' || 'TD_NA_DCF_KJN_SENMONI';
                        EXECUTE IMMEDIATE EXECUTE_SQL;
                        ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);
			INSERT INTO TD_NA_DCF_KJN_SENMONI(
					LAYOUT_KBN,
					DCF_CD_REC_ID,
					DCF_CD_KJN_CD,
					DCF_CD_YOBI,
					MOD_KBN,
					SENMONI_CD,
					YOBI_1,
					MENTE_YMD,
					YOBI_2,
					SENMONI_FLG,
					SENMONI_KEISAI_D,
					NINTEII_FLG,
					NINTEII_KEISAI_D,
					SHIDOI_FLG,
					SHIDOI_KEISAI_D,
					SENMONI_MENTE_KBN,
					TENSO_YMD,
					TRK_OPE_CD,
					TRK_DATE,
					TRK_PGM_ID,
					UPD_OPE_CD,
					UPD_DATE,
					UPD_PGM_ID)
                        SELECT
					'511',
					A.REC_ID,
					A.KJN_CD,
					NULL,
					NULL,
					B.SENMONI_CD,
					NULL,
					B.UPD_EIGY_YMD,
                                        NULL,
					B.SENMONI_FLG,
					B.SENMONI_KEISAI_YMD,
					B.NINTEII_FLG,
					B.NINTEII_KEISAI_YMD,
					B.SHIDOI_FLG,
					B.SHIDOI_KEISAI_YMD,
					NULL,
					iTensoYMD,
					iOPE_CD,
					iDATE,
					iPGM_ID,
					iOPE_CD,
					iDATE,
					iPGM_ID
		        FROM TT_TIKY_KJN A
                        INNER JOIN TT_TIKY_KJN_SENMONI B
                        ON A.REC_ID = B.REC_ID
                        AND A.KJN_CD = B.KJN_CD
	                WHERE A.REC_ID = '01'
	                AND A.DEL_FLG IS NULL
	                AND B.SOSHITSU_FLG IS NULL;
			EXECUTE_SQL :=  'INSERT INTO TD_NA_DCF_KJN_SENMONI('||
					'LAYOUT_KBN,'||
					'DCF_CD_REC_ID,'||
					'DCF_CD_KJN_CD,'||
					'DCF_CD_YOBI,'||
					'MOD_KBN,'||
					'SENMONI_CD,'||
					'YOBI_1,'||
					'MENTE_YMD,'||
					'YOBI_2,'||
					'SENMONI_FLG,'||
					'SENMONI_KEISAI_D,'||
					'NINTEII_FLG,'||
					'NINTEII_KEISAI_D,'||
					'SHIDOI_FLG,'||
					'SHIDOI_KEISAI_D,'||
					'SENMONI_MENTE_KBN,'||
					'TENSO_YMD,'||
					'TRK_OPE_CD,'||
					'TRK_DATE,'||
					'TRK_PGM_ID,'||
					'UPD_OPE_CD,'||
					'UPD_DATE,'||
					'UPD_PGM_ID)'||
                     '    SELECT                                                          '||
                                        '''511'''  || ','                                        ||
					'A.REC_ID,'||
					'A.KJN_CD,'||
					'NULL,'||
					'NULL,'||
					'B.SENMONI_CD,'||
					'NULL,'||
					'B.UPD_EIGY_YMD,'||
                                        'NULL,'||
					'B.SENMONI_FLG,'||
					'B.SENMONI_KEISAI_YMD,'||
					'B.NINTEII_FLG,'||
					'B.NINTEII_KEISAI_YMD,'||
					'B.SHIDOI_FLG,'||
					'B.SHIDOI_KEISAI_YMD,'||
					'NULL,'||
					'iTensoYMD,'||
					'iOPE_CD,'||
					'iDATE,'||
					'iPGM_ID,'||
					'iOPE_CD,'||
					'iDATE,'||
					'iPGM_ID'||
		        'FROM TT_TIKY_KJN A'||
                        'INNER JOIN TT_TIKY_KJN_SENMONI B'||
                        'ON A.REC_ID = B.REC_ID'||
                        'AND A.KJN_CD = B.KJN_CD'||
	                'WHERE A.REC_ID = ''01'''||
	                'AND A.DEL_FLG IS NULL'||
	                'AND B.SOSHITSU_FLG IS NULL';
			ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);
                        END IF;
        -- �b�背�C�A�E�g
        ELSIF iLayoutKind = 2 THEN
                IF   iShimeKind = 4 OR iShimeKind = 5 THEN
		-- �b��_�S��_�w�����e�[�u���̃f�[�^���N���A����B
                EXECUTE_SQL := 'TRUNCATE TABLE ' || vSchemaNm || '.' || 'TD_PA_DCF_KJN_SENMONI';
                EXECUTE IMMEDIATE EXECUTE_SQL;
                ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);
                INSERT INTO TD_PA_DCF_KJN_SENMONI(
					DCF_CD_REC_ID,
					DCF_CD_KJN_CD,
					DCF_CD_YOBI,
					SENMONI_CD,
					SENMONI_FLG,
					SENMONI_KEISAI_D_Y,
					SENMONI_KEISAI_D_M,
					SENMONI_KEISAI_D_D,
                                        NINTEII_FLG,
					NINTEII_KEISAI_D_Y,
					NINTEII_KEISAI_D_M,
					NINTEII_KEISAI_D_D,
					SHIDOI_FLG,
					SHIDOI_KEISAI_D_Y,
					SHIDOI_KEISAI_D_M,
					SHIDOI_KEISAI_D_D,
					YOBI,
					TENSO_Y,
					TENSO_M,
					TENSO_D,
					MENTE_Y,
					MENTE_M,
					MENTE_D,
					SENMONI_MENTE_KBN,
					MOD_KBN,
					TRK_OPE_CD,
					TRK_DATE,
					TRK_PGM_ID,
					UPD_OPE_CD,
					UPD_DATE,
					UPD_PGM_ID)
                SELECT
					A.REC_ID,
					A.KJN_CD,
					NULL,
					B.SENMONI_CD,
					B.SENMONI_FLG,
					SUBSTR(B.SENMONI_KEISAI_YMD,1,4),
					SUBSTR(B.SENMONI_KEISAI_YMD,5,2),
					SUBSTR(B.SENMONI_KEISAI_YMD,7,2),
					B.NINTEII_FLG ,
					SUBSTR(B.NINTEII_KEISAI_YMD,1,4),
					SUBSTR(B.NINTEII_KEISAI_YMD,5,2),
					SUBSTR(B.NINTEII_KEISAI_YMD,7,2),
					B.SHIDOI_FLG ,
					SUBSTR(B.SHIDOI_KEISAI_YMD,1,4),
					SUBSTR(B.SHIDOI_KEISAI_YMD,5,2),
					SUBSTR(B.SHIDOI_KEISAI_YMD,7,2),
					NULL,
					SUBSTR(iTensoYMD,1,4),
					SUBSTR(iTensoYMD,5,2),
					SUBSTR(iTensoYMD,7,2),
                                        SUBSTR(B.UPD_EIGY_YMD,1,4),
					SUBSTR(B.UPD_EIGY_YMD,5,2),
					SUBSTR(B.UPD_EIGY_YMD,7,2),
					NULL,
					NULL,
					iOPE_CD,
					iDATE,
					iPGM_ID,
					iOPE_CD,
					iDATE,
					iPGM_ID
		FROM TT_TIKY_KJN A
                INNER JOIN TT_TIKY_KJN_SENMONI B
                ON A.REC_ID = B.REC_ID
                AND A.KJN_CD = B.KJN_CD
	        WHERE A.REC_ID = '01'
	        AND A.DEL_FLG IS NULL
	        AND B.SOSHITSU_FLG IS NULL;
	        -- �b��_�S��_�w�����̓o�^
	        EXECUTE_SQL :=  'INSERT INTO TD_PA_DCF_KJN_SENMONI('||
					'DCF_CD_REC_ID,'||
					'DCF_CD_KJN_CD,'||
					'DCF_CD_YOBI,'||
					'SENMONI_CD,'||
					'SENMONI_FLG,'||
					'SENMONI_KEISAI_D_Y,'||
					'SENMONI_KEISAI_D_M,'||
					'SENMONI_KEISAI_D_D,'||
                                        'NINTEII_FLG,'||
					'NINTEII_KEISAI_D_Y,'||
					'NINTEII_KEISAI_D_M,'||
					'NINTEII_KEISAI_D_D,'||
					'SHIDOI_FLG,'||
					'SHIDOI_KEISAI_D_Y,'||
					'SHIDOI_KEISAI_D_M,'||
					'SHIDOI_KEISAI_D_D,'||
					'YOBI,'||
					'TENSO_Y,'||
					'TENSO_M,'||
					'TENSO_D,'||
					'MENTE_Y,'||
					'MENTE_M,'||
					'MENTE_D,'||
					'SENMONI_MENTE_KBN,'||
					'MOD_KBN,'||
					'TRK_OPE_CD,'||
					'TRK_DATE,'||
					'TRK_PGM_ID,'||
					'UPD_OPE_CD,'||
					'UPD_DATE,'||
					'UPD_PGM_ID)'||
                'SELECT'||
					'A.REC_ID,'||
					'A.KJN_CD,'||
					'NULL,'||
					'B.SENMONI_CD,'||
					'B.SENMONI_FLG,'||
					'SUBSTR(B.SENMONI_KEISAI_YMD,1,4),'||
					'SUBSTR(B.SENMONI_KEISAI_YMD,5,2),'||
					'SUBSTR(B.SENMONI_KEISAI_YMD,7,2),'||
					'B.NINTEII_FLG ,'||
					'SUBSTR(B.NINTEII_KEISAI_YMD,1,4),'||
					'SUBSTR(B.NINTEII_KEISAI_YMD,5,2),'||
					'SUBSTR(B.NINTEII_KEISAI_YMD,7,2),'||
					'B.SHIDOI_FLG ,'||
					'SUBSTR(B.SHIDOI_KEISAI_YMD,1,4),'||
					'SUBSTR(B.SHIDOI_KEISAI_YMD,5,2),'||
					'SUBSTR(B.SHIDOI_KEISAI_YMD,7,2),'||
					'NULL,'||
					'SUBSTR(iTensoYMD,1,4),'||
					'SUBSTR(iTensoYMD,5,2),'||
					'SUBSTR(iTensoYMD,7,2),'||
                                        'SUBSTR(B.UPD_EIGY_YMD,1,4),'||
					'SUBSTR(B.UPD_EIGY_YMD,5,2),'||
					'SUBSTR(B.UPD_EIGY_YMD,7,2),'||
					'NULL,'||
					'NULL,'||
					'iOPE_CD,'||
					'iDATE,'||
					'iPGM_ID,'||
					'iOPE_CD,'||
					'iDATE,'||
					'iPGM_ID'||
		'FROM TT_TIKY_KJN A'||
                'INNER JOIN TT_TIKY_KJN_SENMONI B'||
                'ON A.REC_ID = B.REC_ID'||
                'AND A.KJN_CD = B.KJN_CD'||
	        'WHERE A.REC_ID = ''01'''||
	        'AND A.DEL_FLG IS NULL'||
	        'AND B.SOSHITSU_FLG IS NULL';	
                ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

		END IF; 
	END IF;
	COMMIT;
	-- �I�����O�o��
        ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'PL/SQL End',PGM_ID || '�̏������I�����܂����B',iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);
        return 0;
	-- ��O����
	EXCEPTION
		-- ���̑��G���[
		WHEN OTHERS THEN
			W_ERR_INF_RCD.ERR_CD 		:= TO_CHAR(SQLCODE);
			W_ERR_INF_RCD.ERR_MSG 		:= SUBSTR(SQLERRM, 0, 500);
			W_ERR_INF_RCD.ERR_KEY_INF 	:= SUBSTR('iLayoutKind:' || iLayoutKind || ', iShimeKind:' || iShimeKind , 0,500);
			W_INDEX_N 			:= W_ERR_INF_TBL.COUNT + 1;
			W_ERR_INF_TBL.EXTEND;
			W_ERR_INF_TBL(W_INDEX_N) 	:= W_ERR_INF_RCD;

			OPEN oOUT_ERR_INF_CSR FOR
				SELECT * FROM TABLE(W_ERR_INF_TBL);

	   ROLLBACK;
        
	--�G���[���O�̓o�^
        ULT_INSERT_LOG_TABLE('ERROR',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'ERROR_INFO',W_ERR_INF_RCD.ERR_MSG,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

        return 1;
        END;
    END;
/

