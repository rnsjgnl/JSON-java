CREATE OR REPLACE PACKAGE NH010106B001_521
/* **********************************************************
 *  Copyright(c) 2011 beyond, INTEC Inc. All rights reserved.
 * **********************************************************/
AUTHID CURRENT_USER
IS
	/*** �J�[�\���^ ***************************************************************/
	-- �G���[���i�[�p�J�[�\���^
	TYPE ERR_INF_CSR		IS REF CURSOR;

	/*
	************************************************************************
	*  �����w��f��DB�f�[�^�̍쐬
	*  CREATE_DCF_ISI
	************************************************************************
	*/
	FUNCTION CREATE_DCF_GAKKAI(
	iLayoutKind	IN	INTEGER,										-- ���C�A�E�g�敪
	iShimeKind	IN	INTEGER,										-- ���ߓ��敪
  iTensoYMD	IN	VARCHAR2,										-- �]���N���� 
	iIP_ADDR	IN TL_STORED_SHORI.IP%TYPE,							-- ���s�[��IP�A�h���X (FW�Őݒ�)
	iWINDOWS_LOGIN_USER	IN TL_STORED_SHORI.WINDOWS_LOGIN_USER%TYPE, -- ���s�[��OS���[�U�[ (FW�Őݒ�)
	oROW_COUNT	OUT NUMBER,         -- �o�^����
	oOUT_ERR_INF_CSR 	OUT ERR_INF_CSR,    -- �G���[���J�[�\��
   iOPE_CD IN Varchar2,                      -- �I�y���[�^�R�[�h
  iPGM_ID IN Varchar2,                      -- �v���O����ID
  iDATE DATE                              -- �V�X�e������
	) RETURN NUMBER;
    
END;
/

CREATE OR REPLACE PACKAGE BODY NH010106B001_521
/* **********************************************************
 *  Copyright(c) 2011 beyond, INTEC Inc. All rights reserved.
 * **********************************************************/
IS
	/*
	 ************************************************************************
	 * Function ID  : CREATE_DCF_GAKKAI
	 * Program Name : �����w�� �f��DB�f�[�^�̍쐬
	 * Parameter    :  <I> iLayoutKind	    	�F���C�A�E�g�敪
	 *		   		   <I> iShimeKind	    	�F���ߓ��敪
	 *				   <I> iTensoYMD	    	�F�]���N����
	 *				   <I> iOPE_CD		        �F�I�y���[�^�R�[�h
	 *				   <I> iPGM_ID		        �F�v���O����ID
	 *				   <I> iDATE		        �F�V�X�e������ 
	 *		           <I> iIP_ADDR		        �F���s�[��IP�A�h���X
	 *		           <I> iWINDOWS_LOGIN_USER  �F���s�[��IP�A�h���X
	 *                 <O> oROW_COUNT		    �F�X�V����
	 *                <O> oOUT_ERR_INF_CSR	�F�G���[���J�[�\��
	 * Return       �F�������ʁi0:����I���A1:�ُ�I���j
	 ************************************************************************
	 */
	FUNCTION CREATE_DCF_GAKKAI(
	iLayoutKind	IN	INTEGER,										-- ���C�A�E�g�敪
	iShimeKind	IN	INTEGER,										-- ���ߓ��敪
        iTensoYMD	IN	VARCHAR2,										-- �]���N���� 
	iIP_ADDR	IN TL_STORED_SHORI.IP%TYPE,							-- ���s�[��IP�A�h���X (FW�Őݒ�)
	iWINDOWS_LOGIN_USER	IN TL_STORED_SHORI.WINDOWS_LOGIN_USER%TYPE, -- ���s�[��OS���[�U�[ (FW�Őݒ�)
	oROW_COUNT	OUT NUMBER,         -- �o�^����
	oOUT_ERR_INF_CSR 	OUT ERR_INF_CSR,    -- �G���[���J�[�\��
  iOPE_CD IN Varchar2,                      -- �I�y���[�^�R�[�h
  iPGM_ID IN Varchar2,                      -- �v���O����ID
  iDATE DATE                            -- �V�X�e������  
	)RETURN NUMBER IS
  
  PRAGMA AUTONOMOUS_TRANSACTION;
	/************************************************************************/
	/*                              �G���[����                              */
	/************************************************************************/
	W_INDEX_N 					NUMBER(10) := 0;
	W_ERR_INF_TBL 				TYPE_ERR_INFO_TBL := TYPE_ERR_INFO_TBL();
	W_ERR_INF_RCD 				TYPE_ERR_INFO_RCD := TYPE_ERR_INFO_RCD(NULL,NULL,NULL,NULL);
    vSchemaNm     TM_JOSU.HANYO_KOMOKU%TYPE := NULL; -- �X�L�[�}����
	PGM_ID        VARCHAR2(50) := 'NH010106B001_521.CREATE_DCF_GAKKAI';
	EXECUTE_SQL   VARCHAR2(32767) := NULL;

      BEGIN
      -- �J�n���O�o��
      ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'PL/SQL Start',PGM_ID || '�̏������J�n���܂��B',iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);
      -- �[�i�p�X�L�[�}�̎擾���s���B
      vSchemaNm := ULT_COMMON.GET_SCHEMA_NAME(ULT_COMMON.SYS_ENV_JOSU_DAI_CD, ULT_COMMON.NOHIN_SHEMA_JOSU_SHO_CD);
      oROW_COUNT:= -1;

      IF iLayoutKind = 1 THEN
          -- �V���C�A�E�g       
        IF iShimeKind = 1 THEN
          --�V_�S��_DCF��t�e�[�u���̃f�[�^���N���A����B
          EXECUTE_SQL := 'TRUNCATE TABLE ' || vSchemaNm || '.' || 'TD_NA_GAKKAI';
          EXECUTE IMMEDIATE EXECUTE_SQL;
          ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);
          INSERT INTO TD_NA_GAKKAI(
                LAYOUT_KBN,											
	        REC_ID,											
	        KJN_CD,											
	        YOBI_1,											
	        MOD_KBN,											
	        GAKKAI_CD,											
	        SZK_GAKKAI_MENTE_KBN,											
	        MENTE_YMD,
                YOBI_2,											
	        YOBI_3,																							
	        GAKKAI_NENDO,												
                TENSO_YMD,
                TRK_OPE_CD,
                TRK_DATE,
                TRK_PGM_ID,
                UPD_OPE_CD,
                UPD_DATE,
                UPD_PGM_ID)
          SELECT
                '521',											
	        A.REC_ID,
                A.KJN_CD,
	        NULL,
	        NULL,
	        B.GAKKAI_CD,
	        NULL,
	        MAX(B.UPD_EIGY_YMD),		
                NULL,
	        NULL,
	        MAX(B.GAKKAI_NENDO),
                iTensoYMD,
                iOPE_CD,
                iDATE,
                iPGM_ID,
                iOPE_CD,
                iDATE,
                iPGM_ID
          FROM TT_TIKY_KJN A												
          INNER JOIN TT_TIKY_KJN_GAKKAI B												
          ON A.REC_ID = B.REC_ID											
          AND A.KJN_CD = B.KJN_CD
          WHERE A.REC_ID = '01'								
          AND A.DEL_FLG IS NULL								
          AND B.DEL_FLG IS NULL	
          GROUP BY							
          A.REC_ID,						
          A.KJN_CD,						
          B.GAKKAI_CD;
          EXECUTE_SQL :=  'INSERT INTO TD_NA_GAKKAI('||
                'LAYOUT_KBN,			'||								
	        'REC_ID,			'||								
	        'KJN_CD,			'||								
	        'YOBI_1,			'||								
	        'MOD_KBN,			'||								
	        'GAKKAI_CD,			'||								
	        'SZK_GAKKAI_MENTE_KBN,		'||									
	        'MENTE_YMD,'||
                'YOBI_2,'||											
	        'YOBI_3,'||																							
	        'GAKKAI_NENDO,		'||										
                'TENSO_YMD,'||
                'TRK_OPE_CD,'||
                'TRK_DATE,'||
                'TRK_PGM_ID,'||
                'UPD_OPE_CD,'||
                'UPD_DATE,'||
                'UPD_PGM_ID)'||
          '    SELECT                                                          '||
                '''521'''  || ','                                        ||											
	        'A.REC_ID,'||
                'A.KJN_CD,'||
	        'NULL,'||
	        'NULL,'||
	        'B.GAKKAI_CD,'||
	        'NULL,'||
	        'MAX(B.UPD_EIGY_YMD),		'||
                'NULL,'||
	        'NULL,'||
	        'MAX(B.GAKKAI_NENDO),'||
                'iTensoYMD,'||
                'iOPE_CD,'||
                'iDATE,'||
                'iPGM_ID,'||
                'iOPE_CD,'||
                'iDATE,'||
                'iPGM_ID'||
          'FROM TT_TIKY_KJN A	'||											
          'INNER JOIN TT_TIKY_KJN_GAKKAI B		'||										
          'ON A.REC_ID = B.REC_ID			'||								
          'AND A.KJN_CD = B.KJN_CD'||
          'WHERE A.REC_ID = ''01'''||								
          'AND A.DEL_FLG IS NULL'||								
          'AND B.DEL_FLG IS NULL'||
          'GROUP BY'||							
          'A.REC_ID,'||						
          'A.KJN_CD,'||						
          'B.GAKKAI_CD';
	  ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

        END IF;
        
      ELSIF iLayoutKind = 2 THEN
        -- �b�背�C�A�E�g
        IF iShimeKind = 1 THEN
          
          --�b��_�S��_�����w��_VAN�e�[�u���̃f�[�^���N���A����B
          EXECUTE_SQL := 'TRUNCATE TABLE ' || vSchemaNm || '.' || 'TD_PA_GAKKAI_VAN';
          EXECUTE IMMEDIATE EXECUTE_SQL;
          ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);
          INSERT INTO TD_PA_GAKKAI_VAN(                                               
              REC_ID,																						
              TAG_NO,																						
              KJN_CD,																						
	      GAKKAI_RENBAN,																						
	      KEIZOKU_FLG,																						
	      GAKKAI_1_NENDO,																						
	      GAKKAI_1_CD,																						
	      GAKKAI_2_NENDO,																						
	      GAKKAI_2_CD,																						
	      GAKKAI_3_NENDO,																						
	      GAKKAI_3_CD,																						
	      GAKKAI_4_NENDO,																						
	      GAKKAI_4_CD,																						
	      GAKKAI_5_NENDO,																						
	      GAKKAI_5_CD,																						
	      GAKKAI_6_NENDO,																						
	      GAKKAI_6_CD,																						
	      GAKKAI_7_NENDO,																						
	      GAKKAI_7_CD,																						
	      GAKKAI_8_NENDO,																						
	      GAKKAI_8_CD,																						
	      GAKKAI_9_NENDO,																						
	      GAKKAI_9_CD,																						
	      GAKKAI_10_NENDO,																						
	      GAKKAI_10_CD,																						
	      GAKKAI_11_NENDO,																						
	      GAKKAI_11_CD,																						
	      GAKKAI_12_NENDO,																						
	      GAKKAI_12_CD,																						
	      GAKKAI_13_NENDO,																						
	      GAKKAI_13_CD,																						
	      GAKKAI_14_NENDO,																						
	      GAKKAI_14_CD,																						
	      GAKKAI_15_NENDO,																						
	      GAKKAI_15_CD,																						
	      GAKKAI_16_NENDO,																						
	      GAKKAI_16_CD,																						
	      GAKKAI_17_NENDO,																						
	      GAKKAI_17_CD,																						
	      GAKKAI_18_NENDO,																						
	      GAKKAI_18_CD,																						
	      GAKKAI_19_NENDO,																						
	      GAKKAI_19_CD,																						
              GAKKAI_20_NENDO,																						
	      GAKKAI_20_CD,																						
	      GAKKAI_21_NENDO,																						
	      GAKKAI_21_CD,																						
	      GAKKAI_22_NENDO,																						
	      GAKKAI_22_CD,																						
	      GAKKAI_23_NENDO,																						
	      GAKKAI_23_CD,																						
	      GAKKAI_24_NENDO,																						
	      GAKKAI_24_CD,																						
	      GAKKAI_25_NENDO,																						
	      GAKKAI_25_CD,																						
	      GAKKAI_26_NENDO,																						
	      GAKKAI_26_CD,																						
	      GAKKAI_27_NENDO,																						
	      GAKKAI_27_CD,																						
	      GAKKAI_28_NENDO,																						
	      GAKKAI_28_CD,																						
	      GAKKAI_29_NENDO,																						
	      GAKKAI_29_CD,																						
	      GAKKAI_30_NENDO,																						
	      GAKKAI_30_CD,																						
	      TENSO_Y,																						
	      TENSO_M,																						
	      TENSO_D,																						
	      MENTE_Y,																						
	      MENTE_M,																						
	      MENTE_D,																						
	      MOD_KBN,						
              TRK_OPE_CD,
              TRK_DATE,
              TRK_PGM_ID,
              UPD_OPE_CD,
              UPD_DATE,
              UPD_PGM_ID)  
   SELECT                                                                                           
        '01',																						
        '06',																						
        T.KJN_CD,																						
	TO_CHAR(GAKKAI_RENBAN),																						
	DECODE(GAKKAI_RENBAN, 0, '0', '1'),																						
	MAX(DECODE(T.SORT_NO, 1, T.GAKKAI_NENDO, NULL)),																						
	MAX(DECODE(T.SORT_NO, 1, T.GAKKAI_CD, NULL)),																						
	MAX(DECODE(T.SORT_NO, 2, T.GAKKAI_NENDO, NULL)),																						
	MAX(DECODE(T.SORT_NO, 2, T.GAKKAI_CD, NULL)),																						
	MAX(DECODE(T.SORT_NO, 3, T.GAKKAI_NENDO, NULL)),																						
	MAX(DECODE(T.SORT_NO, 3, T.GAKKAI_CD, NULL)),																						
	MAX(DECODE(T.SORT_NO, 4, T.GAKKAI_NENDO, NULL)),																						
	MAX(DECODE(T.SORT_NO, 4, T.GAKKAI_CD, NULL)),																						
	MAX(DECODE(T.SORT_NO, 5, T.GAKKAI_NENDO, NULL)),																						
	MAX(DECODE(T.SORT_NO, 5, T.GAKKAI_CD, NULL)),																						
	MAX(DECODE(T.SORT_NO, 6, T.GAKKAI_NENDO, NULL)),																						
	MAX(DECODE(T.SORT_NO, 6, T.GAKKAI_CD, NULL)),																						
	MAX(DECODE(T.SORT_NO, 7, T.GAKKAI_NENDO, NULL)),																						
	MAX(DECODE(T.SORT_NO, 7, T.GAKKAI_CD, NULL)),																						
	MAX(DECODE(T.SORT_NO, 8, T.GAKKAI_NENDO, NULL)),																						
	MAX(DECODE(T.SORT_NO, 8, T.GAKKAI_CD, NULL)),																						
	MAX(DECODE(T.SORT_NO, 9, T.GAKKAI_NENDO, NULL)),																						
	MAX(DECODE(T.SORT_NO, 9, T.GAKKAI_CD, NULL)),																						
	MAX(DECODE(T.SORT_NO, 10, T.GAKKAI_NENDO, NULL)),																						
	MAX(DECODE(T.SORT_NO, 10, T.GAKKAI_CD, NULL)),																						
	MAX(DECODE(T.SORT_NO, 11, T.GAKKAI_NENDO, NULL)),																						
	MAX(DECODE(T.SORT_NO, 11, T.GAKKAI_CD, NULL)),																						
	MAX(DECODE(T.SORT_NO, 12, T.GAKKAI_NENDO, NULL)),																						
	MAX(DECODE(T.SORT_NO, 12, T.GAKKAI_CD, NULL)),																						
	MAX(DECODE(T.SORT_NO, 13, T.GAKKAI_NENDO, NULL)),																						
	MAX(DECODE(T.SORT_NO, 13, T.GAKKAI_CD, NULL)),																						
	MAX(DECODE(T.SORT_NO, 14, T.GAKKAI_NENDO, NULL)),																						
	MAX(DECODE(T.SORT_NO, 14, T.GAKKAI_CD, NULL)),																						
	MAX(DECODE(T.SORT_NO, 15, T.GAKKAI_NENDO, NULL)),																						
	MAX(DECODE(T.SORT_NO, 15, T.GAKKAI_CD, NULL)),																						
	MAX(DECODE(T.SORT_NO, 16, T.GAKKAI_NENDO, NULL)),																						
	MAX(DECODE(T.SORT_NO, 16, T.GAKKAI_CD, NULL)) ,																						
	MAX(DECODE(T.SORT_NO, 17, T.GAKKAI_NENDO, NULL)),																						
	MAX(DECODE(T.SORT_NO, 17, T.GAKKAI_CD, NULL)) ,																						
	MAX(DECODE(T.SORT_NO, 18, T.GAKKAI_NENDO, NULL)),																						
	MAX(DECODE(T.SORT_NO, 18, T.GAKKAI_CD, NULL)),																						
	MAX(DECODE(T.SORT_NO, 19, T.GAKKAI_NENDO, NULL)),																						
	MAX(DECODE(T.SORT_NO, 19, T.GAKKAI_CD, NULL)),																						
	MAX(DECODE(T.SORT_NO, 20, T.GAKKAI_NENDO, NULL)),																						
	MAX(DECODE(T.SORT_NO, 20, T.GAKKAI_CD, NULL)),																						
	MAX(DECODE(T.SORT_NO, 21, T.GAKKAI_NENDO, NULL)),																						
	MAX(DECODE(T.SORT_NO, 21, T.GAKKAI_CD, NULL)),																						
	MAX(DECODE(T.SORT_NO, 22, T.GAKKAI_NENDO, NULL)),																						
	MAX(DECODE(T.SORT_NO, 22, T.GAKKAI_CD, NULL)),																						
	MAX(DECODE(T.SORT_NO, 23, T.GAKKAI_NENDO, NULL)),																						
	MAX(DECODE(T.SORT_NO, 23, T.GAKKAI_CD, NULL)),																						
	MAX(DECODE(T.SORT_NO, 24, T.GAKKAI_NENDO, NULL)),																						
	MAX(DECODE(T.SORT_NO, 24, T.GAKKAI_CD, NULL)),																						
	MAX(DECODE(T.SORT_NO, 25, T.GAKKAI_NENDO, NULL)),																						
	MAX(DECODE(T.SORT_NO, 25, T.GAKKAI_CD, NULL)),																						
	MAX(DECODE(T.SORT_NO, 26, T.GAKKAI_NENDO, NULL)),																						
	MAX(DECODE(T.SORT_NO, 26, T.GAKKAI_CD, NULL)),																						
	MAX(DECODE(T.SORT_NO, 27, T.GAKKAI_NENDO, NULL)),																						
	MAX(DECODE(T.SORT_NO, 27, T.GAKKAI_CD, NULL)) ,																						
	MAX(DECODE(T.SORT_NO, 28, T.GAKKAI_NENDO, NULL)),																						
	MAX(DECODE(T.SORT_NO, 28, T.GAKKAI_CD, NULL)),																						
	MAX(DECODE(T.SORT_NO, 29, T.GAKKAI_NENDO, NULL)),																						
	MAX(DECODE(T.SORT_NO, 29, T.GAKKAI_CD, NULL)),																						
	MAX(DECODE(T.SORT_NO, 30, T.GAKKAI_NENDO, NULL)),																						
	MAX(DECODE(T.SORT_NO, 30, T.GAKKAI_CD, NULL)),																						
	SUBSTR(iTensoYMD,1,4),																						
	SUBSTR(iTensoYMD,5,2),																						
	SUBSTR(iTensoYMD,7,2),																						
	SUBSTR(MAX(T.UPD_EIGY_YMD),1,4),																						
	SUBSTR(MAX(T.UPD_EIGY_YMD),5,2),																						
	SUBSTR(MAX(T.UPD_EIGY_YMD),7,2),																						
	NULL,
        iOPE_CD,
        iDATE,
        iPGM_ID,
        iOPE_CD,
        iDATE,
        iPGM_ID
  	FROM																				
		 (SELECT																			
			KJN_CD,																		
			GAKKAI_CD,																		
			GAKKAI_NENDO,																		
			UPD_EIGY_YMD,																		
			DECODE(MOD(SORT_NO, 30),0,30,MOD(SORT_NO, 30)) AS SORT_NO,																		
			TRUNC((SORT_NO-1)/30) AS GAKKAI_RENBAN																		
		FROM 																			
			 (SELECT N.*,
                                 ROW_NUMBER() OVER (PARTITION BY 																	
					KJN_CD	
                                        ORDER BY																
					GAKKAI_CD,GAKKAI_NENDO DESC) AS SORT_NO	
                          FROM	
                                (SELECT																		
				A.KJN_CD AS KJN_CD,																	
				B.GAKKAI_CD AS GAKKAI_CD,																	
				MAX(B.GAKKAI_NENDO) AS GAKKAI_NENDO,																	
				MAX(B.UPD_EIGY_YMD) AS UPD_EIGY_YMD																
			FROM TT_TIKY_KJN A																		
			INNER JOIN TT_TIKY_KJN_GAKKAI B																		
				ON A.REC_ID = B.REC_ID																	
				AND A.KJN_CD = B.KJN_CD																	
			WHERE A.REC_ID = '01'																		
			AND A.DEL_FLG IS NULL																		
			AND B.DEL_FLG IS NULL																		
			GROUP BY																		
				A.KJN_CD,																	
				B.GAKKAI_CD )N )) T
                        GROUP BY										
                        T.KJN_CD,									
                        T.GAKKAI_RENBAN	;
          EXECUTE_SQL :=  'INSERT INTO TD_PA_GAKKAI_VAN(                     '||                          
              'REC_ID,								'||														
              'TAG_NO,								'||														
              'KJN_CD,								'||														
	      'GAKKAI_RENBAN,							'||															
	      'KEIZOKU_FLG,							'||															
	      'GAKKAI_1_NENDO,							'||															
	      'GAKKAI_1_CD,							'||															
	      'GAKKAI_2_NENDO,							'||															
	      'GAKKAI_2_CD,							'||															
	      'GAKKAI_3_NENDO,							'||															
	      'GAKKAI_3_CD,							'||															
	      'GAKKAI_4_NENDO,							'||															
	      'GAKKAI_4_CD,							'||															
	      'GAKKAI_5_NENDO,							'||															
	      'GAKKAI_5_CD,							'||															
	      'GAKKAI_6_NENDO,							'||															
	      'GAKKAI_6_CD,							'||															
	      'GAKKAI_7_NENDO,							'||															
	      'GAKKAI_7_CD,							'||															
	      'GAKKAI_8_NENDO,							'||															
	      'GAKKAI_8_CD,							'||															
	      'GAKKAI_9_NENDO,							'||															
	      'GAKKAI_9_CD,							'||															
	      'GAKKAI_10_NENDO,							'||															
	      'GAKKAI_10_CD,							'||															
	      'GAKKAI_11_NENDO,							'||															
	      'GAKKAI_11_CD,							'||															
	      'GAKKAI_12_NENDO,							'||															
	      'GAKKAI_12_CD,							'||															
	      'GAKKAI_13_NENDO,							'||															
	      'GAKKAI_13_CD,							'||															
	      'GAKKAI_14_NENDO,							'||															
	      'GAKKAI_14_CD,							'||															
	      'GAKKAI_15_NENDO,							'||															
	      'GAKKAI_15_CD,							'||															
	      'GAKKAI_16_NENDO,							'||															
	      'GAKKAI_16_CD,							'||															
	      'GAKKAI_17_NENDO,							'||															
	      'GAKKAI_17_CD,							'||															
	      'GAKKAI_18_NENDO,							'||															
	      'GAKKAI_18_CD,							'||															
	      'GAKKAI_19_NENDO,							'||															
	      'GAKKAI_19_CD,							'||															
              'GAKKAI_20_NENDO,							'||															
	      'GAKKAI_20_CD,							'||															
	      'GAKKAI_21_NENDO,							'||															
	      'GAKKAI_21_CD,							'||															
	      'GAKKAI_22_NENDO,							'||															
	      'GAKKAI_22_CD,							'||															
	      'GAKKAI_23_NENDO,							'||															
	      'GAKKAI_23_CD,							'||															
	      'GAKKAI_24_NENDO,							'||															
	      'GAKKAI_24_CD,							'||															
	      'GAKKAI_25_NENDO,							'||															
	      'GAKKAI_25_CD,							'||															
	      'GAKKAI_26_NENDO,							'||															
	      'GAKKAI_26_CD,							'||															
	      'GAKKAI_27_NENDO,							'||															
	      'GAKKAI_27_CD,							'||															
	      'GAKKAI_28_NENDO,							'||															
	      'GAKKAI_28_CD,							'||															
	      'GAKKAI_29_NENDO,							'||															
	      'GAKKAI_29_CD,							'||															
	      'GAKKAI_30_NENDO,							'||															
	      'GAKKAI_30_CD,							'||															
	      'TENSO_Y,								'||														
	      'TENSO_M,								'||														
	      'TENSO_D,								'||														
	      'MENTE_Y,								'||														
	      'MENTE_M,								'||														
	      'MENTE_D,								'||														
	      'MOD_KBN,						'||
              'TRK_OPE_CD,'||
              'TRK_DATE,'||
              'TRK_PGM_ID,'||
              'UPD_OPE_CD,'||
              'UPD_DATE,'||
              'UPD_PGM_ID) '|| 
   '    SELECT                                                          '||
        '''01'''  || ','                                        ||
        '''06'''   || ','                                        ||																						
        'T.KJN_CD,						'||																
	'TO_CHAR(GAKKAI_RENBAN),				'||																		
	'DECODE(GAKKAI_RENBAN, 0, ''0'', ''1''),			'||																			
	'MAX(DECODE(T.SORT_NO, 1, T.GAKKAI_NENDO, NULL)) AS GAKKAI_1_NENDO,		'  ||																				
	'MAX(DECODE(T.SORT_NO, 1, T.GAKKAI_CD, NULL)) AS GAKKAI_1_CD,			'  ||																			
	'MAX(DECODE(T.SORT_NO, 2, T.GAKKAI_NENDO, NULL)) AS GAKKAI_2_NENDO,		'  ||																				
	'MAX(DECODE(T.SORT_NO, 2, T.GAKKAI_CD, NULL)) AS GAKKAI_2_CD,			'  ||																			
	'MAX(DECODE(T.SORT_NO, 3, T.GAKKAI_NENDO, NULL)) AS GAKKAI_3_NENDO,		'  ||																				
	'MAX(DECODE(T.SORT_NO, 3, T.GAKKAI_CD, NULL)) AS GAKKAI_3_CD,			'  ||																			
	'MAX(DECODE(T.SORT_NO, 4, T.GAKKAI_NENDO, NULL)) AS GAKKAI_4_NENDO,		'  ||																				
	'MAX(DECODE(T.SORT_NO, 4, T.GAKKAI_CD, NULL)) AS GAKKAI_4_CD,			'  ||																			
	'MAX(DECODE(T.SORT_NO, 5, T.GAKKAI_NENDO, NULL)) AS GAKKAI_5_NENDO,		'  ||																				
	'MAX(DECODE(T.SORT_NO, 5, T.GAKKAI_CD, NULL)) AS GAKKAI_5_CD,			'  ||																			
	'MAX(DECODE(T.SORT_NO, 6, T.GAKKAI_NENDO, NULL)) AS GAKKAI_6_NENDO,		'  ||																				
	'MAX(DECODE(T.SORT_NO, 6, T.GAKKAI_CD, NULL)) AS GAKKAI_6_CD,			'  ||																			
	'MAX(DECODE(T.SORT_NO, 7, T.GAKKAI_NENDO, NULL)) AS GAKKAI_7_NENDO,		'  ||																				
	'MAX(DECODE(T.SORT_NO, 7, T.GAKKAI_CD, NULL)) AS GAKKAI_7_CD,			'  ||																			
	'MAX(DECODE(T.SORT_NO, 8, T.GAKKAI_NENDO, NULL)) AS GAKKAI_8_NENDO,		'  ||																				
	'MAX(DECODE(T.SORT_NO, 8, T.GAKKAI_CD, NULL)) AS GAKKAI_8_CD,			'  ||																			
	'MAX(DECODE(T.SORT_NO, 9, T.GAKKAI_NENDO, NULL)) AS GAKKAI_9_NENDO,		'  ||																				
	'MAX(DECODE(T.SORT_NO, 9, T.GAKKAI_CD, NULL)) AS GAKKAI_9_CD,			'  ||																			
	'MAX(DECODE(T.SORT_NO, 10, T.GAKKAI_NENDO, NULL)) AS GAKKAI_10_NENDO,		'  ||																				
	'MAX(DECODE(T.SORT_NO, 10, T.GAKKAI_CD, NULL)) AS GAKKAI_10_CD,		'  ||																				
	'MAX(DECODE(T.SORT_NO, 11, T.GAKKAI_NENDO, NULL)) AS GAKKAI_11_NENDO,		'  ||																				
	'MAX(DECODE(T.SORT_NO, 11, T.GAKKAI_CD, NULL)) AS GAKKAI_11_CD,		'  ||																				
	'MAX(DECODE(T.SORT_NO, 12, T.GAKKAI_NENDO, NULL)) AS GAKKAI_12_NENDO,		'  ||																				
	'MAX(DECODE(T.SORT_NO, 12, T.GAKKAI_CD, NULL)) AS GAKKAI_12_CD,		'  ||																				
	'MAX(DECODE(T.SORT_NO, 13, T.GAKKAI_NENDO, NULL)) AS GAKKAI_13_NENDO,		'  ||																				
	'MAX(DECODE(T.SORT_NO, 13, T.GAKKAI_CD, NULL)) AS GAKKAI_13_CD,		'  ||																				
	'MAX(DECODE(T.SORT_NO, 14, T.GAKKAI_NENDO, NULL)) AS GAKKAI_14_NENDO,		'  ||																				
	'MAX(DECODE(T.SORT_NO, 14, T.GAKKAI_CD, NULL)) AS GAKKAI_14_CD,		'  ||																				
	'MAX(DECODE(T.SORT_NO, 15, T.GAKKAI_NENDO, NULL)) AS GAKKAI_15_NENDO,		'  ||																				
	'MAX(DECODE(T.SORT_NO, 15, T.GAKKAI_CD, NULL)) AS GAKKAI_15_CD,		'  ||																				
	'MAX(DECODE(T.SORT_NO, 16, T.GAKKAI_NENDO, NULL)) AS GAKKAI_16_NENDO,		'  ||																				
	'MAX(DECODE(T.SORT_NO, 16, T.GAKKAI_CD, NULL)) AS GAKKAI_16_CD,		'  ||																				
	'MAX(DECODE(T.SORT_NO, 17, T.GAKKAI_NENDO, NULL)) AS GAKKAI_17_NENDO,		'  ||																				
	'MAX(DECODE(T.SORT_NO, 17, T.GAKKAI_CD, NULL)) AS GAKKAI_17_CD,		'  ||																				
	'MAX(DECODE(T.SORT_NO, 18, T.GAKKAI_NENDO, NULL)) AS GAKKAI_18_NENDO,		'  ||																				
	'MAX(DECODE(T.SORT_NO, 18, T.GAKKAI_CD, NULL)) AS GAKKAI_18_CD,		'  ||																				
	'MAX(DECODE(T.SORT_NO, 19, T.GAKKAI_NENDO, NULL)) AS GAKKAI_19_NENDO,		'  ||																				
	'MAX(DECODE(T.SORT_NO, 19, T.GAKKAI_CD, NULL)) AS GAKKAI_19_CD,		'  ||																				
	'MAX(DECODE(T.SORT_NO, 20, T.GAKKAI_NENDO, NULL)) AS GAKKAI_20_NENDO,		'  ||																				
	'MAX(DECODE(T.SORT_NO, 20, T.GAKKAI_CD, NULL)) AS GAKKAI_20_CD,		'  ||																				
	'MAX(DECODE(T.SORT_NO, 21, T.GAKKAI_NENDO, NULL)) AS GAKKAI_21_NENDO,		'  ||																				
	'MAX(DECODE(T.SORT_NO, 21, T.GAKKAI_CD, NULL)) AS GAKKAI_21_CD,		'  ||																				
	'MAX(DECODE(T.SORT_NO, 22, T.GAKKAI_NENDO, NULL)) AS GAKKAI_22_NENDO,		'  ||																				
	'MAX(DECODE(T.SORT_NO, 22, T.GAKKAI_CD, NULL)) AS GAKKAI_22_CD,		'  ||																				
	'MAX(DECODE(T.SORT_NO, 23, T.GAKKAI_NENDO, NULL)) AS GAKKAI_23_NENDO,		'  ||																				
	'MAX(DECODE(T.SORT_NO, 23, T.GAKKAI_CD, NULL)) AS GAKKAI_23_CD,		'  ||																				
	'MAX(DECODE(T.SORT_NO, 24, T.GAKKAI_NENDO, NULL)) AS GAKKAI_24_NENDO,		'  ||																				
	'MAX(DECODE(T.SORT_NO, 24, T.GAKKAI_CD, NULL)) AS GAKKAI_24_CD,		'  ||																				
	'MAX(DECODE(T.SORT_NO, 25, T.GAKKAI_NENDO, NULL)) AS GAKKAI_25_NENDO,		'  ||																				
	'MAX(DECODE(T.SORT_NO, 25, T.GAKKAI_CD, NULL)) AS GAKKAI_25_CD,		'  ||																				
	'MAX(DECODE(T.SORT_NO, 26, T.GAKKAI_NENDO, NULL)) AS GAKKAI_26_NENDO,		'  ||																				
	'MAX(DECODE(T.SORT_NO, 26, T.GAKKAI_CD, NULL)) AS GAKKAI_26_CD,		'  ||																				
	'MAX(DECODE(T.SORT_NO, 27, T.GAKKAI_NENDO, NULL)) AS GAKKAI_27_NENDO,		'  ||																				
	'MAX(DECODE(T.SORT_NO, 27, T.GAKKAI_CD, NULL)) AS GAKKAI_27_CD,		'  ||																				
	'MAX(DECODE(T.SORT_NO, 28, T.GAKKAI_NENDO, NULL)) AS GAKKAI_28_NENDO,		'  ||																				
	'MAX(DECODE(T.SORT_NO, 28, T.GAKKAI_CD, NULL)) AS GAKKAI_28_CD,		'  ||																				
	'MAX(DECODE(T.SORT_NO, 29, T.GAKKAI_NENDO, NULL)) AS GAKKAI_29_NENDO,		'  ||																				
	'MAX(DECODE(T.SORT_NO, 29, T.GAKKAI_CD, NULL)) AS GAKKAI_29_CD,		'  ||																				
	'MAX(DECODE(T.SORT_NO, 30, T.GAKKAI_NENDO, NULL)) AS GAKKAI_30_NENDO,		'  ||																				
	'MAX(DECODE(T.SORT_NO, 30, T.GAKKAI_CD, NULL)) AS GAKKAI_30_CD,		'  ||																									
	'SUBSTR(iTensoYMD,1,4),					'||																	
	'SUBSTR(iTensoYMD,5,2),					'||																	
	'SUBSTR(iTensoYMD,7,2),					'||																	
	'SUBSTR(MAX(T.UPD_EIGY_YMD),1,4),			'||																			
	'SUBSTR(MAX(T.UPD_EIGY_YMD),5,2),			'||																			
	'SUBSTR(MAX(T.UPD_EIGY_YMD),7,2),			'||																			
	'NULL,'||
        'iOPE_CD,'||
        'iDATE,'||
        'iPGM_ID,'||
        'iOPE_CD,'||
        'iDATE,'||
        'iPGM_ID'||
  	'FROM	'||																			
		 '(SELECT					'||														
			'KJN_CD,				'||														
			'GAKKAI_CD,				'||														
			'GAKKAI_NENDO,				'||														
			'UPD_EIGY_YMD,				'||														
			'DECODE(MOD(SORT_NO, 30),0,30,MOD(SORT_NO, 30)) AS SORT_NO,		'||																
			'TRUNC((SORT_NO-1)/30) AS GAKKAI_RENBAN					'||													
		'FROM 										'||									
			 '(SELECT N.*,'||
                                 'ROW_NUMBER() OVER (PARTITION BY 		'||															
					'KJN_CD	'||
                                        'ORDER BY'||																
					'GAKKAI_CD,GAKKAI_NENDO DESC) AS SORT_NO	'||
                          'FROM	'||
                                '(SELECT		'||																
				'A.KJN_CD AS KJN_CD,	'||																
				'B.GAKKAI_CD AS GAKKAI_CD,'||																	
				'MAX(B.GAKKAI_NENDO) AS GAKKAI_NENDO,	'||																
				'MAX(B.UPD_EIGY_YMD) AS UPD_EIGY_YMD	'||															
			'FROM TT_TIKY_KJN A				'||														
			'INNER JOIN TT_TIKY_KJN_GAKKAI B		'||																
				'ON A.REC_ID = B.REC_ID			'||														
				'AND A.KJN_CD = B.KJN_CD		'||															
			'WHERE A.REC_ID = ''01''				'||														
			'AND A.DEL_FLG IS NULL				'||														
			'AND B.DEL_FLG IS NULL				'||														
			'GROUP BY					'||													
				'A.KJN_CD,				'||													
				'B.GAKKAI_CD )N )) T'||
           'GROUP BY	'||									
           'T.KJN_CD,	'||								
           'T.GAKKAI_RENBAN	';
	   ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);
 
        
      ELSIF iShimeKind = 4 OR iShimeKind = 5 THEN

          --�b��_�S��_�����w��e�[�u���̃f�[�^���N���A����B
          EXECUTE_SQL := 'TRUNCATE TABLE ' || vSchemaNm || '.' || 'TD_PA_GAKKAI_KT';
          EXECUTE IMMEDIATE EXECUTE_SQL;
          ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);
          INSERT INTO TD_PA_GAKKAI_KT(                                               
              REC_ID,																													
              KJN_CD,																													
	      YOBI,																													
	      GAKKAI_RENBAN,																													
	      KEIZOKU_FLG,																													
	      GAKKAI_1_NENDO,																													
	      GAKKAI_1_CD,																													
	      GAKKAI_2_NENDO,																													
	      GAKKAI_2_CD,																													
	      GAKKAI_3_NENDO,																													
	      GAKKAI_3_CD,																													
	      GAKKAI_4_NENDO,																													
	      GAKKAI_4_CD,																													
	      GAKKAI_5_NENDO,																													
	      GAKKAI_5_CD,																													
	      GAKKAI_6_NENDO,																													
	      GAKKAI_6_CD,																													
	      GAKKAI_7_NENDO,																													
	      GAKKAI_7_CD,																													
	      GAKKAI_8_NENDO,																													
	      GAKKAI_8_CD,																													
	      GAKKAI_9_NENDO,																													
	      GAKKAI_9_CD,																													
	      GAKKAI_10_NENDO,																													
	      GAKKAI_10_CD,																													
	      GAKKAI_11_NENDO,																													
	      GAKKAI_11_CD,																													
	      GAKKAI_12_NENDO,																													
	      GAKKAI_12_CD,																													
	      GAKKAI_13_NENDO,																													
	      GAKKAI_13_CD,																													
	      GAKKAI_14_NENDO,																													
	      GAKKAI_14_CD,																													
	      GAKKAI_15_NENDO,																													
	      GAKKAI_15_CD,																													
	      GAKKAI_16_NENDO,																													
	      GAKKAI_16_CD,																													
	      GAKKAI_17_NENDO,																													
	      GAKKAI_17_CD,																													
	      GAKKAI_18_NENDO,																													
	      GAKKAI_18_CD,																													
	      GAKKAI_19_NENDO,																													
	      GAKKAI_19_CD,																													
	      GAKKAI_20_NENDO,																													
	      GAKKAI_20_CD,																													
	      GAKKAI_21_NENDO,																													
	      GAKKAI_21_CD,																													
	      GAKKAI_22_NENDO,																													
	      GAKKAI_22_CD,																													
	      GAKKAI_23_NENDO,																													
	      GAKKAI_23_CD,																													
	      GAKKAI_24_NENDO,																													
	      GAKKAI_24_CD,																													
	      GAKKAI_25_NENDO,																													
	      GAKKAI_25_CD,																													
	      GAKKAI_26_NENDO,																													
	      GAKKAI_26_CD,																													
	      GAKKAI_27_NENDO,																													
	      GAKKAI_27_CD,																													
	      GAKKAI_28_NENDO,																													
	      GAKKAI_28_CD,																													
	      GAKKAI_29_NENDO,																													
	      GAKKAI_29_CD,																													
	      GAKKAI_30_NENDO,																													
	      GAKKAI_30_CD,																													
	      GAKKAI_31_NENDO,																													
	      GAKKAI_31_CD,																													
	      GAKKAI_32_NENDO,																													
	      GAKKAI_32_CD,																													
	      GAKKAI_33_NENDO,																													
	      GAKKAI_33_CD,																													
	      GAKKAI_34_NENDO,																													
	      GAKKAI_34_CD,																													
	      GAKKAI_35_NENDO,																													
	      GAKKAI_35_CD,																													
	      GAKKAI_36_NENDO,																													
	      GAKKAI_36_CD,																													
	      GAKKAI_37_NENDO,																													
	      GAKKAI_37_CD,																													
	      GAKKAI_38_NENDO,																													
	      GAKKAI_38_CD,																													
	      GAKKAI_39_NENDO,																													
	      GAKKAI_39_CD,																													
	      GAKKAI_40_NENDO,																													
	      GAKKAI_40_CD,																													
	      GAKKAI_41_NENDO,																													
	      GAKKAI_41_CD,																													
              FILLER,									
              TRK_OPE_CD,
              TRK_DATE,
              TRK_PGM_ID,
              UPD_OPE_CD,
              UPD_DATE,
              UPD_PGM_ID)
  SELECT                                                       
        '01',																													
         T.KJN_CD,																													
	 NULL,																													
	 TO_CHAR(GAKKAI_RENBAN),																													
	 DECODE(GAKKAI_RENBAN, 0, '0', '1'),																													
	 MAX(DECODE(T.SORT_NO, 1, T.GAKKAI_NENDO, NULL)),																													
	 MAX(DECODE(T.SORT_NO, 1, T.GAKKAI_CD, NULL)),																													
	 MAX(DECODE(T.SORT_NO, 2, T.GAKKAI_NENDO, NULL)),																													
	 MAX(DECODE(T.SORT_NO, 2, T.GAKKAI_CD, NULL)),																													
	 MAX(DECODE(T.SORT_NO, 3, T.GAKKAI_NENDO, NULL)),																													
	 MAX(DECODE(T.SORT_NO, 3, T.GAKKAI_CD, NULL)),																													
	 MAX(DECODE(T.SORT_NO, 4, T.GAKKAI_NENDO, NULL)),																													
	 MAX(DECODE(T.SORT_NO, 4, T.GAKKAI_CD, NULL)),																													
	 MAX(DECODE(T.SORT_NO, 5, T.GAKKAI_NENDO, NULL)),																													
	 MAX(DECODE(T.SORT_NO, 5, T.GAKKAI_CD, NULL)),																													
	 MAX(DECODE(T.SORT_NO, 6, T.GAKKAI_NENDO, NULL)),																													
	 MAX(DECODE(T.SORT_NO, 6, T.GAKKAI_CD, NULL)),																													
	 MAX(DECODE(T.SORT_NO, 7, T.GAKKAI_NENDO, NULL)),																													
	 MAX(DECODE(T.SORT_NO, 7, T.GAKKAI_CD, NULL)),																													
	 MAX(DECODE(T.SORT_NO, 8, T.GAKKAI_NENDO, NULL)),																													
	 MAX(DECODE(T.SORT_NO, 8, T.GAKKAI_CD, NULL)),																													
	 MAX(DECODE(T.SORT_NO, 9, T.GAKKAI_NENDO, NULL)),																													
	 MAX(DECODE(T.SORT_NO, 9, T.GAKKAI_CD, NULL)),																													
	 MAX(DECODE(T.SORT_NO, 10, T.GAKKAI_NENDO, NULL)),																													
	 MAX(DECODE(T.SORT_NO, 10, T.GAKKAI_CD, NULL)),																													
	 MAX(DECODE(T.SORT_NO, 11, T.GAKKAI_NENDO, NULL)),																													
	 MAX(DECODE(T.SORT_NO, 11, T.GAKKAI_CD, NULL)),																													
	 MAX(DECODE(T.SORT_NO, 12, T.GAKKAI_NENDO, NULL)),																													
	 MAX(DECODE(T.SORT_NO, 12, T.GAKKAI_CD, NULL)),																													
	 MAX(DECODE(T.SORT_NO, 13, T.GAKKAI_NENDO, NULL)),																													
	 MAX(DECODE(T.SORT_NO, 13, T.GAKKAI_CD, NULL)),																													
	 MAX(DECODE(T.SORT_NO, 14, T.GAKKAI_NENDO, NULL)),																													
	 MAX(DECODE(T.SORT_NO, 14, T.GAKKAI_CD, NULL)),																													
	 MAX(DECODE(T.SORT_NO, 15, T.GAKKAI_NENDO, NULL)),																													
	 MAX(DECODE(T.SORT_NO, 15, T.GAKKAI_CD, NULL)),																													
	 MAX(DECODE(T.SORT_NO, 16, T.GAKKAI_NENDO, NULL)),																													
	 MAX(DECODE(T.SORT_NO, 16, T.GAKKAI_CD, NULL)),																													
	 MAX(DECODE(T.SORT_NO, 17, T.GAKKAI_NENDO, NULL)),																													
	 MAX(DECODE(T.SORT_NO, 17, T.GAKKAI_CD, NULL)),																													
	 MAX(DECODE(T.SORT_NO, 18, T.GAKKAI_NENDO, NULL)),																													
	 MAX(DECODE(T.SORT_NO, 18, T.GAKKAI_CD, NULL)),																													
	 MAX(DECODE(T.SORT_NO, 19, T.GAKKAI_NENDO, NULL)),																													
	 MAX(DECODE(T.SORT_NO, 19, T.GAKKAI_CD, NULL)),																													
	 MAX(DECODE(T.SORT_NO, 20, T.GAKKAI_NENDO, NULL)),																													
	 MAX(DECODE(T.SORT_NO, 20, T.GAKKAI_CD, NULL)),																													
	 MAX(DECODE(T.SORT_NO, 21, T.GAKKAI_NENDO, NULL)),																													
	 MAX(DECODE(T.SORT_NO, 21, T.GAKKAI_CD, NULL)),																													
	 MAX(DECODE(T.SORT_NO, 22, T.GAKKAI_NENDO, NULL)),																													
	 MAX(DECODE(T.SORT_NO, 22, T.GAKKAI_CD, NULL)),																													
	 MAX(DECODE(T.SORT_NO, 23, T.GAKKAI_NENDO, NULL)),																													
	 MAX(DECODE(T.SORT_NO, 23, T.GAKKAI_CD, NULL)),																													
	 MAX(DECODE(T.SORT_NO, 24, T.GAKKAI_NENDO, NULL)),																													
	 MAX(DECODE(T.SORT_NO, 24, T.GAKKAI_CD, NULL)),																													
	 MAX(DECODE(T.SORT_NO, 25, T.GAKKAI_NENDO, NULL)),																													
	 MAX(DECODE(T.SORT_NO, 25, T.GAKKAI_CD, NULL)),																													
	 MAX(DECODE(T.SORT_NO, 26, T.GAKKAI_NENDO, NULL)),																													
	 MAX(DECODE(T.SORT_NO, 26, T.GAKKAI_CD, NULL)),																													
	 MAX(DECODE(T.SORT_NO, 27, T.GAKKAI_NENDO, NULL)),																													
	 MAX(DECODE(T.SORT_NO, 27, T.GAKKAI_CD, NULL)),																													
	 MAX(DECODE(T.SORT_NO, 28, T.GAKKAI_NENDO, NULL)) ,																													
	 MAX(DECODE(T.SORT_NO, 28, T.GAKKAI_CD, NULL)),																													
	 MAX(DECODE(T.SORT_NO, 29, T.GAKKAI_NENDO, NULL)),																													
	 MAX(DECODE(T.SORT_NO, 29, T.GAKKAI_CD, NULL)),																													
	 MAX(DECODE(T.SORT_NO, 30, T.GAKKAI_NENDO, NULL)),																													
	 MAX(DECODE(T.SORT_NO, 30, T.GAKKAI_CD, NULL)) ,																													
	 MAX(DECODE(T.SORT_NO, 31, T.GAKKAI_NENDO, NULL)),																													
	 MAX(DECODE(T.SORT_NO, 31, T.GAKKAI_CD, NULL)) ,																													
	 MAX(DECODE(T.SORT_NO, 32, T.GAKKAI_NENDO, NULL)),																													
	 MAX(DECODE(T.SORT_NO, 32, T.GAKKAI_CD, NULL)),																													
	 MAX(DECODE(T.SORT_NO, 33, T.GAKKAI_NENDO, NULL)),																													
	 MAX(DECODE(T.SORT_NO, 33, T.GAKKAI_CD, NULL)),																													
	 MAX(DECODE(T.SORT_NO, 34, T.GAKKAI_NENDO, NULL)),																													
	 MAX(DECODE(T.SORT_NO, 34, T.GAKKAI_CD, NULL)),																													
	 MAX(DECODE(T.SORT_NO, 35, T.GAKKAI_NENDO, NULL)),																													
	 MAX(DECODE(T.SORT_NO, 35, T.GAKKAI_CD, NULL)),																													
	 MAX(DECODE(T.SORT_NO, 36, T.GAKKAI_NENDO, NULL)),																													
	 MAX(DECODE(T.SORT_NO, 36, T.GAKKAI_CD, NULL)),																													
	 MAX(DECODE(T.SORT_NO, 37, T.GAKKAI_NENDO, NULL)),																													
	 MAX(DECODE(T.SORT_NO, 37, T.GAKKAI_CD, NULL)),																													
	 MAX(DECODE(T.SORT_NO, 38, T.GAKKAI_NENDO, NULL)),																													
	 MAX(DECODE(T.SORT_NO, 38, T.GAKKAI_CD, NULL)),																													
	 MAX(DECODE(T.SORT_NO, 39, T.GAKKAI_NENDO, NULL)),																													
	 MAX(DECODE(T.SORT_NO, 39, T.GAKKAI_CD, NULL)) ,																													
	 MAX(DECODE(T.SORT_NO, 40, T.GAKKAI_NENDO, NULL)) ,																													
	 MAX(DECODE(T.SORT_NO, 40, T.GAKKAI_CD, NULL)) ,																													
	 MAX(DECODE(T.SORT_NO, 41, T.GAKKAI_NENDO, NULL)),																													
	 MAX(DECODE(T.SORT_NO, 41, T.GAKKAI_CD, NULL)),																													
	 NULL,
         iOPE_CD,
         iDATE,
         iPGM_ID,
         iOPE_CD,
         iDATE,
         iPGM_ID																												
         FROM																									
		 (SELECT      
                    KJN_CD,    
                    GAKKAI_CD,    
                    GAKKAI_NENDO,    
                    DECODE(MOD(SORT_NO, 41),0,41,MOD(SORT_NO, 41)) AS SORT_NO,    
                    TRUNC((SORT_NO-1)/41) AS GAKKAI_RENBAN    
                    FROM
                    (SELECT N.*, ROW_NUMBER() OVER (PARTITION BY KJN_CD ORDER BY
                          GAKKAI_CD,GAKKAI_NENDO DESC) AS SORT_NO  
                          FROM
                          (SELECT    
                           A.KJN_CD AS KJN_CD,  
                           B.GAKKAI_CD AS GAKKAI_CD,  
                           MAX(B.GAKKAI_NENDO) AS GAKKAI_NENDO     
                           FROM TT_TIKY_KJN A    
                           INNER JOIN TT_TIKY_KJN_GAKKAI B    
                           ON A.REC_ID = B.REC_ID  
                           AND A.KJN_CD = B.KJN_CD  
                           WHERE A.REC_ID = '01'   
                           AND A.DEL_FLG IS NULL    
                           AND B.DEL_FLG IS NULL 
                           GROUP BY 
                           A.KJN_CD,
                           B.GAKKAI_CD   ) N )) T
          GROUP BY						
          T.KJN_CD,					
	  T.GAKKAI_RENBAN	;			
          --�b��_�S��_�����w��̓o�^
          EXECUTE_SQL :=  'INSERT INTO TD_PA_GAKKAI_KT(                        '||                       
              'REC_ID,								'||																					
              'KJN_CD,								'||																					
	      'YOBI,								'||																					
	      'GAKKAI_RENBAN,							'||																						
	      'KEIZOKU_FLG,							'||																						
	      'GAKKAI_1_NENDO,							'||																						
	      'GAKKAI_1_CD,							'||																						
	      'GAKKAI_2_NENDO,							'||																						
	      'GAKKAI_2_CD,							'||																						
	      'GAKKAI_3_NENDO,							'||																						
	      'GAKKAI_3_CD,							'||																						
	      'GAKKAI_4_NENDO,							'||																						
	      'GAKKAI_4_CD,							'||																						
	      'GAKKAI_5_NENDO,							'||																						
	      'GAKKAI_5_CD,							'||																						
	      'GAKKAI_6_NENDO,							'||																						
	      'GAKKAI_6_CD,							'||																						
	      'GAKKAI_7_NENDO,							'||																						
	      'GAKKAI_7_CD,							'||																						
	      'GAKKAI_8_NENDO,							'||																						
	      'GAKKAI_8_CD,							'||																						
	      'GAKKAI_9_NENDO,							'||																						
	      'GAKKAI_9_CD,							'||																						
	      'GAKKAI_10_NENDO,							'||																						
	      'GAKKAI_10_CD,							'||																						
	      'GAKKAI_11_NENDO,							'||																						
	      'GAKKAI_11_CD,							'||																						
	      'GAKKAI_12_NENDO,							'||																						
	      'GAKKAI_12_CD,							'||																						
	      'GAKKAI_13_NENDO,							'||																						
	      'GAKKAI_13_CD,							'||																						
	      'GAKKAI_14_NENDO,							'||																						
	      'GAKKAI_14_CD,							'||																						
	      'GAKKAI_15_NENDO,							'||																						
	      'GAKKAI_15_CD,							'||																						
	      'GAKKAI_16_NENDO,							'||																						
	      'GAKKAI_16_CD,							'||																						
	      'GAKKAI_17_NENDO,							'||																						
	      'GAKKAI_17_CD,							'||																						
	      'GAKKAI_18_NENDO,							'||																						
	      'GAKKAI_18_CD,							'||																						
	      'GAKKAI_19_NENDO,							'||																						
	      'GAKKAI_19_CD,							'||																						
	      'GAKKAI_20_NENDO,							'||																						
	      'GAKKAI_20_CD,							'||																						
	      'GAKKAI_21_NENDO,							'||																						
	      'GAKKAI_21_CD,							'||																						
	      'GAKKAI_22_NENDO,							'||																						
	      'GAKKAI_22_CD,							'||																						
	      'GAKKAI_23_NENDO,							'||																						
	      'GAKKAI_23_CD,							'||																						
	      'GAKKAI_24_NENDO,							'||																						
	      'GAKKAI_24_CD,							'||																						
	      'GAKKAI_25_NENDO,							'||																						
	      'GAKKAI_25_CD,							'||																						
	      'GAKKAI_26_NENDO,							'||																						
	      'GAKKAI_26_CD,							'||																						
	      'GAKKAI_27_NENDO,							'||																						
	      'GAKKAI_27_CD,							'||																						
	      'GAKKAI_28_NENDO,							'||																						
	      'GAKKAI_28_CD,							'||																						
	      'GAKKAI_29_NENDO,							'||																						
	      'GAKKAI_29_CD,							'||																						
	      'GAKKAI_30_NENDO,							'||																						
	      'GAKKAI_30_CD,							'||																						
	      'GAKKAI_31_NENDO,							'||																						
	      'GAKKAI_31_CD,							'||																						
	      'GAKKAI_32_NENDO,							'||																						
	      'GAKKAI_32_CD,							'||																						
	      'GAKKAI_33_NENDO,							'||																						
	      'GAKKAI_33_CD,							'||																						
	      'GAKKAI_34_NENDO,							'||																						
	      'GAKKAI_34_CD,							'||																						
	      'GAKKAI_35_NENDO,							'||																						
	      'GAKKAI_35_CD,							'||																						
	      'GAKKAI_36_NENDO,							'||																						
	      'GAKKAI_36_CD,							'||																						
	      'GAKKAI_37_NENDO,							'||																						
	      'GAKKAI_37_CD,							'||																						
	      'GAKKAI_38_NENDO,							'||																						
	      'GAKKAI_38_CD,							'||																						
	      'GAKKAI_39_NENDO,							'||																						
	      'GAKKAI_39_CD,							'||																						
	      'GAKKAI_40_NENDO,							'||																						
	      'GAKKAI_40_CD,							'||																						
	      'GAKKAI_41_NENDO,							'||																						
	      'GAKKAI_41_CD,							'||																						
              'FILLER,								'||	
              'TRK_OPE_CD,'||
              'TRK_DATE,'||
              'TRK_PGM_ID,'||
              'UPD_OPE_CD,'||
              'UPD_DATE,'||
              'UPD_PGM_ID)'||
      '    SELECT                                                          '||
         '''01'''  || ','                                        ||																													
         'T.KJN_CD,	'||																												
	 'NULL,		'||																											
	 'TO_CHAR(GAKKAI_RENBAN),'||																													
	 'DECODE(GAKKAI_RENBAN, 0, ''0'', ''1''),	'||																												
	 'MAX(DECODE(T.SORT_NO, 1, T.GAKKAI_NENDO, NULL)) AS GAKKAI_1_NENDO,			'  ||																										
	 'MAX(DECODE(T.SORT_NO, 1, T.GAKKAI_CD, NULL)) AS GAKKAI_1_CD,				'  ||																									
	 'MAX(DECODE(T.SORT_NO, 2, T.GAKKAI_NENDO, NULL)) AS GAKKAI_2_NENDO,			'  ||																										
	 'MAX(DECODE(T.SORT_NO, 2, T.GAKKAI_CD, NULL)) AS GAKKAI_2_CD,				'  ||																									
	 'MAX(DECODE(T.SORT_NO, 3, T.GAKKAI_NENDO, NULL)) AS GAKKAI_3_NENDO,			'  ||																										
	 'MAX(DECODE(T.SORT_NO, 3, T.GAKKAI_CD, NULL)) AS GAKKAI_3_CD,				'  ||																									
	 'MAX(DECODE(T.SORT_NO, 4, T.GAKKAI_NENDO, NULL)) AS GAKKAI_4_NENDO,			'  ||																										
	 'MAX(DECODE(T.SORT_NO, 4, T.GAKKAI_CD, NULL)) AS GAKKAI_4_CD,				'  ||																									
	 'MAX(DECODE(T.SORT_NO, 5, T.GAKKAI_NENDO, NULL)) AS GAKKAI_5_NENDO,			'  ||																										
	 'MAX(DECODE(T.SORT_NO, 5, T.GAKKAI_CD, NULL)) AS GAKKAI_5_CD,				'  ||																									
	 'MAX(DECODE(T.SORT_NO, 6, T.GAKKAI_NENDO, NULL)) AS GAKKAI_6_NENDO,			'  ||																										
	 'MAX(DECODE(T.SORT_NO, 6, T.GAKKAI_CD, NULL)) AS GAKKAI_6_CD,				'  ||																									
	 'MAX(DECODE(T.SORT_NO, 7, T.GAKKAI_NENDO, NULL)) AS GAKKAI_7_NENDO,			'  ||																										
	 'MAX(DECODE(T.SORT_NO, 7, T.GAKKAI_CD, NULL)) AS GAKKAI_7_CD,				'  ||																									
	 'MAX(DECODE(T.SORT_NO, 8, T.GAKKAI_NENDO, NULL)) AS GAKKAI_8_NENDO,			'  ||																										
	 'MAX(DECODE(T.SORT_NO, 8, T.GAKKAI_CD, NULL)) AS GAKKAI_8_CD,				'  ||																									
	 'MAX(DECODE(T.SORT_NO, 9, T.GAKKAI_NENDO, NULL)) AS GAKKAI_9_NENDO,			'  ||																										
	 'MAX(DECODE(T.SORT_NO, 9, T.GAKKAI_CD, NULL)) AS GAKKAI_9_CD,				'  ||																									
	 'MAX(DECODE(T.SORT_NO, 10, T.GAKKAI_NENDO, NULL)) AS GAKKAI_10_NENDO,		'  ||																											
	 'MAX(DECODE(T.SORT_NO, 10, T.GAKKAI_CD, NULL)) AS GAKKAI_10_CD,			'  ||																										
	 'MAX(DECODE(T.SORT_NO, 11, T.GAKKAI_NENDO, NULL)) AS GAKKAI_11_NENDO,		'  ||																											
	 'MAX(DECODE(T.SORT_NO, 11, T.GAKKAI_CD, NULL)) AS GAKKAI_11_CD,			'  ||																										
	 'MAX(DECODE(T.SORT_NO, 12, T.GAKKAI_NENDO, NULL)) AS GAKKAI_12_NENDO,		'  ||																											
	 'MAX(DECODE(T.SORT_NO, 12, T.GAKKAI_CD, NULL)) AS GAKKAI_12_CD,			'  ||																										
	 'MAX(DECODE(T.SORT_NO, 13, T.GAKKAI_NENDO, NULL)) AS GAKKAI_13_NENDO,		'  ||																											
	 'MAX(DECODE(T.SORT_NO, 13, T.GAKKAI_CD, NULL)) AS GAKKAI_13_CD,			'  ||																										
	 'MAX(DECODE(T.SORT_NO, 14, T.GAKKAI_NENDO, NULL)) AS GAKKAI_14_NENDO,		'  ||																											
	 'MAX(DECODE(T.SORT_NO, 14, T.GAKKAI_CD, NULL)) AS GAKKAI_14_CD,			'  ||																										
	 'MAX(DECODE(T.SORT_NO, 15, T.GAKKAI_NENDO, NULL)) AS GAKKAI_15_NENDO,		'  ||																											
	 'MAX(DECODE(T.SORT_NO, 15, T.GAKKAI_CD, NULL)) AS GAKKAI_15_CD,			'  ||																										
	 'MAX(DECODE(T.SORT_NO, 16, T.GAKKAI_NENDO, NULL)) AS GAKKAI_16_NENDO,		'  ||																											
	 'MAX(DECODE(T.SORT_NO, 16, T.GAKKAI_CD, NULL)) AS GAKKAI_16_CD,			'  ||																										
	 'MAX(DECODE(T.SORT_NO, 17, T.GAKKAI_NENDO, NULL)) AS GAKKAI_17_NENDO,		'  ||																											
	 'MAX(DECODE(T.SORT_NO, 17, T.GAKKAI_CD, NULL)) AS GAKKAI_17_CD,			'  ||																										
	 'MAX(DECODE(T.SORT_NO, 18, T.GAKKAI_NENDO, NULL)) AS GAKKAI_18_NENDO,		'  ||																											
	 'MAX(DECODE(T.SORT_NO, 18, T.GAKKAI_CD, NULL)) AS GAKKAI_18_CD,			'  ||																										
	 'MAX(DECODE(T.SORT_NO, 19, T.GAKKAI_NENDO, NULL)) AS GAKKAI_19_NENDO,		'  ||																											
	 'MAX(DECODE(T.SORT_NO, 19, T.GAKKAI_CD, NULL)) AS GAKKAI_19_CD,			'  ||																										
	 'MAX(DECODE(T.SORT_NO, 20, T.GAKKAI_NENDO, NULL)) AS GAKKAI_20_NENDO,		'  ||																											
	 'MAX(DECODE(T.SORT_NO, 20, T.GAKKAI_CD, NULL)) AS GAKKAI_20_CD,			'  ||																										
	 'MAX(DECODE(T.SORT_NO, 21, T.GAKKAI_NENDO, NULL)) AS GAKKAI_21_NENDO,		'  ||																											
	 'MAX(DECODE(T.SORT_NO, 21, T.GAKKAI_CD, NULL)) AS GAKKAI_21_CD,			'  ||																										
	 'MAX(DECODE(T.SORT_NO, 22, T.GAKKAI_NENDO, NULL)) AS GAKKAI_22_NENDO,		'  ||																											
	 'MAX(DECODE(T.SORT_NO, 22, T.GAKKAI_CD, NULL)) AS GAKKAI_22_CD,			'  ||																										
	 'MAX(DECODE(T.SORT_NO, 23, T.GAKKAI_NENDO, NULL)) AS GAKKAI_23_NENDO,		'  ||																											
	 'MAX(DECODE(T.SORT_NO, 23, T.GAKKAI_CD, NULL)) AS GAKKAI_23_CD,			'  ||																										
	 'MAX(DECODE(T.SORT_NO, 24, T.GAKKAI_NENDO, NULL)) AS GAKKAI_24_NENDO,		'  ||																											
	 'MAX(DECODE(T.SORT_NO, 24, T.GAKKAI_CD, NULL)) AS GAKKAI_24_CD,			'  ||																										
	 'MAX(DECODE(T.SORT_NO, 25, T.GAKKAI_NENDO, NULL)) AS GAKKAI_25_NENDO,		'  ||																											
	 'MAX(DECODE(T.SORT_NO, 25, T.GAKKAI_CD, NULL)) AS GAKKAI_25_CD,			'  ||																										
	 'MAX(DECODE(T.SORT_NO, 26, T.GAKKAI_NENDO, NULL)) AS GAKKAI_26_NENDO,		'  ||																											
	 'MAX(DECODE(T.SORT_NO, 26, T.GAKKAI_CD, NULL)) AS GAKKAI_26_CD,			'  ||																										
	 'MAX(DECODE(T.SORT_NO, 27, T.GAKKAI_NENDO, NULL)) AS GAKKAI_27_NENDO,		'  ||																											
	 'MAX(DECODE(T.SORT_NO, 27, T.GAKKAI_CD, NULL)) AS GAKKAI_27_CD,			'  ||																										
	 'MAX(DECODE(T.SORT_NO, 28, T.GAKKAI_NENDO, NULL)) AS GAKKAI_28_NENDO,		'  ||																											
	 'MAX(DECODE(T.SORT_NO, 28, T.GAKKAI_CD, NULL)) AS GAKKAI_28_CD,			'  ||																										
	 'MAX(DECODE(T.SORT_NO, 29, T.GAKKAI_NENDO, NULL)) AS GAKKAI_29_NENDO,		'  ||																											
	 'MAX(DECODE(T.SORT_NO, 29, T.GAKKAI_CD, NULL)) AS GAKKAI_29_CD,			'  ||																										
	 'MAX(DECODE(T.SORT_NO, 30, T.GAKKAI_NENDO, NULL)) AS GAKKAI_30_NENDO,		'  ||																											
	 'MAX(DECODE(T.SORT_NO, 30, T.GAKKAI_CD, NULL)) AS GAKKAI_30_CD,			'  ||																										
	 'MAX(DECODE(T.SORT_NO, 31, T.GAKKAI_NENDO, NULL)) AS GAKKAI_31_NENDO,		'  ||																											
	 'MAX(DECODE(T.SORT_NO, 31, T.GAKKAI_CD, NULL)) AS GAKKAI_31_CD,			'  ||																										
	 'MAX(DECODE(T.SORT_NO, 32, T.GAKKAI_NENDO, NULL)) AS GAKKAI_32_NENDO,		'  ||																											
	 'MAX(DECODE(T.SORT_NO, 32, T.GAKKAI_CD, NULL)) AS GAKKAI_32_CD,			'  ||																										
	 'MAX(DECODE(T.SORT_NO, 33, T.GAKKAI_NENDO, NULL)) AS GAKKAI_33_NENDO,		'  ||																											
	 'MAX(DECODE(T.SORT_NO, 33, T.GAKKAI_CD, NULL)) AS GAKKAI_33_CD,			'  ||																										
	 'MAX(DECODE(T.SORT_NO, 34, T.GAKKAI_NENDO, NULL)) AS GAKKAI_34_NENDO,		'  ||																											
	 'MAX(DECODE(T.SORT_NO, 34, T.GAKKAI_CD, NULL)) AS GAKKAI_34_CD,			'  ||																										
	 'MAX(DECODE(T.SORT_NO, 35, T.GAKKAI_NENDO, NULL)) AS GAKKAI_35_NENDO,		'  ||																											
	 'MAX(DECODE(T.SORT_NO, 35, T.GAKKAI_CD, NULL)) AS GAKKAI_35_CD,			'  ||																										
	 'MAX(DECODE(T.SORT_NO, 36, T.GAKKAI_NENDO, NULL)) AS GAKKAI_36_NENDO,		'  ||																											
	 'MAX(DECODE(T.SORT_NO, 36, T.GAKKAI_CD, NULL)) AS GAKKAI_36_CD,			'  ||																										
	 'MAX(DECODE(T.SORT_NO, 37, T.GAKKAI_NENDO, NULL)) AS GAKKAI_37_NENDO,		'  ||																											
	 'MAX(DECODE(T.SORT_NO, 37, T.GAKKAI_CD, NULL)) AS GAKKAI_37_CD,			'  ||																										
	 'MAX(DECODE(T.SORT_NO, 38, T.GAKKAI_NENDO, NULL)) AS GAKKAI_38_NENDO,		'  ||																											
	 'MAX(DECODE(T.SORT_NO, 38, T.GAKKAI_CD, NULL)) AS GAKKAI_38_CD,			'  ||																										
	 'MAX(DECODE(T.SORT_NO, 39, T.GAKKAI_NENDO, NULL)) AS GAKKAI_39_NENDO,		'  ||																											
	 'MAX(DECODE(T.SORT_NO, 39, T.GAKKAI_CD, NULL)) AS GAKKAI_39_CD,			'  ||																										
	 'MAX(DECODE(T.SORT_NO, 40, T.GAKKAI_NENDO, NULL)) AS GAKKAI_40_NENDO,		'  ||																											
	 'MAX(DECODE(T.SORT_NO, 40, T.GAKKAI_CD, NULL)) AS GAKKAI_40_CD,			'  ||																										
	 'MAX(DECODE(T.SORT_NO, 41, T.GAKKAI_NENDO, NULL)) AS GAKKAI_41_NENDO,		'  ||																											
	 'MAX(DECODE(T.SORT_NO, 41, T.GAKKAI_CD, NULL)) AS GAKKAI_41_CD,			'  ||																														
	 'NULL,'||
         'iOPE_CD,'||
         'iDATE,'||
         'iPGM_ID,'||
         'iOPE_CD,'||
         'iDATE,'||
         'iPGM_ID'||																												
         'FROM	'||																								
		 '(SELECT      '||
                    'KJN_CD,    '||
                    'GAKKAI_CD,    '||
                    'GAKKAI_NENDO,    '||
                    'DECODE(MOD(SORT_NO, 41),0,41,MOD(SORT_NO, 41)) AS SORT_NO,    '||
                    'TRUNC((SORT_NO-1)/41) AS GAKKAI_RENBAN    '||
                    'FROM'||
                    '(SELECT N.*, ROW_NUMBER() OVER (PARTITION BY KJN_CD ORDER BY'||
                          'GAKKAI_CD,GAKKAI_NENDO DESC) AS SORT_NO  '||
                          'FROM'||
                          '(SELECT   '|| 
                          ' A.KJN_CD AS KJN_CD,  '||
                          ' B.GAKKAI_CD AS GAKKAI_CD,  '||
                          ' MAX(B.GAKKAI_NENDO) AS GAKKAI_NENDO     '||
                          ' FROM TT_TIKY_KJN A    '||
                          ' INNER JOIN TT_TIKY_KJN_GAKKAI B    '||
                          ' ON A.REC_ID = B.REC_ID  '||
                          ' AND A.KJN_CD = B.KJN_CD  '||
                          ' WHERE A.REC_ID = ''01'''||
                          ' AND A.DEL_FLG IS NULL    '||
                          ' AND B.DEL_FLG IS NULL '||
                          ' GROUP BY '||
                          ' A.KJN_CD,'||
                          ' B.GAKKAI_CD   ) N )) T'||	
          'GROUP BY'||						
          'T.KJN_CD,'||					
	  'T.GAKKAI_RENBAN	';	
	  ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

          END IF;
      
      END IF;
      
      commit;
        
      -- �I�����O�o��
      ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'PL/SQL End',PGM_ID || '�̏������I�����܂����B',iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);
      return 0;
    -- ��O����
	EXCEPTION
		-- ���̑��G���[
		WHEN OTHERS THEN
			W_ERR_INF_RCD.ERR_CD 		:= TO_CHAR(SQLCODE);
			W_ERR_INF_RCD.ERR_MSG 		:= SUBSTR(SQLERRM, 0, 500);
			W_ERR_INF_RCD.ERR_KEY_INF 	:= SUBSTR('iLayoutKind:' || iLayoutKind || ', iShimeKind:' || iShimeKind , 0,500);
			W_INDEX_N 					:= W_ERR_INF_TBL.COUNT + 1;
			W_ERR_INF_TBL.EXTEND;
			W_ERR_INF_TBL(W_INDEX_N) 	:= W_ERR_INF_RCD;

			OPEN oOUT_ERR_INF_CSR FOR
				SELECT * FROM TABLE(W_ERR_INF_TBL);
      ROLLBACK;

      --�G���[���O�̓o�^
      ULT_INSERT_LOG_TABLE('ERROR',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'ERROR_INFO',W_ERR_INF_RCD.ERR_MSG,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

      return 1;
        END;
    END;
/
/
