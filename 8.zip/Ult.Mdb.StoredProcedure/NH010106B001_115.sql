CREATE OR REPLACE PACKAGE NH010106B001_115
/* **********************************************************
 *  Copyright(c) 2011 beyond, INTEC Inc. All rights reserved.
 * **********************************************************/
AUTHID CURRENT_USER
IS
	/*** �J�[�\���^ ***************************************************************/
	-- �G���[���i�[�p�J�[�\���^
	TYPE ERR_INF_CSR		IS REF CURSOR;

  /*
  ************************************************************************
  *  �b��_�S��_�ǉ��A�C�e���R�e�[�u���̍쐬
  *  CREATE_TSUIKAITEM3
  ************************************************************************
  */
  FUNCTION CREATE_TSUIKAITEM3(
  iShimeKind  IN  INTEGER,                    -- ���ߓ��敪
  iTensoYMD	IN	VARCHAR2,                     -- �]���N����
  iOPE_CD IN Varchar2,                      -- �I�y���[�^�R�[�h
  iPGM_ID IN Varchar2,                      -- �v���O����ID
  iDATE DATE,                               -- �V�X�e������
  iIP_ADDR  IN TL_STORED_SHORI.IP%TYPE,              -- ���s�[��IP�A�h���X (FW�Őݒ�)
  iWINDOWS_LOGIN_USER  IN TL_STORED_SHORI.WINDOWS_LOGIN_USER%TYPE, -- ���s�[��OS���[�U�[ (FW�Őݒ�)
  oROW_COUNT  OUT NUMBER,         -- �o�^����
  oOUT_ERR_INF_CSR   OUT ERR_INF_CSR    -- �G���[���J�[�\��
  ) RETURN NUMBER; 

END;
/
CREATE OR REPLACE PACKAGE BODY NH010106B001_115
/* **********************************************************
 *  Copyright(c) 2011 beyond, INTEC Inc. All rights reserved.
 * **********************************************************/
IS
  /*
   ************************************************************************
   * Function ID  : CREATE_TSUIKAITEM3
   * Program Name : �b��_�S��_�ǉ��A�C�e���R�e�[�u���̍쐬
   * Parameter    :  <I> iShimeKind    �F���ߓ��敪
   *                 <I> iTensoYMD    �F�]���N����
   *                 <I> iOPE_CD    �F�I�y���[�^�R�[�h
   *                 <I> iPGM_ID    �F�v���O����ID
   *                 <I> iDATE    �F�V�X�e������ 
   *                 <I> iIP_ADDR    �F���s�[��IP�A�h���X
   *                 <I> iWINDOWS_LOGIN_USER  �F���s�[��IP�A�h���X
   *                <O> oROW_COUNT        �F�X�V����
   *                <O> oOUT_ERR_INF_CSR  �F�G���[���J�[�\��
   * Return       �F�������ʁi0:����I���A1:�ُ�I���j
   ************************************************************************
   */
  FUNCTION CREATE_TSUIKAITEM3(
  iShimeKind  IN  INTEGER,                    -- ���ߓ��敪
  iTensoYMD	IN	VARCHAR2,                     -- �]���N����
  iOPE_CD IN Varchar2,                      -- �I�y���[�^�R�[�h
  iPGM_ID IN Varchar2,                      -- �v���O����ID
  iDATE DATE,                               -- �V�X�e������  
  iIP_ADDR  IN TL_STORED_SHORI.IP%TYPE,              -- ���s�[��IP�A�h���X (FW�Őݒ�)
  iWINDOWS_LOGIN_USER  IN TL_STORED_SHORI.WINDOWS_LOGIN_USER%TYPE, -- ���s�[��OS���[�U�[ (FW�Őݒ�)
  oROW_COUNT  OUT NUMBER,         -- �o�^����
  oOUT_ERR_INF_CSR   OUT ERR_INF_CSR    -- �G���[���J�[�\��
  )RETURN NUMBER IS
PRAGMA AUTONOMOUS_TRANSACTION;
  /************************************************************************/
  /*                              �G���[����                              */
  /************************************************************************/
  W_INDEX_N           NUMBER(10) := 0;
  W_ERR_INF_TBL         TYPE_ERR_INFO_TBL := TYPE_ERR_INFO_TBL();
  W_ERR_INF_RCD         TYPE_ERR_INFO_RCD := TYPE_ERR_INFO_RCD(NULL,NULL,NULL,NULL);
  vSchemaNm           TM_JOSU.HANYO_KOMOKU%TYPE := NULL; -- �X�L�[�}����
  PGM_ID        VARCHAR2(50) := 'NH010106B001_115.CREATE_TSUIKAITEM3';
  EXECUTE_SQL   VARCHAR2(32767) := NULL;
 
  BEGIN
  
   -- �J�n���O�o��
    ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'PL/SQL Start',PGM_ID || '�̏������J�n���܂��B',iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);
         
    -- �����D���ߋ敪��"1"(������)��
    IF iShimeKind = ULT_COMMON.SHIME_SBT_CD_HISHIME THEN
    
      -- �[�i�p�X�L�[�}�̎擾���s���B
      vSchemaNm := ULT_COMMON.GET_SCHEMA_NAME(ULT_COMMON.SYS_ENV_JOSU_DAI_CD, ULT_COMMON.NOHIN_SHEMA_JOSU_SHO_CD);

      --�b��_�S��_�ǉ��A�C�e���R�e�[�u���̃f�[�^���N���A����
      EXECUTE_SQL := 'TRUNCATE TABLE ' || vSchemaNm || '.' || 'TD_PA_TSUIKAITEM3';
      EXECUTE IMMEDIATE EXECUTE_SQL;
      ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);
      
      -- �b��_�S��_�ǉ��A�C�e���R�e�[�u���ɓo�^����
      INSERT INTO TD_PA_TSUIKAITEM3(
							            SHIREC_ID                      ,
							            SHI_CD                         ,
							            SHI_CD_YOBI                    ,
							            TOKUTEIKENSHIN                 ,
							            TOKUTEISHIDO                   ,
							            DPCJUNBI_BYOIN_FLG             ,
							            DPCJUNBI_BYOIN_SHONIN_Y        ,
							            DPCJUNBI_BYOIN_CANCEL_D_Y      ,
							            DPCJUNBI_BYOIN_CANCEL_D_M      ,
							            DPCJUNBI_BYOIN_CANCEL_D_D      ,
							            CHIKENCHUKAKU_FLG              ,
							            CHIKENCHUKAKU_KBN              ,
							            CHIKENCHUKAKU_SHONIN_D_Y       ,
							            CHIKENCHUKAKU_SHONIN_D_M       ,
							            CHIKENCHUKAKU_SHONIN_D_D       ,
							            CHIKENCHUKAKU_CANCEL_D_Y       ,
							            CHIKENCHUKAKU_CANCEL_D_M       ,
							            CHIKENCHUKAKU_CANCEL_D_D       ,
							            NINCHISHOIRY_FLG               ,
							            NINCHISHOIRY_SHONIN_D_Y        ,
							            NINCHISHOIRY_SHONIN_D_M        ,
							            NINCHISHOIRY_SHONIN_D_D        ,
							            NINCHISHOIRY_CANCEL_D_Y        ,
							            NINCHISHOIRY_CANCEL_D_M        ,
							            NINCHISHOIRY_CANCEL_D_D        ,
							            SOGONYUIN_FLG                  ,
							            SOGONYUIN_SHONIN_D_Y           ,
							            SOGONYUIN_SHONIN_D_M           ,
							            SOGONYUIN_SHONIN_D_D           ,
							            SOGONYUIN_CANCEL_D_Y           ,
							            SOGONYUIN_CANCEL_D_M           ,
							            SOGONYUIN_CANCEL_D_D           ,
							            CHOKYUNOSOCCHU_FLG             ,
							            CHOKYUNOSOCCHU_SHONIN_D_Y      ,
							            CHOKYUNOSOCCHU_SHONIN_D_M      ,
							            CHOKYUNOSOCCHU_SHONIN_D_D      ,
							            CHOKYUNOSOCCHU_CANCEL_D_Y      ,
							            CHOKYUNOSOCCHU_CANCEL_D_M      ,
							            CHOKYUNOSOCCHU_CANCEL_D_D      ,
							            ISHIHOJO_FLG                   ,
							            ISHIHOJO_SHONIN_D_Y            ,
							            ISHIHOJO_SHONIN_D_M            ,
							            ISHIHOJO_SHONIN_D_D            ,
							            ISHIHOJO_CANCEL_D_Y            ,
							            ISHIHOJO_CANCEL_D_M            ,
							            ISHIHOJO_CANCEL_D_D            ,
							            ZAITAKUMAKKI_FLG               ,
							            ZAITAKUMAKKI_SHONIN_D_Y        ,
							            ZAITAKUMAKKI_SHONIN_D_M        ,
							            ZAITAKUMAKKI_SHONIN_D_D        ,
							            ZAITAKUMAKKI_CANCEL_D_Y        ,
							            ZAITAKUMAKKI_CANCEL_D_M        ,
							            ZAITAKUMAKKI_CANCEL_D_D        ,
							            SENSHIN_FLG                    ,
							            SENSHIN_21_CD                  ,
							            SENSHIN_22_CD                  ,
							            SENSHIN_23_CD                  ,
							            SENSHIN_24_CD                  ,
							            SENSHIN_25_CD                  ,
							            SENSHIN_26_CD                  ,
							            SENSHIN_27_CD                  ,
							            SENSHIN_28_CD                  ,
							            SENSHIN_29_CD                  ,
							            SENSHIN_30_CD                  ,
							            SENSHIN_31_CD                  ,
							            SENSHIN_32_CD                  ,
							            SENSHIN_33_CD                  ,
							            SENSHIN_34_CD                  ,
							            SENSHIN_35_CD                  ,
							            SENSHIN_36_CD                  ,
							            SENSHIN_37_CD                  ,
							            SENSHIN_38_CD                  ,
							            SENSHIN_39_CD                  ,
							            SENSHIN_40_CD                  ,
							            TENSO_Y                        ,
							            TENSO_M                        ,
							            TENSO_D                        ,
							            MENTE_Y                        ,
							            MENTE_M                        ,
							            MENTE_D                        ,
							            MOD_KBN                        ,
							            TRK_OPE_CD                     ,
							            TRK_DATE                       ,
							            TRK_PGM_ID                     ,
							            UPD_OPE_CD                     ,
							            UPD_DATE                       ,                     
							            UPD_PGM_ID
							         )  
			        SELECT
			            TS.REC_ID,        
			            TS.SHI_CD, 
			            NULL,
			            TS.TOKUTEIKENSHIN_FLG,
			            TS.TOKUTEISHIDO_FLG,           
			            TS.DPCJUNBI_FLG,                   
			            TS.DPCJUNBI_SHONIN_Y,              
			            SUBSTR(TS.DPCJUNBI_CANCEL_YMD,1,4),
			            SUBSTR(TS.DPCJUNBI_CANCEL_YMD,5,2),
			            SUBSTR(TS.DPCJUNBI_CANCEL_YMD,7,2),
			            TS.CHIKENCHUKAKU_FLG,   
			            TS.CHIKENCHUKAKU_KBN,           
			            SUBSTR(TS.CHIKENCHUKAKU_SHONIN_YMD,1,4),
			            SUBSTR(TS.CHIKENCHUKAKU_SHONIN_YMD,5,2),
			            SUBSTR(TS.CHIKENCHUKAKU_SHONIN_YMD,7,2),
			            SUBSTR(TS.CHIKENCHUKAKU_CANCEL_YMD,1,4),
			            SUBSTR(TS.CHIKENCHUKAKU_CANCEL_YMD,5,2),
			            SUBSTR(TS.CHIKENCHUKAKU_CANCEL_YMD,7,2),            
			            TS.NINCHISHOIRY_FLG,               
			            SUBSTR(TS.NINCHISHOIRY_SHONIN_YMD,1,4),
			            SUBSTR(TS.NINCHISHOIRY_SHONIN_YMD,5,2),
			            SUBSTR(TS.NINCHISHOIRY_SHONIN_YMD,7,2),
			            SUBSTR(TS.NINCHISHOIRY_CANCEL_YMD,1,4),
			            SUBSTR(TS.NINCHISHOIRY_CANCEL_YMD,5,2),
			            SUBSTR(TS.NINCHISHOIRY_CANCEL_YMD,7,2),                        
			            TS.SOGONYUIN_FLG,                  
			            SUBSTR(TS.SOGONYUIN_SHONIN_YMD,1,4),
			            SUBSTR(TS.SOGONYUIN_SHONIN_YMD,5,2),
			            SUBSTR(TS.SOGONYUIN_SHONIN_YMD,7,2),
			            SUBSTR(TS.SOGONYUIN_CANCEL_YMD,1,4),
			            SUBSTR(TS.SOGONYUIN_CANCEL_YMD,5,2),
			            SUBSTR(TS.SOGONYUIN_CANCEL_YMD,7,2),                                         
			            TS.CHOKYUNOSOCCHU_FLG,               
			            SUBSTR(TS.CHOKYUNOSOCCHU_SHONIN_YMD,1,4),
			            SUBSTR(TS.CHOKYUNOSOCCHU_SHONIN_YMD,5,2),
			            SUBSTR(TS.CHOKYUNOSOCCHU_SHONIN_YMD,7,2),
			            SUBSTR(TS.CHOKYUNOSOCCHU_CANCEL_YMD,1,4),
			            SUBSTR(TS.CHOKYUNOSOCCHU_CANCEL_YMD,5,2),
			            SUBSTR(TS.CHOKYUNOSOCCHU_CANCEL_YMD,7,2),                       
			            TS.ISHIHOJO_FLG,                     
			            SUBSTR(TS.ISHIHOJO_SHONIN_YMD,1,4),
			            SUBSTR(TS.ISHIHOJO_SHONIN_YMD,5,2),
			            SUBSTR(TS.ISHIHOJO_SHONIN_YMD,7,2),
			            SUBSTR(TS.ISHIHOJO_CANCEL_YMD,1,4),
			            SUBSTR(TS.ISHIHOJO_CANCEL_YMD,5,2),
			            SUBSTR(TS.ISHIHOJO_CANCEL_YMD,7,2),                            
			            TS.ZAITAKUMAKKI_FLG,                     
			            SUBSTR(TS.ZAITAKUMAKKI_SHONIN_YMD,1,4),
			            SUBSTR(TS.ZAITAKUMAKKI_SHONIN_YMD,5,2),
			            SUBSTR(TS.ZAITAKUMAKKI_SHONIN_YMD,7,2),
			            SUBSTR(TS.ZAITAKUMAKKI_CANCEL_YMD,1,4),
			            SUBSTR(TS.ZAITAKUMAKKI_CANCEL_YMD,5,2),
			            SUBSTR(TS.ZAITAKUMAKKI_CANCEL_YMD,7,2),       
			            TS.SENSHIN_21_40_FLG,              
			            TS.SENSHIN_CD_21,                  
			            TS.SENSHIN_CD_22,                  
			            TS.SENSHIN_CD_23,                  
			            TS.SENSHIN_CD_24,                  
			            TS.SENSHIN_CD_25,                  
			            TS.SENSHIN_CD_26,                  
			            TS.SENSHIN_CD_27,                  
			            TS.SENSHIN_CD_28,                  
			            TS.SENSHIN_CD_29,                  
			            TS.SENSHIN_CD_30,                  
			            TS.SENSHIN_CD_31,                  
			            TS.SENSHIN_CD_32,                  
			            TS.SENSHIN_CD_33,                  
			            TS.SENSHIN_CD_34,                  
			            TS.SENSHIN_CD_35,                  
			            TS.SENSHIN_CD_36,                  
			            TS.SENSHIN_CD_37,                  
			            TS.SENSHIN_CD_38,                  
			            TS.SENSHIN_CD_39,                  
			            TS.SENSHIN_CD_40,     
			            SUBSTR(iTensoYMD,1,4),
			            SUBSTR(iTensoYMD,5,2),
			            SUBSTR(iTensoYMD,7,2),
			            SUBSTR(TS.UPD_EIGY_YMD,1,4),
			            SUBSTR(TS.UPD_EIGY_YMD,5,2),
			            SUBSTR(TS.UPD_EIGY_YMD,7,2),                                             
			            NULL,                                                       
			            iOPE_CD,
			            iDATE,
			            iPGM_ID,
			            iOPE_CD,
			            iDATE,
			            iPGM_ID
			       FROM (
			       			SELECT															
					        TTT.REC_ID,														
					        TTT.SHI_CD,														
					        TTT.DPCJUNBI_FLG,														
					        TTT.DPCJUNBI_SHONIN_Y,														
					        TTT.DPCJUNBI_CANCEL_YMD,														
					        TTT.CHOKYUNOSOCCHU_FLG,														
					        TTT.CHOKYUNOSOCCHU_SHONIN_YMD,														
					        TTT.CHOKYUNOSOCCHU_CANCEL_YMD,														
					        TTT.SOGONYUIN_FLG,														
					        TTT.SOGONYUIN_SHONIN_YMD,														
					        TTT.SOGONYUIN_CANCEL_YMD,														
					        TTT.ISHIHOJO_FLG,														
					        TTT.ISHIHOJO_SHONIN_YMD,														
					        TTT.ISHIHOJO_CANCEL_YMD,														
					        TTT.ZAITAKUMAKKI_FLG,														
					        TTT.ZAITAKUMAKKI_SHONIN_YMD,														
					        TTT.ZAITAKUMAKKI_CANCEL_YMD,														
					        TTT.CHIKENCHUKAKU_FLG,														
					        TTT.CHIKENCHUKAKU_SHONIN_YMD,														
					        TTT.CHIKENCHUKAKU_CANCEL_YMD,														
					        TTT.CHIKENCHUKAKU_KBN,														
					        TTT.NINCHISHOIRY_FLG,														
					        TTT.NINCHISHOIRY_SHONIN_YMD,														
					        TTT.NINCHISHOIRY_CANCEL_YMD,														
					        TTT.TOKUTEIKENSHIN_FLG,														
					        TTT.TOKUTEISHIDO_FLG,														
					        TTT.SENSHIN_21_40_FLG,														
					        TTT.SENSHIN_CD_21,														
					        TTT.SENSHIN_CD_22,														
					        TTT.SENSHIN_CD_23,														
					        TTT.SENSHIN_CD_24,														
					        TTT.SENSHIN_CD_25,														
					        TTT.SENSHIN_CD_26,														
					        TTT.SENSHIN_CD_27,														
					        TTT.SENSHIN_CD_28,														
					        TTT.SENSHIN_CD_29,														
					        TTT.SENSHIN_CD_30,														
					        TTT.SENSHIN_CD_31,														
					        TTT.SENSHIN_CD_32,														
					        TTT.SENSHIN_CD_33,														
					        TTT.SENSHIN_CD_34,														
					        TTT.SENSHIN_CD_35,														
					        TTT.SENSHIN_CD_36,														
					        TTT.SENSHIN_CD_37,														
					        TTT.SENSHIN_CD_38,														
					        TTT.SENSHIN_CD_39,														
					        TTT.SENSHIN_CD_40,														
					        TTT.UPD_EIGY_YMD														
						   FROM TT_TIKY_SHI�@TTS												
					     INNER JOIN TT_TIKY_TSUIKAITEM�@TTT ON TTS�DREC_ID = TTT�DREC_ID	AND  TTS�DSHI_CD = TTT�DSHI_CD														
						   WHERE�@TTS.REC_ID�@= '00'															
						         AND�@TTS.DEL_FLG IS NULL															
						         AND�@TTT�DITEM_3_MOD_EIGY_YMD IS NOT NULL															
						         AND�@TTT.DEL_FLG IS NULL															
					    UNION
						  SELECT																	
					        TTT.REC_ID,															
					        TTT.SHI_CD,															
					        NULL AS DPCJUNBI_FLG,															
					        NULL AS DPCJUNBI_SHONIN_Y,															
					        NULL AS DPCJUNBI_CANCEL_YMD,															
					        NULL AS CHOKYUNOSOCCHU_FLG,															
					        NULL AS CHOKYUNOSOCCHU_SHONIN_YMD,															
					        NULL AS CHOKYUNOSOCCHU_CANCEL_YMD,															
					        NULL AS SOGONYUIN_FLG,															
					        NULL AS SOGONYUIN_SHONIN_YMD,															
					        NULL AS SOGONYUIN_CANCEL_YMD,															
					        NULL AS ISHIHOJO_FLG,															
					        NULL AS ISHIHOJO_SHONIN_YMD,															
					        NULL AS ISHIHOJO_CANCEL_YMD,															
					        NULL AS ZAITAKUMAKKI_FLG,															
					        NULL AS ZAITAKUMAKKI_SHONIN_YMD,															
					        NULL AS ZAITAKUMAKKI_CANCEL_YMD,															
					        NULL AS CHIKENCHUKAKU_FLG,															
					        NULL AS CHIKENCHUKAKU_SHONIN_YMD,															
					        NULL AS CHIKENCHUKAKU_CANCEL_YMD,															
					        NULL AS CHIKENCHUKAKU_KBN,															
					        NULL AS NINCHISHOIRY_FLG,															
					        NULL AS NINCHISHOIRY_SHONIN_YMD,															
					        NULL AS NINCHISHOIRY_CANCEL_YMD,															
					        NULL AS TOKUTEIKENSHIN_FLG,															
					        NULL AS TOKUTEISHIDO_FLG,															
					        NULL AS SENSHIN_21_40_FLG,															
					        NULL AS SENSHIN_CD_21,															
					        NULL AS SENSHIN_CD_22,															
					        NULL AS SENSHIN_CD_23,															
					        NULL AS SENSHIN_CD_24,															
					        NULL AS SENSHIN_CD_25,															
					        NULL AS SENSHIN_CD_26,															
					        NULL AS SENSHIN_CD_27,															
					        NULL AS SENSHIN_CD_28,															
					        NULL AS SENSHIN_CD_29,															
					        NULL AS SENSHIN_CD_30,															
					        NULL AS SENSHIN_CD_31,															
					        NULL AS SENSHIN_CD_32,															
					        NULL AS SENSHIN_CD_33,															
					        NULL AS SENSHIN_CD_34,															
					        NULL AS SENSHIN_CD_35,															
					        NULL AS SENSHIN_CD_36,															
					        NULL AS SENSHIN_CD_37,															
					        NULL AS SENSHIN_CD_38,															
					        NULL AS SENSHIN_CD_39,															
					        NULL AS SENSHIN_CD_40,															
					        TTT.UPD_EIGY_YMD															
						   FROM TT_TIKY_SHI�@TTS													
					     INNER JOIN TT_TIKY_TSUIKAITEM�@TTT ON TTS�DREC_ID = TTT�DREC_ID	AND  TTS�DSHI_CD = TTT�DSHI_CD															
						   WHERE�@TTS.REC_ID�@= '00'																
						          AND�@TTS.DEL_FLG IS NULL																
						          AND�@TTT�DITEM_3_MOD_EIGY_YMD IS NOT NULL																
						          AND�@TTT.DEL_FLG = '1'
			       		) TS; 
	-- �b��_�S��_�ǉ��A�C�e���R�e�[�u���̃��O��o�^����		
	EXECUTE_SQL:='  INSERT INTO TD_PA_TSUIKAITEM3(                                               ' ||  
					'  							            SHIREC_ID                      ,        ' ||
					'  							            SHI_CD                         ,        ' ||
					'  							            SHI_CD_YOBI                    ,        ' ||
					'  							            TOKUTEIKENSHIN                 ,        ' ||
					'  							            TOKUTEISHIDO                   ,        ' ||
					'  							            DPCJUNBI_BYOIN_FLG             ,        ' ||
					'  							            DPCJUNBI_BYOIN_SHONIN_Y        ,        ' ||
					'  							            DPCJUNBI_BYOIN_CANCEL_D_Y      ,        ' ||
					'  							            DPCJUNBI_BYOIN_CANCEL_D_M      ,        ' ||
					'  							            DPCJUNBI_BYOIN_CANCEL_D_D      ,        ' ||
					'  							            CHIKENCHUKAKU_FLG              ,        ' ||
					'  							            CHIKENCHUKAKU_KBN              ,        ' ||
					'  							            CHIKENCHUKAKU_SHONIN_D_Y       ,        ' ||
					'  							            CHIKENCHUKAKU_SHONIN_D_M       ,        ' ||
					'  							            CHIKENCHUKAKU_SHONIN_D_D       ,        ' ||
					'  							            CHIKENCHUKAKU_CANCEL_D_Y       ,        ' ||
					'  							            CHIKENCHUKAKU_CANCEL_D_M       ,        ' ||
					'  							            CHIKENCHUKAKU_CANCEL_D_D       ,        ' ||
					'  							            NINCHISHOIRY_FLG               ,        ' ||
					'  							            NINCHISHOIRY_SHONIN_D_Y        ,        ' ||
					'  							            NINCHISHOIRY_SHONIN_D_M        ,        ' ||
					'  							            NINCHISHOIRY_SHONIN_D_D        ,        ' ||
					'  							            NINCHISHOIRY_CANCEL_D_Y        ,        ' ||
					'  							            NINCHISHOIRY_CANCEL_D_M        ,        ' ||
					'  							            NINCHISHOIRY_CANCEL_D_D        ,        ' ||
					'  							            SOGONYUIN_FLG                  ,        ' ||
					'  							            SOGONYUIN_SHONIN_D_Y           ,        ' ||
					'  							            SOGONYUIN_SHONIN_D_M           ,        ' ||
					'  							            SOGONYUIN_SHONIN_D_D           ,        ' ||
					'  							            SOGONYUIN_CANCEL_D_Y           ,        ' ||
					'  							            SOGONYUIN_CANCEL_D_M           ,        ' ||
					'  							            SOGONYUIN_CANCEL_D_D           ,        ' ||
					'  							            CHOKYUNOSOCCHU_FLG             ,        ' ||
					'  							            CHOKYUNOSOCCHU_SHONIN_D_Y      ,        ' ||
					'  							            CHOKYUNOSOCCHU_SHONIN_D_M      ,        ' ||
					'  							            CHOKYUNOSOCCHU_SHONIN_D_D      ,        ' ||
					'  							            CHOKYUNOSOCCHU_CANCEL_D_Y      ,        ' ||
					'  							            CHOKYUNOSOCCHU_CANCEL_D_M      ,        ' ||
					'  							            CHOKYUNOSOCCHU_CANCEL_D_D      ,        ' ||
					'  							            ISHIHOJO_FLG                   ,        ' ||
					'  							            ISHIHOJO_SHONIN_D_Y            ,        ' ||
					'  							            ISHIHOJO_SHONIN_D_M            ,        ' ||
					'  							            ISHIHOJO_SHONIN_D_D            ,        ' ||
					'  							            ISHIHOJO_CANCEL_D_Y            ,        ' ||
					'  							            ISHIHOJO_CANCEL_D_M            ,        ' ||
					'  							            ISHIHOJO_CANCEL_D_D            ,        ' ||
					'  							            ZAITAKUMAKKI_FLG               ,        ' ||
					'  							            ZAITAKUMAKKI_SHONIN_D_Y        ,        ' ||
					'  							            ZAITAKUMAKKI_SHONIN_D_M        ,        ' ||
					'  							            ZAITAKUMAKKI_SHONIN_D_D        ,        ' ||
					'  							            ZAITAKUMAKKI_CANCEL_D_Y        ,        ' ||
					'  							            ZAITAKUMAKKI_CANCEL_D_M        ,        ' ||
					'  							            ZAITAKUMAKKI_CANCEL_D_D        ,        ' ||
					'  							            SENSHIN_FLG                    ,        ' ||
					'  							            SENSHIN_21_CD                  ,        ' ||
					'  							            SENSHIN_22_CD                  ,        ' ||
					'  							            SENSHIN_23_CD                  ,        ' ||
					'  							            SENSHIN_24_CD                  ,        ' ||
					'  							            SENSHIN_25_CD                  ,        ' ||
					'  							            SENSHIN_26_CD                  ,        ' ||
					'  							            SENSHIN_27_CD                  ,        ' ||
					'  							            SENSHIN_28_CD                  ,        ' ||
					'  							            SENSHIN_29_CD                  ,        ' ||
					'  							            SENSHIN_30_CD                  ,        ' ||
					'  							            SENSHIN_31_CD                  ,        ' ||
					'  							            SENSHIN_32_CD                  ,        ' ||
					'  							            SENSHIN_33_CD                  ,        ' ||
					'  							            SENSHIN_34_CD                  ,        ' ||
					'  							            SENSHIN_35_CD                  ,        ' ||
					'  							            SENSHIN_36_CD                  ,        ' ||
					'  							            SENSHIN_37_CD                  ,        ' ||
					'  							            SENSHIN_38_CD                  ,        ' ||
					'  							            SENSHIN_39_CD                  ,        ' ||
					'  							            SENSHIN_40_CD                  ,        ' ||
					'  							            TENSO_Y                        ,        ' ||
					'  							            TENSO_M                        ,        ' ||
					'  							            TENSO_D                        ,        ' ||
					'  							            MENTE_Y                        ,        ' ||
					'  							            MENTE_M                        ,        ' ||
					'  							            MENTE_D                        ,        ' ||
					'  							            MOD_KBN                        ,        ' ||
					'  							            TRK_OPE_CD                     ,        ' ||
					'  							            TRK_DATE                       ,        ' ||
					'  							            TRK_PGM_ID                     ,        ' ||
					'  							            UPD_OPE_CD                     ,        ' ||
					'  							            UPD_DATE                       ,        ' ||
					'  							            UPD_PGM_ID                              ' ||
					'  							         )                                          ' ||
					'  			        SELECT                                                      ' ||
					'  			            TS.REC_ID,                                              ' ||
					'  			            TS.SHI_CD,                                              ' ||
					'  			            NULL,                                                   ' ||
					'  			            TS.TOKUTEIKENSHIN_FLG,                                  ' ||
					'  			            TS.TOKUTEISHIDO_FLG,                                    ' ||
					'  			            TS.DPCJUNBI_FLG,                                        ' ||
					'  			            TS.DPCJUNBI_SHONIN_Y,                                   ' ||
					'  			            SUBSTR(TS.DPCJUNBI_CANCEL_YMD,1,4),                     ' ||
					'  			            SUBSTR(TS.DPCJUNBI_CANCEL_YMD,5,2),                     ' ||
					'  			            SUBSTR(TS.DPCJUNBI_CANCEL_YMD,7,2),                     ' ||
					'  			            TS.CHIKENCHUKAKU_FLG,                                   ' ||
					'  			            TS.CHIKENCHUKAKU_KBN,                                   ' ||
					'  			            SUBSTR(TS.CHIKENCHUKAKU_SHONIN_YMD,1,4),                ' ||
					'  			            SUBSTR(TS.CHIKENCHUKAKU_SHONIN_YMD,5,2),                ' ||
					'  			            SUBSTR(TS.CHIKENCHUKAKU_SHONIN_YMD,7,2),                ' ||
					'  			            SUBSTR(TS.CHIKENCHUKAKU_CANCEL_YMD,1,4),                ' ||
					'  			            SUBSTR(TS.CHIKENCHUKAKU_CANCEL_YMD,5,2),                ' ||
					'  			            SUBSTR(TS.CHIKENCHUKAKU_CANCEL_YMD,7,2),                ' ||
					'  			            TS.NINCHISHOIRY_FLG,                                    ' ||
					'  			            SUBSTR(TS.NINCHISHOIRY_SHONIN_YMD,1,4),                 ' ||
					'  			            SUBSTR(TS.NINCHISHOIRY_SHONIN_YMD,5,2),                 ' ||
					'  			            SUBSTR(TS.NINCHISHOIRY_SHONIN_YMD,7,2),                 ' ||
					'  			            SUBSTR(TS.NINCHISHOIRY_CANCEL_YMD,1,4),                 ' ||
					'  			            SUBSTR(TS.NINCHISHOIRY_CANCEL_YMD,5,2),                 ' ||
					'  			            SUBSTR(TS.NINCHISHOIRY_CANCEL_YMD,7,2),                 ' ||
					'  			            TS.SOGONYUIN_FLG,                                       ' ||
					'  			            SUBSTR(TS.SOGONYUIN_SHONIN_YMD,1,4),                    ' ||
					'  			            SUBSTR(TS.SOGONYUIN_SHONIN_YMD,5,2),                    ' ||
					'  			            SUBSTR(TS.SOGONYUIN_SHONIN_YMD,7,2),                    ' ||
					'  			            SUBSTR(TS.SOGONYUIN_CANCEL_YMD,1,4),                    ' ||
					'  			            SUBSTR(TS.SOGONYUIN_CANCEL_YMD,5,2),                    ' ||
					'  			            SUBSTR(TS.SOGONYUIN_CANCEL_YMD,7,2),                    ' ||
					'  			            TS.CHOKYUNOSOCCHU_FLG,                                  ' ||
					'  			            SUBSTR(TS.CHOKYUNOSOCCHU_SHONIN_YMD,1,4),               ' ||
					'  			            SUBSTR(TS.CHOKYUNOSOCCHU_SHONIN_YMD,5,2),               ' ||
					'  			            SUBSTR(TS.CHOKYUNOSOCCHU_SHONIN_YMD,7,2),               ' ||
					'  			            SUBSTR(TS.CHOKYUNOSOCCHU_CANCEL_YMD,1,4),               ' ||
					'  			            SUBSTR(TS.CHOKYUNOSOCCHU_CANCEL_YMD,5,2),               ' ||
					'  			            SUBSTR(TS.CHOKYUNOSOCCHU_CANCEL_YMD,7,2),               ' ||
					'  			            TS.ISHIHOJO_FLG,                                        ' ||
					'  			            SUBSTR(TS.ISHIHOJO_SHONIN_YMD,1,4),                     ' ||
					'  			            SUBSTR(TS.ISHIHOJO_SHONIN_YMD,5,2),                     ' ||
					'  			            SUBSTR(TS.ISHIHOJO_SHONIN_YMD,7,2),                     ' ||
					'  			            SUBSTR(TS.ISHIHOJO_CANCEL_YMD,1,4),                     ' ||
					'  			            SUBSTR(TS.ISHIHOJO_CANCEL_YMD,5,2),                     ' ||
					'  			            SUBSTR(TS.ISHIHOJO_CANCEL_YMD,7,2),                     ' ||
					'  			            TS.ZAITAKUMAKKI_FLG,                                    ' ||
					'  			            SUBSTR(TS.ZAITAKUMAKKI_SHONIN_YMD,1,4),                 ' ||
					'  			            SUBSTR(TS.ZAITAKUMAKKI_SHONIN_YMD,5,2),                 ' ||
					'  			            SUBSTR(TS.ZAITAKUMAKKI_SHONIN_YMD,7,2),                 ' ||
					'  			            SUBSTR(TS.ZAITAKUMAKKI_CANCEL_YMD,1,4),                 ' ||
					'  			            SUBSTR(TS.ZAITAKUMAKKI_CANCEL_YMD,5,2),                 ' ||
					'  			            SUBSTR(TS.ZAITAKUMAKKI_CANCEL_YMD,7,2),                 ' ||
					'  			            TS.SENSHIN_21_40_FLG,                                   ' ||
					'  			            TS.SENSHIN_CD_21,                                       ' ||
					'  			            TS.SENSHIN_CD_22,                                       ' ||
					'  			            TS.SENSHIN_CD_23,                                       ' ||
					'  			            TS.SENSHIN_CD_24,                                       ' ||
					'  			            TS.SENSHIN_CD_25,                                       ' ||
					'  			            TS.SENSHIN_CD_26,                                       ' ||
					'  			            TS.SENSHIN_CD_27,                                       ' ||
					'  			            TS.SENSHIN_CD_28,                                       ' ||
					'  			            TS.SENSHIN_CD_29,                                       ' ||
					'  			            TS.SENSHIN_CD_30,                                       ' ||
					'  			            TS.SENSHIN_CD_31,                                       ' ||
					'  			            TS.SENSHIN_CD_32,                                       ' ||
					'  			            TS.SENSHIN_CD_33,                                       ' ||
					'  			            TS.SENSHIN_CD_34,                                       ' ||
					'  			            TS.SENSHIN_CD_35,                                       ' ||
					'  			            TS.SENSHIN_CD_36,                                       ' ||
					'  			            TS.SENSHIN_CD_37,                                       ' ||
					'  			            TS.SENSHIN_CD_38,                                       ' ||
					'  			            TS.SENSHIN_CD_39,                                       ' ||
					'  			            TS.SENSHIN_CD_40,                                       ' ||
					'  			            SUBSTR(iTensoYMD,1,4),                                  ' ||
					'  			            SUBSTR(iTensoYMD,5,2),                                  ' ||
					'  			            SUBSTR(iTensoYMD,7,2),                                  ' ||
					'  			            SUBSTR(TS.UPD_EIGY_YMD,1,4),                            ' ||
					'  			            SUBSTR(TS.UPD_EIGY_YMD,5,2),                            ' ||
					'  			            SUBSTR(TS.UPD_EIGY_YMD,7,2),                            ' ||
					'  			            NULL,                                                   ' ||
											iOPE_CD   || ','           ||
								            iDATE     || ','           ||
								            iPGM_ID   || ','           ||
								            iOPE_CD   || ','           ||
								            iDATE     || ','           ||
								            iPGM_ID                    ||
					'  			       FROM (                                                       ' ||
					'  			       			SELECT                                              ' ||
					'  					        TTT.REC_ID,                                         ' ||
					'  					        TTT.SHI_CD,                                         ' ||
					'  					        TTT.DPCJUNBI_FLG,                                   ' ||
					'  					        TTT.DPCJUNBI_SHONIN_Y,                              ' ||
					'  					        TTT.DPCJUNBI_CANCEL_YMD,                            ' ||
					'  					        TTT.CHOKYUNOSOCCHU_FLG,                             ' ||
					'  					        TTT.CHOKYUNOSOCCHU_SHONIN_YMD,                      ' ||
					'  					        TTT.CHOKYUNOSOCCHU_CANCEL_YMD,                      ' ||
					'  					        TTT.SOGONYUIN_FLG,                                  ' ||
					'  					        TTT.SOGONYUIN_SHONIN_YMD,                           ' ||
					'  					        TTT.SOGONYUIN_CANCEL_YMD,                           ' ||
					'  					        TTT.ISHIHOJO_FLG,                                   ' ||
					'  					        TTT.ISHIHOJO_SHONIN_YMD,                            ' ||
					'  					        TTT.ISHIHOJO_CANCEL_YMD,                            ' ||
					'  					        TTT.ZAITAKUMAKKI_FLG,                               ' ||
					'  					        TTT.ZAITAKUMAKKI_SHONIN_YMD,                        ' ||
					'  					        TTT.ZAITAKUMAKKI_CANCEL_YMD,                        ' ||
					'  					        TTT.CHIKENCHUKAKU_FLG,                              ' ||
					'  					        TTT.CHIKENCHUKAKU_SHONIN_YMD,                       ' ||
					'  					        TTT.CHIKENCHUKAKU_CANCEL_YMD,                       ' ||
					'  					        TTT.CHIKENCHUKAKU_KBN,                              ' ||
					'  					        TTT.NINCHISHOIRY_FLG,                               ' ||
					'  					        TTT.NINCHISHOIRY_SHONIN_YMD,                        ' ||
					'  					        TTT.NINCHISHOIRY_CANCEL_YMD,                        ' ||
					'  					        TTT.TOKUTEIKENSHIN_FLG,                             ' ||
					'  					        TTT.TOKUTEISHIDO_FLG,                               ' ||
					'  					        TTT.SENSHIN_21_40_FLG,                              ' ||
					'  					        TTT.SENSHIN_CD_21,                                  ' ||
					'  					        TTT.SENSHIN_CD_22,                                  ' ||
					'  					        TTT.SENSHIN_CD_23,                                  ' ||
					'  					        TTT.SENSHIN_CD_24,                                  ' ||
					'  					        TTT.SENSHIN_CD_25,                                  ' ||
					'  					        TTT.SENSHIN_CD_26,                                  ' ||
					'  					        TTT.SENSHIN_CD_27,                                  ' ||
					'  					        TTT.SENSHIN_CD_28,                                  ' ||
					'  					        TTT.SENSHIN_CD_29,                                  ' ||
					'  					        TTT.SENSHIN_CD_30,                                  ' ||
					'  					        TTT.SENSHIN_CD_31,                                  ' ||
					'  					        TTT.SENSHIN_CD_32,                                  ' ||
					'  					        TTT.SENSHIN_CD_33,                                  ' ||
					'  					        TTT.SENSHIN_CD_34,                                  ' ||
					'  					        TTT.SENSHIN_CD_35,                                  ' ||
					'  					        TTT.SENSHIN_CD_36,                                  ' ||
					'  					        TTT.SENSHIN_CD_37,                                  ' ||
					'  					        TTT.SENSHIN_CD_38,                                  ' ||
					'  					        TTT.SENSHIN_CD_39,                                  ' ||
					'  					        TTT.SENSHIN_CD_40,                                  ' ||
					'  					        TTT.UPD_EIGY_YMD                                    ' ||
					'  						   FROM TT_TIKY_SHI�@TTS                                ' ||
					'  					     INNER JOIN TT_TIKY_TSUIKAITEM�@TTT                     ' ||
					'						 ON TTS�DREC_ID = TTT�DREC_ID	                        ' ||
					' 						 AND  TTS�DSHI_CD = TTT�DSHI_CD                         ' ||
					'  						   WHERE�@TTS.REC_ID�@= ''00''                            ' ||
					'  						         AND�@TTS.DEL_FLG IS NULL                       ' ||
					'  						         AND�@TTT�DITEM_3_MOD_EIGY_YMD IS NOT NULL      ' ||
					'  						         AND�@TTT.DEL_FLG IS NULL                       ' ||
					'  					    UNION                                                   ' ||
					'  						  SELECT                                                ' ||
					'  					        TTT.REC_ID,                                         ' ||
					'  					        TTT.SHI_CD,                                         ' ||
					'  					        NULL AS DPCJUNBI_FLG,                               ' ||
					'  					        NULL AS DPCJUNBI_SHONIN_Y,                          ' ||
					'  					        NULL AS DPCJUNBI_CANCEL_YMD,                        ' ||
					'  					        NULL AS CHOKYUNOSOCCHU_FLG,                         ' ||
					'  					        NULL AS CHOKYUNOSOCCHU_SHONIN_YMD,                  ' ||
					'  					        NULL AS CHOKYUNOSOCCHU_CANCEL_YMD,                  ' ||
					'  					        NULL AS SOGONYUIN_FLG,                              ' ||
					'  					        NULL AS SOGONYUIN_SHONIN_YMD,                       ' ||
					'  					        NULL AS SOGONYUIN_CANCEL_YMD,                       ' ||
					'  					        NULL AS ISHIHOJO_FLG,                               ' ||
					'  					        NULL AS ISHIHOJO_SHONIN_YMD,                        ' ||
					'  					        NULL AS ISHIHOJO_CANCEL_YMD,                        ' ||
					'  					        NULL AS ZAITAKUMAKKI_FLG,                           ' ||
					'  					        NULL AS ZAITAKUMAKKI_SHONIN_YMD,                    ' ||
					'  					        NULL AS ZAITAKUMAKKI_CANCEL_YMD,                    ' ||
					'  					        NULL AS CHIKENCHUKAKU_FLG,                          ' ||
					'  					        NULL AS CHIKENCHUKAKU_SHONIN_YMD,                   ' ||
					'  					        NULL AS CHIKENCHUKAKU_CANCEL_YMD,                   ' ||
					'  					        NULL AS CHIKENCHUKAKU_KBN,                          ' ||
					'  					        NULL AS NINCHISHOIRY_FLG,                           ' ||
					'  					        NULL AS NINCHISHOIRY_SHONIN_YMD,                    ' ||
					'  					        NULL AS NINCHISHOIRY_CANCEL_YMD,                    ' ||
					'  					        NULL AS TOKUTEIKENSHIN_FLG,                         ' ||
					'  					        NULL AS TOKUTEISHIDO_FLG,                           ' ||
					'  					        NULL AS SENSHIN_21_40_FLG,                          ' ||
					'  					        NULL AS SENSHIN_CD_21,                              ' ||
					'  					        NULL AS SENSHIN_CD_22,                              ' ||
					'  					        NULL AS SENSHIN_CD_23,                              ' ||
					'  					        NULL AS SENSHIN_CD_24,                              ' ||
					'  					        NULL AS SENSHIN_CD_25,                              ' ||
					'  					        NULL AS SENSHIN_CD_26,                              ' ||
					'  					        NULL AS SENSHIN_CD_27,                              ' ||
					'  					        NULL AS SENSHIN_CD_28,                              ' ||
					'  					        NULL AS SENSHIN_CD_29,                              ' ||
					'  					        NULL AS SENSHIN_CD_30,                              ' ||
					'  					        NULL AS SENSHIN_CD_31,                              ' ||
					'  					        NULL AS SENSHIN_CD_32,                              ' ||
					'  					        NULL AS SENSHIN_CD_33,                              ' ||
					'  					        NULL AS SENSHIN_CD_34,                              ' ||
					'  					        NULL AS SENSHIN_CD_35,                              ' ||
					'  					        NULL AS SENSHIN_CD_36,                              ' ||
					'  					        NULL AS SENSHIN_CD_37,                              ' ||
					'  					        NULL AS SENSHIN_CD_38,                              ' ||
					'  					        NULL AS SENSHIN_CD_39,                              ' ||
					'  					        NULL AS SENSHIN_CD_40,                              ' ||
					'  					        TTT.UPD_EIGY_YMD                                    ' ||
					'  						   FROM TT_TIKY_SHI�@TTS                                ' ||
					'  					     INNER JOIN TT_TIKY_TSUIKAITEM�@TTT                     ' ||
					'   					 ON TTS�DREC_ID = TTT�DREC_ID	                        ' ||
					' 						 AND  TTS�DSHI_CD = TTT�DSHI_CD                         ' ||
					'  						   WHERE�@TTS.REC_ID�@= ''00''                            ' ||
					'  						          AND�@TTS.DEL_FLG IS NULL                      ' ||
					'  						          AND�@TTT�DITEM_3_MOD_EIGY_YMD IS NOT NULL     ' ||
					'  						          AND�@TTT.DEL_FLG = ''1''                        ' ||
					'  			       		) TS                                                    ' ;
	ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',EXECUTE_SQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);
	
    END IF;
    COMMIT;
    
   -- �I�����O�o��
   ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'PL/SQL End',PGM_ID || '�̏������I�����܂����B',iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

  oROW_COUNT := -1;
  return 0;
  -- ��O����
  EXCEPTION
    -- ���̑��G���[
    WHEN OTHERS THEN
      W_ERR_INF_RCD.ERR_CD     := TO_CHAR(SQLCODE);
      W_ERR_INF_RCD.ERR_MSG     := SUBSTR(SQLERRM, 0, 500);
      W_ERR_INF_RCD.ERR_KEY_INF   := SUBSTR('iShimeKind:' || iShimeKind , 0,500);
      W_INDEX_N           := W_ERR_INF_TBL.COUNT + 1;
      W_ERR_INF_TBL.EXTEND;
      W_ERR_INF_TBL(W_INDEX_N)   := W_ERR_INF_RCD;

      OPEN oOUT_ERR_INF_CSR FOR
        SELECT * FROM TABLE(W_ERR_INF_TBL);

       ROLLBACK;
       
      --�G���[���O�̓o�^
      ULT_INSERT_LOG_TABLE('ERROR',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'ERROR_INFO',W_ERR_INF_RCD.ERR_MSG,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID); 

  return 1;
END;

END;
/
