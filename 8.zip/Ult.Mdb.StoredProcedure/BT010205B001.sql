CREATE OR REPLACE PACKAGE BT010205B001
/* **********************************************************
 *  Copyright(c) 2011 beyond, INTEC Inc.BT010205B001 All rights reserved.
 * **********************************************************/
IS
	/*** �J�[�\���^ ***************************************************************/
	-- �G���[���i�[�p�J�[�\���^
	TYPE ERR_INF_CSR		IS REF CURSOR;

	/*
	************************************************************************
	*  �[�i�p�Տ����C�a�@�f�[�^���[�h 
	*  CREATE_TT_RRK_TR
	************************************************************************
	*/
	FUNCTION CREATE_TT_RRK_TR(
--        iSeq	IN	NUMBER,			
        iRrkRenban  IN	NUMBER,					
        iRecId	 IN	CHAR,				
        iShiCd	 IN	CHAR,				
--        iKyrykRecId    IN	CHAR,					
--        iKyrykShiCd    IN	CHAR,					
        iSNendo    IN	CHAR,
        iShoriEigybi    IN	CHAR,
        iIP_ADDR	IN TL_STORED_SHORI.IP%TYPE,	                 -- ���s�[��IP�A�h���X
		iWINDOWS_LOGIN_USER	IN TL_STORED_SHORI.WINDOWS_LOGIN_USER%TYPE, -- ���s�[��OS���[�U�[
		oROW_COUNT	        OUT NUMBER,              -- �X�V����
		oOUT_ERR_INF_CSR 	OUT ERR_INF_CSR,          -- �G���[���J�[�\��
		iOPE_CD		IN TT_SISN_KJN.UPD_OPE_CD%TYPE,             -- �I�y���[�^�R�[�h
		iPGM_ID		IN TT_SISN_KJN.UPD_PGM_ID%TYPE,             -- �@�\ID
		iDATE		IN TT_SISN_KJN.UPD_DATE%TYPE                -- ��������

	) RETURN NUMBER;
   
END;
/


CREATE OR REPLACE PACKAGE BODY BT010205B001
/* **********************************************************
 *  Copyright(c) 2011 beyond, INTEC Inc. All rights reserved.
 * **********************************************************/
IS
	/*
	 ************************************************************************
	 * Function ID  : CREATE_TT_RRK_TR
	 * Program Name : �[�i�p�Տ����C�a�@�f�[�^���[�h
	 * Parameter    :	<I> iLayoutKind	    	�F���C�A�E�g�敪
	 *			<I> iShimeKind	    	�F���ߓ��敪
	 *			<I> iTensoYMD	    	�F�]���N����
	 *			<I> iOPE_CD		�F�I�y���[�^�R�[�h
	 *			<I> iPGM_ID		�F�v���O����ID
	 *			<I> iDATE		�F�V�X�e������ 
	 *			<I> iWINDOWS_LOGIN_USER �F���s�[��IP�A�h���X
	 *			<O> oROW_COUNT		�F�X�V����
	 *			<O> oOUT_ERR_INF_CSR	�F�G���[���J�[�\��
	 * Return       �F�������ʁi0:����I���A1:�ُ�I���j
	 ************************************************************************
	 */
	FUNCTION CREATE_TT_RRK_TR(
--        iSeq	IN	NUMBER,			
        iRrkRenban  IN	NUMBER,					
        iRecId	 IN	CHAR,				
        iShiCd	 IN	CHAR,				
--        iKyrykRecId    IN	CHAR,					
--        iKyrykShiCd    IN	CHAR,					
        iSNendo    IN	CHAR,
        iShoriEigybi    IN	CHAR,
        iIP_ADDR	IN TL_STORED_SHORI.IP%TYPE,	                 -- ���s�[��IP�A�h���X
		iWINDOWS_LOGIN_USER	IN TL_STORED_SHORI.WINDOWS_LOGIN_USER%TYPE, -- ���s�[��OS���[�U�[
		oROW_COUNT	        OUT NUMBER,              -- �X�V����
		oOUT_ERR_INF_CSR 	OUT ERR_INF_CSR,          -- �G���[���J�[�\��
		iOPE_CD		IN TT_SISN_KJN.UPD_OPE_CD%TYPE,             -- �I�y���[�^�R�[�h
		iPGM_ID		IN TT_SISN_KJN.UPD_PGM_ID%TYPE,             -- �@�\ID
		iDATE		IN TT_SISN_KJN.UPD_DATE%TYPE                -- ��������

	)RETURN NUMBER IS

	/************************************************************************/
	/*                              �G���[����                                */
	/************************************************************************/
	W_INDEX_N 				NUMBER(10) := 0;
	W_ERR_INF_TBL 				TYPE_ERR_INFO_TBL := TYPE_ERR_INFO_TBL();
	W_ERR_INF_RCD 				TYPE_ERR_INFO_RCD := TYPE_ERR_INFO_RCD(NULL,NULL,NULL,NULL);
	vSQL VARCHAR2(32767) := NULL;  
	PGM_ID        VARCHAR2(50) := 'BT010205B001.CREATE_TT_RRK_TR';

	BEGIN
	-- �J�n���O�o��
        ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'PL/SQL Start',PGM_ID || '�̏������J�n���܂��B',iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);
		oROW_COUNT:= -1;

		       vSQL := 	'INSERT INTO TT_RRK_TSUIKAITEM_RNSKNS('||
					'SEQ,'||
	                                'RRK_RENBAN,'||
	                                'REC_ID,'||
	                                'SHI_CD,'||
	                                'KYRYK_REC_ID,'||
	                                'KYRYK_SHI_CD,'||
	                                'S_NENDO,'||
	                                'SORTKEY,'||
	                                'SORTKEY_NOHIN,'||
	                                'TRK_EIGY_YMD,'||
	                                'UPD_EIGY_YMD,'||
	                                'TRK_OPE_CD,'||
	                                'TRK_DATE,'||
	                                'TRK_PGM_ID,'||
	                                'UPD_OPE_CD,'||
	                                'UPD_DATE,'||
	                                'UPD_PGM_ID)'||
                       'SELECT '||
	                                'SEQ_RIREKI_PK.NEXTVAL, ' ||
	                                ':iRrkRenban, ' ||
	                                'REC_ID, ' ||
	                                'SHI_CD, ' ||
	                                'KYRYK_REC_ID, ' ||
	                                'KYRYK_SHI_CD, ' ||
	                                'S_NENDO, ' ||
	                                'SORTKEY, ' ||
	                                'SORTKEY_NOHIN, ' ||
	                                'TRK_EIGY_YMD, ' ||
	                                ':iShoriEigybi, ' ||
	                                'TRK_OPE_CD, ' ||
	                                'TRK_DATE, ' ||
	                                'TRK_PGM_ID, ' ||
	                                ':iOPE_CD, ' ||
	                                ':iDATE, ' ||
                                    ':iPGM_ID ' ||
                       'FROM 			'||									
	               'TT_SISN_TSUIKAITEM_RNSKNS ' ||
                       'WHERE REC_ID = :iRecId '||									
	               'AND SHI_CD = :iShiCd '||									
--	               'AND KYRYK_REC_ID = :iKyrykRecId		'||								
--	               'AND KYRYK_SHI_CD = :iKyrykShiCd		'||								
	               'AND S_NENDO IN (:iSNendo1, :iSNendo2, :iSnendo3)';	
	               
		--EXECUTE IMMEDIATE vSQL USING in iSeq, iRrkRenban, iShoriEigybi, iOPE_CD, iDATE, iPGM_ID, iRecId, iShiCd, iKyrykRecId, iKyrykShiCd, iSNendo;
		EXECUTE IMMEDIATE vSQL USING in iRrkRenban, iShoriEigybi, iOPE_CD, iDATE, iPGM_ID, iRecId, iShiCd, TO_NUMBER(iSNendo) - 1, iSNendo, TO_NUMBER(iSNendo) + 1;
		oROW_COUNT := SQL%ROWCOUNT;

		ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'Execute Sql',vSQL,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);
	-- �I�����O�o��
        ULT_INSERT_LOG_TABLE('INFO',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'PL/SQL End',PGM_ID || '�̏������I�����܂����B',iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);
        return 0;
	-- ��O����
	EXCEPTION
		-- ���̑��G���[
		WHEN OTHERS THEN
			W_ERR_INF_RCD.ERR_CD 		:= TO_CHAR(SQLCODE);
			W_ERR_INF_RCD.ERR_MSG 		:= SUBSTR(SQLERRM, 0, 500);
			W_INDEX_N 			:= W_ERR_INF_TBL.COUNT + 1;
			W_ERR_INF_TBL.EXTEND;
			W_ERR_INF_TBL(W_INDEX_N) 	:= W_ERR_INF_RCD;

			OPEN oOUT_ERR_INF_CSR FOR
				SELECT * FROM TABLE(W_ERR_INF_TBL);

		--�G���[���O�̓o�^
        ULT_INSERT_LOG_TABLE('ERROR',iIP_ADDR,iWINDOWS_LOGIN_USER,iOPE_CD,'ERROR_INFO',W_ERR_INF_RCD.ERR_MSG,iOPE_CD,iDATE,iPGM_ID,iOPE_CD,iDATE,iPGM_ID);

		RAISE;
        END;
	END;
/
