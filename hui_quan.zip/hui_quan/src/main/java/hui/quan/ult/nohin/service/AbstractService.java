/*
 * @(#)AbstractService.java
 *
 * Copyright (C) 2019, Japan Housing Finance Agency.
 */
package hui.quan.ult.nohin.service;

import java.util.ArrayList;
import java.util.List;

import hui.quan.ult.nohin.common.core.service.Service;
import hui.quan.ult.nohin.vo.ErrorVO;



/**
 * 全サービスの抽象クラス
 * 
 * @param <I> 入力情報。
 * @param <O> 出力情報。
 * 
 * @author HS
 *
 */
public abstract class AbstractService<I, O> implements Service<I, O> {

  /** エラーVO初期化 */
  private List<ErrorVO> errorList = new ArrayList<ErrorVO>();

  /**
   * 実行処理
   * 
   * @param input 基本情報VO
   * @return 基本情報VO
   */
  public O execute(I input) {
    // 前処理
    doPre(input);
    // メイン処理
    doExecute(input);
    // 後処理
    return doPost(input);
  }

  /**
   * 前処理
   * 
   * @param input 基本情報VO
   */
  protected abstract void doPre(I input);

  /**
   * メイン処理
   * 
   * @param input 基本情報VO
   */
  protected abstract void doExecute(I input);

  /**
   * 後処理
   * 
   * @param input 基本情報VO
   * @return 基本情報VO
   */
  protected abstract O doPost(I input);

  /**
   * エラーリスト追加
   * 
   * @param errorVO エラーVO
   */
  protected void addErrorList(ErrorVO errorVO) {
    errorList.add(errorVO);
  }

  /**
   * エラーリスト追加
   * 
   * @param errorVOLst エラーVOList
   */
  protected void addErrorList(List<ErrorVO> errorVOLst) {
    for (ErrorVO errorVO : errorVOLst) {
      errorList.add(errorVO);
    }
  }
}
