/*
 * @(#)ConcurrencyControlException.java
 *
 * Copyright (C) 2019, Japan Housing Finance Agency.
 */
package hui.quan.ult.nohin.common.core.exception;

/**
 * 排他制御例外
 *
 * <p>楽観排他制御および悲観排他制御で異常が発生した場合に発生する例外。</p>
 *
 * @author HS
 */
public class ConcurrencyControlException extends RuntimeException {

  /** シリアルバージョンUID */
  private static final long serialVersionUID = 1L;

  /**
   * コンストラクタ
   */
  public ConcurrencyControlException() {
  }

  /**
   * コンストラクタ
   *
   * @param message 詳細メッセージ
   */
  public ConcurrencyControlException(String message) {
    super(message);
  }

  /**
   * コンストラクタ
   *
   * @param cause 原因
   */
  public ConcurrencyControlException(Throwable cause) {
    super(cause);
  }

  /**
   * コンストラクタ
   *
   * @param message 詳細メッセージ
   * @param cause 原因
   */
  public ConcurrencyControlException(String message, Throwable cause) {
    super(message, cause);
  }

  /**
   * コンストラクタ
   *
   * @param message 詳細メッセージ
   * @param cause 原因
   * @param enableSuppression 抑制の有無
   * @param writableStackTrace スタックトレースの書き込み可・不可
   */
  public ConcurrencyControlException(String message, Throwable cause,
      boolean enableSuppression, boolean writableStackTrace) {
    super(message, cause, enableSuppression, writableStackTrace);
  }
}
