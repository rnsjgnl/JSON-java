/*
 * @(#)YHOJB_D_K04SB010_31.java
 *
 * Copyright (C) 2019, Japan Housing Finance Agency.
 */
package hui.quan.ult.nohin.tasklet;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import lombok.Setter;

import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Component;

import hui.quan.ult.nohin.common.core.service.Service;
import hui.quan.ult.nohin.vo.BatchInputVO;
import hui.quan.ult.nohin.vo.BatchOutputVO;


/**
 * 変更通知書原票タスクレット
 *
 * @author HS
 */
@Component
public class YHOJB_D_K04SB010_01 extends BaseTasklet implements ApplicationContextAware {
  /** サービス名 */
  @Setter
  private String serviceName;

  /** アプリケーションコンテキスト */
  @Setter
  private ApplicationContext applicationContext;

  /**
   * タスクレット実行
   *
   * @return 処理完了
   * @throws Exception 何らかの例外
   */
  @Override
  public RepeatStatus execute() throws Exception {

    DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyyMMdd");
/*
    ReportInputVO inVO = new ReportInputVO();

    // ジョブパラメータからジョブ名を取得及び設定
    inVO.setJobName(this.chunkContext.getStepContext().getJobName());
    // 処理日設定
    if (null != this.chunkContext.getStepContext().getJobParameters().get("shoriYmd")) {
      // ジョブパラメータから処理年月日を取得
      String shoriYmd = this.chunkContext.getStepContext().getJobParameters()
          .get("shoriYmd").toString();
      // 処理日設定
      inVO.setSyoriYmd(LocalDate.parse(shoriYmd, dtf));

    } else {
      // 運用日付マスタから取得した日付を設定
      inVO.setSyoriYmd(HizukeHensyu.getSyoriYmd());
    }

    // コピー先パス設定
    if (null != this.chunkContext.getStepContext().getJobParameters().get("copyToPath")) {
      // ジョブパラメータからコピー先パスを取得
      String copyToPath = this.chunkContext.getStepContext().getJobParameters()
          .get("copyToPath").toString();
      // コピー先パスを格納する。
      inVO.setCopyToPath(copyToPath);
    } else {
      // 例外をスロー
      throw new ApplicationException();
    }

    // Serviceクラスを呼び出す
    BatchOutputVO outVO = createService().execute(inVO);

    // エラー判定
    if (outVO.getSyoriKekkaEnum() == SyoriKekkaEnum.ABNORMAL) {
      // 例外をスロー
      throw new ApplicationException();
    }
*/
    BatchInputVO inVO=new BatchInputVO();
    // Serviceクラスを呼び出す
    BatchOutputVO outVO = createService().execute(inVO);
    
    return RepeatStatus.FINISHED;

  }

  /**
   * サービスオブジェクト生成。
   *
   * @return Serviceオブジェクト
   */
  @SuppressWarnings("unchecked")
  private Service<BatchInputVO, BatchOutputVO> createService() {
    return (Service<BatchInputVO, BatchOutputVO>) applicationContext.getBean(serviceName);
  }


}

