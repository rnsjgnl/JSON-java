/*
 * @(#)ApplicationException.java
 *
 * Copyright (C) 2019, Japan Housing Finance Agency.
 */
package hui.quan.ult.nohin.common.core.exception;

/**
 * アプリケーション例外クラス。
 *
 * <p>予期しないチェック例外が発生した場合にこの例外クラスのオブジェクトをスローする。</p>
 *
 * @author HS
 */
public class ApplicationException extends RuntimeException {

  /** シリアルバージョンUID。 */
  private static final long serialVersionUID = 1L;

  /**
   * コンストラクタ。
   */
  public ApplicationException() {
    super();
  }

  /**
   * コンストラクタ。
   *
   * @param message 詳細メッセージ。
   */
  public ApplicationException(String message) {
    super(message);
  }

  /**
   * コンストラクタ。
   *
   * @param cause 原因。
   */
  public ApplicationException(Throwable cause) {
    super(cause);
  }

  /**
   * コンストラクタ。
   *
   * @param message 詳細メッセージ。
   * @param cause 原因。
   */
  public ApplicationException(String message, Throwable cause) {
    super(message, cause);
  }
}
