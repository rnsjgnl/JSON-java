/*
 * @(#)EntityManager.java
 *
 * Copyright (C) 2019, Japan Housing Finance Agency.
 */
package hui.quan.ult.nohin.manager;

/**
 * Entity Managerインタフェース。
 *
 * @author HS
 *
 * @param <E> エンティティ。
 * @param <P> パラメータ。
 */
public interface EntityManager<E, P> {

  /**
   * 生成。
   *
   * @param parameter パラメータ。
   * @return エンティティ。
   */
  E create(P parameter);

  /**
   * 保存。
   *
   * @param entity エンティティ。
   * @return 処理結果。
   */
  boolean store(E entity);
}
