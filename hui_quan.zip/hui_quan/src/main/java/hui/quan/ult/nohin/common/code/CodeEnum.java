/*
 * @(#)CodeConst.java
 *
 * Copyright (C) 2019, Japan Housing Finance Agency.
 */
package hui.quan.ult.nohin.common.code;

import java.util.Arrays;

import hui.quan.ult.nohin.common.core.exception.BadStateException;



/**
 * コードenumインタフェース
 *
 * @param <E> enum型
 *
 * @author HS
 */
public interface CodeEnum<E extends Enum<E>> {

  /**
   * コード値取得
   *
   * @return コード値
   */
  String getCode();

  /**
   * コード値比較
   *
   * @param code コード
   * @return コードが等しい場合{@code true}を異なる場合{@code false}を返却する。
   */
  default boolean equals(String code) {
    return getCode().equals(code);
  }

  /**
   * コード値包有
   *
   * @param <E> enum型
   * @param clazz コードenumクラス
   * @param code コード値
   * @return コードenumにコード値が等しい定義が含まれる場合{@code true}を含まれない場合{@code false}を返却する。
   */
  static <E extends Enum<E>> boolean contais(Class<? extends CodeEnum<E>> clazz, String code) {
    return Arrays.stream(clazz.getEnumConstants()).anyMatch(e -> e.equals(code));
  }

  /**
   * 列挙型変換
   *
   * @param <E> enum型
   * @param clazz コードenumクラス
   * @param code コード値
   * @return 引数のコード値と一致する列挙型を返却する。
   */
  @SuppressWarnings("unchecked")
  static <E extends Enum<E>> E toEnum(Class<? extends CodeEnum<E>> clazz, String code) {
    return (E) Arrays.stream(clazz.getEnumConstants())
      .filter(e -> e.equals(code))
      .findFirst()
      .orElseThrow(() -> new BadStateException());
  }
}
