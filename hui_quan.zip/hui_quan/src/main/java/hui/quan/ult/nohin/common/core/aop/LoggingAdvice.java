/*
 * @(#)LoggingAdvice.java
 *
 * Copyright (C) 2019, Japan Housing Finance Agency.
 */
package hui.quan.ult.nohin.common.core.aop;

import java.lang.reflect.Method;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.aop.AfterReturningAdvice;
import org.springframework.aop.MethodBeforeAdvice;

/**
 * メソッド開始終了ロギングアドバイス
 *
 * <p>メソッドの実行時に開始ログ、終了ログを出力する。</p>
 *
 * @author HS
 */
public class LoggingAdvice implements MethodBeforeAdvice, AfterReturningAdvice {

  /**
   * メソッド開始ロギング。
   *
   * @param method 対象メソッド
   * @param args 対象メソッドの引数
   * @param target 実行対象オブジェクト
   * @throws Throwable 何らかの例外
   */
  @Override
  public void before(Method method, Object[] args, Object target) throws Throwable {
    Logger logger = LoggerFactory.getLogger(target.getClass());
    if (logger.isInfoEnabled()) {
      logger.info(method.getName() + "() start.");
    }
  }

  /**
   * メソッド終了ロギング。
   *
   * @param returnValue 対象メソッドの戻り値
   * @param method 対象メソッド
   * @param args 対象メソッドの引数
   * @param target 実行対象オブジェクト
   * @throws Throwable 何らかの例外
   */
  @Override
  public void afterReturning(Object returnValue, Method method, Object[] args, Object target)
      throws Throwable {
    Logger logger = LoggerFactory.getLogger(target.getClass());
    if (logger.isInfoEnabled()) {
      logger.info(method.getName() + "() end.");
    }
  }
}
