/*
 * @(#)BaseTasklet.java
 *
 * Copyright (C) 2019, Japan Housing Finance Agency.
 */
package hui.quan.ult.nohin.tasklet;

import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;

/**
 * 概要を記載
 *
 * <p>必要に応じて詳細を記載。不要の場合削除。</p>
 *
 * @author HS
 */
public class BaseTasklet implements Tasklet {

  protected StepContribution stepContribution;
  
  protected ChunkContext chunkContext;
  
  /**
   * 概要を記載
   *
   * <p>必要に応じて詳細を記載。不要の場合削除。</p>
   *
   * @param arg0
   * @param arg1
   * @return
   * @throws Exception
   * @see org.springframework.batch.core.step.tasklet.Tasklet#execute(org.springframework.batch.core.StepContribution, org.springframework.batch.core.scope.context.ChunkContext)
   */
  @Override
  public RepeatStatus execute(StepContribution stepContribution, ChunkContext chunkContext) throws Exception {
    // TODO 自動生成されたメソッド・スタブ
    
    this.stepContribution = stepContribution;
    
    this.chunkContext = chunkContext;
    
    return execute();
  }

  protected RepeatStatus execute() throws Exception {
    
    return RepeatStatus.FINISHED;
  }
}
