/*
 * @(#)Profile.java
 *
 * Copyright (C) 2019, Japan Housing Finance Agency.
 */
package hui.quan.ult.nohin.common.core.context;

import java.time.LocalDate;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;



/**
 * プロファイルクラス
 *
 * <p>処理実行時に使用されるスレッド固有の情報を管理するクラス。</p>
 *
 * @author HS
 */
public final class Profile {

  /** スレットローカル変数 */
  private static ThreadLocal<Context> context = new ThreadLocal<Context>() {

    /**
     * スレットローカル変数の初期値取得
     *
     * @return スレットローカル変数の初期値
     */
    @Override
    protected Context initialValue() {
      return new Context();
    }
  };

  /**
   * インスタンス化抑止コンストラクタ
   */
  private Profile() {
  }

  /**
   * 初期化処理
   *
   * <p>スレットローカル変数の初期化を行う。</p>
   *
   * @param id ID
   * @param user ユーザ情報
   * @param operaitonDate 運用日付
   * @param tradeId 取引ID
   */
  public static void initialize(String id, LocalDate operaitonDate, String tradeId) {
    context.get().setId(id);
    context.get().setOperaitonDate(operaitonDate);
    context.get().setTradeId(tradeId);
  }

  /**
   * 終了処理
   *
   * <p>スレットローカル変数の終了処理を行う。</p>
   *
   */
  public static void clear() {
    context.remove();
  }

  /**
   * ID取得
   *
   * @return ID
   */
  public static String id() {
    return context.get().getId();
  }

  /**
   * 運用日付取得
   *
   * @return operaitonDate 運用日付
   */
  public static LocalDate getOperaitonDate() {
    return context.get().getOperaitonDate();
  }

  /**
   * 取引ID取得
   *
   * @return 取引ID
   */
  public static String getTradeId() {
    return context.get().getTradeId();
  }

  /**
   * コンテキストクラス
   *
   * <p>スレットローカル変数が保持するデータを管理するクラス。</p>
   *
   * @author HS
   */
  @Setter(value = AccessLevel.PRIVATE)
  @Getter
  private static class Context {
    /** ID */
    private String id;
    /** 運用日付 */
    private LocalDate operaitonDate;
    /** 取引ID */
    private String tradeId;
  }
}
