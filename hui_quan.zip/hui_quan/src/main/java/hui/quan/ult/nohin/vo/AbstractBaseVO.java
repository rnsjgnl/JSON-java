/*
 * @(#)AbstractBaseVO.java
 *
 * Copyright (C) 2019, Japan Housing Finance Agency.
 */
package hui.quan.ult.nohin.vo;

import java.io.Serializable;
import java.time.LocalDate;

import hui.quan.ult.nohin.common.core.context.Profile;


/**
 * BaseVOクラス
 *
 * @author HS
 */
public abstract class AbstractBaseVO  implements Serializable{

  /** シリアルバージョンUID */
  private static final long serialVersionUID = 1L;

  /**
   * 処理日取得
   *
   * @return 処理年月日
   */
  public LocalDate getSyoriYmd() {
    return Profile.getOperaitonDate();
  }
}
