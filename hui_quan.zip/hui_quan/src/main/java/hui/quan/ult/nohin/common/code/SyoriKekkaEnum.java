/*
 * @(#)SyoriKekkaEnum.java
 *
 * Copyright (C) 2019, Japan Housing Finance Agency.
 */
package hui.quan.ult.nohin.common.code;
/**
 * 処理結果列挙型
 *
 * @author HS
 */
public enum SyoriKekkaEnum implements CodeEnum<SyoriKekkaEnum> {

  /** 正常終了 */
  NORMAL("1"),

  /** 異常終了 */
  ABNORMAL("2"),
  ;

  /** コード */
  private final String code;

  /**
   * コンストラクタ
   *
   * @param code コード
   */
  SyoriKekkaEnum(String code) {
    this.code = code;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public String getCode() {
    return code;
  }
}
