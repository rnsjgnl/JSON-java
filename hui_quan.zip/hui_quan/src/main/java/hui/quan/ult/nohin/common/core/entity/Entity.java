/*
 * @(#)Entity.java
 *
 * Copyright (C) 2019, Japan Housing Finance Agency.
 */
package hui.quan.ult.nohin.common.core.entity;

import java.io.Serializable;
import java.time.LocalDate;

import hui.quan.ult.nohin.common.core.context.Profile;
import lombok.Getter;
import lombok.Setter;


/**
 * ベースEntity
 *
 * @author HS
 */
@Getter
@Setter
public class Entity implements Serializable {

  /** シリアルバージョンUID */
  private static final long serialVersionUID = 1L;

  /** 実施SQL区分 */
  private String jishiSqlKbn;

  
  /**
   * 処理日取得
   *
   * @return 処理年月日
   */
  public LocalDate getSyoriYmd() {
    return Profile.getOperaitonDate();
  }
}
