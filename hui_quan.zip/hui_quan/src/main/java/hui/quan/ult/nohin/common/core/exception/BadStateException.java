/*
 * @(#)BadStateException.java
 *
 * Copyright (C) 2019, Japan Housing Finance Agency.
 */
package hui.quan.ult.nohin.common.core.exception;

/**
 * 状態不正例外クラス。
 *
 * <p>分岐処理などで想定外の状態が発生した場合にこの例外クラスのオブジェクトをスローする。</p>
 *
 * @author HS
 */
public final class BadStateException extends RuntimeException {

  /** シリアルバージョンUID。 */
  private static final long serialVersionUID = 1L;

  /**
   * コンストラクタ。
   */
  public BadStateException() {
    super();
  }

  /**
   * コンストラクタ。
   *
   * @param message 詳細メッセージ。
   */
  public BadStateException(String message) {
    super(message);
  }

  /**
   * コンストラクタ。
   *
   * @param cause 原因。
   */
  public BadStateException(Throwable cause) {
    super(cause);
  }

  /**
   * コンストラクタ。
   *
   * @param message 詳細メッセージ。
   * @param cause 原因。
   */
  public BadStateException(String message, Throwable cause) {
    super(message, cause);
  }
}
