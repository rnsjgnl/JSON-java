/*
 * @(#)AuthenticatedException.java
 *
 * Copyright (C) 2019, Japan Housing Finance Agency.
 */
package hui.quan.ult.nohin.common.core.exception;

import javax.security.sasl.AuthenticationException;

import lombok.Getter;
import lombok.Setter;

/**
 * 認証済例外
 *
 * @author HS
 *
 */
@Setter
@Getter
public class AuthenticatedException extends AuthenticationException implements AutoCloseable {

  /** シリアルバージョンUID。 */
  private static final long serialVersionUID = 1L;

  /**
   * コンストラクタ。
   */
  public AuthenticatedException() {
    super();
  }

  /**
   * コンストラクタ。
   *
   * @param message 詳細メッセージ。
   */
  public AuthenticatedException(String message) {
    super(message);
  }

  /**
   * コンストラクタ。
   *
   * @param message 詳細メッセージ。
   * @param cause 原因。
   */
  public AuthenticatedException(String message, Throwable cause) {
    super(message, cause);
  }

  /**
   * 概要を記載
   *
   * <p>必要に応じて詳細を記載。不要の場合削除。</p>
   *
   * @throws Exception 例外
   * @see java.lang.AutoCloseable#close()
   */
  @Override
  public void close() throws Exception {
    // TODO 自動生成されたメソッド・スタブ

  }

}
