/*
 * @(#)NysListEntity.java
 *
 * Copyright (C) 2019, Japan Housing Finance Agency.
 */

package hui.quan.ult.nohin.entity;

import java.time.LocalDate;

import hui.quan.ult.nohin.common.core.entity.Entity;
import lombok.Getter;
import lombok.Setter;

/**
 * 名寄せリストワークEntity
 *
 * @author HS
 */
@Getter
@Setter
public class NysListEntity extends Entity {

  /** シリアルバージョンUID */
  private static final long serialVersionUID = 1L;

  /** 金融機関コード */
  private String id;

  /** 漁協コード */
  private String name;

  /** 金融機関名 */
  private String age;

  /** 種別コード */
  private String address;

}

