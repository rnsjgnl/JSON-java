/*
 * @(#)VarcharArrayTypeHandler.java
 *
 * Copyright (C) 2019, Japan Housing Finance Agency.
 */
package hui.quan.ult.nohin.common.core.typehandler;

import java.sql.Array;
import java.sql.CallableStatement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.ibatis.type.BaseTypeHandler;
import org.apache.ibatis.type.JdbcType;
import org.apache.ibatis.type.MappedJdbcTypes;
import org.apache.ibatis.type.MappedTypes;

/**
 * 配列型（varchar, String）タイプハンドラ
 *
 * @author HS
 */
@MappedJdbcTypes(value = JdbcType.ARRAY, includeNullJdbcType = true)
@MappedTypes(String[].class)
public class VarcharArrayTypeHandler extends BaseTypeHandler<String[]> {

  /** 配列要素がマッピングされる型のSQL名 */
  private static final String TYPE_NAME = "varchar";

  /**
   * 結果取得
   *
   * @param rs 結果セット
   * @param columnName カラム名
   * @return DB取得値
   * @throws SQLException 何らかのSQL例外
   */
  @Override
  public String[] getNullableResult(ResultSet rs, String columnName) throws SQLException {
    Array array = rs.getArray(columnName);
    if (array != null) {
      return (String[]) array.getArray();
    } else {
      return null;
    }
  }

  /**
   * 結果取得
   *
   * @param rs 結果セット
   * @param columnIndex カラムインデックス
   * @return DB取得値
   * @throws SQLException 何らかのSQL例外
   */
  @Override
  public String[] getNullableResult(ResultSet rs, int columnIndex) throws SQLException {
    Array array = rs.getArray(columnIndex);
    if (array != null) {
      return (String[]) array.getArray();
    } else {
      return null;
    }
  }

  /**
   * 結果取得
   *
   * @param cs コーラブルステートメント
   * @param columnIndex カラムインデックス
   * @return DB取得値
   * @throws SQLException なんらかのSQL例外
   */
  @Override
  public String[] getNullableResult(CallableStatement cs, int columnIndex) throws SQLException {
    Array array = cs.getArray(columnIndex);
    if (array != null) {
      return (String[]) array.getArray();
    } else {
      return null;
    }
  }

  /**
   * パラメータ設定
   *
   * @param ps プリペアドステートメント
   * @param parameterIndex パラメータインデックス
   * @param parameter パラメータ
   * @param jdbcType JDBCタイプ
   * @throws SQLException なんらかのSQL例外
   */
  @Override
  public void setNonNullParameter(PreparedStatement ps, int parameterIndex,
      String[] parameter, JdbcType jdbcType) throws SQLException {
    ps.setArray(parameterIndex, ps.getConnection().createArrayOf(TYPE_NAME, parameter));
  }
}
