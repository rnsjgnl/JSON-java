/*
 * @(#)HktcsGhCreateServiceImpl.java
 *
 * Copyright (C) 2019, Japan Housing Finance Agency.
 */
package hui.quan.ult.nohin.service;

import org.apache.commons.collections.CollectionUtils;

import hui.quan.ult.nohin.common.code.SyoriKekkaEnum;
import hui.quan.ult.nohin.common.core.entity.Entity;
import hui.quan.ult.nohin.manager.EntityManager;
import hui.quan.ult.nohin.vo.BatchInputVO;
import hui.quan.ult.nohin.vo.BatchOutputVO;


/**
 * 変更通知書原票作成サービス
 *
 * @author HS
 */
public class HktcsGhCreateServiceImpl extends AbstractService<BatchInputVO, BatchOutputVO> {

  /** 変更通知書一括登録帳票編集EntityManager */
  private final EntityManager<Entity, BatchInputVO>
      hktcsIktrReceiptEditEntityManagerImpl;


  /** エラーフラグ */
  private boolean errorFlg;

  /**
   * コンストラクタ
   *
   * @param hktcsIktrReceiptEditEntityManagerImpl 変更通知書一括登録帳票編集EntityManager
   * @param reportManager 帳票Manager
   */
  public HktcsGhCreateServiceImpl(
      EntityManager<Entity, BatchInputVO> hktcsIktrReceiptEditEntityManagerImpl) {
    super();
    this.hktcsIktrReceiptEditEntityManagerImpl = hktcsIktrReceiptEditEntityManagerImpl;
  }

  /**
   * 前処理
   *
   * @param input 帳票コピー先パスVO
   * @see jp.go.jhf.hlis.core.domain.service.k00.AbstractService#doPre(java.lang.Object)
   */
  @Override
  protected void doPre(BatchInputVO input) {
    //特になし
  }

  /**
   * 主処理
   *
   * @param input 帳票コピー先パスVO
   * @see jp.go.jhf.hlis.core.domain.service.k00.AbstractService#doExecute(java.lang.Object)
   */
  @Override
  protected void doExecute(BatchInputVO input) {
    
  }

  /**
   * 後処理
   *
   * @param input 帳票コピー先パスVO
   * @return BatchOutputVO
   * @see jp.go.jhf.hlis.core.domain.service.k00.AbstractService#doPost(java.lang.Object)
   */
  @Override
  protected BatchOutputVO doPost(BatchInputVO input) {
    //（１）BatchBaseOutVOを新規作成する
    BatchOutputVO output = new BatchOutputVO();
    //（２）エラーフラグがTRUEの場合、BatchBaseOutVOの実行結果をFALSEでセットし、返却する
    if (errorFlg) {
      output.setSyoriKekkaEnum(SyoriKekkaEnum.ABNORMAL);
    } else {
      //（３）BatchBaseOutVOの実行結果をTRUEでセットし、返却する
      output.setSyoriKekkaEnum(SyoriKekkaEnum.NORMAL);
    }
    return output;
  }
}
