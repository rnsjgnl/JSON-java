/*
 * @(#)NysListTmpDAO.java
 *
 * Copyright (C) 2019, Japan Housing Finance Agency.
 */
package hui.quan.ult.nohin.dao;

import java.util.List;

import org.mybatis.spring.annotation.MapperScan;



/**
 * 名寄せリストワークDAO
 *
 *
 * @author HS
 */
@MapperScan
public interface NysListTmpDAO {

  /**
   * 登録
   *
   *
   * @return 登録件数
   */
  int insert();

  /**
   * 取得
   *
   *
   * @return List名寄せリストワークEntity
   */
 // List<NysListEntity> select();
}
