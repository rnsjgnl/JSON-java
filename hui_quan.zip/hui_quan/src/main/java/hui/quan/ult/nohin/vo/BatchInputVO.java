/*
 * @(#)BatchInputVO.java
 *
 * Copyright (C) 2019, Japan Housing Finance Agency.
 */
package hui.quan.ult.nohin.vo;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.Map;

import lombok.Getter;
import lombok.Setter;

/**
 * 概要を記載
 *
 * <p>必要に応じて詳細を記載。不要の場合削除。</p>
 *
 * @author HS
 */
@Setter
@Getter
public class BatchInputVO implements Serializable {

  /** シリアルバージョンUID */
  private static final long serialVersionUID = 5424486467418829770L;

  /** ジョブID */
  private String jobName;

  /** ジョブパラメータ */
  private Map<String, Object> jobParameters;

  /** 処理 年月日 */
  private LocalDate syoriYmd;

  /** 処理対象月 */
  private LocalDate syoriTaisyoTsuki;

  /** 集計対象月 */
  private LocalDate syukeiTaisyoTsuki;

  /** 決算対象年度 */
  private LocalDate kessaiTaisyoNendo;
}
