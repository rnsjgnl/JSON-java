/*
 * @(#)LoggerImpl.java
 *
 * Copyright (C) 2019, Japan Housing Finance Agency.
 */
package hui.quan.ult.nohin.common.core.logger;

import java.util.ResourceBundle;

import org.slf4j.LoggerFactory;
import org.slf4j.Marker;

import hui.quan.ult.nohin.common.core.constants.MessageIdEnum;



/**
 * ロガークラス
 *
 * <p>
 * SL4Jを使用しログを出力するロガー部品。
 * SL4Jのロガーインタフェースに加えメッセージIDを引数にログを出力するインタフェースを提供する。
 * </p>
 *
 * @author HS
 */
public class LoggerImpl implements Logger {

  /** ロガー */
  private final org.slf4j.Logger logger;

  /** リソースバンドル */
  private final ResourceBundle bundle;

  /**
   * コンストラクタ
   *
   * @param clazz ロガークラス名
   * @param bundle リソースバンドル
   */
  public LoggerImpl(Class<?> clazz, ResourceBundle bundle) {
    logger = LoggerFactory.getLogger(clazz);
    this.bundle = bundle;
  }

  /**
   * コンストラクタ
   *
   * @param name ロガー名
   * @param bundle リソースバンドル
   */
  public LoggerImpl(String name, ResourceBundle bundle) {
    logger = LoggerFactory.getLogger(name);
    this.bundle = bundle;
  }

  /**
   * ロガー名取得
   *
   * @return ロガー名取得
   */
  @Override
  public String getName() {
    return logger.getName();
  }

  /**
   * traceレベルのロブ出力の可否判定
   *
   * <p>traceレベルのログ出力が可能な場合、{@code true}を不可の場合、{@code false}を返却する。</p>
   *
   * @return 出力可能な場合、{@code true}を不可の場合、{@code false}
   */
  @Override
  public boolean isTraceEnabled() {
    return logger.isTraceEnabled();
  }

  /**
   * traceレベルのロブ出力の可否判定
   *
   * <p>traceレベルのログ出力が可能な場合、{@code true}を不可の場合、{@code false}を返却する。</p>
   *
   * @param marker マーカー
   * @return 出力可能な場合、{@code true}を不可の場合、{@code false}
   */
  @Override
  public boolean isTraceEnabled(Marker marker) {
    return logger.isTraceEnabled(marker);
  }

  /**
   * traceレベルログ出力
   *
   * <p>引数のメッセージをtraceレベルでログを出力する。</p>
   *
   * @param message メッセージ
   */
  @Override
  public void trace(String message) {
    logger.trace(message);
  }

  /**
   * traceレベルログ出力
   *
   * <p>引数のメッセージおよび例外・エラー情報をtraceレベルでログを出力する。</p>
   *
   * @param message メッセージ
   * @param throwable 何らかの例外・エラー
   */
  @Override
  public void trace(String message, Throwable throwable) {
    logger.trace(message, throwable);
  }

  /**
   * traceレベルログ出力
   *
   * <p>引数のメッセージIDに紐づくメッセージをtraceレベルでログを出力する。</p>
   *
   * @param messageId メッセージID
   */
  @Override
  public void trace(MessageIdEnum messageId) {
    String message = bundle.getString(messageId.getId());
    logger.trace(message);
  }

  /**
   * traceレベルログ出力
   *
   * <p>引数のメッセージIDに紐づくフォーマットおよび置換オブジェクトで生成したメッセージをtraceレベルでログを出力する。</p>
   *
   * @param messageId メッセージID
   * @param arg 置換オブジェクト
   */
  @Override
  public void trace(MessageIdEnum messageId, Object arg) {
    String format = bundle.getString(messageId.getId());
    logger.trace(format, arg);
  }

  /**
   * traceレベルログ出力
   *
   * <p>引数のメッセージIDに紐づくフォーマットおよび置換オブジェクトで生成したメッセージをtraceレベルでログを出力する。</p>
   *
   * @param messageId メッセージID
   * @param arg1 置換オブジェクト1
   * @param arg2 置換オブジェクト2
   */
  @Override
  public void trace(MessageIdEnum messageId, Object arg1, Object arg2) {
    String format = bundle.getString(messageId.getId());
    logger.trace(format, arg1, arg2);
  }

  /**
   * traceレベルログ出力
   *
   * <p>引数のメッセージIDに紐づくフォーマットおよび置換オブジェクトで生成したメッセージをtraceレベルでログを出力する。</p>
   *
   * @param messageId メッセージID
   * @param args 置換オブジェクトの配列
   */
  @Override
  public void trace(MessageIdEnum messageId, Object... args) {
    String format = bundle.getString(messageId.getId());
    logger.trace(format, args);
  }

  /**
   * traceレベルログ出力
   *
   * <p>引数のメッセージをtraceレベルの指定されたマーカーでログを出力する。</p>
   *
   * @param marker マーカー
   * @param message メッセージ
   */
  @Override
  public void trace(Marker marker, String message) {
    logger.trace(marker, message);
  }

  /**
   * traceレベルログ出力
   *
   * <p>引数のメッセージおよび例外・エラー情報をマーカーで指定されたロガーへtraceレベルでログを出力する。</p>
   *
   * @param marker マーカー
   * @param message メッセージ
   * @param throwable 何らかの例外・エラー
   */
  @Override
  public void trace(Marker marker, String message, Throwable throwable) {
    logger.trace(marker, message, throwable);
  }

  /**
   * traceレベルログ出力
   *
   * <p>引数のメッセージIDに紐づくフォーマットおよび置換オブジェクトで生成したメッセージをマーカーで指定されたロガーへtraceレベルでログを出力する。</p>
   *
   * @param marker マーカー
   * @param messageId メッセージID
   * @param arg 置換オブジェクト
   */
  @Override
  public void trace(Marker marker, MessageIdEnum messageId, Object arg) {
    String format = bundle.getString(messageId.getId());
    logger.trace(marker, format, arg);
  }

  /**
   * traceレベルログ出力
   *
   * <p>引数のメッセージIDに紐づくメッセージをマーカーで指定されたロガーへtraceレベルでログを出力する。</p>
   *
   * @param marker マーカー
   * @param messageId メッセージID
   */
  @Override
  public void trace(Marker marker, MessageIdEnum messageId) {
    String message = bundle.getString(messageId.getId());
    logger.trace(marker, message);
  }

  /**
   * traceレベルログ出力
   *
   * <p>引数のメッセージIDに紐づくフォーマットおよび置換オブジェクトで生成したメッセージをマーカーで指定されたロガーへtraceレベルでログを出力する。</p>
   *
   * @param marker マーカー
   * @param messageId メッセージID
   * @param arg1 置換オブジェクト1
   * @param arg2 置換オブジェクト2
   */
  @Override
  public void trace(Marker marker, MessageIdEnum messageId, Object arg1, Object arg2) {
    String format = bundle.getString(messageId.getId());
    logger.trace(marker, format, arg1, arg2);
  }

  /**
   * traceレベルログ出力
   *
   * <p>引数のメッセージIDに紐づくフォーマットおよび置換オブジェクトで生成したメッセージをマーカーで指定されたロガーへtraceレベルでログを出力する。</p>
   *
   * @param marker マーカー
   * @param messageId メッセージID
   * @param args 置換オブジェクトの配列
   */
  @Override
  public void trace(Marker marker, MessageIdEnum messageId, Object... args) {
    String format = bundle.getString(messageId.getId());
    logger.trace(marker, format, args);
  }

  /**
   * debugレベルのロブ出力の可否判定
   *
   * <p>debugレベルのログ出力が可能な場合、{@code true}を不可の場合、{@code false}を返却する。</p>
   *
   * @return 出力可能な場合、{@code true}を不可の場合、{@code false}
   */
  @Override
  public boolean isDebugEnabled() {
    return logger.isDebugEnabled();
  }

  /**
   * debugレベルのロブ出力の可否判定
   *
   * <p>debugレベルのログ出力が可能な場合、{@code true}を不可の場合、{@code false}を返却する。</p>
   *
   * @param marker マーカー
   * @return 出力可能な場合、{@code true}を不可の場合、{@code false}
   */
  @Override
  public boolean isDebugEnabled(Marker marker) {
    return logger.isDebugEnabled(marker);
  }

  /**
   * debugレベルログ出力
   *
   * <p>引数のメッセージをdebugレベルでログを出力する。</p>
   *
   * @param message メッセージ
   */
  @Override
  public void debug(String message) {
    logger.debug(message);
  }

  /**
   * debugレベルログ出力
   *
   * <p>引数のメッセージおよび例外・エラー情報をdebugレベルでログを出力する。</p>
   *
   * @param message メッセージ
   * @param throwable 何らかの例外・エラー
   */
  @Override
  public void debug(String message, Throwable throwable) {
    logger.debug(message, throwable);
  }

  /**
   * debugレベルログ出力
   *
   * <p>引数のメッセージIDに紐づくメッセージをdebugレベルでログを出力する。</p>
   *
   * @param messageId メッセージID
   */
  @Override
  public void debug(MessageIdEnum messageId) {
    String message = bundle.getString(messageId.getId());
    logger.debug(message);
  }

  /**
   * debugレベルログ出力
   *
   * <p>引数のメッセージIDに紐づくフォーマットおよび置換オブジェクトで生成したメッセージをdebugレベルでログを出力する。</p>
   *
   * @param messageId メッセージID
   * @param arg 置換オブジェクト
   */
  @Override
  public void debug(MessageIdEnum messageId, Object arg) {
    String format = bundle.getString(messageId.getId());
    logger.debug(format, arg);
  }

  /**
   * debugレベルログ出力
   *
   * <p>引数のメッセージIDに紐づくフォーマットおよび置換オブジェクトで生成したメッセージをdebugレベルでログを出力する。</p>
   *
   * @param messageId メッセージID
   * @param arg1 置換オブジェクト1
   * @param arg2 置換オブジェクト2
   */
  @Override
  public void debug(MessageIdEnum messageId, Object arg1, Object arg2) {
    String format = bundle.getString(messageId.getId());
    logger.debug(format, arg1, arg2);
  }

  /**
   * debugレベルログ出力
   *
   * <p>引数のメッセージIDに紐づくフォーマットおよび置換オブジェクトで生成したメッセージをdebugレベルでログを出力する。</p>
   *
   * @param messageId メッセージID
   * @param args 置換オブジェクトの配列
   */
  @Override
  public void debug(MessageIdEnum messageId, Object... args) {
    String format = bundle.getString(messageId.getId());
    logger.debug(format, args);
  }

  /**
   * debugレベルログ出力
   *
   * <p>引数のメッセージをdebugレベルの指定されたマーカーでログを出力する。</p>
   *
   * @param marker マーカー
   * @param message メッセージ
   */
  @Override
  public void debug(Marker marker, String message) {
    logger.debug(marker, message);
  }

  /**
   * debugレベルログ出力
   *
   * <p>引数のメッセージおよび例外・エラー情報をマーカーで指定されたロガーへdebugレベルでログを出力する。</p>
   *
   * @param marker マーカー
   * @param message メッセージ
   * @param throwable 何らかの例外・エラー
   */
  @Override
  public void debug(Marker marker, String message, Throwable throwable) {
    logger.debug(marker, message, throwable);
  }

  /**
   * debugレベルログ出力
   *
   * <p>引数のメッセージIDに紐づくメッセージをマーカーで指定されたロガーへdebugレベルでログを出力する。</p>
   *
   * @param marker マーカー
   * @param messageId メッセージID
   */
  @Override
  public void debug(Marker marker, MessageIdEnum messageId) {
    String message = bundle.getString(messageId.getId());
    logger.debug(marker, message);
  }

  /**
   * debugレベルログ出力
   *
   * <p>引数のメッセージIDに紐づくフォーマットおよび置換オブジェクトで生成したメッセージをマーカーで指定されたロガーへdebugレベルでログを出力する。</p>
   *
   * @param marker マーカー
   * @param messageId メッセージID
   * @param arg 置換オブジェクト
   */
  @Override
  public void debug(Marker marker, MessageIdEnum messageId, Object arg) {
    String format = bundle.getString(messageId.getId());
    logger.debug(marker, format, arg);
  }

  /**
   * debugレベルログ出力
   *
   * <p>引数のメッセージIDに紐づくフォーマットおよび置換オブジェクトで生成したメッセージをマーカーで指定されたロガーへdebugレベルでログを出力する。</p>
   *
   * @param marker マーカー
   * @param messageId メッセージID
   * @param arg1 置換オブジェクト1
   * @param arg2 置換オブジェクト2
   */
  @Override
  public void debug(Marker marker, MessageIdEnum messageId, Object arg1, Object arg2) {
    String format = bundle.getString(messageId.getId());
    logger.debug(marker, format, arg1, arg2);
  }

  /**
   * debugレベルログ出力
   *
   * <p>引数のメッセージIDに紐づくフォーマットおよび置換オブジェクトで生成したメッセージをマーカーで指定されたロガーへdebugレベルでログを出力する。</p>
   *
   * @param marker マーカー
   * @param messageId メッセージID
   * @param args 置換オブジェクトの配列
   */
  @Override
  public void debug(Marker marker, MessageIdEnum messageId, Object... args) {
    String format = bundle.getString(messageId.getId());
    logger.debug(marker, format, args);
  }

  /**
   * infoレベルのロブ出力の可否判定
   *
   * <p>infoレベルのログ出力が可能な場合、{@code true}を不可の場合、{@code false}を返却する。</p>
   *
   * @return 出力可能な場合、{@code true}を不可の場合、{@code false}
   */
  @Override
  public boolean isInfoEnabled() {
    return logger.isInfoEnabled();
  }

  /**
   * infoレベルのロブ出力の可否判定
   *
   * <p>infoレベルのログ出力が可能な場合、{@code true}を不可の場合、{@code false}を返却する。</p>
   *
   * @param marker マーカー
   * @return 出力可能な場合、{@code true}を不可の場合、{@code false}
   */
  @Override
  public boolean isInfoEnabled(Marker marker) {
    return logger.isInfoEnabled(marker);
  }

  /**
   * infoレベルログ出力
   *
   * <p>引数のメッセージをinfoレベルでログを出力する。</p>
   *
   * @param message メッセージ
   */
  @Override
  public void info(String message) {
    logger.info(message);
  }

  /**
   * infoレベルログ出力
   *
   * <p>引数のメッセージおよび例外・エラー情報をinfoレベルでログを出力する。</p>
   *
   * @param message メッセージ
   * @param throwable 何らかの例外・エラー
   */
  @Override
  public void info(String message, Throwable throwable) {
    logger.info(message, throwable);
  }

  /**
   * infoレベルログ出力
   *
   * <p>引数のメッセージIDに紐づくメッセージをinfoレベルでログを出力する。</p>
   *
   * @param messageId メッセージID
   */
  @Override
  public void info(MessageIdEnum messageId) {
    String message = bundle.getString(messageId.getId());
    logger.info(message);
  }

  /**
   * infoレベルログ出力
   *
   * <p>引数のメッセージIDに紐づくフォーマットおよび置換オブジェクトで生成したメッセージをinfoレベルでログを出力する。</p>
   *
   * @param messageId メッセージID
   * @param arg 置換オブジェクト
   */
  @Override
  public void info(MessageIdEnum messageId, Object arg) {
    String format = bundle.getString(messageId.getId());
    logger.info(format, arg);
  }

  /**
   * infoレベルログ出力
   *
   * <p>引数のメッセージIDに紐づくフォーマットおよび置換オブジェクトで生成したメッセージをinfoレベルでログを出力する。</p>
   *
   * @param messageId メッセージID
   * @param arg1 置換オブジェクト1
   * @param arg2 置換オブジェクト2
   */
  @Override
  public void info(MessageIdEnum messageId, Object arg1, Object arg2) {
    String format = bundle.getString(messageId.getId());
    logger.info(format, arg1, arg2);
  }

  /**
   * infoレベルログ出力
   *
   * <p>引数のメッセージIDに紐づくフォーマットおよび置換オブジェクトで生成したメッセージをinfoレベルでログを出力する。</p>
   *
   * @param messageId メッセージID
   * @param args 置換オブジェクトの配列
   */
  @Override
  public void info(MessageIdEnum messageId, Object... args) {
    String format = bundle.getString(messageId.getId());
    logger.info(format, args);
  }

  /**
   * infoレベルログ出力
   *
   * <p>引数のメッセージをinfoレベルの指定されたマーカーでログを出力する。</p>
   *
   * @param marker マーカー
   * @param message メッセージ
   */
  @Override
  public void info(Marker marker, String message) {
    logger.info(marker, message);
  }

  /**
   * infoレベルログ出力
   *
   * <p>引数のメッセージおよび例外・エラー情報をマーカーで指定されたロガーへinfoレベルでログを出力する。</p>
   *
   * @param marker マーカー
   * @param message メッセージ
   * @param throwable 何らかの例外・エラー
   */
  @Override
  public void info(Marker marker, String message, Throwable throwable) {
    logger.info(marker, message, throwable);
  }

  /**
   * infoレベルログ出力
   *
   * <p>引数のメッセージIDに紐づくメッセージをマーカーで指定されたロガーへinfoレベルでログを出力する。</p>
   *
   * @param marker マーカー
   * @param messageId メッセージID
   */
  @Override
  public void info(Marker marker, MessageIdEnum messageId) {
    String message = bundle.getString(messageId.getId());
    logger.info(marker, message);
  }

  /**
   * infoレベルログ出力
   *
   * <p>引数のメッセージIDに紐づくフォーマットおよび置換オブジェクトで生成したメッセージをマーカーで指定されたロガーへinfoレベルでログを出力する。</p>
   *
   * @param marker マーカー
   * @param messageId メッセージID
   * @param arg 置換オブジェクト
   */
  @Override
  public void info(Marker marker, MessageIdEnum messageId, Object arg) {
    String format = bundle.getString(messageId.getId());
    logger.info(marker, format, arg);
  }

  /**
   * infoレベルログ出力
   *
   * <p>引数のメッセージIDに紐づくフォーマットおよび置換オブジェクトで生成したメッセージをマーカーで指定されたロガーへinfoレベルでログを出力する。</p>
   *
   * @param marker マーカー
   * @param messageId メッセージID
   * @param arg1 置換オブジェクト1
   * @param arg2 置換オブジェクト2
   */
  @Override
  public void info(Marker marker, MessageIdEnum messageId, Object arg1, Object arg2) {
    String format = bundle.getString(messageId.getId());
    logger.info(marker, format, arg1, arg2);
  }

  /**
   * infoレベルログ出力
   *
   * <p>引数のメッセージIDに紐づくフォーマットおよび置換オブジェクトで生成したメッセージをマーカーで指定されたロガーへinfoレベルでログを出力する。</p>
   *
   * @param marker マーカー
   * @param messageId メッセージID
   * @param args 置換オブジェクトの配列
   */
  @Override
  public void info(Marker marker, MessageIdEnum messageId, Object... args) {
    String format = bundle.getString(messageId.getId());
    logger.info(marker, format, args);
  }

  /**
   * warnレベルのロブ出力の可否判定
   *
   * <p>warnレベルのログ出力が可能な場合、{@code true}を不可の場合、{@code false}を返却する。</p>
   *
   * @return 出力可能な場合、{@code true}を不可の場合、{@code false}
   */
  @Override
  public boolean isWarnEnabled() {
    return logger.isWarnEnabled();
  }

  /**
   * warnレベルのロブ出力の可否判定
   *
   * <p>warnレベルのログ出力が可能な場合、{@code true}を不可の場合、{@code false}を返却する。</p>
   *
   * @param marker マーカー
   * @return 出力可能な場合、{@code true}を不可の場合、{@code false}
   */
  @Override
  public boolean isWarnEnabled(Marker marker) {
    return logger.isWarnEnabled(marker);
  }

  /**
   * warnレベルログ出力
   *
   * <p>引数のメッセージをwarnレベルでログを出力する。</p>
   *
   * @param message メッセージ
   */
  @Override
  public void warn(String message) {
    logger.warn(message);
  }

  /**
   * warnレベルログ出力
   *
   * <p>引数のメッセージおよび例外・エラー情報をwarnレベルでログを出力する。</p>
   *
   * @param message メッセージ
   * @param throwable 何らかの例外・エラー
   */
  @Override
  public void warn(String message, Throwable throwable) {
    logger.warn(message, throwable);
  }

  /**
   * warnレベルログ出力
   *
   * <p>引数のメッセージIDに紐づくメッセージをwarnレベルでログを出力する。</p>
   *
   * @param messageId メッセージID
   */
  @Override
  public void warn(MessageIdEnum messageId) {
    String message = bundle.getString(messageId.getId());
    logger.warn(message);
  }

  /**
   * warnレベルログ出力
   *
   * <p>引数のメッセージIDに紐づくフォーマットおよび置換オブジェクトで生成したメッセージをwarnレベルでログを出力する。</p>
   *
   * @param messageId メッセージID
   * @param arg 置換オブジェクト
   */
  @Override
  public void warn(MessageIdEnum messageId, Object arg) {
    String format = bundle.getString(messageId.getId());
    logger.warn(format, arg);
  }

  /**
   * warnレベルログ出力
   *
   * <p>引数のメッセージIDに紐づくフォーマットおよび置換オブジェクトで生成したメッセージをwarnレベルでログを出力する。</p>
   *
   * @param messageId メッセージID
   * @param arg1 置換オブジェクト1
   * @param arg2 置換オブジェクト2
   */
  @Override
  public void warn(MessageIdEnum messageId, Object arg1, Object arg2) {
    String format = bundle.getString(messageId.getId());
    logger.warn(format, arg1, arg2);
  }

  /**
   * warnレベルログ出力
   *
   * <p>引数のメッセージIDに紐づくフォーマットおよび置換オブジェクトで生成したメッセージをwarnレベルでログを出力する。</p>
   *
   * @param messageId メッセージID
   * @param args 置換オブジェクトの配列
   */
  @Override
  public void warn(MessageIdEnum messageId, Object... args) {
    String format = bundle.getString(messageId.getId());
    logger.warn(format, args);
  }

  /**
   * warnレベルログ出力
   *
   * <p>引数のメッセージをwarnレベルの指定されたマーカーでログを出力する。</p>
   *
   * @param marker マーカー
   * @param message メッセージ
   */
  @Override
  public void warn(Marker marker, String message) {
    logger.warn(marker, message);
  }

  /**
   * warnレベルログ出力
   *
   * <p>引数のメッセージおよび例外・エラー情報をマーカーで指定されたロガーへwarnレベルでログを出力する。</p>
   *
   * @param marker マーカー
   * @param message メッセージ
   * @param throwable 何らかの例外・エラー
   */
  @Override
  public void warn(Marker marker, String message, Throwable throwable) {
    logger.warn(marker, message, throwable);
  }

  /**
   * warnレベルログ出力
   *
   * <p>引数のメッセージIDに紐づくメッセージをマーカーで指定されたロガーへwarnレベルでログを出力する。</p>
   *
   * @param marker マーカー
   * @param messageId メッセージID
   */
  @Override
  public void warn(Marker marker, MessageIdEnum messageId) {
    String message = bundle.getString(messageId.getId());
    logger.warn(marker, message);
  }

  /**
   * warnレベルログ出力
   *
   * <p>引数のメッセージIDに紐づくフォーマットおよび置換オブジェクトで生成したメッセージをマーカーで指定されたロガーへwarnレベルでログを出力する。</p>
   *
   * @param marker マーカー
   * @param messageId メッセージID
   * @param arg 置換オブジェクト
   */
  @Override
  public void warn(Marker marker, MessageIdEnum messageId, Object arg) {
    String format = bundle.getString(messageId.getId());
    logger.warn(marker, format, arg);
  }

  /**
   * warnレベルログ出力
   *
   * <p>引数のメッセージIDに紐づくフォーマットおよび置換オブジェクトで生成したメッセージをマーカーで指定されたロガーへwarnレベルでログを出力する。</p>
   *
   * @param marker マーカー
   * @param messageId メッセージID
   * @param arg1 置換オブジェクト1
   * @param arg2 置換オブジェクト2
   */
  @Override
  public void warn(Marker marker, MessageIdEnum messageId, Object arg1, Object arg2) {
    String format = bundle.getString(messageId.getId());
    logger.warn(marker, format, arg1, arg2);
  }

  /**
   * warnレベルログ出力
   *
   * <p>引数のメッセージIDに紐づくフォーマットおよび置換オブジェクトで生成したメッセージをマーカーで指定されたロガーへwarnレベルでログを出力する。</p>
   *
   * @param marker マーカー
   * @param messageId メッセージID
   * @param args 置換オブジェクトの配列
   */
  @Override
  public void warn(Marker marker, MessageIdEnum messageId, Object... args) {
    String format = bundle.getString(messageId.getId());
    logger.warn(marker, format, args);
  }

  /**
   * errorレベルのロブ出力の可否判定
   *
   * <p>errorレベルのログ出力が可能な場合、{@code true}を不可の場合、{@code false}を返却する。</p>
   *
   * @return 出力可能な場合、{@code true}を不可の場合、{@code false}
   */
  @Override
  public boolean isErrorEnabled() {
    return logger.isErrorEnabled();
  }

  /**
   * errorレベルのロブ出力の可否判定
   *
   * <p>errorレベルのログ出力が可能な場合、{@code true}を不可の場合、{@code false}を返却する。</p>
   *
   * @param marker マーカー
   * @return 出力可能な場合、{@code true}を不可の場合、{@code false}
   */
  @Override
  public boolean isErrorEnabled(Marker marker) {
    return logger.isErrorEnabled(marker);
  }

  /**
   * errorレベルログ出力
   *
   * <p>引数のメッセージをerrorレベルでログを出力する。</p>
   *
   * @param message メッセージ
   */
  @Override
  public void error(String message) {
    logger.error(message);
  }

  /**
   * errorレベルログ出力
   *
   * <p>引数のメッセージおよび例外・エラー情報をerrorレベルでログを出力する。</p>
   *
   * @param message メッセージ
   * @param throwable 何らかの例外・エラー
   */
  @Override
  public void error(String message, Throwable throwable) {
    logger.error(message, throwable);
  }

  /**
   * errorレベルログ出力
   *
   * <p>引数のメッセージIDに紐づくメッセージをerrorレベルでログを出力する。</p>
   *
   * @param messageId メッセージID
   */
  @Override
  public void error(MessageIdEnum messageId) {
    String message = bundle.getString(messageId.getId());
    logger.error(message);
  }

  /**
   * errorレベルログ出力
   *
   * <p>引数のメッセージIDに紐づくフォーマットおよび置換オブジェクトで生成したメッセージをerrorレベルでログを出力する。</p>
   *
   * @param messageId メッセージID
   * @param arg 置換オブジェクト
   */
  @Override
  public void error(MessageIdEnum messageId, Object arg) {
    String format = bundle.getString(messageId.getId());
    logger.error(format, arg);
  }

  /**
   * errorレベルログ出力
   *
   * <p>引数のメッセージIDに紐づくフォーマットおよび置換オブジェクトで生成したメッセージをerrorレベルでログを出力する。</p>
   *
   * @param messageId メッセージID
   * @param arg1 置換オブジェクト1
   * @param arg2 置換オブジェクト2
   */
  @Override
  public void error(MessageIdEnum messageId, Object arg1, Object arg2) {
    String format = bundle.getString(messageId.getId());
    logger.error(format, arg1, arg2);
  }

  /**
   * errorレベルログ出力
   *
   * <p>引数のメッセージIDに紐づくフォーマットおよび置換オブジェクトで生成したメッセージをerrorレベルでログを出力する。</p>
   *
   * @param messageId メッセージID
   * @param args 置換オブジェクトの配列
   */
  @Override
  public void error(MessageIdEnum messageId, Object... args) {
    String format = bundle.getString(messageId.getId());
    logger.error(format, args);
  }

  /**
   * errorレベルログ出力
   *
   * <p>引数のメッセージをerrorレベルの指定されたマーカーでログを出力する。</p>
   *
   * @param marker マーカー
   * @param message メッセージ
   */
  @Override
  public void error(Marker marker, String message) {
    logger.error(marker, message);
  }

  /**
   * errorレベルログ出力
   *
   * <p>引数のメッセージおよび例外・エラー情報をマーカーで指定されたロガーへerrorレベルでログを出力する。</p>
   *
   * @param marker マーカー
   * @param message メッセージ
   * @param throwable 何らかの例外・エラー
   */
  @Override
  public void error(Marker marker, String message, Throwable throwable) {
    logger.error(marker, message, throwable);
  }

  /**
   * errorレベルログ出力
   *
   * <p>引数のメッセージIDに紐づくメッセージをマーカーで指定されたロガーへerrorレベルでログを出力する。</p>
   *
   * @param marker マーカー
   * @param messageId メッセージID
   */
  @Override
  public void error(Marker marker, MessageIdEnum messageId) {
    String message = bundle.getString(messageId.getId());
    logger.error(marker, message);
  }

  /**
   * errorレベルログ出力
   *
   * <p>引数のメッセージIDに紐づくフォーマットおよび置換オブジェクトで生成したメッセージをマーカーで指定されたロガーへerrorレベルでログを出力する。</p>
   *
   * @param marker マーカー
   * @param messageId メッセージID
   * @param arg 置換オブジェクト
   */
  @Override
  public void error(Marker marker, MessageIdEnum messageId, Object arg) {
    String format = bundle.getString(messageId.getId());
    logger.error(marker, format, arg);
  }

  /**
   * errorレベルログ出力
   *
   * <p>引数のメッセージIDに紐づくフォーマットおよび置換オブジェクトで生成したメッセージをマーカーで指定されたロガーへerrorレベルでログを出力する。</p>
   *
   * @param marker マーカー
   * @param messageId メッセージID
   * @param arg1 置換オブジェクト1
   * @param arg2 置換オブジェクト2
   */
  @Override
  public void error(Marker marker, MessageIdEnum messageId, Object arg1, Object arg2) {
    String format = bundle.getString(messageId.getId());
    logger.error(marker, format, arg1, arg2);
  }

  /**
   * errorレベルログ出力
   *
   * <p>引数のメッセージIDに紐づくフォーマットおよび置換オブジェクトで生成したメッセージをマーカーで指定されたロガーへerrorレベルでログを出力する。</p>
   *
   * @param marker マーカー
   * @param messageId メッセージID
   * @param args 置換オブジェクトの配列
   */
  @Override
  public void error(Marker marker, MessageIdEnum messageId, Object... args) {
    String format = bundle.getString(messageId.getId());
    logger.error(marker, format, args);
  }
}
