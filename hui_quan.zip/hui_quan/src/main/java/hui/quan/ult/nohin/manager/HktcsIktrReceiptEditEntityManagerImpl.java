/*
 * @(#)HktcsIktrReceiptEditEntityManagerImpl.java
 *
 * Copyright (C) 2019, Japan Housing Finance Agency.
 */
package hui.quan.ult.nohin.manager;

import java.util.List;

import hui.quan.ult.nohin.common.core.entity.Entity;
import hui.quan.ult.nohin.dao.NysListTmpDAO;
import hui.quan.ult.nohin.vo.AbstractBaseVO;



/**
 * 変更通知書一括登録帳票編集EntityManager
 *
 * @author HS
 */
public final class HktcsIktrReceiptEditEntityManagerImpl
    implements EntityManager<Entity, AbstractBaseVO> {

 
  /** 名寄せリストワークDAO */
  private final NysListTmpDAO nysListTmpDAO;

  /**
   * コンストラクタ
   *
   * @param hktcsNrKnlistSntTmpDAO 変更通知書入力確認リスト（その他）ワークDAO
   * @param hktcsIktkKnlistTkbTmpDAO 変更通知書一括登録データ確認リスト（登録分）ワークDAO
   * @param hktcsIktkKnlistMtkbTmpDAO 変更通知書入力確認リスト（その他）ワークDAO
   * @param hktcsGhDAO 変更通知書原票DAO
   * @param nysListTmpDAO 名寄せリストワークDAO
   */
  public HktcsIktrReceiptEditEntityManagerImpl(
      NysListTmpDAO nysListTmpDAO) {
    super();
    this.nysListTmpDAO = nysListTmpDAO;
  }

  /**
   * 生成
   *
   * @param input BaseVO
   * @return entity Entity
   * @see jp.go.jhf.lscm.core.domain.manager.EntityManager#create(java.lang.Object)
   */
  @Override
  public Entity create(AbstractBaseVO input) {
    return null;
  }

  /**
   * 保存
   *
   * @param entity Entity
   * @return 保存成功／保存失敗
   * @see jp.go.jhf.lscm.core.domain.manager.EntityManager#store(java.lang.Object)
   */
  @Override
  public boolean store(Entity entity) {

    return true;
  }

}
