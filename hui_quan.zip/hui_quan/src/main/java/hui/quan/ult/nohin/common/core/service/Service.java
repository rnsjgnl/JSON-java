/*
 * @(#)Service.java
 *
 * Copyright (C) 2019, Japan Housing Finance Agency.
 */
package hui.quan.ult.nohin.common.core.service;

/**
 * Serviceインタフェース。
 *
 * @author HS
 *
 * @param <I> 入力情報。
 * @param <O> 出力情報。
 */
public interface Service<I, O> {

  /**
   * 実行
   *
   * <p>入力情報を使用して何らかの処理を実行し出力情報を返却する。</p>
   *
   * @param input 入力情報
   * @return 出力情報
   */
  O execute(I input);
}
