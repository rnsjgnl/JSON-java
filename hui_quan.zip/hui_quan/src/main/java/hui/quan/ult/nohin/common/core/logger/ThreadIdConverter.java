/*
 * @(#)ThreadIdConverter.java
 *
 * Copyright (C) 2019, Japan Housing Finance Agency.
 */
package hui.quan.ult.nohin.common.core.logger;

import ch.qos.logback.classic.pattern.ClassicConverter;
import ch.qos.logback.classic.spi.ILoggingEvent;

/**
 * 概要を記載
 *
 * <p>必要に応じて詳細を記載。不要の場合削除。</p>
 *
 * @author HS
 */
public class ThreadIdConverter extends ClassicConverter {

  /**
   * 概要を記載
   *
   * @param event イベント
   * @return スレッドID
   */
  @Override
  public String convert(ILoggingEvent event) {
    return String.format("%016x", Thread.currentThread().getId());
  }

}
