/*
 * @(#)Logger.java
 *
 * Copyright (C) 2019, Japan Housing Finance Agency.
 */
package hui.quan.ult.nohin.common.core.logger;

import org.slf4j.Marker;

import hui.quan.ult.nohin.common.core.constants.MessageIdEnum;



/**
 * 概要を記載
 *
 * <p>
 * 必要に応じて詳細を記載。不要の場合削除。
 * </p>
 *
 * @author HS
 */
public interface Logger {
  /**
   * ロガー名取得
   *
   * @return ロガー名取得
   */
  String getName();

  /**
   * traceレベルのロブ出力の可否判定
   *
   * <p>traceレベルのログ出力が可能な場合、{@code true}を不可の場合、{@code false}を返却する。</p>
   *
   * @return 出力可能な場合、{@code true}を不可の場合、{@code false}
   */
  boolean isTraceEnabled();

  /**
   * traceレベルのロブ出力の可否判定
   *
   * <p>traceレベルのログ出力が可能な場合、{@code true}を不可の場合、{@code false}を返却する。</p>
   *
   * @param marker マーカー
   * @return 出力可能な場合、{@code true}を不可の場合、{@code false}
   */
  boolean isTraceEnabled(Marker marker);

  /**
   * traceレベルログ出力
   *
   * <p>引数のメッセージをtraceレベルでログを出力する。</p>
   *
   * @param message メッセージ
   */
  void trace(String message);

  /**
   * traceレベルログ出力
   *
   * <p>引数のメッセージおよび例外・エラー情報をtraceレベルでログを出力する。</p>
   *
   * @param message メッセージ
   * @param throwable 何らかの例外・エラー
   */
  void trace(String message, Throwable throwable);

  /**
   * traceレベルログ出力
   *
   * <p>引数のメッセージIDに紐づくメッセージをtraceレベルでログを出力する。</p>
   *
   * @param messageId メッセージID
   */
  void trace(MessageIdEnum messageId);

  /**
   * traceレベルログ出力
   *
   * <p>引数のメッセージIDに紐づくフォーマットおよび置換オブジェクトで生成したメッセージをtraceレベルでログを出力する。</p>
   *
   * @param messageId メッセージID
   * @param arg 置換オブジェクト
   */
  void trace(MessageIdEnum messageId, Object arg);

  /**
   * traceレベルログ出力
   *
   * <p>引数のメッセージIDに紐づくフォーマットおよび置換オブジェクトで生成したメッセージをtraceレベルでログを出力する。</p>
   *
   * @param messageId メッセージID
   * @param arg1 置換オブジェクト1
   * @param arg2 置換オブジェクト2
   */
  void trace(MessageIdEnum messageId, Object arg1, Object arg2);

  /**
   * traceレベルログ出力
   *
   * <p>引数のメッセージIDに紐づくフォーマットおよび置換オブジェクトで生成したメッセージをtraceレベルでログを出力する。</p>
   *
   * @param messageId メッセージID
   * @param args 置換オブジェクトの配列
   */
  void trace(MessageIdEnum messageId, Object... args);

  /**
   * traceレベルログ出力
   *
   * <p>引数のメッセージをtraceレベルの指定されたマーカーでログを出力する。</p>
   *
   * @param marker マーカー
   * @param message メッセージ
   */
  void trace(Marker marker, String message);

  /**
   * traceレベルログ出力
   *
   * <p>引数のメッセージおよび例外・エラー情報をマーカーで指定されたロガーへtraceレベルでログを出力する。</p>
   *
   * @param marker マーカー
   * @param message メッセージ
   * @param throwable 何らかの例外・エラー
   */
  void trace(Marker marker, String message, Throwable throwable);

  /**
   * traceレベルログ出力
   *
   * <p>引数のメッセージIDに紐づくフォーマットおよび置換オブジェクトで生成したメッセージをマーカーで指定されたロガーへtraceレベルでログを出力する。</p>
   *
   * @param marker マーカー
   * @param messageId メッセージID
   * @param arg 置換オブジェクト
   */
  void trace(Marker marker, MessageIdEnum messageId, Object arg);

  /**
   * traceレベルログ出力
   *
   * <p>引数のメッセージIDに紐づくメッセージをマーカーで指定されたロガーへtraceレベルでログを出力する。</p>
   *
   * @param marker マーカー
   * @param messageId メッセージID
   */
  void trace(Marker marker, MessageIdEnum messageId);

  /**
   * traceレベルログ出力
   *
   * <p>引数のメッセージIDに紐づくフォーマットおよび置換オブジェクトで生成したメッセージをマーカーで指定されたロガーへtraceレベルでログを出力する。</p>
   *
   * @param marker マーカー
   * @param messageId メッセージID
   * @param arg1 置換オブジェクト1
   * @param arg2 置換オブジェクト2
   */
  void trace(Marker marker, MessageIdEnum messageId, Object arg1, Object arg2);

  /**
   * traceレベルログ出力
   *
   * <p>引数のメッセージIDに紐づくフォーマットおよび置換オブジェクトで生成したメッセージをマーカーで指定されたロガーへtraceレベルでログを出力する。</p>
   *
   * @param marker マーカー
   * @param messageId メッセージID
   * @param args 置換オブジェクトの配列
   */
  void trace(Marker marker, MessageIdEnum messageId, Object... args);

  /**
   * debugレベルのロブ出力の可否判定
   *
   * <p>debugレベルのログ出力が可能な場合、{@code true}を不可の場合、{@code false}を返却する。</p>
   *
   * @return 出力可能な場合、{@code true}を不可の場合、{@code false}
   */
  boolean isDebugEnabled();

  /**
   * debugレベルのロブ出力の可否判定
   *
   * <p>debugレベルのログ出力が可能な場合、{@code true}を不可の場合、{@code false}を返却する。</p>
   *
   * @param marker マーカー
   * @return 出力可能な場合、{@code true}を不可の場合、{@code false}
   */
  boolean isDebugEnabled(Marker marker);

  /**
   * debugレベルログ出力
   *
   * <p>引数のメッセージをdebugレベルでログを出力する。</p>
   *
   * @param message メッセージ
   */
  void debug(String message);

  /**
   * debugレベルログ出力
   *
   * <p>引数のメッセージおよび例外・エラー情報をdebugレベルでログを出力する。</p>
   *
   * @param message メッセージ
   * @param throwable 何らかの例外・エラー
   */
  void debug(String message, Throwable throwable);

  /**
   * debugレベルログ出力
   *
   * <p>引数のメッセージIDに紐づくメッセージをdebugレベルでログを出力する。</p>
   *
   * @param messageId メッセージID
   */
  void debug(MessageIdEnum messageId);

  /**
   * debugレベルログ出力
   *
   * <p>引数のメッセージIDに紐づくフォーマットおよび置換オブジェクトで生成したメッセージをdebugレベルでログを出力する。</p>
   *
   * @param messageId メッセージID
   * @param arg 置換オブジェクト
   */
  void debug(MessageIdEnum messageId, Object arg);

  /**
   * debugレベルログ出力
   *
   * <p>引数のメッセージIDに紐づくフォーマットおよび置換オブジェクトで生成したメッセージをdebugレベルでログを出力する。</p>
   *
   * @param messageId メッセージID
   * @param arg1 置換オブジェクト1
   * @param arg2 置換オブジェクト2
   */
  void debug(MessageIdEnum messageId, Object arg1, Object arg2);

  /**
   * debugレベルログ出力
   *
   * <p>引数のメッセージIDに紐づくフォーマットおよび置換オブジェクトで生成したメッセージをdebugレベルでログを出力する。</p>
   *
   * @param messageId メッセージID
   * @param args 置換オブジェクトの配列
   */
  void debug(MessageIdEnum messageId, Object... args);

  /**
   * debugレベルログ出力
   *
   * <p>引数のメッセージをdebugレベルの指定されたマーカーでログを出力する。</p>
   *
   * @param marker マーカー
   * @param message メッセージ
   */
  void debug(Marker marker, String message);

  /**
   * debugレベルログ出力
   *
   * <p>引数のメッセージおよび例外・エラー情報をマーカーで指定されたロガーへdebugレベルでログを出力する。</p>
   *
   * @param marker マーカー
   * @param message メッセージ
   * @param throwable 何らかの例外・エラー
   */
  void debug(Marker marker, String message, Throwable throwable);

  /**
   * debugレベルログ出力
   *
   * <p>引数のメッセージIDに紐づくメッセージをマーカーで指定されたロガーへdebugレベルでログを出力する。</p>
   *
   * @param marker マーカー
   * @param messageId メッセージID
   */
  void debug(Marker marker, MessageIdEnum messageId);

  /**
   * debugレベルログ出力
   *
   * <p>引数のメッセージIDに紐づくフォーマットおよび置換オブジェクトで生成したメッセージをマーカーで指定されたロガーへdebugレベルでログを出力する。</p>
   *
   * @param marker マーカー
   * @param messageId メッセージID
   * @param arg 置換オブジェクト
   */
  void debug(Marker marker, MessageIdEnum messageId, Object arg);

  /**
   * debugレベルログ出力
   *
   * <p>引数のメッセージIDに紐づくフォーマットおよび置換オブジェクトで生成したメッセージをマーカーで指定されたロガーへdebugレベルでログを出力する。</p>
   *
   * @param marker マーカー
   * @param messageId メッセージID
   * @param arg1 置換オブジェクト1
   * @param arg2 置換オブジェクト2
   */
  void debug(Marker marker, MessageIdEnum messageId, Object arg1, Object arg2);

  /**
   * debugレベルログ出力
   *
   * <p>引数のメッセージIDに紐づくフォーマットおよび置換オブジェクトで生成したメッセージをマーカーで指定されたロガーへdebugレベルでログを出力する。</p>
   *
   * @param marker マーカー
   * @param messageId メッセージID
   * @param args 置換オブジェクトの配列
   */
  void debug(Marker marker, MessageIdEnum messageId, Object... args);

  /**
   * infoレベルのロブ出力の可否判定
   *
   * <p>infoレベルのログ出力が可能な場合、{@code true}を不可の場合、{@code false}を返却する。</p>
   *
   * @return 出力可能な場合、{@code true}を不可の場合、{@code false}
   */
  boolean isInfoEnabled();

  /**
   * infoレベルのロブ出力の可否判定
   *
   * <p>infoレベルのログ出力が可能な場合、{@code true}を不可の場合、{@code false}を返却する。</p>
   *
   * @param marker マーカー
   * @return 出力可能な場合、{@code true}を不可の場合、{@code false}
   */
  boolean isInfoEnabled(Marker marker);

  /**
   * infoレベルログ出力
   *
   * <p>引数のメッセージをinfoレベルでログを出力する。</p>
   *
   * @param message メッセージ
   */
  void info(String message);

  /**
   * infoレベルログ出力
   *
   * <p>引数のメッセージおよび例外・エラー情報をinfoレベルでログを出力する。</p>
   *
   * @param message メッセージ
   * @param throwable 何らかの例外・エラー
   */
  void info(String message, Throwable throwable);

  /**
   * infoレベルログ出力
   *
   * <p>引数のメッセージIDに紐づくメッセージをinfoレベルでログを出力する。</p>
   *
   * @param messageId メッセージID
   */
  void info(MessageIdEnum messageId);

  /**
   * infoレベルログ出力
   *
   * <p>引数のメッセージIDに紐づくフォーマットおよび置換オブジェクトで生成したメッセージをinfoレベルでログを出力する。</p>
   *
   * @param messageId メッセージID
   * @param arg 置換オブジェクト
   */
  void info(MessageIdEnum messageId, Object arg);

  /**
   * infoレベルログ出力
   *
   * <p>引数のメッセージIDに紐づくフォーマットおよび置換オブジェクトで生成したメッセージをinfoレベルでログを出力する。</p>
   *
   * @param messageId メッセージID
   * @param arg1 置換オブジェクト1
   * @param arg2 置換オブジェクト2
   */
  void info(MessageIdEnum messageId, Object arg1, Object arg2);

  /**
   * infoレベルログ出力
   *
   * <p>引数のメッセージIDに紐づくフォーマットおよび置換オブジェクトで生成したメッセージをinfoレベルでログを出力する。</p>
   *
   * @param messageId メッセージID
   * @param args 置換オブジェクトの配列
   */
  void info(MessageIdEnum messageId, Object... args);

  /**
   * infoレベルログ出力
   *
   * <p>引数のメッセージをinfoレベルの指定されたマーカーでログを出力する。</p>
   *
   * @param marker マーカー
   * @param message メッセージ
   */
  void info(Marker marker, String message);

  /**
   * infoレベルログ出力
   *
   * <p>引数のメッセージおよび例外・エラー情報をマーカーで指定されたロガーへinfoレベルでログを出力する。</p>
   *
   * @param marker マーカー
   * @param message メッセージ
   * @param throwable 何らかの例外・エラー
   */
  void info(Marker marker, String message, Throwable throwable);

  /**
   * infoレベルログ出力
   *
   * <p>引数のメッセージIDに紐づくメッセージをマーカーで指定されたロガーへinfoレベルでログを出力する。</p>
   *
   * @param marker マーカー
   * @param messageId メッセージID
   */
  void info(Marker marker, MessageIdEnum messageId);

  /**
   * infoレベルログ出力
   *
   * <p>引数のメッセージIDに紐づくフォーマットおよび置換オブジェクトで生成したメッセージをマーカーで指定されたロガーへinfoレベルでログを出力する。</p>
   *
   * @param marker マーカー
   * @param messageId メッセージID
   * @param arg 置換オブジェクト
   */
  void info(Marker marker, MessageIdEnum messageId, Object arg);

  /**
   * infoレベルログ出力
   *
   * <p>引数のメッセージIDに紐づくフォーマットおよび置換オブジェクトで生成したメッセージをマーカーで指定されたロガーへinfoレベルでログを出力する。</p>
   *
   * @param marker マーカー
   * @param messageId メッセージID
   * @param arg1 置換オブジェクト1
   * @param arg2 置換オブジェクト2
   */
  void info(Marker marker, MessageIdEnum messageId, Object arg1, Object arg2);

  /**
   * infoレベルログ出力
   *
   * <p>引数のメッセージIDに紐づくフォーマットおよび置換オブジェクトで生成したメッセージをマーカーで指定されたロガーへinfoレベルでログを出力する。</p>
   *
   * @param marker マーカー
   * @param messageId メッセージID
   * @param args 置換オブジェクトの配列
   */
  void info(Marker marker, MessageIdEnum messageId, Object... args);

  /**
   * warnレベルのロブ出力の可否判定
   *
   * <p>warnレベルのログ出力が可能な場合、{@code true}を不可の場合、{@code false}を返却する。</p>
   *
   * @return 出力可能な場合、{@code true}を不可の場合、{@code false}
   */
  boolean isWarnEnabled();

  /**
   * warnレベルのロブ出力の可否判定
   *
   * <p>warnレベルのログ出力が可能な場合、{@code true}を不可の場合、{@code false}を返却する。</p>
   *
   * @param marker マーカー
   * @return 出力可能な場合、{@code true}を不可の場合、{@code false}
   */
  boolean isWarnEnabled(Marker marker);

  /**
   * warnレベルログ出力
   *
   * <p>引数のメッセージをwarnレベルでログを出力する。</p>
   *
   * @param message メッセージ
   */
  void warn(String message);

  /**
   * warnレベルログ出力
   *
   * <p>引数のメッセージおよび例外・エラー情報をwarnレベルでログを出力する。</p>
   *
   * @param message メッセージ
   * @param throwable 何らかの例外・エラー
   */
  void warn(String message, Throwable throwable);

  /**
   * warnレベルログ出力
   *
   * <p>引数のメッセージIDに紐づくメッセージをwarnレベルでログを出力する。</p>
   *
   * @param messageId メッセージID
   */
  void warn(MessageIdEnum messageId);

  /**
   * warnレベルログ出力
   *
   * <p>引数のメッセージIDに紐づくフォーマットおよび置換オブジェクトで生成したメッセージをwarnレベルでログを出力する。</p>
   *
   * @param messageId メッセージID
   * @param arg 置換オブジェクト
   */
  void warn(MessageIdEnum messageId, Object arg);

  /**
   * warnレベルログ出力
   *
   * <p>引数のメッセージIDに紐づくフォーマットおよび置換オブジェクトで生成したメッセージをwarnレベルでログを出力する。</p>
   *
   * @param messageId メッセージID
   * @param arg1 置換オブジェクト1
   * @param arg2 置換オブジェクト2
   */
  void warn(MessageIdEnum messageId, Object arg1, Object arg2);

  /**
   * warnレベルログ出力
   *
   * <p>引数のメッセージIDに紐づくフォーマットおよび置換オブジェクトで生成したメッセージをwarnレベルでログを出力する。</p>
   *
   * @param messageId メッセージID
   * @param args 置換オブジェクトの配列
   */
  void warn(MessageIdEnum messageId, Object... args);

  /**
   * warnレベルログ出力
   *
   * <p>引数のメッセージをwarnレベルの指定されたマーカーでログを出力する。</p>
   *
   * @param marker マーカー
   * @param message メッセージ
   */
  void warn(Marker marker, String message);

  /**
   * warnレベルログ出力
   *
   * <p>引数のメッセージおよび例外・エラー情報をマーカーで指定されたロガーへwarnレベルでログを出力する。</p>
   *
   * @param marker マーカー
   * @param message メッセージ
   * @param throwable 何らかの例外・エラー
   */
  void warn(Marker marker, String message, Throwable throwable);

  /**
   * warnレベルログ出力
   *
   * <p>引数のメッセージIDに紐づくメッセージをマーカーで指定されたロガーへwarnレベルでログを出力する。</p>
   *
   * @param marker マーカー
   * @param messageId メッセージID
   */
  void warn(Marker marker, MessageIdEnum messageId);

  /**
   * warnレベルログ出力
   *
   * <p>引数のメッセージIDに紐づくフォーマットおよび置換オブジェクトで生成したメッセージをマーカーで指定されたロガーへwarnレベルでログを出力する。</p>
   *
   * @param marker マーカー
   * @param messageId メッセージID
   * @param arg 置換オブジェクト
   */
  void warn(Marker marker, MessageIdEnum messageId, Object arg);

  /**
   * warnレベルログ出力
   *
   * <p>引数のメッセージIDに紐づくフォーマットおよび置換オブジェクトで生成したメッセージをマーカーで指定されたロガーへwarnレベルでログを出力する。</p>
   *
   * @param marker マーカー
   * @param messageId メッセージID
   * @param arg1 置換オブジェクト1
   * @param arg2 置換オブジェクト2
   */
  void warn(Marker marker, MessageIdEnum messageId, Object arg1, Object arg2);

  /**
   * warnレベルログ出力
   *
   * <p>引数のメッセージIDに紐づくフォーマットおよび置換オブジェクトで生成したメッセージをマーカーで指定されたロガーへwarnレベルでログを出力する。</p>
   *
   * @param marker マーカー
   * @param messageId メッセージID
   * @param args 置換オブジェクトの配列
   */
  void warn(Marker marker, MessageIdEnum messageId, Object... args);

  /**
   * errorレベルのロブ出力の可否判定
   *
   * <p>errorレベルのログ出力が可能な場合、{@code true}を不可の場合、{@code false}を返却する。</p>
   *
   * @return 出力可能な場合、{@code true}を不可の場合、{@code false}
   */
  boolean isErrorEnabled();

  /**
   * errorレベルのロブ出力の可否判定
   *
   * <p>errorレベルのログ出力が可能な場合、{@code true}を不可の場合、{@code false}を返却する。</p>
   *
   * @param marker マーカー
   * @return 出力可能な場合、{@code true}を不可の場合、{@code false}
   */
  boolean isErrorEnabled(Marker marker);

  /**
   * errorレベルログ出力
   *
   * <p>引数のメッセージをerrorレベルでログを出力する。</p>
   *
   * @param message メッセージ
   */
  void error(String message);

  /**
   * errorレベルログ出力
   *
   * <p>引数のメッセージおよび例外・エラー情報をerrorレベルでログを出力する。</p>
   *
   * @param message メッセージ
   * @param throwable 何らかの例外・エラー
   */
  void error(String message, Throwable throwable);

  /**
   * errorレベルログ出力
   *
   * <p>引数のメッセージIDに紐づくメッセージをerrorレベルでログを出力する。</p>
   *
   * @param messageId メッセージID
   */
  void error(MessageIdEnum messageId);

  /**
   * errorレベルログ出力
   *
   * <p>引数のメッセージIDに紐づくフォーマットおよび置換オブジェクトで生成したメッセージをerrorレベルでログを出力する。</p>
   *
   * @param messageId メッセージID
   * @param arg 置換オブジェクト
   */
  void error(MessageIdEnum messageId, Object arg);

  /**
   * errorレベルログ出力
   *
   * <p>引数のメッセージIDに紐づくフォーマットおよび置換オブジェクトで生成したメッセージをerrorレベルでログを出力する。</p>
   *
   * @param messageId メッセージID
   * @param arg1 置換オブジェクト1
   * @param arg2 置換オブジェクト2
   */
  void error(MessageIdEnum messageId, Object arg1, Object arg2);

  /**
   * errorレベルログ出力
   *
   * <p>引数のメッセージIDに紐づくフォーマットおよび置換オブジェクトで生成したメッセージをerrorレベルでログを出力する。</p>
   *
   * @param messageId メッセージID
   * @param args 置換オブジェクトの配列
   */
  void error(MessageIdEnum messageId, Object... args);

  /**
   * errorレベルログ出力
   *
   * <p>引数のメッセージをerrorレベルの指定されたマーカーでログを出力する。</p>
   *
   * @param marker マーカー
   * @param message メッセージ
   */
  void error(Marker marker, String message);

  /**
   * errorレベルログ出力
   *
   * <p>引数のメッセージおよび例外・エラー情報をマーカーで指定されたロガーへerrorレベルでログを出力する。</p>
   *
   * @param marker マーカー
   * @param message メッセージ
   * @param throwable 何らかの例外・エラー
   */
  void error(Marker marker, String message, Throwable throwable);

  /**
   * errorレベルログ出力
   *
   * <p>引数のメッセージIDに紐づくメッセージをマーカーで指定されたロガーへerrorレベルでログを出力する。</p>
   *
   * @param marker マーカー
   * @param messageId メッセージID
   */
  void error(Marker marker, MessageIdEnum messageId);

  /**
   * errorレベルログ出力
   *
   * <p>引数のメッセージIDに紐づくフォーマットおよび置換オブジェクトで生成したメッセージをマーカーで指定されたロガーへerrorレベルでログを出力する。</p>
   *
   * @param marker マーカー
   * @param messageId メッセージID
   * @param arg 置換オブジェクト
   */
  void error(Marker marker, MessageIdEnum messageId, Object arg);

  /**
   * errorレベルログ出力
   *
   * <p>引数のメッセージIDに紐づくフォーマットおよび置換オブジェクトで生成したメッセージをマーカーで指定されたロガーへerrorレベルでログを出力する。</p>
   *
   * @param marker マーカー
   * @param messageId メッセージID
   * @param arg1 置換オブジェクト1
   * @param arg2 置換オブジェクト2
   */
  void error(Marker marker, MessageIdEnum messageId, Object arg1, Object arg2);

  /**
   * errorレベルログ出力
   *
   * <p>引数のメッセージIDに紐づくフォーマットおよび置換オブジェクトで生成したメッセージをマーカーで指定されたロガーへerrorレベルでログを出力する。</p>
   *
   * @param marker マーカー
   * @param messageId メッセージID
   * @param args 置換オブジェクトの配列
   */
  void error(Marker marker, MessageIdEnum messageId, Object... args);
}
