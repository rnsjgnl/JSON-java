/*
 * @(#)MessageIdEnum.java
 *
 * Copyright (C) 2019, Japan Housing Finance Agency.
 */
package hui.quan.ult.nohin.common.core.constants;

/**
 * メッセージインタフェース
 *
 * @author HS
 */
public interface MessageIdEnum {

  /**
   * メッセージID取得。
   *
   * @return メッセージID
   */
  String getId();

  /**
   * メッセージレベル取得
   *
   * @return メッセージレベル
   */
 default String getLevel() {
    return getId().substring(getId().length() - 1);
  }
}
