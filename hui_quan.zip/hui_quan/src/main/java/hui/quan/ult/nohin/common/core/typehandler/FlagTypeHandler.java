/*
 * @(#)FlagTypeHandler.java
 *
 * Copyright (C) 2019, Japan Housing Finance Agency.
 */
package hui.quan.ult.nohin.common.core.typehandler;

import java.sql.CallableStatement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.ibatis.type.BaseTypeHandler;
import org.apache.ibatis.type.JdbcType;
import org.apache.ibatis.type.MappedJdbcTypes;
import org.apache.ibatis.type.MappedTypes;

import hui.quan.ult.nohin.common.core.logger.Logger;
import hui.quan.ult.nohin.common.core.logger.LoggerFactory;



/**
 * フラグ（VARCHAR）、Booleanタイプハンドラ
 *
 * @author HS
 */
@MappedJdbcTypes(value = JdbcType.VARCHAR, includeNullJdbcType = true)
@MappedTypes(value = {Boolean.class, boolean.class})
public class FlagTypeHandler extends BaseTypeHandler<Boolean> {

  /** フラグオン */
  private static final String FLAG_ON = "1";

  /** フラグオフ */
  private static final String FLAG_OFF = "0";

  /** ロガー */
  private final Logger logger = LoggerFactory.getLogger(FlagTypeHandler.class);

  /**
   * 結果取得
   *
   * @param rs 結果セット
   * @param columnName カラム名
   * @return DB取得値
   * @throws SQLException 何らかのSQL例外
   */
  @Override
  public Boolean getNullableResult(ResultSet rs, String columnName) throws SQLException {
    return toBoolean(rs.getString(columnName));
  }

  /**
   * 結果取得
   *
   * @param rs 結果セット
   * @param columnIndex カラムインデックス
   * @return DB取得値
   * @throws SQLException 何らかのSQL例外
   */
  @Override
  public Boolean getNullableResult(ResultSet rs, int columnIndex) throws SQLException {
    return toBoolean(rs.getString(columnIndex));
  }

  /**
   * 結果取得
   *
   * @param cs コーラブルステートメント
   * @param columnIndex カラムインデックス
   * @return DB取得値
   * @throws SQLException 何らかのSQL例外
   */
  @Override
  public Boolean getNullableResult(CallableStatement cs, int columnIndex) throws SQLException {
    return toBoolean(cs.getString(columnIndex));
  }

  /**
   * パラメータ設定
   *
   * @param ps プリペアドステートメント
   * @param parameterIndex パラメータインデックス
   * @param parameter パラメータ
   * @param jdbcType JDBCタイプ
   * @throws SQLException なんらかのSQL例外
   */
  @Override
  public void setNonNullParameter(PreparedStatement ps, int parameterIndex,
      Boolean parameter, JdbcType jdbcType) throws SQLException {
    if (logger.isDebugEnabled()) {
      logger.debug("parameterIndex=" + parameterIndex);
    }
    ps.setString(parameterIndex, toFlag(parameter));
  }

  /**
   * Booleanフラグ変換
   *
   * @param value 真偽値
   * @return 真偽値が{@code true} の場合"1"、それ以外の場合"0"
   */
  private String toFlag(Boolean value) {
    if (value == null) {
      return null;
    } else if (value.booleanValue()) {
      return FLAG_ON;
    } else {
      return FLAG_OFF;
    }
  }

  /**
   * フラグBoolean変換
   *
   * @param value 真偽値
   * @return 真偽値が{@code true} の場合"1"、それ以外の場合"0"
   */
  private Boolean toBoolean(String value) {
    if (value == null) {
      return null;
    } else {
      return Boolean.valueOf(FLAG_ON.equals(value));
    }
  }
}
