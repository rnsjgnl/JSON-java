/*
 * @(#)BatchOutputVO.java
 *
 * Copyright (C) 2019, Japan Housing Finance Agency.
 */
package hui.quan.ult.nohin.vo;

import java.io.Serializable;
import java.util.List;

import hui.quan.ult.nohin.common.code.SyoriKekkaEnum;
import hui.quan.ult.nohin.common.core.logger.Logger;
import hui.quan.ult.nohin.common.core.logger.LoggerFactory;
import lombok.Getter;
import lombok.Setter;



/**
 * バッチ出力VO
 *
 * @author HS
 */
@Setter
@Getter
public class BatchOutputVO implements Serializable {

  /** シリアルバージョンUID */
  private static final long serialVersionUID = 7849474005012674780L;

  /** ロガー */
  private final Logger logger = LoggerFactory.getLogger(BatchOutputVO.class);

  /** 処理結果Enum */
  private SyoriKekkaEnum syoriKekkaEnum;

  /** エラーリスト */
  private List<?> errorList;

  /**
   * 処理結果Enum設定
   *
   * @param syoriKekkaEnum 処理結果Enum
   */
  public void setSyoriKekkaEnum(SyoriKekkaEnum syoriKekkaEnum) {
    this.syoriKekkaEnum = syoriKekkaEnum;
    if (this.syoriKekkaEnum == SyoriKekkaEnum.ABNORMAL) {
      if (logger.isInfoEnabled()) {
        logger.info("異常終了 at " + Thread.currentThread().getStackTrace()[2].toString());
      }
    }
  }
}
