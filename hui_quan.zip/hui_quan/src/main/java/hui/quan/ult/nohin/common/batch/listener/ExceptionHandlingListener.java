/*
 * @(#)ExceptionHandlingListener.java
 *
 * Copyright (C) 2019, Japan Housing Finance Agency.
 */
package hui.quan.ult.nohin.common.batch.listener;

import java.time.LocalDate;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.JobParameter;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;

import hui.quan.ult.nohin.common.core.context.Profile;



/**
 * ステップリスナー
 *
 * @author HS
 */
public class ExceptionHandlingListener implements StepExecutionListener {

  /** MDC用ジョブIDキー */
  private static final String MDC_JOB_ID = "jobId";

  /** MDC用運用日付キー */
  private static final String MDC_EXECUTION_ID = "executionId";

  /** 終了コード（正常終了） */
  private static final String SUCCESS = "0";

  /** 終了コード（異常終了） */
  private static final String FAILURE = "100";

  /** ロガー */
  private final Logger logger = LoggerFactory.getLogger(ExceptionHandlingListener.class);

  /**
   * 事前処理
   *
   * @param stepExecution ステップ実行情報
   */
  @Override
  public void beforeStep(StepExecution stepExecution) {

    LocalDate syoriYmd = LocalDate.now();
    Profile.initialize(
        stepExecution.getJobExecution().getJobInstance().getJobName(),
        syoriYmd,
        null);

    MDC.put(MDC_JOB_ID, stepExecution.getJobExecution().getJobInstance().getJobName());
    MDC.put(MDC_EXECUTION_ID, getExecutionId(stepExecution));

    if (logger.isInfoEnabled()) {
      logger.info("開始" + getParameterMessage(stepExecution.getJobExecution().getJobParameters()));
    }

  }

  /**
   * ジョブ実行ID取得
   *
   * @param stepExecution ステップ実行情報
   * @return ジョブ実行ID
   */
  private static String getExecutionId(StepExecution stepExecution) {
    return String.format("%016x",
        stepExecution.getJobExecution().getJobParameters().getLong("jsr_batch_run_id").longValue());
  }

  /**
   * 後処理
   *
   * @param stepExecution ステップ実行情報
   * @return 終了状態
   */
  @Override
  public ExitStatus afterStep(StepExecution stepExecution) {

    if (!stepExecution.getFailureExceptions().isEmpty()) {
      if (logger.isErrorEnabled()) {
        logger.error(getParameterMessage(stepExecution.getJobExecution().getJobParameters()));
        stepExecution.getFailureExceptions().stream()
          .filter(e -> e instanceof Exception)
          .forEach(e -> logger.error(e.getClass().getName(), e));
      }
    }

    if (logger.isInfoEnabled()) {
      logger.info("終了 exit=" + convert(stepExecution.getExitStatus()));
    }

    Profile.clear();
    MDC.remove(MDC_JOB_ID);

    return stepExecution.getExitStatus();
  }

  /**
   * 終了コード変換
   *
   * <p>終了ステータスより終了コードへ変換する。</p>
   *
   * @param exitStatus  終了ステータス
   * @return 終了コード
   */
  public String convert(ExitStatus exitStatus) {
    if (ExitStatus.COMPLETED.equals(exitStatus)
        || ExitStatus.NOOP.equals(exitStatus)) {
      return SUCCESS;
    } else {
      return FAILURE;
    }
  }

  /**
   * パラメータ情報取得
   *
   * @param jobParameters ジョブパラメータ
   * @return パラメータ情報
   */
  private String getParameterMessage(JobParameters jobParameters) {
    StringBuilder result = new StringBuilder("params={");
    Map<String, JobParameter> parameters = jobParameters.getParameters();
    parameters.keySet().stream()
        .forEach(k -> result.append(
          getParameterKeyValues(k, parameters.get(k))).append(","));
    result.deleteCharAt(result.length() - 1).append("}");
    return result.toString();
  }

  /**
   * パラメータの文字列表現取得
   *
   * @param key パラメータキー
   * @param jobParameter ジョブパラメータ
   * @return パラメータの文字列表現
   */
  private String getParameterKeyValues(String key, JobParameter jobParameter) {
    return new StringBuilder(key).append("=").append(jobParameter.getValue()).toString();
  }
}
