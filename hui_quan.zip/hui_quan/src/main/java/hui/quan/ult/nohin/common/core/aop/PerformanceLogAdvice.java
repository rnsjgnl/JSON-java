/*
 * @(#)PerformanceLogAdvice.java
 *
 * Copyright (C) 2019, Japan Housing Finance Agency.
 */
package hui.quan.ult.nohin.common.core.aop;

import java.time.LocalDateTime;
import java.time.temporal.ChronoField;
import java.time.temporal.ChronoUnit;

import org.aspectj.lang.ProceedingJoinPoint;

import hui.quan.ult.nohin.common.core.logger.Logger;
import hui.quan.ult.nohin.common.core.logger.LoggerFactory;



/**
 * 性能ログ出力アドバイス
 *
 * @author HS
 */
public class PerformanceLogAdvice {

  /** パッケージプレフィックス */
  private static final String PACKAGE_PREFIX = "hui.quan.";

  /** 出力フォーマット */
  private static final String FORMAT =
      "%s.%s() %02d:%02d:%02d.%03d - %02d:%02d:%02d.%03d (%d.%03dsec.)";

  /** ロガー */
  private final Logger logger = LoggerFactory.getLogger("hui.quan.nohin.performance");

  /**
   * メソッド実行
   *
   * @param joinPoint ジョインポイント
   * @return 実行結果
   * @throws Throwable 何らかの例外
   */
  public Object measure(ProceedingJoinPoint joinPoint) throws Throwable {

    LocalDateTime s = LocalDateTime.now();

    Object result = joinPoint.proceed();

    LocalDateTime e = LocalDateTime.now();

    long d = s.until(e, ChronoUnit.MILLIS);

    String className = joinPoint.getTarget().getClass().getName();
    if (!className.startsWith(PACKAGE_PREFIX)) {
      className = joinPoint.getSignature().getDeclaringTypeName();
    }

    if (logger.isInfoEnabled()) {
      logger.info(
          String.format(FORMAT,
              className,
              joinPoint.getSignature().getName(),
              s.get(ChronoField.HOUR_OF_DAY),
              s.get(ChronoField.MINUTE_OF_HOUR),
              s.get(ChronoField.SECOND_OF_MINUTE),
              s.get(ChronoField.MILLI_OF_SECOND),
              e.get(ChronoField.HOUR_OF_DAY),
              e.get(ChronoField.MINUTE_OF_HOUR),
              e.get(ChronoField.SECOND_OF_MINUTE),
              e.get(ChronoField.MILLI_OF_SECOND),
              d / 1000L,
              d % 1000L));
    }
    return result;
  }
}
