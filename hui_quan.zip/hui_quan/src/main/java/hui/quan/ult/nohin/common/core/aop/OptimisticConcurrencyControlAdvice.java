/*
 * @(#)OptimisticConcurrencyControlAdvice.java
 *
 * Copyright (C) 2019, Japan Housing Finance Agency.
 */
package hui.quan.ult.nohin.common.core.aop;

import org.springframework.dao.DuplicateKeyException;

import hui.quan.ult.nohin.common.core.exception.ConcurrencyControlException;



/**
 * 楽観排他制御アドバイス
 *
 * @author HS
 */
public class OptimisticConcurrencyControlAdvice {

  /**
   * insert楽観排他制御アドバイス
   *
   * @param exception 何らかの例外
   */
  public void insert(Exception exception) {
    if (exception instanceof DuplicateKeyException) {
      throw new ConcurrencyControlException(exception);
    }
  }

  /**
   * update楽観排他制御アドバイス
   *
   * @param result 処理結果
   */
  public void update(int result) {
    if (result != 1) {
      throw new ConcurrencyControlException();
    }
  }

  /**
   * delete楽観排他制御アドバイス
   *
   * @param result 処理結果
   */
  public void delete(int result) {
    if (result != 1) {
      throw new ConcurrencyControlException();
    }
  }
}
