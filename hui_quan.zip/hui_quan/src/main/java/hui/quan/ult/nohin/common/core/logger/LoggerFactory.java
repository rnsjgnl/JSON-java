/*
 * @(#)LoggerFactory.java
 *
 * Copyright (C) 2019, Japan Housing Finance Agency.
 */
package hui.quan.ult.nohin.common.core.logger;

import java.util.ResourceBundle;

/**
 * ロガー生成クラス。
 *
 * @author HS
 */
public final class LoggerFactory {

  /** リソースバンドル名 */
  private static final String BUNDLE_NAME = "Messages";

  /** リソースバンドル */
  private static ResourceBundle bundle = ResourceBundle.getBundle(BUNDLE_NAME);

  /**
   * インスタンス化抑止コンストラクタ
   */
  private LoggerFactory() {
  }

  /**
   * ロガー取得。
   *
   * @param clazz ロガークラス
   * @return ロガー
   */
  public static Logger getLogger(Class<?> clazz) {
    return new LoggerImpl(clazz, bundle);
  }

  /**
   * ロガー取得。
   *
   * @param name ロガー名
   * @return ロガー
   */
  public static Logger getLogger(String name) {
    return new LoggerImpl(name, bundle);
  }
}
