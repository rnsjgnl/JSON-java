/*
 * @(#)ErrorVO.java
 *
 * Copyright (C) 2019, Japan Housing Finance Agency.
 */
package hui.quan.ult.nohin.vo;

import java.io.Serializable;

import lombok.Data;

/**
 * エラーVO
 *
 * @author HS
 */
@Data
public final class ErrorVO implements Serializable {

  /** シリアルバージョンUID */
  private static final long serialVersionUID = 1L;

  /** メッセージコード */
  private String messageId;
  /** メッセージ内容 */
  private String messageContent;
  /** エラー種別 */
  private String errorKbn;
  /** バインドパラメータ */
  private String[] args;

  /**
   * コンストラクタ
   *
   * @param messageId メッセージID
   * @param errorKbn エラー区分
   */
  private ErrorVO(String messageId, String errorKbn) {
    this.messageId = messageId;
    this.errorKbn = errorKbn;
  }

  /**
   * コンストラクタ
   *
   * @param messageId メッセージID
   * @param errorKbn エラー区分
   * @param args パラメータ
   */
  private ErrorVO(String messageId, String errorKbn, String[] args) {
    this.messageId = messageId;
    this.errorKbn = errorKbn;
    this.args = args;
  }

  /**
   * エラーVO取得
   *
   * @param id メッセージID
   * @param kbn エラー区分
   * @return エラーVO
   */
  public static ErrorVO getErrorVO(String id, String kbn) {
    return new ErrorVO(id, kbn);
  }

  /**
   * エラーVO取得
   *
   * @param id メッセージID
   * @param kbn エラー区分
   * @param args パラメータ
   * @return エラーVO
   */
  public static ErrorVO getErrorVO(String id, String kbn, String[] args) {
    return new ErrorVO(id, kbn, args);
  }

  /**
   * エラーVO作成（IDと名称）
   *
   * @param id エラーID
   * @param value エラー名称
   * @return エラーVO
   */
  public static ErrorVO getErrorVOByIdValue(String id, String value) {
    ErrorVO errorVO = new ErrorVO(id, id.substring(id.length() - 1));
    errorVO.messageContent=value;//setMessageContent(value);
    return errorVO;
  }

}
