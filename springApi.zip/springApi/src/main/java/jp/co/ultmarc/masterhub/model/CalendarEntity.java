package jp.co.ultmarc.masterhub.model;

import lombok.Getter;
import lombok.Setter;

/**
 * カレンダーEntity
 *
 * @author 権
 *
 */
@Setter
@Getter
public class CalendarEntity {

	/**
	 * 年月日
	 */
	private String ymdDate;

	/**
	 * 営業日取消フラグ
	 */
	private String eigyobiTorikeshiFlg;

	/**
	 * 週締め日フラグ
	 */
	private String shuShimebiFlg;

	/**
	 * 中締め日フラグ
	 */
	private String nakaShimebiFlg;

	/**
	 * 末締め日フラグ
	 */
	private String matsuShimebiFlg;

	/**
	 * 臨床研修病院フラグ
	 */
	private String rnsknsByoinFlg;

	/**
	 * 町字フラグ
	 */
	private String machiazaFlg;

	/**
	 * 登録者
	 */
	private String registUserId;

	/**
	 * 更新者
	 */
	private String updateUserId;

	/**
	 * 登録日付
	 */
	private String registDate;

	/**
	 * 更新日付
	 */
	private String updateDate;

	/**
	 * 削除フラグ
	 */
	private String delFlg;

	/**
	 * sfdc_id
	 */
	private String sfdcId;
}
