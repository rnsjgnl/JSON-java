package jp.co.ultmarc.masterhub.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import jp.co.ultmarc.masterhub.dao.MasterhubDAO;
import jp.co.ultmarc.masterhub.model.AccountEntity;
import jp.co.ultmarc.masterhub.model.CalendarEntity;
import jp.co.ultmarc.masterhub.model.ContactEntity;
import jp.co.ultmarc.masterhub.model.HinMokuEntity;
import jp.co.ultmarc.masterhub.model.NohinSetEntity;
import jp.co.ultmarc.masterhub.model.NohinSetItemEntity;
import jp.co.ultmarc.masterhub.model.VANUserEntity;
import jp.co.ultmarc.masterhub.service.IMasterhubService;

@Service
public class MasterhubServiceImpl implements IMasterhubService {

	 	@Resource
	    private MasterhubDAO masterhubDAO;

	 	@Override
	    public List<CalendarEntity> calendarSelect(String id) {
	        return masterhubDAO.calendarSelect(id);
	    }

	 	@Override
	    public List<VANUserEntity> VANSelect(String id) {
	        return masterhubDAO.VANSelect(id);
	    }
	 	@Override
	    public List<CalendarEntity> DRMSelect(String id) {
	        return masterhubDAO.calendarSelect(id);
	    }

		@Override
		public List<NohinSetEntity> NohinSetSelect(String id) {
			return masterhubDAO.NohinSetSelect(id);
		}

		@Override
		public List<NohinSetItemEntity> NohinSetItemSelect(String id) {
			return masterhubDAO.NohinSetItemSelect(id);
		}

		@Override
		public List<HinMokuEntity> HinMokuSelect(String id) {
			return masterhubDAO.HinMokuSelect(id);
		}

		@Override
		public List<ContactEntity> ContactSelect(String id) {
			return masterhubDAO.ContactSelect(id);
		}

		@Override
		public List<AccountEntity> AccountSelect(String id) {
			return masterhubDAO.AccountSelect(id);
		}

}
