package jp.co.ultmarc.masterhub.model;

import lombok.Getter;
import lombok.Setter;

/**
 * 納品セット内訳Entity
 *
 * @author 権
 *
 */
@Setter
@Getter
public class NohinSetItemEntity {

}
