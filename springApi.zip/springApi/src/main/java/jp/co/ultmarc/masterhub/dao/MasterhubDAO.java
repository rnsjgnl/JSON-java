package jp.co.ultmarc.masterhub.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import jp.co.ultmarc.masterhub.model.AccountEntity;
import jp.co.ultmarc.masterhub.model.CalendarEntity;
import jp.co.ultmarc.masterhub.model.ContactEntity;
import jp.co.ultmarc.masterhub.model.DRMUserEntity;
import jp.co.ultmarc.masterhub.model.HinMokuEntity;
import jp.co.ultmarc.masterhub.model.NohinSetEntity;
import jp.co.ultmarc.masterhub.model.NohinSetItemEntity;
import jp.co.ultmarc.masterhub.model.VANUserEntity;

public interface  MasterhubDAO {
	  /**
	   * 取得(カレンダー)
	   *
	   *
	   * @return カレンダーEntityリスト
	   */
	  List<CalendarEntity> calendarSelect(@Param("id")String id);

	  /**
	   * 取得(VAN)
	   *
	   *
	   * @return VANユーザEntityリスト
	   */
	  List<VANUserEntity> VANSelect(@Param("id")String id);

	  /**
	   * 取得
	   *
	   *
	   * @return DRMユーザEntityリスト
	   */
	  List<DRMUserEntity> DRMSelect(@Param("id")String id);

	  /**
	   * 取得
	   *
	   *
	   * @return 納品セットEntityリスト
	   */
	  List<NohinSetEntity> NohinSetSelect(@Param("id")String id);

	  /**
	   * 取得
	   *
	   *
	   * @return 納品セット内訳Entityリスト
	   */
	  List<NohinSetItemEntity> NohinSetItemSelect(@Param("id")String id);

	  /**
	   * 取得
	   *
	   *
	   * @return 年間契約品目Entityリスト
	   */
	  List<HinMokuEntity> HinMokuSelect(@Param("id")String id);

	  /**
	   * 取得
	   *
	   *
	   * @return 取引先責任者Entityリスト
	   */
	  List<ContactEntity> ContactSelect(@Param("id")String id);

	  /**
	   * 取得
	   *
	   *
	   * @return 取引先Entityリスト
	   */
	  List<AccountEntity> AccountSelect(@Param("id")String id);
}
