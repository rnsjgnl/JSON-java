package jp.co.ultmarc.masterhub.model;

import lombok.Getter;
import lombok.Setter;

/**
 * 年間契約品目Entity
 *
 * @author 権
 *
 */
@Setter
@Getter
public class HinMokuEntity {

}
