package jp.co.ultmarc.masterhub.service;

import java.util.List;

import jp.co.ultmarc.masterhub.model.AccountEntity;
import jp.co.ultmarc.masterhub.model.CalendarEntity;
import jp.co.ultmarc.masterhub.model.ContactEntity;
import jp.co.ultmarc.masterhub.model.HinMokuEntity;
import jp.co.ultmarc.masterhub.model.NohinSetEntity;
import jp.co.ultmarc.masterhub.model.NohinSetItemEntity;
import jp.co.ultmarc.masterhub.model.VANUserEntity;


public interface IMasterhubService {

	/**
	 * カレンダーデータ取得
	 *
	 * @return
	 */
	public List<CalendarEntity> calendarSelect(String id);

	/**
	 * VANユーザデータ取得
	 * @return
	 */
	public List<VANUserEntity> VANSelect(String id);

	/**
	 * DRMユーザデータ取得
	 * @return
	 */
	public List<CalendarEntity> DRMSelect(String id);

	/**
	 * 納品セットデータ取得
	 * @return
	 */
	public List<NohinSetEntity> NohinSetSelect(String id);

	/**
	 * 納品セット内訳データ取得
	 * @return
	 */
	public List<NohinSetItemEntity> NohinSetItemSelect(String id);

	/**
	 * 年間契約品目データ取得
	 * @return
	 */
	public List<HinMokuEntity> HinMokuSelect(String id);

	/**
	 * 取引先責任者データ取得
	 * @return
	 */
	public List<ContactEntity> ContactSelect(String id);

	/**
	 * DRMユーザデータ取得
	 * @return
	 */
	public List<AccountEntity> AccountSelect(String id);

}
