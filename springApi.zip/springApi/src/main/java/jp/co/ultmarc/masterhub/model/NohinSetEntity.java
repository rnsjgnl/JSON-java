package jp.co.ultmarc.masterhub.model;

import lombok.Getter;
import lombok.Setter;

/**
 * 納品セットEntity
 *
 * @author 権
 *
 */
@Setter
@Getter
public class NohinSetEntity {

}
