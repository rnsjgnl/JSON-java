package jp.co.ultmarc.masterhub.model;

import lombok.Getter;
import lombok.Setter;

/**
 * DRMユーザEntity
 *
 * @author 権
 *
 */
@Setter
@Getter
public class DRMUserEntity {

}
