package jp.co.ultmarc.masterhub.model;

import java.util.Date;

import lombok.Getter;
import lombok.Setter;

/**
 * 取引先Entity
 *
 * @author 権
 *
 */
@Setter
@Getter
public class AccountEntity {

	private String tkiId;

    private String deleteFlg;

    private String masterRecordId;

    private String tkiNm;

    private String tkiMyoji;

    private String tkiNamae;

    private String keisyo;

    private String tkiSyubetu;

    private String recordType;

    private String oyaTkiCd;

    private String seikyusakiChomei;

    private String seikyusakiShiku;

    private String seikyusakiTodofuken;

    private String seikyusakiYubin;

    private String seikyusakiKuni;

    private String nonyusakiChomei;

    private String nonyusakiShiku;

    private String nonyusakiTodofuken;

    private String nonyusakiYubin;

    private String nonyusakiKuni;

    private String tel;

    private String fax;

    private String tkiNo;

    private String website;

    private String sangyoCd;

    private String gyoshu;

    private Long annualrevenue;

    private Integer numberofemployees;

    private String ownership;

    private String tickersymbol;

    private String description;

    private String rating;

    private String site;

    private String ownerid;

    private Date createddate;

    private String createdbyid;

    private Date lastmodifieddate;

    private String lastmodifiedbyid;

    private Date systemmodstamp;

    private Date lastactivitydate;

    private String ispartner;

    private String personcontactid;

    private String ispersonaccount;

    private String personmailingstreet;

    private String personmailingcity;

    private String personmailingstate;

    private String personmailingpostalcode;

    private String personmailingcountry;

    private String personotherstreet;

    private String personothercity;

    private String personotherstate;

    private String personotherpostalcode;

    private String personothercountry;

    private String personmobilephone;

    private String personhomephone;

    private String personotherphone;

    private String personassistantphone;

    private String personemail;

    private String persontitle;

    private String persondepartment;

    private String personassistantname;

    private String personleadsource;

    private Date personbirthdate;

    private String personhasoptedoutofemail;

    private Date personlastcurequestdate;

    private Date personlastcuupdatedate;

    private String personemailbouncedreason;

    private Date personemailbounceddate;

    private String entyouStatuw;

    private String entyouMemo;

    private String kobai;

    private String naishiGaishi;

    private Date entyouHiduke;

    private String mrsalesqty;

    private String credensial;

    private Long entyouKeika;

    private String entyouBikou;

    private String shortname;

    private String mdbTanto;

    private String entyouTuki;

    private String x1StandardData;

    private String x1StandardEigyouNouki;

    private String x1StandardAgencyNouki;

    private String x1StandardTouroku;

    private String x2StandardData;

    private String x2StandardEigyouNouki;

    private String x2StandardAgencyNouki;

    private String x2StandardTouroku;

    private String x3StandardData;

    private String x3StandardEigyouNouki;

    private String x3StandardAgencyNouki;

    private String x3StandardTouroku;

    private String enqueteFrom;

    private String enqueteTo;

    private String enqueteResultNouki;

    private String receiptDesignRequestStandard;

    private String receiptDesignDecisionStandard;

    private String resultNouhinFinal;

    private String resultNouhin1;

    private String xlStandardTourku;

    private String xlStandardData;

    private String xlStandardJyuryou;

    private String ticketDesignRequestStandard;

    private String ticketDesignDecisionStandard;

    private String memo;

    private String houmeiDesignRequestStandard;

    private String houmeiDesignDecisionStandard;

    private String coKana;

    private Date hidukeMr;

    private String tkiCd;

    private String annualrevenueSeazon;

    private String tkiOuNm;

    private String areaNm;

    private String sendKbn;

    private String koukaiKbn;

    private Date trhkSYmd;

    private Date delYmd;

    private String kaiinKbn;

    private String hokatsuKbn;

    private String cdbKbn;

    private String mdgcKbn;

    private String sefKbn;

    private String c3Kbn;

    private String mdbmokuteki;

    private String riyoumokutekiHoka;

    private String seiyakukyou;

    private String nitiyaku;

    private String kousinMemo;

    private String kousinduki;

    private Date kousinHiduke;

    private String kaiteiStatus;

    private String ball;

    private Long keikanissuu;

    private String keiyakubikou;

    private String kyoudouUrl;

    private String kyoudouMune;

    private String kyoudouJitaku;

    private String parenttkiCd;

    private String bizcardid;

    private String isdigitizing;

    private String mdbGiketu;

    private String sfidOriginal;

    private String mdbmemberinchargeofaccount;

    private String parentaccountofcomprehensivecontract;

    private String parentcustomertext;

    private String parentofcomprehensivecontractflag;

    private String parentofcomprehensivecontractforsearch;

    private String esguidedeliveryexclusion;

    private String currentcontractitem;

    private String dcfforoutput;

    private String dsfforoutput;

    private String esguideassignpersonnel;

    private String flowacquisitiondata;

    private String pcfforoutput;

    private String dcffacility;

    private String dcf;

    private String dnf;

    private String dsf;

    private String ecf;

    private String kgf;

    private String pcf;

    private String van;

    private String dcffacilityforoutput;

    private String dnfforoutput;

    private String ecfforoutput;

    private String kgfforoutput;

    private String vanforoutput;

    private String parentcomprehensivetkiCd;

    private String dailyvan;

    private String dailyvanforoutput;

    private String syousyuBunrui;

    private String gyoshuMainCd;

    private String gyoshuNewCd;

    private String accessTkiMemo;

    private String accountinvalidationformula;

    private String tkiMemo;

    private Date beforevalsetdate;

    private String beforevaloperation;

    private String faxbeforeval;

    private String websitebeforeval;

    private String sitebeforeval;

    private String shippingcitybeforeval;

    private String shippingstreetbeforeval;

    private String shippingstatebeforeval;

    private String shippingpostalcodebeforeval;

    private String phonebeforeval;

    private String chushutsuKbn;

    private Date keiyakuYmd;

    private Date kaiyakuYmd;

    private String chushutsuJohoTodofuken;

    private String chushutsuJohoShiKbn;

    private String chushutsuJohoShinryokamoku;

    private String chushutsuJohoShinryokamokuDaikbn;
	}
