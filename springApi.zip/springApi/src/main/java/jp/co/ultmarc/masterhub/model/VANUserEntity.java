package jp.co.ultmarc.masterhub.model;

import lombok.Getter;
import lombok.Setter;

/**
 * VANユーザEntity
 *
 * @author 権
 *
 */
@Setter
@Getter
public class VANUserEntity {

	/**
	 * VANユーザID番号
	 */
	private String vanUseridNo;

	/**
	 * 得意先コード
	 */
	private String tkiCd;

	/**
	 * VANユーザID
	 */
	private String vanUserid;

	/**
	 * 全銀接続形態区分
	 */
	private String zenginSetsuzokukeitaiKbn;

	/**
	 * VANパスワード
	 */
	private String vanPassword;

	/**
	 * ユーザセンタ確認コード
	 */
	private String userCenterKakuninCd;

	/**
	 * 社内センタ確認コード
	 */
	private String ultCenterKakuninCd;

	/**
	 * 全銀協標準プロトコル区分
	 */
	private String zenginkyoHyojunProtocolKbn;

	/**
	 * EINSユーザID
	 */
	private String einsUserid;

	/**
	 * EINSパスワード
	 */
	private String einsPassword;

	/**
	 * 定例VAN受信時間
	 */
	private String teireiVanIushintime;

	/**
	 * 備考コメント
	 */
	private String bikoComments;

	/**
	 * 登録者
	 */
	private String registUserId;

	/**
	 * 更新者
	 */
	private String updateUserId;

	/**
	 * 登録日付
	 */
	private String registDate;

	/**
	 * 更新日付
	 */
	private String updateDate;

	/**
	 * 削除フラグ
	 */
	private String delFlg;

	/**
	 * sfdc_id
	 */
	private String sfdcId;


}
