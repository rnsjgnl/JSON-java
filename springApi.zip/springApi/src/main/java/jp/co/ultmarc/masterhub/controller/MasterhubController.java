package jp.co.ultmarc.masterhub.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.BoundHashOperations;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ValueOperations;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import jp.co.ultmarc.masterhub.common.RedisCacheManager;
import jp.co.ultmarc.masterhub.common.constants.tableNmEnum;
import jp.co.ultmarc.masterhub.service.IMasterhubService;


@RestController
@RequestMapping("/masterhub")
public class MasterhubController {

    private static final Logger log = LoggerFactory.getLogger(MasterhubController.class);
    @Autowired
    private RedisTemplate<String, Object> redisTemplate;
    //データカウント名
    private static final String dataCnt ="count";
    //データリスト名
    private static final String dataList ="list";
        @Resource
        private IMasterhubService masterhubService;

        @SuppressWarnings("unchecked")
        @RequestMapping("/index_api")
        //@ResponseBody
        public <T> Map<String,Object> Index(HttpServletRequest request,Model model) throws Exception {

            //検索必要table
            String table = request.getParameter("table");
            //検索必要カラムID
            String id = request.getParameter("id");
            //初期化
            List<T> list = null;
            Map<String,Object> map = new HashMap<String,Object>();


            switch(tableNmEnum.valueOf(table)) {

            //DRMユーザ
            case DRMAccount:
                list = (List<T>) this.masterhubService.DRMSelect(id);
                break;
            //カレンダー
            case Calendar:
                list = (List<T>) this.masterhubService.calendarSelect(id);
                break;
            //VANユーザ
            case VANAccount:
                list = (List<T>) this.masterhubService.VANSelect(id);
                break;

            //取引先
            case Account:
                list = (List<T>) this.masterhubService.AccountSelect(id);
                break;
            default:
                log.error("エラー発生しました。");
                log.error("Parameter[table]:"+table);
                log.error("Parameter[id]:"+id);
                throw new Exception();
            }

            //取得データ数
            map.put(dataCnt, list.size());

            //取得データリスト
            map.put(dataList, list);



            log.info("正常処理しました。");

            return map;
        }

        @SuppressWarnings("unchecked")
        @RequestMapping("/index_apiTest")
        public <T> String IndexTest(HttpServletRequest request,Model model) throws Exception {

            /*
            RedisCacheManager redisCacheManager = new RedisCacheManager();
            redisCacheManager.setRedisTemplate(redisTemplate);

            boolean setFlg = redisCacheManager.set("aaa", "sssss");
            Object aaaa = redisCacheManager.get("aaa");

            */
            /* 削除
            Set<String> keysList = redisTemplate.keys("*");

            for(String str :keysList) {
                redisCacheManager.del(str);
            }

            //批量查询
            List<Object> strings = redisTemplate.opsForValue().multiGet(keysList);

            */

            RedisCacheManager redisCacheManager = new RedisCacheManager();
             redisCacheManager.setRedisTemplate(redisTemplate);

            Set<String> keysList = redisTemplate.keys("account_*");

            List<String> listTest = new ArrayList<String>();
            StringBuilder sb = new StringBuilder();
            for(String str :keysList) {
                String value = redisCacheManager.get(str).toString();
                listTest.add(value);
              //  boundHashOperations.values().forEach(v -> System.out.println("获取map中的value值" + v));
              //  boundHashOperations.entries().forEach((m,n) -> System.out.println("获取map键值对:" + m + "-" + n));
            }
            sb.append("{" + String.join(",", listTest) +"}");

            String testJson =null;

          //検索必要table
            String table = request.getParameter("table");
            //検索必要カラムID
            String id = request.getParameter("id");
            //初期化
            List<T> list = null;
            Map<String,Object> map = new HashMap<String,Object>();


            switch(tableNmEnum.valueOf(table)) {
            //DRMユーザ
            case DRMAccount:
                list = (List<T>) this.masterhubService.DRMSelect(id);
                break;
            //カレンダー
            case Calendar:
                list = (List<T>) this.masterhubService.calendarSelect(id);
                break;
            //VANユーザ
            case VANAccount:
                list = (List<T>) this.masterhubService.VANSelect(id);
                break;
            //取引先
            case Account:
                testJson = "{\"Objects\":{\"取引先\":{\"SourceObject\":\"Account\",\"Key\":\"得意先コード\",\"FieldDefs\":{\"得意先コード\":{\"SourceStringField\":\"得意先コード\"},\"取引先名\":{\"SourceStringField\":\"取引先名\"}},},},\"Objects1\":{\"取引先責任者\":{\"SourceObject\":\"Contact\",\"Key\":\"個人コード\",\"FieldDefs\":{\"個人コード\":{\"SourceStringField\":\"個人コード\"},\"氏名\":{\"SourceStringField\":\"氏名\"}},\"出向先情報\":{\"SourceStringField\":\"取引先ID\",\"Lookup\":{\"SourceObject\":\"Account\",\"FieldDefs\":{\"得意先コード\":{\"SourceStringField\":\"得意先コード\"},\"取引先名\":{\"SourceStringField\":\"取引先名\"}}}}}}}";
                break;
            default:
                log.error("エラー発生しました。");
                log.error("Parameter[table]:"+table);
                log.error("Parameter[id]:"+id);
                throw new Exception();
            }

            //取得データ数
           // map.put(dataCnt, list.size());

            //取得データリスト
            //map.put(dataList, list);


            testJson ="{" +
                    "\"001N000001Pty8GIAR\": {" +
                    "    \"name\": \"CSLベーリング株式会社\"," +
                    "    \"account_number\": \"BSL\"," +
                    "    \"last_modified_date\": \"2019-02-26T01:03:12.000Z\"," +
                    "    \"gyoushu_main_cd\": \"001 医薬品製造販売業\"," +
                    "    \"mdb\": [" +
                    "      \"DCF\"," +
                    "      \"DSF\"," +
                    "      \"PCF\"," +
                    "      \"VAN\"" +
                    "    ]," +
                    "    \"nohingaiyou\":{" +
                    "     \"A001\":" +
                    "     {" +
                    "     \"RecordType\":\"01 媒体\"," +
                    "     \"Name\":\"テスト名\"," +
                    "     \"USER\":\"テスト001\"," +
                    "     \"ULT_TANTOSHA_LASTNAME\":\"\"," +
                    "     \"BIKO_COMMENTS\":\"\"," +
                    "     \"nohinset\":{" +
                    "      \"B001\":{" +
                    "        \"RecordTypeName\":\"01 媒体\"," +
                    "        \"NOHIN_CD\":\"A11\"," +
                    "        \"NOHIN_KBN\":\"01 定例\"," +
                    "        \"TEIREI_SHIMEBI_KBN\":\"03 月2\"," +
                    "        \"nohinSetItem\":{}," +
                    "        \"sohusaki\":{" +
                    "          \"S001\":" +
                    "          {" +
                    "         \"SOFUSAKI_KAISHA_NM\":\"送付先名\"," +
                    "         \"SOFUSAKI_ZIP\":\"013214\"," +
                    "         \"SOFUSAKI_JUSHO\":\"東京都 江東区 東雲1-7-12 KDX豊洲グランスクエア3階\"," +
                    "         \"SOFUSAKI_TEL\":\"080-0000-0000\"," +
                    "         \"GAIJIFAX_SOFUSAKI_TANTOSHA_NO\":\"\"" +
                    "         }" +
                    "       }" +
                    "       }" +
                    "      }" +
                    "      }," +
                    "     \"A002\":" +
                    "     {" +
                    "     \"RecordType\":\"01 媒体\"," +
                    "     \"Name\":\"テスト名\"," +
                    "     \"USER\":\"テスト001\"," +
                    "     \"ULT_TANTOSHA_LASTNAME\":\"\"," +
                    "     \"BIKO_COMMENTS\":\"\"," +
                    "     \"nohinset\":{" +
                    "      \"B002\":{" +
                    "        \"RecordTypeName\":\"01 媒体\"," +
                    "        \"NOHIN_CD\":\"A01\"," +
                    "        \"NOHIN_KBN\":\"01 定例\"," +
                    "        \"TEIREI_SHIMEBI_KBN\":\"04 中締め\"," +
                    "        \"nohinSetItem\":{}," +
                    "      \"sohusaki\":{" +
                    "          \"S002\":" +
                    "          {" +
                    "         \"SOFUSAKI_KAISHA_NM\":\"送付先名\"," +
                    "         \"SOFUSAKI_ZIP\":\"013214\"," +
                    "         \"SOFUSAKI_JUSHO\":\"東京都 江東区 東雲1-7-12 KDX豊洲グランスクエア3階\"," +
                    "         \"SOFUSAKI_TEL\":\"080-0000-0000\"," +
                    "         \"GAIJIFAX_SOFUSAKI_TANTOSHA_NO\":\"\"" +
                    "         }" +
                    "       }" +
                    "       }" +
                    "       }" +
                    "      }," +
                    "      \"A003\":" +
                    "     {" +
                    "     \"RecordType\":\"01 媒体\"," +
                    "     \"Name\":\"テスト名\"," +
                    "     \"USER\":\"テスト001\"," +
                    "     \"ULT_TANTOSHA_LASTNAME\":\"\"," +
                    "     \"BIKO_COMMENTS\":\"\"," +
                    "     \"nohinset\":{" +
                    "      \"B003\":{" +
                    "        \"RecordTypeName\":\"01 媒体\"," +
                    "        \"NOHIN_CD\":\"D01\"," +
                    "        \"NOHIN_KBN\":\"01 定例\"," +
                    "        \"TEIREI_SHIMEBI_KBN\":\"01 日次\"," +
                    "        \"nohinSetItem\":{}," +
                    "       \"sohusaki\":{" +
                    "          \"S003\":" +
                    "          {" +
                    "         \"SOFUSAKI_KAISHA_NM\":\"送付先名\"," +
                    "         \"SOFUSAKI_ZIP\":\"013214\"," +
                    "         \"SOFUSAKI_JUSHO\":\"東京都 江東区 東雲1-7-12 KDX豊洲グランスクエア3階\"," +
                    "         \"SOFUSAKI_TEL\":\"080-0000-0000\"," +
                    "         \"GAIJIFAX_SOFUSAKI_TANTOSHA_NO\":\"\"" +
                    "         }" +
                    "       }" +
                    "       }" +
                    "      }" +
                    "      }" +
                    "     }," +
                    "    \"contacts\": {" +
                    "      \"003N000001K7zRMIAZ\": {" +
                    "        \"name\": \"毅 松浦\"," +
                    "        \"kana\": \" \"," +
                    "        \"address\": \"1350062 東京都 江東区 東雲1-7-12 KDX豊洲グランスクエア3階\"," +
                    "        \"email\": \"takeshi.matsuura@cslbehring.com\"," +
                    "        \"region\": \"東日本\"," +
                    "        \"affiliation_companyname\": \"CSLベーリング株式会社\"" +
                    "      }," +
                    "      \"003N000001K7zYuIAJ\": {" +
                    "        \"name\": \"モランジュ ジャン・マルク\"," +
                    "        \"kana\": \" \"," +
                    "        \"address\": \"1350062 東京都 江東区 東雲1-7-12KDX豊洲ｸﾞﾗﾝｽｸｴｱ3階\"," +
                    "        \"email\": \"\"," +
                    "        \"region\": \"東日本\"," +
                    "        \"affiliation_companyname\": \"CSLベーリング株式会社\"" +
                    "      }," +
                    "      \"003N000001K81AtIAJ\": {" +
                    "        \"name\": \"研一郎 財津\"," +
                    "        \"kana\": \" \"," +
                    "        \"address\": \"1350062 東京都 江東区 東雲1-7-12 KDX豊洲グランスクエア3階\"," +
                    "        \"email\": \"kenichiro.zaitsu@cslbehring.com\"," +
                    "        \"region\": \"東日本\"," +
                    "        \"affiliation_companyname\": \"CSLベーリング株式会社\"" +
                    "      }" +
                    "    }" +
                    "  }," +
                    "  \"001N000001Pty8GIA1\": {" +
                    "    \"name\": \"CSLベーリング株式会社1\"," +
                    "    \"account_number\": \"CSD\"," +
                    "    \"last_modified_date\": \"2019-02-26T01:03:12.000Z\"," +
                    "    \"gyoushu_main_cd\": \"001 医薬品製造販売業\"," +
                    "    \"mdb\": [" +
                    "      \"DCF\"," +
                    "      \"DSF\"," +
                    "      \"PCF\"," +
                    "      \"VAN\"" +
                    "    ]," +
                    "    \"nohingaiyou\":{" +
                    "     \"A001\":" +
                    "     {" +
                    "     \"RecordType\":\"01 媒体\"," +
                    "     \"Name\":\"テスト名\"," +
                    "     \"USER\":\"テスト001\"," +
                    "     \"ULT_TANTOSHA_LASTNAME\":\"\"," +
                    "     \"BIKO_COMMENTS\":\"\"," +
                    "     \"nohinset\":{" +
                    "      \"B001\":{" +
                    "        \"RecordTypeName\":\"01 媒体\"," +
                    "        \"NOHIN_CD\":\"B01\"," +
                    "        \"NOHIN_KBN\":\"01 定例\"," +
                    "        \"TEIREI_SHIMEBI_KBN\":\"03 月2\"," +
                    "        \"nohinSetItem\":{}," +
                    "        \"sohusaki\":{" +
                    "          \"S001\":" +
                    "          {" +
                    "         \"SOFUSAKI_KAISHA_NM\":\"送付先名\"," +
                    "         \"SOFUSAKI_ZIP\":\"013214\"," +
                    "         \"SOFUSAKI_JUSHO\":\"東京都 江東区 東雲1-7-12 KDX豊洲グランスクエア3階\"," +
                    "         \"SOFUSAKI_TEL\":\"080-0000-0000\"," +
                    "         \"GAIJIFAX_SOFUSAKI_TANTOSHA_NO\":\"\"" +
                    "         }" +
                    "       }" +
                    "       }" +
                    "      }" +
                    "      }," +
                    "     \"A002\":" +
                    "     {" +
                    "     \"RecordType\":\"01 媒体\"," +
                    "     \"Name\":\"テスト名\"," +
                    "     \"USER\":\"テスト001\"," +
                    "     \"ULT_TANTOSHA_LASTNAME\":\"\"," +
                    "     \"BIKO_COMMENTS\":\"\"," +
                    "     \"nohinset\":{" +
                    "      \"B002\":{" +
                    "        \"RecordTypeName\":\"01 媒体\"," +
                    "        \"NOHIN_CD\":\"A01\"," +
                    "        \"NOHIN_KBN\":\"01 定例\"," +
                    "        \"TEIREI_SHIMEBI_KBN\":\"04 中締め\"," +
                    "        \"nohinSetItem\":{}," +
                    "      \"sohusaki\":{" +
                    "          \"S002\":" +
                    "          {" +
                    "         \"SOFUSAKI_KAISHA_NM\":\"送付先名\"," +
                    "         \"SOFUSAKI_ZIP\":\"013214\"," +
                    "         \"SOFUSAKI_JUSHO\":\"東京都 江東区 東雲1-7-12 KDX豊洲グランスクエア3階\"," +
                    "         \"SOFUSAKI_TEL\":\"080-0000-0000\"," +
                    "         \"GAIJIFAX_SOFUSAKI_TANTOSHA_NO\":\"\"" +
                    "         }" +
                    "       }" +
                    "       }" +
                    "       }" +
                    "      }," +
                    "      \"A003\":" +
                    "     {" +
                    "     \"RecordType\":\"01 媒体\"," +
                    "     \"Name\":\"テスト名\"," +
                    "     \"USER\":\"テスト001\"," +
                    "     \"ULT_TANTOSHA_LASTNAME\":\"\"," +
                    "     \"BIKO_COMMENTS\":\"\"," +
                    "     \"nohinset\":{" +
                    "      \"B003\":{" +
                    "        \"RecordTypeName\":\"01 媒体\"," +
                    "        \"NOHIN_CD\":\"C01\"," +
                    "        \"NOHIN_KBN\":\"01 定例\"," +
                    "        \"TEIREI_SHIMEBI_KBN\":\"01 日次\"," +
                    "        \"nohinSetItem\":{}," +
                    "       \"sohusaki\":{" +
                    "          \"S003\":" +
                    "          {" +
                    "         \"SOFUSAKI_KAISHA_NM\":\"送付先名\"," +
                    "         \"SOFUSAKI_ZIP\":\"013214\"," +
                    "         \"SOFUSAKI_JUSHO\":\"東京都 江東区 東雲1-7-12 KDX豊洲グランスクエア3階\"," +
                    "         \"SOFUSAKI_TEL\":\"080-0000-0000\"," +
                    "         \"GAIJIFAX_SOFUSAKI_TANTOSHA_NO\":\"\"" +
                    "         }" +
                    "       }" +
                    "       }" +
                    "       }" +
                    "      }" +
                    "     }," +
                    "    \"contacts\": {" +
                    "      \"003N000001K7zRMIAZ\": {" +
                    "        \"name\": \"毅 松浦\"," +
                    "        \"kana\": \" \"," +
                    "        \"address\": \"1350062 東京都 江東区 東雲1-7-12 KDX豊洲グランスクエア3階\"," +
                    "        \"email\": \"takeshi.matsuura@cslbehring.com\"," +
                    "        \"region\": \"東日本\"," +
                    "        \"affiliation_companyname\": \"CSLベーリング株式会社\"" +
                    "      }," +
                    "      \"003N000001K7zYuIAJ\": {" +
                    "        \"name\": \"モランジュ ジャン・マルク\"," +
                    "        \"kana\": \" \"," +
                    "        \"address\": \"1350062 東京都 江東区 東雲1-7-12KDX豊洲ｸﾞﾗﾝｽｸｴｱ3階\"," +
                    "        \"email\": \"\"," +
                    "        \"region\": \"東日本\"," +
                    "        \"affiliation_companyname\": \"CSLベーリング株式会社\"" +
                    "      }," +
                    "      \"003N000001K81AtIAJ\": {" +
                    "        \"name\": \"研一郎 財津\"," +
                    "        \"kana\": \" \"," +
                    "        \"address\": \"1350062 東京都 江東区 東雲1-7-12 KDX豊洲グランスクエア3階\"," +
                    "        \"email\": \"kenichiro.zaitsu@cslbehring.com\"," +
                    "        \"region\": \"東日本\"," +
                    "        \"affiliation_companyname\": \"CSLベーリング株式会社\"" +
                    "      }" +
                    "    }" +
                    "  }," +
                    "  \"001N000001Pty8GIA2\": {" +
                    "    \"name\": \"CSLベーリング株式会社2\"," +
                    "    \"account_number\": \"ASL\"," +
                    "    \"last_modified_date\": \"2019-02-26T01:03:12.000Z\"," +
                    "    \"gyoushu_main_cd\": \"001 医薬品製造販売業\"," +
                    "    \"mdb\": [" +
                    "      \"DCF\"," +
                    "      \"DSF\"," +
                    "      \"PCF\"," +
                    "      \"VAN\"" +
                    "    ]," +
                    "    \"nohingaiyou\":{" +
                    "     \"A001\":" +
                    "     {" +
                    "     \"RecordType\":\"01 媒体\"," +
                    "     \"Name\":\"テスト名\"," +
                    "     \"USER\":\"テスト001\"," +
                    "     \"ULT_TANTOSHA_LASTNAME\":\"\"," +
                    "     \"BIKO_COMMENTS\":\"\"," +
                    "     \"nohinset\":{" +
                    "      \"B001\":{" +
                    "        \"RecordTypeName\":\"01 媒体\"," +
                    "        \"NOHIN_CD\":\"F01\"," +
                    "        \"NOHIN_KBN\":\"01 定例\"," +
                    "        \"TEIREI_SHIMEBI_KBN\":\"03 月2\"," +
                    "        \"nohinSetItem\":{}," +
                    "        \"sohusaki\":{" +
                    "          \"S001\":" +
                    "          {" +
                    "         \"SOFUSAKI_KAISHA_NM\":\"送付先名\"," +
                    "         \"SOFUSAKI_ZIP\":\"013214\"," +
                    "         \"SOFUSAKI_JUSHO\":\"東京都 江東区 東雲1-7-12 KDX豊洲グランスクエア3階\"," +
                    "         \"SOFUSAKI_TEL\":\"080-0000-0000\"," +
                    "         \"GAIJIFAX_SOFUSAKI_TANTOSHA_NO\":\"\"" +
                    "         }" +
                    "       }" +
                    "       }" +
                    "      }" +
                    "      }," +
                    "     \"A002\":" +
                    "     {" +
                    "     \"RecordType\":\"01 媒体\"," +
                    "     \"Name\":\"テスト名\"," +
                    "     \"USER\":\"テスト001\"," +
                    "     \"ULT_TANTOSHA_LASTNAME\":\"\"," +
                    "     \"BIKO_COMMENTS\":\"\"," +
                    "     \"nohinset\":{" +
                    "      \"B002\":{" +
                    "        \"RecordTypeName\":\"01 媒体\"," +
                    "        \"NOHIN_CD\":\"A01\"," +
                    "        \"NOHIN_KBN\":\"01 定例\"," +
                    "        \"TEIREI_SHIMEBI_KBN\":\"04 中締め\"," +
                    "        \"nohinSetItem\":{}," +
                    "      \"sohusaki\":{" +
                    "          \"S002\":" +
                    "          {" +
                    "         \"SOFUSAKI_KAISHA_NM\":\"送付先名\"," +
                    "         \"SOFUSAKI_ZIP\":\"013214\"," +
                    "         \"SOFUSAKI_JUSHO\":\"東京都 江東区 東雲1-7-12 KDX豊洲グランスクエア3階\"," +
                    "         \"SOFUSAKI_TEL\":\"080-0000-0000\"," +
                    "         \"GAIJIFAX_SOFUSAKI_TANTOSHA_NO\":\"\"" +
                    "         }" +
                    "       }" +
                    "       }" +
                    "       }" +
                    "      }," +
                    "      \"A003\":" +
                    "     {" +
                    "     \"RecordType\":\"01 媒体\"," +
                    "     \"Name\":\"テスト名\"," +
                    "     \"USER\":\"テスト001\"," +
                    "     \"ULT_TANTOSHA_LASTNAME\":\"\"," +
                    "     \"BIKO_COMMENTS\":\"\"," +
                    "     \"nohinset\":{" +
                    "      \"B003\":{" +
                    "        \"RecordTypeName\":\"01 媒体\"," +
                    "        \"NOHIN_CD\":\"A01\"," +
                    "        \"NOHIN_KBN\":\"01 定例\"," +
                    "        \"TEIREI_SHIMEBI_KBN\":\"01 日次\"," +
                    "        \"nohinSetItem\":{}," +
                    "       \"sohusaki\":{" +
                    "          \"S003\":" +
                    "          {" +
                    "         \"SOFUSAKI_KAISHA_NM\":\"送付先名\"," +
                    "         \"SOFUSAKI_ZIP\":\"013214\"," +
                    "         \"SOFUSAKI_JUSHO\":\"東京都 江東区 東雲1-7-12 KDX豊洲グランスクエア3階\"," +
                    "         \"SOFUSAKI_TEL\":\"080-0000-0000\"," +
                    "         \"GAIJIFAX_SOFUSAKI_TANTOSHA_NO\":\"\"" +
                    "         }" +
                    "       }" +
                    "       }" +
                    "      }" +
                    "      }" +
                    "     }," +
                    "    \"contacts\": {" +
                    "      \"003N000001K7zRMIAZ\": {" +
                    "        \"name\": \"毅 松浦\"," +
                    "        \"kana\": \" \"," +
                    "        \"address\": \"1350062 東京都 江東区 東雲1-7-12 KDX豊洲グランスクエア3階\"," +
                    "        \"email\": \"takeshi.matsuura@cslbehring.com\"," +
                    "        \"region\": \"東日本\"," +
                    "        \"affiliation_companyname\": \"CSLベーリング株式会社\"" +
                    "      }," +
                    "      \"003N000001K7zYuIAJ\": {" +
                    "        \"name\": \"モランジュ ジャン・マルク\"," +
                    "        \"kana\": \" \"," +
                    "        \"address\": \"1350062 東京都 江東区 東雲1-7-12KDX豊洲ｸﾞﾗﾝｽｸｴｱ3階\"," +
                    "        \"email\": \"\"," +
                    "        \"region\": \"東日本\"," +
                    "        \"affiliation_companyname\": \"CSLベーリング株式会社\"" +
                    "      }," +
                    "      \"003N000001K81AtIAJ\": {" +
                    "        \"name\": \"研一郎 財津\"," +
                    "        \"kana\": \" \"," +
                    "        \"address\": \"1350062 東京都 江東区 東雲1-7-12 KDX豊洲グランスクエア3階\"," +
                    "        \"email\": \"kenichiro.zaitsu@cslbehring.com\"," +
                    "        \"region\": \"東日本\"," +
                    "        \"affiliation_companyname\": \"CSLベーリング株式会社\"" +
                    "      }" +
                    "    }" +
                    "  }" +
                    "}";


            log.info("正常処理しました。");



            return sb.toString();//.replaceAll("\\\\", "");

            }


}
