package jp.co.ultmarc.masterhub.common.constants;

/**
 *
 * @author 権
 *
 */
public enum tableNmEnum {

    /** DRMユーザ */
    DRMAccount{

        public String toString() {
            return "DRMAccount";
        }
    },
    /** カレンダー */
    Calendar{

        public String toString() {
            return "Calendar";
        }
    },
    /** VANユーザ */
    VANAccount{

        public String toString() {
            return "VANAccount";
        }
    },
    /** 取引先 */
    Account{

        public String toString() {
            return "Account";
        }
    }
}
