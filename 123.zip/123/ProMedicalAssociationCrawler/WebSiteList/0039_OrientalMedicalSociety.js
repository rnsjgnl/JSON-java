require('date-utils');
const puppeteer = require('puppeteer');
var fs = require('fs');
var seq = 1;
var robotsParser = require('../Utils/robotsParser');
var csvFormat = require('../Utils/csvFormat');
var csvConverter = require('../CallPython/CallPythonSell');
var convertDir = 'data';
var today = new Date().toFormat("YYYYMMDD");

exports.accessPage = async function accessPage(accessURL, headless, code, name, logger) {
	// robots.txtチェック
	robotsResult = await robotsParser.robotsTextSearch(accessURL, logger);
	if(robotsResult == true){
		( async () => {
			logger.info('クローラ起動')
			// ブラウザ起動と設定
			const browser = await puppeteer.launch({
				headless: headless,
				args: [
					'--window-size=1600,950',
					'--window-position=100,50',
					'--no-sandbox',
					'--disable-setuid-sandbox'
				]
			});
			const page = await browser.newPage();
			
			// ディレクトリ+ファイル名
			var filePath = convertDir + '/' + code + '_' + name + '_' + today + '.csv'
			logger.info('出力ディレクトリ：' + convertDir + '/');
			logger.info('出力ファイル名：' + code + '_' + name + '_' + today + '.csv');
			
			// 同名ファイル存在チェック
			if(fs.existsSync(filePath)){
				logger.info('同名ファイル存在チェック：' + fs.existsSync(filePath))
				logger.info('ファイル削除')
				fs.unlinkSync(filePath)
				logger.info('同名ファイル存在チェック：' + fs.existsSync(filePath))
			}
			
			try {
				logger.info('クロール開始');
				// ヘッダーの設定
				csvFormat.setCsvHedFormat(filePath);
				
				await page.setViewport({width: 1600, height: 950});
				await page.goto(accessURL, {waitUntil: 'networkidle2', timeout: 15000});
				
				// 検索ボンタンを押下
				var searchButtonXpath = "//a[img[@name='検索']]";
				var searchButton = await page.$x(searchButtonXpath);
				await Promise.all([
					page.waitForNavigation({waitUntil: "networkidle2"}),
					searchButton[0].click()
				])
				
				// 氏名リスト
				count = 0;
				var nameListXpath =  '//tr/td/a[img[@alt="詳細へ"]]';
				var nameList = await page.$x(nameListXpath);
				for(var j = 0; j < nameList.length; j ++){
					await Promise.all([
						page.waitForNavigation({waitUntil: "networkidle2"}),
						nameList[j].click()
					]);
					var dt = new Date();
					var formatted = dt.toFormat("YYYY/MM/DD HH24:MI.SS");
					var kinmu = '' 
					var ken = ''
					var sikaku = '専門医'
					var nameItemXpath = '/html/body/table[1]/tbody/tr/td/table/tbody/tr[position() >1]'
					await page.waitForXPath(nameItemXpath)
					var nameItem =  await page.$x(nameItemXpath);
					for(var k =　0; k <　nameItem.length; k ++){
						var temp_valu = await (await (await nameItem[k].$x('td[1]'))[0].getProperty('textContent')).jsonValue();
						if(temp_valu.indexOf('氏名') > -1){
							var value = await (await (await nameItem[k].$x('td[2]'))[0].getProperty('textContent')).jsonValue();
							value = value.replace(/	/g, '').replace(/\n/g, '').replace('*', '').trim()
						} else if (temp_valu.indexOf('開業先名') > -1){
							var kinmu = await (await (await nameItem[k].$x('td[2]'))[0].getProperty('textContent')).jsonValue();
							kinmu = kinmu.replace(/	/g, '').replace(/\n/g, '').trim()
						} else if(temp_valu.indexOf('開業先所在') > -1){
							var ken =  await (await (await nameItem[k].$x('td[2]'))[0].getProperty('textContent')).jsonValue();
							ken = ken.replace(/	/g, '').replace(/\n/g, '').trim()
							ken = ken.match(/((.{2}[都|府|道])|(.{2,3}県))/)[0].trim()
						}
					}
					
					//住所が記載されていない場合、固定値「01」を指定
					if(ken == ""){
						ken = '01'
					}
					csvFormat.setCsvDate(filePath, sikaku, ken, kinmu, value, seq, formatted);
					count = count +1
					seq++;
					
					// 氏名リストに戻る
					var nameListBackBtnXpath = '//tbody/tr/td[@align="left"]/a';
					await page.waitForXPath(nameListBackBtnXpath);
					const nameListBackBtn = await page.$x(nameListBackBtnXpath);
					await Promise.all([
						page.waitForNavigation({waitUntil: "networkidle2"}),
						nameListBackBtn[0].click()
					]);
					var nameListXpath =  '//tr/td/a[img[@alt="詳細へ"]]';
					await page.waitForXPath(nameListXpath);
					nameList = await page.$x(nameListXpath);
				}
				logger.info('取得件数：' + count);
				
				// csv⇒Excel
				csvConverter.PythonShellCsvConverter(filePath, name, code, today, logger);
			} catch(e) {
				// エラー出力
				logger.error(e)
				
				// ブラウザを閉じて終了
				await browser.close();
				process.exit(200);
			}
			// ブラウザを閉じて終了
			await browser.close();
		})();
	}
}