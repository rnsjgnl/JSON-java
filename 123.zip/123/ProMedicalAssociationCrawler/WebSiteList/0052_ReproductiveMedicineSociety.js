require('date-utils');
const puppeteer = require('puppeteer');
var fs = require('fs');
var seq = 1;
var robotsParser = require('../Utils/robotsParser');
var csvFormat = require('../Utils/csvFormat');
var csvConverter = require('../CallPython/CallPythonSell');
var convertDir = 'data';
var today = new Date().toFormat("YYYYMMDD");

exports.accessPage = async function accessPage(accessURL, headless, code, name, logger) {
	// robots.txtチェック
	robotsResult = await robotsParser.robotsTextSearch(accessURL, logger);
	if(robotsResult == true){
		( async () => {
			logger.info('クローラ起動')
			// ブラウザ起動と設定
			const browser = await puppeteer.launch({
				headless: headless,
				args: [
					'--window-size=1600,950',
					'--window-position=100,50',
					'--no-sandbox',
					'--disable-setuid-sandbox'
				]
			});
			const page = await browser.newPage();
			
			// ディレクトリ+ファイル名
			var filePath = convertDir + '/' + code + '_' + name + '_' + today + '.csv';
			logger.info('出力ディレクトリ：' + convertDir + '/');
			logger.info('出力ファイル名：' + code + '_' + name + '_' + today + '.csv');
			
			// 同名ファイル存在チェック
			if(fs.existsSync(filePath)){
				logger.info('同名ファイル存在チェック：' + fs.existsSync(filePath));
				logger.info('ファイル削除');
				fs.unlinkSync(filePath);
				logger.info('同名ファイル存在チェック：' + fs.existsSync(filePath));
			}
			
			try {
				logger.info('クロール開始');
				// ヘッダーの設定
				csvFormat.setCsvHedFormat(filePath);
				
				await page.setViewport({width: 1600, height: 950});
				await page.goto(accessURL, {waitUntil: 'networkidle2', timeout: 5000});
				
				// ページのスクショ
				await page.screenshot({path: 'screenshotData/' + code + '_' + name + '.jpg', fullPage: true});
				
				// サイト掲載日の取得
				var publicationDateXpath = '//*[@id="right_column"]/div/p[1]';
				await page.waitForXPath(publicationDateXpath);
				const publicationDateItem = await page.$x(publicationDateXpath);
				var publicationDate = await (await publicationDateItem[0].getProperty('textContent')).jsonValue();
				publicationDate = publicationDate.replace('\n','')
				logger.info('掲載日：' + publicationDate);
				
				// 登録件数
				var numberOfEntriesXpath = '//*[@id="right_column"]/div/p[2]';
				await page.waitForXPath(numberOfEntriesXpath);
				const numberOfEntriesItem = await page.$x(numberOfEntriesXpath);
				var numberOfEntries = await (await numberOfEntriesItem[0].getProperty('innerHTML')).jsonValue();
				numberOfEntries = numberOfEntries.split('<br>');
				var numberOfEntries = numberOfEntries[0].replace('総合計', '').replace('名', '')
				logger.info('登録件数：' + numberOfEntries);
				
				var count = 0
				var excludeCount = 0
				var specialistDoctorCount = 0
				var guidanceDoctorCount = 0
				
				// 氏名の取得
				var xpath = '//*[@id="right_column"]/div/table[@class="specialist-list"]/tbody/tr[position() >1]';
				await page.waitForXPath(xpath);
				const nameList = await page.$x(xpath);
				var dt = new Date();
				var formatted = dt.toFormat("YYYY/MM/DD HH24:MI.SS");
				for (var i = 0; i < nameList.length; i++) {
					var td_tab_data = await nameList[i].$x('td')
					var value = await (await (await td_tab_data[1].getProperty('textContent')).jsonValue()).replace(/ /g, '');
					
					//取得対象氏名
					if (value.indexOf('*') == -1) {
						var sikaku = "";
						//「★」がついている氏名は指導医
						if (value.indexOf('★') != -1) {
							value = value.replace('★', '');
							sikaku = "指導医";
							guidanceDoctorCount ++;
						} else {
							sikaku = "専門医";
							specialistDoctorCount ++;
						}
						var ken = await (await (await td_tab_data[0].getProperty('textContent')).jsonValue()).replace(/ /g, '').replace(/\n/g, '');
						var kinmu = await (await (await td_tab_data[3].getProperty('textContent')).jsonValue()).trim();
						csvFormat.setCsvDate(filePath, sikaku, ken, kinmu, value, seq, formatted);
						seq++;
						count ++
					} else {
						//名誉医療専門医(取得対象外)
						excludeCount ++
					}
				}
				logger.info('取得件数：' + count + '(内訳：[専門医数：' + specialistDoctorCount + '],[指導医数：' + guidanceDoctorCount + '])');
				logger.info('除外件数：' + excludeCount + '(名誉医療専門医)');
				// csv⇒Excel
				csvConverter.PythonShellCsvConverter(filePath, name, code, today, logger);
			} catch(e) {
				// エラー出力
				logger.error(e);
				
				// ブラウザを閉じて終了
				await browser.close();
				process.exit(200);
			}
			// ブラウザを閉じて終了
			await browser.close();
			logger.info('クロール終了');
		})();
	}
}