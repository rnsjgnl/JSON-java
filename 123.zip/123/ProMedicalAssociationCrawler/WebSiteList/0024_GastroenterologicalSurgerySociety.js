require('date-utils');
const puppeteer = require('puppeteer');
var fs = require('fs');
var seq = 1;
var robotsParser = require('../Utils/robotsParser');
var csvFormat = require('../Utils/csvFormat');
var csvConverter = require('../CallPython/CallPythonSell');
var convertDir = 'data';
var today = new Date().toFormat("YYYYMMDD");

exports.accessPage = async function accessPage(accessURL, headless, code, name, logger) {
	// robots.txtチェック
	robotsResult = await robotsParser.robotsTextSearch(accessURL, logger);
	if(robotsResult == true){
		( async () => {
			logger.info('クローラ起動')
			// ブラウザ起動と設定
			const browser = await puppeteer.launch({
				headless: headless,
				args: [
					'--window-size=1600,950',
					'--window-position=100,50',
					'--no-sandbox',
					'--disable-setuid-sandbox'
				]
			});
			const page = await browser.newPage();
			
			// ディレクトリ+ファイル名
			var filePath = convertDir + '/' + code + '_' + name + '_' + today + '.csv'
			logger.info('出力ディレクトリ：' + convertDir + '/');
			logger.info('出力ファイル名：' + code + '_' + name + '_' + today + '.csv');
			
			// 同名ファイル存在チェック
			if(fs.existsSync(filePath)){
				logger.info('同名ファイル存在チェック：' + fs.existsSync(filePath))
				logger.info('ファイル削除')
				fs.unlinkSync(filePath)
				logger.info('同名ファイル存在チェック：' + fs.existsSync(filePath))
			}
			
			try {
				logger.info('クロール開始');
				// ヘッダーの設定
				csvFormat.setCsvHedFormat(filePath);
				
				await page.setViewport({width: 1600, height: 950});
				await page.goto(accessURL, {waitUntil: 'networkidle2', timeout: 5000});
				
				// ページのスクショ
				await page.screenshot({path: 'screenshotData/' + code + '_' + name + '.jpg', fullPage: true});
				
				// サイト掲載日の取得
				var publicationDateXpath = '//div[@class="date_search"]';
				await page.waitForXPath(publicationDateXpath);
				const publicationDateItem = await page.$x(publicationDateXpath);
				var publicationDate = await (await publicationDateItem[0].getProperty('textContent')).jsonValue();
				publicationDate = publicationDate.replace('現在', '').replace('\n','')
				logger.info('掲載日：' + publicationDate);
				
				// 登録件数
				var numberOfEntriesXpath = '//div[@class="under_sm"]/p/b';
				await page.waitForXPath(numberOfEntriesXpath);
				const numberOfEntriesItem = await page.$x(numberOfEntriesXpath);
				var numberOfEntries = await (await numberOfEntriesItem[0].getProperty('textContent')).jsonValue();
				logger.info('登録件数：' + numberOfEntries);
				
				// 半角空白入力
				await page.type("#sq3", ' ');
				
				// 検索ボタンが来るまで待つ
				var searchBtnXpath = '//div[@class="form_submit"]/input';
				await page.waitForXPath(searchBtnXpath);
				// 検索ボタンがクリック
				const searchBtn = await page.$x(searchBtnXpath);
				await Promise.all([
					page.waitForNavigation({waitUntil: "networkidle2"}),
					searchBtn[0].click()
				]);
				
				var sikakuXpath = '//*[@id="senmoni"]//div[@class="search_map_in"]/h2'
				const sikakuItem = await page.$x(sikakuXpath);
				var sikaku = await (await sikakuItem[0].getProperty('textContent')).jsonValue()
				sikaku = sikaku.replace('消化器外科', '').replace('を検索する', '')
				
				// 専門医名を取得
				var xpath = '//*[@id="senmoni"]//ul[@class="hlist"]/li';
				const nameList = await page.$x(xpath);
				var dt = new Date();
				var formatted = dt.toFormat("YYYY/MM/DD HH24:MI.SS");
				for (var i = 0; i < nameList.length; i++) {
					var value = await (await nameList[i].getProperty('innerHTML')).jsonValue();
					value = value.split( '</span>' )[1]
					var ken = await (await (await nameList[i].$x('span'))[0].getProperty('textContent')).jsonValue();
					var kinmu = ''
					csvFormat.setCsvDate(filePath, sikaku, ken, kinmu, value, seq, formatted);
					seq++;
				}
				logger.info('取得件数：' + i);
				// csv⇒Excel
				csvConverter.PythonShellCsvConverter(filePath, name, code, today, logger);
			} catch(e) {
				// エラー出力
				logger.error(e)
				
				// ブラウザを閉じて終了
				await browser.close();
				process.exit(200);
			}
			// ブラウザを閉じて終了
			await browser.close();
		})();
	}
}