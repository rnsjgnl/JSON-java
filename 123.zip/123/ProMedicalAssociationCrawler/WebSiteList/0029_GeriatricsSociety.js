require('date-utils');
const puppeteer = require('puppeteer');
var fs = require('fs');
var seq = 1;
var robotsParser = require('../Utils/robotsParser');
var csvFormat = require('../Utils/csvFormat');
var csvConverter = require('../CallPython/CallPythonSell');
var convertDir = 'data';
var today = new Date().toFormat("YYYYMMDD");
var allCounter = 0;

exports.accessPage = async function accessPage(accessURL, headless, code, name, logger) {
	// robots.txtチェック
	robotsResult = await robotsParser.robotsTextSearch(accessURL, logger);
	if(robotsResult == true){
		( async () => {
			logger.info('クローラ起動');
			// ブラウザ起動と設定
			const browser = await puppeteer.launch({
				headless: headless,
				args: [
					'--window-size=1600,950',
					'--window-position=100,50',
					'--no-sandbox',
					'--disable-setuid-sandbox'
				]
			});
			const page = await browser.newPage();
			
			// ディレクトリ+ファイル名
			var filePath = convertDir + '/' + code + '_' + name + '_' + today + '.csv';
			logger.info('出力ディレクトリ：' + convertDir + '/');
			logger.info('出力ファイル名：' + code + '_' + name + '_' + today + '.csv');
			
			// 同名ファイル存在チェック
			if(fs.existsSync(filePath)){
				logger.info('同名ファイル存在チェック：' + fs.existsSync(filePath));
				logger.info('ファイル削除');
				fs.unlinkSync(filePath);
				logger.info('同名ファイル存在チェック：' + fs.existsSync(filePath));
			}
			
			try {
				logger.info('クロール開始');
				// ヘッダーの設定
				csvFormat.setCsvHedFormat(filePath);
				;
				await page.setViewport({width: 1600, height: 950});
				await page.goto(accessURL, {waitUntil: 'networkidle2', timeout: 5000});
				
				// 氏名検索ボックス
				var nameSearchBoxXpath = '//*[@id="txtName"]';
				await page.waitForXPath(nameSearchBoxXpath);
				await page.type('#txtName', ' ');
				
				// 氏名検索ボタン
				var nameSearchButtonXpath = '//*[@id="cmdSeek"]';
				await page.waitForXPath(nameSearchButtonXpath);
				const nameSearchButton = await page.$x(nameSearchButtonXpath);
				await Promise.all([
					page.waitForNavigation({waitUntil: "networkidle2"}),
					nameSearchButton[0].click()
				]);
				
				// 登録件数
				var numberOfEntriesXpath = '//*[@id="lblCnt"]';
				await page.waitForXPath(numberOfEntriesXpath);
				const numberOfEntriesItem = await page.$x(numberOfEntriesXpath);
				var numberOfEntries = await (await numberOfEntriesItem[0].getProperty('textContent')).jsonValue();
				logger.info('登録件数：' + numberOfEntries);
				
				// ページのスクショ
				await page.screenshot({path: 'screenshotData/' + code + '_' + name + '.jpg', fullPage: true});
				
				// 資格名の取得
				var sikaku = '専門医';
				var lasutPageFlag = false;
				do{
					// 専門医名を取得
					var nameListxpath = '//table[@id="dgSenmon"]/tbody/tr[position() > 1]';
					const nameList = await page.$x(nameListxpath);
					var dt = new Date();
					var formatted = dt.toFormat("YYYY/MM/DD HH24:MI.SS");
					for(var j = 0; j < nameList.length; j++) {
						var kinmu = '';
						var clItem =  await (await nameList[j].$x('td'));
						if(clItem.length > 1){
							var ken = await (await (await nameList[j].$x('td[2]'))[0].getProperty('textContent')).jsonValue();
							ken = ken.replace('&nbsp;', '').replace(' ', '');
							var value = await (await (await nameList[j].$x('td[3]'))[0].getProperty('textContent')).jsonValue();
							var tempkinmu = await (await (await nameList[j].$x('td[4]'))[0].getProperty('innerHTML')).jsonValue();
							if(tempkinmu != '&nbsp;'){
								var tempkinmu = tempkinmu.split('<br>');
								var count = tempkinmu.length;
								var tempStr = '';
								for(let i = 0; i < count; i++){
									// 郵便番号
									const postalCodeStr = '(^[0-9]{3}-[0-9]{4}$)';
									var strMatch = tempkinmu[i].match(postalCodeStr);
									if(strMatch != null){
										continue;
									}
									// 住所
									const addressStr = '(^([0-9]|[０-９])+(-|－)+([0-9]|[０-９])+$)|(.+(市|区|町|村|丁目).+(([0-9]|[０-９])|(番|番地|号|丁目))+$)';
									var strMatch = tempkinmu[i].match(addressStr);
									if(strMatch != null){
										continue;
									}
									// 建物名+階
									const Buildingstr = '((.*([0-9]|[０-９])+(Ｆ|F|階)+$)|(.+(Ｆ|F|階|ビル)+$)|(.+(団地|練|街|号館|マンション|ビル).*(([0-9]|[０-９])|号+$|号室+$)))';
									var strMatch = tempkinmu[i].match(Buildingstr);
									if(strMatch != null){
										continue;
									}
									// 住所、ビル名、会社名の場合取得しない
									const Buildingstr2 = '(^テラスカーム１０２|^ＳＫ-II－１０１|^イオンリテール株式会社+$|大供２０１)';
									var strMatch = tempkinmu[i].match(Buildingstr2);
									if(strMatch != null){
										continue;
									}
									// 役職名の場合取得しない
									var strMatch =  tempkinmu[i].match('(^院長+$|殿+$|^施設長+$|^理事長+$|^センター長+$|^総合センター長+$)');
									if(strMatch != null){
										continue;
									} else {
										// 施設名+役職名の場合役職名削除
										var str = tempkinmu[i].replace(/(院長|副院長|副病院長|名誉院長|病院長|名誉病院長|センター長)/g, '').trim();
										if(tempStr != ''){
											tempStr = tempStr + '　' + str;
										} else {
											tempStr = tempStr + str;
										}
									}
								}
								kinmu = tempStr;
							}
							csvFormat.setCsvDate(filePath, sikaku, ken, kinmu, value, seq, formatted);
							allCounter = allCounter  +1;
							seq++;
						}
					}
					// ページングリストの取得
					var pageListXpath = '//span[@id="lblLink1"]/span/following-sibling::a[1]';
					var pageList = await page.$x(pageListXpath);
					if(pageList.length != 0){
						await Promise.all([
							page.waitForNavigation({waitUntil: "networkidle2"}),
							pageList[0].click()
						]);
					} else{
						lasutPageFlag = true;
					}
				}while(lasutPageFlag == false)
				logger.info('取得件数：' + allCounter);
				// csv⇒Excel
				csvConverter.PythonShellCsvConverter(filePath, name, code, today, logger);
			} catch(e) {
				// エラー出力
				logger.error(e)
				
				// ブラウザを閉じて終了
				await browser.close();
				process.exit(200);
			}
			// ブラウザを閉じて終了
			await browser.close();
		})();
	}
}