require('date-utils');
const puppeteer = require('puppeteer');
var fs = require('fs');
var seq = 1;
var robotsParser = require('../Utils/robotsParser');
var csvFormat = require('../Utils/csvFormat');
var csvConverter = require('../CallPython/CallPythonSell');
var convertDir = 'data';
var today = new Date().toFormat("YYYYMMDD");
var allcount = 0;

exports.accessPage = async function accessPage(accessURL, headless, code, name, logger) {
	// robots.txtチェック
	robotsResult = await robotsParser.robotsTextSearch(accessURL, logger);
	if(robotsResult == true){
		( async () => {
			logger.info('クローラ起動')
			// ブラウザ起動と設定
			const browser = await puppeteer.launch({
				headless: headless,
				args: [
					'--window-size=1600,950',
					'--window-position=100,50',
					'--no-sandbox',
					'--disable-setuid-sandbox'
				]
			});
			const page = await browser.newPage();
			
			// ディレクトリ+ファイル名
			var filePath = convertDir + '/' + code + '_' + name + '_' + today + '.csv'
			logger.info('出力ディレクトリ：' + convertDir + '/');
			logger.info('出力ファイル名：' + code + '_' + name + '_' + today + '.csv');
			
			// 同名ファイル存在チェック
			if(fs.existsSync(filePath)){
				logger.info('同名ファイル存在チェック：' + fs.existsSync(filePath))
				logger.info('ファイル削除')
				fs.unlinkSync(filePath)
				logger.info('同名ファイル存在チェック：' + fs.existsSync(filePath))
			}
			
			try {
				logger.info('クロール開始');
				// ヘッダーの設定
				csvFormat.setCsvHedFormat(filePath);
				
				await page.setViewport({width: 1600, height: 950});
				await page.goto(accessURL, {waitUntil: 'networkidle2', timeout: 5000});
				
				// ページのスクショ
				await page.screenshot({path: 'screenshotData/' + code + '_' + name + '.jpg', fullPage: true});
				
				// サイト掲載日と登録件数の取得
				var publicationDateAndnumberOfEntriesXpath = '//*[@id="main-content"]/p[3]';
				await page.waitForXPath(publicationDateAndnumberOfEntriesXpath);
				const publicationDateAndnumberOfEntriesItem = await page.$x(publicationDateAndnumberOfEntriesXpath);
				var publicationDateAndnumberOfEntries = await (await publicationDateAndnumberOfEntriesItem[0].getProperty('textContent')).jsonValue()
				var publicationDateAndnumberOfEntries = publicationDateAndnumberOfEntries.split('（');
				var numberOfEntries = publicationDateAndnumberOfEntries[0].replace('\n','').replace('専門医数 : ', '');
				var publicationDate = publicationDateAndnumberOfEntries[1].replace('\n','').replace('現在）', '');
				logger.info('掲載日：' + publicationDate);
				logger.info('登録件数：' + numberOfEntries);
				
				// 検索ボタンが来るまで待つ
				var prefecturesListXpath = '//*[@id="main-content"]/table[1]/tbody/tr/td/a[1]';
				await page.waitForXPath(prefecturesListXpath);
				var prefecturesList = await page.$x(prefecturesListXpath);
				// 九州・沖縄枠と海外枠の内容が同じため
				var prefecturesListCount = prefecturesList.length -1
				for(var i = 0; i < prefecturesListCount; i ++){
					await Promise.all([
						page.waitForNavigation({waitUntil: "networkidle2"}),
						prefecturesList[i].click()
					]);
					var xpath = '//*[@id="main-content"]/table';
					const nameList = await page.$x(xpath);
					var dt = new Date();
					var formatted = dt.toFormat("YYYY/MM/DD HH24:MI.SS");
					for (var j = 0; j < nameList.length; j++) {
						var count = 0
						var sikaku = "専門医";
						var kinmu = "";
						var ken = ""
						var list = await (await nameList[j].$x('tbody/tr'))
						for(var k = 0; k < list.length; k++){
							var listItem = await (await list[k].$x('td'))
							if(listItem.length == 1){
								var ken = await (await listItem[0].getProperty('textContent')).jsonValue();
							}else{
								var kinmu = await (await listItem[0].getProperty('textContent')).jsonValue();
								var value = await (await listItem[1].getProperty('textContent')).jsonValue();
								csvFormat.setCsvDate(filePath, sikaku, ken, kinmu.trim(), value, seq, formatted);
								count = count +1
								allcount = allcount +1
								seq++;
							}
						}
						var listItem = await (await nameList[j].$x('following-sibling::p[1]'))
						if(listItem.length == 1){
							var tempkencount = await (await listItem[0].getProperty('textContent')).jsonValue();
							tempkencount = tempkencount.replace('（', '').replace('）', '')
						}
						logger.info(ken + '[' + count + '/' + tempkencount + ']')
					}
					var backBtnXpath = '//*[@id="pankuzu"]/li/a[text()="専門医制度"]';
					await page.waitForXPath(backBtnXpath);
					const backBtn = await page.$x(backBtnXpath);
					await Promise.all([
						page.waitForNavigation({waitUntil: "networkidle2"}),
						backBtn[0].click()
					]);
					await page.waitForXPath(prefecturesListXpath);
					var prefecturesList = await page.$x(prefecturesListXpath);
				}
				logger.info('取得件数' + allcount)
				// csv⇒Excel
				csvConverter.PythonShellCsvConverter(filePath, name, code, today, logger);
			} catch(e) {
				// エラー出力
				logger.error(e);
				
				// ブラウザを閉じて終了
				await browser.close();
				process.exit(200);
			}
			// ブラウザを閉じて終了
			await browser.close();
			logger.info('クロール終了');
		})();
	}
}