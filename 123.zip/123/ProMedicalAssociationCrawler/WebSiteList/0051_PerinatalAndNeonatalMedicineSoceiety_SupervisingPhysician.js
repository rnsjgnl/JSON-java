require('date-utils');
const puppeteer = require('puppeteer');
var fs = require('fs');
var seq = 1;
var robotsParser = require('../Utils/robotsParser');
var csvFormat = require('../Utils/csvFormat');
var csvConverter = require('../CallPython/CallPythonSell');
var convertDir = 'data';
var today = new Date().toFormat("YYYYMMDD");

exports.accessPage = async function accessPage(accessURL, headless, code, name, logger) {
	// robots.txtチェック
	robotsResult = await robotsParser.robotsTextSearch(accessURL, logger);
	if(robotsResult == true){
		( async () => {
			logger.info('クローラ起動')
			// ブラウザ起動と設定
			const browser = await puppeteer.launch({
				headless: headless,
				args: [
					'--window-size=1600,950',
					'--window-position=100,50',
					'--no-sandbox',
					'--disable-setuid-sandbox'
				]
			});
			const page = await browser.newPage();
			
			// ディレクトリ+ファイル名
			var filePath = convertDir + '/' + code + '_' + name + '_' + today + '.csv'
			logger.info('出力ディレクトリ：' + convertDir + '/');
			logger.info('出力ファイル名：' + code + '_' + name + '_' + today + '.csv');
			
			// 同名ファイル存在チェック
			if(fs.existsSync(filePath)){
				logger.info('同名ファイル存在チェック：' + fs.existsSync(filePath))
				logger.info('ファイル削除')
				fs.unlinkSync(filePath)
				logger.info('同名ファイル存在チェック：' + fs.existsSync(filePath))
			}
			
			try {
				logger.info('クロール開始');
				// ヘッダーの設定
				csvFormat.setCsvHedFormat(filePath);
				
				await page.setViewport({width: 1600, height: 950});
				await page.goto(accessURL, {waitUntil: 'networkidle2', timeout: 5000});
				
				// ページのスクショ
				await page.screenshot({path: 'screenshotData/' + code + '_' + name + '.jpg', fullPage: true});
				
				// サイト掲載日の取得
				var publicationDateXpath = '//*[@id="ctl00_ContentPlaceHolder1_hizuke"]';
				await page.waitForXPath(publicationDateXpath);
				const publicationDateItem = await page.$x(publicationDateXpath);
				var publicationDate = await (await publicationDateItem[0].getProperty('textContent')).jsonValue()
				publicationDate = publicationDate.replace('\n','')
				logger.info('掲載日：' + publicationDate);
				
				// 氏名の取得 
				var count =0
				var xpath = '//*[@id="aspnetForm"]/table[@class="shidoi"]/tbody/tr';
				await page.waitForXPath(xpath);
				const nameList = await page.$x(xpath);
				var dt = new Date();
				var formatted = dt.toFormat("YYYY/MM/DD HH24:MI.SS");
				for (var i = 0; i < nameList.length; i++) {
					var sikaku = "指導医";
					
					var kenXpath = 'th[@class="shidoi_todofuken"]'
					var kenIndex = await nameList[i].$x(kenXpath)
					if(kenIndex.length != 0){
						var ken = await (await kenIndex[0].getProperty('textContent')).jsonValue();
						ken = ken.replace(/ /g, '').replace(/\n/g, '')
					}
					
					var datexpath = "td"
					var date = await nameList[i].$x(datexpath)
					if(date.length != 0){
						var kinmu = await (await date[1].getProperty('textContent')).jsonValue();
						var value = await (await date[2].getProperty('textContent')).jsonValue();
						value = value.replace('(代表)', '')
						csvFormat.setCsvDate(filePath, sikaku, ken, kinmu, value, seq, formatted);
						count = count +1
						seq++;
					}
				}
				logger.info('取得件数：' + count);
				// csv⇒Excel
				csvConverter.PythonShellCsvConverter(filePath, name, code, today, logger);
			} catch(e) {
				// エラー出力
				logger.error(e);
				
				// ブラウザを閉じて終了
				await browser.close();
				process.exit(200);
			}
			// ブラウザを閉じて終了
			await browser.close();
			logger.info('クロール終了');
		})();
	}
}