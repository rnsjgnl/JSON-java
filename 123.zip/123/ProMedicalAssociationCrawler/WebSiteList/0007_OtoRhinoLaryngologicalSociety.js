require('date-utils');
const puppeteer = require('puppeteer');
var fs = require('fs');
var seq = 1;
var robotsParser = require('../Utils/robotsParser');
var csvFormat = require('../Utils/csvFormat');
var csvConverter = require('../CallPython/CallPythonSell');
var convertDir = 'data';
var today = new Date().toFormat("YYYYMMDD");
var allCounter = 0;

exports.accessPage = async function accessPage(accessURL, headless, code, name, logger) {
	//robots.txtチェック
	robotsResult = await robotsParser.robotsTextSearch(accessURL, logger);
	if(robotsResult == true){
		( async () => {
			logger.info('クローラ起動')
			//ブラウザ起動と設定
			const browser = await puppeteer.launch({
				headless: headless,
				args: [
					'--window-size=1600,950',
					'--window-position=100,50',
					'--no-sandbox',
					'--disable-setuid-sandbox'
				]
			});
			const page = await browser.newPage();
			
			//ディレクトリ+ファイル名
			var filePath = convertDir + '/' + code + '_' + name + '_' + today + '.csv';
			logger.info('出力ディレクトリ：' + convertDir + '/');
			logger.info('出力ファイル名：' + code + '_' + name + '_' + today + '.csv');
			
			//同名ファイル存在チェック
			if(fs.existsSync(filePath)){
				logger.info('同名ファイル存在チェック：' + fs.existsSync(filePath));
				logger.info('ファイル削除');
				fs.unlinkSync(filePath);
				logger.info('同名ファイル存在チェック：' + fs.existsSync(filePath));
			}
			
			//外字画像（氏名）の保存先
			var nameImgFileDir = convertDir + '/' + code + '_' + name + '_' + '氏名画像' + '_' + today;
			var nameImgCount = 0;
			
			try {
				logger.info('クロール開始');
				//ヘッダーの設定
				csvFormat.setCsvHedFormat(filePath);
				
				await page.setViewport({width: 1600, height: 950});
				await page.goto(accessURL, {waitUntil: 'networkidle2', timeout: 5000});
				
				//検索ボタンが来るまで待つ
				var searchBtnXpath = '//div[@class="form_submit"]/input[@alt="検索する"]';
				await page.waitForXPath(searchBtnXpath);
				
				//検索ボタンをクリック
				const searchBtn = await page.$x(searchBtnXpath);
				await Promise.all([
					page.waitForNavigation({waitUntil: "networkidle2"}),
					searchBtn[0].click()
				]);
				
				//ページのスクショ
				await page.screenshot({path: 'screenshotData/' + code + '_' + name + '.jpg', fullPage: true});
				
				//サイト掲載日の取得
				var publicationDateXpath = '//div[@class="article"]/div[@class="box_date"]';
				await page.waitForXPath(publicationDateXpath);
				const publicationDateItem = await page.$x(publicationDateXpath);
				var publicationDate = await (await publicationDateItem[0].getProperty('textContent')).jsonValue();
				publicationDate = publicationDate.replace(/\n/g, '');
				logger.info('掲載日：' + publicationDate);
				
				//登録件数の取得
				var numberOfEntriesXpath = '//div[@id="result-list"]/table/tbody/tr/th/span[contains(text(),"件表示")]';
				await page.waitForXPath(numberOfEntriesXpath);
				const numberOfEntriesItem = await page.$x(numberOfEntriesXpath);
				var tempNumberOfEntries = await (await numberOfEntriesItem[0].getProperty('textContent')).jsonValue();
				tempNumberOfEntries = tempNumberOfEntries.replace(/ /g,'').replace(/\n/g, '');
				var numberOfEntries = tempNumberOfEntries.split('件中')
				logger.info('登録件数：' + numberOfEntries[0].replace('(', ''));
				
				//処理日の取得
				var dt = new Date();
				var formatted = dt.toFormat("YYYY/MM/DD HH24:MI.SS");
				var sikaku = '専門医';
				var lastPageFlg = new Boolean(false);
				do{
					var xpath = "//div[@id='result-list']/table/tbody/tr[position() > 2]";
					var nameList = await page.$x(xpath);
					for(var i = 0; i < nameList.length; i++){
						//氏名の取得
						var value = ''
						var td1ElementList = []
						var td1Element00 = await nameList[i].$x('td[1]')
						var td1Element02 = await (await td1Element00[0].getProperty('innerHTML')).jsonValue()
						//氏名に画像が含まれている
						if(td1Element02.includes('img')){
							value = await (await td1Element00[00].getProperty('textContent')).jsonValue()
							// 氏名の表示用imgファイルのスクショを取得
							if (!fs.existsSync(nameImgFileDir)) {
								fs.mkdirSync(nameImgFileDir);
							}
							// 氏名画像保存先
							const imgNameCount =  await td1Element00[0].$x('img')
							if(imgNameCount != 0){
								await imgNameCount[0].screenshot({path: nameImgFileDir + '/' + seq + '_[' + value + ']' + '.jpg'});
							}
							value = value.split(value.match(/[ｧ-ﾝﾞﾟ\-]|[ァ-ンヴー]/)[0])[0].trim()
							nameImgCount ++;
						}else{
							td1ElementList = td1Element02.split('<br>')
							value = td1ElementList[0].trim()
						}
						//施設名の取得
						var kinmu = await (await (await nameList[i].$x('td[2]'))[0].getProperty('textContent')).jsonValue()
						//県名の取得
						var ken = ""
						var td3ElementList = []
						var td3Element = await (await (await nameList[i].$x('td[3]'))[0].getProperty('innerHTML')).jsonValue()
						td3ElementList = td3Element.split('<br>')
						for(var j = 0; j < td3ElementList.length; j ++){
							var address = td3ElementList[j].trim()
							if((address != '') && (address != ' ') && (!address.includes('〒')) && (!address.includes('TEL'))){
								if(address.match(/^((.{2}[都|府|道])|(.{2,3}県))/) != null){
									//住所から都道府県名を取得
									ken = address.match(/^((.{2}[都|府|道])|(.{2,3}県))/)[0].trim()
									break;
								}else if(address.match(/^([ァ-ヶ]|[ｦ-ﾟ])+州/) != null){
									//住所から州名を取得
									ken = address.match(/^([ァ-ヶ]|[ｦ-ﾟ])+州/)[0].trim()
									break;
								}else{
									//上記以外の場合
									ken = address.trim()
									break;
								}
							}
						}
						//住所が存在しない場合は「01」を設定
						if(ken == ''){
							ken = "01"
						}
						csvFormat.setCsvDate(filePath, sikaku, ken, kinmu, value, seq, formatted);
						allCounter = allCounter  +1;
						seq++;
					}
					//ページ番号の取得
					var pageNumverxpath = "//span[@class='kensuu']";
					await page.waitForXPath(pageNumverxpath);
					const pageNumverElement = await page.$x(numberOfEntriesXpath);
					var pageNumverItem = await (await pageNumverElement[0].getProperty('textContent')).jsonValue();
					var pageNumver = Math.ceil(((pageNumverItem.match(/～(.)+件/)[0].trim().replace(/～|件/g, '') / 10) *10) /10);
					logger.info(pageNumver + 'ページのクロールが終了しました。')
					//ページ遷移
					var xpath = "//div[@class='inner']/following-sibling::div[1]/div/div/a[(text()='→')]";
					var nextPageButton = await page.$x(xpath);
					if(nextPageButton.length != 0){
						await Promise.all([
							page.waitForNavigation({waitUntil: "networkidle2"}),
							nextPageButton[0].click()
						]);	
					} else {
						lastPageFlg = true
					}
				} while(lastPageFlg == false);
				logger.info('取得件数：' + allCounter);
				logger.info('外字文字画像を' + nameImgCount + '個取得しました。格納先は「' + nameImgFileDir + '」です。');
				//csv⇒Excel
				csvConverter.PythonShellCsvConverter(filePath, name, code, today, logger);
			} catch(e) {
				//エラー出力
				logger.error(e);
				//ブラウザを閉じて終了
				await browser.close();
				process.exit(200);
			}
			//ブラウザを閉じて終了
			await browser.close();
		})();
	}
}