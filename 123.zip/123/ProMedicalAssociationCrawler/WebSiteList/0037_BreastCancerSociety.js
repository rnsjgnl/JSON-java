require('date-utils');
const puppeteer = require('puppeteer');
var fs = require('fs');
var seq = 1;
var robotsParser = require('../Utils/robotsParser');
var csvFormat = require('../Utils/csvFormat');
var csvConverter = require('../CallPython/CallPythonSell');
var convertDir = 'data';
var today = new Date().toFormat("YYYYMMDD");
var allCounter = 0;

exports.accessPage = async function accessPage(accessURL, headless, code, name, logger) {
	// robots.txtチェック
	robotsResult = await robotsParser.robotsTextSearch(accessURL, logger);
	if(robotsResult == true){
		( async () => {
			logger.info('クローラ起動')
			// ブラウザ起動と設定
			const browser = await puppeteer.launch({
				headless: headless,
				args: [
					'--window-size=1600,950',
					'--window-position=100,50',
					'--no-sandbox',
					'--disable-setuid-sandbox'
				]
			});
			const page = await browser.newPage();
			
			// ディレクトリ+ファイル名
			var filePath = convertDir + '/' + code + '_' + name + '_' + today + '.csv'
			logger.info('出力ディレクトリ：' + convertDir + '/');
			logger.info('出力ファイル名：' + code + '_' + name + '_' + today + '.csv');
			
			// 同名ファイル存在チェック
			if(fs.existsSync(filePath)){
				logger.info('同名ファイル存在チェック：' + fs.existsSync(filePath))
				logger.info('ファイル削除')
				fs.unlinkSync(filePath)
				logger.info('同名ファイル存在チェック：' + fs.existsSync(filePath))
			}
			
			try {
				logger.info('クロール開始');
				// ヘッダーの設定
				csvFormat.setCsvHedFormat(filePath);
				
				await page.setViewport({width: 1600, height: 950});
				await page.goto(accessURL, {waitUntil: 'networkidle2', timeout: 5000});
				
				// ページのスクショ
				await page.screenshot({path: 'screenshotData/' + code + '_' + name + '.jpg', fullPage: true});
				
				// サイト掲載日と登録件数
				var publicationDateXpath = '//*[@id="post-3476"]/p';
				await page.waitForXPath(publicationDateXpath);
				const publicationDateItem = await page.$x(publicationDateXpath);
				var publicationDate = await (await publicationDateItem[0].getProperty('textContent')).jsonValue()
				var tpublicationDate = publicationDate.split('　')
				var publicationDate = tpublicationDate[0].replace('現在','')
				var numberOfEntries = tpublicationDate[1].replace('掲載数 : ','')
				logger.info('掲載日：' + publicationDate);
				logger.info('登録件数：' + numberOfEntries);

				// 地域ごとにクリック
				var regionXpath = '//*[@id="post-3476"]/blockquote/p//a';
				await page.waitForXPath(regionXpath);
				var regionList = await page.$x(regionXpath);
				for (var i = 0; i < regionList.length; i++) {
					var link = await (await regionList[i].getProperty('href')).jsonValue()
					await page.goto(link, {waitUntil: 'networkidle2', timeout: 5000});
 					// 専門医名を取得
					var regionNamexpath = '//*[@id="content"]/div/h3';
					const regionNameList = await page.$x(regionNamexpath);
					var dt = new Date();
					var formatted = dt.toFormat("YYYY/MM/DD HH24:MI.SS");
					var sikaku = "専門医";
					var kinmu = ''
					if(regionNameList.length == 0){
						// 北海道地区、その他
						var count = 0
						var kenXpath = '//*[@id="content"]/div/h2'
						await page.waitForXPath(kenXpath)
						var kenItem = await page.$x(kenXpath)
						var ken = await (await kenItem[0].getProperty('textContent')).jsonValue();
						ken = ken.replace('地区', '')
						var regionItemXpaht = '//*[@id="content"]/div/table//tr/td'
						await page.waitForXPath(regionItemXpaht)
						var regionItemList = await page.$x(regionItemXpaht)
						for(var j = 0; j < regionItemList.length; j++){
							// 出力順が逆転する場合が有る為50秒ミリ待つ
							await page.waitFor(50);
							var value = await (await regionItemList[j].getProperty('textContent')).jsonValue();
							value = value.replace(/\n/g, '').trim()
							if(value != ""){
								csvFormat.setCsvDate(filePath, sikaku, ken, kinmu, value, seq, formatted);
								allCounter = allCounter +1
								count = count +1
								seq++;
							}
						}
						logger.info(ken + ',取得件数：' + count);
					} else {
						// 東北地区～九州地区
						var kenXpath = '//*[@id="content"]/div/h3'
						await page.waitForXPath(kenXpath)
						var kenList = await page.$x(kenXpath)
						for(var K = 0; K < kenList.length; K++){
							var ken = await (await kenList[K].getProperty('textContent')).jsonValue();
							ken = ken.replace(/ /g, '').replace(/\n/g, '')
							// 2020/01/27_サイト上の表記ミス[ 秋田件を秋田県 ］に修正
							if (ken == '秋田件'){
								ken = ken.replace('件', '県')
							}
							var tableItemXpath = '//*[@id="content"]/div/table[position() >1]'
							await page.waitForXPath(tableItemXpath)
							var tableItemList = await page.$x(tableItemXpath)
							var tableItem = await (await tableItemList[K].$x('tbody/tr/td'))
							count = 0
							for (var l = 0; l < tableItem.length; l ++){
								// 出力順が逆転する場合が有る為50秒ミリ待つ
								await page.waitFor(50);
								var value = await (await tableItem[l].getProperty('textContent')).jsonValue();
								value = value.replace(/\n/g, '').trim()
								if(value != ""){
									csvFormat.setCsvDate(filePath, sikaku, ken, kinmu, value, seq, formatted);
									allCounter = allCounter +1
									count = count +1
									seq++;
								}
							}
							logger.info(ken + ',取得件数：' + count);
						}
					}
					// 検索画面に戻る
					var backBtnXpath = '//*[@id="panListInner"]//a[span[text()="乳腺専門医一覧"]]';
					await page.waitForXPath(backBtnXpath);
					const backBtn = await page.$x(backBtnXpath);
					await Promise.all([
						page.waitForNavigation({waitUntil: "networkidle2"}),
						backBtn[0].click()
					]);
					await page.waitForXPath(regionXpath);
					var regionList = await page.$x(regionXpath);
				}
				logger.info('取得件数：' + allCounter);
				// csv⇒Excel
				csvConverter.PythonShellCsvConverter(filePath, name, code, today, logger);
			} catch(e) {
				// エラー出力
				logger.error(e);
				
				// ブラウザを閉じて終了
				await browser.close();
				process.exit(200);
			}
			// ブラウザを閉じて終了
			await browser.close();
			logger.info('クロール終了');
		})();
	}
}