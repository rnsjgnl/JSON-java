const puppeteer = require('puppeteer');
const http = require('http');
const fs = require('fs');
var robotsParser = require('../Utils/robotsParser');
var csvConverter = require('../CallPython/CallPythonSell');
var convertDir = 'pdfData';
var today = new Date().toFormat("YYYYMMDD");
var pdfCrawle = '0049_PDF_Crawler.py'

exports.accessPage = async function accessPage(accessURL, headless, code, name, logger) {
	// robots.txtチェック
	robotsResult = await robotsParser.robotsTextSearch(accessURL, logger);
	if(robotsResult == true){
		( async () => {
			logger.info('クローラ起動')
			// ブラウザ起動と設定
			const browser = await puppeteer.launch({
				headless: headless,
				args: [
					'--window-size=1600,950',
					'--window-position=100,50',
					'--no-sandbox',
					'--disable-setuid-sandbox'
				]
			});
			const page = await browser.newPage();
			
			try {
				await page.setViewport({width: 1600, height: 950});
				await page.goto(accessURL, {waitUntil: 'networkidle2', timeout: 10000});
				// PDFボタンが来るまで待つ
				var searchBtnXpath = '//table[tbody/tr/td/span//span[contains(text(), "専門医")]]/following-sibling::table/tbody/tr/td[4]/a';
				await page.waitForXPath(searchBtnXpath);
				// PDFボタンがクリック
				const searchBtn = await page.$x(searchBtnXpath);
				// ページのスクショ
				await page.screenshot({path: 'screenshotData/' + code + '_' + name + '.jpg', fullPage: true});
				
				// 掲載日の取得と登録件数
				var numberAndDateXpath = '//table[tbody/tr/td/span//span[contains(text(), "専門医")]]/following-sibling::p/span';
				await page.waitForXPath(numberAndDateXpath);
				const numberAndDateItem = await page.$x(numberAndDateXpath);
				var numberAndDate = await (await numberAndDateItem[0].getProperty('textContent')).jsonValue()
				
				// 掲載日の取得
				var publicationDate = numberAndDate.match(/\(.+?\)/);
				logger.info('掲載日：' + publicationDate[0].trim());
				
				// 登録件数
				var numberOfEntries = numberAndDate.match(/(.)+名+?/);
				logger.info('登録件数：' + numberOfEntries[0].replace('(', '').replace('現在)', ''));
				
				var pdfFilePath = []
				var PrefecturesCount = 0
				var tempArealist = []
				for(var i = 0; i < searchBtn.length; i++){
					const searchBtn = await page.$x(searchBtnXpath);
					var PDFLink = await (await searchBtn[i].getProperty('href')).jsonValue();
					var kenName = await (await searchBtn[i].getProperty('textContent')).jsonValue()
					logger.info('PDF名前', kenName,':PDFリンク', PDFLink);
					const download = (url, pdfFilePath, cb) => {
						const file = fs.createWriteStream(pdfFilePath);
						const request = http.get(url, (response) => {
							if (response.statusCode !== 200) {
								return cb('Response status was ' + response.statusCode);
							}
							response.pipe(file);
						});
						file.on('finish', () => file.close(cb));
						
						request.on('error', (err) => {
							fs.unlink(pdfFilePath);
							return cb(err.message);
						});
						file.on('error', (err) => {
							fs.unlink(pdfFilePath);
							return cb(err.message);
						});
					};
					var cb = '';
					pdfFilePath.push(convertDir + '/' + code + '_' + name + '.pdf')
					download(PDFLink, pdfFilePath[PrefecturesCount], cb);
					PrefecturesCount = PrefecturesCount +1
				}
				logger.info('PDFタウンロード終了');
				for(var areaNum = 0; areaNum < tempArealist.length; areaNum++){
					pdfFilePath.push(tempArealist[areaNum])
				}
				csvConverter.PythonShellPdfCrawler(pdfCrawle, pdfFilePath, name, code, today, logger);
			} catch(e) {
				// エラー出力
				logger.error(e);
				// ブラウザを閉じて終了
				await browser.close();
				process.exit(200);
			}
			// ブラウザを閉じて終了
			await browser.close();
		})();
	}
}