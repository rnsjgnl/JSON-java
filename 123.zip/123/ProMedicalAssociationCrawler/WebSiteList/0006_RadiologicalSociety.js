require('date-utils');
const puppeteer = require('puppeteer');
var fs = require('fs');
var seq = 1;
var robotsParser = require('../Utils/robotsParser');
var csvFormat = require('../Utils/csvFormat');
var csvConverter = require('../CallPython/CallPythonSell');
const { from } = require('form-data');
var convertDir = 'data';
var today = new Date().toFormat("YYYYMMDD");
var allCounter = 0;

exports.accessPage = async function accessPage(accessURL, headless, code, name, logger) {
	// robots.txtチェック
	robotsResult = await robotsParser.robotsTextSearch(accessURL, logger);
	if(robotsResult == true){
		( async () => {
			logger.info('クローラ起動')
			// ブラウザ起動と設定
			const browser = await puppeteer.launch({
				headless: headless,
				args: [
					'--window-size=1600,950',
					'--window-position=100,50',
					'--no-sandbox',
					'--disable-setuid-sandbox'
				]
			});
			const page = await browser.newPage();
			
			// ディレクトリ+ファイル名
			var filePath = convertDir + '/' + code + '_' + name + '_' + today + '.csv'
			logger.info('出力ディレクトリ：' + convertDir + '/');
			logger.info('出力ファイル名：' + code + '_' + name + '_' + today + '.csv');
			
			// 同名ファイル存在チェック
			if(fs.existsSync(filePath)){
				logger.info('同名ファイル存在チェック：' + fs.existsSync(filePath))
				logger.info('ファイル削除')
				fs.unlinkSync(filePath)
				logger.info('同名ファイル存在チェック：' + fs.existsSync(filePath))
			}
			
			try {
				logger.info('クロール開始');
				// ヘッダーの設定
				csvFormat.setCsvHedFormat(filePath);
				
				await page.setViewport({width: 1600, height: 950});
				await page.goto(accessURL, {waitUntil: 'networkidle2', timeout: 15000});
				
				// ページタイトルが来るまで待つ
				await page.waitForXPath('//*[@id=\"contents\"]/h2');
				
				// ページのスクショ
				await page.screenshot({path: 'screenshotData/' + code + '_' + name + '.jpg', fullPage: true});
				
				// サイト掲載日の取得
				var publicationDateXpath = '//span[@class="menuCenter"]';
				await page.waitForXPath(publicationDateXpath);
				const publicationDateItem = await page.$x(publicationDateXpath);
				var publicationDate = await (await publicationDateItem[0].getProperty('textContent')).jsonValue();
				logger.info('掲載日：' + publicationDate);
				var initialList = await page.$x(initialListXpath)
				
				var initialListXpath = '//strong[contains(text(),診断専門医)]/following-sibling::a'
				await page.waitForXPath(initialListXpath)
				var initialList = await page.$x(initialListXpath)
				for(var i = 0; i < (initialList.length + 1); i++){
					var initialXpath = '//h4[contains(text(),診断専門医)]'
					await page.$x(initialXpath)
					const initialItem = await page.$x(initialXpath);
					var initial = await (await initialItem[0].getProperty('textContent')).jsonValue();
					logger.info(initial + 'の専門医を取得します。');
					// 専門医名を取得
					var nameListXpath = '//*[@id="contents"]/div/table/tbody/tr/td';
					await page.waitForXPath(nameListXpath);
					var nameList = await page.$x(nameListXpath);
					
					var dt = new Date();
					var formatted = dt.toFormat("YYYY/MM/DD HH24:MI.SS");
					var kinmu = '';
					var ken = '';
					var sikaku = '専門医';
					
					for (var j = 0; j < nameList.length; j++) {
						var rowValue = await (await nameList[j].getProperty('innerHTML')).jsonValue();
						var valueList = rowValue.split('<br>');
						for (var k = 0; k < valueList.length; k++) {
							var value = valueList[k].trim();
							if(typeof value !== 'undefined') {
								csvFormat.setCsvDate(filePath, sikaku, ken, kinmu, value, seq, formatted);
								allCounter = allCounter  +1;
								seq++;
							 }
						}
					}
					if(initialList.length > i){
						var initialListXpath = '//strong[contains(text(),診断専門医)]/following-sibling::a'
						await page.waitForXPath(initialListXpath)
						var initialList = await page.$x(initialListXpath)
						await Promise.all([
							page.waitForNavigation({waitUntil: "networkidle2"}),
							initialList[i].click()
						]);
					}
				}
				logger.info('取得件数：' + allCounter);
				// csv⇒Excel
				csvConverter.PythonShellCsvConverter(filePath, name, code, today, logger);
			} catch(e) {
				// エラー出力
				logger.error(e);
				// ブラウザを閉じて終了
				await browser.close();
				process.exit(200);
			}
			// ブラウザを閉じて終了
			await browser.close();
		})();
	}
}