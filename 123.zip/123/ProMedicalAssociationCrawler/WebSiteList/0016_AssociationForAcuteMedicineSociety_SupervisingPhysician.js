require('date-utils');
const puppeteer = require('puppeteer');
var fs = require('fs');
var seq = 1;
var robotsParser = require('../Utils/robotsParser');
var csvFormat = require('../Utils/csvFormat');
var csvConverter = require('../CallPython/CallPythonSell');
var convertDir = 'data';
var today = new Date().toFormat("YYYYMMDD");

exports.accessPage = async function accessPage(accessURL, headless, code, name, logger) {
	// robots.txtチェック
	robotsResult = await robotsParser.robotsTextSearch(accessURL, logger);
	if(robotsResult == true){
		( async () => {
			logger.info('クローラ起動')
			// ブラウザ起動と設定
			const browser = await puppeteer.launch({
				headless: headless,
				args: [
					'--window-size=1600,950',
					'--window-position=100,50',
					'--no-sandbox',
					'--disable-setuid-sandbox'
				]
			});
			const page = await browser.newPage();
			
			// ディレクトリ+ファイル名
			var filePath = convertDir + '/' + code + '_' + name + '_' + today + '.csv'
			logger.info('出力ディレクトリ：' + convertDir + '/');
			logger.info('出力ファイル名：' + code + '_' + name + '_' + today + '.csv');
			
			// 同名ファイル存在チェック
			if(fs.existsSync(filePath)){
				logger.info('同名ファイル存在チェック：' + fs.existsSync(filePath))
				logger.info('ファイル削除')
				fs.unlinkSync(filePath)
				logger.info('同名ファイル存在チェック：' + fs.existsSync(filePath))
			}
			
			try {
				logger.info('クロール開始');
				// ヘッダーの設定
				csvFormat.setCsvHedFormat(filePath);
				
				await page.setViewport({width: 1600, height: 950});
				await page.goto(accessURL, {waitUntil: 'networkidle2', timeout: 15000});
				
				// ページのスクショ
				await page.screenshot({path: 'screenshotData/' + code + '_' + name + '.jpg', fullPage: true});
				
				// サイト掲載日の取得
				var publicationDateXpath = '//div[@class="sub_contents card"]/h2';
				await page.waitForXPath(publicationDateXpath);
				const publicationDateItem = await page.$x(publicationDateXpath);
				var publicationDate = await (await publicationDateItem[0].getProperty('textContent')).jsonValue();
				publicationDate = publicationDate.replace('現在', '')
				logger.info('掲載日：' + publicationDate);

				// 登録件数
				var numberOfEntriesXpath = '/html/body/section/main/div/p';
				await page.waitForXPath(numberOfEntriesXpath);
				const numberOfEntriesItem = await page.$x(numberOfEntriesXpath);
				var numberOfEntries = await (await numberOfEntriesItem[0].getProperty('textContent')).jsonValue();
				numberOfEntries = numberOfEntries.replace(/\n/g ,'').replace(/	/g ,'').replace('以上', '')
				logger.info('_登録件数：' + numberOfEntries);
				
				// 専門医名を取得
				var count = 0;
				var xpath = '//div[@class="sub_contents card"]/h3';
				const itemList = await page.$x(xpath);
				var dt = new Date();
				var formatted = dt.toFormat("YYYY/MM/DD HH24:MI.SS");
				for (var i = 0; i < itemList.length; i++) {
					
					var ken = await (await itemList[i].getProperty('textContent')).jsonValue();
					var kinmu = '';
					var sikaku = '指導医';
					
					var nameListXpath = 'following-sibling::div[1]/ul/li';
					var nameList = await (await itemList[i].$x(nameListXpath));
					for(var j = 0; j < nameList.length; j++){
						var value = await (await nameList[j].getProperty('textContent')).jsonValue();
						if(value != ""){
							var value = value.trim()
							csvFormat.setCsvDate(filePath, sikaku, ken, kinmu, value, seq, formatted);
							count = count +1
							seq++;
						}
					}
				}
				logger.info('取得件数：' + count);
				// csv⇒Excel
				csvConverter.PythonShellCsvConverter(filePath, name, code, today, logger);
			} catch(e) {
				// エラー出力
				logger.error(e)
				
				// ブラウザを閉じて終了
				await browser.close();
				process.exit(200);
			}
			// ブラウザを閉じて終了
			await browser.close();
		})();
	}
}