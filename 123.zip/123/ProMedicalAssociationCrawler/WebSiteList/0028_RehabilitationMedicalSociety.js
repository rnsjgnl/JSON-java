require('date-utils');
const puppeteer = require('puppeteer');
var fs = require('fs');
var seq = 1;
var robotsParser = require('../Utils/robotsParser');
var csvFormat = require('../Utils/csvFormat');
var csvConverter = require('../CallPython/CallPythonSell');
var convertDir = 'data';
var today = new Date().toFormat("YYYYMMDD");
var allCounter = 0;

exports.accessPage = async function accessPage(accessURL, headless, code, name, logger) {
	// robots.txtチェック
	robotsResult = await robotsParser.robotsTextSearch(accessURL, logger);
	if(robotsResult == true){
		( async () => {
			logger.info('クローラ起動')
			// ブラウザ起動と設定
			const browser = await puppeteer.launch({
				headless: headless,
				args: [
					'--window-size=1600,950',
					'--window-position=100,50',
					'--no-sandbox',
					'--disable-setuid-sandbox'
				]
			});
			const page = await browser.newPage();
			
			// ディレクトリ+ファイル名
			var filePath = convertDir + '/' + code + '_' + name + '_' + today + '.csv';
			logger.info('出力ディレクトリ：' + convertDir + '/');
			logger.info('出力ファイル名：' + code + '_' + name + '_' + today + '.csv');
			
			// 同名ファイル存在チェック
			if(fs.existsSync(filePath)){
				logger.info('同名ファイル存在チェック：' + fs.existsSync(filePath));
				logger.info('ファイル削除');
				fs.unlinkSync(filePath);
				logger.info('同名ファイル存在チェック：' + fs.existsSync(filePath));
			}
			
			try {
				logger.info('クロール開始');
				// ヘッダーの設定
				csvFormat.setCsvHedFormat(filePath);
				
				await page.setViewport({width: 1600, height: 950});
				await page.goto(accessURL, {waitUntil: 'networkidle2', timeout: 10000});
				
				// 登録件数
				var numberOfEntriesXpath = '//div[@class="caption"]//h3';
				await page.waitForXPath(numberOfEntriesXpath);
				const numberOfEntriesItem = await page.$x(numberOfEntriesXpath);
				var numberOfEntries = await (await numberOfEntriesItem[0].getProperty('textContent')).jsonValue();
				numberOfEntries = numberOfEntries.replace(/\n/g,'').replace(/	/g, '').replace('現在 ', '');
				logger.info('登録件数：' + numberOfEntries);
				// ページのスクショ
				// await page.screenshot({path: 'screenshotData/' + code + '_' + name + '.jpg', fullPage: true});
				await page.screenshot({path: 'screenshotData/' + code + '_' + name + '.png', fullPage: true});
				
				// 専門医名を取得
				var xpath = '//table[@class="mb-5 table-orange table-sm"]/tbody/tr[position() > 1]';
				const nameList = await page.$x(xpath);
				
				var sikakuXpath = '//span[@class="badge"]/text()';
				await page.waitForXPath(sikakuXpath);
				const sikakuItem = await page.$x(sikakuXpath);
				var sikaku =  await (await sikakuItem[1].getProperty('textContent')).jsonValue();
				sikaku = sikaku.replace(/\n/g,'').replace(/ /g, '').replace(/	/g, '').replace('地域別', '').replace('リスト', '');
				var dt = new Date();
				var formatted = dt.toFormat("YYYY/MM/DD HH24:MI.SS");
				for (var i = 0; i < nameList.length; i++) {
					const kenIndex = await (await nameList[i].$x('th'));
					if(kenIndex.length != 0){
						var ken = await (await (await nameList[i].$x('th'))[0].getProperty('textContent')).jsonValue();
						ken = ken.replace(/\n/g,'').replace(/	/g, '');
					}
					const valueAndkinmuIndex = await (await nameList[i].$x('td[not(contains(@colspan, "3")) and not(contains(@colspan, "4")) ]'));
					if(valueAndkinmuIndex.length != 0){
						var value = await (await (await nameList[i].$x('td[1]'))[0].getProperty('textContent')).jsonValue();
						value = value.replace(/\n/g,'').replace(/	/g, '');
						var kinmu = await (await (await nameList[i].$x('td[2]'))[0].getProperty('textContent')).jsonValue();
						kinmu = kinmu.replace(/\n/g,'').replace(/	/g, '');
						csvFormat.setCsvDate(filePath, sikaku, ken, kinmu, value, seq, formatted);
						allCounter = allCounter + 1
						seq++;
					}
				}
				logger.info('取得件数：' + allCounter);
				// csv⇒Excel
				csvConverter.PythonShellCsvConverter(filePath, name, code, today, logger);
			} catch(e) {
				// エラー出力
				logger.error(e)
				
				// ブラウザを閉じて終了
				await browser.close();
				process.exit(200);
			}
			// ブラウザを閉じて終了
			await browser.close();
		})();
	}
}