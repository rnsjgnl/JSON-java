require('date-utils');
const puppeteer = require('puppeteer');
var fs = require('fs');
var seq = 1;
var robotsParser = require('../Utils/robotsParser');
var csvFormat = require('../Utils/csvFormat');
var csvConverter = require('../CallPython/CallPythonSell');
var convertDir = 'data';
var today = new Date().toFormat("YYYYMMDD");
var allCounter = 0;

exports.accessPage = async function accessPage(accessURL, headless, code, name, logger) {
	// robots.txtチェック
	robotsResult = await robotsParser.robotsTextSearch(accessURL, logger);
	if(robotsResult == true){
		( async () => {
			logger.info('クローラ起動')
			// ブラウザ起動と設定
			const browser = await puppeteer.launch({
				headless: headless,
				args: [
					'--window-size=1600,950',
					'--window-position=100,50',
					'--no-sandbox',
					'--disable-setuid-sandbox'
				]
			});
			const page = await browser.newPage();
			
			// ディレクトリ+ファイル名
			var filePath = convertDir + '/' + code + '_' + name + '_' + today + '.csv'
			logger.info('出力ディレクトリ：' + convertDir + '/');
			logger.info('出力ファイル名：' + code + '_' + name + '_' + today + '.csv');
			
			// 同名ファイル存在チェック
			if(fs.existsSync(filePath)){
				logger.info('同名ファイル存在チェック：' + fs.existsSync(filePath))
				logger.info('ファイル削除')
				fs.unlinkSync(filePath)
				logger.info('同名ファイル存在チェック：' + fs.existsSync(filePath))
			}
			
			try {
				logger.info('クロール開始');
				// ヘッダーの設定
				csvFormat.setCsvHedFormat(filePath);
				
				await page.setViewport({width: 1600, height: 950});
				await page.goto(accessURL, {waitUntil: 'networkidle2', timeout: 150000});
				// Webサイトが重い為、タイムアウト時間を設定しない
				await page.setDefaultNavigationTimeout(0); 
				
				// ページのスクショ
				await page.screenshot({path: 'screenshotData/' + code + '_' + name + '.jpg', fullPage: true});
				
				// 登録件数
				var numberOfEntriesXpath = '//*[@id="main_contents"]/p[1]/span';
				await page.waitForXPath(numberOfEntriesXpath);
				const numberOfEntriesItem = await page.$x(numberOfEntriesXpath);
				var numberOfEntries = await (await numberOfEntriesItem[0].getProperty('textContent')).jsonValue()
				logger.info('登録件数：' + numberOfEntries);
				
				// 北海道ボタンが来るまで待つ
				await page.waitForXPath('//*[@id="main_contents"]/table/tbody/tr[1]/td/span/a');
				// 都道府県ごとにクリック
				var searchBtnXpath = '//*[@id="main_contents"]/table/tbody/tr/td/span/a';
				var searchBtnList = await page.$x(searchBtnXpath);
				for (var i = 0; i < searchBtnList.length; i++) {
					await Promise.all([
						page.waitForNavigation({waitUntil: "networkidle2"}),
						searchBtnList[i].click()
					]);
					
					// 専門医名を取得
					var kenXpath = '//*[@id="result"]/table[1]/tbody/tr/td[1]/h5/span/strong';
					await page.waitForXPath(kenXpath);
					var ken = await (await (await page.$x(kenXpath))[0].getProperty('innerHTML')).jsonValue();
					var count = 0;
					
					// 都道府県毎に登録されている人数を取得
					numberOfPeopleXpath = '//div[@id="main_contents"]/div/p/span'
					var numberOfPeople = await (await (await page.$x(numberOfPeopleXpath))[0].getProperty('innerHTML')).jsonValue();
					var numberOfPeople = numberOfPeople.replace('現在&nbsp;', '')
					logger.info(ken + '：[登録件数：' + numberOfPeople + ']');
					
					// 資格名を取得
					var sikakuXpath = '//*[@id="main"]/h2/img';
					var sikaku = await (await (await page.$x(sikakuXpath))[0].getProperty('alt')).jsonValue();
					sikaku = sikaku.replace('をさがす', '')
					
					var nextPageFlg = true;
					do {
						// 何件目を表示してる以下LOGに表示
						var loadCountXpath = '//table[@class ="searchinfo"]/tbody/tr/td[@class="count"]/span';
						var loadCount = await (await(await page.$x(loadCountXpath))[0].getProperty('textContent')).jsonValue();
						logger.info(ken + '：[' + loadCount.replace('\n', '').replace(/	/g, '').trim() + ']を表示中');
						// 氏名の取得
						var nameListXpath = '//*[@id="doctors_list"]/tbody/tr/td/span/a';
						var nameList = await page.$x(nameListXpath);
						var dt = new Date();
						var formatted = dt.toFormat("YYYY/MM/DD HH24:MI.SS");
						for (var j = 0; j < nameList.length; j++) {
							nameList = await page.$x(nameListXpath);
							var value = await (await nameList[j].getProperty('textContent')).jsonValue();
							var kinmu = '';
							
							// 氏名を押下
							await Promise.all([
								page.waitForNavigation({waitUntil: ["domcontentloaded", "networkidle2"]}),
								nameList[j].click()
							]);
							
							// 勤務先の取得
							xpath = '//*[@id="detail"]/table/tbody/tr[2]/td';
							kinmu = await (await (await page.$x(xpath))[0].getProperty('textContent')).jsonValue();
							
							// 海外の施設名の場合「,」がふうまれている場合が有るので[.]に変換
							if (kinmu.indexOf(',') != -1){
								kinmu = kinmu.replace(/,/g, '.');
							}
							
							csvFormat.setCsvDate(filePath, sikaku, ken, kinmu, value, seq, formatted);
							allCounter = allCounter  +1;
							seq++;
							count = count + 1
							// 検索結果に戻るボタンを押下
							var detailBackBtnXpath = '//*[@id="detail"]/p/span/a';
							await page.waitForXPath(detailBackBtnXpath);
							const detailBackBtn = await page.$x(detailBackBtnXpath);
							await Promise.all([
								page.waitForNavigation({waitUntil: ["domcontentloaded", "networkidle2"]}),
								detailBackBtn[0].click()
							]);
						}
						// 次のページボタンを押下
						var pageLinkBottonXpath = '//table[@class="prev_next"]/tbody/tr/td[@class="return" or @class="next"]/a'
						var nextBtn = await page.$x(pageLinkBottonXpath);
						if(nextBtn.length == 2) {
							await Promise.all([
								// page.waitForNavigation({waitUntil: "networkidle2"}),
								page.waitForNavigation({waitUntil: ["domcontentloaded", "networkidle2"]}),
								nextBtn[1].click()
							]);
						} else {
							nextPageFlg = false;
						}
					} while(nextPageFlg == true);
					logger.info(ken + '：[' + count + '（取得人数）/' + numberOfPeople + '（登録人数）]')
					
					//back result
					var backBtnXpath = '//*[@id=\"result\"]/table[3]/tbody/tr/td[2]/a';
					await page.waitForXPath(backBtnXpath);
					const backBtn = await page.$x(backBtnXpath);
					await Promise.all([
						// page.waitForNavigation({waitUntil: "networkidle2"}),
						page.waitForNavigation({waitUntil: ["domcontentloaded", "networkidle2"]}),
						backBtn[0].click()
					]);
					
					//reset
					searchBtnList = await page.$x(searchBtnXpath);
				}
				logger.info('取得件数：' + allCounter);
				// csv⇒Excel
				csvConverter.PythonShellCsvConverter(filePath, name, code, today, logger);
			} catch(e) {
				// エラー出力
				logger.error(e)
				
				// ブラウザを閉じて終了
				await browser.close();
				process.exit(200);
			}
			
			// ブラウザを閉じて終了
			await browser.close();
		})();
	}
}