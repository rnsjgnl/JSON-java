require('date-utils');
const puppeteer = require('puppeteer');
var fs = require('fs');
var seq = 1;
var robotsParser = require('../Utils/robotsParser');
var csvFormat = require('../Utils/csvFormat');
var csvConverter = require('../CallPython/CallPythonSell');
var convertDir = 'data';
var today = new Date().toFormat("YYYYMMDD");

exports.accessPage = async function accessPage(accessURL, headless, code, name, logger) {
	// robots.txtチェック
	robotsResult = await robotsParser.robotsTextSearch(accessURL, logger);
	if(robotsResult == true){
		( async () => {
			logger.info('クローラ起動')
			// ブラウザ起動と設定
			const browser = await puppeteer.launch({
				headless: headless,
				args: [
					'--window-size=1600,950',
					'--window-position=100,50',
					'--no-sandbox',
					'--disable-setuid-sandbox'
				]
			});
			const page = await browser.newPage();
			
			// ディレクトリ+ファイル名
			var filePath = convertDir + '/' + code + '_' + name + '_' + today + '.csv'
			logger.info('出力ディレクトリ：' + convertDir + '/');
			logger.info('出力ファイル名：' + code + '_' + name + '_' + today + '.csv');
			
			// 同名ファイル存在チェック
			if(fs.existsSync(filePath)){
				logger.info('同名ファイル存在チェック：' + fs.existsSync(filePath));
				logger.info('ファイル削除');
				fs.unlinkSync(filePath);
				logger.info('同名ファイル存在チェック：' + fs.existsSync(filePath));
			}
			
			try {
				logger.info('クロール開始');
				// ヘッダーの設定
				csvFormat.setCsvHedFormat(filePath);
				
				await page.setViewport({width: 1600, height: 950});
				await page.goto(accessURL, {waitUntil: 'networkidle2', timeout: 5000});
				
				// ページのスクショ
				await page.screenshot({path: 'screenshotData/' + code + '_' + name + '.jpg', fullPage: true});
				
				// サイト掲載日と登録件数の取得
				var publicationDateXpath = '//table[@align="center"][2]/tbody/tr[1]/td[1]';
				await page.waitForXPath(publicationDateXpath);
				const publicationDateItem = await page.$x(publicationDateXpath);
				var publicationDateAndnumberOfEntries = await (await publicationDateItem[0].getProperty('textContent')).jsonValue();
				var publicationDateAndnumberOfEntries = publicationDateAndnumberOfEntries.split('\n');
				publicationDate = publicationDateAndnumberOfEntries[0].replace('\n','');
				numberOfEntries = publicationDateAndnumberOfEntries[1].replace('\n','');
				logger.info('掲載日：' + publicationDate);
				logger.info('登録件数：' + numberOfEntries);
				
				// 都道府県ごとにクリック
				var searchBtnXpath = '//td[a[@name="top"]]//table[4]//tbody/tr[@valign="top"]/td/a';
				await page.waitForXPath(searchBtnXpath);
				const searchBtnList = await page.$x(searchBtnXpath);
				for (var i = 0; i < searchBtnList.length; i++) {
					if(i != 0){
						// 再度パス指定
						searchBtnXpath = '//body[a[@name="top"]]//td[@valign="top"]/table[2]//tr[2]/td/a';
						const searchBtn = await page.$x(searchBtnXpath);
						await Promise.all([
							page.waitForNavigation({waitUntil: "networkidle2"}),
							searchBtn[i].click()
						]);
					} else {
						await Promise.all([
							page.waitForNavigation({waitUntil: "networkidle2"}),
							searchBtnList[i].click()
						]);
					}
					// 専門医名を取得
					var xpath = '//body[a[@name="top"]]//td[@valign="top"]/table[1]/tbody//tbody/tr/td';
					const nameList = await page.$x(xpath);
					
					var dt = new Date();
					var formatted = dt.toFormat("YYYY/MM/DD HH24:MI.SS");
					for (var j = 0; j < nameList.length; j++) {
						if(j == 0){
							var kent = await (await nameList[j].getProperty('innerHTML')).jsonValue();
							ken = kent.replace('<b>', '').replace('</b>', '');
							var sikaku = "専門医";
							continue;
						}
						var value = await (await nameList[j].getProperty('innerHTML')).jsonValue();
						if(value == '<br>'){
							continue
						}
						// 氏名+（勤務先）判定
						if (value.match(/\(財\)|\（財\）/g)){
							var strtindex = value.indexOf('（');
						}else{
							var strtindex = value.lastIndexOf('（');
						}
						var kinmu = "";
						if(strtindex > 0){
							var endindex = value.length;
							kinmu = value.substring(strtindex +1, endindex -1);
							var value = value.substring(0,strtindex);
						}
						csvFormat.setCsvDate(filePath, sikaku, ken, kinmu, value, seq, formatted);
						seq++;
					}
				}
				// csv⇒Excel
				csvConverter.PythonShellCsvConverter(filePath, name, code, today, logger);
			} catch(e) {
				// エラー出力
				logger.error(e)
				// ブラウザを閉じて終了
				await browser.close();
				process.exit(200);
			}
			// ブラウザを閉じて終了
			await browser.close();
			logger.info('クロール終了');
		})();
	}
}