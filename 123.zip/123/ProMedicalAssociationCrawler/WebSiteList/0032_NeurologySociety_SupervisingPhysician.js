require('date-utils');
const puppeteer = require('puppeteer');
var fs = require('fs');
var seq = 1;
var robotsParser = require('../Utils/robotsParser');
var csvFormat = require('../Utils/csvFormat');
var csvConverter = require('../CallPython/CallPythonSell');
var convertDir = 'data';
var today = new Date().toFormat("YYYYMMDD");
var allCounter = 0;

exports.accessPage = async function accessPage(accessURL, headless, code, name, logger) {
	// robots.txtチェック
	robotsResult = await robotsParser.robotsTextSearch(accessURL, logger);
	if(robotsResult == true){
		( async () => {
			logger.info('クローラ起動')
			// ブラウザ起動と設定
			const browser = await puppeteer.launch({
				headless: headless,
				args: [
					'--window-size=1600,950',
					'--window-position=100,50',
					'--no-sandbox',
					'--disable-setuid-sandbox'
				]
			});
			const page = await browser.newPage();
			// ディレクトリ+ファイル名
			var filePath = convertDir + '/' + code + '_' + name + '_' + today + '.csv';
			logger.info('出力ディレクトリ：' + convertDir + '/');
			logger.info('出力ファイル名：' + code + '_' + name + '_' + today + '.csv');
			// 同名ファイル存在チェック
			if(fs.existsSync(filePath)){
				logger.info('同名ファイル存在チェック：' + fs.existsSync(filePath));
				logger.info('ファイル削除');
				fs.unlinkSync(filePath);
				logger.info('同名ファイル存在チェック：' + fs.existsSync(filePath));
			}
			
			try {
				logger.info('クロール開始');
				// ヘッダーの設定
				csvFormat.setCsvHedFormat(filePath);
				// ページの読込
				await page.setViewport({width: 1600, height: 950});
				await page.goto(accessURL, {waitUntil: 'networkidle2', timeout: 5000});
				// 資格名の取得
				var sikaku = '指導医';
				// 都道府県
				var pageListXpath = '//table/tbody/tr[td[@class="KenLinkS"]]/td/a';
				await page.waitForXPath(pageListXpath);
				var pageList = await page.$x(pageListXpath);
				for(var i = 0 ; i < pageList.length; i ++){
					// 都道府県名の取得
					var ken = await (await pageList[i].getProperty('textContent')).jsonValue();
					// 都道府県を押下
					await Promise.all([
						page.waitForNavigation({waitUntil: "networkidle2"}),
						pageList[i].click()
					]);
					var count = 0;
					// サイト掲載日と登録件数の取得
					var publicationDateAndnumberOfEntriesXpath = '//p[@class="count"]';
					await page.waitForXPath(publicationDateAndnumberOfEntriesXpath);
					const publicationDateAndnumberOfEntriesItem = await page.$x(publicationDateAndnumberOfEntriesXpath);
					var publicationDateAndnumberOfEntries = await (await publicationDateAndnumberOfEntriesItem[0].getProperty('textContent')).jsonValue()
					var publicationDateAndnumberOfEntries = publicationDateAndnumberOfEntries.split('名');
					var publicationDate = publicationDateAndnumberOfEntries[1].replace('\n','').replace('現在', '');
					var numberOfEntries = publicationDateAndnumberOfEntries[0].replace('\n','').replace('名', '');
					logger.info('登録件数:[' + ken + '：' + numberOfEntries + ' ,記載日:' + publicationDate + ']');
					// ページのスクショ
					await page.screenshot({path: 'screenshotData/' + code + '_' + name + '_' + ken + '.jpg', fullPage: true});
					// 地域でまとめている場合
					var openNameListXpath = '//span[@class="municipalityName allName"]/a';
					const openNameList = await page.$x(openNameListXpath);
					if(openNameList.length != 0){
						await Promise.all([
							page.waitForNavigation({waitUntil: "networkidle2"}),
							openNameList[0].click()
						])  
					}
					// 専門医名を取得
					var hospitalListXpath = '//table/tbody/tr/td/h4';
					const hospitalList = await page.$x(hospitalListXpath);
					var dt = new Date();
					var formatted = dt.toFormat("YYYY/MM/DD HH24:MI.SS");
					for (var j = 0; j < hospitalList.length; j++) {
						// 施設名の取得
						var kinmu = await (await hospitalList[j].getProperty('textContent')).jsonValue();
						// 氏名の取得
						const nameListXpath = 'following-sibling::div[1]/span';
						var nameList = await( await hospitalList[j].$x(nameListXpath));
						if(nameList.length != 0){
							for(var k =0; k <nameList.length; k++){
								var value = await (await nameList[k].getProperty('textContent')).jsonValue();
								if(value != " "){
									csvFormat.setCsvDate(filePath, sikaku, ken, kinmu, value, seq, formatted);
									allCounter = allCounter  +1;
									count = count +1
									seq++;
								}
							}
						}
					}
					logger.info('取得件数:[' + ken + '：' + count +']');
					// 地域でまとめられている都道府県の場合、戻るボタンを押下
					if(openNameList.length != 0){
						var backButton2Xpaht = '//*[@id="container"]/table/tbody/tr/td/p[1]/a';
						await page.waitForXPath(backButton2Xpaht);
						const backButton2 = await page.$x(backButton2Xpaht);
						await Promise.all([
							page.waitForNavigation({waitUntil: "networkidle2"}),
							backButton2[0].click()
						]);
					}
					// 戻るボタン
					var backButtonXpaht = '//*[@id="container"]/table/tbody/tr/td/p[1]/a'
					await page.waitForXPath(backButtonXpaht);
					const backButton = await page.$x(backButtonXpaht);
					await Promise.all([
						page.waitForNavigation({waitUntil: "networkidle2"}),
						backButton[0].click()
					]);
					// 都道府県の再取得
					await page.waitForXPath(pageListXpath);
					var pageList = await page.$x(pageListXpath);
				}
				logger.info('総取得件数：' + allCounter);
				// csv⇒Excel
				csvConverter.PythonShellCsvConverter(filePath, name, code, today, logger);
			} catch(e) {
				// エラー出力
				logger.error(e)
				
				// ブラウザを閉じて終了
				await browser.close();
				process.exit(200);
			}
			// ブラウザを閉じて終了
			await browser.close();
		})();
	}
}