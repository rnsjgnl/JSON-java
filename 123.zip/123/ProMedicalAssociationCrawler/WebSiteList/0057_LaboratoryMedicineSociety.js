const puppeteer = require('puppeteer');
const http = require('http');
const https = require('https');
const fs = require('fs');
var robotsParser = require('../Utils/robotsParser');
var csvConverter = require('../CallPython/CallPythonSell');
var convertDir = 'pdfData';
var today = new Date().toFormat("YYYYMMDD");
var pdfCrawle = '0057_PDF_Crawler.py'

exports.accessPage = async function accessPage(accessURL, headless, code, name, logger) {
	// robots.txtチェック
	robotsResult = await robotsParser.robotsTextSearch(accessURL, logger);
	if(robotsResult == true){
		( async () => {
			logger.info('クローラ起動')
			// ブラウザ起動と設定
			const browser = await puppeteer.launch({
				headless: headless,
				args: [
					'--window-size=1600,950',
					'--window-position=100,50',
					'--no-sandbox',
					'--disable-setuid-sandbox'
				]
			});
			const page = await browser.newPage();
			
			try {
				await page.setViewport({width: 1600, height: 950});
				await page.goto(accessURL, {waitUntil: 'networkidle2', timeout: 10000});
				// ページのスクショ
				await page.screenshot({path: 'screenshotData/' + code + '_' + name + '.jpg', fullPage: true});
				// PDF
				var pdfFilePath = []
				// PDFのリンクが取得出来るか
				try {
					var searPdfXpath = '//h3/following-sibling::div[1]//a[contains(text(),"専門医") and not(contains(text(),"名誉"))]'
					await page.waitForXPath(searPdfXpath);
					const pdfbtn = await page.$x(searPdfXpath);
					for(var i = 0; i < pdfbtn.length; i ++){
						var PDFLink = await (await pdfbtn[i].getProperty('href')).jsonValue();
						var pdfName = await (await pdfbtn[i].getProperty('textContent')).jsonValue()
						// PDFの取得
						logger.info('PDF名前', pdfName,':PDFリンク', PDFLink);
						pdfName = pdfName.replace(/\（[0-9]{4}年[0-9]{1}月[0-9]{1}日\）/g, '')
						pdfName = pdfName.replace(/(日本専門医機構|日本臨床検査医学会)/g,'').trim();
						pdfFilePath.push(convertDir + '/' + code + '_' + pdfName + '_' + today + '.pdf');
						var download = (url, dlpdf, cb) => {
							var file = fs.createWriteStream(dlpdf);
							var request = https.get(url, (response) => {
								if (response.statusCode !== 200) {
									return cb('Response status was ' + response.statusCode);
								}
								response.pipe(file);
							});
							file.on('finish', () => file.close(cb));
							request.on('error', (err) => {
								fs.unlink(dlpdf);
								return cb(err.message);
							});
							file.on('error', (err) => {
								fs.unlink(dlpdf);
								return cb(err.message);
							});
						};
						download(PDFLink, pdfFilePath[i]);
					} 
				} catch (TimeoutError) {
					logger.error(TimeoutError.message)
					logger.info('PDF格納フォルダに格納されているPDFを使用します。')
					pdfFilePath.push(convertDir + '/' + '0057_臨床検査専門医.pdf');
					pdfFilePath.push(convertDir + '/' + '0057_基本領域 臨床検査専門医.pdf');
				}
				csvConverter.PythonShellPdfCrawler(pdfCrawle, pdfFilePath, name, code, today, logger);
			} catch(e) {
				// エラー出力
				logger.error(e);
				// ブラウザを閉じて終了
				await browser.close();
				process.exit(200);
			}
			// ブラウザを閉じて終了
			await browser.close();
		})();
	}
}