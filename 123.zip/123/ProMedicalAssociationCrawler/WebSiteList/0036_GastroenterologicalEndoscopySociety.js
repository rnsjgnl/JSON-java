const puppeteer = require('puppeteer');
// const http = require('http');
const https = require('https');
const fs = require('fs');
var robotsParser = require('../Utils/robotsParser');
var csvConverter = require('../CallPython/CallPythonSell');
var convertDir = 'pdfData';
var today = new Date().toFormat("YYYYMMDD");
var pdfCrawle = '0036_PDF_Crawler.py'

exports.accessPage = async function accessPage(accessURL, headless, code, name, logger) {
	
	// 動的PDF表示の為PDF格納ディレクトリを連携
	try{
		var pdfFiledir = convertDir + '/' + code + '_' + name
		// PDFディレクトリが存在するかチェック
		if(fs.existsSync(pdfFiledir)){
			logger.info('0036_消化器内視鏡専門医' + fs.existsSync(pdfFiledir))
			var pdfFilePath = []
			pdfFilePath.push(convertDir + '/' + code + '_' + name)
			csvConverter.PythonShellPdfCrawler(pdfCrawle, pdfFilePath, name, code, today, logger);
		} else{
			logger.info('[0036_消化器内視鏡専門医]フォルダが存在しません。')
		}
	} catch(e) {
		logger.error(e);
	}
}