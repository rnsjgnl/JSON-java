require('date-utils');
const puppeteer = require('puppeteer');
var fs = require('fs');
var seq = 1;
var robotsParser = require('../Utils/robotsParser');
var csvFormat = require('../Utils/csvFormat');
var csvConverter = require('../CallPython/CallPythonSell');
var convertDir = 'data';
var today = new Date().toFormat("YYYYMMDD");
var allCounter = 0;

exports.accessPage = async function accessPage(accessURL, headless, code, name, logger) {
	// robots.txtチェック
	robotsResult = await robotsParser.robotsTextSearch(accessURL, logger);
	if(robotsResult == true){
		( async () => {
			logger.info('クローラ起動')
			// ブラウザ起動と設定
			const browser = await puppeteer.launch({
				headless: headless,
				args: [
					'--window-size=1600,950',
					'--window-position=100,50',
					'--no-sandbox',
					'--disable-setuid-sandbox'
				]
			});
			const page = await browser.newPage();
			
			// ディレクトリ+ファイル名
			var filePath = convertDir + '/' + code + '_' + name + '_' + today + '.csv'
			logger.info('出力ディレクトリ：' + convertDir + '/');
			logger.info('出力ファイル名：' + code + '_' + name + '_' + today + '.csv');
			
			// 同名ファイル存在チェック
			if(fs.existsSync(filePath)){
				logger.info('同名ファイル存在チェック：' + fs.existsSync(filePath))
				logger.info('ファイル削除')
				fs.unlinkSync(filePath)
				logger.info('同名ファイル存在チェック：' + fs.existsSync(filePath))
			}
			
			try {
				logger.info('クロール開始');
				// ヘッダーの設定
				csvFormat.setCsvHedFormat(filePath);
				
				await page.setViewport({width: 1600, height: 950});
				await page.goto(accessURL, {waitUntil: 'networkidle2', timeout: 5000});
				
				// 更新日
				var publicationDateXpath = '//*[@id="rightcolumn"]/div[@class="box_date"]';
				await page.waitForXPath(publicationDateXpath);
				const publicationDateItem = await page.$x(publicationDateXpath);
				var publicationDate = await (await publicationDateItem[0].getProperty('textContent')).jsonValue()
				publicationDate = publicationDate.replace('現在登録データ', '').replace('\n','');
				logger.info('掲載日：' + publicationDate);
				
				// ページのスクショ
				// await page.screenshot({path: 'screenshotData/' + code + '_' + name + '_掲載日' + '.jpg', fullPage: true});
				
				// 半角空白入力
				await page.type("#sq4", ' ');
				
				// 検索ボタンが来るまで待つ
				var searchBtnXpath = '//table[@class="search_form"]//div[@class="form_submit"]/input';
				await page.waitForXPath(searchBtnXpath);
				// 検索ボタンがクリック
				const searchBtn = await page.$x(searchBtnXpath);
				await Promise.all([
					page.waitForNavigation({waitUntil: "networkidle2"}),
					searchBtn[0].click()
				]);
				
				// 資格区分を取得
				var sikakuXpath = '//*[@id="title_senmoni"]/img';
				await page.waitForXPath(sikakuXpath);
				const sikakuItem = await page.$x(sikakuXpath);
				var sikaku = await (await sikakuItem[0].getProperty('alt')).jsonValue();
				sikaku = sikaku.replace('をさがす', '')
				
				// 登録件数
				var numberOfEntriesXpath = '//*[@id="rightcolumn"]/div[5]/b';
				await page.waitForXPath(numberOfEntriesXpath);
				const numberOfEntriesItem = await page.$x(numberOfEntriesXpath);
				var numberOfEntries = await (await numberOfEntriesItem[0].getProperty('textContent')).jsonValue();
				numberOfEntries = numberOfEntries.replace('\n','');
				logger.info('登録件数：' + numberOfEntries); 
				
				// ページのスクショ
				await page.screenshot({path: 'screenshotData/' + code + '_' + name + '.jpg', fullPage: true});
				
				// 最大ページ数の取得
				var pageMaxNmXpath = '//*[@id="rightcolumn"]/div[6]/div[2]/a/text()';
				const nextPage = await page.$x(pageMaxNmXpath);
				var pageMaxNm = nextPage.length - 1
				var maxPagenum = await (await (await nextPage[pageMaxNm]).getProperty('textContent')).jsonValue();
				for (var i = 1 ; i <= maxPagenum; i ++){
					logger.info('ページ数[' + i + '/' + maxPagenum +']')
					
					// 専門医名を取得
					var nameListXpath = '//table[@id="fdtable"]//tr[position() >1]';
					var nameList = await page.$x(nameListXpath);
					var dt = new Date();
					var formatted = dt.toFormat("YYYY/MM/DD HH24:MI.SS");
					for (var j = 0; j < nameList.length; j++) {
						var value = await (await (await nameList[j].$x('td[2]'))[0].getProperty('textContent')).jsonValue();
						var ken = await (await (await nameList[j].$x('td[1]'))[0].getProperty('textContent')).jsonValue();
						var kinmu = ''
						csvFormat.setCsvDate(filePath, sikaku, ken, kinmu, value, seq, formatted);
						seq++;
						allCounter = allCounter  +1;
					}
					// logger.info(j + '件取得')
					if(i != maxPagenum){
						// 次のページへ遷移
						var nextPageButtonXpath = '//*[@id="rightcolumn"]/div[6]//a[u[text()="»"]]'
						var nextPageButton = await page.$x(nextPageButtonXpath);
						await Promise.all([
							page.waitForNavigation({waitUntil: "networkidle2"}),
							nextPageButton[0].click()
						]);
					}
				}
				logger.info('取得件数：' + allCounter);
				// csv⇒Excel
				csvConverter.PythonShellCsvConverter(filePath, name, code, today, logger);
				
			} catch(e) {
				// エラー出力
				logger.error(e)
				
				// ブラウザを閉じて終了
				await browser.close();
				process.exit(200);
			}
			// ブラウザを閉じて終了
			await browser.close();
		})();
	}
}