const puppeteer = require('puppeteer');
const https = require('https');
const fs = require('fs');
var robotsParser = require('../Utils/robotsParser');
var csvConverter = require('../CallPython/CallPythonSell');
var convertDir = 'pdfData';
var today = new Date().toFormat("YYYYMMDD");
var pdfCrawle = '0050_PDF_Crawler.py'

exports.accessPage = async function accessPage(accessURL, headless, code, name, logger) {
	// robots.txtチェック
	robotsResult = await robotsParser.robotsTextSearch(accessURL, logger);
	if(robotsResult == true){
		( async () => {
			logger.info('クローラ起動')
			// ブラウザ起動と設定
			const browser = await puppeteer.launch({
				headless: headless,
				args: [
					'--window-size=1600,950',
					'--window-position=100,50',
					'--no-sandbox',
					'--disable-setuid-sandbox'
				]
			});
			const page = await browser.newPage();
			
			try {
				await page.setViewport({width: 1600, height: 950});
				await page.goto(accessURL, {waitUntil: 'networkidle2', timeout: 10000});
				//専門医名簿
				var specialistDoctorListXpath = '//h2[span[contains(text(),"日本臨床腫瘍学会 各種名簿")]]/following-sibling::div//a[contains(text(),"専門医名簿")]'
				var specialistDoctorListPdf = await page.waitForXPath(specialistDoctorListXpath);
				var pdfFilePath = []
				var PDFLink = await (await specialistDoctorListPdf.getProperty('href')).jsonValue();
				var pdfName = await (await specialistDoctorListPdf.getProperty('textContent')).jsonValue()
				logger.info('PDF名前', pdfName,':PDFリンク', PDFLink);
				pdfFilePath.push(convertDir + '/' + code + '_' + 'がん薬物療法専門医一覧' + '.pdf')
				var download = (url, dlpdf, cb) => {
					var file = fs.createWriteStream(dlpdf);
					var request = https.get(url, (response) => {
						if (response.statusCode !== 200) {
							return cb('Response status was ' + response.statusCode);
						}
						response.pipe(file);
					});
					file.on('finish', () => file.close(cb));
				
					request.on('error', (err) => {
						fs.unlink(dlpdf);
						return cb(err.message);
					});
					file.on('error', (err) => {
						fs.unlink(dlpdf);
						return cb(err.message);
					});
				};
				download(PDFLink, pdfFilePath[0]);
				
				//指導医名簿
				var supervisingDoctorListXpath = '//h2[span[contains(text(),"日本臨床腫瘍学会 各種名簿")]]/following-sibling::div//a[contains(text(),"指導医名簿") and not(contains(text(),"暫定"))]'
				var supervisingDoctorListPdf = await page.waitForXPath(supervisingDoctorListXpath);
				var PDFLink = await (await supervisingDoctorListPdf.getProperty('href')).jsonValue();
				var pdfName = await (await supervisingDoctorListPdf.getProperty('textContent')).jsonValue()
				logger.info('PDF名前', pdfName,':PDFリンク', PDFLink);
				pdfFilePath.push(convertDir + '/' + code + '_' + 'がん薬物療法指導医一覧' + '.pdf')
				var download = (url, dlpdf, cb) => {
					var file = fs.createWriteStream(dlpdf);
					var request = https.get(url, (response) => {
						if (response.statusCode !== 200) {
							return cb('Response status was ' + response.statusCode);
						}
						response.pipe(file);
					});
					file.on('finish', () => file.close(cb));
				
					request.on('error', (err) => {
						fs.unlink(dlpdf);
						return cb(err.message);
					});
					file.on('error', (err) => {
						fs.unlink(dlpdf);
						return cb(err.message);
					});
				};
				download(PDFLink, pdfFilePath[1]);
				
				var pdfFilePath = []
				pdfFilePath.push(convertDir + '/' + '0050_がん薬物療法指導医一覧.pdf')
				pdfFilePath.push(convertDir + '/' + '0050_がん薬物療法専門医一覧.pdf')
				
				csvConverter.PythonShellPdfCrawler(pdfCrawle, pdfFilePath, name, code, today, logger);
			} catch(e) {
				// エラー出力
				logger.error(e);
				// ブラウザを閉じて終了
				await browser.close();
				process.exit(200);
			}
			// ブラウザを閉じて終了
			await browser.close();
		})();
	}
}