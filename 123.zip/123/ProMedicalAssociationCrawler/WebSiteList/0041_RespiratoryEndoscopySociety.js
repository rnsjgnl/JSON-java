require('date-utils');
const puppeteer = require('puppeteer');
var fs = require('fs');
var seq = 1;
var robotsParser = require('../Utils/robotsParser');
var csvFormat = require('../Utils/csvFormat');
var csvConverter = require('../CallPython/CallPythonSell');
var convertDir = 'data';
var today = new Date().toFormat("YYYYMMDD");
var allCounter = 0;

exports.accessPage = async function accessPage(accessURL, headless, code, name, logger) {
	// robots.txtチェック
	robotsResult = await robotsParser.robotsTextSearch(accessURL, logger);
	if(robotsResult == true){
		( async () => {
			logger.info('クローラ起動')
			// ブラウザ起動と設定
			const browser = await puppeteer.launch({
				headless: headless,
				args: [
					'--window-size=1600,950',
					'--window-position=100,50',
					'--no-sandbox',
					'--disable-setuid-sandbox'
				]
			});
			const page = await browser.newPage();
			
			// ディレクトリ+ファイル名
			var filePath = convertDir + '/' + code + '_' + name + '_' + today + '.csv'
			logger.info('出力ディレクトリ：' + convertDir + '/');
			logger.info('出力ファイル名：' + code + '_' + name + '_' + today + '.csv');
			
			// 同名ファイル存在チェック
			if(fs.existsSync(filePath)){
				logger.info('同名ファイル存在チェック：' + fs.existsSync(filePath))
				logger.info('ファイル削除')
				fs.unlinkSync(filePath)
				logger.info('同名ファイル存在チェック：' + fs.existsSync(filePath))
			}
			
			try {
				logger.info('クロール開始');
				// ヘッダーの設定
				csvFormat.setCsvHedFormat(filePath);
				
				await page.setViewport({width: 1600, height: 950});
				await page.goto(accessURL, {waitUntil: 'networkidle2', timeout: 5000});
				
				// 検索ボタンが来るまで待つ
				var searchBtnXpath = '//input[@type="submit"]';
				await page.waitForXPath(searchBtnXpath);
				// 検索ボタンがクリック
				const searchBtn = await page.$x(searchBtnXpath);
				await Promise.all([
					page.waitForNavigation({waitUntil: "networkidle2"}),
					searchBtn[0].click()
				]);
				
				// 掲載日の取得
				var publicationDateXpath = '//*[@id="container"]/div[2]/div[1]/form/p[1]/table/tbody/tr/td/table[2]/tbody/tr[2]/td/div/font';
				await page.waitForXPath(publicationDateXpath);
				const publicationDateItem = await page.$x(publicationDateXpath);
				var publicationDate = await (await publicationDateItem[0].getProperty('textContent')).jsonValue()
				publicationDate = publicationDate.replace('\n', '').replace('現在', '');
				logger.info('掲載日：' + publicationDate);
				
				// ページのスクショ
				await page.screenshot({path: 'screenshotData/' + code + '_' + name + '.jpg', fullPage: true});
				
				// 都道府県ごとにクリック
				var searchBtnXpath = '//*[@id="container"]/div[2]/div[1]/form/p[1]/table/tbody/tr/td/table[1]/tbody/tr/td/table/tbody/tr[1]/td//img';
				await page.waitForXPath(searchBtnXpath);
				const searchBtnList = await page.$x(searchBtnXpath);
				for(var i = 0; i < searchBtnList.length; i++){
					var count = 0
					var dt = new Date();
					var formatted = dt.toFormat("YYYY/MM/DD HH24:MI.SS");
					var kinmu = "";
					var kenXpath = '//*[@id="container"]/div[2]/div[1]/form/p[1]/table/tbody/tr/td/table[1]/tbody/tr/td/table/tbody/tr/td/img'
					await page.waitForXPath(kenXpath)
					var kenItem = await page.$x(kenXpath)
					var ken =  await (await kenItem[0].getProperty('alt')).jsonValue()
					
					var nameListXpath = '//form[@name="form"]/p[1]/table/tbody/tr/td/table[position() > 1]'
					await page.waitForXPath(nameListXpath)
					var nameList = await page.$x(nameListXpath)
					for (var j = 0; j < nameList.length; j++) {
						var sidouNameListXptah = 'tbody/tr[td[contains(text(), "指導医一覧")]]/following-sibling::tr/td/table/tbody/tr/td/table/tbody/tr/td'
						var sidouNameList = await (await nameList[j].$x(sidouNameListXptah))
						if(sidouNameList.length != 0){
							var sikaku = '指導医'
							for(var k = 0; k < sidouNameList.length; k++){
								var value = await (await sidouNameList[k].getProperty('textContent')).jsonValue()
								csvFormat.setCsvDate(filePath, sikaku, ken, kinmu, value, seq, formatted);
								count = count +1;
								allCounter = allCounter +1;
								seq++;
							}
							logger.info('対象地域と取得件数：' + ken + ',' + sikaku + ',' + count)
						}
						
						var senmoniNameListXptah = 'tbody/tr[td[contains(text(), "専門医一覧")]]/following-sibling::tr/td/table/tbody/tr/td/table/tbody/tr/td'
						var senmoniNameList = await (await nameList[j].$x(senmoniNameListXptah))
						if(senmoniNameList.length != 0){
							var sikaku = '専門医'
							for(var k = 0; k < senmoniNameList.length; k++){
								var value =  await (await senmoniNameList[k].getProperty('textContent')).jsonValue()
								csvFormat.setCsvDate(filePath, sikaku, ken, kinmu, value, seq, formatted);
								count = count +1
								allCounter = allCounter +1;
								seq++;
							}
							logger.info('対象地域と取得件数：' + ken + ',' + sikaku + ',' + count)
						}
					}
					var nextButtonXptah = '//form[@name="form"]/p[1]/table/tbody/tr/td/table[1]/tbody/tr/td/table/tbody/tr[1]/td[img]/following-sibling::td[1]/a'
					var nextButton = await page.$x(nextButtonXptah)
					if(nextButton.length != 0){
						await Promise.all([
							page.waitForNavigation({waitUntil: "networkidle2"}),
							nextButton[0].click()
						]);
					}
				}
				logger.info('取得件数：' + allCounter);
				// csv⇒Excel
				csvConverter.PythonShellCsvConverter(filePath, name, code, today, logger);
			} catch(e) {
				// エラー出力
				logger.error(e);
				
				// ブラウザを閉じて終了
				await browser.close();
				process.exit(200);
			}
			// ブラウザを閉じて終了
			await browser.close();
			logger.info('クロール終了');
		})();
	}
}