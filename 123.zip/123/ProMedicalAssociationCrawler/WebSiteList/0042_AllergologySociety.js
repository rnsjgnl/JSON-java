require('date-utils');
const puppeteer = require('puppeteer');
var fs = require('fs');
var seq = 1;
var robotsParser = require('../Utils/robotsParser');
var csvFormat = require('../Utils/csvFormat');
var csvConverter = require('../CallPython/CallPythonSell');
var convertDir = 'data';
var today = new Date().toFormat("YYYYMMDD");
var allCounter = 0;

exports.accessPage = async function accessPage(accessURL, headless, code, name, logger) {
	// robots.txtチェック
	robotsResult = await robotsParser.robotsTextSearch(accessURL, logger);
	if(robotsResult == true){
		( async () => {
			logger.info('クローラ起動')
			// ブラウザ起動と設定
			const browser = await puppeteer.launch({
				headless: headless,
				args: [
					'--window-size=1600,950',
					'--window-position=100,50',
					'--no-sandbox',
					'--disable-setuid-sandbox'
				]
			});
			const page = await browser.newPage();
			
			// ディレクトリ+ファイル名
			var filePath = convertDir + '/' + code + '_' + name + '_' + today + '.csv';
			logger.info('出力ディレクトリ：' + convertDir + '/');
			logger.info('出力ファイル名：' + code + '_' + name + '_' + today + '.csv');
			
			// 同名ファイル存在チェック
			if(fs.existsSync(filePath)){
				logger.info('同名ファイル存在チェック：' + fs.existsSync(filePath));
				logger.info('ファイル削除');
				fs.unlinkSync(filePath);
				logger.info('同名ファイル存在チェック：' + fs.existsSync(filePath));
			}
			
			try {
				logger.info('クロール開始');
				// ヘッダーの設定
				csvFormat.setCsvHedFormat(filePath);
				;
				await page.setViewport({width: 1600, height: 950});
				await page.goto(accessURL, {waitUntil: 'networkidle2', timeout: 5000});
				
				// サイト掲載日の取得
				var publicationDateXpath = '//*[@id="box_main"]/article/p/strong';
				await page.waitForXPath(publicationDateXpath);
				const publicationDateItem = await page.$x(publicationDateXpath);
				var publicationDate = await (await publicationDateItem[0].getProperty('innerHTML')).jsonValue()
				var publicationDate = publicationDate.split('<br>')
				var publicationDate = publicationDate[0].replace('\n','').replace('現在認定の指導医・専門医一覧です。', '')
				logger.info('掲載日：' + publicationDate);
				
				// 登録件数
				var numberOfEntriesXpath = '//*[@id="box_main"]/article/div[2]/div[1]';
				await page.waitForXPath(numberOfEntriesXpath);
				const numberOfEntriesItem = await page.$x(numberOfEntriesXpath);
				var numberOfEntries = await (await numberOfEntriesItem[0].getProperty('innerHTML')).jsonValue()
				var numberOfEntries = numberOfEntries.split('全')
				var numberOfEntries = numberOfEntries[1]
				numberOfEntries = numberOfEntries.replace('\n','').replace(' 件)', '')
				logger.info('登録件数：' + numberOfEntries);
				
				
				// ページのスクショ
				await page.screenshot({path: 'screenshotData/' + code + '_' + name + '.jpg', fullPage: true});
				
				// 資格名の取得
				var sikaku = '専門医'
				var lasutPageFlag = false
				do{
					// 専門医名を取得
					var nameListxpath = '//*[@id="fdtable"]/tbody/tr[position() >1]';
					const nameList = await page.$x(nameListxpath);
					var dt = new Date();
					var formatted = dt.toFormat("YYYY/MM/DD HH24:MI.SS");
					for (var j = 0; j < nameList.length; j++) {
						var kinmu = '';
						var clItem =  await (await nameList[j].$x('td'));
						if(clItem.length > 1){
							var sikakuDivisiton = await (await (await nameList[j].$x('td[1]'))[0].getProperty('textContent')).jsonValue();
							if(sikakuDivisiton == "*"){
								var  sikaku = '指導医'
							} else {
								var  sikaku = '専門医'
							}
							var value = await (await (await nameList[j].$x('td[2]'))[0].getProperty('textContent')).jsonValue();
							var ken = await (await (await nameList[j].$x('td[4]'))[0].getProperty('textContent')).jsonValue();
							var tempKinmu = await (await nameList[j].$x('td[5]/a'));
							if(tempKinmu.length != 0 ){
								var kinmu = await (await (await nameList[j].$x('td[5]/a'))[0].getProperty('textContent')).jsonValue();
							} else{
								var kinmu = await (await (await nameList[j].$x('td[5]'))[0].getProperty('innerHTML')).jsonValue();
								var kinmu = kinmu.split('<br>')
								var kinmu = kinmu[0].replace('\n', '')
								if(kinmu.match(/(.)+(  )+(.)/)){
									kinmu = kinmu.replace('  ', ' ');
								}
							}
							csvFormat.setCsvDate(filePath, sikaku, ken, kinmu, value, seq, formatted);
							allCounter = allCounter  +1;
							seq++;
						}
					}
					// ページングリストの取得
					var pageListXpath = '//*[@id="box_main"]/article/div[2]/div[2]/a[u and position () >1]';
					var pageList = await page.$x(pageListXpath);
					if(pageList.length != 0){
						await Promise.all([
							page.waitForNavigation({waitUntil: "networkidle2"}),
							pageList[0].click()
						]);
					} else{
						lasutPageFlag = true;
					}
				}while(lasutPageFlag == false)
				logger.info('取得件数：' + allCounter);
				// csv⇒Excel
				csvConverter.PythonShellCsvConverter(filePath, name, code, today, logger);
			} catch(e) {
				// エラー出力
				logger.error(e)
				
				// ブラウザを閉じて終了
				await browser.close();
				process.exit(200);
			}
			// ブラウザを閉じて終了
			await browser.close();
		})();
	}
}