require('date-utils');
const puppeteer = require('puppeteer');
var fs = require('fs');
var seq = 1;
var robotsParser = require('../Utils/robotsParser');
var csvFormat = require('../Utils/csvFormat');
var csvConverter = require('../CallPython/CallPythonSell');
var convertDir = 'data';
var today = new Date().toFormat("YYYYMMDD");

exports.accessPage = async function accessPage(accessURL, headless, code, name, logger) {
	// robots.txtチェック
	robotsResult = await robotsParser.robotsTextSearch(accessURL, logger);
	if(robotsResult == true){
		( async () => {
			logger.info('クローラ起動')
			// ブラウザ起動と設定
			const browser = await puppeteer.launch({
				headless: headless,
				args: [
					'--window-size=1600,950',
					'--window-position=100,50',
					'--no-sandbox',
					'--disable-setuid-sandbox'
				]
			});
			const page = await browser.newPage();
			
			// ディレクトリ+ファイル名
			var filePath = convertDir + '/' + code + '_' + name + '_' + today + '.csv'
			logger.info('出力ディレクトリ：' + convertDir + '/');
			logger.info('出力ファイル名：' + code + '_' + name + '_' + today + '.csv');
			
			// 同名ファイル存在チェック
			if(fs.existsSync(filePath)){
				logger.info('同名ファイル存在チェック：' + fs.existsSync(filePath))
				logger.info('ファイル削除')
				fs.unlinkSync(filePath)
				logger.info('同名ファイル存在チェック：' + fs.existsSync(filePath))
			}
			
			try {
				logger.info('クロール開始');
				// ヘッダーの設定
				csvFormat.setCsvHedFormat(filePath);
				
				await page.setViewport({width: 1600, height: 950});
				await page.goto(accessURL, {waitUntil: 'networkidle2', timeout: 5000});
				
				// ページのスクショ
				await page.screenshot({path: 'screenshotData/' + code + '_' + name + '.jpg', fullPage: true});
				
				var publicationDateXpath = '//*[@id="post-3236"]/h2';
				await page.waitForXPath(publicationDateXpath);
				const publicationDateItem = await page.$x(publicationDateXpath);
				var publicationDateAndnumberOfEntries = await (await publicationDateItem[0].getProperty('textContent')).jsonValue()
				var publicationDateAndnumberOfEntries = publicationDateAndnumberOfEntries.split('　');
				publicationDate = publicationDateAndnumberOfEntries[0].replace('現在', '').replace('\n','');
				numberOfEntries = publicationDateAndnumberOfEntries[1].replace('総合内科専門医', '').replace('\n','');
				logger.info('掲載日：' + publicationDate);
				logger.info('登録件数：' + numberOfEntries);
				
				// 検索ボタンが来るまで待つ
				var searchBtnXpath = '//*[@id="content"]/div[h2[contains(text(), "専門医")]]/div/div/div/ul/li/a';
				await page.waitForXPath(searchBtnXpath);
				
				var allCounter = 0;
				
				// 検索ボタンがクリック
				var searchBtnList = await page.$x(searchBtnXpath);
				for (var i = 0; i < searchBtnList.length; i++) {
					await Promise.all([
						page.waitForNavigation({waitUntil: "networkidle2"}),
						searchBtnList[i].click()
					]);
					
					var kenXpath = '//*[@id="my_form_contents"]/h2';
					await page.waitForXPath(kenXpath);
					var ken = await (await (await page.$x(kenXpath))[0].getProperty('innerHTML')).jsonValue();
					var dt = new Date();
					var formatted = dt.toFormat("YYYY/MM/DD HH24:MI.SS");
					var sikaku = '専門医';
					var kinmu = '';
					
					// 県名
					await page.waitForXPath('//*[@id="my_form_contents"]/h2');
					const prefectures = await page.$x('//*[@id="my_form_contents"]/h2');
					var prefecturesItem = await (await prefectures[0].getProperty('textContent')).jsonValue()
					
					// 件数
					await page.waitForXPath('//*[@id="my_form_contents"]/p');
					const count = await page.$x('//*[@id="my_form_contents"]/p');
					var countItem = await (await count[0].getProperty('textContent')).jsonValue()
					logger.info('取得対象：'+ prefecturesItem + ' 件数：' + countItem);
					
					// 専門医名を取得
					var conter = 0;
					var xpath = '//*[@id=\"my_form_contents\"]/table/tbody/tr/td';
					var nameList = await page.$x(xpath);
					for (var j = 0; j < nameList.length; j++) {
						var value = await (await nameList[j].getProperty('innerHTML')).jsonValue();
						value = value.replace(/\r?\n/g, '').replace(/\t/g, '');
						if (typeof value !== 'undefined' && value !== '') {
							csvFormat.setCsvDate(filePath, sikaku, ken, kinmu, value, seq, formatted);
							seq++;
							allCounter = allCounter + 1;
							conter = conter + 1;
						}
					}
					logger.info('取得結果：' + prefecturesItem + ' 件数：' + conter);
					var nextBtn = await page.$x('//*[@id=\"panListInner\"]/ul/li[4]/a');
					await Promise.all([
						page.waitForNavigation({waitUntil: "networkidle2"}),
						nextBtn[0].click()
					]);
					//reset
					searchBtnList = await page.$x(searchBtnXpath);
				}
				logger.info('取得件数：' + allCounter);
				// csv⇒Excel
				csvConverter.PythonShellCsvConverter(filePath, name, code, today, logger);
			} catch(e) {
				// エラー出力
				logger.error(e)
				
				// ブラウザを閉じて終了
				await browser.close();
				process.exit(200);
			}
			
			// ブラウザを閉じて終了
			await browser.close();
		})();
	}
}