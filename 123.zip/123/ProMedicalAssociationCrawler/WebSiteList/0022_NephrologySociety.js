require('date-utils');
const puppeteer = require('puppeteer');
var fs = require('fs');
var seq = 1;
var robotsParser = require('../Utils/robotsParser');
var csvFormat = require('../Utils/csvFormat');
var csvConverter = require('../CallPython/CallPythonSell');
var convertDir = 'data';
var today = new Date().toFormat("YYYYMMDD");
var allCounter = 0;

// 
process.on('unhandledRejection', console.dir);

exports.accessPage = async function accessPage(accessURL, headless, code, name, logger) {
	// robots.txtチェック
	robotsResult = await robotsParser.robotsTextSearch(accessURL, logger);
	if(robotsResult == true){
		( async () => {
			logger.info('クローラ起動')
			// ブラウザ起動と設定
			const browser = await puppeteer.launch({
				headless: headless,
				args: [
					'--window-size=1600,950',
					'--window-position=100,50',
					'--no-sandbox',
					'--disable-setuid-sandbox'
				]
			});
			const page = await browser.newPage();
			
			// ディレクトリ+ファイル名
			var filePath = convertDir + '/' + code + '_' + name + '_' + today + '.csv'
			logger.info('出力ディレクトリ：' + convertDir + '/');
			logger.info('出力ファイル名：' + code + '_' + name + '_' + today + '.csv');
			
			// 同名ファイル存在チェック
			if(fs.existsSync(filePath)){
				logger.info('同名ファイル存在チェック：' + fs.existsSync(filePath))
				logger.info('ファイル削除')
				fs.unlinkSync(filePath)
				logger.info('同名ファイル存在チェック：' + fs.existsSync(filePath))
			}
			
			try {
				logger.info('クロール開始');
				// ヘッダーの設定
				csvFormat.setCsvHedFormat(filePath);
				
				await page.setViewport({width: 1600, height: 950});
				await page.goto(accessURL, {waitUntil: 'networkidle2', timeout: 50000});
				
				var searcBoxXpath = '//div[@class="contentArea"]/div/span/a'
				await page.waitForXPath(searcBoxXpath);
				const searcBoxItem = await page.$x(searcBoxXpath);
				var searcBox = await (await searcBoxItem[0].getProperty('href')).jsonValue();
				// ページ遷移
				await page.goto(searcBox, {waitUntil: 'networkidle2', timeout: 50000});
				
				// ページのスクショ
				await page.screenshot({path: 'screenshotData/' + code + '_' + name + '.jpg', fullPage: true});
				
				// 登録件数
				var numberOfEntriesXpath = '//div[@class="dataTables_info"]';
				await page.waitForXPath(numberOfEntriesXpath);
				const numberOfEntriesItem = await page.$x(numberOfEntriesXpath);
				var numberOfEntries = await (await numberOfEntriesItem[0].getProperty('textContent')).jsonValue();
				numberOfEntries = numberOfEntries.split('件中');
				logger.info('登録件数：' + numberOfEntries[0]);
				
				// 表示件数の変更
				await page.waitForXPath('//select[@name="list_length"]');
				await page.select('select[name="list_length"]', '100');
				
				// 最大ページ数
				var pageListXpath = '//*[@id="list_paginate"]//li[@class="paginate_button "]/a';
				const pageList =  await page.$x(pageListXpath);
				var num = pageList.length -1;
				var pageListNm = await (await pageList[num].getProperty('textContent')).jsonValue();
					
				for(var i = 0; i < pageListNm ; i++){
					logger.info("処理状況[" + (i + 1) + '(ページ番号)/' + pageListNm + '(総ページ数)]')
					// 専門医名を取得
					var xpath = '//*[@id="list"]/tbody/tr';
					const nameList = await page.$x(xpath);
					var dt = new Date();
					var formatted = dt.toFormat("YYYY/MM/DD HH24:MI.SS");
					for (var j = 0; j < nameList.length; j++) {
						var value = await (await (await (await nameList[j].$x('td[1]'))[0].getProperty('textContent')).jsonValue()).trim();
						var kinmu = await (await (await (await nameList[j].$x('td[3]'))[0].getProperty('textContent')).jsonValue()).trim();
						var kamoku = await (await (await (await nameList[j].$x('td[4]'))[0].getProperty('textContent')).jsonValue()).trim();
						if (kamoku != ''){
							var kinmu = kinmu + kamoku
						}
						
						var ken = ''
						var address = await (await (await nameList[j].$x('td[6]'))[0].getProperty('textContent')).jsonValue();
						if (address != ''){
							var pattern = /^(.){2}(道)|^(.){2}(都)|^(.){2}(府)|^(.){2,3}(県)/;
							if(address.match(pattern)){
								ken = address.match(pattern)[0].trim()
							} else {
								ken = address.trim()
							}
						} else {
							ken = '01'
						}
						
						var sikaku = '専門医'
						csvFormat.setCsvDate(filePath, sikaku, ken, kinmu, value, seq, formatted);
						allCounter = allCounter + 1;
						seq++;
					}
					if(i < pageListNm){
						var nextPageButtonXpath = '//*[@id="list_next"]/a';
						var flag = new Boolean(false);
						do {
							const nextPageButton = await page.$x(nextPageButtonXpath);
							if(nextPageButton.length != 0){
								flag = true
								await page.waitFor(3000);
								await nextPageButton[0].click();
							}
						} while(!flag)
					}
				}
				logger.info('取得件数：' + allCounter);
				// csv⇒Excel
				csvConverter.PythonShellCsvConverter(filePath, name, code, today, logger);
				
			} catch(e) {
				// エラー出力
				logger.error(e)
				
				// ブラウザを閉じて終了
				await browser.close();
				process.exit(200);
			}
			// ブラウザを閉じて終了
			await browser.close();
		})();
	}	
}