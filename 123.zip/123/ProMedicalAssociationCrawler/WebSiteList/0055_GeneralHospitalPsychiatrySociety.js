const puppeteer = require('puppeteer');
const http = require('http');
const fs = require('fs');
var robotsParser = require('../Utils/robotsParser');
var csvConverter = require('../CallPython/CallPythonSell');
var convertDir = 'pdfData';
var today = new Date().toFormat("YYYYMMDD");
var pdfCrawle = '0055_PDF_Crawler.py'

exports.accessPage = async function accessPage(accessURL, headless, code, name, logger) {
	// robots.txtチェック
	robotsResult = await robotsParser.robotsTextSearch(accessURL, logger);
	if(robotsResult == true){
		( async () => {
			logger.info('クローラ起動')
			// ブラウザ起動と設定
			const browser = await puppeteer.launch({
				headless: headless,
				args: [
					'--window-size=1600,950',
					'--window-position=100,50',
					'--no-sandbox',
					'--disable-setuid-sandbox'
				]
			});
			const page = await browser.newPage();
			
			try {
				await page.setViewport({width: 1600, height: 950});
				await page.goto(accessURL, {waitUntil: 'networkidle2', timeout: 10000});
				
				// pdf
				var pdfFilePath = []
				var searPdfXpath = '//div[@class="list01"]/ul/li/a[span[text()="専門医・指導医リスト"]]'
				var pdfbtn = await page.waitForXPath(searPdfXpath);
				var PDFLink = await (await pdfbtn.getProperty('href')).jsonValue();
				var pdfName = await (await pdfbtn.getProperty('textContent')).jsonValue()
				
				// ページのスクショ
				await page.screenshot({path: 'screenshotData/' + code + '_' + name + '.jpg', fullPage: true});
				
				// PDFの取得
				if (pdfbtn != null){
					var PDFLink = await (await pdfbtn.getProperty('href')).jsonValue();
					var pdfName = await (await pdfbtn.getProperty('textContent')).jsonValue();
					logger.info('PDF名前', pdfName,':PDFリンク', PDFLink);
					pdfFilePath.push(convertDir + '/' + code + '_' + name + '_' + today + '.pdf');
					
					var download = (url, dlpdf, cb) => {
						var file = fs.createWriteStream(dlpdf);
						var request = http.get(url, (response) => {
							if (response.statusCode !== 200) {
								return cb('Response status was ' + response.statusCode);
							}
							response.pipe(file);
						});
						file.on('finish', () => file.close(cb));
						request.on('error', (err) => {
							fs.unlink(dlpdf);
							return cb(err.message);
						});
						file.on('error', (err) => {
							fs.unlink(dlpdf);
							return cb(err.message);
						});
					};
					download(PDFLink, pdfFilePath[0]);
				}
				csvConverter.PythonShellPdfCrawler(pdfCrawle, pdfFilePath, name, code, today, logger);
			} catch(e) {
				// エラー出力
				logger.error(e);
				// ブラウザを閉じて終了
				await browser.close();
				process.exit(200);
			}
			// ブラウザを閉じて終了
			await browser.close();
		})();
	}
}