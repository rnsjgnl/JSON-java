const puppeteer = require('puppeteer');
const http = require('http');
const fs = require('fs');
var robotsParser = require('../Utils/robotsParser');
var csvConverter = require('../CallPython/CallPythonSell');
var convertDir = 'pdfData';
var today = new Date().toFormat("YYYYMMDD");
var pdfCrawle = '0044_PDF_Crawler.py'

exports.accessPage = async function accessPage(accessURL, headless, code, name, logger) {
	// robots.txtチェック
	robotsResult = await robotsParser.robotsTextSearch(accessURL, logger);
	if(robotsResult == true){
		( async () => {
			logger.info('クローラ起動')
			// ブラウザ起動と設定
			const browser = await puppeteer.launch({
				headless: headless,
				args: [
					'--window-size=1600,950',
					'--window-position=100,50',
					'--no-sandbox',
					'--disable-setuid-sandbox'
				]
			});
			const page = await browser.newPage();
			
			try {
				await page.setViewport({width: 1600, height: 950});
				await page.goto(accessURL, {waitUntil: 'networkidle2', timeout: 10000});
				
				// ディレクトリ+ファイル名
				var pdfFilePath = convertDir + '/' + code + '_' + name + '_' + today + '.pdf'
				
				// PDFボタンが来るまで待つ
				var searchBtnXpath = '//*[@id=\"main\"]/article/section/ul/li/a';
				await page.waitForXPath(searchBtnXpath);
				// PDFボタンがクリック
				const searchBtn = await page.$x(searchBtnXpath);
				var PDFLink = await (await searchBtn[0].getProperty('href')).jsonValue();
				logger.info('PDFリンク', PDFLink);
				
				const download = (url, pdfFilePath, cb) => {
					const file = fs.createWriteStream(pdfFilePath);
					const request = http.get(url, (response) => {
						if (response.statusCode !== 200) {
							return cb('Response status was ' + response.statusCode);
						}
						response.pipe(file);
					});
					
					file.on('finish', () => file.close(cb));
					
					request.on('error', (err) => {
						fs.unlink(pdfFilePath);
						return cb(err.message);
					});
					
					file.on('error', (err) => {
						fs.unlink(pdfFilePath);
						return cb(err.message);
					});
				};
				var cb = '';
				download(PDFLink, pdfFilePath, cb);
				logger.info('PDFタウンロード終了');
				// csv⇒Excel
				csvConverter.PythonShellPdfCrawler(pdfCrawle, pdfFilePath, name, code, today, logger);
			} catch(e) {
				// エラー出力
				logger.error(e);
				
				// ブラウザを閉じて終了
				await browser.close();
				process.exit(200);
			}
			// ブラウザを閉じて終了
			await browser.close();
		})();
	}
}