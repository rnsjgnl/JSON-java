require('date-utils');
const puppeteer = require('puppeteer');
var fs = require('fs');
var seq = 1;
var robotsParser = require('../Utils/robotsParser');
var csvFormat = require('../Utils/csvFormat');
var csvConverter = require('../CallPython/CallPythonSell');
var convertDir = 'data';
var today = new Date().toFormat("YYYYMMDD");
var allCounter = 0;

exports.accessPage = async function accessPage(accessURL, headless, code, name, logger) {
	// robots.txtチェック
	robotsResult = await robotsParser.robotsTextSearch(accessURL, logger);
	if(robotsResult == true){
		( async () => {
			logger.info('クローラ起動')
			// ブラウザ起動と設定
			const browser = await puppeteer.launch({
				headless: headless,
				args: [
					'--window-size=1600,950',
					'--window-position=100,50',
					'--no-sandbox',
					'--disable-setuid-sandbox'
				]
			});
			const page = await browser.newPage();
			
			// ディレクトリ+ファイル名
			var filePath = convertDir + '/' + code + '_' + name + '_' + today + '.csv'
			logger.info('出力ディレクトリ：' + convertDir + '/');
			logger.info('出力ファイル名：' + code + '_' + name + '_' + today + '.csv');
			
			// 同名ファイル存在チェック
			if(fs.existsSync(filePath)){
				logger.info('同名ファイル存在チェック：' + fs.existsSync(filePath))
				logger.info('ファイル削除')
				fs.unlinkSync(filePath)
				logger.info('同名ファイル存在チェック：' + fs.existsSync(filePath))
			}
			
			try {
				logger.info('クロール開始');
				// ヘッダーの設定
				csvFormat.setCsvHedFormat(filePath);
				
				await page.setViewport({width: 1600, height: 950});
				await page.goto(accessURL, {waitUntil: 'networkidle2', timeout: 5000});
				
				// 検索ボタンが車で待つ
				var searcBoxXpath = '//div[@class="page_content"]/div/iframe'
				await page.waitForXPath(searcBoxXpath);
				const searcBoxItem = await page.$x(searcBoxXpath);
				var searcBox = await (await searcBoxItem[0].getProperty('src')).jsonValue();
				
				// 資格区分の取得
				var sikakuXpath = '//*[@id="page_ttl_wrapper"]/div/h2'
				const sikakuName = await page.$x(sikakuXpath);
				var sikaku = await (await (await sikakuName[0]).getProperty('textContent')).jsonValue();
				sikaku = sikaku.replace('名簿', '')
				
				// ページ遷移
				await page.goto(searcBox, {waitUntil: 'networkidle2', timeout: 5000});
				
				// テキストボックス
				await page.waitForXPath('//input[@name="keys1"]');
				await page.type('input[name=keys1]', ' ');
				
				// 表示件数の変更
				await page.waitForXPath('//select[@name="print"]');
				await page.select('select[name="print"]', '100');
				
				// 検索ボタンがクリック
				var searchBtnXpath = '//input[@name="cmdKensaku"]'
				const searchBtn = await page.$x(searchBtnXpath);
				await Promise.all([
					page.waitForNavigation({waitUntil: "networkidle2"}),
					searchBtn[0].click()
				]);
				
				// ページのスクショ
				await page.screenshot({path: 'screenshotData/' + code + '_' + name + '.jpg', fullPage: true});
				
				// サイト掲載日の取得
				var publicationDateXpath = '//*[@id="what"]/div/div/table/tbody/tr/td[2]/div/p[2]/font';
				await page.waitForXPath(publicationDateXpath);
				const publicationDateItem = await page.$x(publicationDateXpath);
				var publicationDate = await (await publicationDateItem[0].getProperty('textContent')).jsonValue()
				publicationDate = publicationDate.replace('現在', '').replace('\n','')
				logger.info('掲載日：' + publicationDate);
				
				// 登録件数の取得
				var numberOfEntriesXpath = '//*[@id="what"]/div/div/table/tbody/tr/td[2]/div/div/p/text()';
				await page.waitForXPath(numberOfEntriesXpath);
				const numberOfEntriesItem = await page.$x(numberOfEntriesXpath);
				var numberOfEntries = await (await numberOfEntriesItem[0].getProperty('textContent')).jsonValue()
				numberOfEntries = numberOfEntries.replace(' 件該当しました。','').replace('\n','')
				logger.info('登録件数：' + numberOfEntries); 
				
				var nextSearchButtonFlg = false;
				do {
					// リストの取得
					var itemXpath = '//*[@id="what"]//div[@align="center"]/table[2]/tbody/tr[position() >2]'
					const itemList = await page.$x(itemXpath);
					for(var itemNm = 0; itemNm < itemList.length; itemNm ++){
						// 県名
						var tempKen = await (await itemList[itemNm].$x('td[@colspan="5"]'))
						if (tempKen.length >0){
							var ken = await (await tempKen[0].getProperty('textContent')).jsonValue();
							ken = ken.replace(/\n/g,'').replace(/　/g, '');
							var count = 0
						}
						
						var nameList = await (await itemList[itemNm].$x('td[not(@colspan="5")]'))
						for(var j = 0; j < nameList.length; j++){
							// 専門医名
							var kinmu = '';
							var dt = new Date();
							var formatted = dt.toFormat("YYYY/MM/DD HH24:MI.SS");
							var value = await (await (await nameList[j]).getProperty('textContent')).jsonValue();
							value = value.replace(/\n/g,'').replace(/ /g, '')
							if(value != '　'){
								csvFormat.setCsvDate(filePath, sikaku, ken, kinmu, value, seq, formatted);
								allCounter = allCounter +1;
								count =  count +1;
								seq++;
							}
						}
					}
					
					var nextSearchButtonXpath = '//*[@id="what"]/div/div/table/tbody/tr/td[2]/div/div/table[1]/tbody/tr/td[2]/a'
					const nextSearchButton = await page.$x(nextSearchButtonXpath);
					if (nextSearchButton.length == 0){
						nextSearchButtonFlg = true
					} else{
						logger.info(ken + '/' + count)
						await Promise.all([
							page.waitForNavigation({waitUntil: "networkidle2"}),
							nextSearchButton[0].click()
						]);
					}
				} while (nextSearchButtonFlg == false)
				logger.info('取得件数：' + allCounter);
				// csv⇒Excel
				csvConverter.PythonShellCsvConverter(filePath, name, code, today, logger);
			} catch(e) {
				// エラー出力
				logger.error(e)
				
				// ブラウザを閉じて終了
				await browser.close();
				process.exit(200);
			}
			// ブラウザを閉じて終了
			await browser.close();
		})();
	}
}