require('date-utils');
const puppeteer = require('puppeteer');
var fs = require('fs');
var seq = 1;
var robotsParser = require('../Utils/robotsParser');
var csvFormat = require('../Utils/csvFormat');
var csvConverter = require('../CallPython/CallPythonSell');
var convertDir = 'data';
var today = new Date().toFormat("YYYYMMDD");

exports.accessPage = async function accessPage(accessURL, headless, code, name, logger) {
	// robots.txtチェック
	robotsResult = await robotsParser.robotsTextSearch(accessURL, logger);
	if(robotsResult == true){
		( async () => {
			logger.info('クローラ起動')
			// ブラウザ起動と設定
			const browser = await puppeteer.launch({
				headless: headless,
				args: [
					'--window-size=1600,950',
					'--window-position=100,50',
					'--no-sandbox',
					'--disable-setuid-sandbox'
				]
			});
			const page = await browser.newPage();
			
			// ディレクトリ+ファイル名
			var filePath = convertDir + '/' + code + '_' + name + '_' + today + '.csv'
			logger.info('出力ディレクトリ：' + convertDir + '/');
			logger.info('出力ファイル名：' + code + '_' + name + '_' + today + '.csv');
			
			// 同名ファイル存在チェック
			if(fs.existsSync(filePath)){
				logger.info('同名ファイル存在チェック：' + fs.existsSync(filePath))
				logger.info('ファイル削除')
				fs.unlinkSync(filePath)
				logger.info('同名ファイル存在チェック：' + fs.existsSync(filePath))
			}
			
			try {
				logger.info('クロール開始');
				// ヘッダーの設定
				csvFormat.setCsvHedFormat(filePath);
				
				await page.setViewport({width: 1600, height: 950});
				await page.goto(accessURL, {waitUntil: 'networkidle2', timeout: 5000});
				
				// 都道府県ごとにクリック
				var searchBtnXpath = '//div[@class="Cyp"]/a';
				await page.waitForXPath(searchBtnXpath);
				var searchBtnList = await page.$x(searchBtnXpath);
				for (var i = 0; i < searchBtnList.length; i++) {
					await Promise.all([
						page.waitForNavigation({waitUntil: "networkidle2"}),
						searchBtnList[i].click()
					]);
					var count = 0;
					// 県名の取得
					var kenXpat = '//*[@id="container"]/div[2]/h2';
					var tempKen = await page.$x(kenXpat);
					var ken = await (await tempKen[0].getProperty('textContent')).jsonValue();
					ken = ken.replace('外科専門医名簿 （', '').replace('）' , '')
					
					// ページのスクショ
					await page.screenshot({path: 'screenshotData/' + code + '_' + name + '_' + ken +'.jpg', fullPage: true});
					
					// サイト掲載日の取得
					var publicationDateXpath = '//*[@id="container"]/div[2]/table/tbody/tr[2]/td[2]/table[1]/tbody/tr[2]/td[1]/div';
					await page.waitForXPath(publicationDateXpath);
					const publicationDateItem = await page.$x(publicationDateXpath);
					var publicationDate = await (await publicationDateItem[0].getProperty('textContent')).jsonValue()
					publicationDate = publicationDate.replace('\n','').replace(' 現在', '')
					logger.info(ken + '_掲載日：' + publicationDate);
					
					// 登録件数
					var numberOfEntriesXpath = '//*[@id="container"]/div[2]/table/tbody/tr[2]/td[2]/table[3]/tbody/tr/td/div';
					await page.waitForXPath(numberOfEntriesXpath);
					const numberOfEntriesItem = await page.$x(numberOfEntriesXpath);
					var numberOfEntries = await (await numberOfEntriesItem[0].getProperty('textContent')).jsonValue();
					numberOfEntries = numberOfEntries.replace(/\n/g ,'').replace(/	/g ,'').replace('(', '').replace(')', '');
					logger.info(ken + '_登録件数：' + numberOfEntries);

					// 専門医名を取得
					var xpath = '//*[@id="container"]/div[2]/table/tbody/tr[2]/td[2]/table[4]/tbody/tr';
					const nameList = await page.$x(xpath);
					var dt = new Date();
					var formatted = dt.toFormat("YYYY/MM/DD HH24:MI.SS");
					for (var j = 0; j < nameList.length; j++) {
						var temp_date = await( nameList[j].$x('td'))
						if(temp_date.length != 1){
							var kinmu = "";
							var sikaku = "専門医";
							for(var k = 0; k < temp_date.length; k++){
								var value = await (await temp_date[k].getProperty('textContent')).jsonValue();
								if(value != "  "){
									csvFormat.setCsvDate(filePath, sikaku, ken, kinmu, value.trim(), seq, formatted);
									count = count +1
									seq++;
								}
							}
						}
					}
					logger.info(ken + '_取得件数：' + count);
					// 検索画面に戻る
					var backBtnXpath = '//*[@id="container"]/div/div[@class="pathIn"]/a[4]';
					await page.waitForXPath(backBtnXpath);
					const backBtn = await page.$x(backBtnXpath);
					await Promise.all([
						page.waitForNavigation({waitUntil: "networkidle2"}),
						backBtn[0].click()
					]);
					await page.waitForXPath(searchBtnXpath);
					var searchBtnList = await page.$x(searchBtnXpath);
				}
				// csv⇒Excel
				csvConverter.PythonShellCsvConverter(filePath, name, code, today, logger);
			} catch(e) {
				// エラー出力
				logger.error(e);
				
				// ブラウザを閉じて終了
				await browser.close();
				process.exit(200);
			}
			// ブラウザを閉じて終了
			await browser.close();
			logger.info('クロール終了');
		})();
	}
}