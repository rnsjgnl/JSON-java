require('date-utils');
const puppeteer = require('puppeteer');
var fs = require('fs');
var seq = 1;
var robotsParser = require('../Utils/robotsParser');
var csvFormat = require('../Utils/csvFormat');
var csvConverter = require('../CallPython/CallPythonSell');
var convertDir = 'data';
var today = new Date().toFormat("YYYYMMDD");
var allCounter = 0;

exports.accessPage = async function accessPage(accessURL, headless, code, name, logger) {
	// robots.txtチェック
	robotsResult = await robotsParser.robotsTextSearch(accessURL, logger);
	if(robotsResult == true){
		( async () => {
			logger.info('クローラ起動')
			// ブラウザ起動と設定
			const browser = await puppeteer.launch({
				headless: headless,
				args: [
					'--window-size=1600,950',
					'--window-position=100,50',
					'--no-sandbox',
					'--disable-setuid-sandbox'
				]
			});
			const page = await browser.newPage();
			
			// ディレクトリ+ファイル名
			var filePath = convertDir + '/' + code + '_' + name + '_' + today + '.csv'
			logger.info('出力ディレクトリ：' + convertDir + '/');
			logger.info('出力ファイル名：' + code + '_' + name + '_' + today + '.csv');
			
			// 同名ファイル存在チェック
			if(fs.existsSync(filePath)){
				logger.info('同名ファイル存在チェック：' + fs.existsSync(filePath));
				logger.info('ファイル削除');
				fs.unlinkSync(filePath);
				logger.info('同名ファイル存在チェック：' + fs.existsSync(filePath));
			}
			
			try {
				logger.info('クロール開始');
				// ヘッダーの設定
				csvFormat.setCsvHedFormat(filePath);
				
				await page.setViewport({width: 1600, height: 950});
				await page.goto(accessURL, {waitUntil: 'networkidle2', timeout: 5000});
				
				// 登録件数
				var numberOfEntriesXpath = '//*[@id="seach"]/form/p/span';
				await page.waitForXPath(numberOfEntriesXpath);
				const numberOfEntriesItem = await page.$x(numberOfEntriesXpath);
				var numberOfEntries = await (await numberOfEntriesItem[0].getProperty('textContent')).jsonValue();
				logger.info('登録件数：' + numberOfEntries);
				
				// ページのスクショ
				await page.screenshot({path: 'screenshotData/' + code + '_' + name + '.jpg', fullPage: true});
				
				var nextSearchButtonFlg = false;
				do {
					//　現在表示されている件数を取得
					var pageXpath = '//*[@id="seach"]/form/p/text()';
					await page.waitForXPath(pageXpath);
					const pageItem = await page.$x(pageXpath);
					var pageNm = await (await pageItem[0].getProperty('textContent')).jsonValue();
					logger.info(pageNm);
					
					// 氏名の取得
					var tableListXpath = '//*[@id="seach"]/form/table'
					const tableList = await page.$x(tableListXpath);
					var dt = new Date();
					var formatted = dt.toFormat("YYYY/MM/DD HH24:MI.SS");
					for(var i = 0; i < tableList.length; i ++){
						var value = await (await (await tableList[i].$x('tbody/tr[1]/td'))[0].getProperty('textContent')).jsonValue();
						var tempvalue = value.split('＊');
						var value = tempvalue[0];
						if(tempvalue.length == 1){
							var sikaku = '専門医'
						} else {
							var sikaku = '指導医'
						}
						var kinmu = await (await (await tableList[i].$x('tbody/tr[2]/td'))[0].getProperty('textContent')).jsonValue();
						var  kinmu = kinmu.split('／')
						kinmu = kinmu[0]
						var ken = await (await (await tableList[i].$x('tbody/tr[3]/td'))[0].getProperty('textContent')).jsonValue();
						var kne = ken.split(' ')
						ken = kne[0].replace(/\n/g,'')
						csvFormat.setCsvDate(filePath, sikaku, ken, kinmu, value, seq, formatted);
						allCounter = allCounter +1;
						seq++;
					}
					
					var nextSearchButtonXpath = '//form/div[1]//li[a[not(contains(text(), "20件"))] and @class="active"]/following::a[position() = 1 and not(contains(text(), "20件"))]'
					const nextSearchButton = await page.$x(nextSearchButtonXpath);
					if (nextSearchButton.length == 0){
						nextSearchButtonFlg = true;
					} else{
						await Promise.all([
							page.waitForNavigation({waitUntil: "networkidle2"}),
							nextSearchButton[0].click()
						]);
					}
					
				} while (nextSearchButtonFlg == false)
				logger.info('取得件数：' + allCounter);
				// csv⇒Excel
				csvConverter.PythonShellCsvConverter(filePath, name, code, today, logger);
			} catch(e) {
				// エラー出力
				logger.error(e)
				
				// ブラウザを閉じて終了
				await browser.close();
				process.exit(200);
			}
			// ブラウザを閉じて終了
			await browser.close();
		})();
	}
}