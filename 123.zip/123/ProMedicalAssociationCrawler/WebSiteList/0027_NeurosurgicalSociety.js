require('date-utils');
const puppeteer = require('puppeteer');
var fs = require('fs');
var seq = 1;
var robotsParser = require('../Utils/robotsParser');
var csvFormat = require('../Utils/csvFormat');
var csvConverter = require('../CallPython/CallPythonSell');
var convertDir = 'data';
var today = new Date().toFormat("YYYYMMDD");
var allCounter = 0;

exports.accessPage = async function accessPage(accessURL, headless, code, name, logger) {
	// robots.txtチェック
	robotsResult = await robotsParser.robotsTextSearch(accessURL, logger);
	if(robotsResult == true){
		( async () => {
			logger.info('クローラ起動')
			// ブラウザ起動と設定
			const browser = await puppeteer.launch({
				headless: headless,
				args: [
					'--window-size=1600,950',
					'--window-position=100,50',
					'--no-sandbox',
					'--disable-setuid-sandbox'
				]
			});
			const page = await browser.newPage();
			
			// ディレクトリ+ファイル名
			var filePath = convertDir + '/' + code + '_' + name + '_' + today + '.csv';
			logger.info('出力ディレクトリ：' + convertDir + '/');
			logger.info('出力ファイル名：' + code + '_' + name + '_' + today + '.csv');
			
			// 同名ファイル存在チェック
			if(fs.existsSync(filePath)){
				logger.info('同名ファイル存在チェック：' + fs.existsSync(filePath));
				logger.info('ファイル削除');
				fs.unlinkSync(filePath);
				logger.info('同名ファイル存在チェック：' + fs.existsSync(filePath));
			}
			try {
				logger.info('クロール開始');
				// ヘッダーの設定
				csvFormat.setCsvHedFormat(filePath);
				
				await page.setViewport({width: 1600, height: 950});
				await page.goto(accessURL, {waitUntil: 'networkidle2', timeout: 15000});
				
				// 登録件数と掲載日
				var numberOfEntriesAndPublicationDateXpath = '//h3[contains(text(),"全国の脳神経外科専門医")]/following::p[1]';
				await page.waitForXPath(numberOfEntriesAndPublicationDateXpath);
				const numberOfEntriesAndPublicationDateItem = await page.$x(numberOfEntriesAndPublicationDateXpath);
				var tempNumberOfEntriesAndPublicationDate = await (await numberOfEntriesAndPublicationDateItem[0].getProperty('textContent')).jsonValue();
				var numberOfEntriesAndPublicationDate = tempNumberOfEntriesAndPublicationDate.split('（');
				var publicationDate = numberOfEntriesAndPublicationDate[1].replace('現在）', '').replace('\n','');
				logger.info('掲載日：' + publicationDate);
				var numberOfEntries = numberOfEntriesAndPublicationDate[0].replace('全国で現在', '').replace('の脳神経外科専門医が登録されています。', '')
				logger.info('登録件数：' + numberOfEntries);
				// ページのスクショ
				await page.screenshot({path: 'screenshotData/' + code + '_' + name + '.jpg', fullPage: true});
				
				// 専門検索ページボタン
				var specialistSearchButtonXpath = '//p[contains(text(),"専門医リストにつきま")]/a';
				await page.waitForXPath(specialistSearchButtonXpath);
				var specialistSearch =  await (await (await page.$x(specialistSearchButtonXpath))[0].getProperty('href')).jsonValue();
				const response = await page.goto(specialistSearch, {waitUntil: 'networkidle2', timeout: 70000});
				
				//専門医リストをクリック
				var specialistListXpath = '//a[img[@alt="専門医リスト"]]';
				await page.waitForXPath(specialistListXpath);
				var specialist =  await (await (await page.$x(specialistListXpath))[0].getProperty('href')).jsonValue();
				var getUrl =  specialist.split(/'/)
				var nameListUrl = response.url().replace('/jns_web/jsp_pub/map.jsp', getUrl[1])
				await page.goto(nameListUrl, {waitUntil: 'networkidle2', timeout: 70000});
				
				// 専門医氏名リスト
				var specialistNameListXpath = '//tr[td[contains(text(),"氏名")]]/following-sibling::tr';
				await page.waitForXPath(specialistNameListXpath);
				var specialistNameList = await page.$x(specialistNameListXpath);
				for(var i = 0; i < specialistNameList.length; i++){
					var dt = new Date();
					var formatted = dt.toFormat("YYYY/MM/DD HH24:MI.SS");
					// 資格
					sikaku = '専門医';
					// 県名
					var ken = '';
					//　氏名
					var value = await (await (await specialistNameList[i].$x('td/a'))[0].getProperty('textContent')).jsonValue();
					value = value.replace(/	/g, '').replace('undefined', '').replace(/\n/g, '');
					var namebtn = await specialistNameList[i].$x('td/a');
					
					// 氏名クリック
					await Promise.all([
						page.waitForNavigation({waitUntil: "networkidle2"}),
						namebtn[0].click()
					]);
					
					// 勤務先公開専門医
					specialistNameList = await page.$x('//td[contains(text(),"施設名") or contains(text(),"氏名") ]');
					if(specialistNameList.length != 0){
						// 勤務先
						var kinmuXpath = '//td[contains(text(),"施設名")]/following-sibling::td';
						var kinmuItem =  await page.$x(kinmuXpath);
						var kinmu = await (await (await kinmuItem[0].getProperty('textContent')).jsonValue()).trim();
						csvFormat.setCsvDate(filePath, sikaku, ken, kinmu, value, seq, formatted);
						allCounter = allCounter + 1;
						seq++;
					}
					// 勤務先非公開専門医
					privateEmploymentSpecialist = await page.$x('//span[contains(string(),"非公開")]');
					if(privateEmploymentSpecialist.length != 0){
						kinmu = '';
						csvFormat.setCsvDate(filePath, sikaku, ken, kinmu, value, seq, formatted);
						allCounter = allCounter + 1;
						seq++;
					}
					// 氏名リストに戻る
					var namelListBackBtnXpath = '//input[@name="back"]';
					await page.waitForXPath(namelListBackBtnXpath);
					const namelListBackBtn = await page.$x(namelListBackBtnXpath);
					await Promise.all([
						page.waitForNavigation({waitUntil: "networkidle2"}),
						namelListBackBtn[0].click()
					]);
					// 氏名リストを再取得
					specialistNameList = await page.$x(specialistNameListXpath);
					logger.info('読込数：' + allCounter + ' / ' + specialistNameList.length);
				}
				// csv⇒Excel
				csvConverter.PythonShellCsvConverter(filePath, name, code, today, logger);
			} catch(e) {
				// エラー出力
				logger.error(e)
				
				// ブラウザを閉じて終了
				await browser.close();
				process.exit(200);
			}
			// ブラウザを閉じて終了
			await browser.close();
		})();
	}
}