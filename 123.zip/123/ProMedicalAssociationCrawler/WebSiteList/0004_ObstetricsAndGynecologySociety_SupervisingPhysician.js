require('date-utils');
const puppeteer = require('puppeteer');
var fs = require('fs');
var seq = 1;
var robotsParser = require('../Utils/robotsParser');
var csvFormat = require('../Utils/csvFormat');
var csvConverter = require('../CallPython/CallPythonSell');
var convertDir = 'data';
var today = new Date().toFormat("YYYYMMDD");
var allCounter = 0;

exports.accessPage = async function accessPage(accessURL, headless, code, name, logger) {
	// robots.txtチェック
	robotsResult = await robotsParser.robotsTextSearch(accessURL, logger);
	if(robotsResult == true){
		( async () => {
			logger.info('クローラ起動')
			// ブラウザ起動と設定
			const browser = await puppeteer.launch({
				headless: headless,
				args: [
					'--window-size=1600,950',
					'--window-position=100,50',
					'--no-sandbox',
					'--disable-setuid-sandbox'
				]
			});
			const page = await browser.newPage();
			
			// ディレクトリ+ファイル名
			var filePath = convertDir + '/' + code + '_' + name + '_' + today + '.csv'
			logger.info('出力ディレクトリ：' + convertDir + '/');
			logger.info('出力ファイル名：' + code + '_' + name + '_' + today + '.csv');
			
			// 同名ファイル存在チェック
			if(fs.existsSync(filePath)){
				logger.info('同名ファイル存在チェック：' + fs.existsSync(filePath))
				logger.info('ファイル削除')
				fs.unlinkSync(filePath)
				logger.info('同名ファイル存在チェック：' + fs.existsSync(filePath))
			}
			
			try {
				logger.info('クロール開始');
				// ヘッダーの設定
				csvFormat.setCsvHedFormat(filePath);
				
				await page.setViewport({width: 1600, height: 950});
				await page.goto(accessURL, {waitUntil: 'networkidle2', timeout: 5000});
				
				// ページのスクショ
				await page.screenshot({path: 'screenshotData/' + code + '_' + name + '.jpg', fullPage: true});
				
				// サイト掲載日の取得
				var publicationDateXpath = '//*[@id="senmoni"]//div[@class="under_sm"]/p/text()[1]';
				await page.waitForXPath(publicationDateXpath);
				const publicationDateItem = await page.$x(publicationDateXpath);
				var publicationDate = await (await publicationDateItem[0].getProperty('textContent')).jsonValue()
				publicationDate = publicationDate.replace('合計：', '').replace('\n','')
				logger.info('掲載日：' + publicationDate);
				
				// 登録件数
				var numberOfEntriesXpath = '//*[@id="senmoni"]//div[@class="under_sm"]/p/b';
				await page.waitForXPath(numberOfEntriesXpath);
				const numberOfEntriesItem = await page.$x(numberOfEntriesXpath);
				var numberOfEntries = await (await numberOfEntriesItem[0].getProperty('textContent')).jsonValue()
				numberOfEntries = numberOfEntries.replace(' 合計：', '')
				logger.info('登録件数：' + numberOfEntries);
				
				// 資格区分
				var sikakuXpath = '//*[@id="senmoni"]//div[@class="aside"]/h2/img';
				await page.waitForXPath(sikakuXpath);
				const sikakuItem = await page.$x(sikakuXpath);
				var sikaku = await (await sikakuItem[0].getProperty('alt')).jsonValue();
				sikaku = sikaku.replace('を検索する', '')
				
				// 都道府県ごとにクリック
				var searchBtnXpath = '//div[@class="search_map heigher"]/div//td/a';
				await page.waitForXPath(searchBtnXpath);
				const searchBtnList = await page.$x(searchBtnXpath);
				for (var i = 0; i < searchBtnList.length; i++) {
					searchBtnXpath = '//div[@class="search_map heigher"]/div//td/a';
					await page.waitForXPath(searchBtnXpath);
					const searchBtnList = await page.$x(searchBtnXpath);
					await Promise.all([
						page.waitForNavigation({waitUntil: "networkidle2"}),
						searchBtnList[i].click()
					]);
					
					// 専門医名を取得
					var xpath = '//*[@class="name_list"]/li';
					const nameList = await page.$x(xpath);
					var dt = new Date();
					var formatted = dt.toFormat("YYYY/MM/DD HH24:MI.SS");
					var kinmu = '';
					var prefecturesXpath = '//div[@class="search_map_in"]/div[1]';
					await page.waitForXPath(prefecturesXpath);
					const prefecturesName = await page.$x(prefecturesXpath);
					var ken = await (await prefecturesName[0].getProperty('textContent')).jsonValue();
					for (var j = 0; j < nameList.length; j++) {
						var value = await (await nameList[j].getProperty('innerHTML')).jsonValue();
						csvFormat.setCsvDate(filePath, sikaku, ken, kinmu, value, seq, formatted);
						allCounter = allCounter  +1;
						seq++;
					}
					
					// 検索画面に戻る
					var backBtnXpath = '//*[@class="n_s_back_bt"]/a';
					await page.waitForXPath(backBtnXpath);
					const backBtn = await page.$x(backBtnXpath);
					await Promise.all([
						page.waitForNavigation({waitUntil: "networkidle2"}),
						backBtn[0].click()
					]);
				}
				logger.info('取得件数：' + allCounter);
				// csv⇒Excel
				await csvConverter.PythonShellCsvConverter(filePath, name, code, today, logger);
				
			} catch(e) {
				// エラー出力
				logger.error(e);
				
				// ブラウザを閉じて終了
				await browser.close();
				process.exit(200);
			}
			
			// ブラウザを閉じて終了
			await browser.close();
		})();
	}
}