require('date-utils');
const puppeteer = require('puppeteer');
var fs = require('fs');
var seq = 1;
var robotsParser = require('../Utils/robotsParser');
var csvFormat = require('../Utils/csvFormat');
var csvConverter = require('../CallPython/CallPythonSell');
var convertDir = 'data';
var today = new Date().toFormat("YYYYMMDD");
var allcount = 0;

exports.accessPage = async function accessPage(accessURL, headless, code, name, logger) {
	// robots.txtチェック
	robotsResult = await robotsParser.robotsTextSearch(accessURL, logger);
	if(robotsResult == true){
		( async () => {
			logger.info('クローラ起動')
			// ブラウザ起動と設定
			const browser = await puppeteer.launch({
				headless: headless,
				slowMo: 20,
				args: [
					'--window-size=1600,950',
					'--window-position=100,50',
					'--no-sandbox',
					'--disable-setuid-sandbox'
				]
			});
			const page = await browser.newPage();
			
			// ディレクトリ+ファイル名
			var filePath = convertDir + '/' + code + '_' + name + '_' + today + '.csv'
			logger.info('出力ディレクトリ：' + convertDir + '/');
			logger.info('出力ファイル名：' + code + '_' + name + '_' + today + '.csv');
			
			// 同名ファイル存在チェック
			if(fs.existsSync(filePath)){
				logger.info('同名ファイル存在チェック：' + fs.existsSync(filePath))
				logger.info('ファイル削除')
				fs.unlinkSync(filePath)
				logger.info('同名ファイル存在チェック：' + fs.existsSync(filePath))
			}
			
			try {
				logger.info('クロール開始');
				// ヘッダーの設定
				csvFormat.setCsvHedFormat(filePath);
				
				await page.setViewport({width: 1600, height: 950});
				await page.goto(accessURL, {waitUntil: 'networkidle2', timeout: 5000});
				
				const frame = await page.frames().find(f => f.name() === 'topics');
				
				// ページのスクショ
				await page.screenshot({path: 'screenshotData/' + code + '_' + name + '.jpg', fullPage: true});
				
				// 掲載日の取得
				var publicationDateXpath = '//*[@id="contents-area2"]/article/section[1]';
				await frame.waitForXPath(publicationDateXpath);
				const publicationDateItem = await frame.$x(publicationDateXpath);
				var publicationDate = await (await publicationDateItem[0].getProperty('innerHTML')).jsonValue()
				publicationDate = publicationDate.split('<br>')
				publicationDate = publicationDate[2].replace('\n', '').replace(/	/g, '').replace('熱傷専門医の所属は', '').replace('現在の事務局のデータによるものです。', '')
				logger.info('掲載日：' + publicationDate);
				
				// 検索ボタンが来るまで待つ
				var prefecturesListXpath = '//*[@id="contents-area2"]/article/section[position() >1]/input';
				var prefecturesList = await frame.$x(prefecturesListXpath);
				
				for(var i = 0; i < prefecturesList.length; i ++){
					await Promise.all([
						prefecturesList[i].click()
					]);
					var ken = await (await prefecturesList[i].getProperty('value')).jsonValue();
					await frame.waitForXPath('//*[@id="view541"]/table/tbody/tr')
					var xpath = '//*[@id="view541"]/table/tbody/tr[position() > 1]';
					const nameList = await frame.$x(xpath);
					var dt = new Date();
					var formatted = dt.toFormat("YYYY/MM/DD HH24:MI.SS");
					for (var j = 0; j < nameList.length; j++) {
						var sikaku = "専門医";
						var value = await (await (await nameList[j].$x('td[2]'))[0].getProperty('textContent')).jsonValue();
						var kinmu = await (await (await nameList[j].$x('td[4]'))[0].getProperty('textContent')).jsonValue();
						var ken = await (await (await nameList[j].$x('td[6]'))[0].getProperty('textContent')).jsonValue();
						csvFormat.setCsvDate(filePath, sikaku, ken, kinmu, value, seq, formatted);
						allcount = allcount +1
						seq++;
					}
					logger.info(ken + ',' + j)
				}
				logger.info('取得件数' + allcount)
				// csv⇒Excel
				csvConverter.PythonShellCsvConverter(filePath, name, code, today, logger);
			} catch(e) {
				// エラー出力
				logger.error(e);
				
				// ブラウザを閉じて終了
				await browser.close();
				process.exit(200);
			}
			// ブラウザを閉じて終了
			await browser.close();
			logger.info('クロール終了');
		})();
	}
}