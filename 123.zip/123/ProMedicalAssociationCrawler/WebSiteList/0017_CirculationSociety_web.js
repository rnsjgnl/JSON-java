const puppeteer = require('puppeteer');
const fs = require('fs');
var seq = 1;
var robotsParser = require('../Utils/robotsParser');
var csvFormat = require('../Utils/csvFormat');
var csvConverter = require('../CallPython/CallPythonSell');
var convertDir = 'data';
var today = new Date().toFormat("YYYYMMDD");

exports.accessPage = async function accessPage(accessURL, headless, code, name, logger) {
	// robots.txtチェック
	robotsResult = await robotsParser.robotsTextSearch(accessURL, logger);
	if(robotsResult == true){
		( async () => {
			logger.info('クローラ起動')
			// ブラウザ起動と設定
			const browser = await puppeteer.launch({
				headless: headless,
				args: [
					'--window-size=1600,950',
					'--window-position=100,50',
					'--no-sandbox',
					'--disable-setuid-sandbox'
				]
			});
			const page = await browser.newPage();
			
			// ディレクトリ+ファイル名
			var filePath = convertDir + '/' + code + '_' + name + '_' + today + '.csv'
			logger.info('出力ディレクトリ：' + convertDir + '/');
			logger.info('出力ファイル名：' + code + '_' + name + '_' + today + '.csv');
			
			// 同名ファイル存在チェック
			if(fs.existsSync(filePath)){
				logger.info('同名ファイル存在チェック：' + fs.existsSync(filePath))
				logger.info('ファイル削除')
				fs.unlinkSync(filePath)
				logger.info('同名ファイル存在チェック：' + fs.existsSync(filePath))
			}
			
			try {
				logger.info('クロール開始');
				// ヘッダーの設定
				csvFormat.setCsvHedFormat(filePath);
				
				await page.setViewport({width: 1600, height: 950});
				await page.goto(accessURL, {waitUntil: 'networkidle2', timeout: 10000});
				
				// 登録件数
				var numberOfEntriesXpath = '//h2[contains(text(),"専門医数")]/following-sibling::div/p';
				await page.waitForXPath(numberOfEntriesXpath);
				const numberOfEntriesItem = await page.$x(numberOfEntriesXpath);
				var tempNumberOfEntries = await (await numberOfEntriesItem[0].getProperty('textContent')).jsonValue()
				numberOfEntries = tempNumberOfEntries.replace(')', '').replace('\n', '').split('(')
				logger.info('登録件数：' + numberOfEntries[0]);
				logger.info('掲載日：' + numberOfEntries[1]);
				
				// ページのスクショ
				await page.screenshot({path: 'screenshotData/' + code + '_' + name + '.jpg', fullPage: true});
				
				//都道府県リストを取得
				var prefecturesXpath = '//div/h2[contains(text(),"専門医名簿")]/following-sibling::div/select/option'
				await page.waitForXPath(prefecturesXpath);
				const prefecturesItem = await page.$x(prefecturesXpath);
				var allCounter = 0
				
				//各都道府県の専門医一覧を取得
				for(var i =0; i < prefecturesItem.length; i++){
					await page.waitForXPath(prefecturesXpath);
					const prefecturesItem = await page.$x(prefecturesXpath);
					var prefecturesName = await (await prefecturesItem[i].getProperty('textContent')).jsonValue()
					if(prefecturesName=="都道府県"){continue}
					prefecturesName = prefecturesName.replace('県', '')
					//都道府県を選択
					await page.select(
						'body > div > div.l-layout > main > div > div > div > ul.c-search--pulldown > li:nth-child(2) > div > div > select'
						, seelctprefectures = '/specialist_area/'+ prefecturesName +'/'
					);
					
					//専門医名簿検索ボタン押下
					var searchButtonXpath = '//h2[contains(text(),"専門医名簿検索")]/following-sibling::a'
					await page.waitForXPath(searchButtonXpath);
					const searchButton = await page.$x(searchButtonXpath);
					await Promise.all([
						page.waitForNavigation({waitUntil: "networkidle2"}),
						searchButton[0].click()
					]);
					
					//都道府県名と登録件数を取得
					var searchResultsXpath = '//h1[contains(text(),"専門医検索")]/following-sibling::h2/span'
					await page.waitForXPath(searchResultsXpath);
					const searchResultsItem = await page.$x(searchResultsXpath);
					var searchResults = await (await searchResultsItem[0].getProperty('textContent')).jsonValue()
					searchResults = searchResults.replace(/\n/, '').replace(/\”/g, '').split('で')
					var ken = searchResults[0]
					var sikaku =  '専門医'
					var count = 0
					var prefecturesCount = searchResults[1].replace('ヒットしました。', '').replace('\n', '')
					logger.info(ken +'の登録件数' + prefecturesCount);
					var lastPageFlg = new Boolean(false);
					do {
						//専門医名を取得
						var userListXpath = '//h3[span[contains(text(),"専門医名")]]/following-sibling::ul[1]/li'
						await page.waitForXPath(userListXpath);
						const nameList = await page.$x(userListXpath);
						var dt = new Date();
						var formatted = dt.toFormat("YYYY/MM/DD HH24:MI.SS");
						// 連続アクセスで画面描写の性能劣化が発生する為、５秒待つ
						await new Promise(resolve => setTimeout(resolve, 5000))
						
						for(var j = 0; j < nameList.length; j ++){
							var value = ""
							var kinmu = ""
							value = await (await (await nameList[j].$x('div[2]/p[contains(@class,"name")]'))[0].getProperty('textContent')).jsonValue();
							kinmu = await (await (await nameList[j].$x('div[2]/p[contains(@class,"facility")]'))[0].getProperty('textContent')).jsonValue();
							csvFormat.setCsvDate(filePath, sikaku, ken, kinmu, value, seq, formatted);
							count =  count +1;
							allCounter = allCounter +1;
							seq++;
						}
						
						//現在のページボタンを取得
						var activePageButtonXpath = '//ul[contains(@class,"pagination")]/li[contains(@class,"active")]'
						var activePageButtonItem = await page.$x(activePageButtonXpath);
						
						//ページング機能の判定
						if(activePageButtonItem != 0){
							var activePageNumber =  await (await (activePageButtonItem[0]).getProperty('textContent')).jsonValue();
							logger.info(ken + ':ページ番号:' + activePageNumber)
						
							//各都道府県の専門医リストをスクショ
							await page.screenshot({path: '0017_' + today + '/' + (i+1)+ '_' + ken + '_ページ番号' + activePageNumber + '.jpg', fullPage: true});
							
							//次のページへのボタンを取得
							var nextPageXpath = '//ul[contains(@class,"pagination")]/li[contains(@class,"active")]/following-sibling::li[1]/a'
							var nextPageButtonItem = await page.$x(nextPageXpath);
							
							//各都道府県の最終ページか
							if(nextPageButtonItem.length != 0){
								var nextPageNumber =  await (await (nextPageButtonItem[0]).getProperty('textContent')).jsonValue();
								
								//次ページのボタン押下
								await Promise.all([
									page.waitForNavigation({waitUntil: "networkidle2"}),
									nextPageButtonItem[0].click()
								]);
								
								//再度現在のページを取得しページ遷移判定を実施（動的サイトの為waitが効かない場合が有る為）
								var pageFlg = new Boolean(false);
								var exceptionFlg = new Boolean(false);
								var retryCount = 0;
								do{
									try {
										var reActivePageButtonXpath = '//ul[contains(@class,"pagination")]/li[contains(@class,"active")]'
										var reActivePageButtonItem = await page.$x(reActivePageButtonXpath);
										var reActivePageNumber =  await (await (reActivePageButtonItem[0]).getProperty('textContent')).jsonValue();
										if(reActivePageNumber == nextPageNumber){
											pageFlg = true
										} else {
											retryCount ++
										}
									} catch (e) {
										logger.info('画面描写描写処理に失敗しました。[' + e.name + ':' + e.message + ']')
										exceptionFlg = true
									}
									
									//次ページのボタン押下処理に失敗している為、再度押下
									if(exceptionFlg == true && retryCount > 5){
										var nextPageButtonItem = await page.$x(nextPageXpath);
										await Promise.all([
											page.waitForNavigation({waitUntil: "networkidle2"}),
											nextPageButtonItem[0].click()
										]);
									}
								} while(pageFlg != true)
							}else{
								lastPageFlg = true
							}
						}else{
							//各都道府県の専門医リストをスクショ
							await page.screenshot({path: '0017_' + today + '/' + i + '_' + ken + '_ページ番号' + '1' + '.jpg', fullPage: true});
							lastPageFlg = true
						}
					} while(lastPageFlg != true);
					logger.info(ken +'の取得件数' + count + '件');
					
					//会員名簿・専門医名簿画面に遷移
					var memberSpecialistListXpath = '//li[contains(@class,"c-breadcrumb__item")]/a[contains(text(),"会員名簿・専門医名簿")]'
					await page.waitForXPath(memberSpecialistListXpath);
					const memberSpecialistList = await page.$x(memberSpecialistListXpath);
					await Promise.all([
						page.waitForNavigation({waitUntil: "networkidle2"}),
						memberSpecialistList[0].click()
					]);
				}
				logger.info('総取得数' + allCounter)
				csvConverter.PythonShellCsvConverter(filePath, name, code, today, logger);
			} catch(e) {
				// エラー出力
				logger.error(e);
				// ブラウザを閉じて終了
				await browser.close();
				process.exit(200);
			}
			// ブラウザを閉じて終了
			await browser.close();
		})();
	}
}