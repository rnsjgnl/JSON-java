require('date-utils');
const puppeteer = require('puppeteer');
var fs = require('fs');
var seq = 1;
var robotsParser = require('../Utils/robotsParser');
var csvFormat = require('../Utils/csvFormat');
var csvConverter = require('../CallPython/CallPythonSell');
var convertDir = 'data';
var today = new Date().toFormat("YYYYMMDD");

exports.accessPage = async function accessPage(accessURL, headless, code, name, logger) {
	// robots.txtチェック
	robotsResult = await robotsParser.robotsTextSearch(accessURL, logger);
	if(robotsResult == true){
		( async () => {
			logger.info('クローラ起動')
			// ブラウザ起動と設定
			const browser = await puppeteer.launch({
				headless: headless,
				args: [
					'--window-size=1600,950',
					'--window-position=100,50',
					'--no-sandbox',
					'--disable-setuid-sandbox'
				]
			});
			const page = await browser.newPage();
			
			// ディレクトリ+ファイル名
			var filePath = convertDir + '/' + code + '_' + name + '_' + today + '.csv'
			logger.info('出力ディレクトリ：' + convertDir + '/');
			logger.info('出力ファイル名：' + code + '_' + name + '_' + today + '.csv');
			
			// 同名ファイル存在チェック
			if(fs.existsSync(filePath)){
				logger.info('同名ファイル存在チェック：' + fs.existsSync(filePath))
				logger.info('ファイル削除')
				fs.unlinkSync(filePath)
				logger.info('同名ファイル存在チェック：' + fs.existsSync(filePath))
			}
			
			try {
				logger.info('クロール開始');
				// ヘッダーの設定
				csvFormat.setCsvHedFormat(filePath);
				
				await page.setViewport({width: 1600, height: 950});
				await page.goto(accessURL, {waitUntil: 'networkidle2', timeout: 5000});
				
				// ページのスクショ
				await page.screenshot({path: 'screenshotData/' + code + '_' + name + '.jpg', fullPage: true});
				
				var publicationDateXpath = '//div[@class="date_search"]';
				await page.waitForXPath(publicationDateXpath);
				const publicationDateItem = await page.$x(publicationDateXpath);
				var publicationDateAndnumberOfEntries = await (await publicationDateItem[0].getProperty('textContent')).jsonValue()
				var publicationDateAndnumberOfEntries = publicationDateAndnumberOfEntries.split('　');
				publicationDate = publicationDateAndnumberOfEntries[0].replace('現在', '').replace('\n','');
				numberOfEntries = publicationDateAndnumberOfEntries[1].replace('\n','');
				logger.info('掲載日：' + publicationDate);
				logger.info('登録件数：' + numberOfEntries);
				
				// 半角空白入力
				await page.type("#sq4", ' ');
				
				// 検索ボタンが来るまで待つ
				var searchBtnXpath = '//div[@class="form_submit"]/a';
				await page.waitForXPath(searchBtnXpath);
				
				// 検索ボタンがクリック
				const searchBtn = await page.$x(searchBtnXpath);
				await Promise.all([
					page.waitForNavigation({waitUntil: "networkidle2"}),
					searchBtn[0].click()
				]);
				
				// 専門医名を取得
				var xpath = '//*[@id="stable"]/tbody/tr';
				const nameList = await page.$x(xpath);
				
				var dt = new Date();
				var formatted = dt.toFormat("YYYY/MM/DD HH24:MI.SS");
				for (var i = 0; i < nameList.length; i++) {
					var kinmu = ''
					var value = await (await (await nameList[i].$x('td[2]'))[0].getProperty('innerHTML')).jsonValue();
					var ken = await (await (await nameList[i].$x('td[5]'))[0].getProperty('innerHTML')).jsonValue();
					if (ken == ''){
						ken = '01'
					}
					
					if(ken != '01'){
						var tdItem = await (await (await nameList[i].$x('td[6]'))[0].getProperty('innerHTML')).jsonValue();
						tdItem = tdItem.replace('\n', '').trim()
						var tdItemList = tdItem.split('<br>')
						if(tdItemList[0] != ''){
							kinmu = tdItemList[0].replace('&nbsp;', '').replace(/,/g, '.').trim()
						} else {
							kinmu = tdItemList[1].replace('&nbsp;', '').replace(/,/g, '.').trim()
						}
						// 
						if(kinmu.search(/〒/) != -1){
							logger.info('勤務先の住所のみ、氏名[' + value + ']')
							kinmu = ''
						}
					} else {
						kinmu = await (await (await nameList[i].$x('td[6]'))[0].getProperty('textContent')).jsonValue();
						kinmu = kinmu.replace('\n', '').replace('&nbsp;', '').replace(/,/g, '.').trim()
					}
					
					var sikaku =  await (await (await nameList[i].$x('td[1]/img'))[0].getProperty('alt')).jsonValue();
					csvFormat.setCsvDate(filePath, sikaku, ken, kinmu, value, seq, formatted);
					seq++;
				}
				logger.info('取得件数：' + i);
				// csv⇒Excel
				csvConverter.PythonShellCsvConverter(filePath, name, code, today, logger);
			} catch(e) {
				// エラー出力
				logger.error(e)
				
				// ブラウザを閉じて終了
				await browser.close();
				process.exit(200);
			}
			// ブラウザを閉じて終了
			await browser.close();
		})();
	}
}