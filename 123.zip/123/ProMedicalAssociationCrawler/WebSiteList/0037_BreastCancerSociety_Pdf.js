const puppeteer = require('puppeteer');
const http = require('http');
var fs = require('fs');
var robotsParser = require('../Utils/robotsParser');
var csvConverter = require('../CallPython/CallPythonSell');
var convertDir = 'pdfData';
var today = new Date().toFormat("YYYYMMDD");
var pdfCrawle = '0037_PDF_Crawler.py'

exports.accessPage = async function accessPage(accessURL, headless, code, name, logger) {
	// robots.txtチェック
	robotsResult = await robotsParser.robotsTextSearch(accessURL, logger);
	if(robotsResult == true){
		( async () => {
			logger.info('クローラ起動')
			// ブラウザ起動と設定
			const browser = await puppeteer.launch({
				headless: headless,
				args: [
					'--window-size=1600,950',
					'--window-position=100,50',
					'--no-sandbox',
					'--disable-setuid-sandbox'
				]
			});
			const page = await browser.newPage();
			
			try {
				logger.info('クロール開始');
				
				await page.setViewport({width: 1600, height: 950});
				await page.goto(accessURL, {waitUntil: 'networkidle2', timeout: 5000});
				
				// ページのスクショ
				await page.screenshot({path: 'screenshotData/' + code + '_' + name + '.jpg', fullPage: true});
				
				// サイト掲載日と登録件数
				var publicationDateXpath = '//*[@id="post-3476"]/p';
				await page.waitForXPath(publicationDateXpath);
				const publicationDateItem = await page.$x(publicationDateXpath);
				var tpublicationDate = await (await publicationDateItem[0].getProperty('textContent')).jsonValue()
				var publicationDate = (tpublicationDate.match('([0-9])+年+([0-9])+月'))[0]
				var numberOfEntries = (tpublicationDate.match('掲載数：+(.)+名'))[0].replace('掲載数：','')
				logger.info('掲載日：' + publicationDate);
				logger.info('登録件数：' + numberOfEntries);
				
				// 地域名の取得
				var areaNameXpath = '//*[@id="post-3476"]/blockquote/p/span';
				await page.waitForXPath(areaNameXpath);
				var areaNameItem = await page.$x(areaNameXpath);
				// 地域ごとにクリック
				var regionXpath = '//*[@id="post-3476"]/blockquote/p//a';
				await page.waitForXPath(regionXpath);
				var regionList = await page.$x(regionXpath);
				var pdfFilePath = []
				for (var i = 0; i < regionList.length; i++) {
					var areaName = await (await (await areaNameItem[i].getProperty('textContent')).jsonValue()).replace('：', '')
					var PDFLink = await (await regionList[i].getProperty('href')).jsonValue();
					var pdfName = await (await regionList[i].getProperty('textContent')).jsonValue()
					var pdfFileName = pdfName + '_' + (i+1) + '_' + areaName
					logger.info('PDF名前', pdfFileName,':PDFリンク', PDFLink);
					pdfFilePath.push(convertDir + '/' + code + '_' + pdfFileName + '.pdf')
					var dlpdf = pdfFilePath[i]
					var download = (url, dlpdf, cb) => {
						var file = fs.createWriteStream(dlpdf);
						var request = http.get(url, (response) => {
							if (response.statusCode !== 200) {
								return cb('Response status was ' + response.statusCode);
							}
							response.pipe(file);
						});
						file.on('finish', () => file.close(cb));
						
						request.on('error', (err) => {
							fs.unlink(dlpdf);
							return cb(err.message);
						});
						file.on('error', (err) => {
							fs.unlink(dlpdf);
							return cb(err.message);
						});
					};
					download(PDFLink, pdfFilePath[i]);
				}
				csvConverter.PythonShellPdfCrawler(pdfCrawle, pdfFilePath, name, code, today, logger);
				
			} catch(e) {
				// エラー出力
				logger.error(e);
				
				// ブラウザを閉じて終了
				await browser.close();
				process.exit(200);
			}
			// ブラウザを閉じて終了
			await browser.close();
			logger.info('クロール終了');
		})();
	}
}