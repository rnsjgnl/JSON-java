var HashMap  = require('hashmap');
exports.getCodeList = function getCodeList(cdlist) {
	var hashMap = new HashMap();
	
	hashMap.set(1, '0001') // 皮膚科専門医
	hashMap.set(2, '0002') // 整形外科専門医
	hashMap.set(3, '0003') // 麻酔科専門医
	hashMap.set(4, '0004') // 産婦人科専門医
	hashMap.set(5, '0005') // 眼科専門医
	hashMap.set(6, '0006') // 放射線科専門医
	hashMap.set(7, '0007') // 耳鼻咽喉科専門医
	hashMap.set(8, '0008') // 泌尿器科専門医
	hashMap.set(9, '0009') // 総合内科専門医
	hashMap.set(10, '0010') // 病理専門医
	hashMap.set(11, '0011') // 形成外科専門医
	hashMap.set(12, '0012') // 外科専門医
	hashMap.set(13, '0013') // 糖尿病専門医
	hashMap.set(14, '0014') // 肝臓専門医
	hashMap.set(15, '0015') // 感染症専門医
	hashMap.set(16, '0016') // 救急科専門医
	hashMap.set(17, '0017') // 循環器専門医
	hashMap.set(18, '0018') // 血液専門医
	hashMap.set(19, '0019') // 小児科専門医
	hashMap.set(20, '0020') // 消化器病専門医
	hashMap.set(21, '0021') // 呼吸器専門医
	hashMap.set(22, '0022') // 腎臓専門医
	hashMap.set(23, '0023') // 内分泌代謝科専門医
	hashMap.set(24, '0024') // 消化器外科専門医
	hashMap.set(25, '0025') // 超音波専門医
	hashMap.set(26, '0026') // 細胞診専門医
	hashMap.set(27, '0027') // 脳神経外科専門医
	hashMap.set(28, '0028') // リハビリテーション科専門医
	hashMap.set(29, '0029') // 老年病専門医
	hashMap.set(30, '0030') // 心臓血管外科専門医
	hashMap.set(31, '0031') // 透析専門医
	hashMap.set(32, '0032') // 神経内科専門医
	hashMap.set(33, '0033') // 呼吸器外科専門医
	hashMap.set(34, '0034') // 小児外科専門医
	hashMap.set(35, '0035') // リウマチ専門医
	hashMap.set(36, '0036') // 消化器内視鏡専門医
	hashMap.set(37, '0037') // 乳腺専門医
	hashMap.set(38, '0038') // 臨床遺伝専門医
	hashMap.set(39, '0039') // 漢方専門医
	hashMap.set(40, '0040') // レーザー専門医
	hashMap.set(41, '0041') // 気管支鏡専門医
	hashMap.set(42, '0042') // アレルギー専門医
	hashMap.set(43, '0043') // 気管食道科専門医
	hashMap.set(44, '0044') // 核医学専門医
	hashMap.set(45, '0045') // 大腸肛門病専門医
	hashMap.set(46, '0046') // ペインクリニック専門医
	hashMap.set(47, '0047') // 婦人科腫瘍専門医
	hashMap.set(48, '0048') // 熱傷専門医
	hashMap.set(49, '0049') // 脳血管内治療専門医
	hashMap.set(50, '0050') // がん薬物療法専門医
	hashMap.set(51, '0051') // 周産期(新生児)専門医
	hashMap.set(52, '0052') // 生殖医療専門医
	hashMap.set(53, '0053') // 小児神経専門医
	hashMap.set(54, '0054') // 心療内科専門医
	hashMap.set(55, '0055') // 一般病院連携精神医学専門医
	hashMap.set(56, '0056') // 精神科専門医
	hashMap.set(57, '0057') // 臨床検査専門医
	
	return hashMap.get(cdlist);
}