var fs = require("fs");
var os = require('os');
var eol = os.EOL;

exports.setCsvHedFormat = function setCsvHedFormat(FilePath) {
	appendFile(FilePath, '"区分","都道府県名","施設名","個人名","SEQ","処理実行時間"');
}

exports.setCsvDate = function setCsvDate(FilePath, sikaku, ken, kinmu, value, seq, formatted) {
	appendFile(FilePath, eol + '"' + sikaku + '","' + ken + '","' + kinmu + '","' + value + '","' + seq + '","' + formatted + '"');
}

function appendFile(path, data) {
	// fs.appendFile(path, data, function (err) {
	fs.appendFileSync(path, data, function (err) {
		if (err) {
			throw err;
		}
	});
}