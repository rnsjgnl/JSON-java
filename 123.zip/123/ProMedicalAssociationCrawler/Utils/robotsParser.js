 var robotsParsers = require('robots-parser');
var request = require('request');
var robotsResult = '';

exports.robotsTextSearch = async function robotsTextSearch(accessPageUrl, logger) {
	var urlSearchStert = accessPageUrl.indexOf('://');
	var urlSearchEnd = accessPageUrl.indexOf('/', urlSearchStert + 3);
	var topPageUrl = accessPageUrl.slice(0 , urlSearchEnd);
	var robotsTxtUrl = topPageUrl + '/robots.txt';
	
	var options = {
		url: robotsTxtUrl,
		method: 'GET',
	}
	
	return new Promise(function (resolve, reject) {
		request(options, function (err, res, body) {
			if (!err && res.statusCode == 200) {
				var robotsTxt = robotsParsers(robotsTxtUrl);
				logger.info('サイト[' + topPageUrl + ']のrobots.txtを取得しました。');
				logger.info('クロール対象URL[' + accessPageUrl + ']');
				robotsResult = robotsTxt.isAllowed(accessPageUrl, 'Sams-Bot/1.0');
			} else {
				logger.info('サイト[' + topPageUrl + ']のrobots.txtが見つかりませんでした。');
				logger.info('HTTPステース[' + res.statusCode + ']');
				robotsResult = true;
			}
			logger.info('クロール可否：' + robotsResult)
			resolve(robotsResult);
		});
	});
	
}