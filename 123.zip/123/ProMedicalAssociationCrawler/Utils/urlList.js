var HashMap  = require('hashmap');
exports.getURL = function getURL(num) {
	var hashMap = new HashMap();
	
	hashMap.set(1, urlList = ['https://www.dermatol.or.jp/modules/spMap/']) // 0001皮膚科専門医
	hashMap.set(2, urlList = ['https://www.joa.or.jp/public/speciality_search/']) // 0002整形外科専門医
	hashMap.set(3, urlList = ['https://anesth.or.jp/users/person/requirement/doctors']) // 0003麻酔科専門医
	hashMap.set(4, urlList = ['http://www.jsog.or.jp/modules/senmoni/', 'http://www.jsog.or.jp/modules/shidoui/']) // 0004産婦人科専門医
	hashMap.set(5, urlList = ['http://www.nichigan.or.jp/senmonlist/map.jsp']) // 0005眼科専門医
	hashMap.set(6, urlList = ['http://www.radiology.jp/specialist/list_s_a.html']) // 006放射線科専門医
	hashMap.set(7, urlList = ['http://www.jibika.or.jp/citizens/search/']) // 007耳鼻咽喉科専門医
	hashMap.set(8, urlList = ['https://www.urol.or.jp/specialist/list/']) // 0008泌尿器科専門医
	hashMap.set(9, urlList = ['https://www.naika.or.jp/nintei/seido/meibo/']) // 009総合内科専門医
	hashMap.set(10, urlList = ['http://pathology.or.jp/senmoni/board-certified.html']); // 0010病理専門医
	hashMap.set(11, urlList = ['http://www.jsprs.or.jp/specialist/list/']) // 0011形成外科専門医
	hashMap.set(12, urlList = ['https://www.jssoc.or.jp/aboutus/list/mem_kenmeigoto.html']) // 0012外科専門医
	hashMap.set(13, urlList = ['http://www.jds.or.jp/modules/senmoni/']) // 0013糖尿病専門医
	hashMap.set(14, urlList = ['https://www.jsh.or.jp/medical/specialists/specialists_list']); // 0014肝臓専門医
	hashMap.set(15, urlList = ['http://www.kansensho.or.jp/modules/senmoni/index.php?content_id=29']); // 0015感染症専門医
	hashMap.set(16, urlList = ['https://www.jaam.jp/about/shisetsu/senmon-list.html', 'https://www.jaam.jp/about/shisetsu/shidou-list.html']) // 0016救急科専門医
	hashMap.set(17, urlList = ['http://www.j-circ.or.jp/information/senmoni/kensaku/senmoni_kensaku.htm']) // 017循環器専門医
	hashMap.set(18, urlList = ['http://www.jshem.or.jp/modules/senmoni/']) // 0018血液専門医
	hashMap.set(19, urlList = ['http://www.jpeds.or.jp/modules/senmoni/']) // 0019小児科専門医
	hashMap.set(20, urlList = ['http://www.jsge.or.jp/about/meibo_senmon']) // 0020消化器病専門医
	hashMap.set(21, urlList = ['http://www.jrs.or.jp/modules/senmoni/']) // 0021呼吸器専門医
	hashMap.set(22, urlList = ['https://www.jsn.or.jp/specialist/listindex.php']) // 0022腎臓専門医
	hashMap.set(23, urlList = ['http://www.j-endo.jp/modules/senmoni/']) // 0023内分泌代謝科専門医
	hashMap.set(24, urlList = ['https://www.jsgs.or.jp/modules/specialist/']) // 0024消化器外科専門医
	hashMap.set(25, urlList = ['https://www.jsum.or.jp/capacity/fjsum/']) // 0025消化器外科専門医
	hashMap.set(26, urlList = ['http://jscc.or.jp/others/cytologyspecialist/']) // 0026細胞診専門医
	hashMap.set(27, urlList = ['http://jns.umin.ac.jp/member/specialist']) // 0027脳神経外科専門医
	hashMap.set(28, urlList = ['https://member-new.jarm.or.jp/facility/specialist.php']) // 0028リハビリテーション科専門医
	hashMap.set(29, urlList = ['https://www.kktcs.co.jp/jgsmember/secure/senmon/seek.aspx', 'https://www.jpn-geriat-soc.or.jp/senmoni/index.html']) // 0029老年病専門医
	hashMap.set(30, urlList = ['http://cvs.umin.jp/spcl_list/main.html']) // 0030心臓血管外科専門医
	hashMap.set(31, urlList = ['http://member.jsdt.or.jp/list/specialist']) // 0031透析専門医
	hashMap.set(32, urlList = ['http://www.kktcs.co.jp/jsn-senmon/secure/senmon.aspx', 'https://www.kktcs.co.jp/jsn-senmon/secure/shidoi.aspx']) // 0032神経内科専門医
	hashMap.set(33, urlList = ['http://chest.umin.jp/spl/spl_list.html']) // 0033呼吸器外科専門医
	hashMap.set(34, urlList = ['http://www.jsps.or.jp/business/roster']) // 0034小児外科専門医
	hashMap.set(35, urlList = ['http://pro.ryumachi-net.com/?ln=&fn=&pref=&kw=&f=1#result']) // 0035リウマチ専門医
	hashMap.set(36, urlList = ['https://www.jges.net/medical/specialist/member-list']) // 0036消化器内視鏡専門医
	hashMap.set(37, urlList = ['http://jbcs.gr.jp/member/aboutus/senmonilist/']) // 0037乳腺専門医
	hashMap.set(38, urlList = ['http://service.kktcs.co.jp/smms2/c/jbmg/ws/license/List_jbmg.htm?id=all&t=http://www.jbmg.jp/list/senmon.html']) // 0038臨床遺伝専門医
	hashMap.set(39, urlList = ['https://www.jsom.or.jp/jsom_splist/listTop.do']) // 0039漢方専門医
	hashMap.set(40, urlList = ['http://www.jslsm.or.jp/main/individual/index.html']) // 0040レーザー専門医
	hashMap.set(41, urlList = ['http://www.jsre.org/senmon/search_sidoi_senmoni.jsp']) // 0041気管支鏡専門医
	hashMap.set(42, urlList = ['http://www.jsaweb.jp/modules/ninteilist_general/']) // 0042アレルギー専門医
	hashMap.set(43, urlList = ['http://www.kishoku.gr.jp/specialist_list/index.html']) // 0043気管食道科専門医
	hashMap.set(44, urlList = ['http://www.jsnm.org/archives/1993/']) // 0044核医学専門医
	hashMap.set(45, urlList = ['https://www.coloproctology.gr.jp/medical/specialist/']) // 0045大腸肛門病専門医
	hashMap.set(46, urlList = ['https://www.jspc.gr.jp/shisetsu/senmonimap.html']) // 0046ペインクリニック専門医
	hashMap.set(47, urlList = ['https://jsgo.or.jp/specialist/index.html'])// 0047婦人科腫瘍専門医
	hashMap.set(48, urlList = ['http://www.jsbi-burn.org/members/senmon/archive/ichiran.html']) // 0048熱傷専門医
	hashMap.set(49, urlList = ['http://jsnet.website/documents.php?id=42', 'http://jsnet.website/documents.php?id=43']) // 0049脳血管内治療専門医
	hashMap.set(50, urlList = ['https://www.jsmo.or.jp/authorize/lists.html']) // 0050がん薬物療法専門医
	hashMap.set(51, urlList = ['https://www.jspnm.com/Senmoni/Shinseiji.aspx', 'https://www.jspnm.com/Senmoni/ShidoiS.aspx']) // 0051周産期(新生児)専門医
	hashMap.set(52, urlList = ['http://www.jsrm.or.jp/qualification/specialist_list.html']) // 0052生殖医療専門医
	hashMap.set(53, urlList = ['https://www.childneuro.jp/modules/senmoni/']) // 0053小児神経専門医
	hashMap.set(54, urlList = ['http://www.jspim.org/tomem/ss_07.html']) // 0054心療内科専門医
	hashMap.set(55, urlList = ['http://psy.umin.ac.jp/senmoni_01_list01.html']) // 0055一般病院連携精神医学専門医 2019/09/17 PDFに変更
	hashMap.set(56, urlList = ['https://www.jspn.or.jp/modules/senmoni/']) // 0056精神科専門医
	hashMap.set(57, urlList = ['https://jslm.org/recognition/list/index.html']) // 0057臨床検査医学会
	
	return hashMap.get(num);
}