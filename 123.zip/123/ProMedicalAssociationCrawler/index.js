var urlList = require('./Utils/urlList.js');
var funcList = require('./Utils/funcList.js');
var codeList = require('./Utils/codeList.js');
var specialistNameList = require('./Utils/specialistNameList')
var loggerConfig = require('./config/loggerConfig')

var today = new Date().toFormat('YYYYMMDD_HH24MISS');
var logger = '';
var TARGET_URL = '';
var TAEGET_FUNC = '';
var TARGET_NAME = '';
var TARGET_CODE = '';
var headless = true;
//var headless = false;

//var doNumver = [3, 4];
var doNumver = [8];
var doCount = doNumver.length;
if(doNumver.length === 0) {
	doCount = 53; //max?
}

async function indexRun() {
	//サイトごとに実行
	for (var i = 0; i < doCount; i++) {
		var number = doNumver[i];
		TARGET_CODE = codeList.getCodeList(number);
		TARGET_NAME = specialistNameList.getSpecialistNameList(number);
		TARGET_URL = urlList.getURL(number);
		TAEGET_FUNC = funcList.getFunc(number);
		for(var j = 0; j < TAEGET_FUNC.length; j++) {
			logger =  loggerConfig.logSettingInformation(j, TARGET_CODE, TARGET_NAME, today);
			logger.info('実行対象：', TARGET_CODE, '_', TARGET_NAME[j])
			await TAEGET_FUNC[j].accessPage(TARGET_URL[j], headless, TARGET_CODE, TARGET_NAME[j], logger);
		}
	} 
}
indexRun();