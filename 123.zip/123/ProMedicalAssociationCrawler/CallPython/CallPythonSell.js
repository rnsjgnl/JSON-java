var {PythonShell} = require('python-shell');
var pdfCrawlerdir = 'CallPython/PDFminer/';
var converter = 'CallPython/PDFminer/csvConverter.py';

exports.PythonShellPdfCrawler =async function (targetPy, pdfFile, name, code, today, logger){
	var options={
		mode:'json',
		filePath:pdfFile,
		society:name,
		code:code,
		today:today
	};
	var pdfCrawler = pdfCrawlerdir + targetPy
	var json = JSON.stringify(options);
	var pyshell = new PythonShell(pdfCrawler);
	pyshell.send(json);
	pyshell.on('message', function (data) {
		logger.info(data);
	});
	pyshell.end(function (err,code,signal) {
		if (err != null){
			logger.error('エラーコード: ' + code);
			logger.error('エラーシグナル: ' + signal);
			logger.error('エラー内容: ' + err.traceback);
		}
		logger.info('クローラ終了')
	});
}

exports.PythonShellCsvConverter = async function (convertFile, name, code, today, logger){
	var options={
		mode:'json',
		filePath:convertFile,
		society:name,
		code:code,
		today:today
	};

	var json = JSON.stringify(options);
	var pyshell = new PythonShell(converter);
	pyshell.send(json);
	pyshell.on('message', function (data) {
		logger.info(data);
	});
	 pyshell.end(function (err,code,signal) {
		if (err != null){
			logger.info('Excel変換エラー')
			logger.error('エラーコード: ' + code);
			logger.error('エラーシグナル: ' + signal);
			logger.error('エラー内容: ' + err.traceback);
		}
		logger.info('クローラ終了')
	});
}