import openpyxl
import os, sys, io, json
import openpyxl as px
import logging

from openpyxl.styles import PatternFill

outPutFileDir = 'ExcelData/'
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
data = sys.stdin.buffer.read()
jsonData = json.loads(data.decode())
filePath = jsonData["filePath"]
fileName = jsonData["code"] + '_' + jsonData["society"] + '_' + jsonData["today"] + '.xlsx'
outputText = filePath
print(u'Excel変換開始')
print(u'変換対象ファイルパス : ', outputText)
print(u'変換対象ファイル存在チェック : ', os.access(outputText,os.F_OK))
print(u'変換対象ファイル読込チェック : ', os.access(outputText,os.R_OK))

wb = px.Workbook()
ws = wb.active
result_file = open(outputText, encoding="utf-8-sig")
line = result_file.readline()
i = 1
isFirst = True
while line:
	tttt = line.split(',')
	if (i > 1):
		for w in enumerate(tttt):
			if(int(w[0]) >= 4):continue
			index = int(w[0]+1)
			tstr = w[1].replace('"','')
			ws.cell(row=i,column = index).value = tstr
	i+=1
	line = result_file.readline()
	isFirst = False
result_file.close

if __name__ == 'csvConverter':
	ws.title = "WorkSheetTitle"
	ws.sheet_properties.tabColor = "1072BA"

# set data
fill = PatternFill(patternType='solid', fgColor='36bd11')
for rows in ws['A1':'D1']:
	for cell in rows:
		ws[cell.coordinate].fill = fill
ws["A1"] = "区分"
ws["B1"] = "都道府県"
ws["C1"] = "施設名"
ws["D1"] = "個人名"

# ExcelAutoFilter
ws.auto_filter.ref = 'A1:D1'

# エクセルファイル作成
outPutFile = outPutFileDir + fileName

print(u'出力ファイルディレクトリ', outPutFileDir)
print(u'出力ファイル名', fileName)

# 実行日付が同一の物が存在する場合削除
if(os.access(outPutFile,os.F_OK)):
	print(u'同名ファイル存在チェック : ', os.access(outPutFile,os.F_OK))
	print(u'ファイル削除')
	os.remove(outPutFile)
	print(u'同名ファイル存在チェック : ', os.access(outPutFile,os.F_OK))

wb.save(outPutFile)
print(u'Excel変換終了')