import os, sys, io, openpyxl, json, math, re
from time import sleep
from openpyxl.styles import PatternFill
from pdfminer.pdfinterp import PDFPageInterpreter, PDFResourceManager
from pdfminer.pdfpage import PDFPage
from pdfminer.converter import PDFPageAggregator, TextConverter
from pdfminer.layout import LAParams, LTContainer, LTTextBox, LTTextLine, LTAnno

sys.path.append('CallPython/PDFminer')
import CharacterConversion

csvFileDir = 'data/'
excelFileDir = 'ExcelData/'
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
data = sys.stdin.buffer.read()
jsonData = json.loads(data.decode())
fileName = jsonData["code"] + '_' + jsonData["society"] + '_' + jsonData["today"]
pdfFilePath = jsonData["filePath"]

pdfMaxNumver = 0
pdfCounter = 0
cellIndex = 2

for pdf in enumerate(pdfFilePath) :
	pdf_file_name = pdf[1].replace('pdfData/', '').replace('.pdf', '')
	pdfMaxNumver = len(pdfFilePath)
	inPutPdfFilePath = pdf[1]
	print('PDFファイルパス,', inPutPdfFilePath)
	outPutCsvPath = csvFileDir + pdf_file_name + '.csv'
	print('CSVファイルパス,', outPutCsvPath)
	outPutFile = excelFileDir + pdf_file_name + '.xlsx'
	print('Excelファイルパス,', outPutFile)
	output_txt = open(outPutCsvPath, 'w', encoding='utf-8_sig')
	pdfCounter += 1
	print(' [', pdfCounter, '/' , pdfMaxNumver, ']', ':', pdf_file_name)

	laparams = LAParams(
		all_texts=True, detect_vertical=False,
		line_overlap=0.5, char_margin=100.0,
		line_margin=0.5, word_margin=0.2,
		boxes_flow=1)
	resource_manager = PDFResourceManager()
	device = PDFPageAggregator(resource_manager, laparams=laparams)
	interpreter = PDFPageInterpreter(resource_manager, device)

	def find_textboxes_recursively(layout_obj):
		if isinstance(layout_obj, LTTextBox):
			return [layout_obj]
		if isinstance(layout_obj, LTContainer):
			boxes = []
			for child in layout_obj:
				boxes.extend(find_textboxes_recursively(child))
			return boxes
		return []

	def load_pdf():
		count = 0
		prefectures_text = ''
		# print('os.getcwd()', os.getcwd())
		# print('os.walk(root)',os.walk(os.getcwd()))
		# print(os.path.isfile('pdfData'))
		# print(os.listdir(inPutPdfFilePath))
		with open(inPutPdfFilePath, 'rb') as pdffile:
			for page in PDFPage.get_pages(pdffile):
				interpreter.process_page(page)
				layout = device.get_result()
				boxes = find_textboxes_recursively(layout)
				boxes.sort(key=lambda b: (-b.y1, b.x0))
				for box in enumerate(boxes):
					outPutText = ''
					if isinstance(box[1], LTTextBox) or isinstance(box[1], LTTextLine):
						if box[1]._objs:
							pdf_text = box[1].get_text()
							# ヘッダー
							if "氏名" in pdf_text:
								continue
							# タイトル
							if "日本臨床腫瘍学会" in pdf_text:
								if "専門医認定者" in pdf_text :
									doctorClassification = '専門医'
								else:
									doctorClassification = '指導医'
								continue
							# 都道府県名
							page_num_match = re.search(r'^(.{2}[都道府県]|.{3}県)', pdf_text.strip())
							if page_num_match:
								prefectures_text = pdf_text.strip().replace('\n', '')
								continue
							# PDF認定者合計数
							if "認定者数" in pdf_text:
								print(pdf_text.replace('\n', ''))
								continue
							# 認定日が含まれている場合認定者名
							ishi_name_match = re.search(r'((\d+)年(\d+)月(\d+)日)', pdf_text.strip())
							if ishi_name_match:
								outPutText = outPutText + doctorClassification + ',' + prefectures_text + ','
							# 氏名、施設名、認定日をカンマ区切りで分割
							if pdf_text.count('\n') >1:
								# 施設名が２行の場合
								flg = False
								for text_obj in box[1]._objs:
									if isinstance(text_obj, LTTextBox) or isinstance(text_obj,LTTextLine):
										for outText_obj in  enumerate(text_obj._objs):
											if isinstance(outText_obj[1], LTAnno):
												if outText_obj[1].get_text() == ' ':
													outPutText = outPutText + ','
												else :
													if re.search(r'((\d+)年(\d+)月(\d+)日)', outPutText):
														flg = True
														outPutText = outPutText + outText_obj[1].get_text()
											else :
												outPutText = outPutText + outText_obj[1].get_text()
									if flg == True:
										count = count + 1
										output_txt.write(outPutText)
										outPutText = ""
										outPutText = outPutText + doctorClassification + ',' + prefectures_text + ','
										flg = False
							else :
								for text_obj in box[1]._objs:
									if isinstance(text_obj, LTTextBox) or isinstance(text_obj,LTTextLine):
										for outText_obj in  enumerate(text_obj._objs):
											if isinstance(outText_obj[1], LTAnno):
												if outText_obj[1].get_text() == ' ':
													outPutText = outPutText + ','
												else :
													outPutText = outPutText + outText_obj[1].get_text()
											else :
												outPutText = outPutText + outText_obj[1].get_text()
									if re.search(r'((\d+)年(\d+)月(\d+)日)', outPutText):
										count = count + 1
									output_txt.write(outPutText)
			output_txt.close()
		print(pdf[1], ',レコード数', count)

	def load_csv(wb, i):
		ws = wb.active
		print(u'エクセル変換対象', outPutCsvPath)
		result_file = open(outPutCsvPath, encoding= 'utf-8_sig')
		line = result_file.readline()
		isFirst = True
		contertCounter = 0
		cellIndex = 2
		while line:
			if line.find(",") > 2:
				if 'cid' in line:
					print('CID文字コード変換前', line.replace('\n', ''))
					line = CharacterConversion.conversionFunction(line)
					print('CID文字コード変換後', line.replace('\n', ''))
				split_Character_ist = []
				split_Character_ist = line.split(',')
				ws.cell(row = cellIndex, column = 1).value = split_Character_ist[0]
				ws.cell(row = cellIndex, column = 2).value = split_Character_ist[1]
				ws.cell(row = cellIndex, column = 4).value = split_Character_ist[2]
				# 施設名が有る場合
				if len(split_Character_ist) == 5:
					ws.cell(row = cellIndex, column = 3).value = split_Character_ist[3]
				contertCounter +=1
				cellIndex += 1
				line = result_file.readline()
				isFirst = False
			else:
				line = result_file.readline()
				isFirst = False
		print(u'変換処理数：', contertCounter)
		result_file.close

	if __name__ == '__main__':
		wb = openpyxl.Workbook()
		ws = wb.active
		ws.title = "WorkSheetTitle"
		ws.sheet_properties.tabColor = "1072BA"
		fill = PatternFill(patternType='solid', fgColor='36bd11')
		for rows in ws['A1':'D1']:
			for cell in rows:
				ws[cell.coordinate].fill = fill
		ws["A1"] = "区分"
		ws["B1"] = "都道府県"
		ws["C1"] = "施設名"
		ws["D1"] = "個人名"
		ws.auto_filter.ref = 'A1:D1'
		
		load_pdf()
		load_csv(wb, cellIndex)
		
		if(os.access(outPutFile,os.F_OK)):
			print(u'同名ファイル存在チェック : ', os.access(outPutFile,os.F_OK))
			print(u'ファイル削除')
			os.remove(outPutFile)
			print(u'同名ファイル存在チェック : ', os.access(outPutFile,os.F_OK))
		wb.save(outPutFile)
		print(u'Excel変換終了')