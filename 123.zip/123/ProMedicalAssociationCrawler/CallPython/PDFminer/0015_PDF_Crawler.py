import openpyxl
import os, sys, io, json, math, re
from time import sleep
from openpyxl.styles import PatternFill
from pdfminer.pdfinterp import PDFPageInterpreter, PDFResourceManager
from pdfminer.pdfpage import PDFPage
from pdfminer.converter import PDFPageAggregator, TextConverter
from pdfminer.layout import LAParams, LTContainer, LTTextBox, LTTextLine, LTAnno
# 文字変換処理クラス
# sys.path.append('CallPython/PDFminer')
import CharacterConversion

csvFileDir = 'data/'
excelFileDir = 'ExcelData/'
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
data = sys.stdin.buffer.read()
jsonData = json.loads(data.decode())
fileName = jsonData["code"] + '_' + jsonData["society"] + '_' + jsonData["today"]
convertPdfs = jsonData["filePath"]
	
pdfMaxNumver = 0
pdfCounter = 0
cellIndex = 2

for pdf in enumerate(convertPdfs) :
	
	pdfMaxNumver = len(convertPdfs)
	pdfCounter += 1
	pdfFilePath = pdf[1]
	outPutCsvPath = csvFileDir + pdf[1].replace('pdfData/', '').replace('.pdf', '.csv')
	outPutFile = excelFileDir + pdf[1].replace('pdfData/', '').replace('.pdf', '.xlsx')
	output_txt = open(outPutCsvPath, 'w', encoding='utf-8_sig')
	print(' [', pdfCounter, '/' , pdfMaxNumver, ']', ':', pdf[1])
	
	laparams = LAParams(
		all_texts=False, detect_vertical=False, 
		line_overlap=0.1, char_margin=10,
		line_margin=0.1, word_margin=1)
	resource_manager = PDFResourceManager()
	device = PDFPageAggregator(resource_manager, laparams=laparams)
	interpreter = PDFPageInterpreter(resource_manager, device)

	def find_textboxes_recursively(layout_obj):
		if isinstance(layout_obj, LTTextBox):
			return [layout_obj]

		if isinstance(layout_obj, LTContainer):
			boxes = []
			for child in layout_obj:
				boxes.extend(find_textboxes_recursively(child))
			return boxes
		return []
		
	def load_pdf():	
		count = 0
		ken = ''
		next_ken = ''
		out_put_counter = 0
		
		output_list = []
		output_shi_list = ''
		temp_output_shi_list = ''
		output_name_list = []
		output_ken = ''
		
		with open(pdfFilePath, 'rb') as pdffile:
			for page in PDFPage.get_pages(pdffile):
				interpreter.process_page(page)
				layout = device.get_result()
				boxes = find_textboxes_recursively(layout)
				boxes.sort(key=lambda b: (-b.y1, b.x0))
				
				special_flg = False
				special_shi_list = ''
				for box in enumerate(boxes):
					outPutText = ''
					if isinstance(box[1], LTTextBox) or isinstance(box[1], LTTextLine):
						if box[1]._objs:
							for text_obj in enumerate(box[1]._objs):
								load_text = text_obj[1].get_text().replace('\n', '')
								if '医療法⼈ 朽名医院' in load_text:
									print('')
								# タイトル
								if re.match(r'感染症専⾨医名簿', load_text):
									continue
								# 表タイトル
								if re.match(r'都道府県別認定者数', load_text):
									continue
								# 空白
								if load_text is '\u2003':
									continue
								# 年月日
								if re.match(r'((.)+[0-9|０-９]{1,2}.)+([0-9|０-９]{1,2}.)+([0-9|０-９]{1,2}.)', load_text) is not None:
									continue
								# 登録数
								if re.match(r'.+[0-9]+名+.', load_text) is not None:
									continue
								# 都道府県+海外
								# if re.match(r'(^.{2,3}県$)|(^.{2}[道|都|府]$)|(^海外$)', load_text):
								# 	output_ken = load_text
								# 	continue
								# 都道府県毎の登録件数
								if re.match(r'(.{2,3}[道|都|府]+( )+[0-9])|(.{2,3}県+( )+[0-9])', load_text):
									print('都道府県毎の登録件数（名簿非掲載者含む）', load_text)
									continue
								# 施設名の取得
								# 各都道府県の先頭施設は都道府県名と結合して取得する為、別途対応
								if 40 < text_obj[1].x0 < 80:
									match_text = re.match(r'(.{2,3}[道|都|府])|(.{2,3}県)|海外', load_text)
									if match_text  is not None:
										output_ken = match_text.group(0)
										output_shi_list = load_text.replace(output_ken, '', 1).replace('\u2003', ' ').strip()
									else:
										output_shi_list = load_text.replace('\n', '').replace('\u2003', ' ').strip()
								# if text_obj[1].get_text().startswith('\u2003') == False and 74 < text_obj[1].x0 <= 113:
								elif text_obj[1].x0 <= 90:
									# 特別対応[1] 以下の施設は施設名+氏名で取得出来ない為
									if re.match(r'(IMSグループ+(.))|(⿂津緑ヶ丘+(.)|(.)+朽名医院)', output_shi_list):
										special_flg = True
										special_shi_list = output_shi_list
										temp_output_shi_list = load_text.replace('\n', '').replace('\u2003', ' ').strip()
										output_shi_list = ''
									else:
										output_shi_list = load_text.replace('\n', '').replace('\u2003', ' ').strip()
								# 氏名の取得
								# elif (text_obj[1].get_text().startswith('\u2003') and 74 < text_obj[1].x0 <= 113) or 113 < text_obj[1].x0:
								elif text_obj[1].x0 > 90:
									for outText_obj in  enumerate(text_obj[1]._objs):
										temp_output_Text = outText_obj[1].get_text().replace('\n', '')
										if isinstance(outText_obj[1], LTAnno):
											if outText_obj[1].get_text() in ' ':
												output_name_list.append(outPutText)
												outPutText = ''
										outPutText = outPutText + temp_output_Text.replace('\u2003', ' ')
										# 特別対応[2] 次の氏名と結合して読み込む為
										if  '中村（内⼭）ふくみ' in outPutText or '加勢⽥（光本）富⼠⼦' in outPutText:
											output_name_list.append(outPutText)
											outPutText = ''
									output_name_list.append(outPutText)
									outPutText = ''
								# 特別対応[1] 施設名の入れ替え処理
								if special_flg is True and len(output_name_list) > 0:
									temp_output_shi_list = output_shi_list
									output_shi_list = special_shi_list
								# 出力処理。
								if (len(output_name_list) > 0) and (len(output_shi_list) > 0):
									for name in output_name_list:
										if name.replace('\n', '') != '' and name.replace('\n', '') != '\u2003':
											if re.match(r'.+  +.', name):
												for i in range(2):
													name = name.replace('  ', ' ')
											outText = '専門医' + ',' + output_ken + ',' + output_shi_list + ',' + name.strip() + '\n'
											count += 1
											output_list.append(outText)
									output_name_list = []
									if special_flg is True:
										special_flg = False
										output_shi_list = temp_output_shi_list
										temp_output_shi_list = ''
										special_shi_list = ''
			unique_list = []
			re_count = 0
			for record in output_list:
				if not record in unique_list:
					re_count += 1
					unique_list.append(record)
					output_txt.write(record)
			output_txt.close()
		print(pdf[1], ',レコード数', count, '重複削除後[', re_count, ']')

	def load_csv(wb, i):
		# シート名を取得
		worksheet_list = wb.sheetnames
		print(u'エクセル変換対象', outPutCsvPath)
		result_file = open(outPutCsvPath, encoding= 'utf-8_sig')
		line = result_file.readline()
		isFirst = True
		contertCounter = 0
		cellIndex = 2
		ken = ''
		while line:
			if line not in '':
				templist = CharacterConversion.unicodeConversionFunction(line)
				tempStr = []
				tempStr = line.split(',')
				if len(tempStr) >= 2:
					for sheetName in worksheet_list:
						wb.active = wb[sheetName]
						ws = wb.active
						if sheetName is not "WorkSheetTitle":
							tempStr = templist.split(',')
						ws.cell(row = cellIndex, column = 1).value = tempStr[0].replace('\n','').replace('\'','')
						ws.cell(row = cellIndex, column = 2).value = tempStr[1].replace('\n','').replace('\'','')
						ws.cell(row = cellIndex, column = 4).value = tempStr[3].replace('\n','').replace('\'','')
						ws.cell(row = cellIndex, column = 3).value = tempStr[2].replace('\n','').replace('\'','')
				contertCounter +=1
				cellIndex += 1
			line = result_file.readline()
			isFirst = False
			
		print(u'変換処理数：', contertCounter)
		result_file.close

	if __name__ == '__main__':
		wb = openpyxl.Workbook()
		# unicode変換前後のシートを用意
		wb.create_sheet()
		ws = wb["Sheet"]
		ws.title = "WorkSheetTitle"
		ws = wb["Sheet1"]
		ws.title = "WorkSheetTitle_コード変換"
		for sheetName in wb.sheetnames:
				# レイアウトを適応
				wb.active = wb[sheetName]
				ws = wb.active
				ws.sheet_properties.tabColor = "1072BA"
				fill = PatternFill(patternType='solid', fgColor='36bd11')
				for rows in ws['A1':'D1']:
					for cell in rows:
						ws[cell.coordinate].fill = fill
				ws["A1"] = "区分"
				ws["B1"] = "都道府県"
				ws["C1"] = "施設名"
				ws["D1"] = "個人名"
				
				ws.auto_filter.ref = 'A1:D1'
		load_pdf()
		load_csv(wb, cellIndex)
		
		print(u'同名ファイル存在チェック : ', os.access(outPutFile,os.F_OK))
		if(os.access(outPutFile,os.F_OK)):
			print(u'ファイル削除')
			os.remove(outPutFile)
			print(u'同名ファイル存在チェック : ', os.access(outPutFile,os.F_OK))
		wb.save(outPutFile)
		print(u'Excel変換終了')