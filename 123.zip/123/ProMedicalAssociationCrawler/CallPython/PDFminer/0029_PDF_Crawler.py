import openpyxl
import os, sys, io, json, math, re
import datetime
from time import sleep
from openpyxl.styles import PatternFill
from pdfminer.pdfinterp import PDFPageInterpreter, PDFResourceManager
from pdfminer.pdfpage import PDFPage
from pdfminer.converter import PDFPageAggregator, TextConverter
from pdfminer.layout import LAParams, LTContainer, LTTextBox, LTTextLine, LTAnno

now = datetime.datetime.now()
csvFileDir = 'data/'
pdfFileDir = 'pdfData/'
excelFileDir = 'ExcelData/'
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
data = sys.stdin.buffer.read()
jsonData = json.loads(data.decode())
society = jsonData["society"]
code = jsonData["code"]
convertPdfs = jsonData["filePath"]

pdfMaxNumver = 0
pdfCounter = 0
cellIndex = 2

for pdf in enumerate(convertPdfs) :
	pdfMaxNumver = len(convertPdfs)
	pdfCounter += 1
	pdfFileName = pdf[1].split('/')
	pdfName = pdfFileName[1].replace('.pdf', '')
	pdfFilePath = pdfFileDir + pdfName + '.pdf'
	outPutCsvPath = csvFileDir + pdfName + '.csv'
	output_txt = open(outPutCsvPath, 'w', encoding='utf-8_sig')
	outPutFile = excelFileDir + str(pdfName) + '_' + now.strftime("%Y%m%d") + '.xlsx'

	laparams = LAParams(
		all_texts=True, detect_vertical=False, 
		line_overlap=0.5, char_margin=10.0,
		line_margin=0.5, word_margin=0.2,
		boxes_flow=1)
	resource_manager = PDFResourceManager()
	device = PDFPageAggregator(resource_manager, laparams=laparams)
	interpreter = PDFPageInterpreter(resource_manager, device)

	def find_textboxes_recursively(layout_obj):
		if isinstance(layout_obj, LTTextBox):
			return [layout_obj]

		if isinstance(layout_obj, LTContainer):
			boxes = []
			for child in layout_obj:
				boxes.extend(find_textboxes_recursively(child))
			return boxes
		return []

	# 先頭、末尾、氏名の間のブランク調整。
	def outPutNameBlankControl(text):
		retext = " ".join(text.split())
		return retext
		
	def load_pdf():	
		count = 0
		lite_content_box = ''
		left_content_box = ''
		old_lite_prefectures = ''
		old_left_prefectures = ''
		lite_prefectures = ''
		left_prefectures = ''
		with open(pdfFilePath, 'rb') as pdffile:
			for page in PDFPage.get_pages(pdffile):
				interpreter.process_page(page)
				layout = device.get_result()
				boxes = find_textboxes_recursively(layout)
				boxes.sort(key=lambda b: (-b.y1, b.x0))
				lite_content_box = ''
				left_content_box = ''
				temp_lite_content_box = ''
				temp_left_content_box = ''
				for box in enumerate(boxes):
					outPutText = ''
					if isinstance(box[1], LTTextBox) or isinstance(box[1], LTTextLine):
						if box[1]._objs:
							for text_obj in box[1]._objs:
								temp_text = text_obj.get_text()
								page_num_match = re.search(r'-(.+)-', temp_text)
								if page_num_match:
									old_lite_prefectures = lite_prefectures
									old_left_prefectures = left_prefectures
									lite_prefectures = ''
									left_prefectures = ''
									continue
								title_match = re.search(r'(日本老年医学会認定).+', temp_text)
								if title_match:
									continue
								yer_match = re.search(r'(\d+)年(\d+)月(\d+)日', temp_text)
								if yer_match:
									yer_match = yer_match.group(0).replace('、順不同', '')
									print(yer_match)
									continue
								shikaku_match = re.search(r'(.+)氏名一覧', temp_text)
								if shikaku_match:
									sikaku = shikaku_match.group(0).replace('氏名一覧', '')
									continue
								tiku_match = re.search(r'.+地区', temp_text)
								if tiku_match:
									kubun = tiku_match.group(0)
									if kubun == '北海道地区':
										# x0_57  x1_107
										lite_Coordinate_x0 = math.floor(text_obj.x0)
										lite_Coordinate_x1 = math.floor(text_obj.x1)
										if kubun == '北海道地区':
											lite_prefectures = '北海道'
									if kubun == '関東甲信越地区':
										# x0_308  x1_376
										left_Coordinate_x0 = math.floor(text_obj.x0)
										left_Coordinate_x1 = math.floor(text_obj.x1)
									continue
									
								prefectures_match = re.search(r'(東京都)|(.+府)|(.+県)', temp_text)
								if temp_text != ' \n' and math.floor(text_obj.x0) < 150:
									if (math.floor(text_obj.x0) > 55 and math.floor(text_obj.x0) <= 56):
										ttttt = temp_text.replace(' ', '')
										if prefectures_match:
											lite_prefectures = prefectures_match.group(0)
											continue
										elif lite_prefectures == '':
											lite_prefectures = old_left_prefectures
											
									temp_text_box = ''
									for outText_obj in  enumerate(text_obj._objs):
										if isinstance(outText_obj[1], LTAnno):
											if outText_obj[1].get_text() == '\n' and (temp_text.endswith(' \n') == False):
												lite_content_box = lite_content_box + lite_prefectures + ',' + sikaku + ',' + outPutNameBlankControl(temp_text_box) + '\n'
												count = count + 1
												temp_text_box = ''
												continue
											else:
												continue
										
										text = outText_obj[1].get_text()
										text_Coordinate = math.floor(outText_obj[1].x0)
										if (text == ' ' and text_Coordinate >= 112 and text_Coordinate < 133) \
										or (text == ' ' and text_Coordinate >= 178 and text_Coordinate < 199) \
										or (text == ' ' and text_Coordinate >= 244 and text_Coordinate < 300):
											lite_content_box = lite_content_box + lite_prefectures + ',' + sikaku + ',' + outPutNameBlankControl(temp_text_box) + '\n'
											count = count + 1
											temp_text_box = ''
										# 1個目
										elif text_Coordinate >= 67 and text_Coordinate < 133:
											temp_text_box = temp_text_box + outText_obj[1].get_text()
											continue
										# 2個目
										elif text_Coordinate >= 133 and text_Coordinate < 199:
											temp_text_box = temp_text_box + outText_obj[1].get_text()
											continue
										# 3個目
										elif text_Coordinate >= 199:
											temp_text_box = temp_text_box + outText_obj[1].get_text()
											
								elif temp_text != ' \n' and math.floor(text_obj.x0) > 150:
									if (math.floor(text_obj.x0) > 307 and math.floor(text_obj.x0) <= 308):
										if prefectures_match:
											left_prefectures = prefectures_match.group(0)
											continue
											
									temp_text_box = ''
									for outText_obj in  enumerate(text_obj._objs):
										if isinstance(outText_obj[1], LTAnno):
											if outText_obj[1].get_text() == '\n' and temp_text_box != '' and temp_text_box != ' ': 
												if left_prefectures != '':
													left_content_box = left_content_box + left_prefectures + ',' + sikaku + ',' + outPutNameBlankControl(temp_text_box) + '\n'
													count = count + 1
												else:
													temp_left_content_box = temp_left_content_box + 'tempPrefectures' + ',' + sikaku + ',' + outPutNameBlankControl(temp_text_box) + '\n'
													count = count + 1
												continue
											else:
												continue
										text = outText_obj[1].get_text()
										text_Coordinate = math.floor(outText_obj[1].x0)
										if (text == ' ' and text_Coordinate >= 355 and text_Coordinate < 385) \
										or (text == ' ' and text_Coordinate >= 430 and text_Coordinate < 456) \
										or (text == ' ' and text_Coordinate >= 496 and text_Coordinate < 495):
											if left_prefectures != '':
												left_content_box = left_content_box + left_prefectures + ',' + sikaku + ',' + outPutNameBlankControl(temp_text_box) + '\n'
											else:
												temp_left_content_box = temp_left_content_box + 'tempPrefectures' + ',' + sikaku + ',' + outPutNameBlankControl(temp_text_box) + '\n'
											count = count + 1
											temp_text_box = ''
										# 1個目
										elif text_Coordinate >= 309 and text_Coordinate < 385:
											temp_text_box = temp_text_box + outText_obj[1].get_text()
											continue
										# 2個目
										elif text_Coordinate >= 385 and text_Coordinate <= 430:
											temp_text_box = temp_text_box + outText_obj[1].get_text()
											continue
										# 3個目
										elif text_Coordinate >= 451:
											temp_text_box = temp_text_box + outText_obj[1].get_text()
											# 吉井 文均 特別対応　PDFの文字が壊れている為
											yoshii_match = re.search(r'.+井 文均', temp_text_box)
											if yoshii_match:
												temp_text_box = '吉井 文均'
											continue
											
				output_txt.write(lite_content_box)
				if temp_left_content_box != '':
					prefectures_replace_text = temp_left_content_box.replace('tempPrefectures', old_lite_prefectures)
					output_txt.write(prefectures_replace_text)
				output_txt.write(left_content_box)
			output_txt.close()
		print(pdf[1], ',レコード数', count)

	def load_csv(wb, i):
		ws = wb.active
		print(u'エクセル変換対象', outPutCsvPath)
		result_file = open(outPutCsvPath, encoding= 'utf-8_sig')
		line = result_file.readline()
		isFirst = True
		contertCounter = 0
		cellIndex = 2
		while line:
			tempStr = []
			tempStr = line.split(',')
			kubun = len(tempStr)
			ws.cell(row = cellIndex, column = 1).value = tempStr[1]
			ws.cell(row = cellIndex, column = 2).value = tempStr[0]
			ws.cell(row = cellIndex, column = 4).value = tempStr[2].replace('\n', '')
			contertCounter +=1
			cellIndex += 1
			line = result_file.readline()
			isFirst = False
		print(u'変換処理数：', contertCounter)
		result_file.close

	if __name__ == '__main__':
		wb = openpyxl.Workbook()
		ws = wb.active
		ws.title = "WorkSheetTitle"
		ws.sheet_properties.tabColor = "1072BA"
		fill = PatternFill(patternType='solid', fgColor='36bd11')
		for rows in ws['A1':'D1']:
			for cell in rows:
				ws[cell.coordinate].fill = fill
		ws["A1"] = "区分"
		ws["B1"] = "都道府県"
		ws["C1"] = "施設名"
		ws["D1"] = "個人名"
		
		ws.auto_filter.ref = 'A1:D1'
		
		load_pdf()
		load_csv(wb, cellIndex)
		
		print(u'同名ファイル存在チェック : ', os.access(outPutFile,os.F_OK))
		if(os.access(outPutFile,os.F_OK)):
			print(u'ファイル削除')
			os.remove(outPutFile)
			print(u'同名ファイル存在チェック : ', os.access(outPutFile,os.F_OK))
		wb.save(outPutFile)
		print(u'Excel変換終了')