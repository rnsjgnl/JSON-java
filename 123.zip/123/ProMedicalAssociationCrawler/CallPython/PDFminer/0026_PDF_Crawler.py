import openpyxl
import os, sys, io, json, math, re
import datetime
from time import sleep
from openpyxl.styles import PatternFill
from pdfminer.pdfinterp import PDFPageInterpreter, PDFResourceManager
from pdfminer.pdfpage import PDFPage
from pdfminer.converter import PDFPageAggregator, TextConverter
from pdfminer.layout import LAParams, LTContainer, LTTextBox, LTTextLine, LTAnno


now = datetime.datetime.now()
csvFileDir = 'data/'
pdfFileDir = 'pdfData/'
excelFileDir = 'ExcelData/'
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
data = sys.stdin.buffer.read()
jsonData = json.loads(data.decode())
society = jsonData["society"]
code = jsonData["code"]
convertPdfs = jsonData["filePath"]
pdfMaxNumver = 0
pdfCounter = 0
cellIndex = 2

for pdf in enumerate(convertPdfs) :
	pdfMaxNumver = len(convertPdfs)
	pdfCounter += 1
	pdfFileName = pdf[1].split('/')
	pdfName = pdfFileName[1].replace('.pdf', '')
	pdfFilePath = pdfFileDir + pdfName + '.pdf'
	outPutCsvPath = csvFileDir + pdfName + '.csv'
	output_txt = open(outPutCsvPath, 'w', encoding='utf-8_sig')
	outPutFile = excelFileDir + str(pdfName) + '_' + now.strftime("%Y%m%d") + '.xlsx'

	laparams = LAParams(
		all_texts=True, detect_vertical=False, 
		line_overlap=0.5, char_margin=0.5,
		line_margin=0.5, word_margin=0.5,
		boxes_flow=1)
	resource_manager = PDFResourceManager()
	device = PDFPageAggregator(resource_manager, laparams=laparams)
	interpreter = PDFPageInterpreter(resource_manager, device)

	def find_textboxes_recursively(layout_obj):
		if isinstance(layout_obj, LTTextBox):
			return [layout_obj]

		if isinstance(layout_obj, LTContainer):
			boxes = []
			for child in layout_obj:
				boxes.extend(find_textboxes_recursively(child))
			return boxes
		return []

	def load_pdf():	
		count = 0
		ken = ''
		kbn = ''
		crawlerEndFlg = False
		with open(pdfFilePath, 'rb') as pdffile:
			for page in PDFPage.get_pages(pdffile):
				interpreter.process_page(page)
				layout = device.get_result()
				boxes = find_textboxes_recursively(layout)
				boxes.sort(key=lambda b: (-b.y1, b.x0))
				for box in enumerate(boxes):
					if crawlerEndFlg:
						break
					outPutText = ''
					if isinstance(box[1], LTTextBox) or isinstance(box[1], LTTextLine):
						if box[1]._objs:
							for text_obj in box[1]._objs:
								text = text_obj.get_text().strip()
								
								if text == (''):
									continue
								
								if re.match(r'(^.{2,3}県$)|(^.{2}[道|都|府]$)', text):
									ken = text
									continue
								
								if text.startswith('公益社団法人日本臨床細胞学会'):
									continue
								
								if text.startswith('細胞診専門医'):
									kbn = '専門医'
									continue
								
								if re.match(r'([0-9]{4}年+(.))', text):
									continue
								
								if re.match(r'(細胞診専門歯科医)', text):
									crawlerEndFlg = True
									break
								
								if isinstance(text_obj, LTTextBox) or isinstance(text_obj,LTTextLine):
									for outText_obj in  enumerate(text_obj._objs):
										if isinstance(outText_obj[1], LTAnno):
											temp = outText_obj[1].get_text()
											if temp == ' ':
												temp_1 = outText_obj[1].get_text()
												outPutText = outPutText + ','
											else :
												temp_2 = outText_obj[1].get_text()
												outPutText = outPutText + temp_2
										else :
											outPutText = outPutText + outText_obj[1].get_text()
									count = count + 1
						if outPutText != '':
							test = kbn.replace('\n', '') + ',' + ken.replace('\n', '') + ',' + '' + outPutText
							output_txt.write(test)
			output_txt.close()
		print(pdf[1], ',レコード数', count)

	def load_csv(wb, i):
		ws = wb.active
		print(u'エクセル変換対象', outPutCsvPath)
		result_file = open(outPutCsvPath, encoding= 'utf-8_sig')
		line = result_file.readline()
		isFirst = True
		exclusionWord03 = ["専門医・専門医指導医・特定指導医リスト\n"]

		contertCounter = 0
		cellIndex = 2
		ken = ''
		while line:
			if line not in exclusionWord03:
				# 下記は氏名と氏名の間が空白表示
				if re.match(r'(^(.)+(,)+(.)+(,)+(ﾙｲｽﾞ|ﾒﾙﾆｪｲ))', line):
					tempStr = []
					tempStr = line.split(',')
					nameList = str(tempStr[2].replace('\n', '')).split('\u3000', 1)
					for name in nameList:
						ws.cell(row = cellIndex, column = 1).value = tempStr[0]
						ws.cell(row = cellIndex, column = 2).value = tempStr[1]
						ws.cell(row = cellIndex, column = 3).value = ''
						ws.cell(row = cellIndex, column = 4).value = name.strip()
						contertCounter +=1
						cellIndex += 1
				
				else:
					tempStr = []
					tempStr = line.split(',')
					if len(tempStr) == 3:
						ws.cell(row = cellIndex, column = 1).value = tempStr[0]
						ws.cell(row = cellIndex, column = 2).value = tempStr[1]
						ws.cell(row = cellIndex, column = 3).value = ''
						ws.cell(row = cellIndex, column = 4).value = tempStr[2].replace('\n', '')
					contertCounter +=1
					cellIndex += 1
			line = result_file.readline()
			isFirst = False
			
		print(u'変換処理数：', contertCounter)
		result_file.close

	if __name__ == '__main__':
		wb = openpyxl.Workbook()
		ws = wb.active
		ws.title = "WorkSheetTitle"
		ws.sheet_properties.tabColor = "1072BA"
		fill = PatternFill(patternType='solid', fgColor='36bd11')
		for rows in ws['A1':'D1']:
			for cell in rows:
				ws[cell.coordinate].fill = fill
		ws["A1"] = "区分"
		ws["B1"] = "都道府県"
		ws["C1"] = "施設名"
		ws["D1"] = "個人名"
			
		ws.auto_filter.ref = 'A1:D1'

		load_pdf()
		load_csv(wb, cellIndex)
		
		wb.save(outPutFile)
		
		print(u'同名ファイル存在チェック : ', os.access(outPutFile,os.F_OK))
		if(os.access(outPutFile,os.F_OK)):
			print(u'ファイル削除')
			os.remove(outPutFile)
			print(u'同名ファイル存在チェック : ', os.access(outPutFile,os.F_OK))
		wb.save(outPutFile)
		print(u'Excel変換終了')