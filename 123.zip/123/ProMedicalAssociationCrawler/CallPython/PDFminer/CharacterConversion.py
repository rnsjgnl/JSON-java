import os, sys, io, math, re
import unicodedata
cid_file_Path = "./config/CharacterConversionList.csv"
unicode_file_Path = "./config/UnicodeCharacterConversionList.csv"


def conversionFunction(inputtext):
	"""cid文字をCharacterConversionList.csvを元に変換"""
	
	# cid文字コードを変換リスト通りに変換
	try:
		# 変換テーブルの読込
		open_text = open(cid_file_Path, encoding="utf_8_sig")
		load_text = open_text.read().replace('\n', '')
		open_text.close()
		
		# 変換リストを辞書形式で読込
		replacements = {}
		for comma_Delimiter_list in load_text.split(','):
			delimiter_Character_ist = comma_Delimiter_list.split('=')
			replacements[delimiter_Character_ist[0]] = delimiter_Character_ist[1]
		return re.sub('({})'.format('|'.join(map(re.escape, replacements.keys()))), lambda m: replacements[m.group()], inputtext)
	except Exception as e:
		print(e)


def unicodeConversionFunction(inputtext):
	"""unicode文字をUnicodeCharacterConversionList.csvを元に変換"""
	
	# unicodeコードを変換リスト通りに変換
	try:
		# 変換テーブルの読込
		list_text = ascii(inputtext)
		open_text = open(unicode_file_Path, encoding="utf_8_sig")
		load_text = open_text.read().replace('\n', '')
		open_text.close()
		
		# 変換リストを辞書形式で読込
		replacements = {}
		
		# UnicodeCharacterConversionList.CSVを元に辞書を作成
		for comma_Delimiter_list in load_text.split(','):
			delimiter_Character_ist = comma_Delimiter_list.split('=')
			replacements[delimiter_Character_ist[0]] = delimiter_Character_ist[1]
		
		# 辞書のkeyにヒットで値を置換
		for key in replacements:
			if key in list_text:
				print('変換対象文字コードが存在します。')
				list_text = list_text.replace(key, replacements[key])
		return list_text.encode().decode('unicode-escape')
	except Exception as e:
		print(e)