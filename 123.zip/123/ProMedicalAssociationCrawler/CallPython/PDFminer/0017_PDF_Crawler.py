import openpyxl
import os, sys, io, json, math, re

from openpyxl.styles import PatternFill
from pdfminer.pdfinterp import PDFPageInterpreter, PDFResourceManager
from pdfminer.pdfpage import PDFPage
from pdfminer.converter import PDFPageAggregator, TextConverter
from pdfminer.layout import LAParams, LTContainer, LTTextBox, LTTextLine, LTAnno

csvFileDir = 'data/'
pdfFileDir = 'pdfData/'
excelFileDir = 'ExcelData/'
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
data = sys.stdin.buffer.read()
jsonData = json.loads(data.decode())
society = jsonData["society"]
code = jsonData["code"]
convertPdfs = jsonData["filePath"]
pdfMaxNumver = 0
pdfCounter = 0
cellIndex = 2
outPutFile = excelFileDir + code + '_' + society + '.xlsx'

for pdf in enumerate(convertPdfs) :
	pdfMaxNumver = len(convertPdfs)
	pdfCounter += 1
	pdfFileName = pdf[1].split('/')
	KenName = pdfFileName[1].replace('.pdf', '')
	pdfFilePath = pdfFileDir + KenName + '.pdf'
	tempCsvPath = csvFileDir + KenName + '.csv'
	output_txt = open(tempCsvPath, 'w', encoding='utf-8_sig')
	print(u'対象ファイル : ', pdfFilePath)
	print(u'ファイル存在チェック : ', os.access(pdfFilePath,os.F_OK))
	print(u'ファイル読込チェック : ', os.access(pdfFilePath,os.R_OK))
	print(' [', pdfCounter, '/' , pdfMaxNumver, ']', ':', KenName)

	laparams = LAParams(all_texts=True, detect_vertical=False,
	 line_overlap=0.5, char_margin=1000.0, line_margin=0.5, word_margin=0.1, boxes_flow=1)
	resource_manager = PDFResourceManager()
	device = PDFPageAggregator(resource_manager, laparams=laparams)
	interpreter = PDFPageInterpreter(resource_manager, device)

	def find_textboxes_recursively(layout_obj):
		if isinstance(layout_obj, LTTextBox):
			return [layout_obj]
		if isinstance(layout_obj, LTContainer):
			boxes = []
			for child in layout_obj:
				boxes.extend(find_textboxes_recursively(child))
			return boxes
		return []

	def load_pdf():	
		count = 0
		with open(pdfFilePath, 'rb') as pdffile:
			for page in PDFPage.get_pages(pdffile):
				interpreter.process_page(page)
				layout = device.get_result()
				boxes = find_textboxes_recursively(layout)
				boxes.sort(key=lambda b: (-b.y1, b.x0))
				for box in enumerate(boxes):
					outPutText = ''
					if isinstance(box[1], LTTextBox) or isinstance(box[1], LTTextLine):
						if box[1]._objs:
							for text_obj in box[1]._objs:
								if isinstance(text_obj, LTTextBox) or isinstance(text_obj,LTTextLine):
									for outText_obj in  enumerate(text_obj._objs):
										if isinstance(outText_obj[1], LTAnno):
											temp = outText_obj[1].get_text()
											if temp == ' ':
												temp_1 = outText_obj[1].get_text()
												outPutText = outPutText + ','
											else :
												temp_2 = outText_obj[1].get_text()
												outPutText = outPutText + temp_2
										else :
											outPutText = outPutText + outText_obj[1].get_text()
									count += 1
				output_txt.write(outPutText)
			output_txt.close()
		print(KenName, ',レコード数', count)

	def load_csv(wb, i):
		ws = wb.active
		print(u'エクセル変換対象', tempCsvPath)
		tempNo = tempCsvPath.split('_')[1]
		tempName = tempCsvPath.split('_')[2].replace('.csv', '')
		result_file = open(tempCsvPath, encoding= 'utf-8_sig')
		line = result_file.readline()
		isFirst = True
		exclusionWord = ["専門医名,施設名,施設住所"]
		convertCounter = 0
		global cellIndex
		while line:
			if line.strip() != "氏名" and not line.strip().replace(" ", "") in exclusionWord and not isFirst:
				tempStr = []
				tempStr = line.split(',')
				for strItem in enumerate(tempStr):
					if tempNo == '99':
						ws.cell(row = cellIndex, column = 2).value = tempName
					if strItem[0] == 0:
						ws.cell(row = cellIndex, column = 1).value = '専門医'
						ws.cell(row = cellIndex, column = 4).value = tempStr[strItem[0]].rstrip()
					if strItem[0] == 1:
						ws.cell(row = cellIndex, column = 3).value = tempStr[strItem[0]].rstrip()
					if strItem[0] == 2:
						Index = tempStr[strItem[0]].find('県',2 , 4)
						if Index == -1:
							Index = tempStr[strItem[0]].find('都',2 , 4)
						if Index == -1:
							Index = tempStr[strItem[0]].find('道',2 , 4)
						if Index == -1:
							Index = tempStr[strItem[0]].find('府',2 , 4)
						ws.cell(row = cellIndex, column = 2).value = tempStr[2].rstrip()[0:Index + 1]
				cellIndex += 1
				convertCounter +=1
			line = result_file.readline()
			isFirst = False
		print(u'変換処理数：', convertCounter)
		result_file.close

	if __name__ == '__main__':
		if pdfCounter == 1 :
			wb = openpyxl.Workbook()
			ws = wb.active
			ws.title = "WorkSheetTitle"
			ws.sheet_properties.tabColor = "1072BA"
			fill = PatternFill(patternType='solid', fgColor='36bd11')
			for rows in ws['A1':'D1']:
				for cell in rows:
					ws[cell.coordinate].fill = fill
			ws["A1"] = "区分"
			ws["B1"] = "都道府県"
			ws["C1"] = "施設名"
			ws["D1"] = "個人名"
			ws.auto_filter.ref = 'A1:D1'
			
		load_pdf()
		load_csv(wb, cellIndex)
		
		if pdfCounter == pdfMaxNumver :
			if(os.access(outPutFile,os.F_OK)):
				print(u'同名ファイル存在チェック : ', os.access(outPutFile,os.F_OK))
				print(u'ファイル削除')
				os.remove(outPutFile)
				print(u'同名ファイル存在チェック : ', os.access(outPutFile,os.F_OK))
			wb.save(outPutFile)
			print(u'Excel変換終了')