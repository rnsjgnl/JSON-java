import openpyxl
import os, sys, io, json, math, re

from time import sleep

from openpyxl.styles import PatternFill
from pdfminer.pdfinterp import PDFPageInterpreter, PDFResourceManager
from pdfminer.pdfpage import PDFPage
from pdfminer.converter import PDFPageAggregator, TextConverter
from pdfminer.layout import LAParams, LTContainer, LTTextBox, LTTextLine, LTAnno

csvFileDir = 'data/'
excelFileDir = 'ExcelData/'
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
data = sys.stdin.buffer.read()
jsonData = json.loads(data.decode())
fileName = jsonData["code"] + '_' + jsonData["society"] + '_' + jsonData["today"]
convertPdfs = jsonData["filePath"]

# 取得対象外文字列
excusion_List = ['日本肝臓学会','肝臓学会肝臓専門医一覧 ','※印は認定施設/＊','アンダーラインは指導医(うち点線は暫定指導医)']

# 施設名に空白が含まれている施設一覧
Facility_Including_Blank_List = [
	# 北海道・東北
	'・水色の木もれ陽','津軽保健生協','静和会','JCHO','IMC'
	# 関東・甲信越
	,'慈正会','顕正会','メディカルコミニティ','竹内','社団','つるかめ会','シンセリティ','ホクレア','※がん・感染症センター','武蔵野台クリニック','総合健診センター','喜望会','守成会'
	,'宜保内科','竹山会南那須介護老人介護施設','竹山会南那須介護老人介護施設','社団 栄陽会','東京都保健医療公社','内科･消化器科','Ai','介護老人健康施設','神奈川県結核予防会'
	# 東海・北陸
	,'秋桜','中津川市国民健康保険','翠風会','あずま会','医療法人慶和会','藤が丘北'
	# 近畿
	,'関西労働保健協会','錦秀会','好也会','医仁会','一祐会','阪急電鉄株式会社','愛仁会','北樟会','内科・消化器内科','秀博会','錦秀会','関西労働保健協会'
	# 中国・四国
	,'川口内科','総合病院','ブルースカイ','聖ルカ会'
	# 九州
	,'アカデミア','相生会','社会医療法人シマダ','寛晴会','鎮寿会','隆成会']

pdfMaxNumver = 0
pdfCounter = 0
cellIndex = 2

for pdf in enumerate(convertPdfs) :
	pdfMaxNumver = len(convertPdfs)
	pdfCounter += 1
	pdfFilePath = pdf[1]
	outPutCsvPath = csvFileDir + pdf[1].replace('pdfData/', '').replace('.pdf', '.csv')
	outPutFile = excelFileDir + pdf[1].replace('pdfData/', '').replace('.pdf', '.xlsx')
	output_txt = open(outPutCsvPath, 'w', encoding='utf-8_sig')
	print(' [', pdfCounter, '/' , pdfMaxNumver, ']', ':', pdf[1])

	laparams = LAParams(
		all_texts=True, detect_vertical=False, 
		line_overlap=0.1, char_margin=50,
		line_margin=0.1, word_margin=50,
		boxes_flow=1)
	resource_manager = PDFResourceManager()
	device = PDFPageAggregator(resource_manager, laparams=laparams)
	interpreter = PDFPageInterpreter(resource_manager, device)

	def find_textboxes_recursively(layout_obj):
		if isinstance(layout_obj, LTTextBox):
			return [layout_obj]

		if isinstance(layout_obj, LTContainer):
			boxes = []
			for child in layout_obj:
				boxes.extend(find_textboxes_recursively(child))
			return boxes
		return []

	def load_pdf():	
		count = 0
		ken = ''
		flag = False
		out_put_counter = 0
		
		name_List = []
		shi_name = ''
		ShiNameFlg = True
		
		with open(pdfFilePath, 'rb') as pdffile:
			for page in PDFPage.get_pages(pdffile):
				interpreter.process_page(page)
				layout = device.get_result()
				boxes = find_textboxes_recursively(layout)
				boxes.sort(key=lambda b: (-b.y1, b.x0))
				for box in enumerate(boxes):
					outPutText = ''
					if isinstance(box[1], LTTextBox) or isinstance(box[1], LTTextLine):
						if box[1]._objs:
							for text_obj in box[1]._objs:
								text = text_obj.get_text().replace('\n', '')
								
								# 取得対象外文字
								excusion_item = [i for i in excusion_List if text.startswith(i)]
								if len(excusion_item) != 0:
									continue
								
								# ページ番号をスキップ
								if re.match(r'(-)+([0-9])+(-)', text.replace(' ', '')) is not None:
									continue
								
								# 年月日をスキップ
								if re.match(r'([0-9])+年+([0-9])+月+([0-9])+日現在', text.replace(' ', '')) is not None:
									continue
								
								# 空白、記号をスキップ
								if text == ' ' or text == '※ ' or text == '＊ ':
									continue 
								
								# 施設名、医師名の開始位置を取得
								if text.startswith('＜  施  設  名  ＞ ＜  肝  臓  専  門  医  ＞'):
									ShiAndNameIndex = [i for i, x in enumerate(list(text_obj.get_text())) if x == '＜']
									ShiNameStartIndex = math.floor(text_obj._objs[ShiAndNameIndex[0]].x0)
									NameStartIndex = math.floor(text_obj._objs[ShiAndNameIndex[1]].x0)
									continue
								
								# 市、区、町をスキップ
								if re.match(r'^( )*(.)+(市|区|町)+( )*$', text) is not None and (re.match(r'(.)+(病院|医院)+(.)', text)) is None:
									continue
								
								# 都道府県名の取得
								page_num_match = re.search(r'^(.{2}[都道府県]|.{3}県)$', text.strip())
								if page_num_match:
									ken = text.strip().replace('\n', '')
									continue
								
								# 開始位置が氏名位置より小さい場合は施設名
								if math.floor(text_obj.x0) < NameStartIndex:
									ShiNameFlg = True
								
								# (東海・北陸地区PDF)記号の後にある施設名を医師名の後に読み込むため
								if text.startswith('中本安成、平松活志、'):
									shi_name = '福井大学医学部附属病院'
								if text.startswith('岡井 研、坂西康志、'):
									shi_name = '聖隷三方原病院'
								
								# 勤務先と氏名の読込
								if isinstance(text_obj, LTTextBox) or isinstance(text_obj,LTTextLine):
									for outText_obj in  enumerate(text_obj._objs):
										straight_line = outText_obj[1].get_text().replace('\n', '').strip()
										
										if ShiNameFlg:
											if straight_line in ' ':
												
												# 記号付き施設の場合、始めの空白で分割しない
												if outPutText == '＊' or outPutText == '※' or outPutText == '・' or outPutText == '･':
													continue
												
												# 末尾のブランクはスキップ
												if (outText_obj[0] + 1) == len(text_obj):
													continue
												
												# 取得対象外文字列が存在する場合スキップ
												FIB_List = [i for i in Facility_Including_Blank_List if outPutText == i]
												if len(FIB_List) != 0:
													outPutText = outPutText + outText_obj[1].get_text().replace('\n', '')
													continue
												
												# 施設名
												if straight_line in ' ' and outPutText is not '':
													# print(str(math.floor(outText_obj[1].x0)) + ' : ' + outPutText)
													shi_name = outPutText
													ShiNameFlg = False
													outPutText = ''
											else:
												outPutText = outPutText + outText_obj[1].get_text().replace('\n', '')
												
										# 氏名
										else:
											if straight_line == '、' or straight_line == '，':
												name_List.append(outPutText)
												outPutText = ''
											else:
												outPutText = outPutText + outText_obj[1].get_text().replace('\n', '')
												
									# 末尾の氏名
									if (outText_obj[0] + 1) == len(text_obj):
										name_List.append(outPutText)
										outPutText = ''
							# 出力処理
							for name in name_List:
								if name.strip() is not '':
									output_txt.write('専門医' + ',' + ken + ',' + shi_name + ',' + name.strip() + '\n')
									count += +1
							name_List = []
			output_txt.close()
		print(pdf[1], ',レコード数', count)

	def load_csv(wb, i):
		ws = wb.active
		print(u'エクセル変換対象', outPutCsvPath)
		result_file = open(outPutCsvPath, encoding= 'utf-8_sig')
		line = result_file.readline()
		isFirst = True
		contertCounter = 0
		cellIndex = 2
		ken = ''
		while line:
			if line not in '':
				tempStr = []
				tempStr = line.split(',')
				if len(tempStr) == 4:
					ws.cell(row = cellIndex, column = 1).value = tempStr[0].replace('\n','')
					ws.cell(row = cellIndex, column = 2).value = tempStr[1].replace('\n','')
					ws.cell(row = cellIndex, column = 3).value = tempStr[2].replace('\n','')
					ws.cell(row = cellIndex, column = 4).value = tempStr[3].replace('\n','')
				contertCounter +=1
				cellIndex += 1
			line = result_file.readline()
			isFirst = False
			
		print(u'変換処理数：', contertCounter)
		result_file.close

	if __name__ == '__main__':
		wb = openpyxl.Workbook()
		ws = wb.active
		ws.title = "WorkSheetTitle"
		ws.sheet_properties.tabColor = "1072BA"
		fill = PatternFill(patternType='solid', fgColor='36bd11')
		for rows in ws['A1':'D1']:
			for cell in rows:
				ws[cell.coordinate].fill = fill
		ws["A1"] = "区分"
		ws["B1"] = "都道府県"
		ws["C1"] = "施設名"
		ws["D1"] = "個人名"
			
		ws.auto_filter.ref = 'A1:D1'
		
		load_pdf()
		load_csv(wb, cellIndex)
		
		print(u'同名ファイル存在チェック : ', os.access(outPutFile,os.F_OK))
		if(os.access(outPutFile,os.F_OK)):
			print(u'ファイル削除')
			os.remove(outPutFile)
			print(u'同名ファイル存在チェック : ', os.access(outPutFile,os.F_OK))
		wb.save(outPutFile)
		print(u'Excel変換終了')