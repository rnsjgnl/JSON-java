import openpyxl
import os, sys, io, json, math, re

from time import sleep

from openpyxl.styles import PatternFill
from pdfminer.pdfinterp import PDFPageInterpreter, PDFResourceManager
from pdfminer.pdfpage import PDFPage
from pdfminer.converter import PDFPageAggregator, TextConverter
from pdfminer.layout import LAParams, LTContainer, LTTextBox, LTTextLine, LTAnno

sys.path.append('CallPython/PDFminer')
import CharacterConversion

csvFileDir = 'data/'
excelFileDir = 'ExcelData/'
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
data = sys.stdin.buffer.read()
jsonData = json.loads(data.decode())
fileName = jsonData["code"] + '_' + jsonData["society"] + '_' + jsonData["today"]
convertPdfs = jsonData["filePath"]

pdfMaxNumver = 0
pdfCounter = 0
cellIndex = 2

exclusion_List = ['梶井町 465', '上る梶井町 465', '横浜市都筑区茅ヶ崎中央 35-1', '（CRC A 棟 707 号室）', '国分寺市商工会館 4 階'
					, 'パシオス小田原店 1F', 'ジュネス・コート 1F', '12 階', '順天堂 OG ビル 2 階', '上る', 'ユニゾ本郷四丁目ビル'
					, '名古屋合同庁舎第 1 号館 6 階', '大川産婦人科・高砂ビル 7 階', '渚クリニックモール 2 階', '博多駅 FR ビル 7 階'
					, '摩耶クリニックビル', '番地', '管理棟 5 階 504', '梶井町 465 番地', '九州大学 小児外科 '] 

exclusion_List_2 = ['本名簿は学会登録データに','方は本会ホームページより','登録番号の最初の','登録番号先頭の']

for pdf in enumerate(convertPdfs) :
	pdfMaxNumver = len(convertPdfs)
	pdfCounter += 1
	
	pdfFilePath = pdf[1]
	outPutCsvPath = csvFileDir + pdf[1].replace('pdfData/', '').replace('.pdf', '.csv')
	outPutFile = excelFileDir + pdf[1].replace('pdfData/', '').replace('.pdf', '.xlsx')
	
	output_txt = open(outPutCsvPath, 'w', encoding='utf-8_sig')
	print(' [', pdfCounter, '/' , pdfMaxNumver, ']', ':', pdf[1])	
	
	laparams = LAParams(
		all_texts=True, detect_vertical=True, 
		line_overlap=0.1, char_margin=0.3,
		line_margin=1.4, word_margin=0.1,
		boxes_flow=1)
		
	resource_manager = PDFResourceManager()
	device = PDFPageAggregator(resource_manager, laparams=laparams)
	interpreter = PDFPageInterpreter(resource_manager, device)
	
	def find_textboxes_recursively(layout_obj):
		if isinstance(layout_obj, LTTextBox):
			return [layout_obj]
		if isinstance(layout_obj, LTContainer):
			boxes = []
			for child in layout_obj:
				boxes.extend(find_textboxes_recursively(child))
			return boxes
		return []
		
	def load_pdf():	
		count = 0
		kbn = ''
		temp_out_put_text = ''
		next_name_flg = False
		next_shisetu_flg = False
		with open(pdfFilePath, 'rb') as pdffile:
			for page in PDFPage.get_pages(pdffile):
				interpreter.process_page(page)
				layout = device.get_result()
				boxes = find_textboxes_recursively(layout)
				boxes.sort(key=lambda b: (-b.y1, b.x0))
				# 格納リスト
				shisetu_list = []
				name_list = []
				righ_name_list = []
				for box in enumerate(boxes):
					if isinstance(box[1], LTTextBox) or isinstance(box[1], LTTextLine):
						if box[1]._objs:
							for text_obj in box[1]._objs:
								test_text = text_obj.get_text()
								text_index = text_obj.x0
								# ページ番号を取得しない
								if re.fullmatch(r'[0-9]{2,3}', test_text.replace('\n', '')):
									print('ページ番号' + test_text.replace('\n', ''))
									continue
								# 区分
								if test_text.startswith('指　導　医　名　簿'):
									kbn = '指導医'
									continue
								if test_text.startswith('小児外科専門医'):
									kbn = '専門医'
									continue
								# 取得対象名簿タイトル
								if test_text.startswith('小児外科認定'):
									end_Flg = True
									print('取得対象外名簿が読み込まれました。' + '\n' + '[' + test_text.replace('\n', '') + ']')
									break
								# タイトル、説明文を取得しない
								exclusion_Item = [i for i in exclusion_List_2 if test_text.startswith(i)]
								if len(exclusion_Item) > 0:
									continue
								# 年月を取得しない
								if re.match(r'([\d]+(.)+年+(.)+月現在)', test_text.replace('\n', '')):
									continue
								# ビル名等を取得しない
								if re.match(r'^(?!.*〒)((.)+(階|([0-9]F)|ビル))$', test_text.replace('\n', '')):
									# print('ビル名が表示されました。', test_text.replace('\n', ''))
									continue
								# 住所単体を取得しない
								exclusion_Item = [i for i in exclusion_List if test_text.replace('\n', '') == i]
								if len(exclusion_Item) != 0:
									# print('住所単体が表示されました。', test_text.replace('\n', '') )
									continue
								# 施設名の取得
								if isinstance(text_obj, LTTextBox) or isinstance(text_obj,LTTextLine):
									# 〒番号が取得された場合、施設出力フラグを立てる
									if re.match(r'〒', test_text):
										next_shisetu_flg = True	
									# 海外施設の場合
									elif re.match(r'([0-9]{3})+(.)+Street+(.)', test_text):
										next_shisetu_flg = True
									elif re.match(r'(.)+HospitalMulti-organ+(.)', test_text):
										temp_out_put_text = temp_out_put_text + test_text.strip().replace('\n', '')
									elif temp_out_put_text != '':
										temp_out_put_text = temp_out_put_text + ' ' + test_text.strip().replace('\n', '')
									else:
										temp_out_put_text = test_text.strip().replace('\n', '')
								# 登録番号は取得しない
								if re.match(r'^[0-9]{5}', test_text.replace('\n', '')):
									# print('登録番号が読み込まれました', test_text.replace('\n', ''))
									next_name_flg = True
									temp_out_put_text = ''
									continue
								# 住所が取得された場合施設名をリストに保存
								if next_shisetu_flg:
									# 出力対象外文字が含まれている場合、削除
									exclusion_Item = [i for i in exclusion_List if i in temp_out_put_text.replace('\n', '')]
									if len(exclusion_Item) != 0:
										temp_out_put_text = temp_out_put_text.replace(exclusion_Item[0], '').strip()
									temp_out_put_text = temp_out_put_text.strip().rstrip('　').replace('\n', ' ')
									shisetu_list.append(temp_out_put_text + '\n')
									temp_out_put_text = ''
									next_shisetu_flg = False
								# 登録番号が取得された時施設名をリストに保存
								if next_name_flg:
									# ページの右辺から氏名を読み込む場合右辺用の氏名リストに追加
									if text_index > 250:
										righ_name_list.append(temp_out_put_text)
									else:
										name_list.append(temp_out_put_text)
									temp_out_put_text = ''
									next_name_flg = False
				# 右辺の氏名リストを追加
				if len(righ_name_list) > 0:
					for i in righ_name_list:
						name_list.append(i)
				# 施設名が記載されていない場合
				if len(shisetu_list) != len(name_list):
					print('施設数と氏名数に差分が有ります。[施設数：' , len(shisetu_list) , '],[氏名数：' , len(name_list) , ']')
					# 施設名が存在しない
					insert_item = [i for i in name_list if i in ['小角　卓也','佐藤かおり','池田　　均','原　普二夫','白月　　遼']]
					for j in insert_item:
						shisetu_list.insert(name_list.index(j),'')
						print('施設の記載が存在しない氏名です。[', j, ']')
					print('施設に空白を挿入します。[施設数：' , len(shisetu_list) , '],[氏名数：' , len(name_list) , ']')
				# 特殊対応施設
				for i in enumerate(name_list):
					shisetu = shisetu_list[i[0]].replace('\n', '')
					if re.match(r'^A +(.)', shisetu):
						shisetu = shisetu.replace(' J', '').replace('A ', 'JA ')
						print('JA施設特殊対応[', shisetu_list[i[0]].replace('\n', '') , ']⇒[' ,shisetu, ']')
					# tt = kbn + ',' + ',' + i[1].replace('\n', '') + ',' + name_list[i[0]]
					out_Text = kbn + ','  + ',' + i[1].replace('\n', '') + ',' + shisetu + '\n'
					count = count + 1
					output_txt.write(out_Text)
			# output_txt.write(outPutText + '\n')
			output_txt.close()
		print(pdf[1], ',レコード数', count)

	def load_csv(wb, i):
		ws = wb.active
		print(u'エクセル変換対象', outPutCsvPath)
		result_file = open(outPutCsvPath, encoding= 'utf-8_sig')
		line = result_file.readline()
		isFirst = True
		exclusionWord03 = ["専門医・専門医指導医・特定指導医リスト\n"]

		contertCounter = 0
		cellIndex = 2
		ken = ''
		while line:
			if line not in exclusionWord03:
				
				if 'cid' in line:
					print('CID文字コード変換前', line.replace('\n', ''))
					line = CharacterConversion.conversionFunction(line)
					print('CID文字コード変換後', line.replace('\n', ''))
				
				tempStr = []
				tempStr = line.split(',')
				if len(tempStr) >= 4:
					ws.cell(row = cellIndex, column = 1).value = tempStr[0].replace('\n','').strip()
					ws.cell(row = cellIndex, column = 2).value = tempStr[1].replace('\n','').strip()
					ws.cell(row = cellIndex, column = 4).value = tempStr[2].replace('\n','').strip()
					ws.cell(row = cellIndex, column = 3).value = tempStr[3].replace('\n','').strip()
				contertCounter +=1
				cellIndex += 1
			line = result_file.readline()
			isFirst = False
			
		print(u'変換処理数：', contertCounter)
		result_file.close

	if __name__ == '__main__':
		wb = openpyxl.Workbook()
		ws = wb.active
		ws.title = "WorkSheetTitle"
		ws.sheet_properties.tabColor = "1072BA"
		fill = PatternFill(patternType='solid', fgColor='36bd11')
		for rows in ws['A1':'D1']:
			for cell in rows:
				ws[cell.coordinate].fill = fill
		ws["A1"] = "区分"
		ws["B1"] = "都道府県"
		ws["C1"] = "施設名"
		ws["D1"] = "個人名"
		
		ws.auto_filter.ref = 'A1:D1'
		
		load_pdf()
		load_csv(wb, cellIndex)
		
		print(u'同名ファイル存在チェック : ', os.access(outPutFile,os.F_OK))
		if(os.access(outPutFile,os.F_OK)):
			print(u'ファイル削除')
			os.remove(outPutFile)
			print(u'同名ファイル存在チェック : ', os.access(outPutFile,os.F_OK))
		wb.save(outPutFile)
		print(u'Excel変換終了')