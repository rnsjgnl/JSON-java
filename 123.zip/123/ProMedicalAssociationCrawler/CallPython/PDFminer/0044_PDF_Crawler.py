import openpyxl
import os, sys, io, json
import re

from openpyxl.styles import PatternFill
from pdfminer.pdfinterp import PDFPageInterpreter, PDFResourceManager
from pdfminer.pdfpage import PDFPage
from pdfminer.converter import PDFPageAggregator, TextConverter
from pdfminer.layout import LAParams, LTContainer, LTTextBox, LTTextLine, LTAnno

csvFileDir = 'data/'
excelFileDir = 'ExcelData/'
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
data = sys.stdin.buffer.read()
jsonData = json.loads(data.decode())
fileName = jsonData["code"] + '_' + jsonData["society"] + '_' + jsonData["today"]
pdfFilePath = jsonData["filePath"]
outPutCsvPath = csvFileDir + fileName + '.csv'
print(u'対象ファイル : ', pdfFilePath)
print(u'ファイル存在チェック : ', os.access(pdfFilePath,os.F_OK))
print(u'ファイル読込チェック : ', os.access(pdfFilePath,os.R_OK))

# Layout Analysisのパラメーターを設定。縦書きの検出を有効にする。
laparams = LAParams(detect_vertical=True)

# 共有のリソースを管理するリソースマネージャーを作成。
resource_manager = PDFResourceManager()

# ページを集めるPageAggregatorオブジェクトを作成。
device = PDFPageAggregator(resource_manager, laparams=laparams)

# Interpreterオブジェクトを作成。
interpreter = PDFPageInterpreter(resource_manager, device)

# 出力用のテキストファイル
output_txt = open(outPutCsvPath, 'w', encoding='utf-8_sig')

def find_textboxes_recursively(layout_obj):
	if isinstance(layout_obj, LTTextBox):
		return [layout_obj]
		
	if isinstance(layout_obj, LTContainer):
		boxes = []
		for child in layout_obj:
			boxes.extend(find_textboxes_recursively(child))
		return boxes
	return []

def text_res(lt_objs):
	outPutText = ''
	for lt_text_obj in lt_objs:
		if isinstance(lt_text_obj, LTTextBox) or isinstance(lt_text_obj, LTTextLine):
			if lt_text_obj._objs:
				for text_obj in lt_text_obj._objs:
					if isinstance(text_obj, LTTextBox) or isinstance(text_obj,LTTextLine):
						ast = ''
						for outText_obj in  enumerate(text_obj._objs):
							if isinstance(outText_obj[1], LTAnno):
								outPutText = outPutText + '\n'
								if ((re.search(r'(　)+', outPutText)) is not None):
									outPutText = outPutText.replace('　', '')
							else:
								if outText_obj[1].get_text() == '*':
									ast = outText_obj[1].get_text() + ',' 
								else:

									if ast == '':
										outPutText = outPutText + outText_obj[1].get_text()
									else:
										outPutText = outPutText.replace(' ','') + ast + outText_obj[1].get_text()
										ast = ''
	return outPutText

def print_and_write(txt):
	output_txt.write(txt)

def load_pdf():
	with open(pdfFilePath, 'rb') as f:
		for page in PDFPage.get_pages(f):
			interpreter.process_page(page)
			layout = device.get_result()
			outPutText = text_res(layout)
			print_and_write(outPutText)
	output_txt.close()

def load_csv(wb):
	ws = wb.active
	print(u'エクセル変換対象', outPutCsvPath)
	result_file = open(outPutCsvPath, encoding= 'utf-8_sig')
	line = result_file.readline()
	i = 2
	isFirst = True
	exclusionWord = ["あ行","か行","さ行","た行","な行","は行","ま行","や行","ら行","わ行"]
	while line:
		if line not in '有限責任中間法人\u3000日本核医学会\u3000専門医・認定医(*,)名簿（50音順）\n':
			if line.strip() != "氏名" and not line.strip().replace(" ", "") in exclusionWord and not isFirst:
				tempStr = []
				tempStr = line.split(',')
				count = len(tempStr)
				if count > 1:
					ws.cell(row = i, column = 1).value = '認定医'
					ws.cell(row = i, column = 4).value = tempStr[1].rstrip()
					i+=1
				else:
					ws.cell(row = i, column = 1).value = '専門医'
					ws.cell(row = i, column = 4).value = tempStr[0].rstrip()
					i+=1
				if tempStr[0] in '笠木\u3000寛治\u3000\n':
					print()
		line = result_file.readline()
		isFirst = False
	result_file.close

if __name__ == '__main__':
	wb = openpyxl.Workbook()
	ws = wb.active
	ws.title = "WorkSheetTitle"
	ws.sheet_properties.tabColor = "1072BA"

	# set data
	fill = PatternFill(patternType='solid', fgColor='36bd11')
	for rows in ws['A1':'D1']:
		for cell in rows:
			ws[cell.coordinate].fill = fill
	ws["A1"] = "区分"
	ws["B1"] = "都道府県"
	ws["C1"] = "施設名"
	ws["D1"] = "個人名"
	
	load_pdf()
	load_csv(wb)
	
	ws.auto_filter.ref = 'A1:D1'
	
	outPutFile = excelFileDir + fileName + '.xlsx'
	if(os.access(outPutFile,os.F_OK)):
		print(u'同名ファイル存在チェック : ', os.access(outPutFile,os.F_OK))
		print(u'ファイル削除')
		os.remove(outPutFile)
		print(u'同名ファイル存在チェック : ', os.access(outPutFile,os.F_OK))
	wb.save(outPutFile)
	print(u'Excel変換終了')