import openpyxl
import os, sys, io, json, math, re
import glob
from time import sleep
from openpyxl.styles import PatternFill
from pdfminer.pdfinterp import PDFPageInterpreter, PDFResourceManager
from pdfminer.pdfpage import PDFPage
from pdfminer.converter import PDFPageAggregator, TextConverter
from pdfminer.layout import LAParams, LTContainer, LTTextBox, LTTextLine, LTAnno

csvFileDir = 'data/'
pdfFileDir = 'pdfData/'
excelFileDir = 'ExcelData/'

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
data = sys.stdin.buffer.read()
jsonData = json.loads(data.decode())
pdfFilePath = jsonData["filePath"]
society_code = jsonData["code"]
society_Name = jsonData["society"]

# 連携ディレクト内のPDFを取得
temp_pdf_dir = os.walk(pdfFilePath[0])
temp_pdf_file_list = []
convertPdfs = []
for pdf_files in temp_pdf_dir:
	temp_pdf_file_list = pdf_files[2]
	for pdf_file in temp_pdf_file_list:
		pdf_extension_Survey_match = re.search(r'^(.)+.pdf+$', pdf_file)
		if pdf_extension_Survey_match:
			convertPdfs.append(pdf_file)
		else:
			print(r'拡張子.PDF以外のファイルが存在します。', pdf_file)

# csv格納ディレクトリを作成する
createCsvDir = csvFileDir + society_code + '_' + str(society_Name) 
if not os.path.exists(createCsvDir):
	print(r'csv格納ディレクトリを作成します。[', society_code + '_' + str(society_Name), ']')
	os.mkdir(createCsvDir)

pdfMaxNumver = 0
pdfCounter = 0
cellIndex = 2

for pdf in enumerate(convertPdfs) :
	temp_file_name = pdf[1].replace('.pdf', '')
	pdfMaxNumver = len(convertPdfs)
	pdfCounter += 1
	pdfFilePath = pdfFileDir + society_code + '_' + str(society_Name) + '/' + str(temp_file_name) + '.pdf'
	outPutCsvPath = csvFileDir + society_code + '_' + str(society_Name) + '/' + str(temp_file_name) + '.csv'
	output_txt = open(outPutCsvPath, 'w', encoding='utf-8_sig')	
	outPutFile = excelFileDir + society_code + '_' + society_Name + '_' + jsonData["today"] + '.xlsx'
	laparams = LAParams(
		all_texts=True, detect_vertical=False, 
		line_overlap=0.1, char_margin=2.0,
		line_margin=0.1, word_margin=0.5,
		boxes_flow=1)
	resource_manager = PDFResourceManager()
	device = PDFPageAggregator(resource_manager, laparams=laparams)
	interpreter = PDFPageInterpreter(resource_manager, device)

	def find_textboxes_recursively(layout_obj):
		if isinstance(layout_obj, LTTextBox):
			return [layout_obj]

		if isinstance(layout_obj, LTContainer):
			boxes = []
			for child in layout_obj:
				boxes.extend(find_textboxes_recursively(child))
			return boxes
		return []

	def load_pdf():	
		count = 0
		with open(pdfFilePath, 'rb') as pdffile:
			print(pdffile)
			for page in PDFPage.get_pages(pdffile):
				interpreter.process_page(page)
				layout = device.get_result()
				boxes = find_textboxes_recursively(layout)
				boxes.sort(key=lambda b: (-b.y1, b.x0))
				for box in enumerate(boxes):
					outPutText = ''
					if isinstance(box[1], LTTextBox) or isinstance(box[1], LTTextLine):
						if box[1]._objs:
							# 
							pdf_text = box[1].get_text().replace('\n', '')
							# ページ番号
							page_num_match = re.search(r'^([0-9]|[０-９]])+$', pdf_text.strip())
							if page_num_match:
								continue
							# 日付
							prefectures_match = re.search(r'(\d+)年(\d+)月(\d+)日現在', pdf_text)
							if prefectures_match:
								print(outPutText)
								continue
							# タイトル(重複して取得する)
							prefectures_match1 = re.search(r'(日本)(.)*(（五十音順）)$', pdf_text)
							if prefectures_match1:
								continue
							# 都道府県名
							prefectures_match = re.search(r'^(■)(.)+', pdf_text)
							if prefectures_match:
								prefectures_text = ''
								str_count = 1
								for text_obj in box[1]._objs:
									if isinstance(text_obj, LTTextBox) or isinstance(text_obj,LTTextLine):
										for outText_obj in  enumerate(text_obj._objs):
											text_str = outText_obj[1].get_text().replace('\n', '')
											if text_str != '■':
												if str_count % 2 == 1:
													prefectures_text = prefectures_text + str(text_str)
												str_count = str_count + 1
										print(r'都道府県名:', prefectures_text)
								continue
							# 特別対応が必要な文字列
							specialSupport = None
							if specialSupport is None:# PDF_茨城県_特別対応
								specialSupport = re.search('アディクリスナ(.)ラマ+(.)', pdf_text)
							if specialSupport is None:# PDF_兵庫県_特別対応
								specialSupport = re.search('Kumiko Nakamura+(.)', pdf_text)
							if specialSupport is None:# PDF_東京都_特別対応
								specialSupport = re.search('tsukasa furuhata+(.)', pdf_text)
							if specialSupport is None:# PDF_東京都_特別対応
								specialSupport = re.search('マツザキジュンタロウ+(.)', pdf_text)
							if specialSupport is None:# PDF_長野県_特別対応
								specialSupport = re.search('麻植　ホルム　正之+(.)', pdf_text)
							if specialSupport is None:# PDF_神奈川_特別対応
								specialSupport = re.search('木村　ジェニファー由衣+(.)', pdf_text)
							if specialSupport is None:# PDF_神奈川_特別対応
								specialSupport = re.search('タルマン　寺本　穂波+(.)', pdf_text)
							
							# 特別対応
							if specialSupport:
								for i in range(len(pdf_text.split(str(specialSupport.group(0))))):
									if i == 0:
										text = (pdf_text[:specialSupport.end()]).strip()
										outPutText = outPutText + '専門医' + ',' + prefectures_text + ',' + text + '\n'
										count = count +1
										output_txt.write(outPutText)
										outPutText = ''
									else:
										text = (pdf_text[specialSupport.end():]).strip()
										outPutText = outPutText + '専門医' + ',' + prefectures_text + ',' + text + '\n'
										count = count +1
							else:
								text  = pdf_text.strip()
								outPutText = outPutText + '専門医' + ',' + prefectures_text + ',' + text + '\n'
								count = count +1
						output_txt.write(outPutText)
			output_txt.close()
		print(pdf[1], ',レコード数', count)
	def load_csv(wb, i):
		ws = wb.active
		print(u'エクセル変換対象', outPutCsvPath)
		result_file = open(outPutCsvPath, encoding= 'utf-8_sig')
		line = result_file.readline()
		isFirst = True
		exclusionWord = ["専門医名,施設名,施設住所"]
		convertCounter = 0
		global cellIndex
		while line:
			if line.strip() != "氏名" and line != '':
				tempStr = []
				tempStr = line.split(',')
				ws.cell(row = cellIndex, column = 1).value = tempStr[0]
				ws.cell(row = cellIndex, column = 2).value = tempStr[1]
				ws.cell(row = cellIndex, column = 4).value = tempStr[2].replace('\n', '')
				cellIndex += 1
				convertCounter +=1
			line = result_file.readline()
			isFirst = False
		print(u'変換処理数：', convertCounter)
		result_file.close

	if __name__ == '__main__':
		if pdfCounter == 1 :
			wb = openpyxl.Workbook()
			ws = wb.active
			ws.title = "WorkSheetTitle"
			ws.sheet_properties.tabColor = "1072BA"
			fill = PatternFill(patternType='solid', fgColor='36bd11')
			for rows in ws['A1':'D1']:
				for cell in rows:
					ws[cell.coordinate].fill = fill
			ws["A1"] = "区分"
			ws["B1"] = "都道府県"
			ws["C1"] = "施設名"
			ws["D1"] = "個人名"
			ws.auto_filter.ref = 'A1:D1'
			
		load_pdf()
		load_csv(wb, cellIndex)
		
		if pdfCounter == pdfMaxNumver :
			print(u'出力先のディレクトリとファイル名', outPutFile)
			if(os.access(outPutFile,os.F_OK)):
				print(u'同名ファイル存在チェック : ', os.access(outPutFile,os.F_OK))
				print(u'ファイル削除')
				os.remove(outPutFile)
				print(u'同名ファイル存在チェック : ', os.access(outPutFile,os.F_OK))
			wb.save(outPutFile)
			print(u'Excel変換終了')