import openpyxl
import os, sys, io, json, math, re
import chardet
import datetime
from time import sleep
from openpyxl.styles import PatternFill
from pdfminer.pdfinterp import PDFPageInterpreter, PDFResourceManager
from pdfminer.pdfpage import PDFPage
from pdfminer.converter import PDFPageAggregator, TextConverter
from pdfminer.layout import LAParams, LTContainer, LTTextBox, LTTextLine, LTAnno

now = datetime.datetime.now()
csvFileDir = 'data/'
pdfFileDir = 'pdfData/'
excelFileDir = 'ExcelData/'
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
data = sys.stdin.buffer.read()
jsonData = json.loads(data.decode())
society = jsonData["society"]
code = jsonData["code"]
convertPdfs = jsonData["filePath"]
pdfMaxNumver = 0
pdfCounter = 0
cellIndex = 2

for pdf in enumerate(convertPdfs) :
	pdfMaxNumver = len(convertPdfs)
	pdfCounter += 1
	pdfFileName = pdf[1].split('/')
	pdfName = pdfFileName[1].replace('.pdf', '')
	pdfFilePath = pdfFileDir + pdfName + '.pdf'
	outPutCsvPath = csvFileDir + pdfName + '.csv'
	output_txt = open(outPutCsvPath, 'w', encoding='utf-8_sig')
	outPutFile = excelFileDir + str(pdfName) + '_' + now.strftime("%Y%m%d") + '.xlsx'

	laparams = LAParams(
		all_texts=True, detect_vertical=True, 
		line_overlap=0.3, char_margin=1.0,
		line_margin=0.3, word_margin=0.2,
		boxes_flow=1)
	resource_manager = PDFResourceManager()
	device = PDFPageAggregator(resource_manager, laparams=laparams)
	interpreter = PDFPageInterpreter(resource_manager, device)

	def find_textboxes_recursively(layout_obj):
		if isinstance(layout_obj, LTTextBox):
			return [layout_obj]

		if isinstance(layout_obj, LTContainer):
			boxes = []
			for child in layout_obj:
				boxes.extend(find_textboxes_recursively(child))
			return boxes
		return []

	def load_pdf():	
		count = 0
		outPutText = ''
		specialSupportFlg = ''
		with open(pdfFilePath, 'rb') as pdffile:
			for page in PDFPage.get_pages(pdffile):
				interpreter.process_page(page)
				layout = device.get_result()
				boxes = find_textboxes_recursively(layout)
				boxes.sort(key=lambda b: (-b.y1, b.x0))
				for box in enumerate(boxes):
					if isinstance(box[1], LTTextBox) or isinstance(box[1], LTTextLine):
						if box[1]._objs:
							for text_obj in box[1]._objs:
								temporary_text = text_obj.get_text()
								prefectures_match = re.search(r'－(.+)－', temporary_text)
								if prefectures_match:
									ken = prefectures_match.group(1).replace(' ', '')
									continue
								prefectures_match = re.search(r'(\d+)年(\d+)月(\d+)日現在', temporary_text)
								if prefectures_match:
									continue
								shikaku_match = re.search(r'超音波(.+)一覧\n', temporary_text)
								if shikaku_match:
									sikaku = shikaku_match.group(1)
									continue
								if isinstance(text_obj, LTTextBox) or isinstance(text_obj,LTTextLine):
									number_text = text_obj.get_text()
									number_match = re.search(r'^\d+$', number_text)
									if number_match:
										# 特別対応
										if sikaku == "専門医" and (text_obj.get_text().replace('\n' ,'')) == '1599':
											output_txt.write(outPutText)
											outPutText = ''
											outPutText = outPutText + '\n'+ ken + ',' + sikaku
											count = count + 1
											continue
										if specialSupportFlg == '':
											output_txt.write(outPutText)
											outPutText = ''
											outPutText = outPutText + '\n'+ ken + ',' + sikaku
											count = count + 1
										else:
											temp_text = text_obj.get_text().replace('\n' ,'')
											outPutText = outPutText + ',' + temp_text
											specialSupportFlg = ''
										# 専門医PDF_小島　淳　特別対応
										if number_match.group(0).replace('\n', '') == '1907':
											specialSupportFlg = 'true'
										# 指導医PDF_小島　淳　特別対応
										if number_match.group(0).replace('\n', '') == '1599':
											specialSupportFlg = 'true'
									else:
										temp_text = text_obj.get_text().replace('\n' ,'')
										outPutText = outPutText + ',' + temp_text
			output_txt.write(outPutText)
			output_txt.close()
		print(pdf[1], ',レコード数', count)

	def load_csv(wb, i):
		ws = wb.active
		print(u'エクセル変換対象', outPutCsvPath)
		result_file = open(outPutCsvPath, encoding= 'utf-8_sig')
		line = result_file.readline()
		isFirst = True
		contertCounter = 0
		cellIndex = 2
		while line:
			if line not in ['\n', '岡山県,指導医\n']:
				tempStr = []
				tempStr = line.split(',')
				kubun = len(tempStr)
				# 区分、県名
				ws.cell(row = cellIndex, column = 1).value = tempStr[1]
				ws.cell(row = cellIndex, column = 2).value = tempStr[0]
				if kubun == 4:
					# 氏名、施設名共に改行が含まれていない場合
					ws.cell(row = cellIndex, column = 3).value = tempStr[3].rstrip().replace('\n', '').replace('\r\n', '')
					ws.cell(row = cellIndex, column = 4).value = tempStr[2]
				elif kubun == 5:
					# 氏名又は施設名が改行されている場合
					temp_strCount = len(tempStr[3])
					if temp_strCount < 3:
						# 名前に改行が含まれいる場合
						hosp = tempStr[4].rstrip().replace('\n', '').replace('\r\n', '')
						ws.cell(row = cellIndex, column = 3).value = hosp
						name = tempStr[2] + tempStr[3]
						ws.cell(row = cellIndex, column = 4).value = name
					else:
						# 施設名に改行が含まれている場合
						hosp = tempStr[3].replace('\n', '') + tempStr[4].rstrip().replace('\n', '').replace('\r\n', '')
						ws.cell(row = cellIndex, column = 3).value = hosp
						ws.cell(row = cellIndex, column = 4).value = tempStr[2]
				else :
					# 氏名、施設名共に改行が含まれている場合
					hosp = tempStr[4].replace('\n', '') + tempStr[5].rstrip().replace('\n', '').replace('\r\n', '')
					ws.cell(row = cellIndex, column = 3).value = hosp
					name = tempStr[2] + tempStr[3].rstrip().replace('\n', '').replace('\r\n', '')
					ws.cell(row = cellIndex, column = 4).value = name
				contertCounter +=1
				cellIndex += 1
			line = result_file.readline()
			isFirst = False
		print(u'変換処理数：', contertCounter)
		result_file.close

	if __name__ == '__main__':
		wb = openpyxl.Workbook()
		ws = wb.active
		ws.title = "WorkSheetTitle"
		ws.sheet_properties.tabColor = "1072BA"
		fill = PatternFill(patternType='solid', fgColor='36bd11')
		for rows in ws['A1':'D1']:
			for cell in rows:
				ws[cell.coordinate].fill = fill
		ws["A1"] = "区分"
		ws["B1"] = "都道府県"
		ws["C1"] = "施設名"
		ws["D1"] = "個人名"
			
		ws.auto_filter.ref = 'A1:D1'

		load_pdf()
		load_csv(wb, cellIndex)
		
		print(u'同名ファイル存在チェック : ', os.access(outPutFile,os.F_OK))
		if(os.access(outPutFile,os.F_OK)):
			print(u'ファイル削除')
			os.remove(outPutFile)
			print(u'同名ファイル存在チェック : ', os.access(outPutFile,os.F_OK))
		wb.save(outPutFile)
		print(u'Excel変換終了')