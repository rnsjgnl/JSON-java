var log4js = require('log4js');
var logger = '';
var logFileName = '';

exports.logSettingInformation = function logConfig (num, code, file, today) {
	logFileName = 'logs/' + code + '_' + file + '_' + today + '.log'
	log4js.configure({
		appenders: {
			stdout: {
				type: 'stdout'
			},
			system: {
				type: 'file',
				filename: logFileName,
				pattern: '.yyyy-MM-dd',
				keepFileExt: true
			}
		},
		categories: {
			default: {
				appenders: ['stdout', 'system'],
				"replaceConsole": true,
					level: 'all'
			}
		}
	});
	logger = log4js.getLogger(file[num]);
	return logger;
}